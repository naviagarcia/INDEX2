# SGSINDICAL v9.1 — Aplicación de escritorio

Sistema de gestión sindical sobre **PostgreSQL**, con backend **Python + FastAPI**, interfaz **React** y ventana de escritorio nativa (**pywebview**). Construido a partir del script *Master DDL v9.0*.

```
sgsindical/
├── db/                      Scripts SQL (ejecutar en orden)
│   ├── 01_sgsindical_v9_1_estructura.sql      Tu script v9.0 corregido
│   ├── 02_seguridad_auditoria_indices.sql     Usuarios, permisos, auditoría, concurrencia, índices
│   ├── 02b_reglas_directivos.sql              Catálogo de cargos y reglas estatutarias de directivos
│   ├── 02c_acceso_territorial.sql             Acceso por ámbito territorial (seguridad por filas)
│   ├── 02d_notificaciones.sql                 Correos automáticos de alertas
│   ├── 02e_finanzas.sql                       Gestión financiera
│   ├── 02f … 02i                              Reuniones, redes sociales, escritos jurídicos, contenidos
│   ├── 03_roles_permisos.sql                  Roles de PostgreSQL de mínimo privilegio (psql)
│   ├── 03_roles_permisos_pgadmin.sql          La misma versión, para el Query Tool de pgAdmin
│   ├── 05_inactivacion.sql                    Nada se borra: inactivar, reactivar y anular (R-01)
│   ├── 06_datos_personales.sql                Ley 1581: datos reservados, bitácora de accesos, consentimiento
│   ├── 07_porcentaje_aporte.sql               Aporte 0,6 % / 0,7 %, novedades de nómina y exoneraciones
│   ├── 08_ventanilla_autoservicio.sql         Ventanilla, solicitudes de afiliación y portal del afiliado
│   ├── 09_mfa.sql                             Verificación en dos pasos (MFA)
│   ├── 10_pqrsd.sql                           PQRSD recibidas (Ley 1755 de 2015)
│   ├── 11_endurecimiento.sql                  Endurecimiento: la contraseña de la base no basta para saltarse las reglas
│   ├── 12_roles_suplencias.sql                Varios roles por persona, contexto activo, incompatibilidades y suplencias
│   ├── 13_plazos_ley.sql                      Plazos de ley (Leyes 1755 y 1581): aclaración, recurso, reclamo incompleto, traslado y leyenda
│   ├── 14_niveles_jefes.sql                   Niveles de jefes 1 a 4, representante legal y cadena de escalamiento
│   ├── 15_documentos_legales.sql              Política de datos 2.0, aviso de privacidad, reglamento de PQRSD y criterio de cautela
│   ├── 16_expediente_afiliacion.sql           Expediente documental de afiliación, afiliados dispersos y datos institucionales
│   ├── 17_lugares_traslados.sql               Países ISO 3166-1, DIVIPOLA, traslados entre juntas con dos actas y grupo Palmira
│   ├── 17b_divipola_municipios.sql            Lista oficial DIVIPOLA del DANE: 1.122 municipios, áreas no municipalizadas e isla
│   ├── datos/DIVIPOLA_codigos_municipios.csv  Archivo original del DANE (datos.gov.co) del que sale 17b
│   ├── 18_posesion_permisos.sql               Posesión con el registro del inspector (designaciones) y permisos sindicales
│   ├── 04_datos_demo.sql                      Datos de prueba (opcional; va al final)
│   └── instalar.sh / instalar.bat
├── backend/                 API FastAPI (también sirve la interfaz compilada)
│   ├── app/                 main, auth, crud, vistas, operaciones, seguridad, recursos, cli
│   ├── frontend_dist/       Interfaz React ya compilada (no necesita Node para usarla)
│   ├── tests/prueba_api.py  806 pruebas de extremo a extremo
│   └── .env.ejemplo
├── frontend/                Código fuente React (Vite)
├── escritorio/              Lanzador de escritorio + scripts para generar el .exe
└── ops/                     Backups programados, restauración y mantenimiento de índices
```

---

## 1. Instalación paso a paso

### 1.1 Base de datos (PostgreSQL 15 o superior)

```bash
cd db
./instalar.sh sgsindical --demo        # Linux/macOS  (quite --demo en producción)
instalar.bat sgsindical --demo         # Windows
```

Pide cuatro contraseñas, una por rol de base de datos (ver sección 2). Si prefiere hacerlo a mano:

```bash
psql -d sgsindical -f 01_sgsindical_v9_1_estructura.sql
psql -d sgsindical -f 02_seguridad_auditoria_indices.sql
psql -d sgsindical -f 02b_reglas_directivos.sql
psql -d sgsindical -f 02c_acceso_territorial.sql
psql -d sgsindical -f 02d_notificaciones.sql
psql -d sgsindical -f 02e_finanzas.sql
psql -d sgsindical -f 02f_reuniones_actas.sql
psql -d sgsindical -f 02g_redes_sociales.sql
psql -d sgsindical -f 02h_escritos_juridicos.sql
psql -d sgsindical -f 02i_contenidos_redes.sql
psql -d sgsindical -v app_pass='...' -v lectura_pass='...' -v backup_pass='...' -v notif_pass='...' -f 03_roles_permisos.sql
psql -d sgsindical -f 05_inactivacion.sql
psql -d sgsindical -f 06_datos_personales.sql
psql -d sgsindical -f 07_porcentaje_aporte.sql
psql -d sgsindical -f 08_ventanilla_autoservicio.sql
psql -d sgsindical -f 09_mfa.sql
psql -d sgsindical -f 10_pqrsd.sql
psql -d sgsindical -f 11_endurecimiento.sql
psql -d sgsindical -f 12_roles_suplencias.sql
psql -d sgsindical -f 13_plazos_ley.sql
psql -d sgsindical -f 14_niveles_jefes.sql
psql -d sgsindical -f 15_documentos_legales.sql
psql -d sgsindical -f 16_expediente_afiliacion.sql
psql -d sgsindical -f 17_lugares_traslados.sql
psql -d sgsindical -f 17b_divipola_municipios.sql
psql -d sgsindical -f 18_posesion_permisos.sql
psql -d sgsindical -f 04_datos_demo.sql          # solo en pruebas
```

**Con pgAdmin (Query Tool):**
1. Cree la base `sgsindical` y abra el Query Tool conectado a ella como `postgres`.
2. Abra y ejecute (F5) **uno por uno, en este orden**:
   - `01`, `02`, `02b`, `02c`, `02d`, `02e`, `02f`, `02g`, `02h`, `02i`;
   - `03_roles_permisos_pgadmin.sql`, después de cambiar en él las cuatro contraseñas (`CAMBIAR_…`). **No use `03_roles_permisos.sql` en pgAdmin**: tiene comandos que solo entiende psql.
   - `05_inactivacion.sql` (debe ir después de `03`, porque le quita a la aplicación el permiso de borrar).
   - `06_datos_personales.sql` (después de `05`) `07_porcentaje_aporte.sql`, `08_ventanilla_autoservicio.sql`, `09_mfa.sql`, `10_pqrsd.sql`, `11_endurecimiento.sql`, `12_roles_suplencias.sql`, `13_plazos_ley.sql`, `14_niveles_jefes.sql`, `15_documentos_legales.sql`, `16_expediente_afiliacion.sql`, `17_lugares_traslados.sql`, `17b_divipola_municipios.sql` y `18_posesion_permisos.sql`, en ese orden.
   - `04_datos_demo.sql`, solo en pruebas.
   
   **Si ya tenía instalada la versión anterior**, basta con ejecutar `05_inactivacion.sql`, `06_datos_personales.sql`, `07_porcentaje_aporte.sql`, `08_ventanilla_autoservicio.sql`, `09_mfa.sql`, `10_pqrsd.sql`, `11_endurecimiento.sql`, `12_roles_suplencias.sql`, `13_plazos_ley.sql`, `14_niveles_jefes.sql`, `15_documentos_legales.sql`, `16_expediente_afiliacion.sql`, `17_lugares_traslados.sql`, `17b_divipola_municipios.sql` y `18_posesion_permisos.sql`, en ese orden, sobre la base existente: no borran ni cambian datos, solo agregan columnas, reglas y vistas. Haga antes un backup.
   
   **Importante:** si algún día vuelve a ejecutar `03_roles_permisos…`, ejecute de nuevo `05` a `18` después. Y si vuelve a ejecutar cualquiera de los scripts `02b` a `17`, ejecute otra vez `11_endurecimiento.sql`, `12_roles_suplencias.sql`, `13_plazos_ley.sql`, `14_niveles_jefes.sql`, `15_documentos_legales.sql`, `16_expediente_afiliacion.sql`, `17_lugares_traslados.sql` y `18_posesion_permisos.sql` al final, en ese orden (rehacen sus protecciones), porque `03` vuelve a dar a la aplicación permisos que estos scripts retiran (borrar y leer salario y género).
3. Espere el mensaje de éxito de cada archivo antes de abrir el siguiente.

### 1.2 Backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.ejemplo .env                                   # y edite DATABASE_URL, JWT_SECRET, carpetas
python -m app.cli verificar                            # prueba conexión y políticas
python -m app.cli crear-admin --usuario admin          # crea el primer administrador
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

### 1.3 Aplicación de escritorio

Hay dos modos, que se eligen en `escritorio.ini`:

| Modo | Cuándo usarlo | Cómo funciona |
|---|---|---|
| **central** (recomendado) | Varios usuarios | Un servidor corre el backend; cada equipo abre la ventana apuntando a ese servidor. Las credenciales de PostgreSQL **no** quedan en los equipos. |
| **local** | Un solo equipo | La app arranca el backend dentro de sí misma en `127.0.0.1` (solo accesible desde ese equipo). Requiere `.env` junto al programa. |

Probar sin empaquetar:

```bash
cd escritorio
pip install -r requirements-escritorio.txt
python sgsindical_escritorio.py
```

Generar el instalable (en el sistema operativo destino):

```bat
escritorio\construir_windows.bat        → dist\SGSINDICAL\SGSINDICAL.exe
```

Distribuya la carpeta `dist\SGSINDICAL` con su `escritorio.ini` configurado.

### 1.4 Modificar la interfaz (opcional)

```bash
cd frontend
npm install
npm run dev        # desarrollo en http://localhost:5173 (usa el backend en :8000)
npm run build      # recompila en backend/frontend_dist
```

---

## 2. Políticas implementadas

### Auditoría
- **Bitácora de cambios en las 24 tablas** (el script original solo cubría 7): cada INSERT/UPDATE/DELETE guarda los datos anteriores y nuevos en JSONB, con el **usuario real de la aplicación** e IP.
- **Registro de accesos**: ingresos, intentos fallidos, bloqueos, cierres de sesión, cambios de contraseña, sesiones revocadas y **cada intento de acción sin permiso**.
- **Registro de backups** con tamaño, huella SHA-256, estado y usuario.
- Las tres tablas de auditoría son **inmutables**: un trigger rechaza UPDATE, DELETE y TRUNCATE incluso para el administrador, y el rol de la aplicación ni siquiera tiene permiso de escritura directa sobre la bitácora.
- La contraseña cifrada nunca se copia a la bitácora.
- **Historial de trámite automático** al radicar y en cada cambio de estado, con observación.

### Seguridad
- Contraseñas con **PBKDF2-SHA256** (390.000 iteraciones y sal aleatoria).
- Política de contraseñas: mínimo 10 caracteres, mayúscula, minúscula, número, símbolo, sin contener el usuario. Vencen a los 90 días. **Cambio obligatorio en el primer ingreso.**
- **Bloqueo de cuenta** tras 5 intentos fallidos (15 min) y límite de intentos por equipo.
- Sesiones con token firmado que **se validan contra la base en cada petición**: se pueden revocar al instante, vencen a las 8 h y **se cierran por 30 min de inactividad**.
- El administrador ve las **sesiones activas** y puede cerrarlas.
- **Radicados inmutables** y **archivos PDF con huella SHA-256**: se verifica la integridad en cada descarga y un archivo firmado no se puede reemplazar. Solo se aceptan PDF reales (se valida la firma del archivo, no solo la extensión).
- Cabeceras de seguridad (CSP, anti-clickjacking, no-sniff), sin caché de respuestas de la API y mensajes de error que no exponen detalles internos.
- En la app de escritorio, modo privado: no se guardan cookies ni datos al cerrar.
- **Verificación en dos pasos (MFA)** obligatoria para directivos, personal y administrador; opcional para afiliados (ver sección 3m).

### Permisos de acceso (dos niveles)
**Aplicación.** Cada rol tiene, por módulo, cinco permisos independientes: **Consultar, Registrar, Actualizar, Eliminar y Ver vistas**. El administrador los cambia desde *Administración → Matriz de permisos* y el cambio aplica en la siguiente acción del usuario. La interfaz oculta lo no permitido **y el servidor lo rechaza** aunque se intente saltar la interfaz.

| Rol | Gobernanza | Documental | Finanzas | Auditoría | Administración |
|---|---|---|---|---|---|
| ADMIN | Todo | Todo | Todo | Consultar + vistas | Todo |
| DIRECTIVO | C R A + vistas | C R A + vistas | C + vistas | — | — |
| TESORERO | C | C | Todo | — | — |
| AUDITOR | C + vistas | C + vistas | C + vistas | C + vistas | — |
| CONSULTA | C | C | — | — | — |

*(C = consultar, R = registrar, A = actualizar). Protecciones: nadie puede desactivarse ni quitarse el rol a sí mismo, y el rol ADMIN no puede perder el acceso a Administración.*

**Base de datos** (`03_roles_permisos.sql`), con mínimo privilegio:
- `sgs_app`: el backend. Solo lectura/escritura de datos; no puede crear ni alterar tablas, no puede editar historiales ni la bitácora. Tiene tiempos máximos de sentencia y de bloqueo.
- `sgs_lectura`: reportes/BI, solo SELECT, sin acceso a contraseñas ni sesiones.
- `sgs_backup`: solo lectura para `pg_dump`.

### Control de concurrencia
- **Bloqueo optimista**: cada registro tiene una columna `version`. Si dos personas editan el mismo registro, la segunda recibe un aviso con los datos actuales y el botón *Cargar datos actuales*, en lugar de sobrescribir el trabajo del otro. Lo mismo al eliminar.
- **Consecutivos sin duplicados**: radicados y códigos de expediente se serializan con `pg_advisory_xact_lock`. Probado con 20 radicaciones simultáneas desde PostgreSQL y 15 desde la API: todos únicos.
- Transacciones atómicas por operación, pool de conexiones y bloqueo de fila (`FOR UPDATE`) en login, cambio de contraseña, adjuntos y generación de aportes.

### Backups
- `pg_dump` en formato comprimido y restaurable, con archivo `.sha256` de verificación.
- Botón **Hacer backup ahora** y **Verificar integridad** en *Administración → Backups*.
- Backup programado: `ops/backup.sh` (cron) u `ops/backup.bat` (Programador de tareas; el comando `schtasks` está dentro del archivo).
- Retención automática (30 días por defecto, siempre conserva los 3 más recientes).
- `ops/restaurar_backup.*` verifica la huella y restaura en una **base nueva**, nunca encima de producción.
- **Importante:** copie también la carpeta `UPLOAD_DIR` (los PDF) y guarde copias fuera del servidor.

### Gestión de índices
- **48 índices nuevos**: PostgreSQL no indexa automáticamente las llaves foráneas y el script original no tenía ninguno, así que los JOIN de las vistas y los borrados en cascada recorrían tablas completas. Se agregaron índices a todas las llaves foráneas y a los filtros de las vistas, incluidos índices parciales (trámites pendientes y compromisos abiertos).
- Vistas de monitoreo en la app: **Monitor de índices** (tamaño, uso, inválidos), **Monitor de tablas** (filas muertas, lecturas secuenciales) y **Llaves foráneas sin índice** (debe estar vacía; si no, sugiere el `CREATE INDEX`).
- `ops/mantenimiento.sql`: VACUUM/ANALYZE, limpieza de sesiones viejas y `REINDEX CONCURRENTLY` de índices inválidos. Programarlo semanalmente.

---

## 3. Reglas estatutarias de cargos directivos

Las impone la base de datos (`02b_reglas_directivos.sql`). Se cumplen aunque los datos se modifiquen fuera de la aplicación y aunque dos usuarios guarden al mismo tiempo, porque las reglas 2 a 4 son índices únicos de PostgreSQL.

| Junta | Cargos |
|---|---|
| Junta Directiva Nacional (única) | 12: Presidente, Vicepresidente, Secretario General, Tesorero, Fiscal, Secretarios Jurídico, de Educación, de Cultura, del Mérito y de Comunicaciones, Comisionados de Reclamos 1 y 2 (Nal) |
| Cada Subdirectiva | Los mismos 12 (Reg) |
| Cada Comité Seccional | 2: Presidente Comité y Secretario General Comité |

1. Solo se asignan cargos del catálogo y del tipo de la junta (un cargo "Reg" no se asigna en un comité).
2. **Cada cargo de una junta lo ocupa una sola persona.**
3. **Una persona no puede tener dos cargos en la misma junta.**
4. Máximo simultáneo por persona: **1 cargo nacional + 1 cargo en una subdirectiva o comité**.
5. El cargo de subdirectiva o comité solo se ejerce en el estamento al que **pertenece** el afiliado (campo nuevo en Afiliados). La Junta Directiva Nacional puede conformarse con directivos de cualquier lugar del país. Los comités seccionales no dependen de una subdirectiva.
6. **Registro vigente.** El inspector de trabajo emite el registro a la Subdirectiva, al Comité o a la Nacional. Cada directivo vigente queda asociado automáticamente al registro vigente (el más reciente) de su estamento. Cuando se emite uno nuevo, todos los directivos que continúan pasan a él y el anterior queda en el *Historial de registros por directivo*. Sin registro no se pueden hacer nombramientos. El registro **no** cambia el periodo de nadie: cada directivo sigue en su cargo hasta que vence su periodo personal, aunque al resto de la junta ya se le haya vencido.
7. **Una empresa por afiliado y pertenencia según la sede.** Cada afiliado está vinculado a una sola empresa y, si no trabaja en la sede central, a una de las sedes de esa empresa. Solo puede pertenecer a la Subdirectiva o Comité Seccional del municipio de su sede de trabajo **o** del municipio de la sede central (por ejemplo, quien trabaja en Cúcuta puede ser de la Subdirectiva Cúcuta o de la de Bogotá, pero de una sola). Para un traslado, en *Empresa y sede del afiliado* se cambia la sede y la nueva pertenencia en la misma operación. La vista *Pertenencia de afiliados* señala cualquier inconsistencia.
7b. Para cambiar a un directivo se registra la **fecha de retiro** del actual: el cargo queda libre y el registro anterior se conserva como historial. Un afiliado con cargo local vigente no puede cambiar de pertenencia sin retirarse antes.
8. **El Fiscal no se rota.** Dentro de la misma junta y periodo, el Fiscal no puede pasar a otro cargo y ningún directivo puede pasar a Fiscal. Los demás cargos sí pueden rotarse (retiro y nuevo nombramiento). Tras vencer el periodo se permite una nueva elección. Se controla con la casilla *Permite rotación* del catálogo de cargos.
9. **El periodo de 2 años es individual.** Cuando un directivo rota de cargo dentro de la misma junta, el nuevo nombramiento conserva el inicio y el fin del periodo que traía; no vuelve a empezar. Solo una elección después de vencido el periodo abre un periodo nuevo.
10. **Tipo de nombramiento.** *Elección* y *Reelección* abren un periodo nuevo de 2 años desde la posesión (también si se posesiona antes de que termine el periodo anterior). La reelección es en el mismo cargo que la persona ya ejerció en esa junta y **no tiene límite**; el Fiscal puede reelegirse como Fiscal. *Rotación* es pasar de otro cargo de la misma junta dentro del mismo periodo y conserva ese periodo (el Fiscal no rota).

### Historia de las juntas

*Gobernanza → Juntas en el tiempo* muestra quiénes integraban cualquier junta en una **fecha pasada** (cargo por cargo, incluidas las vacantes, con su tipo de nombramiento, posesión, fin del periodo, retiro y registro vigente en esa fecha) y la **composición oficial de cada registro** del inspector de trabajo. Nada se borra: cada nombramiento conserva su posesión y su retiro, y cada registro conserva a los directivos que figuraron en él. La consulta respeta el ámbito territorial de quien la hace.

### Jerarquía de jefes de empresa

Script `14_niveles_jefes.sql`. La jerarquía sirve para saber **a quién escalar una queja** y **con quién negociar**. Los niveles se definen por la posición en la entidad, no por el nombre del cargo, para que sirvan igual en entidades públicas y en empresas privadas:

| Nivel | Posición |
|---|---|
| 1 | Coordina un grupo, equipo o proceso |
| 2 | Dirige un área o una dependencia |
| 3 | Hace parte de la alta dirección (subdirector, secretario, vicepresidente de la empresa) |
| 4 | Máxima autoridad de la entidad (gerente, director, alcalde, ministro, Presidente) |

- Nadie es jefe de sí mismo, ni directamente ni a través de una cadena (la base bloquea cualquier ciclo, aunque dos usuarios guarden a la vez).
- El jefe directo tiene un nivel **igual o superior** y puede ser de otra entidad (gerente de una entidad adscrita → ministro → Presidente, todos nivel 4). Un jefe no puede bajar de nivel por debajo de quienes dependen de él.
- **Los niveles 1 a 3 deben tener jefe directo**: es la cadena para escalar. La máxima autoridad (nivel 4) puede tener jefe en otra entidad o no tenerlo. Por eso los jefes se registran de arriba hacia abajo.
- El jefe directo de un **afiliado** debe ser de su misma empresa y no puede ser él mismo.
- **Representante legal:** cada empresa tiene **uno solo**, registrado como jefe de esa misma empresa, **de cualquier nivel**. Una persona puede ser representante legal de **varias empresas** (por ejemplo, una pública y otra particular): se registra como jefe en cada una. Lo mismo para el jefe de talento humano.
- Vista **A quién escalar y con quién negociar**: para cada afiliado, la cadena de jefes desde su jefe directo hasta la máxima autoridad, con el representante legal y el jefe de talento humano de su empresa, y alerta si la cadena está incompleta o tiene un jefe inactivo.
- Vista **Jerarquía de jefes**: jefes sin jefe directo, representantes legales que no son nivel 4 (se permite, pero se señala) y niveles por revisar.

**Cambio desde la escala anterior (1 a 6).** Los niveles 5 (viceministros y ministros) y 6 (Presidente) pasaron a 4. Los niveles 2 y 3 anteriores no se pueden convertir solos (un secretario de despacho puede ser 2 o 3 según la entidad): conservan su número y quedan marcados **«Nivel por revisar»**, igual que los antiguos nivel 5 (un viceministro es alta dirección, nivel 3). Ábralos desde la vista *Jerarquía de jefes*, confirme o corrija el nivel y desmarque la casilla.

## 3b. Acceso por ámbito territorial

PostgreSQL filtra los datos con **seguridad por filas** según el usuario de cada operación (`02c_acceso_territorial.sql`). Las pantallas, búsquedas, listas desplegables y vistas de alertas muestran solo lo permitido.

**Ámbito de cada usuario**
- **Nacional (todo el país, consultar y actualizar):** el rol ADMIN, el usuario con *Acceso a todo el país* marcado, o quien ocupe un cargo vigente con *Da acceso a todo el país* marcado en el catálogo de cargos. Por defecto **ningún cargo** lo tiene marcado: el administrador decide cuáles.
- **Territorial:** los estamentos donde la persona vinculada al usuario ocupa un cargo vigente (un directivo nacional sin acceso nacional ve la información propia de la Junta Nacional y la de su subdirectiva o comité), más los que el administrador le asigne en *Ámbitos de usuario* (personal de apoyo).
- Al registrar el retiro de un cargo, el acceso se pierde de inmediato.

**Qué ve cada ámbito**
- Afiliados, su empresa y salario: los que pertenecen a sus estamentos.
- Empresas, sedes, jefes y comités de empresa: solo las empresas donde sus estamentos tienen afiliados (y las aún sin afiliados, para poder registrarlas). Para vincular un afiliado a una empresa que ya existe con afiliados de otros estamentos, se busca por **NIT**.
- Documentos, expedientes, compromisos, cuentas, consignaciones y aportes: los de sus estamentos.
- Directivos: los de sus estamentos; la composición de la Junta Nacional es pública.
- Bitácora, accesos y backups: solo el ámbito nacional.
- Directorio común: estamentos, inspectores, registros, tipos documentales y cargos (solo el ámbito nacional modifica estamentos y catálogos).

**Alcance de esta protección:** el filtro se apoya en el usuario que la aplicación indica en cada transacción. Protege contra errores de la aplicación y contra cualquier acceso a través de ella, pero quien tenga la contraseña del rol `sgs_app` podría suplantar a otro usuario; por eso esa contraseña solo debe estar en el servidor. `sgs_lectura` (reportes) y `sgs_backup` no están sujetos al filtro.

## 3c. Correos automáticos de alertas

Una tarea programada envía los correos (`ops/notificar.sh` con cron o `ops/notificar.bat` con el Programador de tareas; el comando está dentro de cada archivo). Prográmela **cada 30 minutos entre las 6:00 a. m. y las 8:00 p. m.**: así se reintentan pronto las convocatorias que no salieron (las demás alertas no se repiten aunque la tarea corra muchas veces). También se pueden **simular** o **enviar ahora** desde *Administración → Correos automáticos*.

| Correo | A quién | Cuándo |
|---|---|---|
| **Convocatoria a reunión** | Cada directivo vigente de la junta | Al convocar (se envía en el momento; si falla se reintenta hasta las 8:00 p. m. y antes de la reunión) |
| Redes sociales sin publicar | Responsable de la cuenta, con copia al Presidente y al Secretario General | Cuando una cuenta activa supera 5 días sin publicar, y cada 5 días mientras siga así |
| Cancelación de reunión | Cada directivo vigente de la junta | Al cancelar una reunión convocada |
| **Juntas sin acta de reunión mensual** | Todos los directivos vigentes de la junta | Las juntas deben reunirse **al menos una vez por mes calendario**. Cada semana: si no hubo acta (ACT) el mes anterior ni en el mes en curso, o si falta una semana o menos para cerrar el mes sin acta |
| Consolidado de actas | Presidente, Secretario General y Fiscal Nacional | Cada semana, con todas las juntas atrasadas |
| Vencimiento del periodo personal | El directivo, con copia al presidente de su junta | A los 90, 60 y 30 días del vencimiento, y cada mes si ya venció |
| Informe de gestión trimestral | El directivo, con copia al presidente de su junta | 15 días antes de vencer el trimestre y cada mes si está vencido |
| Inactividad documental | Presidente y secretario general de cada junta (la Nacional recibe el de todo el sindicato) | Resumen semanal de los tipos de documento sin emitir hace más de 30 días |
| Cumpleaños | El afiliado | El día de su cumpleaños (los nacidos el 29 de febrero, el 28 en años no bisiestos) |

- **Sin duplicados:** cada correo tiene una clave única; ejecutar la tarea varias veces al día no repite envíos, ni siquiera si dos ejecuciones coinciden.
- **Reintentos:** si el servidor de correo falla, el envío queda como *FALLIDO* y se reintenta en la siguiente ejecución.
- **Historial:** *Auditoría → Correos enviados*.
- **Configuración:** *Administración → Tipos de correo automático* permite activar o desactivar cada tipo.
- **Actas:** la vista *Actas de reunión por junta* muestra las actas del mes anterior y del mes en curso y los meses incumplidos en el último año. Una junta nueva no responde por los meses anteriores a la posesión de sus directivos.
- **Informe trimestral:** cada cargo debe radicar un informe de gestión (INF) de su propia junta cada 90 días, contados desde el último informe o desde la posesión. La vista *Rendición de informes* usa ese plazo.
- Usa el rol `sgs_notificador`, que lee la información de todo el país y solo escribe el historial de envíos. Configure en el `.env`: `NOTIFICADOR_DATABASE_URL`, `SMTP_*`, `CORREO_REMITENTE`, `APP_URL` y, como respaldo, `SINDICATO_NOMBRE` (el nombre oficial se toma de *Administración → Datos institucionales*). Con Gmail o Microsoft 365 use una contraseña de aplicación.

## 3d. Gestión financiera

**Cuentas y fondos.** Hay una cuenta **nacional** (de la Junta Directiva Nacional) y cada Subdirectiva o Comité puede tener **una subcuenta hija** de ella, o ninguna. Además de las cuentas físicas, el sistema lleva el **fondo** de cada junta: cada aporte se reparte **20 % a la Junta Nacional y 80 % a la subdirectiva o comité al que pertenece el afiliado** (parámetro `PORCENTAJE_NACIONAL`). Una junta sin subcuenta tiene su dinero en la cuenta nacional y lo mueve desde allí; una junta con subcuenta debe tenerlo en ella, y la vista *Transferencias pendientes* indica cuánto debe transferirse en cada sentido. Las transferencias solo se registran entre la cuenta nacional y sus subcuentas.

**¿A qué cuenta consignan las empresas?**
- Las empresas y demás personas pueden consignar **directamente en la subcuenta** de la subdirectiva o comité, o **en la cuenta nacional (padre)**.
- Una empresa puede repartir el pago de un mes entre las dos; se registra **una consignación por cuenta y mes**.
- El sistema solo acepta una subcuenta si la empresa tiene afiliados de esa junta.
- **Aportes:** el botón *Generar aportes* crea el aporte de cada afiliado que aún no lo tenga ese mes, y nunca duplica el de un afiliado aunque haya dos consignaciones. Si la empresa repartió el pago, use *Solo afiliados de la junta de la subcuenta* en la consignación hecha a la subcuenta.
- **Reparto:** sin importar a qué cuenta llegó, el dinero se reparte por fondos (20 % Nacional, 80 % la junta de cada afiliado).
- **Vistas:**
  - *Consignaciones por cuenta* muestra cuánto de cada consignación es de la junta dueña de la cuenta y cuánto de otros fondos.
  - *Transferencias pendientes* indica cómo equilibrar: lo que la subcuenta debe pasar a la Nacional, o al revés.
  - La **mora** suma lo consignado en todas las cuentas.
- Los **otros ingresos** (donaciones, rendimientos…) de una junta también pueden llegar a su subcuenta o a la cuenta nacional.
- Cada junta ve las consignaciones de sus empresas tanto en su subcuenta como en la cuenta nacional. La cuenta nacional aparece en las listas de todas las juntas para poder registrarlas, pero su saldo solo lo ve el ámbito nacional.

**Egresos con doble firma.** Cada egreso tiene rubro, beneficiario y **soporte PDF** (factura o cuenta de cobro, con huella SHA-256). Para aprobarse necesita **dos firmas: Tesorero y Presidente** de la junta (en los comités, que no tienen tesorero: Secretario General y Presidente). El sistema identifica el cargo de quien firma; el Fiscal y el administrador no pueden firmar. Con la segunda firma la base verifica el **presupuesto** y que haya **fondos** suficientes en la junta y en la cuenta. Un egreso aprobado **no se modifica**: se **anula** con motivo y queda en el historial.

**Presupuesto anual** por junta y rubro, aprobado con un acta de reunión (ACT) de la misma junta. Un egreso que supera el presupuesto (o sin presupuesto) solo se aprueba con un **acta de autorización**. *Ejecución presupuestal* alerta al llegar al 80 % y al superar el 100 %.

**Mora de empresas.** *Mora de empresas* compara, mes a mes (últimos 12 meses vencidos; plazo hasta el día 15 del mes siguiente), lo que cada empresa debía consignar según los **salarios vigentes** de sus afiliados con lo que consignó.

**Historial de salarios.** Cada cambio de salario se guarda con su fecha de vigencia (*El nuevo salario rige desde*). El 0,7 % y la mora de cada mes se calculan con el salario vigente en ese mes.

**Cierre mensual y conciliación.** El Tesorero (en comités, el Secretario General) cierra cada mes terminado en *Finanzas → Cierre mensual*; desde entonces no se registran ni modifican movimientos de ese mes. Solo el administrador lo reabre, con motivo. En *Conciliación bancaria* se registra el saldo del extracto y el sistema lo compara con su propio saldo.

**Informes y control fiscal.** *Saldo de los fondos*, *Saldo de las cuentas*, *Ingresos y egresos por mes*, *Movimientos de los fondos*, *Ejecución presupuestal* y *Alertas financieras (Fiscal)*, todos exportables a Excel (CSV) e imprimibles como PDF. Correos automáticos: **mora de empresas** cada semana al Tesorero de cada junta (el Nacional recibe la de todo el país) y **resumen financiero** cada mes al Fiscal de cada junta.

Los **parámetros** (porcentaje del aporte, porcentaje nacional, día límite de consignación, tolerancia, exigencia de presupuesto) se ajustan en *Finanzas → Parámetros financieros* (solo el ámbito nacional). Cada junta ve solo sus fondos y movimientos; las obligaciones tributarias y contables del sindicato deben confirmarse con su contador.

## 3e. Reuniones, convocatorias y actas

*Gestión documental → Reuniones y actas.*

**Convocatoria.** No hay frecuencia fija: cada junta se reúne cuando lo considera necesario.
- Convocan solo el **Presidente** o el **Secretario General** vigentes de la junta.
- El sistema envía un correo a **cada directivo** vigente con la fecha, la hora, la modalidad, el lugar o enlace y el **orden del día propuesto** (obligatorio, al menos un punto).
- La convocatoria se rechaza si sale con **menos de 12 horas de anticipación** o **después de las 8:00 p. m.** (hora de Colombia, configurable en `ZONA_HORARIA`).
- Los datos de la convocatoria no se cambian. Para modificarlos se **cancela** la reunión (solo antes de la hora de inicio, con motivo, y los directivos reciben un correo) y se convoca de nuevo. Las reuniones no se eliminan.

**Ordinaria o extraordinaria.** El sistema lo decide:
- La **primera reunión de cada trimestre** calendario (enero–marzo, abril–junio, julio–septiembre, octubre–diciembre) es **ORDINARIA**; las demás del trimestre, **EXTRAORDINARIAS**.
- Si se convoca una reunión anterior en el mismo trimestre, o se cancela la ordinaria, el tipo se recalcula.

**Durante la reunión** (desde la hora de inicio):
- **Asistencia de todos.** Los directivos convocados ya están en la lista. Para cada uno se marca si asistió, la forma (presencial o virtual), la hora de llegada y salida, o su excusa.
- **Invitados.** Se agregan personas registradas o **invitados externos** (nombre, documento, institución, cargo y correo, sin crearlos como personas). Quedan en el acta, pero **no votan ni cuentan para el quórum**.
- La asistencia se guarda en un lote, con control de concurrencia.
- **Orden del día.** El orden convocado es el punto de partida y se puede modificar al empezar la reunión. El acta deja constancia del orden convocado cuando cambió.
- **Decisiones.** Se registran con votos a favor, en contra y abstenciones; se aprueban por mayoría de los votos emitidos. Pueden generar un **compromiso** con responsable y fecha límite.

**Quórum.** Mitad más uno de los directivos vigentes. Sin quórum:
- No se adoptan decisiones.
- El acta queda registrada, pero **no cuenta como la reunión del mes**.

**Firmas y radicación.**
- Firman el **Presidente y el Secretario General** de la junta, cada uno con su usuario. Desde la primera firma el contenido queda congelado.
- Con la segunda firma el acta se **radica (ACT)**, se crean los compromisos y se genera el **PDF del acta** con huella SHA-256.
- El PDF contiene la asistencia de directivos e invitados, el quórum, el orden del día y su desarrollo, las decisiones con votación, los compromisos y las firmas.
- Antes de cerrar se puede descargar una **vista previa** marcada como BORRADOR.

**Aprobación.** El acta se **aprueba en la siguiente reunión con quórum** de la misma junta (casilla *Se aprueba el acta anterior*, con observaciones).

**Vistas.**
- *Control de reuniones*: reuniones convocadas, sin quórum, sin firmar hace más de 7 días, pendientes de aprobación hace más de 45 días, y canceladas.
- *Asistencia de directivos*: porcentaje de asistencia del último año, con alerta para quien faltó sin excusa a las últimas 3 reuniones.

## 3f. Cuentas en redes sociales

*Gobernanza → Redes sociales, Roles en redes sociales y Métricas de redes sociales; vista Seguridad de redes sociales.*

**Inventario.** Cada cuenta (Facebook, Instagram, X, TikTok, YouTube, WhatsApp, Telegram, LinkedIn, Threads u otra) pertenece a una junta (Nacional, subdirectiva o comité) y registra:
- usuario o @, enlace, correo de acceso y estado;
- correo y teléfono de recuperación, a nombre de quién está el teléfono y si son **institucionales**;
- verificación en dos pasos y su método;
- responsable de administrarla, fecha de la última publicación y métricas mensuales (seguidores, publicaciones, alcance, interacciones).

**Claves cifradas.**
- La clave se guarda **cifrada con AES-256-GCM**. La llave (`SECRETOS_LLAVE`) está en el `.env` del servidor, **no en la base de datos**: un backup robado o una consulta directa a la base solo muestran texto cifrado.
- El texto cifrado vive en el esquema `secretos`, al que ningún rol de la aplicación tiene acceso. Solo se usa con funciones que verifican quién lo pide y registran la consulta.
- Cada texto cifrado queda ligado a su cuenta, así que no se puede copiar a otra. Si se altera en la base, el sistema lo detecta.

**Quién ve las claves.**
- Todos los **directivos vigentes de la junta dueña** de la cuenta, y los directivos de la Junta Nacional con acceso nacional.
- El administrador del sistema sin cargo directivo **no** las ve, y un directivo de otra junta tampoco.
- Al retirarse, el directivo deja de verlas de inmediato.
- La clave aparece al pulsar *Ver clave*, se oculta sola a los 30 segundos y no se guarda en la caché del navegador.

**Registro de cada consulta.** Cada vez que alguien **ve o cambia** una clave queda registrado quién, cuándo, desde qué IP y con qué motivo (*Quién la ha visto* en la ficha de la cuenta; *Auditoría → Consultas de claves de redes*). El registro no se puede modificar ni borrar.

**Historial.**
- Las claves anteriores se conservan cifradas, para recuperar una cuenta si alguien cambió la clave sin avisar.
- Ver una clave anterior exige indicar el motivo.
- Botón *Generar clave segura* (20 caracteres aleatorios). Primero se cambia la clave en la red social y luego se registra aquí.

**Alertas** (vista *Seguridad de redes sociales* y correo semanal al Presidente y al Secretario General de cada junta):

| Nivel | Situación |
|---|---|
| Crítica | Cuenta suspendida o en recuperación; el sindicato no tiene registrada la clave |
| Alta | **La clave la conoce quien ya no es directivo** de la junta (la vio o la cambió y luego se retiró): hay que cambiarla |
| Alta | Una persona que ya no es directivo conserva un rol dentro de la red (Meta Business Suite, TikTok Business…) |
| Alta | Correo o teléfono de recuperación personal (no del sindicato); sin verificación en dos pasos |
| Alta | **Cuenta activa sin publicar hace más de 5 días** (máximo ajustable por cuenta) o sin publicaciones registradas |
| Media | Clave sin cambiar hace más de 180 días |

**Publicación de contenidos.**
- Cada cuenta activa debe publicar al menos cada **5 días**; el máximo se puede ajustar por cuenta en *Máximo de días sin publicar*.
- Al superarlo, el sistema envía un correo al **responsable de la cuenta** con copia al Presidente y al Secretario General de la junta. El aviso se repite cada 5 días mientras siga sin publicar.
- El sistema no lee las redes sociales: después de publicar, quien lo hace pulsa **Registrar publicación de hoy** en la ficha de la cuenta (o actualiza *Última publicación*).

**Recomendación.** En Facebook, Instagram, TikTok y YouTube es más seguro dar acceso por **roles** a cada directivo (sin compartir la clave) y registrarlo en *Roles en redes sociales*. En X, que no tiene roles, la clave cifrada es indispensable.

**Configuración de la llave.**
1. Genere la llave con `python -m app.cli generar-llave` y póngala en `SECRETOS_LLAVE` del `.env`.
2. **Guarde una copia en un lugar seguro y separado de los backups**: sin ella, las claves no se recuperan.
3. Todos los servidores o equipos de escritorio que usen la misma base deben tener **la misma llave**. Por eso se recomienda el modo servidor web para este módulo.
4. **Para cambiar la llave:**
   - ponga la nueva en `SECRETOS_LLAVE`;
   - suba `SECRETOS_LLAVE_VERSION`;
   - deje la anterior en `SECRETOS_LLAVE_ANTERIOR`;
   - reinicie y ejecute `POST /api/admin/redes/rotar-llave` como administrador (re-cifra todas las claves);
   - después borre `SECRETOS_LLAVE_ANTERIOR`.

## 3g. Escritos jurídicos con inteligencia artificial

*Gestión documental → Escritos jurídicos (IA).*

**Qué produce.** Proyectos de:
- **derecho de petición**;
- **queja**;
- **comunicado de denuncia pública**;
- **acción de tutela**;
- **recurso de reposición y en subsidio de apelación**;
- **queja por acoso laboral**.

La guía de estructura, normas y cuidados de cada tipo está en *Tipos de escrito jurídico*, y el abogado puede ajustarla.

**A partir de qué.** De uno o varios documentos fuente:
- texto pegado (por ejemplo, un chat de WhatsApp o un relato);
- archivos de texto, **PDF** con texto y **Word (.docx)**;
- **audios** (notas de voz .ogg/.opus, .mp3, .m4a, .wav…);
- **videos** (.mp4, .mov, .webm…).

El audio y el video se **transcriben en el propio servidor** (faster-whisper + ffmpeg), así que la grabación no sale del servidor. Cada fuente queda guardada con su huella SHA-256 y su texto extraído.

**Cómo redacta.** Claude (API de Anthropic) recibe las fuentes, el objetivo y la orientación del tipo de escrito, y entrega **solo el escrito, sin preliminares**. Sus reglas son:
- **no inventar** hechos, fechas, nombres, actos ni sentencias;
- marcar con **[COMPLETAR: …]** lo que falte y con **[VERIFICAR]** las citas dudosas;
- proteger los datos sensibles y usar lenguaje de presunción.

Aparte, y sin formar parte del escrito, deja **notas para la revisión**: datos por completar, citas por verificar, riesgos y plazos.

**Revisión obligatoria.** Ningún proyecto se radica sin **tres aprobaciones sobre la misma versión**:
1. **abogado**: usuario con el rol ABOGADO y ámbito sobre la junta;
2. **Presidente** de la junta;
3. **Secretario General** de la junta.

Los demás directivos pueden **comentar**. Los revisores pueden aprobar, **solicitar cambios** (con comentario) o comentar. Además:
- Cualquier cambio al texto crea una **versión nueva** y las aprobaciones anteriores **dejan de valer**. El cambio puede ser una nueva versión de la IA, que incorpora los comentarios, o una edición manual.
- Si dos personas editan a la vez, el sistema lo detecta: control de concurrencia por número de versión.
- Cada versión, comentario y aprobación queda en el historial.
- Correo a los revisores pendientes al publicarse cada versión, y recordatorio cada 3 días.

**Radicación.**
- Con las tres aprobaciones, el Presidente o el Secretario General **radica** el escrito con el tipo documental que corresponde (PET, QUE, DEN, TUT, REC, ACO).
- El sistema genera el **PDF con huella SHA-256**. Desde ese momento el escrito no se modifica.
- Los escritos que requieren respuesta entran al control de **términos legales** (*Trámites y términos legales*).
- Cualquier versión se descarga en **PDF** (marcado como PROYECTO) o en **Word** para editarla.
- Vista de control: *Control de escritos jurídicos*.

**Configuración** (`.env`):
1. `ANTHROPIC_API_KEY`: clave de la API de Anthropic.
2. `IA_MODELO`: por defecto `claude-opus-5-5`.
3. Para audio y video: `pip install faster-whisper`, ffmpeg instalado y `TRANSCRIPCION_MODELO` (por defecto `small`).
4. `IA_PROVEEDOR=simulado` permite probar el flujo sin IA real.
5. **Privacidad:** el texto de las fuentes se envía a Anthropic para redactar. Evite incluir datos de salud u otros datos sensibles que no sean necesarios, y revise los términos de uso de la API de Anthropic con el abogado del sindicato.

## 3h. Estrategia de contenidos en redes (educación en derechos laborales)

*Gobernanza → Calendario de contenidos, Política de comunicaciones, Publicaciones y resultados, Ejes temáticos, Fechas clave.*

**Política de comunicaciones** por junta: objetivos, públicos, mensajes clave, tono, reglas y meta de publicaciones por semana. La IA puede redactarla completa: propósito, ejes, redes y formatos, frecuencia, revisión, manejo de crisis, uso responsable de la IA, seguridad y medición. **Rige cuando la junta la aprueba con un acta** (la registra el Presidente o el Secretario General) y, desde entonces, no se modifica: se reemplaza por una nueva.

**Calendario editorial.**
- Piezas programadas por fecha, red y **eje temático**, entre ellos:
  - carrera administrativa;
  - negociación colectiva;
  - libertad y fuero sindical;
  - acoso laboral;
  - salud en el trabajo;
  - derecho de petición;
  - estabilidad reforzada;
  - jornada;
  - contratistas;
  - igualdad;
  - vida sindical.
- Incluye las **fechas clave** del año (8 de marzo, 28 de abril, 1 de mayo, 7 de octubre, 10 de diciembre; editables), con aviso si se acercan sin contenido preparado.

**Piezas con IA.**
- La IA crea la pieza en lenguaje sencillo, siguiendo la política vigente y el **material de base** que se pegue (normas o noticias).
- Formatos: guion de video corto, carrusel, hilo para X, publicación, mensaje de WhatsApp, boletín, infografía, y preguntas y respuestas.
- Las citas dudosas se marcan con [VERIFICAR]; las notas para el revisor van aparte.

**Revisión humana obligatoria.** Dos aprobaciones sobre la misma versión:
- **jurídica**: abogado o Secretario Jurídico de la junta;
- **de comunicaciones**: Secretario de Comunicaciones; en los comités, Presidente o Secretario General.

Los demás comentan, y cambiar el texto anula las aprobaciones.

**Publicación y resultados.**
- Se registra en qué cuenta y con qué enlace se publicó. La pieza queda *publicada* y la cuenta actualiza su **última publicación**, lo que la saca de la alerta de 5 días sin publicar.
- Después se anotan alcance, interacciones y compartidos.
- *Rendimiento de contenidos* muestra qué ejes, formatos y redes funcionan mejor.

**Alertas.**
- *Calendario editorial*: piezas vencidas, por publicar sin aprobar y fechas clave sin contenido.
- *Control de contenidos*: junta sin política aprobada, o semana con menos piezas que la meta.
- Correo **diario** a Comunicaciones (en comités, a la Presidencia) y a los abogados con lo pendiente.

---

## 3i. Nada se borra: inactivar, reactivar y anular (regla R-01)

Script `05_inactivacion.sql`. No modifica los scripts anteriores.

| Qué | Cómo se da de baja | Detalle |
|---|---|---|
| Personas, afiliados, empresas, sedes, jefes, juntas, comités y sus miembros, inspectores y sus registros, tipos documentales, cuentas bancarias, cuentas de redes, roles, ámbitos de usuario | **Inactivar / Reactivar** | Con motivo (mínimo 10 caracteres), fecha y usuario. Salen de listas y desplegables; se consultan con «Ver inactivos». |
| Consignaciones, aportes, otros ingresos, transferencias, presupuestos, conciliaciones | **Anular** | Definitivo. Quedan en el historial, fuera de saldos, totales y mora. Anular una consignación anula sus aportes. Solo en meses abiertos y por el Tesorero o el Presidente de la junta. |
| Egresos | **Anular** (ya existía) | Igual que antes. |
| Documentos, compromisos, expedientes | Su propio estado | Documento ANULADO, compromiso CANCELADO, expediente CERRADO o ARCHIVADO. |
| Asistentes, puntos y decisiones de una reunión sin acta firmada | Se pueden quitar | Es trabajo en curso; al firmar el acta quedan fijos. |

**Reglas al inactivar** (las aplica la base de datos, también desde pgAdmin):
- No se inactiva una persona que es afiliada activa, tiene cargo directivo vigente, es jefe o miembro de comité activo, tiene usuario activo o acceso vigente a una red social.
- Inactivar un afiliado es **desafiliarlo**: el mes del retiro se cobra (la nómina ya se causó); desde el mes siguiente ya no se espera su aporte ni se le genera.
- No se inactiva una empresa con afiliados activos. Al inactivarla se inactivan en cadena sus sedes, jefes y comités.
- No se inactiva una junta con afiliados activos, directivos vigentes, cuenta bancaria o de redes activa, ni con saldo en su fondo. La Junta Nacional nunca se inactiva. Una junta inactiva no genera alertas.
- No se inactiva una cuenta bancaria con saldo. Una subdirectiva que cambia de banco inactiva su subcuenta y abre otra.
- Un registro inactivo no se modifica (primero se reactiva) y no se le asocian registros nuevos. Para reactivar, lo que depende de él debe estar activo (p. ej., la persona antes que su afiliación).
- Si se intenta crear algo que ya existe inactivo (mismo documento, NIT…), el sistema indica reactivarlo en lugar de duplicarlo.

**Doble candado:** un trigger rechaza cualquier `DELETE` en las tablas del sindicato, incluso de un superusuario en pgAdmin, y la cuenta de la aplicación (`sgs_app`) ya no tiene permiso de borrar. Las llaves `ON DELETE CASCADE` pasaron a `ON DELETE RESTRICT`.

**Permisos:** la columna «Eliminar» de la matriz de permisos ahora se llama «Inactivar / anular». Por defecto la tienen el administrador (en todos los módulos) y Tesorería (en finanzas). La Junta puede dársela a otros roles desde Administración → Matriz de permisos.

## 3j. Protección de datos personales (Ley 1581 de 2012)

Script `06_datos_personales.sql` y módulo `backend/app/privacidad.py`.

**Datos reservados.** El salario y el campo género (que incluye orientación sexual, dato sensible) ya no los puede leer la cuenta de la aplicación: en listados y fichas aparecen como «•••• Dato reservado». Quien tiene el cargo pulsa **Ver (queda registrado)** y escribe, si quiere, el motivo. Pueden verlos:

| Dato | Quién |
|---|---|
| Género | Administrador; Presidente o Secretario General de la junta del afiliado o de la Junta Nacional |
| Salario | Los anteriores, más el Tesorero de esa junta o de la Nacional y los usuarios con rol Tesorería de su ámbito |

En la bitácora de cambios esos datos también aparecen ocultos (salvo para el administrador).

**Bitácora de accesos** (Auditoría → Bitácora de accesos a datos personales). Registra cada ficha abierta, listado de afiliados o salarios, dato reservado revelado, exportación a CSV, reporte al titular y anonimización: quién, cuándo, desde qué IP y por qué. Es inmutable, solo la consultan el administrador y la Presidencia Nacional, y se conserva 5 años (parámetro `RETENCION_BITACORA_ANOS`; el administrador purga lo más antiguo). Si un usuario consulta en un día más de 50 fichas o datos (parámetro `CONSULTAS_DIA_ALERTA`), aparece la alerta «Consultas inusuales» y se avisa por correo a la Presidencia Nacional.

**Consentimiento.** Gobernanza → Política de tratamiento de datos (versiones; se publica con el acta de la Junta Nacional; una versión publicada no se modifica) y Autorizaciones de datos (por persona y finalidad: gestión sindical, comunicaciones, uso de imagen). Las autorizaciones en papel o grabadas exigen el soporte radicado. No se editan: se revocan o se registra una nueva. Un afiliado sin autorización **sí se puede registrar**, pero queda «pendiente» en la vista *Autorizaciones de datos* y en el correo mensual a la Presidencia y la Secretaría de su junta. Quien niega o revoca las comunicaciones deja de recibir los saludos de cumpleaños. **La versión 2.0 de la política (borrador completo, ver sección 3s) debe revisarla el abogado antes de publicarla.**

**Derechos del titular.** Gobernanza → Solicitudes de titulares: consultas (10 días hábiles) y reclamos de actualización, rectificación, supresión o revocación (15 días hábiles), con una prórroga posible (5 y 8 días) antes del vencimiento. Si un reclamo llega **incompleto**, se le pide al titular completarlo dentro de los 5 días hábiles siguientes al recibo (*Pedir completar*); el plazo se suspende y, si en 2 meses no completa, se declara el desistimiento. Completo el reclamo, los 15 días cuentan desde el día siguiente. Si el sindicato no es competente (los datos los trata otro responsable, como el empleador), se **traslada** en máximo 2 días hábiles informando al titular. Mientras un reclamo completo no se decide, la ficha de la persona muestra la leyenda **«Reclamo en trámite»** y su motivo (art. 15, num. 2). Lo recibido después de las 5 p. m. o en día no hábil se cuenta desde el día hábil siguiente. Los festivos de Colombia se calculan solos (Ley Emiliani) y se pueden ajustar en Gobernanza → Festivos. Alertas al 50 %, 80 % y al vencer. Desde la ficha de una persona: **Reporte de datos del titular (PDF)** con todo lo que el sindicato tiene de ella y quién lo ha consultado.

**Anonimización (supresión).** Solo para personas inactivas (sin afiliación, cargo ni usuario activos). La solicita el administrador desde la ficha de la persona y la aprueba o rechaza la **Presidencia Nacional** (otra persona). Reemplaza nombre, documento, contacto, género y fecha de nacimiento (queda solo el año), también en la bitácora de cambios y en el historial de correos. Se conservan las cifras (aportes, salarios) sin identificar a nadie. Las actas y documentos firmados conservan los nombres por su valor legal.

## 3k. Porcentaje del aporte (0,6 % / 0,7 %), novedades y exoneraciones

Script `07_porcentaje_aporte.sql`.

- **Porcentaje por junta** (Finanzas → Porcentaje del aporte por junta). Cada junta registra desde qué mes aplica el 0,6 % o el 0,7 %. Solo sube. El primer registro de una junta es la carga de su situación actual y puede ir sin acta; los cambios posteriores exigen el acta de la junta. **Una junta sin registro aplica el parámetro general (0,7 %)**: al poner el sistema en marcha, registre al 0,6 % las juntas que aún no han hecho la transición.
- **Porcentaje por afiliado** (solo si es distinto al de su junta). Puede ser mayor que el de su junta, nunca menor: en una junta al 0,7 % no se registra a nadie al 0,6 %. Solo sube.
- **Transición:** cuando la junta pasa al 0,7 %, sus afiliados que estaban en 0,6 % pasan con ella desde el mismo mes.
- **Corrección de digitación:** solo el administrador (botón *Corregir*), con motivo, y solo si aún no se generaron aportes con ese porcentaje.
- Nada de esto puede regir desde un mes ya cerrado.
- **Cálculo:** cada mes con el porcentaje vigente de cada afiliado, sobre el salario vigente al cierre del mes, **redondeado al peso**. El aporte guarda el porcentaje con que se calculó.
- **Novedades:** ingreso (a la empresa o al sindicato, la fecha posterior) entre el día 1 y el 7 → se cobra ese mes; del 8 en adelante → desde el mes siguiente. Retiro → se cobra el mes del retiro. Licencias, suspensiones, incapacidades y vacaciones → se cobran normalmente.
- **Exoneraciones** (Finanzas → Exoneraciones del aporte): se registra la solicitud; la aprueba o la niega el Presidente o el Secretario General de la junta del afiliado con el acta de la reunión. En los meses exonerados no se espera ni se genera su aporte; si la empresa consignó esos meses, la vista lo advierte para devolver o abonar.
- **Vistas:** *Transición al 0,7 %* (porcentaje de cada junta, afiliados por debajo y dinero mensual de diferencia) y *Exoneraciones del aporte*.

## 3l. Ventanilla y portal del afiliado

Script `08_ventanilla_autoservicio.sql` y módulo `backend/app/autoservicio.py`.

**Rol Ventanilla (VENTANILLA).** Se crea el usuario con ese rol y se le asigna su subdirectiva en *Ámbitos de usuario*. Puede registrar personas, radicar documentos, recibir **solicitudes de afiliación** y registrar autorizaciones de datos y solicitudes de titulares. No afilia, no ve salarios ni datos sensibles, no entra a finanzas y no inactiva registros (lo impiden la aplicación y la base de datos).

**Solicitudes de afiliación** (Gobernanza → Solicitudes de afiliación). Quedan pendientes hasta que el Presidente o el Secretario General de la junta las aprueban (se crean el afiliado, su empresa y su salario; si ya había sido afiliado, se reactiva el mismo registro) o las rechazan con motivo. Vista de pendientes en el tablero.

**Portal del afiliado (rol AFILIADO).** Desde la ficha del afiliado, la junta pulsa *Invitar al portal*: le llega un enlace personal de un solo uso (48 horas) a su correo. Si el servidor no tiene correo configurado, el enlace se muestra para entregarlo en persona. Al activar la cuenta, el afiliado acepta la política de datos en línea (queda como autorización con medio «portal»). En el portal, pensado primero para celular:

| Pestaña | Contenido |
|---|---|
| Mi perfil | Sus datos, junta, empresa, salario y porcentaje de aporte; cambia su teléfono; el correo nuevo se confirma con un enlace |
| Mis aportes | Últimos 24 meses con su porcentaje y si la empresa reportó el aporte («la empresa no ha reportado el aporte», sin culparlo) |
| Certificados | Afiliación y paz y salvo en PDF con código de verificación y huella SHA-256. Si la empresa no reportó algún mes, el paz y salvo lleva una nota: la deuda es de la empresa |
| Mis solicitudes | Datos personales, afiliación y exoneraciones, con su estado |
| Privacidad | Sus autorizaciones (cambia las opcionales) y quién ha consultado sus datos |

Todo sale de funciones de la base de datos que solo devuelven los datos de la persona ligada al usuario: no hay forma de pedir los de otro. Directivos y personal ligados a un afiliado ven lo mismo en **Mi espacio**. Si el afiliado se desafilia, su cuenta del portal se desactiva y sus certificados de afiliación dejan de ser válidos.

**Verificación pública** (`#/verificar`, sin iniciar sesión): con el código se ve si el certificado es válido, su tipo, fecha, iniciales del titular y los tres últimos dígitos del documento. Tiene límite de consultas por equipo.

**Importante:** el portal para afiliados solo tiene sentido con el sistema publicado en un servidor web con **HTTPS** y un dominio (defina `APP_URL` en `.env` para que los enlaces de los correos apunten allí), y conviene activar antes el bloque 4 (MFA) para directivos y administradores.

## 3m. Verificación en dos pasos (MFA)

Script `09_mfa.sql` y módulo `backend/app/mfa.py`. Pantallas: verificación al ingresar, **Mi seguridad** (botón en la parte inferior del menú) y pestaña *Seguridad* del portal del afiliado.

**Quién la usa.** Todos los roles la exigen, salvo AFILIADO, para quien es opcional. Los usuarios que ya existían tienen **7 días de gracia**: ven un aviso con los días que quedan; vencido el plazo, al ingresar deben configurarla antes de seguir. Lo mismo para cada usuario nuevo.

**Cómo se activa.** En *Mi seguridad* → *Activar*: se escanea el código QR con una aplicación autenticadora (Google Authenticator, Microsoft Authenticator u otra; no requiere internet en el celular), se escribe el código que aparece y el sistema entrega **10 códigos de recuperación** de un solo uso para imprimir o guardar.

**Códigos.** Las aplicaciones cambian el código cada 30 segundos (es el estándar y no se puede modificar en ellas), pero **el sistema acepta un código de hasta 3 minutos de antigüedad**, como se pidió. Cada código sirve una sola vez. Métodos alternativos: **código al correo** (6 dígitos, vence en 10 minutos) y códigos de recuperación (al usar uno, llega un aviso al correo). No hay SMS.

**Recordar equipo.** Al verificar se puede marcar *Recordar este equipo* durante **30 días** (no disponible para el administrador). Se olvidan todos desde *Mi seguridad* y automáticamente al cambiar la contraseña.

**Acciones críticas (doble verificación).** Cambiar permisos, roles, ámbitos, el rol o el estado de un usuario, ver o rotar claves de redes sociales, corregir porcentajes, gestionar anonimizaciones y regenerar los códigos de recuperación piden el código otra vez si la última verificación tiene más de 5 minutos. Aparece una ventana *Confirme que es usted* y la acción continúa sola al confirmar.

**Bloqueo.** Cinco códigos errados bloquean la cuenta 15 minutos y cierran la sesión. Una sesión que no completa la verificación vence a los 5 minutos.

**Pérdida del celular y de los códigos.** El administrador solicita el **reinicio del MFA** en *Mi seguridad* (con motivo) y lo aprueba la **Presidencia Nacional** (otra persona). El administrador no puede pedir ni aprobar el suyo. Al aprobarse, el usuario configura el MFA de nuevo al siguiente ingreso. La vista *MFA pendiente* (Administración) muestra quién no lo ha activado y cuántos días le quedan.

**Seguridad de las claves.** La clave de cada autenticador se guarda cifrada (AES-256-GCM con `SECRETOS_LLAVE`, la misma de las redes sociales) y la aplicación no puede leer las tablas del MFA: todo pasa por funciones de la base. Al rotar la llave también se recifran estas claves. Los códigos de recuperación y de correo se guardan solo como huella. Todos los eventos (activación, verificación, fallos, reinicios) quedan en el registro de accesos.

**Importante:** la hora del servidor y la de los celulares deben estar bien (sincronizadas por internet); si el reloj del servidor se atrasa más de 3 minutos, los códigos no coincidirán.

## 3n. PQRSD recibidas (Ley 1755 de 2015)

Script `10_pqrsd.sql`, módulo `backend/app/pqrsd.py` y pantalla **Gestión documental → PQRSD recibidas**. Son las peticiones, quejas, reclamos, sugerencias, denuncias, consultas, solicitudes de documentos y felicitaciones que **llegan al sindicato** (las que el sindicato envía a empresas siguen en *Documentos y radicación*). La Ley 1755 también aplica a organizaciones privadas (arts. 32 y 33).

**Plazos (días hábiles, sin sábados, domingos ni festivos de Colombia)** — se cambian en *Tipos y plazos de PQRSD* (ámbito nacional, por recomendación del abogado) y rigen para las nuevas:

| Tipo | Plazo | Nota |
|---|---|---|
| Petición, queja, reclamo, sugerencia | 15 | Término general (art. 14) |
| Denuncia | 15 | Exige **concepto jurídico** antes de responder |
| Solicitud de documentos o información | 10 | Si vence sin respuesta se entiende aceptada: se entregan dentro de los 3 días siguientes |
| Consulta | 30 | |
| Felicitación | 15 | No es una petición; se responde por cortesía |

**Recepción.** Solo por el correo institucional (el papel se escanea y se envía al buzón). Se registra con la fecha y hora en que llegó el correo: lo recibido **desde las 5 p. m.** o en día no hábil cuenta desde el día hábil siguiente, y los días empiezan a contar al día siguiente. Si se registra más de 2 días hábiles después de recibido, hay que explicar la demora (el plazo corre desde que llegó). Al registrar, el peticionario recibe un acuse con el radicado (`PQRSD-AAAA-NNNNNN`) y la fecha límite. Los cierres internos del sindicato **no** suspenden los plazos.

**Anónimas.** No se tramitan: se registran (queda la constancia) y se archivan. Si el peticionario se identifica, el nombre, el documento y el correo son obligatorios.

**Quién hace qué.** Registran la Ventanilla de la junta y el Presidente, Vicepresidente, Secretario General o Fiscal (de la junta o nacionales). Esos cuatro cargos prorrogan, piden completar, declaran el desistimiento, trasladan y **firman la respuesta**. El concepto jurídico lo da el usuario con rol Abogado del ámbito de la junta o el Secretario Jurídico.

**Prórroga.** Antes del vencimiento, con motivo, que se le informa al peticionario por correo. El plazo total no puede pasar del doble del inicial (art. 14, parágrafo); una sola vez.

**Petición que no se entiende (art. 19).** Si no se comprende qué pide, se le devuelve al peticionario para que la aclare dentro de los **10 días hábiles** siguientes (*Pedir aclaración*; ese plazo no se amplía). Al aclarar, el plazo para responder **empieza de nuevo**. Si no aclara, se archiva.

**Solicitud incompleta y desistimiento tácito (art. 17).** Dentro de los 10 días hábiles siguientes a la radicación se le pide al peticionario lo que falta; el plazo para responder queda suspendido. Tiene un mes para completar, ampliable un mes más si lo pide. Al completar, el plazo se reanuda con los días que le quedaban. Si no completa, se declara el desistimiento (decisión motivada, con aviso) y se archiva; puede presentarla de nuevo. Contra el desistimiento procede el **recurso de reposición**, dentro de los **10 días hábiles** siguientes a su notificación (art. 17 y art. 76 del CPACA): el correo de archivo le dice hasta cuándo. Lo registran la Ventanilla o los cuatro cargos; lo deciden los cuatro cargos: si se **revoca**, el trámite sigue con los días que quedaban; si se **confirma**, sigue archivada. Mientras no se decide hay alerta.

**Traslado por competencia (art. 21).** Dentro de los 5 días hábiles siguientes al recibo (si se hace después queda marcado como tardío), con aviso al peticionario. A otra junta del sindicato: el plazo vuelve a empezar desde que la recibe y la junta de origen deja de verla. A una entidad externa (con copia a su correo): el trámite termina aquí.

**Respuesta.** Sale firmada con el cargo de quien responde, en PDF (con huella SHA-256) adjunto al correo del peticionario, y se puede volver a descargar. Una PQRSD cerrada no se modifica.

**Alertas.** En la bandeja, en la ficha, en el tablero (vista *PQRSD recibidas: plazos*) y por correo a los cuatro cargos de la junta: al consumir la mitad del plazo, el 80 % y al vencer (un correo por PQRSD y nivel). También avisa cuando una denuncia pasó la mitad del plazo sin concepto jurídico y cuando venció el plazo para completar.

**Historia.** Cada PQRSD tiene una historia inmutable (radicación, correos enviados o no enviados, prórroga, requerimiento, traslado, concepto, respuesta y notas internas). Los datos del peticionario son personales: consultar la bandeja y las fichas queda en la bitácora de accesos (Ley 1581).

**Los plazos son los de la ley** y la base no deja alargarlos (ver sección 3q). **Criterio de cautela** (reglamento de PQRSD, art. 5): cuando una norma admite dos formas de contar un plazo, se usa la que da la fecha de respuesta más temprana. Así, al completar (art. 17) y al aclarar (art. 19) el plazo se **reanuda con los días que quedaban**; el recurso de reposición se presenta dentro de 10 días hábiles (art. 76 del CPACA) y la junta lo decide dentro de 15 días hábiles (regla interna, con alerta crítica si se pasa); la hora de corte de las 5 p. m. queda en el reglamento y en el acuse de recibo.

## 3o. Endurecimiento de la base de datos

Script `11_endurecimiento.sql`. Objetivo: que **la contraseña de la cuenta de la aplicación (`sgs_app`) no baste para saltarse las reglas**, aunque alguien la obtenga (copia del `.env`, acceso al servidor, un equipo en modo local).

| Antes | Ahora |
|---|---|
| Las funciones que hacen cambios especiales (anular, aprobar, prorrogar…) avisaban con una variable que cualquier conexión podía imitar | Además dejan una marca en una tabla a la que la aplicación no tiene acceso; los controles exigen las dos (59 funciones ajustadas automáticamente) |
| La base creía el número de usuario que le decía la conexión (`app.id_usuario`): se podía fingir ser el administrador | La base identifica al usuario por el **token de una sesión vigente**; en la tabla de sesiones solo se guarda su huella. Sin sesión válida no se ve ni se escribe nada |
| La aplicación podía leer el hash de las contraseñas y crear sesiones directamente | Ya no: el ingreso lo hace una función de la base que recibe el hash calculado con la sal y compara, cuenta intentos y crea la sesión |
| Usuarios, roles, matriz de permisos, ámbitos y parámetros se podían cambiar directamente | Solo un administrador con sesión vigente (o las funciones del sistema). Cambiar la propia contraseña y contar los códigos errados van por funciones |

**Vigilancia.** Vista *Administración → Alertas de seguridad de la base* y correo (tipo *SEGURIDAD_BD*) al administrador y a la Presidencia Nacional cuando: alguien se conecta con la contraseña de la aplicación o del notificador desde otro programa (se revisa en cada ingreso a la aplicación y en cada ejecución de los correos), o la base bloquea una operación protegida que llegó por la aplicación. Los intentos hechos directamente contra la base se rechazan, pero la base no puede guardarlos (la transacción se deshace): para eso active en PostgreSQL `log_connections = on` y `log_min_error_statement = error`.

**Al instalarlo**, se cierran todas las sesiones abiertas (cambia la forma de guardarlas): los usuarios vuelven a ingresar.

**Restablecer un administrador** (contraseña perdida): `python -m app.cli crear-admin` ya no puede hacerlo con la cuenta de la aplicación cuando hay un administrador activo. Defina `ADMIN_DATABASE_URL` (conexión del dueño de la base o de un superusuario, solo para ese momento) y ejecútelo.

**Modo local de la aplicación de escritorio.** Guarda en el equipo la contraseña de la base: solo para pruebas o un único equipo de confianza. La aplicación lo advierte con una franja roja en todas las pantallas. Para varios usuarios use siempre el modo central.

**Configuración del servidor (obligatoria en producción):**
1. `pg_hba.conf`: que `sgs_app` y `sgs_notificador` solo se conecten desde el servidor de la aplicación, con `scram-sha-256` y SSL (`hostssl sgsindical sgs_app 10.0.0.5/32 scram-sha-256`, con la IP del servidor).
2. El archivo `.env` solo legible por el usuario del servicio (`chmod 600` en Linux; en Windows, permisos solo para la cuenta del servicio).
3. Después de instalar este script, cambie las contraseñas de `sgs_app`, `sgs_lectura`, `sgs_backup` y `sgs_notificador` (`ALTER ROLE … PASSWORD '…'`) y actualice el `.env`.
4. Si alguna vez se filtró el `.env`, cambie también `JWT_SECRET` y `SECRETOS_LLAVE` (con la rotación de llaves de *Redes sociales*).

**Límites que conviene conocer:** quien tenga la contraseña de la base y además la contraseña de un usuario puede actuar como ese usuario (como desde la aplicación); el código del segundo factor lo verifica el servidor de aplicación, no la base. Por eso el `.env` completo es lo que más hay que proteger. Las cuentas de solo lectura (`sgs_lectura`, `sgs_notificador`) siguen pudiendo leer los datos que su función necesita.

## 3p. Varios roles por persona, contexto activo, incompatibilidades y suplencias

Script `12_roles_suplencias.sql`, módulo `backend/app/roles.py` y pantallas *Roles* (ficha del usuario), *Roles por aprobar* (Presidencia Nacional) y *Gobernanza → Suplencias de cargos*.

**Contextos.** Una persona tiene **una sola cuenta** con uno o varios roles; cada rol con su ámbito (nacional o juntas) y su vigencia es un *contexto*. Se trabaja en **uno a la vez**: quien tiene varios elige al ingresar (tarjetas «¿Con qué rol va a trabajar?») y puede cambiar con *Cambiar de rol*, en la parte inferior del menú, que muestra siempre el rol y el ámbito activos. **Los permisos nunca se suman**: una Tesorera de Medellín que entra como abogada del Comité Cali no ve finanzas ni Medellín, y su cargo de Tesorera no cuenta en ese contexto. Al cambiar de rol se cierran sus sesiones abiertas en otros equipos. Quien también es afiliado conserva *Mi espacio*. El segundo factor se exige si **cualquiera** de los roles de la persona lo exige. Los usuarios que ya existían conservan su rol como primer contexto.

**Incompatibilidades** (la base las impide al asignar un rol, nombrar un cargo, ligar el usuario a una persona o registrar una suplencia, también con fechas futuras):
1. Tesorería y Auditoría/Fiscalía en la misma junta.
2. Administrador con cualquier otro rol (sí puede tener *Mi espacio* de afiliado).
3. Ventanilla y Presidente o Secretario General (quienes aprueban afiliaciones) en la misma junta.

La vista *Incompatibilidades* (Administración) muestra las que ya existían antes del script para resolverlas.

**Asignar roles.** En la ficha del usuario → *Roles*, con motivo, ámbito y vigencia opcional. Nadie se asigna roles a sí mismo. El rol de **Administrador** y los roles con **ámbito nacional** quedan *pendientes* hasta que los aprueba la **Presidencia Nacional** (en *Roles por aprobar*; rechazar exige motivo). Como nadie aprueba sus propios roles, las solicitudes de quien ejerce la Presidencia Nacional las aprueba la **Vicepresidencia o la Secretaría General Nacional**. Por eso ya no se dan desde la ficha del usuario, y tampoco se puede reescribir desde la ficha un rol aprobado o de suplencia. Ligar una cuenta con quien ejerce un cargo nacional genera una alerta de seguridad.

**Suplencias.** Encargo temporal de un cargo directivo (licencia, incapacidad, comisión):
- La decide la junta **con un acta de esa misma junta**; la registran el Presidente o el Secretario General (o los nacionales), nunca el ausente ni el suplente.
- Dura **máximo 90 días**; se **renueva** con un acta nueva (encadenada a la anterior).
- Mientras dura, **el titular queda suspendido** en ese cargo y solo actúa el suplente (firma PQRSD, aprueba afiliaciones, etc.); si hace falta, recibe un contexto temporal con el rol del cargo (Tesorero → Tesorería, Fiscal → Auditoría, los demás → Directivo).
- Termina sola al vencer (el titular recupera el cargo sin hacer nada) y se puede revocar antes con motivo.
- Correos: 7 días antes del vencimiento (al suplente y a la mesa de la junta) y cuando la misma ausencia lleva **más de 60 días** encadenados, para que la junta declare la vacancia según los estatutos (es una alerta, no un bloqueo).

**Límite que conviene conocer:** el administrador puede crear una cuenta ligada a una persona que ejerce un cargo nacional (por ejemplo, la Presidencia Nacional), y esa cuenta tendría su autoridad. Queda registrado y genera alerta; verifique que la cuenta sea de esa persona.

## 3q. Plazos de ley

Script `13_plazos_ley.sql`. El sistema usa los plazos que fijan la **Ley 1755 de 2015** (derecho de petición, que el art. 32 extiende a las organizaciones privadas) y la **Ley 1581 de 2012** (datos personales). Están en la tabla `gobernanza.plazo_legal` (inmutable) y en la vista **Plazos de ley**, que compara cada uno con el valor configurado.

- Los plazos **del sindicato** (responder, trasladar, pedir completar, entregar documentos) se pueden **acortar**, nunca alargar más allá de la ley.
- Los plazos **del peticionario o titular** (un mes para completar y uno más si lo pide, 10 días para aclarar, 10 días para el recurso, 2 meses en reclamos de datos) son exactamente los de la ley y no se cambian.

| Plazo | Ley | Norma |
|---|---|---|
| Petición, queja, reclamo, sugerencia, denuncia | 15 días hábiles | Ley 1755, art. 14 |
| Solicitud de documentos o información (si vence: se entiende aceptada y se entregan en 3 días) | 10 días hábiles | Ley 1755, art. 14, num. 1 |
| Consulta | 30 días hábiles | Ley 1755, art. 14, num. 2 |
| Prórroga | hasta el doble del plazo inicial, avisando antes de vencer | Ley 1755, art. 14, parágrafo |
| Pedir completar una solicitud | 10 días hábiles desde la radicación | Ley 1755, art. 17 |
| Para completar | 1 mes, + 1 mes si el peticionario lo pide | Ley 1755, art. 17 |
| Recurso de reposición contra el desistimiento | 10 días hábiles | Ley 1755, art. 17; Ley 1437, art. 76 |
| Aclarar una petición que no se entiende | 10 días hábiles | Ley 1755, art. 19 |
| Traslado por falta de competencia | 5 días hábiles | Ley 1755, art. 21 |
| Consulta del titular | 10 días hábiles, + 5 de prórroga | Ley 1581, art. 14 |
| Reclamo del titular | 15 días hábiles, + 8 de prórroga | Ley 1581, art. 15 |
| Requerir al titular un reclamo incompleto | 5 días | Ley 1581, art. 15, num. 1 |
| Desistimiento del reclamo incompleto | 2 meses desde el requerimiento | Ley 1581, art. 15, num. 1 |
| Traslado del reclamo a quien sea competente | 2 días hábiles | Ley 1581, art. 15, num. 1 |
| Leyenda «reclamo en trámite» | máximo 2 días hábiles (el sistema la pone al instante) | Ley 1581, art. 15, num. 2 |

Lo que la ley no fija sigue siendo una decisión del sindicato y se puede configurar: el corte de las 5 p. m., las alertas al 50 % y 80 %, el registro tardío, la retención de la bitácora y todos los plazos estatutarios (periodos, suplencias, convocatorias, informes). El Código Sustantivo del Trabajo (art. 400) no fija un plazo en días para que el empleador entregue las cuotas: el día 15 es una regla del sindicato o de la convención.

## 3s. Documentos legales

Script `15_documentos_legales.sql`. Carga tres borradores completos para que los revise el abogado:

| Documento | Dónde se edita | Norma |
|---|---|---|
| **Política de tratamiento de datos personales 2.0** (responsable, datos, datos sensibles, finalidades, derechos, procedimiento y plazos, seguridad, encargados y transmisiones, conservación, vigencia) | Gobernanza → Política de tratamiento de datos (versión `2.0-borrador`) | Ley 1581 de 2012; Decreto 1074 de 2015, cap. 25 |
| **Aviso de privacidad** | Gobernanza → Aviso de privacidad y reglamento de PQRSD | Decreto 1074 de 2015, cap. 25 |
| **Reglamento interno de PQRSD** (canal, hora de corte, plazos, criterio de cautela, prórroga, solicitud incompleta, desistimiento y recurso, aclaración, traslado, atención prioritaria, denuncias, anónimas, firmas) | La misma pantalla | Ley 1755 de 2015, art. 22 |

- Los datos que solo conoce el sindicato (NIT, registro sindical, dirección, correos, proveedores, actas) están marcados **[COMPLETAR: …]** y los puntos que debe confirmar el abogado, **[VERIFICAR: …]**. **La base no deja publicar un texto con marcas pendientes.**
- Se publican con el acta de la Junta Nacional (administrador o Presidencia Nacional). Una versión publicada no se modifica.
- Las versiones vigentes se consultan **sin iniciar sesión** en `#/legal/politica-datos`, `#/legal/aviso-privacidad` y `#/legal/reglamento-pqrsd`, enlazadas desde la pantalla de ingreso.
- **Al publicar la política 2.0, las autorizaciones dadas con la versión anterior quedan desactualizadas**: hay que recogerlas de nuevo (la vista *Autorizaciones de datos* muestra a quién le falta).
- En el portal, las casillas de comunicaciones y de uso de imagen ya no vienen marcadas: la autorización debe ser expresa.

## 3t. Expediente de afiliación y afiliados dispersos

Script `16_expediente_afiliacion.sql`.

**Documentos.** El catálogo (*Gobernanza → Documentos de afiliación*) trae el documento de identidad y el formato de afiliación firmado (**obligatorios**) y el acta de posesión y el certificado de carrera (**opcionales**). El administrador o la Presidencia Nacional pueden agregar tipos y subir una plantilla (por ejemplo el formato en blanco), que la persona descarga desde su portal. Se aceptan PDF, JPG y PNG; varias fotos se unen en un solo PDF. Cada archivo guarda su huella SHA-256. Nada se borra: un archivo nuevo reemplaza al anterior, que queda en el historial.

**Quién hace qué**

| Quién | Carga | Ve los archivos | Acepta o rechaza | Decide la afiliación |
|---|---|---|---|---|
| La persona (portal) | Lo suyo | Lo suyo | — | — |
| Ventanilla | A nombre de la persona | Solo lo que ella cargó | — | — |
| Presidente y Secretario General de la junta | Sí | Sí | Sí | Sí |
| Vicepresidente, Tesorero y Fiscal de la subdirectiva | — | Sí | — | — |
| Otros directivos | — | Solo el estado | — | — |
| Directivos nacionales (dispersos) | Sí | Sí | Sí | Presidente o Secretario General Nacional, con el acta |
| Administrador | — | Solo escribiendo el motivo | — | — |

Cada apertura de un archivo queda en la bitácora de accesos (Ley 1581). Nadie revisa ni decide lo suyo.

**El trámite.** Ventanilla registra la persona y la solicitud, y la invita al portal desde la misma solicitud (aún no es afiliada). Con su cuenta, la persona ve solo *Mi afiliación*: la lista de documentos, el estado de cada uno y el motivo si se lo rechazaron; puede salir y volver cuando quiera. La afiliación **solo se aprueba con los obligatorios aceptados** (la base lo exige). Al aprobarse, la misma cuenta pasa a ser la del portal completo, con la pestaña *Mis documentos* para los opcionales.

**Plazos** (*Gobernanza → Plazos de la solicitud de afiliación*): 60 días para completar los documentos; recordatorios a los 3 y 10 días, y aviso 10 días antes del vencimiento. Vencido el plazo con documentos incompletos, el proceso de correos archiva la solicitud, desactiva la cuenta del portal y le avisa; la persona puede volver a solicitar y conserva lo que ya le aceptaron. Si los documentos están completos o por revisar y la junta no ha actuado, la solicitud no se archiva: aparece en alerta crítica. **Si la junta rechaza un documento obligatorio, la persona tiene al menos 10 días desde el rechazo para reemplazarlo** (parámetro `DIAS_TRAS_RECHAZO`), aunque el plazo general ya haya vencido, y recibe un correo con el motivo y la nueva fecha límite. El directivo que recibe un documento también puede aceptarlo. La junta recibe cada día el resumen de documentos por revisar y solicitudes listas para decidir.

**Afiliados dispersos.** Pertenecen a la Junta Directiva Nacional. Pasar a disperso, aunque haya subdirectiva, o dejar de serlo lo decide la Junta Nacional en reunión; lo registran su Presidente o su Secretario General con el acta (acción *Disperso / pertenencia* de la ficha del afiliado). No hay traslado automático. Cada cambio queda en el *Historial de pertenencia*. El aporte de un disperso es 100 % de la Nacional. Un disperso no puede tener cargo local.

**Pertenencia obligatoria.** Ningún afiliado nuevo puede quedar sin subdirectiva, comité o Junta Nacional. Si la base ya tenía afiliados sin pertenencia, aparecen en la vista *Afiliados sin pertenencia*; al corregirlos y volver a ejecutar el script, la regla queda fija en la columna.

**Fecha de afiliación.** Es la de la aprobación y la pone el sistema. Solo se admite una fecha anterior si no es antes de la radicación de la solicitud, nunca futura, y con un motivo que queda en la solicitud y en la auditoría. La fecha que la persona escribe en el formato se guarda aparte (*Fecha escrita en el formato*), solo como dato. El cobro del aporte empieza el mes de la afiliación si es en los primeros 7 días, o el mes siguiente.

**Campos del formato.** Persona: lugar de expedición del documento, dirección de correspondencia, otro teléfono y otro correo. Solicitud y afiliado: profesión u oficio y empleo (denominación, código y grado). Al aprobarse, pasan de la solicitud al afiliado.

**Datos institucionales** (*Administración → Datos institucionales*). El nombre oficial, la sigla y el NIT del sindicato se guardan en la base y los usan los correos, certificados, PDF y la pantalla de ingreso. `SINDICATO_NOMBRE` del `.env` queda solo como respaldo. Los borradores legales ya no traen el nombre ni el NIT escritos: usan `{{NOMBRE_SINDICATO}}`, `{{SIGLA}}` y `{{NIT}}`, que se llenan al publicar.

**Vistas:** *Expedientes incompletos* (informativa, para los afiliados actuales), *Historial de pertenencia y dispersos* y *Afiliados sin pertenencia*.

**Formato de afiliación.** La carpeta `plantillas/` trae el formato con el nombre oficial (`Formato_afiliacion_SINTRACAD_V2_2026.pdf`). Súbalo una vez en *Gobernanza → Documentos de afiliación (catálogo) → Formato de afiliación firmado → Subir plantilla*; desde ese momento cada persona lo descarga en su portal con el botón «Descargar formato».

**Servidor:** necesita `Pillow` (está en `requirements.txt`) para convertir las fotos a PDF. Los archivos quedan en `UPLOAD_DIR/afiliacion/`.

## 3u. Lugares oficiales, traslados entre juntas y Palmira

Script `17_lugares_traslados.sql`.

**Listas oficiales.** Países según la norma ISO 3166-1 (249, con su nombre en español y Colombia de primera), departamentos con su código DIVIPOLA del DANE (los 32 y Bogotá, D.C.) y municipios DIVIPOLA. Persona, empresa, sede y junta guardan el **código**; el nombre se llena solo desde la lista. Al diligenciar: el país se elige de la lista; el departamento solo se ofrece para Colombia; el municipio muestra solo los del departamento elegido y se borra si el departamento cambia. La base no deja guardar un municipio de otro departamento, ni departamento o municipio fuera de Colombia.

**Lista de municipios.** El script `17b_divipola_municipios.sql` instala la lista oficial del DANE (datos.gov.co, conjunto «DIVIPOLA - Códigos municipios», descargada el 7 de octubre de 2026): 1.122 registros, que son 1.103 municipios, 18 áreas no municipalizadas y una isla; el archivo original está en `db/datos/`. Cuando el DANE la actualice, descargue el CSV y súbalo como administrador en *Gobernanza → Municipios (DIVIPOLA) → Cargar archivo DIVIPOLA*. La carga reconoce las columnas «Código Municipio» y «Nombre Municipio», agrega los nuevos, deja como no vigentes los que ya no aparezcan (nada se borra) y pasa a código los lugares que ya estaban escritos. Lo que no se pueda reconocer (un nombre mal escrito o ambiguo, como «Rionegro» sin departamento) aparece en la vista *Lugares por corregir*.

**Regla de pertenencia.** Compara códigos de municipio, no nombres. Quien trabaja en una sede puede pertenecer a la subdirectiva o comité del municipio de esa sede o al de la sede principal de su empresa. La subdirectiva la asignan los directivos; el sistema solo verifica.

**Traslados entre subdirectivas o comités.** Los deciden las dos juntas, cada una con su acta:
1. El Presidente o el Secretario General de una de las dos juntas lo propone desde la ficha del afiliado (*Trasladar a otra subdirectiva o comité*), con el acta de su junta y el motivo.
2. El Presidente o el Secretario General de la otra junta lo acepta o lo rechaza en *Gobernanza → Traslados entre juntas*, con el acta de su junta.
3. Al aceptarse, el afiliado pasa a la nueva junta, su expediente la sigue y queda en el historial de pertenencia con las dos actas. Mientras nadie responde, quien lo propuso puede anularlo.

Si el destino no corresponde al municipio de trabajo ni al de la sede principal, el traslado es una **excepción**: se admite igual con las dos actas y queda marcado en la vista de pertenencia («Excepción aprobada por las dos juntas», con los radicados de las actas). Fuera de esta acción y de la de la Junta Nacional, la subdirectiva de un afiliado ya registrado no se cambia editando su ficha.

**Palmira (sede nacional).** En el municipio de la sede nacional (dato institucional `MUNICIPIO_SEDE_NACIONAL`, 76520) no se puede crear subdirectiva ni comité. Quienes trabajan allí pertenecen a la Junta Directiva Nacional, igual que los dispersos: los gestiona cualquier directivo nacional, su ingreso o salida lo decide la Junta Nacional con acta y su aporte es 100 % de la Nacional. ARCADIO distingue solo dos grupos según el municipio donde trabaja cada uno: **Palmira (sede nacional)** y **Dispersos**. Vistas: *Afiliados de la Junta Nacional (Palmira y dispersos)*, para los censos separados, y *Junta Nacional por municipio*, para ver dónde se concentran.

## 3v. Posesión con el registro del inspector y permisos sindicales

Script `18_posesion_permisos.sql`, módulo `backend/app/permisos.py` y pantallas *Gobernanza → Designaciones de directivos* y *Gobernanza → Permisos sindicales*.

**Fecha de posesión = fecha del registro del inspector.** Así se evita que un directivo ejerza el cargo, o que se registre una fecha de posesión a conveniencia, antes de que el inspector de trabajo lo registre.
- La junta **designa** (elección, reelección o rotación) con su acta, en *Designaciones de directivos → + Designar directivo*. Si el cargo está ocupado, se indica a quién reemplaza. La designación queda **pendiente**.
- Cuando se registra el registro del inspector en *Registros ante MinTrabajo*, ARCADIO da la posesión a las designaciones pendientes de esa junta **con la fecha del registro** y ese mismo día retira a quien sale (y, en una rotación, el cargo anterior de la persona). Esa fecha no se modifica a mano. Si el registro vigente ya se emitió el día del acta o después, la posesión es inmediata.
- **Solo ejerce el cargo quien está inscrito y ya se posesionó** (vista *Cargos en ejercicio*, que usan los permisos, el ámbito territorial y las firmas). Un nombramiento cargado a mano en *Directivos por estamento* con posesión posterior al registro vigente queda **sin registro** y no ejerce hasta el registro siguiente. Esa pantalla sigue sirviendo para cargar juntas que el inspector ya registró o corregir.
- La fecha de emisión de un registro no puede ser futura.
- Vistas *Designaciones de directivos* (las pendientes, con alerta a los 30 y 60 días) e *Inscripción de directivos ante el inspector* (quién no ejerce por falta de registro y las posesiones registradas a mano con una fecha distinta de la del registro). Correo semanal a la mesa de la junta con las designaciones que llevan más de 30 días sin registro.
- Los nombramientos que existían antes del script quedan inscritos con su posesión.

**Permisos sindicales** (artículos 2.2.2.5.3 y 2.2.2.5.4 del Decreto 1072 de 2015, modificados por el Decreto 720 de 2024):
- Los solicitan por escrito **solo el Presidente o el Secretario General que ejercen hoy el cargo** (nacional, de subdirectiva o de comité, o quien los suple). Nadie más.
- Pueden pedirlos para un afiliado: la **Junta Directiva Nacional** (para cualquiera), la **junta a la que pertenece** y la **junta del municipio de la sede central de su empresa** (por ejemplo, el Comité Cali para un funcionario de la Gobernación del Valle que trabaja en Andalucía). Cada solicitud es para afiliados de una sola empresa y se dirige a su sede central (por defecto, a su representante legal).
- **Antelación en días hábiles:** 8 si hay delegados que no son directivos (asambleas, negociación colectiva, capacitación), 4 si todos son directivos y 1 en casos excepcionales, con el motivo. Los días se pueden cambiar en *Plazos de los permisos sindicales* (administrador).
- **Sin cruces:** un afiliado no puede tener dos permisos activos en fechas que se crucen, aunque los pidan juntas distintas; el mensaje dice qué junta ya lo pidió.
- La **carta** en PDF (consecutivo PS-AAAA-NNNN) cita la norma, lista a cada servidor con su calidad y los días hábiles, y la firma quien ejerce el cargo.
- **Respuesta de la entidad:** se registra el acto administrativo, la fecha de notificación y, para cada afiliado, si se concedió, se limitó (días) o se negó, con la causal invocada y el motivo. Se alerta si la causal no es la afectación de la debida prestación del servicio (la única legal).
- **Silencio:** si la entidad no notifica la respuesta al menos 3 días hábiles antes del inicio, el permiso se entiende **concedido**; una respuesta notificada después del plazo queda como extemporánea y no cambia el silencio. Correo a la mesa de la junta 2 días hábiles antes de vencer el plazo y cuando opera el silencio.
- **Días por afiliado y año:** solicitados, concedidos (incluido el silencio), negados y en espera (vista *Días de permiso por afiliado*). Un permiso se anula, con motivo, antes de que empiece.
- Lo ven la junta que lo pidió, la junta del afiliado y el ámbito nacional.
- **Nota:** el texto de la norma no dice si los días son hábiles o calendario; ARCADIO cuenta días hábiles. Conviene que el abogado lo confirme.

## 3r. Imagen ARCADIO

La interfaz (escritorio, web y portal del afiliado) usa la identidad de **ARCADIO**: el logosímbolo en el ingreso, el menú y el portal; la paleta del logo (verde salvia, arena y azul petróleo) con un azul marino suave en el menú lateral; y la tipografía **Poppins** en títulos, cifras y botones. Los logos están en `frontend/public/assets/marca` y las fuentes en `frontend/public/assets/fonts` (se sirven desde `/assets/`). Los colores se cambian en un solo lugar: las variables `:root` al inicio de `frontend/src/estilos.css`.

Para recompilar el frontend con esbuild hay que dejar por fuera las rutas `/assets/`:

```bash
esbuild src/main.jsx --bundle --minify --format=esm --jsx=automatic --loader:.js=jsx \
  --define:process.env.NODE_ENV='"production"' --external:/assets/* \
  --outfile=../backend/frontend_dist/assets/index.js --resolve-extensions=.jsx,.js
```

Con Vite (`npm run build`) no hace falta nada especial: copia `public/` automáticamente.

**Corrección incluida:** en el bloque 5 la Presidencia Nacional nunca podía recibir un rol nacional, porque solo ella aprobaba esos roles y nadie aprueba los suyos. Ahora los aprueba la Vicepresidencia o la Secretaría General Nacional (sección 9.8 de `12_roles_suplencias.sql`).

## 4. Correcciones hechas a tu script v9.0

1. **El operador `||` venía como `││`** (caracteres de dibujo que introdujo Word). El script original no compilaba tal como estaba en el documento.
2. **Radicados duplicados bajo concurrencia**: el consecutivo usaba `MAX()+1` sin bloqueo.
3. **Choque de radicados entre estamentos**: dos subdirectivas del mismo municipio generaban el mismo prefijo (p. ej. `SUB_MED`) y la segunda radicación fallaba por la restricción UNIQUE. Ahora el consecutivo se calcula por prefijo.
4. Un documento podía radicarse con un flujo distinto al de su tipo (un ACT como RECIBIDO). Ahora se valida.
5. `usuario_creacion` y la bitácora guardaban siempre el usuario de PostgreSQL; ahora guardan el usuario real de la aplicación.
6. El RLS de `persona` impedía hacer backups con un rol que no fuera superusuario (se detectó en las pruebas); `sgs_backup` ahora tiene `BYPASSRLS`.
7. Los informes y actas **anulados** ya no cuentan como actividad en las vistas de inactividad y rendición de cuentas.
8. Registrar un avance de compromiso actualiza automáticamente el porcentaje y el estado del compromiso.
9. `directivo_estamento` no limitaba los cargos: una persona podía tener cualquier número de cargos, incluso el mismo dos veces, y el cargo era texto libre.

---

## 5. Funciones de la aplicación

- **Tablero de alertas** con conteo por nivel (crítica, alta, media) de todas las vistas que el rol puede ver.
- **Formularios automáticos** para las 21 tablas del script, con búsqueda, orden, paginación y listas desplegables que muestran nombres en lugar de IDs.
- **Radicación**: el radicado y el código de expediente se asignan solos; adjuntar PDF, verificar integridad, descargar y ver el historial del trámite.
- **Expedientes**: hoja de ruta foliada.
- **Compromisos**: registrar y consultar avances.
- **Finanzas**: botón *Generar aportes del 0.7%* en cada consignación, que crea los aportes desde el salario base y muestra la conciliación.
- **Directivos**: catálogo oficial de cargos, retiro con fecha y motivo (el historial se conserva) y pertenencia de cada afiliado a su subdirectiva o comité.
- **Vistas**: las 7 vistas de auditoría del script, *Composición de juntas* (cargos provistos y vacantes), *Directivos con doble cargo* y 3 de índices, con filtro por nivel y exportación a CSV (Excel).

---

## 6. Pruebas

```bash
cd backend
DATABASE_URL=postgresql://sgs_app:...@localhost/sgsindical \
BACKUP_DATABASE_URL=postgresql://sgs_backup:...@localhost/sgsindical \
NOTIFICADOR_DATABASE_URL=postgresql://sgs_notificador:...@localhost/sgsindical \
python -m tests.prueba_api
```

Las pruebas levantan un servidor de correo local que captura los mensajes (no se envía nada a internet) y requieren Python 3.11.

Requiere una base recién instalada con `04_datos_demo.sql` y, para simular reuniones ya ocurridas, `SUPER_DATABASE_URL` (superusuario, solo en pruebas). Verifica 806 casos (777 si se ejecutan después de las 8:00 p. m., porque se omiten las de reuniones): posesión de directivos con el registro del inspector (designación con acta, posesión con la fecha del registro, retiro de quien sale, quién no ejerce sin registro, registro con fecha futura), permisos sindicales (solo Presidente o Secretario General en ejercicio, juntas habilitadas, antelación de 8, 4 y 1 días hábiles, cruce de fechas entre juntas, una empresa por solicitud, carta en PDF, respuesta con causal, silencio administrativo, anulación, días por afiliado y correo automático), lugares oficiales (países ISO 3166-1 con Colombia primero, DIVIPOLA, municipio del departamento elegido, nombres ambiguos, carga del archivo del DANE), traslados entre juntas con dos actas y excepciones, Palmira (sede nacional) y dispersos, expediente de afiliación (cuenta del portal desde la solicitud, fotos convertidas a PDF, revisión y rechazo con motivo, quién ve los archivos, bitácora de accesos, aprobación solo con documentos aceptados, vencimiento a los 60 días, recordatorios y resumen a la junta), afiliados dispersos (acta de la Junta Nacional, historial, aporte 100 % nacional), datos institucionales, documentos legales (borradores que no se publican con marcas pendientes, consulta pública, criterio de cautela), niveles de jefes 1 a 4, jefe directo obligatorio y cadena de escalamiento, representante legal único por empresa y de varias empresas por persona, plazos de ley (aclaración, recurso de reposición, reclamo incompleto, desistimiento, traslado y leyenda «reclamo en trámite»; ningún plazo se alarga más allá de la ley), varios roles y contexto activo (elegir al ingresar, permisos que no se suman, sesiones en otros equipos), incompatibilidades (también con fechas futuras y al ligar personas), aprobación de roles por la Presidencia Nacional, suplencias (acta, 90 días, titular suspendido, renovación, vencimiento, alerta de 60 días), endurecimiento (ataques con la contraseña de la aplicación: suplantar al administrador, leer hashes, crear sesiones, subir roles, apagar el MFA, tocar permisos, saltarse reglas con variables de operación, ejecutar funciones internas; detección de conexiones ajenas y alerta), PQRSD recibidas (plazos con corte de las 5 p. m. y festivos, anónimas, prórroga hasta el doble, solicitud incompleta y desistimiento, traslados, concepto jurídico de denuncias, respuesta firmada en PDF, historia inmutable y alertas), verificación en dos pasos (activación, ingreso, correo, recuperación, recordar equipo, doble verificación, bloqueo y reinicio), Ventanilla, solicitudes de afiliación, invitación y portal del afiliado, certificados y verificación pública,: porcentaje del aporte (0,6 % / 0,7 %, transición, correcciones, novedades, redondeo, exoneraciones),: datos personales (reserva de salario y género, bitácora de accesos, consentimiento, días hábiles, solicitudes del titular, anonimización),: nada se borra (inactivar, reactivar, anular, desafiliación y mora, cascadas, doble candado),: estrategia de contenidos en redes (política, calendario, piezas con IA, revisión, publicación y resultados),: escritos jurídicos con IA (fuentes de texto, PDF, Word, audio y video; revisión y radicación),: redes sociales y claves cifradas, reuniones, convocatorias, asistencia y actas,: historia de las juntas,: elección, reelección y rotación,: jerarquía de jefes,: correos automáticos,: acceso territorial,: autenticación, bloqueo, permisos, reglas de cargos directivos, concurrencia, radicación, archivos, finanzas, vistas, auditoría y backups.

---

## 7. Recomendaciones para producción

- En modo central, publique el backend **solo por HTTPS** (IIS, Nginx o Caddy como proxy inverso) y fije `JWT_SECRET` en el `.env`; si no se fija, las sesiones se invalidan en cada reinicio.
- En `pg_hba.conf` use `scram-sha-256` y SSL, y permita conexiones solo desde el servidor del backend (ver sección 3o).
- Si usa varios procesos de uvicorn, todos deben compartir el mismo `JWT_SECRET`.
- Pruebe una restauración completa al menos una vez al mes.

---

## 8. Ambientes de prueba y despliegue seguro

La guía *Estrategia de pruebas — guía detallada* (documento Word) explica paso a paso las cuatro líneas: Mac local, GitHub, droplet de ensayo y actualización de producción con respaldo. Archivos de apoyo:

| Archivo | Para qué |
|---|---|
| `ops/probar_mac.sh` | Reinstala la base `sgsindical_pruebas` con datos demo y corre las 806 verificaciones (Mac o Linux). |
| `ops/crear_env_local.py` | Crea el `.env` del ambiente local (base `sgsindical_demo`, correos a Mailpit, IA simulada). |
| `.github/workflows/pruebas.yml` | Corre las verificaciones en GitHub Actions con cada cambio. |
| `.gitignore` | Impide subir a GitHub el `.env`, backups y documentos. |
| `ops/que_version.sql` | Muestra qué bloques (12 a 18) tiene instalados una base; solo lee. |
| `ops/respaldo_previo.sh` | Antes de actualizar producción: backup de la base + archivos subidos + programa + `.env`, con huellas SHA-256. |
| `ops/ensayo/neutralizar.sql` | En la copia de ensayo, cambia correos y teléfonos por valores ficticios. Se niega a correr si la base no termina en `_ensayo`. |
| `ops/ensayo/*.service`, `nginx_ensayo.conf` | Servicio, Mailpit y Nginx (con franja roja «AMBIENTE DE PRUEBA») de la droplet de ensayo. |

Los scripts 16, 17, 17b y 18 se pueden aplicar sobre una base que esté en el bloque 15 con `psql -1 -v ON_ERROR_STOP=1 -f …` (cada script en una sola transacción: si falla, no deja nada a medias).
