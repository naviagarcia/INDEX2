-- ============================================================================
-- SGSINDICAL v9.1 — 12: VARIOS ROLES POR PERSONA, CONTEXTO ACTIVO, INCOMPATIBILIDADES Y SUPLENCIAS
-- Ejecutar DESPUÉS de 11. No modifica los archivos anteriores. Si se vuelve a ejecutar alguno de los
-- scripts 02e a 11, ejecute este otra vez al final.
-- ----------------------------------------------------------------------------
--  R1. CONTEXTOS: cada usuario puede tener varios roles, cada uno con su ámbito (nacional o juntas) y su
--      vigencia. Trabaja en uno a la vez (R-05): si tiene varios, elige al ingresar y puede cambiar desde el
--      encabezado. Los permisos nunca se suman entre contextos; los cargos directivos solo cuentan en los
--      contextos que los incluyen. Quien también es afiliado conserva "Mi espacio".
--  R2. INCOMPATIBILIDADES (la base las impide): (1) Tesorería y Auditoría/Fiscalía en la misma junta;
--      (2) Administrador con cualquier otro rol; (3) Ventanilla y Presidente o Secretario General (quienes
--      aprueban afiliaciones) en la misma junta.
--  R3. ASIGNACIÓN: la hace el administrador (no sobre sí mismo). El rol de Administrador y los roles con
--      ámbito nacional quedan pendientes hasta que los apruebe la Presidencia Nacional.
--  R4. SUPLENCIAS: encargo temporal de un cargo directivo, decidido por la junta con acta; máximo 90 días;
--      renovable con acta nueva. Mientras dura, el titular queda suspendido y solo actúa el suplente. Termina
--      sola al vencer. Alerta 7 días antes del vencimiento y cuando la misma ausencia pasa de 60 días.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. TABLAS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS seguridad.usuario_rol (
    id_usuario_rol BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_usuario BIGINT NOT NULL REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    codigo_rol VARCHAR(30) NOT NULL REFERENCES seguridad.rol_app(codigo_rol) ON DELETE RESTRICT,
    ambito_nacional BOOLEAN NOT NULL DEFAULT FALSE,
    incluye_cargos BOOLEAN NOT NULL DEFAULT TRUE,
    desde DATE NOT NULL DEFAULT CURRENT_DATE,
    hasta DATE,
    origen VARCHAR(10) NOT NULL DEFAULT 'ASIGNADO' CHECK (origen IN ('MIGRADO', 'ASIGNADO', 'SUPLENCIA')),
    id_suplencia BIGINT,
    estado VARCHAR(10) NOT NULL DEFAULT 'VIGENTE' CHECK (estado IN ('PENDIENTE', 'VIGENTE', 'RECHAZADO', 'REVOCADO')),
    motivo TEXT,
    solicitado_por VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    fecha_solicitud TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    decidido_por VARCHAR(50),
    fecha_decision TIMESTAMP WITH TIME ZONE,
    observacion_decision TEXT,
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_usuario_rol_fechas CHECK (hasta IS NULL OR hasta >= desde)
);
COMMENT ON TABLE seguridad.usuario_rol IS 'Contextos de trabajo de cada usuario: rol + ámbito + vigencia. Se trabaja en uno a la vez (R-05).';
CREATE INDEX IF NOT EXISTS ix_usuario_rol_usuario ON seguridad.usuario_rol (id_usuario, estado);
CREATE INDEX IF NOT EXISTS ix_usuario_rol_rol ON seguridad.usuario_rol (codigo_rol);

CREATE TABLE IF NOT EXISTS seguridad.usuario_rol_ambito (
    id_usuario_rol BIGINT NOT NULL REFERENCES seguridad.usuario_rol(id_usuario_rol) ON DELETE RESTRICT,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    PRIMARY KEY (id_usuario_rol, id_estamento)
);
CREATE INDEX IF NOT EXISTS ix_usuario_rol_ambito_est ON seguridad.usuario_rol_ambito (id_estamento);

ALTER TABLE seguridad.usuario ADD COLUMN IF NOT EXISTS id_contexto_activo BIGINT REFERENCES seguridad.usuario_rol(id_usuario_rol) ON DELETE RESTRICT;
CREATE INDEX IF NOT EXISTS ix_usuario_contexto ON seguridad.usuario (id_contexto_activo);
ALTER TABLE seguridad.sesion ADD COLUMN IF NOT EXISTS contexto_elegido BOOLEAN NOT NULL DEFAULT TRUE;

CREATE TABLE IF NOT EXISTS gobernanza.suplencia (
    id_suplencia BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    id_cargo BIGINT NOT NULL REFERENCES gobernanza.cargo_directivo(id_cargo) ON DELETE RESTRICT,
    id_persona_titular BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    id_persona_suplente BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    desde DATE NOT NULL,
    hasta DATE NOT NULL,
    id_acta BIGINT NOT NULL REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    motivo TEXT NOT NULL,
    id_suplencia_anterior BIGINT REFERENCES gobernanza.suplencia(id_suplencia) ON DELETE RESTRICT,
    estado VARCHAR(10) NOT NULL DEFAULT 'VIGENTE' CHECK (estado IN ('VIGENTE', 'REVOCADA')),
    fecha_revocacion TIMESTAMP WITH TIME ZONE,
    motivo_revocacion TEXT,
    fecha_registro TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    usuario_registro VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_suplencia_fechas CHECK (hasta >= desde AND hasta - desde <= 89),
    CONSTRAINT ck_suplencia_personas CHECK (id_persona_titular <> id_persona_suplente)
);
COMMENT ON TABLE gobernanza.suplencia IS 'Encargos temporales de cargos directivos (máximo 90 días, con acta de la junta). El titular queda suspendido.';
CREATE INDEX IF NOT EXISTS ix_suplencia_estamento ON gobernanza.suplencia (id_estamento, id_cargo);
CREATE INDEX IF NOT EXISTS ix_suplencia_cargo ON gobernanza.suplencia (id_cargo);
CREATE INDEX IF NOT EXISTS ix_suplencia_titular ON gobernanza.suplencia (id_persona_titular);
CREATE INDEX IF NOT EXISTS ix_suplencia_suplente ON gobernanza.suplencia (id_persona_suplente);
CREATE INDEX IF NOT EXISTS ix_suplencia_acta ON gobernanza.suplencia (id_acta);
CREATE INDEX IF NOT EXISTS ix_suplencia_anterior ON gobernanza.suplencia (id_suplencia_anterior);
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'usuario_rol_id_suplencia_fkey') THEN
        ALTER TABLE seguridad.usuario_rol ADD CONSTRAINT usuario_rol_id_suplencia_fkey
            FOREIGN KEY (id_suplencia) REFERENCES gobernanza.suplencia(id_suplencia) ON DELETE RESTRICT;
    END IF;
END $$;
CREATE INDEX IF NOT EXISTS ix_usuario_rol_suplencia ON seguridad.usuario_rol (id_suplencia);

ALTER TABLE auditoria.registro_acceso DROP CONSTRAINT IF EXISTS registro_acceso_evento_check;
ALTER TABLE auditoria.registro_acceso ADD CONSTRAINT registro_acceso_evento_check CHECK (evento IN (
    'LOGIN_OK', 'LOGIN_FALLIDO', 'CUENTA_BLOQUEADA', 'LOGOUT', 'CAMBIO_CONTRASENA', 'ACCESO_DENEGADO', 'SESION_REVOCADA',
    'MFA_OK', 'MFA_FALLIDO', 'MFA_ACTIVADO', 'MFA_RECUPERACION', 'MFA_REINICIADO', 'MFA_PASO_ADICIONAL', 'SEGURIDAD_BLOQUEO',
    'CAMBIO_CONTEXTO'));

-- ----------------------------------------------------------------------------
-- 2. QUIÉN EJERCE CADA CARGO HOY (titular, salvo que esté suplido; o el suplente)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION gobernanza.fn_suplencia_vigente(s gobernanza.suplencia)
RETURNS BOOLEAN AS $$
    SELECT s.estado = 'VIGENTE' AND gestion_documental.fn_hoy() BETWEEN s.desde AND s.hasta;
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE VIEW gobernanza.v_cargos_en_ejercicio WITH (security_invoker = true) AS
SELECT d.id_estamento, d.id_cargo, c.codigo, c.nombre, c.orden, c.acceso_nacional, d.id_persona,
       d.fecha_posesion_individual AS desde, FALSE AS por_suplencia, NULL::BIGINT AS id_suplencia
  FROM gobernanza.directivo_estamento d
  JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
 WHERE d.fecha_retiro IS NULL
   AND NOT EXISTS (SELECT 1 FROM gobernanza.suplencia s
                    WHERE s.id_estamento = d.id_estamento AND s.id_cargo = d.id_cargo AND s.id_persona_titular = d.id_persona
                      AND s.estado = 'VIGENTE' AND gestion_documental.fn_hoy() BETWEEN s.desde AND s.hasta)
UNION ALL
SELECT s.id_estamento, s.id_cargo, c.codigo, c.nombre, c.orden, c.acceso_nacional, s.id_persona_suplente,
       s.desde, TRUE, s.id_suplencia
  FROM gobernanza.suplencia s
  JOIN gobernanza.cargo_directivo c ON c.id_cargo = s.id_cargo
 WHERE s.estado = 'VIGENTE' AND gestion_documental.fn_hoy() BETWEEN s.desde AND s.hasta;
COMMENT ON VIEW gobernanza.v_cargos_en_ejercicio IS 'Quién ejerce hoy cada cargo: el titular (si no está suplido) o su suplente.';

-- Cargos que el usuario actual ejerce, solo si su contexto activo incluye los cargos
CREATE OR REPLACE FUNCTION seguridad.fn_mis_cargos()
RETURNS TABLE (id_estamento BIGINT, id_cargo BIGINT, codigo TEXT, nombre TEXT, orden INT, acceso_nacional BOOLEAN,
               desde DATE, por_suplencia BOOLEAN) AS $$
    SELECT v.id_estamento, v.id_cargo, v.codigo::TEXT, v.nombre::TEXT, v.orden::INT, v.acceso_nacional, v.desde, v.por_suplencia
      FROM seguridad.usuario u
      JOIN gobernanza.v_cargos_en_ejercicio v ON v.id_persona = u.id_persona
      LEFT JOIN seguridad.usuario_rol r ON r.id_usuario_rol = u.id_contexto_activo
     WHERE u.id_usuario = seguridad.fn_id_usuario_actual() AND u.activo AND COALESCE(r.incluye_cargos, TRUE);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_tiene_cargo(p_patrones TEXT[], p_id_estamento BIGINT DEFAULT NULL)
RETURNS BOOLEAN AS $$
    SELECT EXISTS (SELECT 1 FROM seguridad.fn_mis_cargos() m
                    WHERE m.codigo LIKE ANY (p_patrones) AND (p_id_estamento IS NULL OR m.id_estamento = p_id_estamento));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_ambito_nacional()
RETURNS BOOLEAN AS $$
    SELECT COALESCE((
        SELECT u.codigo_rol = 'ADMIN' OR u.ambito_nacional OR EXISTS (SELECT 1 FROM seguridad.fn_mis_cargos() m WHERE m.acceso_nacional)
          FROM seguridad.usuario u
         WHERE u.id_usuario = seguridad.fn_id_usuario_actual() AND u.activo), FALSE);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_ambito_estamentos()
RETURNS BIGINT[] AS $$
    SELECT COALESCE(ARRAY(
        SELECT m.id_estamento FROM seguridad.fn_mis_cargos() m
        UNION
        SELECT ra.id_estamento FROM seguridad.usuario u
          JOIN seguridad.usuario_rol_ambito ra ON ra.id_usuario_rol = u.id_contexto_activo
         WHERE u.id_usuario = seguridad.fn_id_usuario_actual() AND u.activo
        UNION
        SELECT a.id_estamento FROM seguridad.usuario_ambito a JOIN seguridad.usuario u USING (id_usuario)
         WHERE a.id_usuario = seguridad.fn_id_usuario_actual() AND u.activo AND a.activo AND u.id_contexto_activo IS NULL
    ), '{}');
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Presidencia o Secretaría de la mesa de una junta (reuniones, escritos)
CREATE OR REPLACE FUNCTION gestion_documental.fn_cargo_mesa(p_id_estamento BIGINT, OUT rol TEXT, OUT cargo TEXT, OUT id_persona BIGINT)
RETURNS RECORD AS $$
    SELECT CASE WHEN m.codigo LIKE 'PRES\_%' THEN 'PRESIDENCIA' ELSE 'SECRETARIA' END,
           m.nombre || CASE WHEN m.por_suplencia THEN ' (suplente)' ELSE '' END,
           (SELECT u.id_persona FROM seguridad.usuario u WHERE u.id_usuario = seguridad.fn_id_usuario_actual())
      FROM seguridad.fn_mis_cargos() m
     WHERE m.id_estamento = p_id_estamento AND m.desde <= CURRENT_DATE
       AND (m.codigo LIKE 'PRES\_%' OR m.codigo LIKE 'SGEN\_%')
     ORDER BY 1 LIMIT 1;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Revisión de piezas de contenido (02i)
CREATE OR REPLACE FUNCTION gobernanza.fn_rol_revision_pieza(p_id_pieza BIGINT, OUT rol TEXT, OUT cargo TEXT)
RETURNS RECORD AS $$
DECLARE v_u seguridad.usuario; v_p gobernanza.pieza_contenido; v_c RECORD;
BEGIN
    SELECT * INTO v_u FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo;
    SELECT * INTO v_p FROM gobernanza.pieza_contenido WHERE id_pieza = p_id_pieza;
    IF v_u.id_usuario IS NULL OR v_p.id_pieza IS NULL THEN rol := NULL; RETURN; END IF;
    IF v_u.codigo_rol = 'ABOGADO' AND gobernanza.fn_ambito_pieza(v_p.id_estamento) THEN rol := 'JURIDICA'; cargo := 'Abogado'; RETURN; END IF;
    SELECT m.codigo, m.nombre, e.tipo_estamento INTO v_c
      FROM seguridad.fn_mis_cargos() m JOIN gobernanza.estamento e ON e.id_estamento = m.id_estamento
     WHERE m.id_estamento = v_p.id_estamento
       AND (m.codigo LIKE 'SJUR\_%' OR m.codigo LIKE 'SCOM\_%' OR (e.tipo_estamento = 'COMITÉ SECCIONAL' AND (m.codigo LIKE 'PRES\_%' OR m.codigo LIKE 'SGEN\_%')))
     ORDER BY m.orden LIMIT 1;
    IF v_c.codigo LIKE 'SJUR\_%' THEN rol := 'JURIDICA'; cargo := v_c.nombre; RETURN; END IF;
    IF v_c.codigo IS NOT NULL THEN rol := 'COMUNICACIONES'; cargo := v_c.nombre; RETURN; END IF;
    rol := 'COMENTARIO'; cargo := NULL;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Firma de PQRSD (10)
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_cargo_firmante(p_id_estamento BIGINT)
RETURNS TEXT AS $$
    SELECT m.nombre || CASE WHEN m.por_suplencia THEN ' (suplente)' ELSE '' END || ' — ' || e.nombre_estamento
      FROM seguridad.fn_mis_cargos() m JOIN gobernanza.estamento e ON e.id_estamento = m.id_estamento
     WHERE (m.codigo LIKE ANY (ARRAY['PRES\_%', 'VICE\_%', 'SGEN\_%', 'FIS\_%']) AND m.id_estamento = p_id_estamento)
        OR m.codigo IN ('PRES_NAL', 'VICE_NAL', 'SGEN_NAL', 'FIS_NAL')
     ORDER BY (m.id_estamento = p_id_estamento) DESC, array_position(ARRAY['PRES', 'VICE', 'SGEN', 'FIS'], split_part(m.codigo, '_', 1))
     LIMIT 1;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 3. CONTEXTOS
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION seguridad.fn_contexto_vigente(p_id_usuario_rol BIGINT)
RETURNS BOOLEAN AS $$
    SELECT COALESCE((
        SELECT r.estado = 'VIGENTE' AND r.desde <= gestion_documental.fn_hoy() AND (r.hasta IS NULL OR r.hasta >= gestion_documental.fn_hoy())
               AND (r.id_suplencia IS NULL OR EXISTS (SELECT 1 FROM gobernanza.suplencia s WHERE s.id_suplencia = r.id_suplencia
                                                         AND gobernanza.fn_suplencia_vigente(s)))
          FROM seguridad.usuario_rol r WHERE r.id_usuario_rol = p_id_usuario_rol), FALSE);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Contextos vigentes de un usuario, en orden (el principal primero)
CREATE OR REPLACE FUNCTION seguridad.fn_contextos_de(p_id_usuario BIGINT)
RETURNS TABLE (id_usuario_rol BIGINT, codigo_rol TEXT, nombre_rol TEXT, ambito_nacional BOOLEAN, incluye_cargos BOOLEAN,
               juntas TEXT[], ids_juntas BIGINT[], origen TEXT, desde DATE, hasta DATE, activo BOOLEAN) AS $$
    SELECT r.id_usuario_rol, r.codigo_rol::TEXT, ro.nombre_rol::TEXT, r.ambito_nacional, r.incluye_cargos,
           ARRAY(SELECT e.nombre_estamento::TEXT FROM seguridad.usuario_rol_ambito a JOIN gobernanza.estamento e USING (id_estamento)
                  WHERE a.id_usuario_rol = r.id_usuario_rol ORDER BY 1),
           ARRAY(SELECT a.id_estamento FROM seguridad.usuario_rol_ambito a WHERE a.id_usuario_rol = r.id_usuario_rol ORDER BY 1),
           r.origen::TEXT, r.desde, r.hasta, u.id_contexto_activo = r.id_usuario_rol
      FROM seguridad.usuario_rol r
      JOIN seguridad.rol_app ro ON ro.codigo_rol = r.codigo_rol
      JOIN seguridad.usuario u ON u.id_usuario = r.id_usuario
     WHERE r.id_usuario = p_id_usuario AND seguridad.fn_contexto_vigente(r.id_usuario_rol)
     ORDER BY (r.origen = 'SUPLENCIA'), r.id_usuario_rol;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Aplica un contexto al usuario: rol y ámbito activos (lo que leen todas las reglas y la aplicación)
CREATE OR REPLACE FUNCTION seguridad.fn_aplicar_contexto(p_id_usuario BIGINT, p_id_usuario_rol BIGINT)
RETURNS VOID AS $$
DECLARE r seguridad.usuario_rol%ROWTYPE;
BEGIN
    SELECT * INTO r FROM seguridad.usuario_rol WHERE id_usuario_rol = p_id_usuario_rol AND id_usuario = p_id_usuario;
    IF r.id_usuario_rol IS NULL OR NOT seguridad.fn_contexto_vigente(p_id_usuario_rol) THEN
        RAISE EXCEPTION 'Ese rol no está vigente para el usuario.';
    END IF;
    PERFORM seguridad.fn_fijar_operacion('roles.operacion', 'contexto');
    UPDATE seguridad.usuario SET codigo_rol = r.codigo_rol, ambito_nacional = r.ambito_nacional, id_contexto_activo = r.id_usuario_rol
     WHERE id_usuario = p_id_usuario
       AND (codigo_rol, ambito_nacional, id_contexto_activo) IS DISTINCT FROM (r.codigo_rol, r.ambito_nacional, r.id_usuario_rol);
    PERFORM seguridad.fn_fijar_operacion('roles.operacion', '');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
REVOKE EXECUTE ON FUNCTION seguridad.fn_aplicar_contexto(BIGINT, BIGINT) FROM PUBLIC;

-- El usuario elige (o cambia) el contexto de su sesión
CREATE OR REPLACE FUNCTION seguridad.fn_elegir_contexto(p_id_usuario_rol BIGINT)
RETURNS TEXT AS $$
DECLARE v_u BIGINT := seguridad.fn_id_usuario_actual(); v_desc TEXT;
BEGIN
    IF v_u IS NULL THEN RAISE EXCEPTION 'SEGURIDAD: sesión no válida.' USING ERRCODE = 'insufficient_privilege'; END IF;
    PERFORM seguridad.fn_aplicar_contexto(v_u, p_id_usuario_rol);
    UPDATE seguridad.sesion SET contexto_elegido = TRUE WHERE id_sesion = seguridad.fn_sesion_actual();
    SELECT c.nombre_rol || ' · ' || CASE WHEN c.ambito_nacional THEN 'Nacional' WHEN cardinality(c.juntas) > 0 THEN array_to_string(c.juntas, ', ')
                                        ELSE 'según sus cargos' END
      INTO v_desc FROM seguridad.fn_contextos_de(v_u) c WHERE c.id_usuario_rol = p_id_usuario_rol;
    INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, ip_origen, detalle)
    VALUES (auditoria.fn_usuario_actual(), 'CAMBIO_CONTEXTO', NULLIF(current_setting('app.ip', true), '')::INET, v_desc);
    RETURN v_desc;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- En cada petición: si el contexto activo venció (p. ej. terminó la suplencia), vuelve al principal
CREATE OR REPLACE FUNCTION seguridad.fn_revisar_contexto()
RETURNS BOOLEAN AS $$
DECLARE v_u BIGINT := seguridad.fn_id_usuario_actual(); v_activo BIGINT; v_principal BIGINT; n INT;
BEGIN
    IF v_u IS NULL THEN RETURN FALSE; END IF;
    SELECT id_contexto_activo INTO v_activo FROM seguridad.usuario WHERE id_usuario = v_u;
    IF v_activo IS NOT NULL AND seguridad.fn_contexto_vigente(v_activo) THEN RETURN FALSE; END IF;
    SELECT count(*), min(c.id_usuario_rol) FILTER (WHERE c.origen <> 'SUPLENCIA') INTO n, v_principal FROM seguridad.fn_contextos_de(v_u) c;
    v_principal := COALESCE(v_principal, (SELECT min(c.id_usuario_rol) FROM seguridad.fn_contextos_de(v_u) c));
    IF v_principal IS NULL THEN RETURN FALSE; END IF;
    PERFORM seguridad.fn_aplicar_contexto(v_u, v_principal);
    IF n > 1 THEN UPDATE seguridad.sesion SET contexto_elegido = FALSE WHERE id_sesion = seguridad.fn_sesion_actual(); END IF;
    RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Al crear la sesión: si tiene varios contextos, debe elegir; si tiene uno, se aplica ese
CREATE OR REPLACE FUNCTION seguridad.fn_sesion_contexto()
RETURNS TRIGGER AS $$
DECLARE n INT; v_unico BIGINT;
BEGIN
    SELECT count(*), min(c.id_usuario_rol) INTO n, v_unico FROM seguridad.fn_contextos_de(NEW.id_usuario) c;
    IF n = 1 THEN PERFORM seguridad.fn_aplicar_contexto(NEW.id_usuario, v_unico); END IF;
    NEW.contexto_elegido := n <= 1;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
DROP TRIGGER IF EXISTS trg_sesion_contexto ON seguridad.sesion;
CREATE TRIGGER trg_sesion_contexto BEFORE INSERT ON seguridad.sesion FOR EACH ROW EXECUTE FUNCTION seguridad.fn_sesion_contexto();

-- Segundo factor: se exige si CUALQUIERA de los roles vigentes del usuario lo exige (no solo el activo),
-- para que no se pueda entrar con un rol sin MFA y luego cambiar a uno que lo exige.
CREATE OR REPLACE FUNCTION seguridad.fn_mfa_estado_ingreso(p_id_usuario BIGINT, p_hash_equipo TEXT)
RETURNS TABLE (requiere BOOLEAN, activo BOOLEAN, plazo_hasta TIMESTAMPTZ, equipo_valido BOOLEAN, es_admin BOOLEAN) AS $$
    SELECT r.requiere_mfa OR EXISTS (SELECT 1 FROM seguridad.usuario_rol x JOIN seguridad.rol_app y ON y.codigo_rol = x.codigo_rol
                                      WHERE x.id_usuario = u.id_usuario AND y.requiere_mfa AND seguridad.fn_contexto_vigente(x.id_usuario_rol)),
           u.mfa_activo, u.mfa_plazo_hasta,
           p_hash_equipo IS NOT NULL AND u.codigo_rol <> 'ADMIN' AND EXISTS (
               SELECT 1 FROM seguridad.mfa_equipo e WHERE e.id_usuario = u.id_usuario AND e.hash_token = p_hash_equipo
                  AND NOT e.revocado AND e.expira > now()),
           u.codigo_rol = 'ADMIN'
      FROM seguridad.usuario u JOIN seguridad.rol_app r ON r.codigo_rol = u.codigo_rol
     WHERE u.id_usuario = p_id_usuario;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 4. INCOMPATIBILIDADES
-- ----------------------------------------------------------------------------
-- Devuelve la primera incompatibilidad del usuario con su situación actual (contextos vigentes y cargos que ejerce)
CREATE OR REPLACE FUNCTION seguridad.fn_incompatibilidad(p_id_usuario BIGINT)
RETURNS TEXT AS $$
DECLARE v_persona BIGINT; v_msg TEXT;
BEGIN
    SELECT id_persona INTO v_persona FROM seguridad.usuario WHERE id_usuario = p_id_usuario;
    -- (2) Administrador con cualquier otro rol
    IF EXISTS (SELECT 1 FROM seguridad.fn_contextos_de(p_id_usuario) WHERE codigo_rol = 'ADMIN')
       AND EXISTS (SELECT 1 FROM seguridad.fn_contextos_de(p_id_usuario) WHERE codigo_rol NOT IN ('ADMIN', 'AFILIADO')) THEN
        RETURN 'El Administrador no puede tener además un rol operativo (incompatibilidad 2).';
    END IF;
    -- Funciones por junta (NULL = todo el país)
    WITH ctx AS (SELECT * FROM seguridad.fn_contextos_de(p_id_usuario)),
    fun AS (
        SELECT 'TES' AS f, NULL::BIGINT AS j FROM ctx WHERE codigo_rol = 'TESORERO' AND ambito_nacional
        UNION SELECT 'TES', unnest(ids_juntas) FROM ctx WHERE codigo_rol = 'TESORERO'
        UNION SELECT 'AUD', NULL FROM ctx WHERE codigo_rol = 'AUDITOR' AND ambito_nacional
        UNION SELECT 'AUD', unnest(ids_juntas) FROM ctx WHERE codigo_rol = 'AUDITOR'
        UNION SELECT 'VEN', NULL FROM ctx WHERE codigo_rol = 'VENTANILLA' AND ambito_nacional
        UNION SELECT 'VEN', unnest(ids_juntas) FROM ctx WHERE codigo_rol = 'VENTANILLA'
        UNION SELECT 'TES', v.id_estamento FROM gobernanza.v_cargos_en_ejercicio v WHERE v.id_persona = v_persona AND v.codigo LIKE 'TES\_%'
        UNION SELECT 'AUD', v.id_estamento FROM gobernanza.v_cargos_en_ejercicio v WHERE v.id_persona = v_persona AND v.codigo LIKE 'FIS\_%'
        UNION SELECT 'APR', v.id_estamento FROM gobernanza.v_cargos_en_ejercicio v
               WHERE v.id_persona = v_persona AND (v.codigo LIKE 'PRES\_%' OR v.codigo LIKE 'SGEN\_%')
    )
    SELECT CASE WHEN a.f = 'TES' THEN 'Tesorería y Auditoría/Fiscalía no pueden recaer en la misma persona en la misma junta (incompatibilidad 1)'
                ELSE 'La Ventanilla no puede ser a la vez Presidente o Secretario General de la misma junta, porque ellos aprueban las afiliaciones (incompatibilidad 3)' END
           || COALESCE(': ' || (SELECT nombre_estamento FROM gobernanza.estamento WHERE id_estamento = COALESCE(a.j, b.j)), '') || '.'
      INTO v_msg
      FROM fun a JOIN fun b ON ((a.f = 'TES' AND b.f = 'AUD') OR (a.f = 'VEN' AND b.f = 'APR'))
                            AND (a.j IS NULL OR b.j IS NULL OR a.j = b.j)
     LIMIT 1;
    RETURN v_msg;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_exigir_compatible(p_id_usuario BIGINT)
RETURNS VOID AS $$
DECLARE v TEXT := seguridad.fn_incompatibilidad(p_id_usuario);
BEGIN
    IF v IS NOT NULL THEN
        RAISE EXCEPTION '%', 'Incompatibilidad de funciones: ' || v || ' (usuario ' ||
            (SELECT nombre_usuario FROM seguridad.usuario WHERE id_usuario = p_id_usuario) || ')' ;
    END IF;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Incompatibilidades que ya existían antes de este script (o que surjan por fechas): para revisarlas
CREATE OR REPLACE VIEW seguridad.v_incompatibilidades AS
SELECT u.id_usuario, u.nombre_usuario, u.nombre_completo, x.motivo,
       'ALERTA ALTA: INCOMPATIBILIDAD DE FUNCIONES; RETIRE UNO DE LOS ROLES O CARGOS' AS diagnostico
  FROM seguridad.usuario u
  CROSS JOIN LATERAL (SELECT seguridad.fn_incompatibilidad(u.id_usuario) AS motivo) x
 WHERE u.activo AND x.motivo IS NOT NULL;

-- ----------------------------------------------------------------------------
-- 5. SINCRONÍA CON LAS PANTALLAS DE USUARIOS Y ÁMBITOS (lo que el administrador ya edita)
-- ----------------------------------------------------------------------------
-- Rol de Administrador o ámbito nacional por la ficha del usuario: requieren aprobación (salvo el primer administrador)
CREATE OR REPLACE FUNCTION seguridad.fn_usuario_roles_antes()
RETURNS TRIGGER AS $$
BEGIN
    IF seguridad.fn_operacion('roles.operacion') <> '' OR seguridad.fn_ejecuta_sistema()
       OR NOT EXISTS (SELECT 1 FROM seguridad.usuario WHERE codigo_rol = 'ADMIN' AND activo) THEN
        RETURN NEW;
    END IF;
    IF TG_OP = 'UPDATE' AND NEW.id_usuario = seguridad.fn_id_usuario_actual()
       AND (NEW.codigo_rol IS DISTINCT FROM OLD.codigo_rol OR NEW.ambito_nacional IS DISTINCT FROM OLD.ambito_nacional) THEN
        RAISE EXCEPTION 'SEGURIDAD: nadie puede cambiar su propio rol ni su ámbito.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF (NEW.codigo_rol = 'ADMIN' AND (TG_OP = 'INSERT' OR OLD.codigo_rol <> 'ADMIN'))
       OR (NEW.ambito_nacional AND (TG_OP = 'INSERT' OR NOT OLD.ambito_nacional)) THEN
        RAISE EXCEPTION 'El rol de Administrador y el ámbito nacional los aprueba la Presidencia Nacional: asígnelos en «Roles» del usuario.'
            USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF TG_OP = 'UPDATE' AND NEW.id_contexto_activo IS DISTINCT FROM OLD.id_contexto_activo THEN
        RAISE EXCEPTION 'El contexto activo lo elige el propio usuario.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_usuario_roles_antes ON seguridad.usuario;
CREATE TRIGGER trg_usuario_roles_antes BEFORE INSERT OR UPDATE OF codigo_rol, ambito_nacional, id_contexto_activo ON seguridad.usuario
    FOR EACH ROW EXECUTE FUNCTION seguridad.fn_usuario_roles_antes();

-- Usuario nuevo: su rol es su primer contexto. Cambio de rol en la ficha: cambia el contexto activo.
CREATE OR REPLACE FUNCTION seguridad.fn_usuario_roles_despues()
RETURNS TRIGGER AS $$
DECLARE v_id BIGINT;
BEGIN
    IF seguridad.fn_operacion('roles.operacion') <> '' THEN RETURN NULL; END IF;
    IF TG_OP = 'INSERT' OR NEW.id_contexto_activo IS NULL THEN
        INSERT INTO seguridad.usuario_rol (id_usuario, codigo_rol, ambito_nacional, incluye_cargos, origen, estado, motivo)
        VALUES (NEW.id_usuario, NEW.codigo_rol, NEW.ambito_nacional, NEW.codigo_rol <> 'ADMIN', 'ASIGNADO', 'VIGENTE', 'Rol con el que se creó el usuario')
        RETURNING id_usuario_rol INTO v_id;
        PERFORM seguridad.fn_fijar_operacion('roles.operacion', 'contexto');
        UPDATE seguridad.usuario SET id_contexto_activo = v_id WHERE id_usuario = NEW.id_usuario;
        PERFORM seguridad.fn_fijar_operacion('roles.operacion', '');
    ELSIF NEW.codigo_rol IS DISTINCT FROM OLD.codigo_rol OR NEW.ambito_nacional IS DISTINCT FROM OLD.ambito_nacional THEN
        UPDATE seguridad.usuario_rol SET codigo_rol = NEW.codigo_rol, ambito_nacional = NEW.ambito_nacional,
               incluye_cargos = incluye_cargos AND NEW.codigo_rol <> 'ADMIN'
         WHERE id_usuario_rol = NEW.id_contexto_activo;
    END IF;
    PERFORM seguridad.fn_exigir_compatible(NEW.id_usuario);
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
DROP TRIGGER IF EXISTS trg_usuario_roles_despues ON seguridad.usuario;
CREATE TRIGGER trg_usuario_roles_despues AFTER INSERT OR UPDATE OF codigo_rol, ambito_nacional ON seguridad.usuario
    FOR EACH ROW EXECUTE FUNCTION seguridad.fn_usuario_roles_despues();

-- Ámbitos asignados en «Ámbitos de usuario»: van al contexto activo
CREATE OR REPLACE FUNCTION seguridad.fn_usuario_ambito_contexto()
RETURNS TRIGGER AS $$
DECLARE v_ctx BIGINT;
BEGIN
    SELECT id_contexto_activo INTO v_ctx FROM seguridad.usuario WHERE id_usuario = NEW.id_usuario;
    IF v_ctx IS NULL THEN RETURN NULL; END IF;
    IF NEW.activo THEN
        INSERT INTO seguridad.usuario_rol_ambito (id_usuario_rol, id_estamento) VALUES (v_ctx, NEW.id_estamento) ON CONFLICT DO NOTHING;
    ELSE
        DELETE FROM seguridad.usuario_rol_ambito WHERE id_usuario_rol = v_ctx AND id_estamento = NEW.id_estamento;
    END IF;
    PERFORM seguridad.fn_exigir_compatible(NEW.id_usuario);
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
DROP TRIGGER IF EXISTS trg_usuario_ambito_contexto ON seguridad.usuario_ambito;
CREATE TRIGGER trg_usuario_ambito_contexto AFTER INSERT OR UPDATE OF activo ON seguridad.usuario_ambito
    FOR EACH ROW EXECUTE FUNCTION seguridad.fn_usuario_ambito_contexto();

-- Cargos: al nombrar a alguien, se revisan las incompatibilidades de sus usuarios
CREATE OR REPLACE FUNCTION gobernanza.fn_cargo_compatible()
RETURNS TRIGGER AS $$
DECLARE u BIGINT;
BEGIN
    FOR u IN SELECT id_usuario FROM seguridad.usuario WHERE id_persona = NEW.id_persona AND activo LOOP
        PERFORM seguridad.fn_exigir_compatible(u);
    END LOOP;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
DROP TRIGGER IF EXISTS trg_cargo_compatible ON gobernanza.directivo_estamento;
CREATE TRIGGER trg_cargo_compatible AFTER INSERT OR UPDATE ON gobernanza.directivo_estamento
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_cargo_compatible();

-- Migración: el rol y el ámbito que ya tiene cada usuario pasan a ser su primer contexto (incluye sus cargos, como hoy)
DO $$
DECLARE u RECORD; v_id BIGINT;
BEGIN
    FOR u IN SELECT * FROM seguridad.usuario x WHERE NOT EXISTS (SELECT 1 FROM seguridad.usuario_rol r WHERE r.id_usuario = x.id_usuario) LOOP
        INSERT INTO seguridad.usuario_rol (id_usuario, codigo_rol, ambito_nacional, incluye_cargos, origen, estado, motivo, desde, solicitado_por)
        VALUES (u.id_usuario, u.codigo_rol, u.ambito_nacional, u.codigo_rol <> 'ADMIN', 'MIGRADO', 'VIGENTE', 'Rol que tenía al instalar el bloque 5',
                LEAST(CURRENT_DATE, COALESCE(u.fecha_creacion::DATE, CURRENT_DATE)), 'instalador')
        RETURNING id_usuario_rol INTO v_id;
        INSERT INTO seguridad.usuario_rol_ambito (id_usuario_rol, id_estamento)
        SELECT v_id, a.id_estamento FROM seguridad.usuario_ambito a WHERE a.id_usuario = u.id_usuario AND a.activo;
        PERFORM seguridad.fn_fijar_operacion('roles.operacion', 'contexto');
        UPDATE seguridad.usuario SET id_contexto_activo = v_id WHERE id_usuario = u.id_usuario;
        PERFORM seguridad.fn_fijar_operacion('roles.operacion', '');
    END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- 6. ASIGNACIÓN Y APROBACIÓN DE ROLES
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION seguridad.fn_asignar_rol(p_id_usuario BIGINT, p_codigo_rol TEXT, p_ambito_nacional BOOLEAN, p_juntas BIGINT[],
                                                    p_incluye_cargos BOOLEAN, p_desde DATE, p_hasta DATE, p_motivo TEXT)
RETURNS TABLE (id_usuario_rol BIGINT, estado TEXT) AS $$
DECLARE v_id BIGINT; v_estado TEXT; v_rol TEXT := upper(trim(COALESCE(p_codigo_rol, '')));
BEGIN
    IF NOT seguridad.fn_es_admin() THEN
        RAISE EXCEPTION 'SEGURIDAD: los roles los asigna el administrador.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF p_id_usuario = seguridad.fn_id_usuario_actual() THEN
        RAISE EXCEPTION 'SEGURIDAD: nadie puede asignarse roles a sí mismo.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM seguridad.usuario WHERE id_usuario = p_id_usuario AND activo) THEN RAISE EXCEPTION 'El usuario no existe o está inactivo.'; END IF;
    IF NOT EXISTS (SELECT 1 FROM seguridad.rol_app WHERE codigo_rol = v_rol AND activo) THEN RAISE EXCEPTION 'El rol no existe.'; END IF;
    IF v_rol = 'AFILIADO' THEN RAISE EXCEPTION 'El acceso de afiliado se da con la invitación al portal, no como rol.'; END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo de la asignación (mínimo 10 caracteres).'; END IF;
    IF NOT COALESCE(p_ambito_nacional, FALSE) AND COALESCE(cardinality(p_juntas), 0) = 0 AND NOT COALESCE(p_incluye_cargos, FALSE) AND v_rol <> 'ADMIN' THEN
        RAISE EXCEPTION 'Indique el ámbito: nacional, una o varias juntas, o «según sus cargos».';
    END IF;
    IF p_hasta IS NOT NULL AND p_hasta < COALESCE(p_desde, CURRENT_DATE) THEN RAISE EXCEPTION 'La fecha final es anterior a la inicial.'; END IF;
    v_estado := CASE WHEN v_rol = 'ADMIN' OR COALESCE(p_ambito_nacional, FALSE) THEN 'PENDIENTE' ELSE 'VIGENTE' END;
    INSERT INTO seguridad.usuario_rol (id_usuario, codigo_rol, ambito_nacional, incluye_cargos, desde, hasta, origen, estado, motivo)
    VALUES (p_id_usuario, v_rol, COALESCE(p_ambito_nacional, FALSE) OR v_rol = 'ADMIN',
            COALESCE(p_incluye_cargos, FALSE) AND v_rol <> 'ADMIN', COALESCE(p_desde, CURRENT_DATE), p_hasta, 'ASIGNADO', v_estado, trim(p_motivo))
    RETURNING usuario_rol.id_usuario_rol INTO v_id;
    INSERT INTO seguridad.usuario_rol_ambito (id_usuario_rol, id_estamento)
    SELECT v_id, j FROM unnest(COALESCE(p_juntas, '{}')) j WHERE NOT COALESCE(p_ambito_nacional, FALSE) ON CONFLICT DO NOTHING;
    IF v_estado = 'VIGENTE' THEN PERFORM seguridad.fn_exigir_compatible(p_id_usuario); END IF;
    RETURN QUERY SELECT v_id, v_estado;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_decidir_rol(p_id_usuario_rol BIGINT, p_aprobar BOOLEAN, p_observacion TEXT)
RETURNS TEXT AS $$
DECLARE r seguridad.usuario_rol%ROWTYPE; v_yo TEXT := auditoria.fn_usuario_actual();
BEGIN
    IF NOT seguridad.fn_es_presidente_nacional() THEN
        RAISE EXCEPTION 'SEGURIDAD: los roles de Administrador y de ámbito nacional los aprueba la Presidencia Nacional.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    SELECT * INTO r FROM seguridad.usuario_rol WHERE id_usuario_rol = p_id_usuario_rol FOR UPDATE;
    IF r.id_usuario_rol IS NULL OR r.estado <> 'PENDIENTE' THEN RAISE EXCEPTION 'La solicitud no existe o ya fue decidida.'; END IF;
    IF r.id_usuario = seguridad.fn_id_usuario_actual() OR r.solicitado_por = v_yo THEN
        RAISE EXCEPTION 'SEGURIDAD: no puede aprobar una solicitud propia ni una que usted pidió.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF NOT p_aprobar AND length(trim(COALESCE(p_observacion, ''))) < 5 THEN RAISE EXCEPTION 'Escriba el motivo del rechazo.'; END IF;
    UPDATE seguridad.usuario_rol SET estado = CASE WHEN p_aprobar THEN 'VIGENTE' ELSE 'RECHAZADO' END, decidido_por = v_yo,
           fecha_decision = now(), observacion_decision = NULLIF(trim(COALESCE(p_observacion, '')), '')
     WHERE id_usuario_rol = p_id_usuario_rol;
    IF p_aprobar AND r.codigo_rol = 'ADMIN' THEN
        -- El Administrador no tiene otros roles (incompatibilidad 2): se retiran al aprobarlo
        UPDATE seguridad.usuario_rol SET estado = 'REVOCADO', decidido_por = v_yo, fecha_decision = now(),
               observacion_decision = 'Retirado al aprobar el rol de Administrador (incompatibilidad 2)'
         WHERE id_usuario = r.id_usuario AND id_usuario_rol <> p_id_usuario_rol AND estado IN ('VIGENTE', 'PENDIENTE')
           AND codigo_rol NOT IN ('ADMIN', 'AFILIADO');
        PERFORM seguridad.fn_aplicar_contexto(r.id_usuario, p_id_usuario_rol);
    END IF;
    IF p_aprobar THEN PERFORM seguridad.fn_exigir_compatible(r.id_usuario); END IF;
    RETURN CASE WHEN p_aprobar THEN 'VIGENTE' ELSE 'RECHAZADO' END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_revocar_rol(p_id_usuario_rol BIGINT, p_motivo TEXT)
RETURNS VOID AS $$
DECLARE r seguridad.usuario_rol%ROWTYPE; v_otro BIGINT;
BEGIN
    IF NOT seguridad.fn_es_admin() THEN RAISE EXCEPTION 'SEGURIDAD: los roles los revoca el administrador.' USING ERRCODE = 'insufficient_privilege'; END IF;
    SELECT * INTO r FROM seguridad.usuario_rol WHERE id_usuario_rol = p_id_usuario_rol FOR UPDATE;
    IF r.id_usuario_rol IS NULL OR r.estado NOT IN ('VIGENTE', 'PENDIENTE') THEN RAISE EXCEPTION 'El rol no está vigente.'; END IF;
    IF r.id_usuario = seguridad.fn_id_usuario_actual() THEN
        RAISE EXCEPTION 'SEGURIDAD: nadie puede cambiar sus propios roles.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF r.origen = 'SUPLENCIA' THEN RAISE EXCEPTION 'Este rol viene de una suplencia: revoque la suplencia.'; END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo (mínimo 10 caracteres).'; END IF;
    SELECT c.id_usuario_rol INTO v_otro FROM seguridad.fn_contextos_de(r.id_usuario) c WHERE c.id_usuario_rol <> p_id_usuario_rol LIMIT 1;
    IF r.estado = 'VIGENTE' AND v_otro IS NULL THEN
        RAISE EXCEPTION 'Es el único rol vigente del usuario: si ya no debe entrar, inactive el usuario.';
    END IF;
    UPDATE seguridad.usuario_rol SET estado = 'REVOCADO', decidido_por = auditoria.fn_usuario_actual(), fecha_decision = now(),
           observacion_decision = trim(p_motivo) WHERE id_usuario_rol = p_id_usuario_rol;
    IF EXISTS (SELECT 1 FROM seguridad.usuario WHERE id_usuario = r.id_usuario AND id_contexto_activo = p_id_usuario_rol) THEN
        PERFORM seguridad.fn_aplicar_contexto(r.id_usuario, v_otro);
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE VIEW seguridad.v_roles_usuario AS
SELECT r.id_usuario_rol, r.id_usuario, u.nombre_usuario, u.nombre_completo, r.codigo_rol, ro.nombre_rol, r.ambito_nacional, r.incluye_cargos,
       ARRAY(SELECT e.nombre_estamento FROM seguridad.usuario_rol_ambito a JOIN gobernanza.estamento e USING (id_estamento)
              WHERE a.id_usuario_rol = r.id_usuario_rol ORDER BY 1) AS juntas,
       r.desde, r.hasta, r.origen, r.estado, seguridad.fn_contexto_vigente(r.id_usuario_rol) AS vigente_hoy,
       u.id_contexto_activo = r.id_usuario_rol AS activo, r.motivo, r.solicitado_por, r.fecha_solicitud, r.decidido_por,
       r.fecha_decision, r.observacion_decision, r.id_suplencia
  FROM seguridad.usuario_rol r
  JOIN seguridad.usuario u ON u.id_usuario = r.id_usuario
  JOIN seguridad.rol_app ro ON ro.codigo_rol = r.codigo_rol;

-- ----------------------------------------------------------------------------
-- 7. SUPLENCIAS
-- ----------------------------------------------------------------------------
-- Rol de la aplicación que corresponde a un cargo (para el contexto del suplente)
CREATE OR REPLACE FUNCTION gobernanza.fn_rol_de_cargo(p_codigo TEXT)
RETURNS TEXT AS $$
    SELECT CASE WHEN p_codigo LIKE 'TES\_%' THEN 'TESORERO' WHEN p_codigo LIKE 'FIS\_%' THEN 'AUDITOR' ELSE 'DIRECTIVO' END;
$$ LANGUAGE sql IMMUTABLE;

-- Contexto temporal del suplente (si tiene usuario y no tiene ya un contexto con ese rol que incluya sus cargos)
CREATE OR REPLACE FUNCTION gobernanza.fn_contexto_suplente(p_id_suplencia BIGINT)
RETURNS INT AS $$
DECLARE s gobernanza.suplencia%ROWTYPE; v_rol TEXT; u BIGINT; n INT := 0;
BEGIN
    SELECT * INTO s FROM gobernanza.suplencia WHERE id_suplencia = p_id_suplencia;
    v_rol := gobernanza.fn_rol_de_cargo((SELECT codigo FROM gobernanza.cargo_directivo WHERE id_cargo = s.id_cargo));
    FOR u IN SELECT id_usuario FROM seguridad.usuario WHERE id_persona = s.id_persona_suplente AND activo AND codigo_rol NOT IN ('ADMIN', 'AFILIADO') LOOP
        IF NOT EXISTS (SELECT 1 FROM seguridad.fn_contextos_de(u) c WHERE c.codigo_rol = v_rol AND c.incluye_cargos) THEN
            INSERT INTO seguridad.usuario_rol (id_usuario, codigo_rol, ambito_nacional, incluye_cargos, desde, hasta, origen, id_suplencia, estado, motivo)
            VALUES (u, v_rol, FALSE, TRUE, s.desde, s.hasta, 'SUPLENCIA', s.id_suplencia, 'VIGENTE', 'Suplencia: ' || s.motivo);
        END IF;
        PERFORM seguridad.fn_exigir_compatible(u);
        n := n + 1;
    END LOOP;
    RETURN n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
REVOKE EXECUTE ON FUNCTION gobernanza.fn_contexto_suplente(BIGINT) FROM PUBLIC;

CREATE OR REPLACE FUNCTION gobernanza.fn_exigir_registra_suplencia(p_id_estamento BIGINT, p_titular BIGINT, p_suplente BIGINT)
RETURNS VOID AS $$
DECLARE v_yo BIGINT := (SELECT id_persona FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual());
BEGIN
    IF NOT (seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'SGEN\_%'], p_id_estamento) OR seguridad.fn_tiene_cargo(ARRAY['PRES\_NAL', 'SGEN\_NAL'])) THEN
        RAISE EXCEPTION 'Las suplencias las registra el Presidente o el Secretario General de la junta (o los nacionales), con el acta.'
            USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF v_yo IN (p_titular, p_suplente) THEN
        RAISE EXCEPTION 'Quien está ausente o quien lo suple no registra su propia suplencia: la registra otro de los cargos de la mesa.'
            USING ERRCODE = 'insufficient_privilege';
    END IF;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_registrar_suplencia(p_id_estamento BIGINT, p_id_cargo BIGINT, p_titular BIGINT, p_suplente BIGINT,
                                                            p_desde DATE, p_hasta DATE, p_id_acta BIGINT, p_motivo TEXT,
                                                            p_anterior BIGINT DEFAULT NULL)
RETURNS TABLE (id_suplencia BIGINT, usuarios_con_acceso INT) AS $$
DECLARE v_id BIGINT; v_acta RECORD; n INT;
BEGIN
    PERFORM gobernanza.fn_exigir_registra_suplencia(p_id_estamento, p_titular, p_suplente);
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo de la ausencia (mínimo 10 caracteres).'; END IF;
    IF p_desde IS NULL OR p_hasta IS NULL OR p_hasta < p_desde THEN RAISE EXCEPTION 'Revise las fechas de la suplencia.'; END IF;
    IF p_hasta - p_desde > 89 THEN RAISE EXCEPTION 'Una suplencia dura máximo 90 días; para más tiempo, renuévela con un acta nueva.'; END IF;
    IF p_hasta < gestion_documental.fn_hoy() THEN RAISE EXCEPTION 'La suplencia ya habría terminado: no se registran suplencias pasadas.'; END IF;
    IF NOT EXISTS (SELECT 1 FROM gobernanza.directivo_estamento d WHERE d.id_estamento = p_id_estamento AND d.id_cargo = p_id_cargo
                      AND d.id_persona = p_titular AND d.fecha_retiro IS NULL) THEN
        RAISE EXCEPTION 'El titular no ocupa ese cargo en esa junta.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM gobernanza.afiliado a WHERE a.id_persona = p_suplente AND a.activo) THEN
        RAISE EXCEPTION 'El suplente debe ser afiliado activo.';
    END IF;
    SELECT d.id_estamento, t.sigla_tipo INTO v_acta FROM gestion_documental.documento d
      JOIN gestion_documental.tipo_documento t ON t.id_tipo_documento = d.id_tipo_documento WHERE d.id_documento = p_id_acta;
    IF v_acta.sigla_tipo IS DISTINCT FROM 'ACT' OR v_acta.id_estamento IS DISTINCT FROM p_id_estamento THEN
        RAISE EXCEPTION 'La suplencia se decide con un acta de reunión de la misma junta (documento tipo ACT radicado).';
    END IF;
    IF EXISTS (SELECT 1 FROM gobernanza.suplencia s WHERE s.id_estamento = p_id_estamento AND s.id_cargo = p_id_cargo
                  AND s.estado = 'VIGENTE' AND s.desde <= p_hasta AND s.hasta >= p_desde
                  AND s.id_suplencia IS DISTINCT FROM p_anterior) THEN
        RAISE EXCEPTION 'Ya hay una suplencia de ese cargo en esas fechas.';
    END IF;
    INSERT INTO gobernanza.suplencia (id_estamento, id_cargo, id_persona_titular, id_persona_suplente, desde, hasta, id_acta, motivo, id_suplencia_anterior)
    VALUES (p_id_estamento, p_id_cargo, p_titular, p_suplente, p_desde, p_hasta, p_id_acta, trim(p_motivo), p_anterior)
    RETURNING suplencia.id_suplencia INTO v_id;
    n := gobernanza.fn_contexto_suplente(v_id);
    RETURN QUERY SELECT v_id, n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_renovar_suplencia(p_id BIGINT, p_hasta DATE, p_id_acta BIGINT, p_motivo TEXT)
RETURNS TABLE (id_suplencia BIGINT, usuarios_con_acceso INT) AS $$
DECLARE s gobernanza.suplencia%ROWTYPE;
BEGIN
    SELECT * INTO s FROM gobernanza.suplencia x WHERE x.id_suplencia = p_id FOR UPDATE;
    IF s.id_suplencia IS NULL OR s.estado <> 'VIGENTE' THEN RAISE EXCEPTION 'La suplencia no existe o fue revocada.'; END IF;
    IF EXISTS (SELECT 1 FROM gobernanza.suplencia x WHERE x.id_suplencia_anterior = p_id AND x.estado = 'VIGENTE') THEN
        RAISE EXCEPTION 'Esta suplencia ya fue renovada.';
    END IF;
    IF s.hasta < gestion_documental.fn_hoy() - 1 THEN RAISE EXCEPTION 'La suplencia ya terminó: registre una nueva.'; END IF;
    RETURN QUERY SELECT * FROM gobernanza.fn_registrar_suplencia(s.id_estamento, s.id_cargo, s.id_persona_titular, s.id_persona_suplente,
                                                                 s.hasta + 1, p_hasta, p_id_acta, COALESCE(NULLIF(trim(COALESCE(p_motivo, '')), ''), s.motivo), p_id);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_revocar_suplencia(p_id BIGINT, p_motivo TEXT)
RETURNS VOID AS $$
DECLARE s gobernanza.suplencia%ROWTYPE;
BEGIN
    SELECT * INTO s FROM gobernanza.suplencia WHERE id_suplencia = p_id FOR UPDATE;
    IF s.id_suplencia IS NULL OR s.estado <> 'VIGENTE' THEN RAISE EXCEPTION 'La suplencia no existe o ya fue revocada.'; END IF;
    PERFORM gobernanza.fn_exigir_registra_suplencia(s.id_estamento, s.id_persona_titular, s.id_persona_suplente);
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo (mínimo 10 caracteres), p. ej. el regreso del titular.'; END IF;
    PERFORM seguridad.fn_fijar_operacion('roles.operacion', 'suplencia');
    UPDATE gobernanza.suplencia SET estado = 'REVOCADA', fecha_revocacion = now(), motivo_revocacion = trim(p_motivo) WHERE id_suplencia = p_id;
    UPDATE seguridad.usuario_rol SET estado = 'REVOCADO', decidido_por = auditoria.fn_usuario_actual(), fecha_decision = now(),
           observacion_decision = 'Suplencia revocada: ' || trim(p_motivo)
     WHERE id_suplencia = p_id AND estado = 'VIGENTE';
    PERFORM seguridad.fn_fijar_operacion('roles.operacion', '');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- La suplencia solo se cambia con sus funciones
CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_suplencia()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'UPDATE' AND seguridad.fn_operacion('roles.operacion') = 'suplencia' THEN RETURN NEW; END IF;
    IF TG_OP = 'INSERT' AND seguridad.fn_ejecuta_sistema() THEN RETURN NEW; END IF;
    RAISE EXCEPTION 'Las suplencias se registran, renuevan o revocan con sus acciones.';
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_proteger_suplencia ON gobernanza.suplencia;
CREATE TRIGGER trg_proteger_suplencia BEFORE INSERT OR UPDATE ON gobernanza.suplencia FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_proteger_suplencia();

-- Duración encadenada de una ausencia (suplencia + sus renovaciones anteriores)
CREATE OR REPLACE FUNCTION gobernanza.fn_dias_encadenados(p_id BIGINT)
RETURNS INT AS $$
    WITH RECURSIVE cadena AS (
        SELECT id_suplencia, id_suplencia_anterior, desde, hasta FROM gobernanza.suplencia WHERE id_suplencia = p_id
        UNION ALL
        SELECT s.id_suplencia, s.id_suplencia_anterior, s.desde, s.hasta FROM gobernanza.suplencia s JOIN cadena c ON s.id_suplencia = c.id_suplencia_anterior
    )
    SELECT (max(hasta) - min(desde) + 1)::INT FROM cadena;
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE VIEW gobernanza.v_suplencias WITH (security_invoker = true) AS
SELECT s.id_suplencia, e.nombre_estamento AS junta, c.nombre AS cargo,
       pt.primer_nombre || ' ' || pt.primer_apellido AS titular, ps.primer_nombre || ' ' || ps.primer_apellido AS suplente,
       s.desde, s.hasta, gobernanza.fn_dias_encadenados(s.id_suplencia) AS dias_encadenados, s.estado, s.motivo,
       d.radicado_alfanumerico AS acta,
       CASE WHEN s.estado = 'REVOCADA' THEN 'REVOCADA'
            WHEN gestion_documental.fn_hoy() > s.hasta THEN 'TERMINADA'
            WHEN gestion_documental.fn_hoy() < s.desde THEN 'PROGRAMADA'
            WHEN gobernanza.fn_dias_encadenados(s.id_suplencia) > 60
                 THEN 'ALERTA ALTA: LA AUSENCIA LLEVA MÁS DE 60 DÍAS; LA JUNTA DEBE ESTUDIAR LA VACANCIA SEGÚN LOS ESTATUTOS'
            WHEN s.hasta - gestion_documental.fn_hoy() <= 7 THEN 'ALERTA MEDIA: VENCE EN ' || (s.hasta - gestion_documental.fn_hoy()) || ' DÍA(S)'
            ELSE 'VIGENTE' END AS diagnostico,
       s.id_estamento, s.id_cargo, s.id_persona_titular, s.id_persona_suplente, s.id_suplencia_anterior,
       EXISTS (SELECT 1 FROM gobernanza.suplencia x WHERE x.id_suplencia_anterior = s.id_suplencia AND x.estado = 'VIGENTE') AS renovada
  FROM gobernanza.suplencia s
  JOIN gobernanza.estamento e ON e.id_estamento = s.id_estamento
  JOIN gobernanza.cargo_directivo c ON c.id_cargo = s.id_cargo
  JOIN gobernanza.persona pt ON pt.id_persona = s.id_persona_titular
  JOIN gobernanza.persona ps ON ps.id_persona = s.id_persona_suplente
  LEFT JOIN gestion_documental.documento d ON d.id_documento = s.id_acta;

-- ----------------------------------------------------------------------------
-- 8. VERSIÓN, AUDITORÍA, SEGURIDAD POR FILAS Y PERMISOS
-- ----------------------------------------------------------------------------
DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['seguridad.usuario_rol', 'gobernanza.suplencia'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_control_version ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_control_version BEFORE UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_auditoria ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_no_borrar ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_no_borrar BEFORE DELETE ON %s FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado()', t);
    END LOOP;
END $$;
DROP TRIGGER IF EXISTS trg_auditoria ON seguridad.usuario_rol_ambito;
CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON seguridad.usuario_rol_ambito FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria();

SELECT seguridad.fn_aplicar_politicas('gobernanza.suplencia', ':N OR id_estamento = ANY(:E)', 'false');

DO $$
DECLARE f TEXT; r TEXT;
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        GRANT SELECT ON seguridad.usuario_rol, seguridad.usuario_rol_ambito, seguridad.v_roles_usuario, seguridad.v_incompatibilidades,
                        gobernanza.suplencia, gobernanza.v_suplencias, gobernanza.v_cargos_en_ejercicio TO sgs_app;
        REVOKE INSERT, UPDATE, DELETE ON seguridad.usuario_rol, seguridad.usuario_rol_ambito, gobernanza.suplencia FROM sgs_app;
        -- La aplicación sigue pudiendo leer el usuario (salvo el hash): se agrega la columna nueva
        GRANT SELECT (id_contexto_activo) ON seguridad.usuario TO sgs_app;
        GRANT SELECT (contexto_elegido) ON seguridad.sesion TO sgs_app;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_lectura') THEN
        GRANT SELECT ON gobernanza.suplencia, gobernanza.v_suplencias, gobernanza.v_cargos_en_ejercicio TO sgs_lectura;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_notificador') THEN
        GRANT SELECT ON gobernanza.suplencia, gobernanza.v_suplencias, gobernanza.v_cargos_en_ejercicio TO sgs_notificador;
    END IF;
    FOREACH f IN ARRAY ARRAY['seguridad.fn_elegir_contexto(BIGINT)', 'seguridad.fn_revisar_contexto()',
                             'seguridad.fn_asignar_rol(BIGINT, TEXT, BOOLEAN, BIGINT[], BOOLEAN, DATE, DATE, TEXT)',
                             'seguridad.fn_decidir_rol(BIGINT, BOOLEAN, TEXT)', 'seguridad.fn_revocar_rol(BIGINT, TEXT)',
                             'gobernanza.fn_registrar_suplencia(BIGINT, BIGINT, BIGINT, BIGINT, DATE, DATE, BIGINT, TEXT, BIGINT)',
                             'gobernanza.fn_renovar_suplencia(BIGINT, DATE, BIGINT, TEXT)', 'gobernanza.fn_revocar_suplencia(BIGINT, TEXT)',
                             'seguridad.fn_contextos_de(BIGINT)', 'seguridad.fn_incompatibilidad(BIGINT)'] LOOP
        EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC', f);
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO sgs_app', f); END IF;
    END LOOP;
    -- Internas
    FOREACH f IN ARRAY ARRAY['seguridad.fn_aplicar_contexto(BIGINT, BIGINT)', 'gobernanza.fn_contexto_suplente(BIGINT)'] LOOP
        EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC', f);
        FOREACH r IN ARRAY ARRAY['sgs_app', 'sgs_lectura', 'sgs_notificador'] LOOP
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM %I', f, r); END IF;
        END LOOP;
    END LOOP;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_notificador') THEN
        GRANT EXECUTE ON FUNCTION seguridad.fn_contextos_de(BIGINT), seguridad.fn_incompatibilidad(BIGINT) TO sgs_notificador;
    END IF;
END $$;

INSERT INTO notificaciones.tipo_notificacion (codigo, nombre, descripcion) VALUES
    ('SUPLENCIAS', 'Suplencias por vencer o prolongadas',
     'Al suplente y al Presidente y Secretario General de la junta: 7 días antes de que venza una suplencia, y cuando la misma ausencia pasa de 60 días.')
ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, descripcion = EXCLUDED.descripcion;

-- ============================================================================
-- 9. AJUSTES DE LA REVISIÓN INDEPENDIENTE
-- ============================================================================
-- 9.1 Identidad en capas: la sesión (para el segundo factor y para reparar el contexto) y el usuario
--     operativo (sesión con MFA verificado y contexto vigente). Sin MFA verificado la base no da identidad
--     operativa, y si el rol activo venció (o el usuario no tiene ninguno vigente) tampoco.
CREATE OR REPLACE FUNCTION seguridad.fn_id_usuario_sesion()
RETURNS BIGINT AS $$
    SELECT CASE
        WHEN NULLIF(current_setting('app.sesion', true), '') IS NOT NULL THEN
            (SELECT s.id_usuario FROM seguridad.sesion s JOIN seguridad.usuario u ON u.id_usuario = s.id_usuario
              WHERE s.id_sesion = seguridad.fn_huella_sesion(current_setting('app.sesion', true))
                AND NOT s.revocada AND s.fecha_expiracion > now() AND u.activo)
        WHEN EXISTS (SELECT 1 FROM pg_roles r WHERE r.rolname = session_user AND r.rolsuper) THEN
            NULLIF(current_setting('app.id_usuario', true), '')::BIGINT
        END;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_id_usuario_actual()
RETURNS BIGINT AS $$
    SELECT CASE
        WHEN NULLIF(current_setting('app.sesion', true), '') IS NOT NULL THEN
            (SELECT s.id_usuario FROM seguridad.sesion s JOIN seguridad.usuario u ON u.id_usuario = s.id_usuario
              WHERE s.id_sesion = seguridad.fn_huella_sesion(current_setting('app.sesion', true))
                AND NOT s.revocada AND s.fecha_expiracion > now() AND u.activo AND s.mfa_verificada
                AND (u.id_contexto_activo IS NULL OR seguridad.fn_contexto_vigente(u.id_contexto_activo)))
        WHEN EXISTS (SELECT 1 FROM pg_roles r WHERE r.rolname = session_user AND r.rolsuper) THEN
            NULLIF(current_setting('app.id_usuario', true), '')::BIGINT
        END;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;
COMMENT ON FUNCTION seguridad.fn_id_usuario_actual() IS 'Usuario operativo: sesión vigente, segundo factor verificado y rol activo vigente.';

-- Las funciones del ingreso con segundo factor trabajan con la identidad de la sesión (aún sin MFA verificado)
DO $$
DECLARE f RECORD; v_def TEXT; v_nuevo TEXT;
BEGIN
    FOR f IN SELECT p.oid FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
              WHERE n.nspname = 'seguridad'
                AND ((p.proname LIKE 'fn\_mfa\_%' AND p.proname NOT IN ('fn_mfa_solicitar_reinicio', 'fn_mfa_decidir_reinicio', 'fn_mfa_reconfigurar',
                        'fn_mfa_regenerar_recuperacion', 'fn_mfa_revocar_equipos', 'fn_mfa_secretos_para_rotar', 'fn_mfa_reemplazar_cifrado',
                        'fn_mfa_estado_ingreso'))
                     OR p.proname IN ('fn_registrar_fallo_codigo', 'fn_reiniciar_mis_intentos'))
                AND p.prosrc LIKE '%fn_id_usuario_actual()%'
    LOOP
        v_def := pg_get_functiondef(f.oid);
        v_nuevo := replace(v_def, 'seguridad.fn_id_usuario_actual()', 'seguridad.fn_id_usuario_sesion()');
        IF v_nuevo <> v_def THEN EXECUTE v_nuevo; END IF;
    END LOOP;
END $$;

-- 9.2 Contexto vencido: si es una suplencia renovada, sigue en la renovación; si el usuario no tiene ningún
--     rol vigente, la base lo rechaza (no conserva el último rol)
CREATE OR REPLACE FUNCTION seguridad.fn_revisar_contexto()
RETURNS BOOLEAN AS $$
DECLARE v_u BIGINT := seguridad.fn_id_usuario_sesion(); v_activo BIGINT; v_sig BIGINT; v_principal BIGINT; n INT;
BEGIN
    IF v_u IS NULL THEN RETURN FALSE; END IF;
    SELECT id_contexto_activo INTO v_activo FROM seguridad.usuario WHERE id_usuario = v_u;
    IF v_activo IS NOT NULL AND seguridad.fn_contexto_vigente(v_activo) THEN RETURN FALSE; END IF;
    SELECT r2.id_usuario_rol INTO v_sig
      FROM seguridad.usuario_rol r1
      JOIN gobernanza.suplencia s2 ON s2.id_suplencia_anterior = r1.id_suplencia
      JOIN seguridad.usuario_rol r2 ON r2.id_suplencia = s2.id_suplencia AND r2.id_usuario = v_u
     WHERE r1.id_usuario_rol = v_activo AND seguridad.fn_contexto_vigente(r2.id_usuario_rol)
     LIMIT 1;
    IF v_sig IS NOT NULL THEN
        PERFORM seguridad.fn_aplicar_contexto(v_u, v_sig);
        RETURN TRUE;
    END IF;
    SELECT count(*), min(c.id_usuario_rol) FILTER (WHERE c.origen <> 'SUPLENCIA') INTO n, v_principal FROM seguridad.fn_contextos_de(v_u) c;
    v_principal := COALESCE(v_principal, (SELECT min(c.id_usuario_rol) FROM seguridad.fn_contextos_de(v_u) c));
    IF v_principal IS NULL THEN
        RAISE EXCEPTION 'SEGURIDAD: su usuario no tiene ningún rol vigente; pida al administrador que lo revise.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    PERFORM seguridad.fn_aplicar_contexto(v_u, v_principal);
    IF n > 1 THEN UPDATE seguridad.sesion SET contexto_elegido = FALSE WHERE id_sesion = seguridad.fn_sesion_actual(); END IF;
    RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- 9.3 El rol activo es del usuario: al cambiarlo, se cierran sus otras sesiones (un rol a la vez, también
--     entre equipos), para que nunca convivan dos sesiones con permisos distintos
CREATE OR REPLACE FUNCTION seguridad.fn_elegir_contexto(p_id_usuario_rol BIGINT)
RETURNS TEXT AS $$
DECLARE v_u BIGINT := seguridad.fn_id_usuario_sesion(); v_desc TEXT; v_antes BIGINT; v_otras INT := 0;
BEGIN
    IF v_u IS NULL OR NOT EXISTS (SELECT 1 FROM seguridad.sesion WHERE id_sesion = seguridad.fn_sesion_actual() AND mfa_verificada) THEN
        RAISE EXCEPTION 'SEGURIDAD: sesión no válida o sin el segundo factor verificado.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    SELECT id_contexto_activo INTO v_antes FROM seguridad.usuario WHERE id_usuario = v_u;
    PERFORM seguridad.fn_aplicar_contexto(v_u, p_id_usuario_rol);
    UPDATE seguridad.sesion SET contexto_elegido = TRUE WHERE id_sesion = seguridad.fn_sesion_actual();
    IF v_antes IS DISTINCT FROM p_id_usuario_rol THEN
        UPDATE seguridad.sesion SET revocada = TRUE
         WHERE id_usuario = v_u AND NOT revocada AND id_sesion IS DISTINCT FROM seguridad.fn_sesion_actual();
        GET DIAGNOSTICS v_otras = ROW_COUNT;
    END IF;
    SELECT c.nombre_rol || ' · ' || CASE WHEN c.ambito_nacional THEN 'Nacional' WHEN cardinality(c.juntas) > 0 THEN array_to_string(c.juntas, ', ')
                                        ELSE 'según sus cargos' END
      INTO v_desc FROM seguridad.fn_contextos_de(v_u) c WHERE c.id_usuario_rol = p_id_usuario_rol;
    INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, ip_origen, detalle)
    VALUES (auditoria.fn_usuario_actual(), 'CAMBIO_CONTEXTO', NULLIF(current_setting('app.ip', true), '')::INET,
            v_desc || CASE WHEN v_otras > 0 THEN ' (se cerraron ' || v_otras || ' sesión(es) abiertas en otros equipos)' ELSE '' END);
    RETURN v_desc;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- 9.4 Incompatibilidades: se miran los roles vigentes y los que empiezan después (y las suplencias futuras),
--     para que una fecha de inicio futura no sirva para esquivar la regla
CREATE OR REPLACE FUNCTION seguridad.fn_contextos_proyectados(p_id_usuario BIGINT)
RETURNS TABLE (codigo_rol TEXT, ambito_nacional BOOLEAN, ids_juntas BIGINT[]) AS $$
    SELECT r.codigo_rol::TEXT, r.ambito_nacional,
           ARRAY(SELECT a.id_estamento FROM seguridad.usuario_rol_ambito a WHERE a.id_usuario_rol = r.id_usuario_rol)
      FROM seguridad.usuario_rol r
     WHERE r.id_usuario = p_id_usuario AND r.estado = 'VIGENTE' AND (r.hasta IS NULL OR r.hasta >= gestion_documental.fn_hoy())
       AND (r.id_suplencia IS NULL OR EXISTS (SELECT 1 FROM gobernanza.suplencia s WHERE s.id_suplencia = r.id_suplencia
                                                 AND s.estado = 'VIGENTE' AND s.hasta >= gestion_documental.fn_hoy()));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_incompatibilidad(p_id_usuario BIGINT)
RETURNS TEXT AS $$
DECLARE v_persona BIGINT; v_msg TEXT;
BEGIN
    SELECT id_persona INTO v_persona FROM seguridad.usuario WHERE id_usuario = p_id_usuario;
    IF EXISTS (SELECT 1 FROM seguridad.fn_contextos_proyectados(p_id_usuario) WHERE codigo_rol = 'ADMIN')
       AND EXISTS (SELECT 1 FROM seguridad.fn_contextos_proyectados(p_id_usuario) WHERE codigo_rol NOT IN ('ADMIN', 'AFILIADO')) THEN
        RETURN 'El Administrador no puede tener además un rol operativo (incompatibilidad 2).';
    END IF;
    WITH ctx AS (SELECT * FROM seguridad.fn_contextos_proyectados(p_id_usuario)),
    car AS (   -- cargos que ejerce o ejercerá: los suyos (no suplidos hoy) y las suplencias vigentes o futuras
        SELECT v.id_estamento, v.codigo FROM gobernanza.v_cargos_en_ejercicio v WHERE v.id_persona = v_persona AND NOT v.por_suplencia
        UNION SELECT s.id_estamento, c.codigo FROM gobernanza.suplencia s JOIN gobernanza.cargo_directivo c ON c.id_cargo = s.id_cargo
               WHERE s.id_persona_suplente = v_persona AND s.estado = 'VIGENTE' AND s.hasta >= gestion_documental.fn_hoy()
    ),
    fun AS (
        SELECT 'TES' AS f, NULL::BIGINT AS j FROM ctx WHERE codigo_rol = 'TESORERO' AND ambito_nacional
        UNION SELECT 'TES', unnest(ids_juntas) FROM ctx WHERE codigo_rol = 'TESORERO'
        UNION SELECT 'AUD', NULL FROM ctx WHERE codigo_rol = 'AUDITOR' AND ambito_nacional
        UNION SELECT 'AUD', unnest(ids_juntas) FROM ctx WHERE codigo_rol = 'AUDITOR'
        UNION SELECT 'VEN', NULL FROM ctx WHERE codigo_rol = 'VENTANILLA' AND ambito_nacional
        UNION SELECT 'VEN', unnest(ids_juntas) FROM ctx WHERE codigo_rol = 'VENTANILLA'
        UNION SELECT 'TES', id_estamento FROM car WHERE codigo LIKE 'TES\_%'
        UNION SELECT 'AUD', id_estamento FROM car WHERE codigo LIKE 'FIS\_%'
        UNION SELECT 'APR', id_estamento FROM car WHERE codigo LIKE 'PRES\_%' OR codigo LIKE 'SGEN\_%'
    )
    SELECT CASE WHEN a.f = 'TES' THEN 'Tesorería y Auditoría/Fiscalía no pueden recaer en la misma persona en la misma junta (incompatibilidad 1)'
                ELSE 'La Ventanilla no puede ser a la vez Presidente o Secretario General de la misma junta, porque ellos aprueban las afiliaciones (incompatibilidad 3)' END
           || COALESCE(': ' || (SELECT nombre_estamento FROM gobernanza.estamento WHERE id_estamento = COALESCE(a.j, b.j)), '') || '.'
      INTO v_msg
      FROM fun a JOIN fun b ON ((a.f = 'TES' AND b.f = 'AUD') OR (a.f = 'VEN' AND b.f = 'APR'))
                            AND (a.j IS NULL OR b.j IS NULL OR a.j = b.j)
     LIMIT 1;
    RETURN v_msg;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;
REVOKE EXECUTE ON FUNCTION seguridad.fn_contextos_proyectados(BIGINT) FROM PUBLIC;

-- 9.5 Cada suplencia (también cada renovación) da su propio contexto al suplente, salvo que ya tenga un rol
--     permanente igual que incluya sus cargos
CREATE OR REPLACE FUNCTION gobernanza.fn_contexto_suplente(p_id_suplencia BIGINT)
RETURNS INT AS $$
DECLARE s gobernanza.suplencia%ROWTYPE; v_rol TEXT; u BIGINT; n INT := 0;
BEGIN
    SELECT * INTO s FROM gobernanza.suplencia WHERE id_suplencia = p_id_suplencia;
    v_rol := gobernanza.fn_rol_de_cargo((SELECT codigo FROM gobernanza.cargo_directivo WHERE id_cargo = s.id_cargo));
    FOR u IN SELECT id_usuario FROM seguridad.usuario WHERE id_persona = s.id_persona_suplente AND activo AND codigo_rol NOT IN ('ADMIN', 'AFILIADO') LOOP
        IF NOT EXISTS (SELECT 1 FROM seguridad.fn_contextos_de(u) c WHERE c.codigo_rol = v_rol AND c.incluye_cargos AND c.origen <> 'SUPLENCIA') THEN
            INSERT INTO seguridad.usuario_rol (id_usuario, codigo_rol, ambito_nacional, incluye_cargos, desde, hasta, origen, id_suplencia, estado, motivo)
            VALUES (u, v_rol, FALSE, TRUE, s.desde, s.hasta, 'SUPLENCIA', s.id_suplencia, 'VIGENTE', 'Suplencia: ' || s.motivo);
        END IF;
        PERFORM seguridad.fn_exigir_compatible(u);
        n := n + 1;
    END LOOP;
    RETURN n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
REVOKE EXECUTE ON FUNCTION gobernanza.fn_contexto_suplente(BIGINT) FROM PUBLIC;
DO $$
DECLARE r TEXT;
BEGIN
    FOREACH r IN ARRAY ARRAY['sgs_app', 'sgs_lectura', 'sgs_notificador'] LOOP
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
            EXECUTE format('REVOKE EXECUTE ON FUNCTION gobernanza.fn_contexto_suplente(BIGINT) FROM %I', r);
            EXECUTE format('REVOKE EXECUTE ON FUNCTION seguridad.fn_contextos_proyectados(BIGINT) FROM %I', r);
        END IF;
    END LOOP;
END $$;

-- 9.6 Registro de suplencias: sin carreras entre dos registros simultáneos, y cada renovación con un acta
--     nueva (que no se haya usado antes en la misma cadena)
CREATE OR REPLACE FUNCTION gobernanza.fn_registrar_suplencia(p_id_estamento BIGINT, p_id_cargo BIGINT, p_titular BIGINT, p_suplente BIGINT,
                                                            p_desde DATE, p_hasta DATE, p_id_acta BIGINT, p_motivo TEXT,
                                                            p_anterior BIGINT DEFAULT NULL)
RETURNS TABLE (id_suplencia BIGINT, usuarios_con_acceso INT) AS $$
DECLARE v_id BIGINT; v_acta RECORD; n INT;
BEGIN
    PERFORM pg_advisory_xact_lock(hashtext('sgs:suplencia'), (p_id_estamento * 1000 + p_id_cargo)::INT);
    PERFORM gobernanza.fn_exigir_registra_suplencia(p_id_estamento, p_titular, p_suplente);
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo de la ausencia (mínimo 10 caracteres).'; END IF;
    IF p_desde IS NULL OR p_hasta IS NULL OR p_hasta < p_desde THEN RAISE EXCEPTION 'Revise las fechas de la suplencia.'; END IF;
    IF p_hasta - p_desde > 89 THEN RAISE EXCEPTION 'Una suplencia dura máximo 90 días; para más tiempo, renuévela con un acta nueva.'; END IF;
    IF p_hasta < gestion_documental.fn_hoy() THEN RAISE EXCEPTION 'La suplencia ya habría terminado: no se registran suplencias pasadas.'; END IF;
    IF p_titular = p_suplente THEN RAISE EXCEPTION 'El titular no puede ser su propio suplente.'; END IF;
    IF NOT EXISTS (SELECT 1 FROM gobernanza.directivo_estamento d WHERE d.id_estamento = p_id_estamento AND d.id_cargo = p_id_cargo
                      AND d.id_persona = p_titular AND d.fecha_retiro IS NULL) THEN
        RAISE EXCEPTION 'El titular no ocupa ese cargo en esa junta.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM gobernanza.afiliado a WHERE a.id_persona = p_suplente AND a.activo) THEN
        RAISE EXCEPTION 'El suplente debe ser afiliado activo.';
    END IF;
    SELECT d.id_estamento, t.sigla_tipo INTO v_acta FROM gestion_documental.documento d
      JOIN gestion_documental.tipo_documento t ON t.id_tipo_documento = d.id_tipo_documento WHERE d.id_documento = p_id_acta;
    IF v_acta.sigla_tipo IS DISTINCT FROM 'ACT' OR v_acta.id_estamento IS DISTINCT FROM p_id_estamento THEN
        RAISE EXCEPTION 'La suplencia se decide con un acta de reunión de la misma junta (documento tipo ACT radicado).';
    END IF;
    IF p_anterior IS NOT NULL AND EXISTS (
        WITH RECURSIVE cadena AS (
            SELECT s.id_suplencia, s.id_suplencia_anterior, s.id_acta FROM gobernanza.suplencia s WHERE s.id_suplencia = p_anterior
            UNION ALL
            SELECT s.id_suplencia, s.id_suplencia_anterior, s.id_acta FROM gobernanza.suplencia s JOIN cadena c ON s.id_suplencia = c.id_suplencia_anterior)
        SELECT 1 FROM cadena WHERE id_acta = p_id_acta) THEN
        RAISE EXCEPTION 'La renovación se decide con un acta nueva: esa acta ya se usó en esta suplencia.';
    END IF;
    IF EXISTS (SELECT 1 FROM gobernanza.suplencia s WHERE s.id_estamento = p_id_estamento AND s.id_cargo = p_id_cargo
                  AND s.estado = 'VIGENTE' AND s.desde <= p_hasta AND s.hasta >= p_desde
                  AND s.id_suplencia IS DISTINCT FROM p_anterior) THEN
        RAISE EXCEPTION 'Ya hay una suplencia de ese cargo en esas fechas.';
    END IF;
    INSERT INTO gobernanza.suplencia (id_estamento, id_cargo, id_persona_titular, id_persona_suplente, desde, hasta, id_acta, motivo, id_suplencia_anterior)
    VALUES (p_id_estamento, p_id_cargo, p_titular, p_suplente, p_desde, p_hasta, p_id_acta, trim(p_motivo), p_anterior)
    RETURNING suplencia.id_suplencia INTO v_id;
    n := gobernanza.fn_contexto_suplente(v_id);
    -- El suplente también queda sujeto a las incompatibilidades aunque no tenga usuario en el sistema
    IF EXISTS (SELECT 1 FROM gobernanza.suplencia s JOIN gobernanza.cargo_directivo c ON c.id_cargo = s.id_cargo
                WHERE s.id_suplencia = v_id AND (
                    (c.codigo LIKE 'TES\_%' AND EXISTS (SELECT 1 FROM gobernanza.v_cargos_en_ejercicio v WHERE v.id_persona = p_suplente
                                                          AND v.id_estamento = p_id_estamento AND v.codigo LIKE 'FIS\_%'))
                 OR (c.codigo LIKE 'FIS\_%' AND EXISTS (SELECT 1 FROM gobernanza.v_cargos_en_ejercicio v WHERE v.id_persona = p_suplente
                                                          AND v.id_estamento = p_id_estamento AND v.codigo LIKE 'TES\_%')))) THEN
        RAISE EXCEPTION 'Incompatibilidad de funciones: Tesorería y Auditoría/Fiscalía no pueden recaer en la misma persona en la misma junta (incompatibilidad 1).';
    END IF;
    RETURN QUERY SELECT v_id, n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- 9.7 Ficha del usuario: el vínculo con una persona (que trae sus cargos) también pasa por las incompatibilidades;
--     nadie cambia su propio vínculo; y no se puede reescribir desde la ficha un rol aprobado por la Presidencia
--     Nacional, de Administrador o de suplencia (se gestiona en «Roles»)
CREATE OR REPLACE FUNCTION seguridad.fn_usuario_roles_antes()
RETURNS TRIGGER AS $$
BEGIN
    IF seguridad.fn_operacion('roles.operacion') <> '' OR seguridad.fn_ejecuta_sistema()
       OR NOT EXISTS (SELECT 1 FROM seguridad.usuario WHERE codigo_rol = 'ADMIN' AND activo) THEN
        RETURN NEW;
    END IF;
    IF TG_OP = 'UPDATE' AND NEW.id_usuario = seguridad.fn_id_usuario_actual()
       AND (NEW.codigo_rol IS DISTINCT FROM OLD.codigo_rol OR NEW.ambito_nacional IS DISTINCT FROM OLD.ambito_nacional
            OR NEW.id_persona IS DISTINCT FROM OLD.id_persona) THEN
        RAISE EXCEPTION 'SEGURIDAD: nadie puede cambiar su propio rol, su ámbito ni la persona a la que está ligado.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF (NEW.codigo_rol = 'ADMIN' AND (TG_OP = 'INSERT' OR OLD.codigo_rol <> 'ADMIN'))
       OR (NEW.ambito_nacional AND (TG_OP = 'INSERT' OR NOT OLD.ambito_nacional)) THEN
        RAISE EXCEPTION 'El rol de Administrador y el ámbito nacional los aprueba la Presidencia Nacional: asígnelos en «Roles» del usuario.'
            USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF TG_OP = 'UPDATE' AND NEW.codigo_rol IS DISTINCT FROM OLD.codigo_rol
       AND EXISTS (SELECT 1 FROM seguridad.usuario_rol r WHERE r.id_usuario_rol = OLD.id_contexto_activo
                      AND (r.ambito_nacional OR r.codigo_rol = 'ADMIN' OR r.origen = 'SUPLENCIA' OR r.decidido_por IS NOT NULL)) THEN
        RAISE EXCEPTION 'Ese rol fue aprobado por la Presidencia Nacional o viene de una suplencia: no se cambia desde la ficha; gestiónelo en «Roles» del usuario.'
            USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF TG_OP = 'UPDATE' AND NEW.id_contexto_activo IS DISTINCT FROM OLD.id_contexto_activo THEN
        RAISE EXCEPTION 'El contexto activo lo elige el propio usuario.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_usuario_roles_antes ON seguridad.usuario;
CREATE TRIGGER trg_usuario_roles_antes BEFORE INSERT OR UPDATE OF codigo_rol, ambito_nacional, id_contexto_activo, id_persona ON seguridad.usuario
    FOR EACH ROW EXECUTE FUNCTION seguridad.fn_usuario_roles_antes();
DROP TRIGGER IF EXISTS trg_usuario_roles_despues ON seguridad.usuario;
CREATE TRIGGER trg_usuario_roles_despues AFTER INSERT OR UPDATE OF codigo_rol, ambito_nacional, id_persona ON seguridad.usuario
    FOR EACH ROW EXECUTE FUNCTION seguridad.fn_usuario_roles_despues();

-- Vincular un usuario con quien ejerce un cargo nacional (p. ej. la Presidencia Nacional) da mucho poder:
-- queda registrado y genera alerta de seguridad al administrador y a la Presidencia Nacional
ALTER TABLE auditoria.registro_acceso DROP CONSTRAINT IF EXISTS registro_acceso_evento_check;
ALTER TABLE auditoria.registro_acceso ADD CONSTRAINT registro_acceso_evento_check CHECK (evento IN (
    'LOGIN_OK', 'LOGIN_FALLIDO', 'CUENTA_BLOQUEADA', 'LOGOUT', 'CAMBIO_CONTRASENA', 'ACCESO_DENEGADO', 'SESION_REVOCADA',
    'MFA_OK', 'MFA_FALLIDO', 'MFA_ACTIVADO', 'MFA_RECUPERACION', 'MFA_REINICIADO', 'MFA_PASO_ADICIONAL', 'SEGURIDAD_BLOQUEO',
    'CAMBIO_CONTEXTO', 'VINCULO_CARGO_NACIONAL'));

CREATE OR REPLACE FUNCTION seguridad.fn_avisar_vinculo_nacional()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.id_persona IS NOT NULL AND (TG_OP = 'INSERT' OR NEW.id_persona IS DISTINCT FROM OLD.id_persona)
       AND EXISTS (SELECT 1 FROM gobernanza.v_cargos_en_ejercicio v WHERE v.id_persona = NEW.id_persona AND v.acceso_nacional) THEN
        INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, ip_origen, detalle)
        VALUES (auditoria.fn_usuario_actual(), 'VINCULO_CARGO_NACIONAL', NULLIF(current_setting('app.ip', true), '')::INET,
                format('El usuario %s quedó ligado a %s, que ejerce un cargo nacional.', NEW.nombre_usuario,
                       (SELECT primer_nombre || ' ' || primer_apellido FROM gobernanza.persona WHERE id_persona = NEW.id_persona)));
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
DROP TRIGGER IF EXISTS trg_avisar_vinculo_nacional ON seguridad.usuario;
CREATE TRIGGER trg_avisar_vinculo_nacional AFTER INSERT OR UPDATE OF id_persona ON seguridad.usuario
    FOR EACH ROW EXECUTE FUNCTION seguridad.fn_avisar_vinculo_nacional();

CREATE OR REPLACE VIEW auditoria.v_alertas_seguridad AS
SELECT 'CONEXIÓN AJENA' AS tipo, c.detectada_en AS fecha, c.usuario_bd AS cuenta,
       'Programa: ' || COALESCE(c.aplicacion, '(sin nombre)') || COALESCE(' · IP ' || host(c.ip), ' · conexión local') AS detalle,
       'ALERTA CRÍTICA: ALGUIEN SE CONECTÓ CON LA CONTRASEÑA DE LA APLICACIÓN FUERA DE ELLA' AS diagnostico
  FROM auditoria.conexion_ajena c WHERE c.detectada_en > now() - INTERVAL '30 days'
UNION ALL
SELECT 'INTENTO BLOQUEADO', r.fecha_hora, r.nombre_usuario, r.detalle,
       'ALERTA ALTA: LA BASE DE DATOS BLOQUEÓ UNA OPERACIÓN NO AUTORIZADA'
  FROM auditoria.registro_acceso r WHERE r.evento = 'SEGURIDAD_BLOQUEO' AND r.fecha_hora > now() - INTERVAL '30 days'
UNION ALL
SELECT 'VÍNCULO CON CARGO NACIONAL', r.fecha_hora, r.nombre_usuario, r.detalle,
       'ALERTA MEDIA: VERIFIQUE QUE ESTA CUENTA CORRESPONDA A LA PERSONA QUE EJERCE EL CARGO NACIONAL'
  FROM auditoria.registro_acceso r WHERE r.evento = 'VINCULO_CARGO_NACIONAL' AND r.fecha_hora > now() - INTERVAL '30 days';

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN GRANT SELECT ON auditoria.v_alertas_seguridad TO sgs_app; END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_notificador') THEN GRANT SELECT ON auditoria.v_alertas_seguridad TO sgs_notificador; END IF;
END $$;

-- 9.8 La propia Presidencia Nacional también necesita su rol nacional: como no puede aprobar lo propio,
--     sus solicitudes las aprueba el Vicepresidente o el Secretario General Nacional (y solo esas)
CREATE OR REPLACE FUNCTION seguridad.fn_aprobador_nacional()
RETURNS BOOLEAN AS $$
    SELECT seguridad.fn_es_presidente_nacional() OR seguridad.fn_tiene_cargo(ARRAY['VICE\_NAL', 'SGEN\_NAL']);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_decidir_rol(p_id_usuario_rol BIGINT, p_aprobar BOOLEAN, p_observacion TEXT)
RETURNS TEXT AS $$
DECLARE r seguridad.usuario_rol%ROWTYPE; v_yo TEXT := auditoria.fn_usuario_actual(); v_de_presidencia BOOLEAN;
BEGIN
    IF NOT seguridad.fn_aprobador_nacional() THEN
        RAISE EXCEPTION 'SEGURIDAD: los roles de Administrador y de ámbito nacional los aprueba la Presidencia Nacional.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    SELECT * INTO r FROM seguridad.usuario_rol WHERE id_usuario_rol = p_id_usuario_rol FOR UPDATE;
    IF r.id_usuario_rol IS NULL OR r.estado <> 'PENDIENTE' THEN RAISE EXCEPTION 'La solicitud no existe o ya fue decidida.'; END IF;
    IF r.id_usuario = seguridad.fn_id_usuario_actual() OR r.solicitado_por = v_yo THEN
        RAISE EXCEPTION 'SEGURIDAD: no puede aprobar una solicitud propia ni una que usted pidió.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    v_de_presidencia := EXISTS (SELECT 1 FROM seguridad.usuario u JOIN gobernanza.v_cargos_en_ejercicio v ON v.id_persona = u.id_persona
                                 WHERE u.id_usuario = r.id_usuario AND v.codigo = 'PRES_NAL');
    IF NOT seguridad.fn_es_presidente_nacional() AND NOT v_de_presidencia THEN
        RAISE EXCEPTION 'SEGURIDAD: el Vicepresidente y el Secretario General Nacional solo aprueban las solicitudes de la propia Presidencia Nacional.'
            USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF NOT p_aprobar AND length(trim(COALESCE(p_observacion, ''))) < 5 THEN RAISE EXCEPTION 'Escriba el motivo del rechazo.'; END IF;
    UPDATE seguridad.usuario_rol SET estado = CASE WHEN p_aprobar THEN 'VIGENTE' ELSE 'RECHAZADO' END, decidido_por = v_yo,
           fecha_decision = now(), observacion_decision = NULLIF(trim(COALESCE(p_observacion, '')), '')
     WHERE id_usuario_rol = p_id_usuario_rol;
    IF p_aprobar AND r.codigo_rol = 'ADMIN' THEN
        UPDATE seguridad.usuario_rol SET estado = 'REVOCADO', decidido_por = v_yo, fecha_decision = now(),
               observacion_decision = 'Retirado al aprobar el rol de Administrador (incompatibilidad 2)'
         WHERE id_usuario = r.id_usuario AND id_usuario_rol <> p_id_usuario_rol AND estado IN ('VIGENTE', 'PENDIENTE')
           AND codigo_rol NOT IN ('ADMIN', 'AFILIADO');
        PERFORM seguridad.fn_aplicar_contexto(r.id_usuario, p_id_usuario_rol);
    END IF;
    IF p_aprobar THEN PERFORM seguridad.fn_exigir_compatible(r.id_usuario); END IF;
    RETURN CASE WHEN p_aprobar THEN 'VIGENTE' ELSE 'RECHAZADO' END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
