-- ============================================================================
-- SGSINDICAL v9.1 — 02g: CUENTAS INSTITUCIONALES EN REDES SOCIALES
-- Ejecutar DESPUÉS de 02f y ANTES de 03.
-- ----------------------------------------------------------------------------
--  S1. INVENTARIO: cada cuenta (Facebook, Instagram, X, TikTok, YouTube, WhatsApp…) pertenece a una
--      junta (Nacional, subdirectiva o comité): usuario, enlace, correo de acceso, datos de
--      recuperación (correo y teléfono, y si son institucionales), verificación en dos pasos,
--      administrador, estado, última publicación y métricas mensuales.
--  S2. CLAVES: se guardan CIFRADAS (AES-256-GCM) por el backend con una llave que NO está en la base
--      de datos. El texto cifrado vive en el esquema 'secretos', sin permisos para ningún rol de la
--      aplicación: solo se lee o escribe con las funciones de este script.
--  S3. QUIÉN VE LAS CLAVES: los directivos vigentes de la junta dueña de la cuenta y los directivos
--      vigentes de la Junta Nacional con acceso nacional. El administrador del sistema, sin cargo,
--      NO las ve. Cada consulta y cada cambio queda registrado (quién, cuándo, IP, motivo).
--  S4. HISTORIAL: las claves anteriores se conservan cifradas para recuperar una cuenta.
--  S5. ALERTAS: sin clave registrada; clave conocida por alguien que ya no es directivo de la junta
--      (hay que cambiarla); recuperación con datos personales; sin verificación en dos pasos;
--      roles de administración en manos de quien ya no es directivo; clave sin cambiar hace más de
--      180 días.
--  S6. PUBLICACIÓN: una cuenta activa no puede dejar de publicar más de 5 días (ajustable por cuenta).
--      Al superar el plazo se envía un correo al responsable de la cuenta y a la mesa de la junta, y se
--      repite cada 5 días mientras siga sin publicar.
-- ============================================================================
CREATE SCHEMA IF NOT EXISTS secretos;
REVOKE ALL ON SCHEMA secretos FROM PUBLIC;
COMMENT ON SCHEMA secretos IS 'Claves cifradas. Ningún rol de la aplicación tiene permisos: solo funciones SECURITY DEFINER.';

CREATE TABLE IF NOT EXISTS gobernanza.cuenta_red_social (
    id_cuenta_red BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    red VARCHAR(15) NOT NULL CHECK (red IN ('FACEBOOK', 'INSTAGRAM', 'X', 'TIKTOK', 'YOUTUBE', 'WHATSAPP',
                                           'TELEGRAM', 'LINKEDIN', 'THREADS', 'OTRA')),
    nombre_red_otra VARCHAR(60),
    usuario_cuenta VARCHAR(120) NOT NULL,
    url VARCHAR(300),
    correo_acceso VARCHAR(120),
    correo_recuperacion VARCHAR(120),
    telefono_recuperacion VARCHAR(30),
    titular_telefono VARCHAR(120),
    recuperacion_institucional BOOLEAN NOT NULL DEFAULT FALSE,
    tiene_2fa BOOLEAN NOT NULL DEFAULT FALSE,
    metodo_2fa VARCHAR(80),
    administrado_con_roles BOOLEAN NOT NULL DEFAULT FALSE,
    id_persona_administrador BIGINT REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    estado VARCHAR(16) NOT NULL DEFAULT 'ACTIVA' CHECK (estado IN ('ACTIVA', 'INACTIVA', 'SUSPENDIDA', 'EN_RECUPERACION', 'CERRADA')),
    fecha_apertura DATE,
    fecha_ultima_publicacion DATE,
    dias_max_sin_publicar INT NOT NULL DEFAULT 5 CHECK (dias_max_sin_publicar BETWEEN 1 AND 365),
    observaciones TEXT,
    fecha_cambio_clave TIMESTAMP WITH TIME ZONE,
    usuario_cambio_clave VARCHAR(50),
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_red_otra CHECK (red <> 'OTRA' OR nombre_red_otra IS NOT NULL),
    CONSTRAINT ck_red_2fa CHECK (tiene_2fa OR metodo_2fa IS NULL),
    CONSTRAINT ck_red_publicacion CHECK (fecha_ultima_publicacion IS NULL OR fecha_ultima_publicacion <= CURRENT_DATE)
);
COMMENT ON TABLE gobernanza.cuenta_red_social IS 'Cuentas institucionales del sindicato en redes sociales. La clave está cifrada en secretos.clave_red.';
COMMENT ON COLUMN gobernanza.cuenta_red_social.recuperacion_institucional IS
    'TRUE si el correo y el teléfono de recuperación son del sindicato (no personales de un directivo).';
COMMENT ON COLUMN gobernanza.cuenta_red_social.administrado_con_roles IS
    'TRUE si la cuenta se administra con roles por persona (Meta Business Suite, TikTok Business, YouTube) sin compartir la clave.';
CREATE UNIQUE INDEX IF NOT EXISTS ux_cuenta_red_usuario
    ON gobernanza.cuenta_red_social (red, lower(COALESCE(nombre_red_otra, '')), lower(usuario_cuenta));
CREATE INDEX IF NOT EXISTS ix_cuenta_red_estamento ON gobernanza.cuenta_red_social (id_estamento);
CREATE INDEX IF NOT EXISTS ix_cuenta_red_administrador ON gobernanza.cuenta_red_social (id_persona_administrador);

-- Personas con rol dentro de la red (administrador, editor…) — p. ej. en Meta Business Suite
CREATE TABLE IF NOT EXISTS gobernanza.cuenta_red_acceso (
    id_acceso BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_cuenta_red BIGINT NOT NULL REFERENCES gobernanza.cuenta_red_social(id_cuenta_red) ON DELETE CASCADE,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    rol VARCHAR(15) NOT NULL CHECK (rol IN ('ADMINISTRADOR', 'EDITOR', 'MODERADOR', 'ANUNCIANTE', 'ANALISTA')),
    fecha_asignacion DATE NOT NULL DEFAULT CURRENT_DATE,
    fecha_retiro DATE,
    observaciones TEXT,
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_red_acceso_fechas CHECK (fecha_retiro IS NULL OR fecha_retiro >= fecha_asignacion)
);
COMMENT ON TABLE gobernanza.cuenta_red_acceso IS 'Roles asignados dentro de la red social. Al retirarse la persona como directivo, se le debe quitar el rol.';
CREATE UNIQUE INDEX IF NOT EXISTS ux_red_acceso_vigente ON gobernanza.cuenta_red_acceso (id_cuenta_red, id_persona) WHERE fecha_retiro IS NULL;
CREATE INDEX IF NOT EXISTS ix_red_acceso_persona ON gobernanza.cuenta_red_acceso (id_persona);

CREATE TABLE IF NOT EXISTS gobernanza.cuenta_red_metrica (
    id_metrica BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_cuenta_red BIGINT NOT NULL REFERENCES gobernanza.cuenta_red_social(id_cuenta_red) ON DELETE CASCADE,
    anio INT NOT NULL CHECK (anio BETWEEN 2000 AND 2100),
    mes INT NOT NULL CHECK (mes BETWEEN 1 AND 12),
    seguidores INT NOT NULL CHECK (seguidores >= 0),
    publicaciones INT CHECK (publicaciones >= 0),
    alcance INT CHECK (alcance >= 0),
    interacciones INT CHECK (interacciones >= 0),
    observaciones TEXT,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    UNIQUE (id_cuenta_red, anio, mes)
);
COMMENT ON TABLE gobernanza.cuenta_red_metrica IS 'Seguidores, publicaciones, alcance e interacciones de cada cuenta por mes.';

-- Claves cifradas (vigente + historial). Formato: nonce (12 bytes) || texto cifrado AES-256-GCM.
CREATE TABLE IF NOT EXISTS secretos.clave_red (
    id_clave BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_cuenta_red BIGINT NOT NULL REFERENCES gobernanza.cuenta_red_social(id_cuenta_red) ON DELETE CASCADE,
    clave_cifrada BYTEA NOT NULL CHECK (octet_length(clave_cifrada) > 28),
    version_llave INT NOT NULL DEFAULT 1,
    vigente BOOLEAN NOT NULL DEFAULT TRUE,
    motivo VARCHAR(250),
    id_usuario BIGINT REFERENCES seguridad.usuario(id_usuario) ON DELETE SET NULL,
    id_persona BIGINT REFERENCES gobernanza.persona(id_persona) ON DELETE SET NULL,
    fecha TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_clave_red_vigente ON secretos.clave_red (id_cuenta_red) WHERE vigente;
CREATE INDEX IF NOT EXISTS ix_clave_red_cuenta ON secretos.clave_red (id_cuenta_red, fecha DESC);
REVOKE ALL ON ALL TABLES IN SCHEMA secretos FROM PUBLIC;

-- Registro inmutable de quién vio o cambió cada clave
CREATE TABLE IF NOT EXISTS gobernanza.cuenta_red_consulta (
    id_consulta BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_cuenta_red BIGINT NOT NULL REFERENCES gobernanza.cuenta_red_social(id_cuenta_red) ON DELETE CASCADE,
    id_clave BIGINT,
    accion VARCHAR(10) NOT NULL CHECK (accion IN ('VER', 'CAMBIAR')),
    es_clave_vigente BOOLEAN NOT NULL DEFAULT TRUE,
    id_usuario BIGINT NOT NULL REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    nombre_usuario VARCHAR(50) NOT NULL,
    id_persona BIGINT REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    ip VARCHAR(60),
    motivo VARCHAR(250),
    fecha TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);
COMMENT ON TABLE gobernanza.cuenta_red_consulta IS 'Registro inmutable de cada vez que alguien vio o cambió la clave de una cuenta de red social.';
CREATE INDEX IF NOT EXISTS ix_red_consulta_cuenta ON gobernanza.cuenta_red_consulta (id_cuenta_red, fecha DESC);
CREATE INDEX IF NOT EXISTS ix_red_consulta_persona ON gobernanza.cuenta_red_consulta (id_persona);
CREATE INDEX IF NOT EXISTS ix_red_consulta_usuario ON gobernanza.cuenta_red_consulta (id_usuario);

DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['gobernanza.cuenta_red_social', 'gobernanza.cuenta_red_acceso', 'gobernanza.cuenta_red_metrica'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_control_version ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_control_version BEFORE UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version()', t);
    END LOOP;
    FOREACH t IN ARRAY ARRAY['gobernanza.cuenta_red_social', 'gobernanza.cuenta_red_acceso', 'gobernanza.cuenta_red_metrica'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_auditoria ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria()', t);
    END LOOP;
END $$;

-- La fecha y el autor del último cambio de clave solo los fija el sistema
CREATE OR REPLACE FUNCTION gobernanza.fn_cuenta_red_proteger()
RETURNS TRIGGER AS $$
BEGIN
    IF COALESCE(current_setting('redes.operacion', true), '') = 'clave' THEN RETURN NEW; END IF;
    IF TG_OP = 'INSERT' THEN
        NEW.fecha_cambio_clave := NULL; NEW.usuario_cambio_clave := NULL;
    ELSIF NEW.fecha_cambio_clave IS DISTINCT FROM OLD.fecha_cambio_clave
       OR NEW.usuario_cambio_clave IS DISTINCT FROM OLD.usuario_cambio_clave THEN
        RAISE EXCEPTION 'La fecha del cambio de clave la registra el sistema al cambiarla.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_cuenta_red_proteger ON gobernanza.cuenta_red_social;
CREATE TRIGGER trg_cuenta_red_proteger BEFORE INSERT OR UPDATE ON gobernanza.cuenta_red_social
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_cuenta_red_proteger();

-- ----------------------------------------------------------------------------
-- 1. QUIÉN PUEDE CONOCER LA CLAVE
-- ----------------------------------------------------------------------------
-- Una persona puede conocer las claves de una junta si es directivo vigente de ella, o directivo
-- vigente de la Junta Nacional con acceso nacional (por su cargo o por su usuario).
CREATE OR REPLACE FUNCTION gobernanza.fn_persona_autorizada_red(p_id_persona BIGINT, p_id_estamento BIGINT)
RETURNS BOOLEAN AS $$
    SELECT p_id_persona IS NOT NULL AND (
        EXISTS (SELECT 1 FROM gobernanza.directivo_estamento d
                 WHERE d.id_persona = p_id_persona AND d.id_estamento = p_id_estamento
                   AND d.fecha_posesion_individual <= CURRENT_DATE
                   AND (d.fecha_retiro IS NULL OR d.fecha_retiro > CURRENT_DATE))
        OR EXISTS (SELECT 1 FROM gobernanza.directivo_estamento d
                     JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento AND e.tipo_estamento = 'JUNTA DIRECTIVA NACIONAL'
                     JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
                    WHERE d.id_persona = p_id_persona AND d.fecha_posesion_individual <= CURRENT_DATE
                      AND (d.fecha_retiro IS NULL OR d.fecha_retiro > CURRENT_DATE)
                      AND (c.acceso_nacional OR EXISTS (SELECT 1 FROM seguridad.usuario u
                                                         WHERE u.id_persona = p_id_persona AND u.activo AND u.ambito_nacional))));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_puede_ver_clave_red(p_id_cuenta_red BIGINT)
RETURNS BOOLEAN AS $$
    SELECT COALESCE((
        SELECT gobernanza.fn_persona_autorizada_red(u.id_persona, c.id_estamento)
          FROM seguridad.usuario u, gobernanza.cuenta_red_social c
         WHERE u.id_usuario = seguridad.fn_id_usuario_actual() AND u.activo AND c.id_cuenta_red = p_id_cuenta_red), FALSE);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_exigir_acceso_clave(p_id_cuenta_red BIGINT, OUT u seguridad.usuario)
AS $$
BEGIN
    SELECT * INTO u FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo;
    IF u.id_usuario IS NULL THEN RAISE EXCEPTION 'Usuario no identificado.'; END IF;
    IF NOT EXISTS (SELECT 1 FROM gobernanza.cuenta_red_social WHERE id_cuenta_red = p_id_cuenta_red) THEN
        RAISE EXCEPTION 'La cuenta no existe.';
    END IF;
    IF NOT gobernanza.fn_puede_ver_clave_red(p_id_cuenta_red) THEN
        RAISE EXCEPTION 'Fuera de su ámbito: solo los directivos vigentes de la junta dueña de la cuenta (y los directivos nacionales con acceso nacional) conocen sus claves.'
            USING ERRCODE = 'insufficient_privilege';
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 2. GUARDAR, LISTAR Y LEER CLAVES (todo queda registrado)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION gobernanza.fn_guardar_clave_red(p_id_cuenta_red BIGINT, p_clave_cifrada BYTEA,
                                                          p_motivo TEXT, p_version_llave INT DEFAULT 1)
RETURNS BIGINT AS $$
DECLARE v_u seguridad.usuario; v_id BIGINT;
BEGIN
    v_u := gobernanza.fn_exigir_acceso_clave(p_id_cuenta_red);
    PERFORM 1 FROM gobernanza.cuenta_red_social WHERE id_cuenta_red = p_id_cuenta_red FOR UPDATE;
    UPDATE secretos.clave_red SET vigente = FALSE WHERE id_cuenta_red = p_id_cuenta_red AND vigente;
    INSERT INTO secretos.clave_red (id_cuenta_red, clave_cifrada, version_llave, motivo, id_usuario, id_persona)
    VALUES (p_id_cuenta_red, p_clave_cifrada, p_version_llave, left(NULLIF(trim(p_motivo), ''), 250), v_u.id_usuario, v_u.id_persona)
    RETURNING id_clave INTO v_id;
    INSERT INTO gobernanza.cuenta_red_consulta (id_cuenta_red, id_clave, accion, id_usuario, nombre_usuario, id_persona, ip, motivo)
    VALUES (p_id_cuenta_red, v_id, 'CAMBIAR', v_u.id_usuario, v_u.nombre_usuario, v_u.id_persona,
            NULLIF(current_setting('app.ip', true), ''), left(NULLIF(trim(p_motivo), ''), 250));
    PERFORM set_config('redes.operacion', 'clave', true);
    UPDATE gobernanza.cuenta_red_social SET fecha_cambio_clave = now(), usuario_cambio_clave = v_u.nombre_usuario
     WHERE id_cuenta_red = p_id_cuenta_red;
    PERFORM set_config('redes.operacion', '', true);
    RETURN v_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Lista de claves (vigente e historial) SIN el texto cifrado
CREATE OR REPLACE FUNCTION gobernanza.fn_historial_claves_red(p_id_cuenta_red BIGINT)
RETURNS TABLE (id_clave BIGINT, vigente BOOLEAN, fecha TIMESTAMPTZ, cambiada_por TEXT, motivo TEXT) AS $$
BEGIN
    PERFORM gobernanza.fn_exigir_acceso_clave(p_id_cuenta_red);
    RETURN QUERY
        SELECT k.id_clave, k.vigente, k.fecha, COALESCE(u.nombre_usuario, '—')::TEXT, k.motivo::TEXT
          FROM secretos.clave_red k LEFT JOIN seguridad.usuario u ON u.id_usuario = k.id_usuario
         WHERE k.id_cuenta_red = p_id_cuenta_red ORDER BY k.fecha DESC, k.id_clave DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Entrega el texto cifrado (vigente o uno anterior) y registra la consulta en la misma transacción
CREATE OR REPLACE FUNCTION gobernanza.fn_leer_clave_red(p_id_cuenta_red BIGINT, p_id_clave BIGINT DEFAULT NULL, p_motivo TEXT DEFAULT NULL)
RETURNS TABLE (id_clave BIGINT, clave_cifrada BYTEA, version_llave INT, vigente BOOLEAN, fecha TIMESTAMPTZ) AS $$
DECLARE v_u seguridad.usuario; v_k secretos.clave_red;
BEGIN
    v_u := gobernanza.fn_exigir_acceso_clave(p_id_cuenta_red);
    SELECT * INTO v_k FROM secretos.clave_red k
     WHERE k.id_cuenta_red = p_id_cuenta_red AND (k.id_clave = p_id_clave OR (p_id_clave IS NULL AND k.vigente));
    IF v_k.id_clave IS NULL THEN
        RAISE EXCEPTION 'La cuenta no tiene clave registrada.';
    END IF;
    IF NOT v_k.vigente AND NULLIF(trim(p_motivo), '') IS NULL THEN
        RAISE EXCEPTION 'Para ver una clave anterior indique el motivo (p. ej. recuperación de la cuenta).';
    END IF;
    INSERT INTO gobernanza.cuenta_red_consulta (id_cuenta_red, id_clave, accion, es_clave_vigente, id_usuario, nombre_usuario, id_persona, ip, motivo)
    VALUES (p_id_cuenta_red, v_k.id_clave, 'VER', v_k.vigente, v_u.id_usuario, v_u.nombre_usuario, v_u.id_persona,
            NULLIF(current_setting('app.ip', true), ''), left(NULLIF(trim(p_motivo), ''), 250));
    RETURN QUERY SELECT v_k.id_clave, v_k.clave_cifrada, v_k.version_llave, v_k.vigente, v_k.fecha;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Para que el backend re-cifre todo al cambiar la llave maestra (solo ADMIN, sin registrar consulta)
CREATE OR REPLACE FUNCTION gobernanza.fn_claves_para_rotar()
RETURNS TABLE (id_clave BIGINT, id_cuenta_red BIGINT, clave_cifrada BYTEA, version_llave INT) AS $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo AND codigo_rol = 'ADMIN') THEN
        RAISE EXCEPTION 'Solo el administrador rota la llave de cifrado.';
    END IF;
    RETURN QUERY SELECT k.id_clave, k.id_cuenta_red, k.clave_cifrada, k.version_llave FROM secretos.clave_red k ORDER BY k.id_clave;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_reemplazar_cifrado(p_id_clave BIGINT, p_clave_cifrada BYTEA, p_version_llave INT)
RETURNS VOID AS $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo AND codigo_rol = 'ADMIN') THEN
        RAISE EXCEPTION 'Solo el administrador rota la llave de cifrado.';
    END IF;
    UPDATE secretos.clave_red SET clave_cifrada = p_clave_cifrada, version_llave = p_version_llave WHERE id_clave = p_id_clave;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 3. VISTA DE CONTROL
-- ----------------------------------------------------------------------------
DROP VIEW IF EXISTS gobernanza.v_auditoria_redes_sociales;
CREATE VIEW gobernanza.v_auditoria_redes_sociales WITH (security_invoker = true) AS
WITH base AS (
    SELECT c.*, e.nombre_estamento AS junta,
           c.fecha_cambio_clave AS fecha_clave,
           (SELECT string_agg(DISTINCT p.primer_nombre || ' ' || p.primer_apellido, ', ')
              FROM gobernanza.cuenta_red_consulta q JOIN gobernanza.persona p ON p.id_persona = q.id_persona
             WHERE q.id_cuenta_red = c.id_cuenta_red AND q.es_clave_vigente
               AND q.fecha >= COALESCE(c.fecha_cambio_clave, '-infinity')
               AND NOT gobernanza.fn_persona_autorizada_red(q.id_persona, c.id_estamento)) AS conocen_sin_ser_directivos,
           (SELECT string_agg(DISTINCT p.primer_nombre || ' ' || p.primer_apellido, ', ')
              FROM gobernanza.cuenta_red_acceso a JOIN gobernanza.persona p ON p.id_persona = a.id_persona
             WHERE a.id_cuenta_red = c.id_cuenta_red AND a.fecha_retiro IS NULL
               AND NOT gobernanza.fn_persona_autorizada_red(a.id_persona, c.id_estamento)) AS roles_sin_ser_directivos,
           (SELECT m.seguidores FROM gobernanza.cuenta_red_metrica m WHERE m.id_cuenta_red = c.id_cuenta_red
             ORDER BY m.anio DESC, m.mes DESC LIMIT 1) AS seguidores,
           (SELECT count(*) FROM gobernanza.cuenta_red_consulta q
             WHERE q.id_cuenta_red = c.id_cuenta_red AND q.accion = 'VER' AND q.fecha > now() - INTERVAL '30 days')::INT AS consultas_clave_30_dias
      FROM gobernanza.cuenta_red_social c
      JOIN gobernanza.estamento e ON e.id_estamento = c.id_estamento
)
SELECT id_cuenta_red, id_estamento, junta,
       CASE WHEN red = 'OTRA' THEN nombre_red_otra ELSE red END AS red,
       usuario_cuenta, estado, tiene_2fa, recuperacion_institucional, administrado_con_roles,
       fecha_cambio_clave::DATE AS clave_cambiada, (CURRENT_DATE - fecha_cambio_clave::DATE) AS dias_clave,
       fecha_ultima_publicacion, (CURRENT_DATE - fecha_ultima_publicacion) AS dias_sin_publicar, dias_max_sin_publicar,
       (estado = 'ACTIVA' AND (fecha_ultima_publicacion IS NULL OR CURRENT_DATE - fecha_ultima_publicacion > dias_max_sin_publicar)) AS sin_publicar,
       seguidores, consultas_clave_30_dias, conocen_sin_ser_directivos, roles_sin_ser_directivos,
       CASE
           WHEN estado = 'CERRADA' THEN 'CUENTA CERRADA'
           WHEN estado IN ('SUSPENDIDA', 'EN_RECUPERACION') THEN 'ALERTA CRÍTICA: CUENTA ' || replace(estado, '_', ' ')
           WHEN fecha_clave IS NULL AND NOT administrado_con_roles THEN 'ALERTA CRÍTICA: EL SINDICATO NO TIENE REGISTRADA LA CLAVE'
           WHEN conocen_sin_ser_directivos IS NOT NULL
               THEN 'ALERTA ALTA: CAMBIAR LA CLAVE — LA CONOCE QUIEN YA NO ES DIRECTIVO (' || conocen_sin_ser_directivos || ')'
           WHEN roles_sin_ser_directivos IS NOT NULL
               THEN 'ALERTA ALTA: QUITAR EL ROL EN LA RED A QUIEN YA NO ES DIRECTIVO (' || roles_sin_ser_directivos || ')'
           WHEN estado = 'ACTIVA' AND fecha_ultima_publicacion IS NULL
               THEN 'ALERTA ALTA: NO HAY REGISTRO DE PUBLICACIONES'
           WHEN estado = 'ACTIVA' AND CURRENT_DATE - fecha_ultima_publicacion > dias_max_sin_publicar
               THEN 'ALERTA ALTA: SIN PUBLICAR HACE ' || (CURRENT_DATE - fecha_ultima_publicacion) || ' DÍAS (MÁXIMO ' || dias_max_sin_publicar || ')'
           WHEN NOT recuperacion_institucional THEN 'ALERTA ALTA: CORREO O TELÉFONO DE RECUPERACIÓN PERSONAL (NO INSTITUCIONAL)'
           WHEN NOT tiene_2fa THEN 'ALERTA ALTA: SIN VERIFICACIÓN EN DOS PASOS'
           WHEN fecha_cambio_clave < now() - INTERVAL '180 days' THEN 'ALERTA MEDIA: CLAVE SIN CAMBIAR HACE MÁS DE 180 DÍAS'
           ELSE 'CUENTA AL DÍA'
       END AS diagnostico
FROM base;

-- ----------------------------------------------------------------------------
-- 4. SEGURIDAD POR FILAS
-- ----------------------------------------------------------------------------
SELECT seguridad.fn_aplicar_politicas('gobernanza.cuenta_red_social', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('gobernanza.cuenta_red_acceso',
    'EXISTS (SELECT 1 FROM gobernanza.cuenta_red_social c WHERE c.id_cuenta_red = cuenta_red_acceso.id_cuenta_red)',
    'EXISTS (SELECT 1 FROM gobernanza.cuenta_red_social c WHERE c.id_cuenta_red = cuenta_red_acceso.id_cuenta_red)');
SELECT seguridad.fn_aplicar_politicas('gobernanza.cuenta_red_metrica',
    'EXISTS (SELECT 1 FROM gobernanza.cuenta_red_social c WHERE c.id_cuenta_red = cuenta_red_metrica.id_cuenta_red)',
    'EXISTS (SELECT 1 FROM gobernanza.cuenta_red_social c WHERE c.id_cuenta_red = cuenta_red_metrica.id_cuenta_red)');
-- El registro de consultas se ve en el ámbito y nunca se modifica (solo lo escriben las funciones)
SELECT seguridad.fn_aplicar_politicas('gobernanza.cuenta_red_consulta',
    'EXISTS (SELECT 1 FROM gobernanza.cuenta_red_social c WHERE c.id_cuenta_red = cuenta_red_consulta.id_cuenta_red)', 'false');

-- ----------------------------------------------------------------------------
-- 5. CORREO SEMANAL DE ALERTAS DE REDES
-- ----------------------------------------------------------------------------
INSERT INTO notificaciones.tipo_notificacion (codigo, nombre, descripcion) VALUES
    ('REDES_SOCIALES', 'Seguridad de las cuentas en redes sociales',
     'Cada semana al Presidente y al Secretario General de cada junta, con sus cuentas en alerta crítica o alta: '
     'sin clave registrada, clave conocida por quien ya no es directivo, roles sin retirar, recuperación personal o sin 2FA.')
ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, descripcion = EXCLUDED.descripcion;

INSERT INTO notificaciones.tipo_notificacion (codigo, nombre, descripcion) VALUES
    ('PUBLICACION_REDES', 'Redes sociales sin publicar',
     'Al responsable de la cuenta, con copia al Presidente y al Secretario General de la junta, cuando una cuenta activa '
     'lleva más de 5 días (o el máximo fijado para esa cuenta) sin publicar. Se repite cada 5 días mientras siga sin publicar.')
ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, descripcion = EXCLUDED.descripcion;
