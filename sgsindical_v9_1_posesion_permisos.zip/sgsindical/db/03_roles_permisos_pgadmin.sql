-- ============================================================================
-- SGSINDICAL v9.1 — 03: ROLES Y PERMISOS — VERSIÓN PARA pgADMIN (Query Tool)
-- Igual a 03_roles_permisos.sql, pero sin comandos de psql.
-- ANTES DE EJECUTAR: reemplace las cuatro contraseñas de la sección 1 (busque CAMBIAR_).
-- Ejecútelo conectado a la base sgsindical, con un usuario superusuario (postgres).
-- ============================================================================
-- 1. ROLES (cambie las contraseñas)
DO $$
DECLARE
    v_app   TEXT := 'CAMBIAR_clave_sgs_app';
    v_lec   TEXT := 'CAMBIAR_clave_sgs_lectura';
    v_bak   TEXT := 'CAMBIAR_clave_sgs_backup';
    v_not   TEXT := 'CAMBIAR_clave_sgs_notificador';
    r TEXT;
BEGIN
    FOREACH r IN ARRAY ARRAY['sgs_app', 'sgs_lectura', 'sgs_backup', 'sgs_notificador'] LOOP
        IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
            EXECUTE format('CREATE ROLE %I LOGIN', r);
        END IF;
    END LOOP;
    EXECUTE format('ALTER ROLE sgs_app PASSWORD %L NOSUPERUSER NOCREATEDB NOCREATEROLE CONNECTION LIMIT 50', v_app);
    EXECUTE format('ALTER ROLE sgs_lectura PASSWORD %L NOSUPERUSER NOCREATEDB NOCREATEROLE CONNECTION LIMIT 10', v_lec);
    EXECUTE format('ALTER ROLE sgs_backup PASSWORD %L NOSUPERUSER NOCREATEDB NOCREATEROLE CONNECTION LIMIT 2', v_bak);
    EXECUTE format('ALTER ROLE sgs_notificador PASSWORD %L NOSUPERUSER NOCREATEDB NOCREATEROLE CONNECTION LIMIT 2', v_not);
    EXECUTE format('GRANT CONNECT ON DATABASE %I TO sgs_app, sgs_lectura, sgs_backup, sgs_notificador', current_database());
    EXECUTE format('REVOKE CONNECT ON DATABASE %I FROM PUBLIC', current_database());
END $$;



-- Tiempo máximo de sentencia y de transacción inactiva para la app (evita bloqueos colgados).
ALTER ROLE sgs_app SET statement_timeout = '30s';
ALTER ROLE sgs_app SET idle_in_transaction_session_timeout = '60s';
ALTER ROLE sgs_app SET lock_timeout = '10s';

-- Nadie crea objetos en public.
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA auditoria, gobernanza, gestion_documental, finanzas FROM PUBLIC;

-- Conexión a la base

-- ---------------------------------------------------------------- sgs_app
GRANT USAGE ON SCHEMA gobernanza, finanzas, gestion_documental, auditoria, seguridad TO sgs_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA gobernanza, finanzas, gestion_documental TO sgs_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON seguridad.usuario, seguridad.permiso_rol, seguridad.rol_app, seguridad.sesion,
    seguridad.usuario_ambito TO sgs_app;
-- Historiales: solo se agregan filas, nunca se editan ni se borran desde la app.
REVOKE UPDATE, DELETE ON gestion_documental.historial_tramite, gestion_documental.historial_avance_compromiso FROM sgs_app;
-- Auditoría: lectura y registro de accesos/backups; la bitácora de cambios solo la escriben los triggers.
GRANT SELECT ON ALL TABLES IN SCHEMA auditoria TO sgs_app;
GRANT INSERT ON auditoria.registro_acceso, auditoria.registro_backup TO sgs_app;
REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON auditoria.bitacora_cambios FROM sgs_app;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA gobernanza, finanzas, gestion_documental, auditoria, seguridad TO sgs_app;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA gobernanza, finanzas, gestion_documental, auditoria TO sgs_app;

-- ---------------------------------------------------------------- sgs_lectura
GRANT USAGE ON SCHEMA gobernanza, finanzas, gestion_documental, auditoria TO sgs_lectura;
GRANT SELECT ON ALL TABLES IN SCHEMA gobernanza, finanzas, gestion_documental, auditoria TO sgs_lectura;
GRANT EXECUTE ON FUNCTION auditoria.fn_usuario_actual() TO sgs_lectura;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA gobernanza, gestion_documental, finanzas TO sgs_lectura;
-- Reportes nacionales: sgs_lectura no queda sujeto al filtro territorial (solo puede leer).
ALTER ROLE sgs_lectura BYPASSRLS;

-- ---------------------------------------------------------------- sgs_backup
GRANT pg_read_all_data TO sgs_backup;   -- PostgreSQL 14+
-- persona tiene seguridad por filas (RLS); sin esto pg_dump falla en esa tabla.
ALTER ROLE sgs_backup BYPASSRLS;

-- Privilegios por defecto para objetos que se creen en el futuro.
ALTER DEFAULT PRIVILEGES IN SCHEMA gobernanza, finanzas, gestion_documental
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO sgs_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA gobernanza, finanzas, gestion_documental, auditoria
    GRANT SELECT ON TABLES TO sgs_lectura;
ALTER DEFAULT PRIVILEGES IN SCHEMA gobernanza, finanzas, gestion_documental, auditoria, seguridad
    GRANT USAGE ON SEQUENCES TO sgs_app;

-- ---------------------------------------------------------------- correos automáticos
GRANT USAGE ON SCHEMA notificaciones TO sgs_app;
GRANT SELECT, UPDATE ON notificaciones.tipo_notificacion TO sgs_app;
GRANT SELECT ON notificaciones.tipo_notificacion TO sgs_lectura;
GRANT USAGE ON SCHEMA notificaciones TO sgs_lectura;
GRANT SELECT ON notificaciones.registro_envio TO sgs_app;

GRANT USAGE ON SCHEMA gobernanza, gestion_documental, notificaciones, auditoria TO sgs_notificador;
GRANT SELECT ON ALL TABLES IN SCHEMA gobernanza, gestion_documental TO sgs_notificador;
GRANT SELECT ON notificaciones.tipo_notificacion TO sgs_notificador;
GRANT SELECT, INSERT, UPDATE ON notificaciones.registro_envio TO sgs_notificador;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA notificaciones TO sgs_notificador;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA gobernanza, gestion_documental, notificaciones TO sgs_notificador;
GRANT EXECUTE ON FUNCTION auditoria.fn_usuario_actual() TO sgs_notificador;
GRANT USAGE ON SCHEMA finanzas TO sgs_notificador;
GRANT SELECT ON ALL TABLES IN SCHEMA finanzas TO sgs_notificador;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA finanzas TO sgs_notificador;
-- Las alertas se calculan para todo el país (la tarea no actúa como ningún usuario)
ALTER ROLE sgs_notificador BYPASSRLS;
ALTER ROLE sgs_notificador SET statement_timeout = '120s';

-- ---------------------------------------------------------------- claves de redes sociales
-- El texto cifrado solo se alcanza con las funciones de 02g (que verifican quién pide y lo registran).
REVOKE ALL ON SCHEMA secretos FROM sgs_app, sgs_lectura, sgs_notificador;
REVOKE ALL ON ALL TABLES IN SCHEMA secretos FROM sgs_app, sgs_lectura, sgs_notificador;
-- El registro de consultas de claves es inmutable: solo lo escriben las funciones
REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON gobernanza.cuenta_red_consulta FROM sgs_app;
-- Los roles de reportes y de correos no leen ni cambian claves
REVOKE EXECUTE ON FUNCTION gobernanza.fn_guardar_clave_red(BIGINT, BYTEA, TEXT, INT), gobernanza.fn_leer_clave_red(BIGINT, BIGINT, TEXT),
    gobernanza.fn_historial_claves_red(BIGINT), gobernanza.fn_claves_para_rotar(), gobernanza.fn_reemplazar_cifrado(BIGINT, BYTEA, INT)
    FROM sgs_lectura, sgs_notificador;

-- ---------------------------------------------------------------- escritos jurídicos
-- Los roles de reportes y de correos no modifican escritos
REVOKE EXECUTE ON FUNCTION gestion_documental.fn_guardar_version_escrito(BIGINT, INT, TEXT, TEXT, TEXT, TEXT, TEXT),
    gestion_documental.fn_marcar_generacion(BIGINT, BOOLEAN, TEXT), gestion_documental.fn_revisar_escrito(BIGINT, INT, TEXT, TEXT),
    gestion_documental.fn_radicar_escrito(BIGINT), gestion_documental.fn_descartar_escrito(BIGINT, TEXT),
    gestion_documental.fn_registrar_extraccion(BIGINT, TEXT, TEXT, TEXT, INT)
    FROM sgs_lectura, sgs_notificador;
-- El proceso de correos avisa a los abogados: solo lee nombre, correo, rol y ámbito (nunca la contraseña)
GRANT USAGE ON SCHEMA seguridad TO sgs_notificador;
GRANT SELECT (id_usuario, nombre_completo, correo_electronico, activo, codigo_rol, ambito_nacional) ON seguridad.usuario TO sgs_notificador;
GRANT SELECT ON seguridad.usuario_ambito TO sgs_notificador;
-- Contenidos de redes: los roles de reportes y de correos no los modifican
REVOKE EXECUTE ON FUNCTION gobernanza.fn_guardar_version_pieza(BIGINT, INT, TEXT, TEXT, TEXT, TEXT, TEXT),
    gobernanza.fn_marcar_generacion_contenido(TEXT, BIGINT, BOOLEAN, TEXT), gobernanza.fn_guardar_politica_ia(BIGINT, TEXT, TEXT),
    gobernanza.fn_revisar_pieza(BIGINT, INT, TEXT, TEXT), gobernanza.fn_descartar_pieza(BIGINT, TEXT), gobernanza.fn_aprobar_politica(BIGINT, BIGINT)
    FROM sgs_lectura, sgs_notificador;
