@echo off
REM Instala la base SGSINDICAL en Windows. Uso: instalar.bat [nombre_bd] [--demo]
REM Ejecutar desde "SQL Shell" o con la carpeta bin de PostgreSQL en el PATH. Pide la clave del usuario postgres.
cd /d %~dp0
set BD=%1
if "%BD%"=="" set BD=sgsindical
set /p APP=Contrasena para sgs_app (backend): 
set /p LEC=Contrasena para sgs_lectura (reportes): 
set /p BAK=Contrasena para sgs_backup (copias): 
set /p NOTI=Contrasena para sgs_notificador (correos): 
createdb -U postgres %BD%
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 01_sgsindical_v9_1_estructura.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 02_seguridad_auditoria_indices.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 02b_reglas_directivos.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 02c_acceso_territorial.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 02d_notificaciones.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 02e_finanzas.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 02f_reuniones_actas.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 02g_redes_sociales.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 02h_escritos_juridicos.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 02i_contenidos_redes.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -v app_pass="%APP%" -v lectura_pass="%LEC%" -v backup_pass="%BAK%" -v notif_pass="%NOTI%" -f 03_roles_permisos.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 05_inactivacion.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 06_datos_personales.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 07_porcentaje_aporte.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 08_ventanilla_autoservicio.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 09_mfa.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 10_pqrsd.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 11_endurecimiento.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 12_roles_suplencias.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 13_plazos_ley.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 14_niveles_jefes.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 15_documentos_legales.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 16_expediente_afiliacion.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 17_lugares_traslados.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 17b_divipola_municipios.sql || goto :error
psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 18_posesion_permisos.sql || goto :error
if "%2"=="--demo" psql -U postgres -v ON_ERROR_STOP=1 -q -d %BD% -f 04_datos_demo.sql
echo Base %BD% instalada. Cree el administrador con: python -m app.cli crear-admin
goto :eof
:error
echo ERROR en la instalacion.
exit /b 1
