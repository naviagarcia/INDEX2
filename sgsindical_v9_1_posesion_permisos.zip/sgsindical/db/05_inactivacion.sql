-- ============================================================================
-- SGSINDICAL v9.1 — 05: NADA SE BORRA (regla R-01 del Documento Maestro)
-- Ejecutar DESPUÉS de 03 (roles y permisos). Si se cargan datos de demostración (04), puede ir
-- antes o después de 04. No modifica los scripts anteriores: los complementa.
-- ----------------------------------------------------------------------------
--  I1. MAESTROS (personas, afiliados, empresas, sedes, jefes, estamentos, comités, inspectores,
--      cuentas bancarias, cuentas de redes, tipos documentales, roles, ámbitos de usuario):
--      se INACTIVAN y se REACTIVAN, con motivo, fecha y usuario. Inactivar un afiliado equivale a
--      desafiliarlo: el mes del retiro se cobra; desde el mes siguiente ya no se espera su aporte.
--  I2. REGLAS AL INACTIVAR: no se inactiva una persona con cargo vigente o afiliación activa, una
--      empresa con afiliados activos, una cuenta con saldo, una junta con afiliados o directivos…
--      Inactivar una empresa inactiva en cadena sus sedes, jefes y comités.
--  I3. Un registro inactivo no se modifica (primero se reactiva) y no se le pueden asociar
--      registros nuevos (un afiliado nuevo de una persona inactiva, una consignación a una cuenta
--      inactiva…). Reactivar exige que los registros de los que depende estén activos.
--  I4. MOVIMIENTOS FINANCIEROS (consignaciones, aportes, otros ingresos, transferencias,
--      presupuestos, conciliaciones): se ANULAN con motivo y quedan en el historial, fuera de
--      saldos, totales y mora. Anular una consignación anula sus aportes. La anulación es
--      definitiva, no se puede hacer en un mes cerrado y la hacen el Tesorero o el Presidente de la
--      junta (en comités, el Secretario General o el Presidente), igual que con los egresos.
--  I5. DOCUMENTOS: ya tienen su propio estado (documento ANULADO, compromiso CANCELADO, expediente
--      CERRADO/ARCHIVADO): se usan esos estados, no el borrado.
--  I6. DOBLE CANDADO: un trigger rechaza cualquier DELETE (incluso desde pgAdmin) y la cuenta de la
--      aplicación (sgs_app) pierde el permiso de borrar. Solo se pueden quitar detalles de trabajo
--      en curso: asistentes, puntos y decisiones de una reunión cuya acta no está firmada, y
--      fuentes de un escrito en borrador (sus propios triggers ya lo controlan).
--  I7. Las llaves foráneas ON DELETE CASCADE hacia tablas protegidas pasan a ON DELETE RESTRICT.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. CATÁLOGO DE TABLAS QUE SE INACTIVAN Y COLUMNAS DE INACTIVACIÓN
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS seguridad.tabla_inactivable (
    tabla TEXT PRIMARY KEY,
    nombre VARCHAR(60) NOT NULL,
    exige_motivo BOOLEAN NOT NULL DEFAULT TRUE
);
COMMENT ON TABLE seguridad.tabla_inactivable IS 'Tablas maestras que no se borran sino que se inactivan (R-01).';

INSERT INTO seguridad.tabla_inactivable (tabla, nombre, exige_motivo) VALUES
    ('gobernanza.persona', 'la persona', TRUE),
    ('gobernanza.afiliado', 'el afiliado', TRUE),
    ('gobernanza.inspector', 'el inspector', TRUE),
    ('gobernanza.empresa', 'la empresa', TRUE),
    ('gobernanza.sede_empresa', 'la sede', TRUE),
    ('gobernanza.jefe_empresa', 'el jefe', TRUE),
    ('gobernanza.estamento', 'la junta', TRUE),
    ('gobernanza.comite', 'el comité', TRUE),
    ('gobernanza.comite_miembro', 'el miembro del comité', TRUE),
    ('gobernanza.registro_inspector_estamento', 'el registro del inspector', TRUE),
    ('gestion_documental.tipo_documento', 'el tipo documental', TRUE),
    ('finanzas.cuenta_bancaria', 'la cuenta bancaria', TRUE),
    ('gobernanza.cuenta_red_social', 'la cuenta de red social', TRUE),
    ('seguridad.usuario_ambito', 'el ámbito del usuario', TRUE),
    ('seguridad.rol_app', 'el rol', TRUE),
    ('seguridad.usuario', 'el usuario', FALSE)
ON CONFLICT (tabla) DO UPDATE SET nombre = EXCLUDED.nombre, exige_motivo = EXCLUDED.exige_motivo;

DO $$
DECLARE t TEXT;
BEGIN
    FOR t IN SELECT tabla FROM seguridad.tabla_inactivable LOOP
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS activo BOOLEAN NOT NULL DEFAULT TRUE', t);
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS fecha_inactivacion TIMESTAMP WITH TIME ZONE', t);
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS usuario_inactivacion VARCHAR(50)', t);
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS motivo_inactivacion TEXT', t);
        EXECUTE format('COMMENT ON COLUMN %s.activo IS %L', t, 'FALSE = inactivo: se conserva en el historial y no se borra (R-01).');
    END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- 2. DEPENDENCIAS: a un registro inactivo no se le asocian registros nuevos
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS seguridad.referencia_activa (
    tabla TEXT NOT NULL,
    columna TEXT NOT NULL,
    tabla_padre TEXT NOT NULL,
    columna_padre TEXT NOT NULL,
    PRIMARY KEY (tabla, columna)
);
COMMENT ON TABLE seguridad.referencia_activa IS 'Columnas que deben apuntar a un registro activo al crear, cambiar o reactivar.';

INSERT INTO seguridad.referencia_activa (tabla, columna, tabla_padre, columna_padre) VALUES
    ('gobernanza.afiliado', 'id_persona', 'gobernanza.persona', 'id_persona'),
    ('gobernanza.afiliado', 'id_estamento_pertenencia', 'gobernanza.estamento', 'id_estamento'),
    ('gobernanza.afiliado_empresa', 'id_empresa', 'gobernanza.empresa', 'id_empresa'),
    ('gobernanza.afiliado_empresa', 'id_sede', 'gobernanza.sede_empresa', 'id_sede'),
    ('gobernanza.afiliado_empresa', 'id_jefe_directo', 'gobernanza.jefe_empresa', 'id_jefe'),
    ('gobernanza.jefe_empresa', 'id_persona', 'gobernanza.persona', 'id_persona'),
    ('gobernanza.jefe_empresa', 'id_empresa', 'gobernanza.empresa', 'id_empresa'),
    ('gobernanza.sede_empresa', 'id_empresa', 'gobernanza.empresa', 'id_empresa'),
    ('gobernanza.comite', 'id_empresa', 'gobernanza.empresa', 'id_empresa'),
    ('gobernanza.comite_miembro', 'id_comite', 'gobernanza.comite', 'id_comite'),
    ('gobernanza.comite_miembro', 'id_persona', 'gobernanza.persona', 'id_persona'),
    ('gobernanza.directivo_estamento', 'id_persona', 'gobernanza.persona', 'id_persona'),
    ('gobernanza.directivo_estamento', 'id_estamento', 'gobernanza.estamento', 'id_estamento'),
    ('gobernanza.directivo_estamento', 'id_registro_inspector', 'gobernanza.registro_inspector_estamento', 'id_registro'),
    ('gobernanza.registro_inspector_estamento', 'id_inspector', 'gobernanza.inspector', 'id_inspector'),
    ('gobernanza.registro_inspector_estamento', 'id_estamento', 'gobernanza.estamento', 'id_estamento'),
    ('gobernanza.cuenta_red_social', 'id_estamento', 'gobernanza.estamento', 'id_estamento'),
    ('gobernanza.cuenta_red_acceso', 'id_persona', 'gobernanza.persona', 'id_persona'),
    ('gobernanza.cuenta_red_acceso', 'id_cuenta_red', 'gobernanza.cuenta_red_social', 'id_cuenta_red'),
    ('finanzas.cuenta_bancaria', 'id_estamento', 'gobernanza.estamento', 'id_estamento'),
    ('finanzas.cuenta_bancaria', 'id_cuenta_padre', 'finanzas.cuenta_bancaria', 'id_cuenta'),
    ('finanzas.consignacion_empresa', 'id_cuenta_destino', 'finanzas.cuenta_bancaria', 'id_cuenta'),
    ('finanzas.ingreso', 'id_cuenta', 'finanzas.cuenta_bancaria', 'id_cuenta'),
    ('finanzas.egreso', 'id_cuenta', 'finanzas.cuenta_bancaria', 'id_cuenta'),
    ('finanzas.transferencia', 'id_cuenta_origen', 'finanzas.cuenta_bancaria', 'id_cuenta'),
    ('finanzas.transferencia', 'id_cuenta_destino', 'finanzas.cuenta_bancaria', 'id_cuenta'),
    ('gestion_documental.documento', 'id_tipo_documento', 'gestion_documental.tipo_documento', 'id_tipo_documento'),
    ('seguridad.usuario_ambito', 'id_estamento', 'gobernanza.estamento', 'id_estamento'),
    ('seguridad.usuario_ambito', 'id_usuario', 'seguridad.usuario', 'id_usuario'),
    ('seguridad.usuario', 'id_persona', 'gobernanza.persona', 'id_persona')
ON CONFLICT (tabla, columna) DO UPDATE SET tabla_padre = EXCLUDED.tabla_padre, columna_padre = EXCLUDED.columna_padre;

-- p_viejo NULL = revisar todas las columnas (al reactivar); si no, solo las que cambiaron
CREATE OR REPLACE FUNCTION seguridad.fn_verificar_padres_activos(p_tabla TEXT, p_nuevo JSONB, p_viejo JSONB)
RETURNS VOID AS $$
DECLARE r RECORD; v_valor TEXT; v_activo BOOLEAN;
BEGIN
    FOR r IN SELECT ra.*, ti.nombre FROM seguridad.referencia_activa ra
               JOIN seguridad.tabla_inactivable ti ON ti.tabla = ra.tabla_padre
              WHERE ra.tabla = p_tabla LOOP
        v_valor := p_nuevo ->> r.columna;
        CONTINUE WHEN v_valor IS NULL;
        CONTINUE WHEN p_viejo IS NOT NULL AND v_valor IS NOT DISTINCT FROM (p_viejo ->> r.columna);
        EXECUTE format('SELECT activo FROM %s WHERE %I::text = $1', r.tabla_padre, r.columna_padre) INTO v_activo USING v_valor;
        IF v_activo IS FALSE THEN
            RAISE EXCEPTION '% (%) está inactivo(a): reactívelo(a) primero o elija otro registro.',
                upper(left(r.nombre, 1)) || substr(r.nombre, 2), r.columna;
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_exigir_padres_activos()
RETURNS TRIGGER AS $$
BEGIN
    IF COALESCE(current_setting('sgs.operacion', true), '') = 'sistema' THEN RETURN NEW; END IF;
    PERFORM seguridad.fn_verificar_padres_activos(TG_TABLE_SCHEMA || '.' || TG_TABLE_NAME, to_jsonb(NEW),
                                                  CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) END);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DO $$
DECLARE t TEXT;
BEGIN
    FOR t IN SELECT DISTINCT tabla FROM seguridad.referencia_activa LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_padres_activos ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_padres_activos BEFORE INSERT OR UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION seguridad.fn_exigir_padres_activos()', t);
    END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- 3. REGLAS DE NEGOCIO AL INACTIVAR
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION seguridad.fn_reglas_inactivar(p_tabla TEXT, r JSONB, p_motivo TEXT)
RETURNS VOID AS $$
DECLARE n INT; v_saldo NUMERIC; v_cascada TEXT := left(p_motivo, 400);
BEGIN
    IF p_tabla = 'gobernanza.persona' THEN
        IF EXISTS (SELECT 1 FROM gobernanza.afiliado WHERE id_persona = (r->>'id_persona')::BIGINT AND activo) THEN
            RAISE EXCEPTION 'La persona es afiliada activa: primero desafíliela (inactive su registro de afiliado).';
        END IF;
        IF EXISTS (SELECT 1 FROM gobernanza.directivo_estamento WHERE id_persona = (r->>'id_persona')::BIGINT AND fecha_retiro IS NULL) THEN
            RAISE EXCEPTION 'La persona tiene un cargo directivo vigente: registre primero su retiro del cargo.';
        END IF;
        IF EXISTS (SELECT 1 FROM gobernanza.jefe_empresa WHERE id_persona = (r->>'id_persona')::BIGINT AND activo) THEN
            RAISE EXCEPTION 'La persona figura como jefe activo en una empresa: inactive primero ese registro.';
        END IF;
        IF EXISTS (SELECT 1 FROM gobernanza.comite_miembro WHERE id_persona = (r->>'id_persona')::BIGINT AND activo) THEN
            RAISE EXCEPTION 'La persona es miembro activo de un comité: inactive primero esa membresía.';
        END IF;
        IF EXISTS (SELECT 1 FROM seguridad.usuario WHERE id_persona = (r->>'id_persona')::BIGINT AND activo) THEN
            RAISE EXCEPTION 'La persona tiene un usuario activo en el sistema: desactívelo primero.';
        END IF;
        IF EXISTS (SELECT 1 FROM gobernanza.cuenta_red_acceso WHERE id_persona = (r->>'id_persona')::BIGINT AND fecha_retiro IS NULL) THEN
            RAISE EXCEPTION 'La persona tiene acceso vigente a una cuenta de red social: registre primero su retiro.';
        END IF;

    ELSIF p_tabla = 'gobernanza.afiliado' THEN
        IF EXISTS (SELECT 1 FROM gobernanza.directivo_estamento WHERE id_persona = (r->>'id_persona')::BIGINT AND fecha_retiro IS NULL) THEN
            RAISE EXCEPTION 'El afiliado tiene un cargo directivo vigente: registre primero su retiro del cargo.';
        END IF;

    ELSIF p_tabla = 'gobernanza.empresa' THEN
        SELECT count(*) INTO n FROM gobernanza.afiliado_empresa ae JOIN gobernanza.afiliado a ON a.id_persona = ae.id_persona
         WHERE ae.id_empresa = (r->>'id_empresa')::BIGINT AND a.activo;
        IF n > 0 THEN
            RAISE EXCEPTION 'La empresa tiene % afiliado(s) activo(s): desafílielos o trasládelos antes de inactivarla.', n;
        END IF;
        -- En cadena: sedes, jefes y comités de la empresa
        UPDATE gobernanza.comite SET activo = FALSE, motivo_inactivacion = 'Empresa inactivada: ' || v_cascada
         WHERE id_empresa = (r->>'id_empresa')::BIGINT AND activo;
        UPDATE gobernanza.jefe_empresa SET activo = FALSE, motivo_inactivacion = 'Empresa inactivada: ' || v_cascada
         WHERE id_empresa = (r->>'id_empresa')::BIGINT AND activo;
        UPDATE gobernanza.sede_empresa SET activo = FALSE, motivo_inactivacion = 'Empresa inactivada: ' || v_cascada
         WHERE id_empresa = (r->>'id_empresa')::BIGINT AND activo;

    ELSIF p_tabla = 'gobernanza.sede_empresa' THEN
        SELECT count(*) INTO n FROM gobernanza.afiliado_empresa ae JOIN gobernanza.afiliado a ON a.id_persona = ae.id_persona
         WHERE ae.id_sede = (r->>'id_sede')::BIGINT AND a.activo;
        IF n > 0 THEN
            RAISE EXCEPTION 'La sede tiene % afiliado(s) activo(s): cámbielos de sede antes de inactivarla.', n;
        END IF;

    ELSIF p_tabla = 'gobernanza.jefe_empresa' THEN
        SELECT count(*) INTO n FROM gobernanza.afiliado_empresa ae JOIN gobernanza.afiliado a ON a.id_persona = ae.id_persona
         WHERE ae.id_jefe_directo = (r->>'id_jefe')::BIGINT AND a.activo;
        IF n > 0 THEN
            RAISE EXCEPTION 'El jefe es jefe directo de % afiliado(s) activo(s): asígneles otro jefe antes de inactivarlo.', n;
        END IF;

    ELSIF p_tabla = 'gobernanza.estamento' THEN
        IF r->>'tipo_estamento' = 'JUNTA DIRECTIVA NACIONAL' THEN
            RAISE EXCEPTION 'La Junta Directiva Nacional no se inactiva.';
        END IF;
        SELECT count(*) INTO n FROM gobernanza.afiliado WHERE id_estamento_pertenencia = (r->>'id_estamento')::BIGINT AND activo;
        IF n > 0 THEN
            RAISE EXCEPTION 'La junta tiene % afiliado(s) activo(s): trasládelos a otra junta antes de inactivarla.', n;
        END IF;
        IF EXISTS (SELECT 1 FROM gobernanza.directivo_estamento WHERE id_estamento = (r->>'id_estamento')::BIGINT AND fecha_retiro IS NULL) THEN
            RAISE EXCEPTION 'La junta tiene directivos vigentes: registre primero su retiro.';
        END IF;
        IF EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria WHERE id_estamento = (r->>'id_estamento')::BIGINT AND activo) THEN
            RAISE EXCEPTION 'La junta tiene una cuenta bancaria activa: trasládele el saldo e inactívela primero.';
        END IF;
        IF EXISTS (SELECT 1 FROM gobernanza.cuenta_red_social WHERE id_estamento = (r->>'id_estamento')::BIGINT AND activo) THEN
            RAISE EXCEPTION 'La junta tiene cuentas de redes sociales activas: inactívelas o asígnelas a otra junta primero.';
        END IF;
        v_saldo := finanzas.fn_saldo_fondo((r->>'id_estamento')::BIGINT);
        IF v_saldo <> 0 THEN
            RAISE EXCEPTION 'El fondo de la junta tiene saldo (%): trasládelo antes de inactivarla.', to_char(v_saldo, 'FM999G999G999D00');
        END IF;
        UPDATE seguridad.usuario_ambito SET activo = FALSE, motivo_inactivacion = 'Junta inactivada: ' || v_cascada
         WHERE id_estamento = (r->>'id_estamento')::BIGINT AND activo;

    ELSIF p_tabla = 'gobernanza.comite' THEN
        UPDATE gobernanza.comite_miembro SET activo = FALSE, motivo_inactivacion = 'Comité inactivado: ' || v_cascada
         WHERE id_comite = (r->>'id_comite')::BIGINT AND activo;

    ELSIF p_tabla = 'gobernanza.inspector' THEN
        IF EXISTS (SELECT 1 FROM gobernanza.registro_inspector_estamento WHERE id_inspector = (r->>'id_inspector')::BIGINT AND activo) THEN
            RAISE EXCEPTION 'El inspector tiene registros sindicales activos: inactívelos primero.';
        END IF;

    ELSIF p_tabla = 'gobernanza.registro_inspector_estamento' THEN
        IF EXISTS (SELECT 1 FROM gobernanza.directivo_estamento WHERE id_registro_inspector = (r->>'id_registro')::BIGINT AND fecha_retiro IS NULL) THEN
            RAISE EXCEPTION 'Hay directivos vigentes inscritos con este registro: no se puede inactivar.';
        END IF;

    ELSIF p_tabla = 'finanzas.cuenta_bancaria' THEN
        v_saldo := finanzas.fn_saldo_cuenta((r->>'id_cuenta')::BIGINT);
        IF v_saldo <> 0 THEN
            RAISE EXCEPTION 'La cuenta tiene saldo (%): trasládelo antes de inactivarla.', to_char(v_saldo, 'FM999G999G999D00');
        END IF;
        IF EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria WHERE id_cuenta_padre = (r->>'id_cuenta')::BIGINT AND activo) THEN
            RAISE EXCEPTION 'La cuenta nacional tiene subcuentas activas: no se puede inactivar.';
        END IF;

    ELSIF p_tabla = 'gobernanza.cuenta_red_social' THEN
        -- Quien tenía acceso a la cuenta lo pierde (queda en el historial con la fecha de retiro)
        UPDATE gobernanza.cuenta_red_acceso SET fecha_retiro = CURRENT_DATE
         WHERE id_cuenta_red = (r->>'id_cuenta_red')::BIGINT AND fecha_retiro IS NULL;

    ELSIF p_tabla = 'seguridad.rol_app' THEN
        IF (r->>'es_sistema')::BOOLEAN THEN RAISE EXCEPTION 'Los roles del sistema no se inactivan.'; END IF;
        IF EXISTS (SELECT 1 FROM seguridad.usuario WHERE codigo_rol = r->>'codigo_rol' AND activo) THEN
            RAISE EXCEPTION 'Hay usuarios activos con este rol: cámbieles el rol primero.';
        END IF;

    ELSIF p_tabla = 'seguridad.usuario' THEN
        -- Un usuario desactivado pierde de inmediato sus sesiones abiertas
        UPDATE seguridad.sesion SET revocada = TRUE WHERE id_usuario = (r->>'id_usuario')::BIGINT AND NOT revocada;
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 4. CONTROL DE ACTIVO / INACTIVO
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION seguridad.fn_control_activo()
RETURNS TRIGGER AS $$
DECLARE
    v_tabla TEXT := TG_TABLE_SCHEMA || '.' || TG_TABLE_NAME;
    v_exige BOOLEAN;
    v_ignorar TEXT[] := ARRAY['version', 'fecha_modificacion', 'usuario_modificacion'];
BEGIN
    IF COALESCE(current_setting('sgs.operacion', true), '') = 'sistema' THEN RETURN NEW; END IF;
    IF TG_OP = 'INSERT' THEN
        NEW.activo := TRUE;
        NEW.fecha_inactivacion := NULL; NEW.usuario_inactivacion := NULL; NEW.motivo_inactivacion := NULL;
        RETURN NEW;
    END IF;

    IF OLD.activo AND NOT NEW.activo THEN                        -- INACTIVAR
        SELECT exige_motivo INTO v_exige FROM seguridad.tabla_inactivable WHERE tabla = v_tabla;
        NEW.motivo_inactivacion := NULLIF(trim(COALESCE(NEW.motivo_inactivacion, '')), '');
        IF v_exige AND length(COALESCE(NEW.motivo_inactivacion, '')) < 10 THEN
            RAISE EXCEPTION 'Escriba el motivo de la inactivación (mínimo 10 caracteres).';
        END IF;
        NEW.fecha_inactivacion := now();
        NEW.usuario_inactivacion := auditoria.fn_usuario_actual();
        IF TG_TABLE_NAME = 'cuenta_red_social' THEN NEW.estado := 'INACTIVA'; END IF;
        PERFORM seguridad.fn_reglas_inactivar(v_tabla, to_jsonb(NEW), COALESCE(NEW.motivo_inactivacion, 'sin motivo'));

    ELSIF NOT OLD.activo AND NEW.activo THEN                     -- REACTIVAR
        PERFORM seguridad.fn_verificar_padres_activos(v_tabla, to_jsonb(NEW), NULL);
        NEW.fecha_inactivacion := NULL; NEW.usuario_inactivacion := NULL; NEW.motivo_inactivacion := NULL;
        IF TG_TABLE_NAME = 'cuenta_red_social' THEN NEW.estado := 'ACTIVA'; END IF;

    ELSIF NOT OLD.activo THEN                                    -- inactivo: no se modifica
        IF TG_TABLE_NAME <> 'usuario'
           AND (to_jsonb(NEW) - v_ignorar) IS DISTINCT FROM (to_jsonb(OLD) - v_ignorar) THEN
            RAISE EXCEPTION 'El registro está inactivo: reactívelo antes de modificarlo.';
        END IF;

    ELSE                                                         -- activo: los datos de inactivación no se tocan
        NEW.fecha_inactivacion := OLD.fecha_inactivacion;
        NEW.usuario_inactivacion := OLD.usuario_inactivacion;
        NEW.motivo_inactivacion := OLD.motivo_inactivacion;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DO $$
DECLARE t TEXT;
BEGIN
    FOR t IN SELECT tabla FROM seguridad.tabla_inactivable LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_activo ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_activo BEFORE INSERT OR UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION seguridad.fn_control_activo()', t);
    END LOOP;
END $$;

-- Una subdirectiva que cambia de banco inactiva su subcuenta (con saldo cero) y abre otra
DROP INDEX IF EXISTS finanzas.ux_una_subcuenta_por_estamento;
CREATE UNIQUE INDEX IF NOT EXISTS ux_una_subcuenta_activa_por_estamento ON finanzas.cuenta_bancaria (id_estamento)
    WHERE NOT es_cuenta_nacional AND activo;

CREATE OR REPLACE FUNCTION finanzas.fn_cuenta_valida(p_id_estamento BIGINT, p_id_cuenta BIGINT)
RETURNS BOOLEAN AS $$
    SELECT EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria c WHERE c.id_cuenta = p_id_cuenta AND c.id_estamento = p_id_estamento)
        OR (EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria c WHERE c.id_cuenta = p_id_cuenta AND c.es_cuenta_nacional)
            AND NOT EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria s
                             WHERE s.id_estamento = p_id_estamento AND NOT s.es_cuenta_nacional AND s.activo));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_usa_cuenta_nacional(p_estamentos BIGINT[])
RETURNS BOOLEAN AS $$
    SELECT EXISTS (SELECT 1 FROM unnest(p_estamentos) x(id)
                    WHERE NOT EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria s
                                       WHERE s.id_estamento = x.id AND NOT s.es_cuenta_nacional AND s.activo));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION finanzas.fn_cuenta_del_fondo(p_id_estamento BIGINT)
RETURNS BIGINT AS $$
    SELECT COALESCE((SELECT id_cuenta FROM finanzas.cuenta_bancaria
                      WHERE id_estamento = p_id_estamento AND NOT es_cuenta_nacional AND activo),
                    (SELECT id_cuenta FROM finanzas.cuenta_bancaria WHERE es_cuenta_nacional AND activo ORDER BY id_cuenta LIMIT 1),
                    (SELECT id_cuenta FROM finanzas.cuenta_bancaria WHERE es_cuenta_nacional ORDER BY id_cuenta LIMIT 1));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Un ámbito de usuario inactivo ya no da acceso a esa junta
CREATE OR REPLACE FUNCTION seguridad.fn_ambito_estamentos()
RETURNS BIGINT[] AS $$
    SELECT COALESCE(ARRAY(
        SELECT d.id_estamento FROM seguridad.usuario u
          JOIN gobernanza.directivo_estamento d ON d.id_persona = u.id_persona AND d.fecha_retiro IS NULL
         WHERE u.id_usuario = seguridad.fn_id_usuario_actual() AND u.activo
        UNION
        SELECT a.id_estamento FROM seguridad.usuario_ambito a JOIN seguridad.usuario u USING (id_usuario)
         WHERE a.id_usuario = seguridad.fn_id_usuario_actual() AND u.activo AND a.activo
    ), '{}');
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 5. ANULACIÓN DE MOVIMIENTOS FINANCIEROS
-- ----------------------------------------------------------------------------
DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['finanzas.consignacion_empresa', 'finanzas.aporte_afiliado', 'finanzas.ingreso',
                             'finanzas.transferencia', 'finanzas.presupuesto', 'finanzas.conciliacion_bancaria'] LOOP
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS anulado BOOLEAN NOT NULL DEFAULT FALSE', t);
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS fecha_anulacion TIMESTAMP WITH TIME ZONE', t);
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS usuario_anulacion VARCHAR(50)', t);
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS motivo_anulacion TEXT', t);
        EXECUTE format('COMMENT ON COLUMN %s.anulado IS %L', t, 'TRUE = anulado: queda en el historial, fuera de saldos, totales y mora.');
    END LOOP;
END $$;

-- Lo anulado no se modifica; anular solo se hace con finanzas.fn_anular_movimiento (motivo y responsable)
CREATE OR REPLACE FUNCTION finanzas.fn_control_anulado()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        NEW.anulado := FALSE; NEW.fecha_anulacion := NULL; NEW.usuario_anulacion := NULL; NEW.motivo_anulacion := NULL;
        RETURN NEW;
    END IF;
    IF OLD.anulado THEN
        RAISE EXCEPTION 'El registro está anulado: no se modifica. Si hace falta, registre uno nuevo.';
    END IF;
    IF NEW.anulado AND COALESCE(current_setting('finanzas.operacion', true), '') <> 'anular' THEN
        RAISE EXCEPTION 'Para anular use la acción Anular (con motivo).';
    END IF;
    IF NOT NEW.anulado THEN
        NEW.fecha_anulacion := NULL; NEW.usuario_anulacion := NULL; NEW.motivo_anulacion := NULL;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['finanzas.consignacion_empresa', 'finanzas.aporte_afiliado', 'finanzas.ingreso',
                             'finanzas.transferencia', 'finanzas.presupuesto', 'finanzas.conciliacion_bancaria'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_anulado ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_anulado BEFORE INSERT OR UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION finanzas.fn_control_anulado()', t);
    END LOOP;
END $$;

-- Lo anulado no ocupa el lugar de lo vigente: se puede registrar de nuevo el movimiento correcto
DROP INDEX IF EXISTS finanzas.ux_consignacion_empresa_periodo_cuenta;
CREATE UNIQUE INDEX IF NOT EXISTS ux_consignacion_vigente_periodo_cuenta
    ON finanzas.consignacion_empresa (id_empresa, periodo_anio, periodo_mes, id_cuenta_destino) WHERE NOT anulado;
DROP INDEX IF EXISTS finanzas.ux_aporte_persona_periodo;
CREATE UNIQUE INDEX IF NOT EXISTS ux_aporte_vigente_persona_periodo
    ON finanzas.aporte_afiliado (id_persona, periodo_anio, periodo_mes) WHERE NOT anulado;
DO $$
DECLARE c RECORD;
BEGIN
    FOR c IN SELECT conrelid::regclass AS tabla, conname FROM pg_constraint
              WHERE contype = 'u' AND conrelid IN ('finanzas.presupuesto'::regclass, 'finanzas.conciliacion_bancaria'::regclass) LOOP
        EXECUTE format('ALTER TABLE %s DROP CONSTRAINT %I', c.tabla, c.conname);
    END LOOP;
END $$;
CREATE UNIQUE INDEX IF NOT EXISTS ux_presupuesto_vigente ON finanzas.presupuesto (id_estamento, anio, id_rubro) WHERE NOT anulado;
CREATE UNIQUE INDEX IF NOT EXISTS ux_conciliacion_vigente ON finanzas.conciliacion_bancaria (id_cuenta, anio, mes) WHERE NOT anulado;

CREATE OR REPLACE FUNCTION finanzas.fn_anular_movimiento(p_tabla TEXT, p_id BIGINT, p_motivo TEXT)
RETURNS TEXT AS $$
DECLARE
    v_u seguridad.usuario%ROWTYPE;
    v_juntas BIGINT[];
    v_anulado BOOLEAN;
    v_n INT := 0;
    v_rel REGCLASS;
    v_pk TEXT;
BEGIN
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN
        RAISE EXCEPTION 'Escriba el motivo de la anulación (mínimo 10 caracteres).';
    END IF;
    SELECT * INTO v_u FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo;
    IF v_u.id_usuario IS NULL THEN RAISE EXCEPTION 'Usuario no identificado.'; END IF;

    -- Juntas a las que pertenece el movimiento (quien anula debe ser Tesorero o Presidente de alguna)
    IF p_tabla = 'consignacion_empresa' THEN
        v_rel := 'finanzas.consignacion_empresa'; v_pk := 'id_consignacion';
        SELECT c.anulado, ARRAY[cb.id_estamento] INTO v_anulado, v_juntas
          FROM finanzas.consignacion_empresa c JOIN finanzas.cuenta_bancaria cb ON cb.id_cuenta = c.id_cuenta_destino
         WHERE c.id_consignacion = p_id FOR UPDATE OF c;
    ELSIF p_tabla = 'aporte_afiliado' THEN
        v_rel := 'finanzas.aporte_afiliado'; v_pk := 'id_aporte';
        SELECT a.anulado, ARRAY[cb.id_estamento, af.id_estamento_pertenencia] INTO v_anulado, v_juntas
          FROM finanzas.aporte_afiliado a
          LEFT JOIN finanzas.consignacion_empresa c ON c.id_consignacion = a.id_consignacion
          LEFT JOIN finanzas.cuenta_bancaria cb ON cb.id_cuenta = c.id_cuenta_destino
          LEFT JOIN gobernanza.afiliado af ON af.id_persona = a.id_persona
         WHERE a.id_aporte = p_id FOR UPDATE OF a;
    ELSIF p_tabla = 'ingreso' THEN
        v_rel := 'finanzas.ingreso'; v_pk := 'id_ingreso';
        SELECT anulado, ARRAY[id_estamento] INTO v_anulado, v_juntas FROM finanzas.ingreso WHERE id_ingreso = p_id FOR UPDATE;
    ELSIF p_tabla = 'transferencia' THEN
        v_rel := 'finanzas.transferencia'; v_pk := 'id_transferencia';
        SELECT t.anulado, ARRAY[o.id_estamento, d.id_estamento] INTO v_anulado, v_juntas
          FROM finanzas.transferencia t
          JOIN finanzas.cuenta_bancaria o ON o.id_cuenta = t.id_cuenta_origen
          JOIN finanzas.cuenta_bancaria d ON d.id_cuenta = t.id_cuenta_destino
         WHERE t.id_transferencia = p_id FOR UPDATE OF t;
    ELSIF p_tabla = 'presupuesto' THEN
        v_rel := 'finanzas.presupuesto'; v_pk := 'id_presupuesto';
        SELECT anulado, ARRAY[id_estamento] INTO v_anulado, v_juntas FROM finanzas.presupuesto WHERE id_presupuesto = p_id FOR UPDATE;
    ELSIF p_tabla = 'conciliacion_bancaria' THEN
        v_rel := 'finanzas.conciliacion_bancaria'; v_pk := 'id_conciliacion';
        SELECT cb.anulado, ARRAY[c.id_estamento] INTO v_anulado, v_juntas
          FROM finanzas.conciliacion_bancaria cb JOIN finanzas.cuenta_bancaria c ON c.id_cuenta = cb.id_cuenta
         WHERE cb.id_conciliacion = p_id FOR UPDATE OF cb;
    ELSE
        RAISE EXCEPTION 'Este tipo de registro no se anula.';
    END IF;

    IF v_anulado IS NULL THEN RAISE EXCEPTION 'El registro no existe.'; END IF;
    IF v_anulado THEN RAISE EXCEPTION 'El registro ya está anulado.'; END IF;
    IF NOT EXISTS (SELECT 1 FROM unnest(v_juntas) j(id)
                    WHERE j.id IS NOT NULL AND (SELECT rol FROM finanzas.fn_rol_financiero(v_u.id_persona, j.id)) IS NOT NULL) THEN
        RAISE EXCEPTION 'Solo el Tesorero o el Presidente de la junta (en comités, el Secretario General o el Presidente) pueden anular movimientos financieros.';
    END IF;

    PERFORM set_config('finanzas.operacion', 'anular', true);
    EXECUTE format('UPDATE %s SET anulado = TRUE, motivo_anulacion = $1, fecha_anulacion = now(), usuario_anulacion = $2 WHERE %I = $3',
                   v_rel, v_pk) USING trim(p_motivo), v_u.nombre_usuario, p_id;
    -- Anular una consignación anula los aportes que se generaron con ella
    IF p_tabla = 'consignacion_empresa' THEN
        UPDATE finanzas.aporte_afiliado SET anulado = TRUE, fecha_anulacion = now(), usuario_anulacion = v_u.nombre_usuario,
               motivo_anulacion = 'Consignación anulada: ' || trim(p_motivo)
         WHERE id_consignacion = p_id AND NOT anulado;
        GET DIAGNOSTICS v_n = ROW_COUNT;
    END IF;
    PERFORM set_config('finanzas.operacion', '', true);
    RETURN CASE WHEN v_n > 0 THEN 'ANULADO (y ' || v_n || ' aporte(s) de la consignación)' ELSE 'ANULADO' END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Al anular no se vuelven a validar las reglas de registro (la cuenta o los afiliados pudieron cambiar después)
CREATE OR REPLACE FUNCTION finanzas.fn_validar_movimiento()
RETURNS TRIGGER AS $$
DECLARE v_acta RECORD; v_origen RECORD; v_destino RECORD;
BEGIN
    IF TG_OP = 'UPDATE' AND TG_TABLE_NAME <> 'egreso' AND COALESCE(current_setting('finanzas.operacion', true), '') = 'anular' THEN
        RETURN NEW;
    END IF;
    IF TG_TABLE_NAME = 'egreso' THEN
        IF NOT finanzas.fn_cuenta_valida(NEW.id_estamento, NEW.id_cuenta) THEN
            RAISE EXCEPTION 'La cuenta no corresponde a la junta: use su subcuenta, o la cuenta nacional si la junta no tiene subcuenta.';
        END IF;
    END IF;
    -- Un ingreso puede llegar a la subcuenta de la junta o a la cuenta nacional (padre)
    IF TG_TABLE_NAME = 'ingreso' THEN
        IF NOT (finanzas.fn_cuenta_valida(NEW.id_estamento, NEW.id_cuenta)
                OR EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria c WHERE c.id_cuenta = NEW.id_cuenta AND c.es_cuenta_nacional)) THEN
            RAISE EXCEPTION 'Un ingreso de la junta llega a su subcuenta o a la cuenta nacional, no a la subcuenta de otra junta.';
        END IF;
    END IF;
    -- Consignación de una empresa: a la cuenta nacional o a la subcuenta de una junta con afiliados en esa empresa
    IF TG_TABLE_NAME = 'consignacion_empresa' THEN
        SELECT * INTO v_destino FROM finanzas.cuenta_bancaria WHERE id_cuenta = NEW.id_cuenta_destino;
        IF NOT v_destino.es_cuenta_nacional AND NOT EXISTS (
               SELECT 1 FROM gobernanza.afiliado_empresa ae JOIN gobernanza.afiliado a ON a.id_persona = ae.id_persona
                WHERE ae.id_empresa = NEW.id_empresa AND a.id_estamento_pertenencia = v_destino.id_estamento) THEN
            RAISE EXCEPTION 'La empresa no tiene afiliados de la junta dueña de esa subcuenta: la consignación debe ir a la cuenta nacional o a la subcuenta de una junta con afiliados en la empresa.';
        END IF;
    END IF;

    IF TG_TABLE_NAME = 'egreso' THEN
        IF TG_OP = 'INSERT' THEN
            NEW.estado := 'REGISTRADO'; NEW.fecha_aprobacion := NULL;
            NEW.motivo_anulacion := NULL; NEW.fecha_anulacion := NULL; NEW.usuario_anulacion := NULL;
        ELSE
            IF OLD.estado <> 'REGISTRADO' AND current_setting('finanzas.operacion', true) IS DISTINCT FROM 'anular' THEN
                RAISE EXCEPTION 'Un egreso % no se modifica. Si hay un error, anúlelo con su motivo y registre uno nuevo.', lower(OLD.estado);
            END IF;
            IF NEW.estado IS DISTINCT FROM OLD.estado AND NULLIF(current_setting('finanzas.operacion', true), '') IS NULL THEN
                RAISE EXCEPTION 'El estado del egreso solo cambia al aprobarlo o anularlo.';
            END IF;
            IF NEW.hash_soporte IS DISTINCT FROM OLD.hash_soporte AND OLD.hash_soporte IS NOT NULL THEN
                RAISE EXCEPTION 'El egreso ya tiene un soporte con huella SHA-256 registrada; no puede reemplazarse.';
            END IF;
        END IF;
        IF NULLIF(current_setting('finanzas.operacion', true), '') IS NULL
           AND NOT EXISTS (SELECT 1 FROM finanzas.rubro WHERE id_rubro = NEW.id_rubro AND activo) THEN
            RAISE EXCEPTION 'El rubro está inactivo.';
        END IF;
        IF NEW.id_acta_autorizacion IS NOT NULL THEN
            SELECT d.id_estamento, t.sigla_tipo INTO v_acta FROM gestion_documental.documento d
              JOIN gestion_documental.tipo_documento t ON t.id_tipo_documento = d.id_tipo_documento
             WHERE d.id_documento = NEW.id_acta_autorizacion;
            IF v_acta.sigla_tipo <> 'ACT' OR v_acta.id_estamento <> NEW.id_estamento THEN
                RAISE EXCEPTION 'El acta de autorización debe ser un acta (ACT) de la misma junta.';
            END IF;
        END IF;
    END IF;

    IF TG_TABLE_NAME = 'presupuesto' THEN
        SELECT d.id_estamento, t.sigla_tipo INTO v_acta FROM gestion_documental.documento d
          JOIN gestion_documental.tipo_documento t ON t.id_tipo_documento = d.id_tipo_documento
         WHERE d.id_documento = NEW.id_acta;
        IF v_acta.sigla_tipo IS DISTINCT FROM 'ACT' OR v_acta.id_estamento IS DISTINCT FROM NEW.id_estamento THEN
            RAISE EXCEPTION 'El presupuesto se aprueba con un acta de reunión (ACT) de la misma junta.';
        END IF;
    END IF;

    IF TG_TABLE_NAME = 'transferencia' THEN
        SELECT * INTO v_origen FROM finanzas.cuenta_bancaria WHERE id_cuenta = NEW.id_cuenta_origen;
        SELECT * INTO v_destino FROM finanzas.cuenta_bancaria WHERE id_cuenta = NEW.id_cuenta_destino;
        IF NOT ((v_origen.es_cuenta_nacional AND v_destino.id_cuenta_padre = v_origen.id_cuenta)
             OR (v_destino.es_cuenta_nacional AND v_origen.id_cuenta_padre = v_destino.id_cuenta)) THEN
            RAISE EXCEPTION 'Las transferencias son entre la cuenta nacional y una de sus subcuentas hijas.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Presupuesto: solo cuenta el vigente (no anulado)
CREATE OR REPLACE FUNCTION finanzas.fn_aprobar_egreso(p_id_egreso BIGINT)
RETURNS TEXT AS $$
DECLARE
    v_e finanzas.egreso%ROWTYPE;
    v_u seguridad.usuario%ROWTYPE;
    v_rol RECORD;
    v_presupuesto NUMERIC;
    v_ejecutado NUMERIC;
    v_fondo NUMERIC;
    v_cuenta NUMERIC;
BEGIN
    SELECT * INTO v_u FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo;
    IF v_u.id_usuario IS NULL THEN RAISE EXCEPTION 'Usuario no identificado.'; END IF;
    SELECT * INTO v_e FROM finanzas.egreso WHERE id_egreso = p_id_egreso FOR UPDATE;
    IF v_e.id_egreso IS NULL THEN RAISE EXCEPTION 'El egreso no existe.'; END IF;
    IF v_e.estado <> 'REGISTRADO' THEN RAISE EXCEPTION 'El egreso ya está %.', lower(v_e.estado); END IF;
    IF finanzas.fn_mes_cerrado(v_e.id_estamento, v_e.fecha) THEN RAISE EXCEPTION 'El mes contable del egreso está cerrado.'; END IF;
    IF v_e.hash_soporte IS NULL THEN
        RAISE EXCEPTION 'Adjunte el soporte (factura o cuenta de cobro en PDF) antes de aprobar el egreso.';
    END IF;

    SELECT * INTO v_rol FROM finanzas.fn_rol_financiero(v_u.id_persona, v_e.id_estamento);
    IF v_rol.rol IS NULL THEN
        RAISE EXCEPTION 'Solo aprueban egresos el Tesorero y el Presidente de la junta (en comités, el Secretario General y el Presidente). El Fiscal revisa pero no aprueba.';
    END IF;
    IF EXISTS (SELECT 1 FROM finanzas.egreso_aprobacion WHERE id_egreso = p_id_egreso AND rol = v_rol.rol) THEN
        RAISE EXCEPTION 'La aprobación de % ya está registrada; falta la otra firma.', lower(v_rol.rol);
    END IF;
    INSERT INTO finanzas.egreso_aprobacion (id_egreso, rol, id_usuario, id_persona, cargo)
    VALUES (p_id_egreso, v_rol.rol, v_u.id_usuario, v_u.id_persona, v_rol.cargo);

    IF (SELECT count(*) FROM finanzas.egreso_aprobacion WHERE id_egreso = p_id_egreso) < 2 THEN
        RETURN 'PENDIENTE: registrada la firma de ' || lower(v_rol.rol) || '; falta la otra firma.';
    END IF;

    -- Segunda firma: controles de presupuesto y de fondos (serializados por junta y por cuenta)
    PERFORM pg_advisory_xact_lock(hashtext('fondo_' || v_e.id_estamento));
    PERFORM pg_advisory_xact_lock(hashtext('cuenta_' || v_e.id_cuenta));
    IF finanzas.fn_parametro('EXIGIR_PRESUPUESTO') = 1 AND v_e.id_acta_autorizacion IS NULL THEN
        SELECT valor_aprobado INTO v_presupuesto FROM finanzas.presupuesto
         WHERE id_estamento = v_e.id_estamento AND id_rubro = v_e.id_rubro AND anio = EXTRACT(YEAR FROM v_e.fecha)::INT AND NOT anulado;
        IF v_presupuesto IS NULL THEN
            RAISE EXCEPTION 'No hay presupuesto aprobado para este rubro en %. Registre el presupuesto o un acta de autorización.',
                EXTRACT(YEAR FROM v_e.fecha)::INT;
        END IF;
        SELECT COALESCE(SUM(valor), 0) INTO v_ejecutado FROM finanzas.egreso
         WHERE id_estamento = v_e.id_estamento AND id_rubro = v_e.id_rubro AND estado = 'APROBADO'
           AND EXTRACT(YEAR FROM fecha) = EXTRACT(YEAR FROM v_e.fecha);
        IF v_ejecutado + v_e.valor > v_presupuesto THEN
            RAISE EXCEPTION 'El egreso supera el presupuesto del rubro (aprobado %, ejecutado %, este egreso %). Requiere un acta de autorización.',
                to_char(v_presupuesto, 'FM999G999G999D00'), to_char(v_ejecutado, 'FM999G999G999D00'), to_char(v_e.valor, 'FM999G999G999D00');
        END IF;
    END IF;
    v_fondo := finanzas.fn_saldo_fondo(v_e.id_estamento);
    v_cuenta := finanzas.fn_saldo_cuenta(v_e.id_cuenta);
    IF v_fondo < v_e.valor THEN
        RAISE EXCEPTION 'Fondos insuficientes: el saldo del fondo de la junta es % y el egreso es %.',
            to_char(v_fondo, 'FM999G999G999D00'), to_char(v_e.valor, 'FM999G999G999D00');
    END IF;
    IF v_cuenta < v_e.valor THEN
        RAISE EXCEPTION 'Saldo insuficiente en la cuenta: % disponible para un egreso de %.',
            to_char(v_cuenta, 'FM999G999G999D00'), to_char(v_e.valor, 'FM999G999G999D00');
    END IF;
    PERFORM set_config('finanzas.operacion', 'aprobar', true);
    UPDATE finanzas.egreso SET estado = 'APROBADO', fecha_aprobacion = now() WHERE id_egreso = p_id_egreso;
    PERFORM set_config('finanzas.operacion', '', true);
    RETURN 'APROBADO';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 6. LIBROS, VISTAS Y APORTES: lo anulado no cuenta; el afiliado retirado deja de deber
--    desde el mes siguiente al retiro (el mes del retiro sí se cobra: la nómina ya se causó)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION gobernanza.fn_afiliado_cotiza(p_activo BOOLEAN, p_fecha_inactivacion TIMESTAMPTZ, p_mes DATE)
RETURNS BOOLEAN AS $$
    SELECT p_activo OR p_fecha_inactivacion >= date_trunc('month', p_mes);
$$ LANGUAGE sql STABLE;
COMMENT ON FUNCTION gobernanza.fn_afiliado_cotiza IS '¿Se espera aporte del afiliado en ese mes? Sí si está activo o si se retiró ese mes o después.';

CREATE OR REPLACE VIEW finanzas_interno.distribucion AS
WITH jdn AS (SELECT id_estamento FROM gobernanza.estamento WHERE tipo_estamento = 'JUNTA DIRECTIVA NACIONAL' LIMIT 1),
pct AS (SELECT finanzas.fn_parametro('PORCENTAJE_NACIONAL') AS v),
ap AS (
    SELECT a.id_aporte, a.id_consignacion, c.fecha_consignacion AS fecha, a.id_persona, a.monto_descuento_ley AS monto,
           af.id_estamento_pertenencia AS est_local, ROUND(a.monto_descuento_ley * (SELECT v FROM pct) / 100, 2) AS parte_nacional
      FROM finanzas.aporte_afiliado a
      JOIN finanzas.consignacion_empresa c ON c.id_consignacion = a.id_consignacion
      LEFT JOIN gobernanza.afiliado af ON af.id_persona = a.id_persona
     WHERE NOT a.anulado AND NOT c.anulado
)
SELECT (SELECT id_estamento FROM jdn) AS id_estamento, fecha, id_consignacion, id_aporte, 'APORTE_NACIONAL' AS concepto, parte_nacional AS valor FROM ap
UNION ALL
SELECT est_local, fecha, id_consignacion, id_aporte, CASE WHEN est_local IS NULL THEN 'APORTE_SIN_PERTENENCIA' ELSE 'APORTE_LOCAL' END,
       monto - parte_nacional FROM ap
UNION ALL
SELECT NULL, c.fecha_consignacion, c.id_consignacion, NULL, 'CONSIGNACION_SIN_DISCRIMINAR',
       c.monto_total_consignado - COALESCE((SELECT SUM(monto_descuento_ley) FROM finanzas.aporte_afiliado a
                                             WHERE a.id_consignacion = c.id_consignacion AND NOT a.anulado), 0)
  FROM finanzas.consignacion_empresa c
 WHERE NOT c.anulado
   AND c.monto_total_consignado - COALESCE((SELECT SUM(monto_descuento_ley) FROM finanzas.aporte_afiliado a
                                             WHERE a.id_consignacion = c.id_consignacion AND NOT a.anulado), 0) <> 0;

CREATE OR REPLACE VIEW finanzas_interno.mov_fondo AS
SELECT id_estamento, fecha, concepto AS tipo, 'Aporte ' || COALESCE(id_aporte::TEXT, 'sin discriminar') || ' (consignación ' || id_consignacion || ')' AS detalle, valor
  FROM finanzas_interno.distribucion
UNION ALL
SELECT id_estamento, fecha, 'OTRO_INGRESO', concepto, valor FROM finanzas.ingreso WHERE NOT anulado
UNION ALL
SELECT id_estamento, fecha, 'EGRESO', concepto || ' — ' || beneficiario_nombre, -valor FROM finanzas.egreso WHERE estado = 'APROBADO';

CREATE OR REPLACE VIEW finanzas_interno.mov_cuenta AS
SELECT id_cuenta_destino AS id_cuenta, fecha_consignacion AS fecha, 'CONSIGNACION' AS tipo,
       'Consignación empresa ' || id_empresa || ' periodo ' || periodo_mes || '/' || periodo_anio AS detalle, monto_total_consignado AS valor
  FROM finanzas.consignacion_empresa WHERE NOT anulado
UNION ALL SELECT id_cuenta, fecha, 'OTRO_INGRESO', concepto, valor FROM finanzas.ingreso WHERE NOT anulado
UNION ALL SELECT id_cuenta_destino, fecha, 'TRANSFERENCIA_RECIBIDA', concepto, valor FROM finanzas.transferencia WHERE NOT anulado
UNION ALL SELECT id_cuenta_origen, fecha, 'TRANSFERENCIA_ENVIADA', concepto, -valor FROM finanzas.transferencia WHERE NOT anulado
UNION ALL SELECT id_cuenta, fecha, 'EGRESO', concepto || ' — ' || beneficiario_nombre, -valor FROM finanzas.egreso WHERE estado = 'APROBADO';

CREATE OR REPLACE VIEW finanzas.vf_mora_empresas AS
WITH meses AS (
    SELECT g::DATE AS mes FROM generate_series(date_trunc('month', CURRENT_DATE) - INTERVAL '12 months',
                                               date_trunc('month', CURRENT_DATE) - INTERVAL '1 month', INTERVAL '1 month') g
     WHERE g + INTERVAL '1 month' + (finanzas.fn_parametro('DIA_LIMITE_CONSIGNACION')::INT - 1) * INTERVAL '1 day' < CURRENT_DATE
), esperado AS (
    SELECT ae.id_empresa, m.mes, COUNT(*) AS afiliados,
           ROUND(SUM(gobernanza.fn_salario_vigente(ae.id_persona, ae.id_empresa, (m.mes + INTERVAL '1 month' - INTERVAL '1 day')::DATE))
                 * finanzas.fn_parametro('PORCENTAJE_APORTE') / 100, 2) AS valor
      FROM gobernanza.afiliado_empresa ae
      JOIN gobernanza.afiliado af ON af.id_persona = ae.id_persona
      JOIN meses m ON ae.fecha_ingreso_empresa <= (m.mes + INTERVAL '1 month' - INTERVAL '1 day')::DATE
     WHERE gobernanza.fn_afiliado_cotiza(af.activo, af.fecha_inactivacion, m.mes)
     GROUP BY ae.id_empresa, m.mes
)
SELECT emp.nombre_empresa AS empresa, emp.nit, to_char(es.mes, 'YYYY-MM') AS periodo, es.afiliados,
       es.valor AS esperado, COALESCE(c.monto_total_consignado, 0) AS consignado,
       COALESCE(c.monto_total_consignado, 0) - es.valor AS diferencia, c.fecha_consignacion, c.cuentas AS consignado_en,
       CASE WHEN c.id_consignacion IS NULL THEN 'ALERTA CRÍTICA: NO CONSIGNÓ LOS APORTES DEL MES'
            WHEN c.monto_total_consignado < es.valor - finanzas.fn_parametro('TOLERANCIA_PESOS') THEN 'ALERTA ALTA: CONSIGNÓ MENOS DE LO ESPERADO'
            ELSE 'AL DÍA' END AS diagnostico,
       emp.id_empresa
  FROM esperado es
  JOIN gobernanza.empresa emp ON emp.id_empresa = es.id_empresa
  LEFT JOIN (SELECT ce.id_empresa, ce.periodo_anio, ce.periodo_mes, SUM(ce.monto_total_consignado) AS monto_total_consignado,
                    MAX(ce.fecha_consignacion) AS fecha_consignacion, MIN(ce.id_consignacion) AS id_consignacion,
                    string_agg(CASE WHEN cb.es_cuenta_nacional THEN 'Cuenta nacional' ELSE 'Subcuenta ' || e2.nombre_estamento END
                               || ' (' || ce.monto_total_consignado || ')', '; ' ORDER BY cb.es_cuenta_nacional DESC, e2.nombre_estamento) AS cuentas
               FROM finanzas.consignacion_empresa ce
               JOIN finanzas.cuenta_bancaria cb ON cb.id_cuenta = ce.id_cuenta_destino
               LEFT JOIN gobernanza.estamento e2 ON e2.id_estamento = cb.id_estamento
              WHERE NOT ce.anulado
              GROUP BY ce.id_empresa, ce.periodo_anio, ce.periodo_mes) c
         ON c.id_empresa = es.id_empresa
        AND c.periodo_anio = EXTRACT(YEAR FROM es.mes)::INT AND c.periodo_mes = EXTRACT(MONTH FROM es.mes)::INT
 WHERE (SELECT rolbypassrls OR rolsuper FROM pg_roles WHERE rolname = session_user)
    OR seguridad.fn_empresa_visible(emp.id_empresa, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos());

CREATE OR REPLACE VIEW finanzas.vf_ejecucion_presupuestal AS
WITH ej AS (
    SELECT id_estamento, EXTRACT(YEAR FROM fecha)::INT AS anio, id_rubro, SUM(valor) AS ejecutado
      FROM finanzas.egreso WHERE estado = 'APROBADO' GROUP BY 1, 2, 3
), base AS (
    SELECT COALESCE(p.id_estamento, ej.id_estamento) AS id_estamento, COALESCE(p.anio, ej.anio) AS anio,
           COALESCE(p.id_rubro, ej.id_rubro) AS id_rubro, p.valor_aprobado, COALESCE(ej.ejecutado, 0) AS ejecutado
      FROM (SELECT * FROM finanzas.presupuesto WHERE NOT anulado) p
      FULL JOIN ej ON ej.id_estamento = p.id_estamento AND ej.anio = p.anio AND ej.id_rubro = p.id_rubro
)
SELECT e.nombre_estamento AS junta, b.anio, r.nombre AS rubro, b.valor_aprobado AS aprobado, b.ejecutado,
       b.valor_aprobado - b.ejecutado AS disponible,
       CASE WHEN b.valor_aprobado > 0 THEN ROUND(b.ejecutado * 100 / b.valor_aprobado, 1) END AS porcentaje_ejecucion,
       CASE WHEN b.valor_aprobado IS NULL THEN 'ALERTA CRÍTICA: GASTO SIN PRESUPUESTO (APROBADO CON ACTA)'
            WHEN b.ejecutado > b.valor_aprobado THEN 'ALERTA CRÍTICA: PRESUPUESTO SUPERADO (APROBADO CON ACTA)'
            WHEN b.ejecutado >= b.valor_aprobado * 0.8 THEN 'ALERTA ALTA: EJECUCIÓN DEL 80 % O MÁS'
            ELSE 'NORMAL' END AS diagnostico,
       b.id_estamento
  FROM base b JOIN gobernanza.estamento e ON e.id_estamento = b.id_estamento JOIN finanzas.rubro r ON r.id_rubro = b.id_rubro
 WHERE seguridad.fn_ve_estamento(b.id_estamento);

CREATE OR REPLACE VIEW finanzas.vf_conciliacion_bancaria AS
SELECT c.banco || ' ' || c.numero_cuenta AS cuenta, e.nombre_estamento AS titular, cb.anio, cb.mes, cb.saldo_extracto,
       finanzas.fn_saldo_cuenta(c.id_cuenta, (make_date(cb.anio, cb.mes, 1) + INTERVAL '1 month' - INTERVAL '1 day')::DATE) AS saldo_sistema,
       cb.saldo_extracto - finanzas.fn_saldo_cuenta(c.id_cuenta, (make_date(cb.anio, cb.mes, 1) + INTERVAL '1 month' - INTERVAL '1 day')::DATE) AS diferencia,
       CASE WHEN abs(cb.saldo_extracto - finanzas.fn_saldo_cuenta(c.id_cuenta, (make_date(cb.anio, cb.mes, 1) + INTERVAL '1 month' - INTERVAL '1 day')::DATE))
                 <= finanzas.fn_parametro('TOLERANCIA_PESOS') THEN 'CONCILIADA'
            ELSE 'ALERTA CRÍTICA: EL EXTRACTO NO COINCIDE CON EL SISTEMA' END AS diagnostico,
       cb.observaciones, c.id_estamento
  FROM finanzas.conciliacion_bancaria cb
  JOIN finanzas.cuenta_bancaria c ON c.id_cuenta = cb.id_cuenta
  LEFT JOIN gobernanza.estamento e ON e.id_estamento = c.id_estamento
 WHERE NOT cb.anulado AND seguridad.fn_ve_estamento(c.id_estamento);

CREATE OR REPLACE VIEW finanzas.v_auditoria_armonizacion_aportes AS
SELECT
    c.id_consignacion,
    e.nombre_empresa,
    c.periodo_mes,
    c.periodo_anio,
    c.monto_total_consignado,
    COALESCE(SUM(a.monto_descuento_ley), 0) AS suma_aportes_individuales,
    (c.monto_total_consignado - COALESCE(SUM(a.monto_descuento_ley), 0)) AS diferencia_conciliacion,
    CASE
        WHEN c.monto_total_consignado = COALESCE(SUM(a.monto_descuento_ley), 0) THEN 'ARMONIZADO / EXACTO'
        WHEN COALESCE(SUM(a.monto_descuento_ley), 0) = 0 THEN 'PENDIENTE DISCRIMINACIÓN (REPORTE CONSOLIDADO SIN DETALLE)'
        ELSE 'DISCREPANCIA FINANCIERA REQUIERE AUDITORÍA'
    END AS diagnostico_auditoria
FROM finanzas.consignacion_empresa c
JOIN gobernanza.empresa e ON c.id_empresa = e.id_empresa
LEFT JOIN finanzas.aporte_afiliado a ON c.id_consignacion = a.id_consignacion AND NOT a.anulado
WHERE NOT c.anulado
GROUP BY c.id_consignacion, e.nombre_empresa, c.periodo_mes, c.periodo_anio, c.monto_total_consignado;

CREATE OR REPLACE FUNCTION finanzas.fn_generar_aportes(p_id_consignacion BIGINT, p_solo_junta BOOLEAN DEFAULT FALSE)
RETURNS INT AS $$
DECLARE v_c RECORD; v_n INT;
BEGIN
    SELECT ce.*, cb.es_cuenta_nacional, cb.id_estamento AS est_cuenta INTO v_c
      FROM finanzas.consignacion_empresa ce JOIN finanzas.cuenta_bancaria cb ON cb.id_cuenta = ce.id_cuenta_destino
     WHERE ce.id_consignacion = p_id_consignacion FOR UPDATE OF ce;
    IF v_c.id_consignacion IS NULL
       OR NOT finanzas.fn_consignacion_visible(v_c.id_empresa, v_c.id_cuenta_destino, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos()) THEN
        RAISE EXCEPTION 'La consignación no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v_c.anulado THEN RAISE EXCEPTION 'La consignación está anulada: no se le generan aportes.'; END IF;
    -- Dos generaciones simultáneas de la misma empresa y mes se serializan
    PERFORM pg_advisory_xact_lock(hashtext('aportes_empresa'), (v_c.id_empresa * 100000 + v_c.periodo_anio * 100 + v_c.periodo_mes)::INT);
    INSERT INTO finanzas.aporte_afiliado (id_consignacion, id_persona, periodo_mes, periodo_anio, monto_descuento_ley)
    SELECT p_id_consignacion, ae.id_persona, v_c.periodo_mes, v_c.periodo_anio,
           ROUND(gobernanza.fn_salario_vigente(ae.id_persona, ae.id_empresa, f.fin_mes) * finanzas.fn_parametro('PORCENTAJE_APORTE') / 100, 2)
      FROM gobernanza.afiliado_empresa ae
      JOIN gobernanza.afiliado a ON a.id_persona = ae.id_persona
     CROSS JOIN (SELECT (make_date(v_c.periodo_anio, v_c.periodo_mes, 1) + INTERVAL '1 month' - INTERVAL '1 day')::DATE AS fin_mes) f
     WHERE ae.id_empresa = v_c.id_empresa AND ae.fecha_ingreso_empresa <= f.fin_mes
       AND gobernanza.fn_afiliado_cotiza(a.activo, a.fecha_inactivacion, f.fin_mes)
       AND (NOT p_solo_junta OR v_c.es_cuenta_nacional OR a.id_estamento_pertenencia = v_c.est_cuenta)
       AND NOT EXISTS (SELECT 1 FROM finanzas.aporte_afiliado x
                        WHERE x.id_persona = ae.id_persona AND x.periodo_anio = v_c.periodo_anio AND x.periodo_mes = v_c.periodo_mes
                          AND NOT x.anulado);
    GET DIAGNOSTICS v_n = ROW_COUNT;
    RETURN v_n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 7. VISTAS DE CONTROL: una junta (o un tipo documental) inactiva no genera alertas
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW gestion_documental.v_auditoria_inactividad_documental AS
WITH matriz_estamento_documento AS (
    SELECT e.id_estamento, e.nombre_estamento, e.tipo_estamento,
           t.id_tipo_documento, t.nombre_tipo, t.sigla_tipo
    FROM gobernanza.estamento e
    CROSS JOIN gestion_documental.tipo_documento t
    WHERE t.categoria_flujo = 'EMITIDO' AND e.activo AND t.activo
), ultimas_emisiones AS (
    SELECT id_estamento, id_tipo_documento, MAX(fecha_radicacion) AS ultima_fecha
    FROM gestion_documental.documento
    WHERE flujo = 'EMITIDO' AND estado_tramite <> 'ANULADO'
    GROUP BY id_estamento, id_tipo_documento
)
SELECT
    m.id_estamento,
    m.nombre_estamento,
    m.tipo_estamento AS ambito_territorial,
    m.nombre_tipo AS tipo_documento,
    m.sigla_tipo,
    u.ultima_fecha AS fecha_ultima_emision,
    CASE WHEN u.ultima_fecha IS NOT NULL THEN
        EXTRACT(MONTH FROM AGE(CURRENT_TIMESTAMP, u.ultima_fecha))::INT + (EXTRACT(YEAR FROM AGE(CURRENT_TIMESTAMP, u.ultima_fecha))::INT * 12)
    END AS meses_inactividad,
    CASE WHEN u.ultima_fecha IS NOT NULL THEN EXTRACT(DAY FROM (CURRENT_TIMESTAMP - u.ultima_fecha))::INT END AS dias_inactividad,
    CASE WHEN u.ultima_fecha IS NOT NULL THEN EXTRACT(HOUR FROM (CURRENT_TIMESTAMP - u.ultima_fecha))::INT END AS horas_inactividad,
    CASE WHEN u.ultima_fecha IS NOT NULL THEN
        (EXTRACT(MONTH FROM AGE(CURRENT_TIMESTAMP, u.ultima_fecha))::INT + (EXTRACT(YEAR FROM AGE(CURRENT_TIMESTAMP, u.ultima_fecha))::INT * 12))::TEXT || ' meses, ' ||
        EXTRACT(DAY FROM (CURRENT_TIMESTAMP - u.ultima_fecha))::INT::TEXT || ' días y ' ||
        EXTRACT(HOUR FROM (CURRENT_TIMESTAMP - u.ultima_fecha))::INT::TEXT || ' horas'
    ELSE 'SIN REGISTRO HISTÓRICO DE EMISIÓN'
    END AS tiempo_inactividad_formateado,
    CASE
        WHEN u.ultima_fecha IS NULL THEN 'ALERTA CRÍTICA: NUNCA HA EMITIDO ESTE TIPO DE DOCUMENTO'
        WHEN CURRENT_TIMESTAMP - u.ultima_fecha > INTERVAL '60 days' THEN 'ALERTA CRÍTICA: INACTIVIDAD GRAVE (>60 DÍAS SIN EMISIÓN)'
        WHEN CURRENT_TIMESTAMP - u.ultima_fecha > INTERVAL '30 days' THEN 'ALERTA ALTA: OMISIÓN DOCUMENTAL (>30 DÍAS SIN EMISIÓN)'
        WHEN CURRENT_TIMESTAMP - u.ultima_fecha > INTERVAL '15 days' AND m.sigla_tipo = 'ACT' THEN 'ALERTA MEDIA: INACTIVIDAD EN REUNIONES (15-29 DÍAS SIN ACTA)'
        ELSE 'ACTIVIDAD REGULAR Y DENTRO DEL PARÁMETRO'
    END AS diagnostico_inactividad
FROM matriz_estamento_documento m
LEFT JOIN ultimas_emisiones u ON m.id_estamento = u.id_estamento AND m.id_tipo_documento = u.id_tipo_documento;

CREATE OR REPLACE VIEW gobernanza.v_composicion_juntas AS
SELECT
    e.id_estamento,
    e.nombre_estamento,
    e.tipo_estamento,
    c.orden,
    c.nombre AS cargo,
    p.tipo_dni || ' ' || p.dni AS identificacion,
    p.primer_nombre || ' ' || p.primer_apellido AS ocupado_por,
    d.fecha_posesion_individual,
    d.fecha_fin_vigencia_programada,
    CASE
        WHEN d.id_directivo_estamento IS NULL THEN 'ALERTA MEDIA: CARGO VACANTE'
        WHEN CURRENT_DATE > d.fecha_fin_vigencia_programada THEN 'ALERTA ALTA: OCUPADO CON PERÍODO VENCIDO'
        ELSE 'CARGO PROVISTO'
    END AS diagnostico
FROM gobernanza.estamento e
JOIN gobernanza.cargo_directivo c ON c.tipo_estamento = e.tipo_estamento AND c.activo
LEFT JOIN gobernanza.directivo_estamento d
       ON d.id_estamento = e.id_estamento AND d.id_cargo = c.id_cargo AND d.fecha_retiro IS NULL
LEFT JOIN gobernanza.persona p ON p.id_persona = d.id_persona
WHERE e.activo;

CREATE OR REPLACE VIEW finanzas.vf_saldo_fondos AS
WITH f AS (
    SELECT id_estamento,
           SUM(valor) FILTER (WHERE tipo LIKE 'APORTE%' OR tipo = 'CONSIGNACION_SIN_DISCRIMINAR') AS aportes,
           SUM(valor) FILTER (WHERE tipo = 'OTRO_INGRESO') AS otros_ingresos,
           -SUM(valor) FILTER (WHERE tipo = 'EGRESO') AS egresos,
           SUM(valor) AS saldo
      FROM finanzas_interno.mov_fondo GROUP BY id_estamento
)
SELECT COALESCE(e.nombre_estamento, 'PENDIENTE DE DISTRIBUIR') AS fondo, e.tipo_estamento,
       (SELECT c.banco || ' ' || c.numero_cuenta FROM finanzas.cuenta_bancaria c
         WHERE c.id_estamento = COALESCE(e.id_estamento, -1) AND NOT c.es_cuenta_nacional AND c.activo LIMIT 1) AS subcuenta,
       COALESCE(f.aportes, 0) AS aportes, COALESCE(f.otros_ingresos, 0) AS otros_ingresos,
       COALESCE(f.egresos, 0) AS egresos, COALESCE(f.saldo, 0) AS saldo,
       CASE WHEN e.id_estamento IS NULL AND COALESCE(f.saldo, 0) > 0
                THEN 'ALERTA ALTA: APORTES SIN DISTRIBUIR (AFILIADOS SIN PERTENENCIA O CONSIGNACIÓN SIN DISCRIMINAR)'
            WHEN e.id_estamento IS NULL AND COALESCE(f.saldo, 0) < 0
                THEN 'ALERTA ALTA: LOS APORTES DISCRIMINADOS SUPERAN LO CONSIGNADO POR LA EMPRESA'
            WHEN COALESCE(f.saldo, 0) < 0 THEN 'ALERTA CRÍTICA: FONDO EN NEGATIVO'
            ELSE 'NORMAL' END AS diagnostico,
       e.id_estamento
  FROM f FULL JOIN gobernanza.estamento e ON e.id_estamento = f.id_estamento
 WHERE (e.id_estamento IS NULL OR e.activo OR COALESCE(f.saldo, 0) <> 0)
   AND (e.id_estamento IS NULL OR e.tipo_estamento IN ('JUNTA DIRECTIVA NACIONAL', 'SUBDIRECTIVA', 'COMITÉ SECCIONAL'))
   AND seguridad.fn_ve_estamento(COALESCE(e.id_estamento, f.id_estamento));

-- CREATE OR REPLACE no conserva la opción security_invoker: las vistas de alertas deben seguir
-- respetando el ámbito territorial de quien consulta (02c)
ALTER VIEW gestion_documental.v_auditoria_inactividad_documental SET (security_invoker = true);
ALTER VIEW gobernanza.v_composicion_juntas SET (security_invoker = true);
ALTER VIEW finanzas.v_auditoria_armonizacion_aportes SET (security_invoker = true);

-- ----------------------------------------------------------------------------
-- 8. DOBLE CANDADO CONTRA EL BORRADO
-- ----------------------------------------------------------------------------
-- Detalles de trabajo en curso que sí se pueden quitar (sus propios triggers solo lo permiten
-- mientras el acta no está firmada o el escrito está en borrador)
CREATE TABLE IF NOT EXISTS seguridad.tabla_borrable (
    tabla TEXT PRIMARY KEY,
    motivo TEXT NOT NULL
);
INSERT INTO seguridad.tabla_borrable (tabla, motivo) VALUES
    ('gestion_documental.reunion_asistente', 'Asistentes de una reunión cuya acta aún no está firmada.'),
    ('gestion_documental.reunion_punto', 'Puntos del orden del día de una reunión cuya acta aún no está firmada.'),
    ('gestion_documental.reunion_decision', 'Decisiones de una reunión cuya acta aún no está firmada.'),
    ('gestion_documental.escrito_fuente', 'Fuentes de un escrito jurídico en borrador.')
ON CONFLICT (tabla) DO UPDATE SET motivo = EXCLUDED.motivo;

CREATE OR REPLACE FUNCTION seguridad.fn_bloquear_borrado()
RETURNS TRIGGER AS $$
BEGIN
    -- Única excepción: operaciones del sistema expresamente autorizadas (p. ej., purgas legales futuras)
    IF COALESCE(current_setting('sgs.operacion', true), '') = 'purga' THEN RETURN OLD; END IF;
    RAISE EXCEPTION 'En SGSINDICAL nada se borra (%.%): inactive o anule el registro con su motivo; así queda en el historial.',
        TG_TABLE_SCHEMA, TG_TABLE_NAME
        USING ERRCODE = 'restrict_violation';
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION seguridad.fn_tablas_protegidas()
RETURNS TABLE (tabla TEXT) AS $$
    SELECT n.nspname || '.' || c.relname
      FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
     WHERE c.relkind IN ('r', 'p')
       AND (n.nspname IN ('gobernanza', 'finanzas', 'gestion_documental')
            OR (n.nspname = 'seguridad' AND c.relname IN ('usuario', 'rol_app', 'permiso_rol', 'usuario_ambito')))
       AND n.nspname || '.' || c.relname NOT IN (SELECT b.tabla FROM seguridad.tabla_borrable b);
$$ LANGUAGE sql STABLE;

DO $$
DECLARE t TEXT; fk RECORD;
BEGIN
    FOR t IN SELECT x.tabla FROM seguridad.fn_tablas_protegidas() x LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_no_borrar ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_no_borrar BEFORE DELETE ON %s FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado()', t);
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
            EXECUTE format('REVOKE DELETE ON %s FROM sgs_app', t);
        END IF;
    END LOOP;

    -- ON DELETE CASCADE hacia tablas protegidas -> ON DELETE RESTRICT
    FOR fk IN SELECT c.conrelid::regclass AS tabla, c.conname, pg_get_constraintdef(c.oid) AS def
                FROM pg_constraint c
               WHERE c.contype = 'f' AND c.confdeltype = 'c'
                 AND c.confrelid::regclass::text IN (SELECT x.tabla FROM seguridad.fn_tablas_protegidas() x) LOOP
        EXECUTE format('ALTER TABLE %s DROP CONSTRAINT %I', fk.tabla, fk.conname);
        EXECUTE format('ALTER TABLE %s ADD CONSTRAINT %I %s', fk.tabla, fk.conname,
                       replace(fk.def, 'ON DELETE CASCADE', 'ON DELETE RESTRICT'));
    END LOOP;
END $$;

-- Tablas que se creen en el futuro en estos esquemas: sgs_app tampoco podrá borrar en ellas
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        ALTER DEFAULT PRIVILEGES IN SCHEMA gobernanza, finanzas, gestion_documental REVOKE DELETE ON TABLES FROM sgs_app;
    END IF;
END $$;

-- La lectura de los catálogos nuevos
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        GRANT SELECT ON seguridad.tabla_inactivable, seguridad.referencia_activa, seguridad.tabla_borrable TO sgs_app;
        GRANT EXECUTE ON FUNCTION finanzas.fn_anular_movimiento(TEXT, BIGINT, TEXT) TO sgs_app;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_lectura') THEN
        GRANT SELECT ON seguridad.tabla_inactivable, seguridad.referencia_activa, seguridad.tabla_borrable TO sgs_lectura;
        REVOKE EXECUTE ON FUNCTION finanzas.fn_anular_movimiento(TEXT, BIGINT, TEXT) FROM sgs_lectura;
    END IF;
END $$;
REVOKE EXECUTE ON FUNCTION finanzas.fn_anular_movimiento(TEXT, BIGINT, TEXT) FROM PUBLIC;
