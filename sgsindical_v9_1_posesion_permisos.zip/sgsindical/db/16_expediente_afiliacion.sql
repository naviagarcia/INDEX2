-- ============================================================================
-- SGSINDICAL v9.1 · 16_expediente_afiliacion.sql
-- Expediente documental de afiliación, afiliados dispersos y datos institucionales.
--
--  1. Datos institucionales (nombre, sigla y NIT del sindicato) en la base, editables por el
--     administrador: la aplicación y los textos legales los toman de aquí, no del código.
--  2. Campos del formato de afiliación: lugar de expedición del documento, dirección de
--     correspondencia, teléfono y correo adicionales, profesión u oficio y empleo
--     (denominación, código y grado).
--  3. Catálogo de documentos (cédula y formato de afiliación obligatorios; acta de posesión y
--     certificado de carrera opcionales) y expediente por persona: cada archivo con huella SHA-256,
--     estado (por revisar, aceptado, rechazado, reemplazado) y quién lo cargó y lo revisó. Nada se
--     borra: un archivo nuevo reemplaza al anterior.
--  4. Quién hace qué: la persona (en su portal) y Ventanilla cargan; el Presidente y el Secretario
--     General de la junta revisan y deciden; Vicepresidente, Tesorero y Fiscal consultan; los demás
--     solo ven el estado. Para los dispersos, cualquier directivo nacional revisa. Cada consulta de
--     un archivo queda en la bitácora de accesos.
--  5. La afiliación se aprueba solo con los documentos obligatorios aceptados. La solicitud vence a
--     los 60 días (parámetro) si los documentos siguen incompletos: se archiva y la cuenta del portal
--     se desactiva; la persona puede volver a solicitar. Si la junta le rechaza un documento obligatorio,
--     la persona tiene al menos 10 días desde el rechazo para reemplazarlo. Quien recibe un documento
--     también puede aceptarlo.
--  8. La fecha de afiliación es la de la aprobación y la pone el sistema. Una fecha anterior solo se
--     admite desde la radicación y con motivo. La fecha que la persona escribe en el formato se
--     guarda aparte, como dato.
--  6. Afiliados dispersos: pertenecen a la Junta Directiva Nacional. Entrar o salir de esa condición
--     lo decide la Junta Nacional con acta (lo registran su Presidente o su Secretario General) y queda
--     en el historial de pertenencia. Su aporte es 100 % de la Nacional. La pertenencia es obligatoria.
--  7. La cuenta del portal se puede crear desde la solicitud (antes de aprobarla).
-- No modifica los scripts anteriores. Se puede ejecutar más de una vez.
-- ============================================================================
SET client_min_messages = warning;

-- ----------------------------------------------------------------------------
-- 1. DATOS INSTITUCIONALES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.dato_institucional (
    clave VARCHAR(30) PRIMARY KEY,
    nombre VARCHAR(80) NOT NULL,
    valor VARCHAR(250) NOT NULL DEFAULT '',
    descripcion TEXT,
    fecha_modificacion TIMESTAMP WITH TIME ZONE,
    usuario_modificacion VARCHAR(50),
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gobernanza.dato_institucional IS
    'Nombre, sigla y NIT del sindicato. Los usan los correos, certificados, PDF y textos legales; los cambia el administrador.';

INSERT INTO gobernanza.dato_institucional (clave, nombre, valor, descripcion) VALUES
    ('NOMBRE_SINDICATO', 'Nombre oficial', 'Sindicato de Trabajadores Defensores de la Carrera Administrativa',
     'Tal como figura en el registro sindical. Aparece en correos, certificados, respuestas de PQRSD y textos legales.'),
    ('SIGLA', 'Sigla', 'SINTRACAD', 'Sigla del sindicato.'),
    ('NIT', 'NIT', '901.763.807-9', 'NIT con dígito de verificación.')
ON CONFLICT (clave) DO NOTHING;

CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_dato_institucional()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' AND NOT seguridad.fn_ejecuta_sistema() THEN
        RAISE EXCEPTION 'Los datos institucionales son fijos: solo se edita su valor.';
    END IF;
    IF TG_OP = 'UPDATE' THEN
        IF NEW.clave IS DISTINCT FROM OLD.clave THEN RAISE EXCEPTION 'La clave no se cambia.'; END IF;
        IF length(trim(NEW.valor)) = 0 THEN RAISE EXCEPTION 'Escriba el valor de «%».', OLD.nombre; END IF;
        NEW.valor := trim(NEW.valor);
        NEW.fecha_modificacion := now(); NEW.usuario_modificacion := auditoria.fn_usuario_actual();
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_proteger_dato ON gobernanza.dato_institucional;
CREATE TRIGGER trg_proteger_dato BEFORE INSERT OR UPDATE ON gobernanza.dato_institucional
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_proteger_dato_institucional();
DROP TRIGGER IF EXISTS trg_no_borrar ON gobernanza.dato_institucional;
CREATE TRIGGER trg_no_borrar BEFORE DELETE ON gobernanza.dato_institucional FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado();
DROP TRIGGER IF EXISTS trg_auditoria ON gobernanza.dato_institucional;
CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON gobernanza.dato_institucional
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria();
DROP TRIGGER IF EXISTS trg_control_version ON gobernanza.dato_institucional;
CREATE TRIGGER trg_control_version BEFORE UPDATE ON gobernanza.dato_institucional
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version();

-- Lectura pública (también la usan la página de ingreso, el notificador y los PDF)
CREATE OR REPLACE FUNCTION gobernanza.fn_datos_institucionales()
RETURNS JSONB AS $$
    SELECT COALESCE(jsonb_object_agg(lower(clave), valor), '{}'::jsonb) FROM gobernanza.dato_institucional;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Los borradores usan marcadores {{NOMBRE_SINDICATO}}, {{SIGLA}} y {{NIT}}: se llenan al publicar
CREATE OR REPLACE FUNCTION gobernanza.fn_rellenar_institucional(p_texto TEXT)
RETURNS TEXT AS $$
DECLARE r RECORD; v TEXT := p_texto;
BEGIN
    FOR r IN SELECT clave, valor FROM gobernanza.dato_institucional LOOP
        IF position('{{' || r.clave || '}}' IN v) > 0 AND length(trim(r.valor)) = 0 THEN
            RAISE EXCEPTION 'Falta el dato institucional «%»: regístrelo antes de publicar.', r.clave;
        END IF;
        v := replace(v, '{{' || r.clave || '}}', r.valor);
    END LOOP;
    RETURN v;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Borradores de 15: el nombre y la sigla pasan a marcadores y el NIT queda resuelto
UPDATE gobernanza.politica_tratamiento
   SET texto = replace(replace(replace(texto,
                   'SINTRACAD – Sindicato de Trabajadores Defensores de la Carrera Administrativa', '{{SIGLA}} – {{NOMBRE_SINDICATO}}'),
                   '[COMPLETAR: NIT]', '{{NIT}}'), 'SINTRACAD', '{{SIGLA}}'),
       titulo = replace(titulo, 'SINTRACAD', '{{SIGLA}}')
 WHERE fecha_vigencia IS NULL AND (texto LIKE '%SINTRACAD%' OR texto LIKE '%[COMPLETAR: NIT]%' OR titulo LIKE '%SINTRACAD%');
UPDATE gobernanza.texto_institucional
   SET texto = replace(replace(replace(texto,
                   'SINTRACAD – Sindicato de Trabajadores Defensores de la Carrera Administrativa', '{{SIGLA}} – {{NOMBRE_SINDICATO}}'),
                   '[COMPLETAR: NIT]', '{{NIT}}'), 'SINTRACAD', '{{SIGLA}}'),
       titulo = replace(titulo, 'SINTRACAD', '{{SIGLA}}')
 WHERE fecha_vigencia IS NULL AND (texto LIKE '%SINTRACAD%' OR texto LIKE '%[COMPLETAR: NIT]%' OR titulo LIKE '%SINTRACAD%');

-- Publicar: además de exigir el acta y que no queden marcas, se llenan los datos institucionales
CREATE OR REPLACE FUNCTION gobernanza.fn_publicar_texto_institucional(p_id_texto BIGINT)
RETURNS VOID AS $$
DECLARE v gobernanza.texto_institucional%ROWTYPE; v_marcas INT;
BEGIN
    IF NOT (seguridad.fn_es_admin() OR seguridad.fn_es_presidente_nacional()) THEN
        RAISE EXCEPTION 'Los textos institucionales los publican el administrador o la Presidencia Nacional.';
    END IF;
    SELECT * INTO v FROM gobernanza.texto_institucional WHERE id_texto = p_id_texto FOR UPDATE;
    IF v.id_texto IS NULL THEN RAISE EXCEPTION 'La versión no existe.'; END IF;
    IF v.fecha_vigencia IS NOT NULL THEN RAISE EXCEPTION 'Esta versión ya fue publicada.'; END IF;
    v_marcas := gobernanza.fn_marcas_pendientes(v.texto);
    IF v_marcas > 0 THEN
        RAISE EXCEPTION 'El texto tiene % marca(s) [COMPLETAR] o [VERIFICAR] sin resolver: el abogado debe revisarlo antes de publicarlo.', v_marcas;
    END IF;
    IF v.id_acta_aprobacion IS NULL THEN
        RAISE EXCEPTION 'Antes de publicarlo, asocie el acta de la Junta Nacional que aprobó esta versión.';
    END IF;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', 'publicar');
    UPDATE gobernanza.texto_institucional SET vigente = FALSE WHERE vigente AND codigo = v.codigo;
    UPDATE gobernanza.texto_institucional SET vigente = TRUE, fecha_vigencia = now(),
           texto = gobernanza.fn_rellenar_institucional(texto), titulo = gobernanza.fn_rellenar_institucional(titulo)
     WHERE id_texto = p_id_texto;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', '');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_publicar_politica_tratamiento(p_id_politica BIGINT)
RETURNS VOID AS $$
DECLARE v_p gobernanza.politica_tratamiento%ROWTYPE; v_marcas INT;
BEGIN
    IF NOT (seguridad.fn_es_admin() OR seguridad.fn_es_presidente_nacional()) THEN
        RAISE EXCEPTION 'La política la publican el administrador o la Presidencia Nacional.';
    END IF;
    SELECT * INTO v_p FROM gobernanza.politica_tratamiento WHERE id_politica = p_id_politica FOR UPDATE;
    IF v_p.id_politica IS NULL THEN RAISE EXCEPTION 'La versión no existe.'; END IF;
    IF v_p.fecha_vigencia IS NOT NULL THEN RAISE EXCEPTION 'Esta versión ya fue publicada.'; END IF;
    v_marcas := gobernanza.fn_marcas_pendientes(v_p.texto);
    IF v_marcas > 0 THEN
        RAISE EXCEPTION 'La política tiene % marca(s) [COMPLETAR] o [VERIFICAR] sin resolver: el abogado debe revisarla antes de publicarla.', v_marcas;
    END IF;
    IF v_p.id_acta_aprobacion IS NULL THEN
        RAISE EXCEPTION 'Antes de publicarla, asocie el acta de la Junta Nacional que aprobó esta versión.';
    END IF;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', 'publicar');
    UPDATE gobernanza.politica_tratamiento SET vigente = FALSE WHERE vigente;
    UPDATE gobernanza.politica_tratamiento SET vigente = TRUE, fecha_vigencia = now(),
           texto = gobernanza.fn_rellenar_institucional(texto), titulo = gobernanza.fn_rellenar_institucional(titulo)
     WHERE id_politica = p_id_politica;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', '');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 2. CAMPOS DEL FORMATO DE AFILIACIÓN
-- ----------------------------------------------------------------------------
ALTER TABLE gobernanza.persona ADD COLUMN IF NOT EXISTS lugar_expedicion_dni VARCHAR(80);
ALTER TABLE gobernanza.persona ADD COLUMN IF NOT EXISTS direccion_correspondencia VARCHAR(200);
ALTER TABLE gobernanza.persona ADD COLUMN IF NOT EXISTS telefono_adicional VARCHAR(20);
ALTER TABLE gobernanza.persona ADD COLUMN IF NOT EXISTS correo_adicional VARCHAR(100);
COMMENT ON COLUMN gobernanza.persona.lugar_expedicion_dni IS 'Municipio donde se expidió el documento de identidad (formato de afiliación).';
COMMENT ON COLUMN gobernanza.persona.direccion_correspondencia IS 'Dirección de correspondencia (formato de afiliación).';

DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['gobernanza.afiliado', 'gobernanza.solicitud_afiliacion'] LOOP
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS profesion_oficio VARCHAR(100)', t);
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS empleo_denominacion VARCHAR(120)', t);
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS empleo_codigo VARCHAR(10)', t);
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS empleo_grado VARCHAR(10)', t);
    END LOOP;
END $$;
COMMENT ON COLUMN gobernanza.afiliado.empleo_denominacion IS 'Denominación del empleo en la entidad (formato de afiliación). Con el código y el grado identifican el empleo público.';

-- ----------------------------------------------------------------------------
-- 3. PARÁMETROS DEL TRÁMITE DE AFILIACIÓN
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.parametro_afiliacion (
    codigo VARCHAR(40) PRIMARY KEY,
    valor INT NOT NULL CHECK (valor > 0),
    descripcion TEXT NOT NULL,
    version INT NOT NULL DEFAULT 1
);
INSERT INTO gobernanza.parametro_afiliacion (codigo, valor, descripcion) VALUES
    ('DIAS_VENCE_SOLICITUD', 60, 'Días calendario para completar los documentos. Vencido el plazo con documentos incompletos, la solicitud se archiva y la persona puede volver a solicitar.'),
    ('DIAS_RECORDATORIO_1', 3, 'Primer recordatorio a la persona si sus documentos siguen incompletos (días desde la solicitud).'),
    ('DIAS_RECORDATORIO_2', 10, 'Segundo recordatorio a la persona si sus documentos siguen incompletos (días desde la solicitud).'),
    ('DIAS_AVISO_VENCIMIENTO', 10, 'Aviso a la persona cuando faltan estos días para que venza su solicitud.'),
    ('DIAS_TRAS_RECHAZO', 10, 'Si la junta rechaza un documento obligatorio, la persona tiene al menos estos días desde el rechazo para reemplazarlo, aunque el plazo general ya haya vencido.')
ON CONFLICT (codigo) DO NOTHING;

CREATE OR REPLACE FUNCTION gobernanza.fn_parametro_afiliacion(p_codigo TEXT)
RETURNS INT AS $$
    SELECT valor FROM gobernanza.parametro_afiliacion WHERE codigo = p_codigo;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_no_borrar ON gobernanza.parametro_afiliacion;
CREATE TRIGGER trg_no_borrar BEFORE DELETE ON gobernanza.parametro_afiliacion FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado();
DROP TRIGGER IF EXISTS trg_auditoria ON gobernanza.parametro_afiliacion;
CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON gobernanza.parametro_afiliacion
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria();
DROP TRIGGER IF EXISTS trg_control_version ON gobernanza.parametro_afiliacion;
CREATE TRIGGER trg_control_version BEFORE UPDATE ON gobernanza.parametro_afiliacion
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version();

-- ----------------------------------------------------------------------------
-- 4. CATÁLOGO DE DOCUMENTOS Y EXPEDIENTE
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.tipo_documento_afiliacion (
    id_tipo_documento_afiliacion BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    codigo VARCHAR(30) NOT NULL UNIQUE CHECK (codigo ~ '^[A-Z0-9_]+$'),
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    obligatorio BOOLEAN NOT NULL DEFAULT FALSE,
    orden INT NOT NULL DEFAULT 99,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    plantilla_ruta VARCHAR(300),
    plantilla_nombre VARCHAR(160),
    plantilla_hash CHAR(64),
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gobernanza.tipo_documento_afiliacion IS
    'Documentos del expediente de afiliación. Los obligatorios deben estar aceptados para aprobar la afiliación. La plantilla es opcional (p. ej. el formato en blanco).';

INSERT INTO gobernanza.tipo_documento_afiliacion (codigo, nombre, descripcion, obligatorio, orden) VALUES
    ('CEDULA', 'Documento de identidad', 'Copia legible por ambas caras (PDF o fotos).', TRUE, 1),
    ('FORMATO_AFILIACION', 'Formato de afiliación firmado', 'El formato diligenciado y firmado, con la autorización del descuento por nómina.', TRUE, 2),
    ('ACTA_POSESION', 'Acta de posesión en el cargo', 'Opcional. Acredita el empleo que desempeña.', FALSE, 3),
    ('CERTIFICADO_CARRERA', 'Certificado de inscripción en carrera administrativa', 'Opcional.', FALSE, 4)
ON CONFLICT (codigo) DO NOTHING;

CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_tipo_documento_afiliacion()
RETURNS TRIGGER AS $$
BEGIN
    IF COALESCE(seguridad.fn_operacion('afiliacion.operacion'), '') = 'plantilla' THEN RETURN NEW; END IF;
    IF TG_OP = 'INSERT' THEN
        NEW.plantilla_ruta := NULL; NEW.plantilla_nombre := NULL; NEW.plantilla_hash := NULL;
        RETURN NEW;
    END IF;
    IF NEW.codigo IS DISTINCT FROM OLD.codigo THEN RAISE EXCEPTION 'El código del documento no se cambia.'; END IF;
    IF (NEW.plantilla_ruta, NEW.plantilla_nombre, NEW.plantilla_hash) IS DISTINCT FROM (OLD.plantilla_ruta, OLD.plantilla_nombre, OLD.plantilla_hash) THEN
        RAISE EXCEPTION 'La plantilla se cambia con la acción «Subir plantilla».';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_proteger_tipo ON gobernanza.tipo_documento_afiliacion;
CREATE TRIGGER trg_proteger_tipo BEFORE INSERT OR UPDATE ON gobernanza.tipo_documento_afiliacion
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_proteger_tipo_documento_afiliacion();
DROP TRIGGER IF EXISTS trg_no_borrar ON gobernanza.tipo_documento_afiliacion;
CREATE TRIGGER trg_no_borrar BEFORE DELETE ON gobernanza.tipo_documento_afiliacion FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado();
DROP TRIGGER IF EXISTS trg_auditoria ON gobernanza.tipo_documento_afiliacion;
CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON gobernanza.tipo_documento_afiliacion
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria();
DROP TRIGGER IF EXISTS trg_control_version ON gobernanza.tipo_documento_afiliacion;
CREATE TRIGGER trg_control_version BEFORE UPDATE ON gobernanza.tipo_documento_afiliacion
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version();

CREATE TABLE IF NOT EXISTS gobernanza.documento_afiliacion (
    id_documento_afiliacion BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    id_solicitud_afiliacion BIGINT REFERENCES gobernanza.solicitud_afiliacion(id_solicitud_afiliacion) ON DELETE RESTRICT,
    id_tipo_documento_afiliacion BIGINT NOT NULL REFERENCES gobernanza.tipo_documento_afiliacion(id_tipo_documento_afiliacion) ON DELETE RESTRICT,
    ruta_archivo VARCHAR(300) NOT NULL,
    nombre_original VARCHAR(160) NOT NULL,
    tipo_mime VARCHAR(60) NOT NULL DEFAULT 'application/pdf',
    tamano_bytes BIGINT NOT NULL CHECK (tamano_bytes > 0),
    paginas INT,
    hash_sha256 CHAR(64) NOT NULL,
    estado VARCHAR(12) NOT NULL DEFAULT 'POR_REVISAR' CHECK (estado IN ('POR_REVISAR', 'ACEPTADO', 'RECHAZADO', 'REEMPLAZADO')),
    vigente BOOLEAN NOT NULL DEFAULT TRUE,
    medio_carga VARCHAR(12) NOT NULL CHECK (medio_carga IN ('PORTAL', 'VENTANILLA', 'JUNTA')),
    id_usuario_carga BIGINT REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    usuario_carga VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    fecha_carga TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_revision VARCHAR(50),
    fecha_revision TIMESTAMP WITH TIME ZONE,
    motivo_rechazo TEXT,
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gobernanza.documento_afiliacion IS
    'Expediente documental de afiliación. Un archivo nuevo del mismo tipo reemplaza al anterior (que queda REEMPLAZADO); nada se borra.';
CREATE UNIQUE INDEX IF NOT EXISTS ux_doc_afil_vigente ON gobernanza.documento_afiliacion (id_persona, id_tipo_documento_afiliacion) WHERE vigente;
CREATE INDEX IF NOT EXISTS ix_doc_afil_persona ON gobernanza.documento_afiliacion (id_persona);
CREATE INDEX IF NOT EXISTS ix_doc_afil_solicitud ON gobernanza.documento_afiliacion (id_solicitud_afiliacion);
CREATE INDEX IF NOT EXISTS ix_doc_afil_tipo ON gobernanza.documento_afiliacion (id_tipo_documento_afiliacion);
CREATE INDEX IF NOT EXISTS ix_doc_afil_usuario ON gobernanza.documento_afiliacion (id_usuario_carga);

-- Solo las funciones del expediente lo modifican; el archivo y su huella nunca cambian
CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_documento_afiliacion()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'UPDATE' AND (NEW.ruta_archivo, NEW.hash_sha256, NEW.id_persona, NEW.id_tipo_documento_afiliacion, NEW.fecha_carga, NEW.usuario_carga)
           IS DISTINCT FROM (OLD.ruta_archivo, OLD.hash_sha256, OLD.id_persona, OLD.id_tipo_documento_afiliacion, OLD.fecha_carga, OLD.usuario_carga) THEN
        RAISE EXCEPTION 'El archivo de un documento del expediente no se modifica: cargue uno nuevo.';
    END IF;
    IF COALESCE(seguridad.fn_operacion('afiliacion.operacion'), '') NOT IN ('documento', 'revisar') THEN
        RAISE EXCEPTION 'El expediente de afiliación se modifica con sus acciones (cargar, aceptar o rechazar).';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_proteger_documento ON gobernanza.documento_afiliacion;
CREATE TRIGGER trg_proteger_documento BEFORE INSERT OR UPDATE ON gobernanza.documento_afiliacion
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_proteger_documento_afiliacion();
DROP TRIGGER IF EXISTS trg_no_borrar ON gobernanza.documento_afiliacion;
CREATE TRIGGER trg_no_borrar BEFORE DELETE ON gobernanza.documento_afiliacion FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado();
DROP TRIGGER IF EXISTS trg_auditoria ON gobernanza.documento_afiliacion;
CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON gobernanza.documento_afiliacion
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria();
DROP TRIGGER IF EXISTS trg_control_version ON gobernanza.documento_afiliacion;
CREATE TRIGGER trg_control_version BEFORE UPDATE ON gobernanza.documento_afiliacion
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version();

-- ----------------------------------------------------------------------------
-- 5. SOLICITUD: estado ARCHIVADA, fecha de vencimiento, dispersos y formato
-- ----------------------------------------------------------------------------
ALTER TABLE gobernanza.solicitud_afiliacion ADD COLUMN IF NOT EXISTS fecha_vence DATE;
ALTER TABLE gobernanza.solicitud_afiliacion ADD COLUMN IF NOT EXISTS fecha_formato DATE;
ALTER TABLE gobernanza.solicitud_afiliacion ADD COLUMN IF NOT EXISTS motivo_fecha_afiliacion TEXT;
COMMENT ON COLUMN gobernanza.solicitud_afiliacion.fecha_formato IS
    'Fecha que la persona escribió en el formato de afiliación. Es solo un dato: la fecha de afiliación es la de la aprobación.';
COMMENT ON COLUMN gobernanza.solicitud_afiliacion.motivo_fecha_afiliacion IS
    'Motivo por el que se registró una fecha de afiliación anterior a la aprobación (nunca antes de la radicación).';
ALTER TABLE gobernanza.solicitud_afiliacion ADD COLUMN IF NOT EXISTS id_acta_decision BIGINT
    REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT;
CREATE INDEX IF NOT EXISTS ix_sol_afil_acta ON gobernanza.solicitud_afiliacion (id_acta_decision);
ALTER TABLE gobernanza.solicitud_afiliacion DROP CONSTRAINT IF EXISTS solicitud_afiliacion_estado_check;
ALTER TABLE gobernanza.solicitud_afiliacion ADD CONSTRAINT solicitud_afiliacion_estado_check
    CHECK (estado IN ('PENDIENTE', 'APROBADA', 'RECHAZADA', 'ARCHIVADA'));
COMMENT ON COLUMN gobernanza.solicitud_afiliacion.fecha_vence IS
    'Fecha hasta la que la persona puede completar los documentos (DIAS_VENCE_SOLICITUD). Si sigue incompleta, se archiva.';


CREATE OR REPLACE FUNCTION gobernanza.fn_id_jdn()
RETURNS BIGINT AS $$
    SELECT id_estamento FROM gobernanza.estamento WHERE tipo_estamento = 'JUNTA DIRECTIVA NACIONAL' ORDER BY id_estamento LIMIT 1;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_solicitud_afiliacion()
RETURNS TRIGGER AS $$
BEGIN
    IF COALESCE(seguridad.fn_operacion('afiliacion.operacion'), '') IN ('aprobar', 'rechazar', 'archivar', 'prorrogar') THEN RETURN NEW; END IF;
    IF TG_OP = 'INSERT' THEN
        IF EXISTS (SELECT 1 FROM gobernanza.afiliado WHERE id_persona = NEW.id_persona AND activo) THEN
            RAISE EXCEPTION 'La persona ya es afiliada activa.';
        END IF;
        -- Subdirectiva o comité; o la Junta Directiva Nacional para quien será afiliado disperso
        IF NOT EXISTS (SELECT 1 FROM gobernanza.estamento WHERE id_estamento = NEW.id_estamento AND activo
                          AND tipo_estamento IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL', 'JUNTA DIRECTIVA NACIONAL')) THEN
            RAISE EXCEPTION 'La afiliación se solicita a una subdirectiva o comité activo (o a la Junta Directiva Nacional, para afiliados dispersos).';
        END IF;
        NEW.radicado := 'SAF-' || to_char(now() AT TIME ZONE gestion_documental.fn_zona(), 'YYYY') || '-'
                        || lpad(nextval('gobernanza.seq_solicitud_afiliacion')::TEXT, 5, '0');
        NEW.estado := 'PENDIENTE'; NEW.fecha_afiliacion := NULL; NEW.fecha_decision := NULL;
        NEW.usuario_decision := NULL; NEW.observacion_decision := NULL; NEW.id_acta_decision := NULL;
        NEW.fecha_vence := gestion_documental.fn_hoy() + gobernanza.fn_parametro_afiliacion('DIAS_VENCE_SOLICITUD');
        NEW.motivo_fecha_afiliacion := NULL;
        IF NEW.fecha_formato > gestion_documental.fn_hoy() THEN RAISE EXCEPTION 'La fecha del formato no puede ser futura.'; END IF;
        RETURN NEW;
    END IF;
    IF OLD.estado <> 'PENDIENTE' THEN RAISE EXCEPTION 'Una solicitud ya decidida o archivada no se modifica.'; END IF;
    IF NEW.estado IS DISTINCT FROM OLD.estado OR NEW.radicado IS DISTINCT FROM OLD.radicado
       OR NEW.fecha_vence IS DISTINCT FROM OLD.fecha_vence OR NEW.id_acta_decision IS DISTINCT FROM OLD.id_acta_decision THEN
        RAISE EXCEPTION 'La solicitud se aprueba o se rechaza con su acción.';
    END IF;
    IF NEW.id_persona IS DISTINCT FROM OLD.id_persona THEN RAISE EXCEPTION 'El solicitante no se cambia.'; END IF;
    IF NEW.fecha_formato > gestion_documental.fn_hoy() THEN RAISE EXCEPTION 'La fecha del formato no puede ser futura.'; END IF;
    IF NEW.motivo_fecha_afiliacion IS DISTINCT FROM OLD.motivo_fecha_afiliacion THEN
        RAISE EXCEPTION 'El motivo de la fecha de afiliación se registra al aprobar.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Solicitudes que ya existían: vencen 60 días después de recibidas
DO $$
BEGIN
    PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', 'archivar');
    UPDATE gobernanza.solicitud_afiliacion
       SET fecha_vence = (fecha_creacion AT TIME ZONE gestion_documental.fn_zona())::DATE + gobernanza.fn_parametro_afiliacion('DIAS_VENCE_SOLICITUD')
     WHERE fecha_vence IS NULL;
    PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', '');
END $$;

-- ----------------------------------------------------------------------------
-- 6. PERTENENCIA OBLIGATORIA, DISPERSOS E HISTORIAL
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.historial_pertenencia (
    id_historial_pertenencia BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    id_estamento_anterior BIGINT REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    id_estamento_nuevo BIGINT REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    disperso BOOLEAN NOT NULL DEFAULT FALSE,
    id_acta BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    motivo TEXT,
    fecha_registro TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_registro VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual()
);
COMMENT ON TABLE gobernanza.historial_pertenencia IS
    'Cada cambio de la junta a la que pertenece un afiliado. Pasar a disperso (Junta Nacional) o dejar de serlo lleva el acta de la Junta Nacional.';
CREATE INDEX IF NOT EXISTS ix_hist_pert_persona ON gobernanza.historial_pertenencia (id_persona);
CREATE INDEX IF NOT EXISTS ix_hist_pert_anterior ON gobernanza.historial_pertenencia (id_estamento_anterior);
CREATE INDEX IF NOT EXISTS ix_hist_pert_nuevo ON gobernanza.historial_pertenencia (id_estamento_nuevo);
CREATE INDEX IF NOT EXISTS ix_hist_pert_acta ON gobernanza.historial_pertenencia (id_acta);
DROP TRIGGER IF EXISTS trg_inmutable ON gobernanza.historial_pertenencia;
CREATE TRIGGER trg_inmutable BEFORE UPDATE OR DELETE ON gobernanza.historial_pertenencia
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_bloquear_modificacion();

CREATE OR REPLACE FUNCTION gobernanza.fn_registrar_historial_pertenencia()
RETURNS TRIGGER AS $$
DECLARE v_jdn BIGINT := gobernanza.fn_id_jdn();
BEGIN
    IF TG_OP = 'UPDATE' AND NEW.id_estamento_pertenencia IS NOT DISTINCT FROM OLD.id_estamento_pertenencia THEN RETURN NULL; END IF;
    INSERT INTO gobernanza.historial_pertenencia (id_persona, id_estamento_anterior, id_estamento_nuevo, disperso, id_acta, motivo)
    VALUES (NEW.id_persona, CASE WHEN TG_OP = 'UPDATE' THEN OLD.id_estamento_pertenencia END, NEW.id_estamento_pertenencia,
            NEW.id_estamento_pertenencia = v_jdn,
            NULLIF(COALESCE(seguridad.fn_operacion('pertenencia.acta'), ''), '')::BIGINT,
            COALESCE(NULLIF(COALESCE(seguridad.fn_operacion('pertenencia.motivo'), ''), ''),
                     CASE WHEN TG_OP = 'INSERT' THEN 'Afiliación' WHEN NEW.activo AND NOT OLD.activo THEN 'Reafiliación' ELSE 'Cambio de pertenencia' END));
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
DROP TRIGGER IF EXISTS trg_historial_pertenencia ON gobernanza.afiliado;
CREATE TRIGGER trg_historial_pertenencia AFTER INSERT OR UPDATE OF id_estamento_pertenencia ON gobernanza.afiliado
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_registrar_historial_pertenencia();

-- Estado inicial del historial para los afiliados que ya existían
INSERT INTO gobernanza.historial_pertenencia (id_persona, id_estamento_anterior, id_estamento_nuevo, disperso, motivo, usuario_registro)
SELECT a.id_persona, NULL, a.id_estamento_pertenencia, a.id_estamento_pertenencia = gobernanza.fn_id_jdn(),
       'Pertenencia registrada antes del historial', 'sistema'
  FROM gobernanza.afiliado a
 WHERE a.id_estamento_pertenencia IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM gobernanza.historial_pertenencia h WHERE h.id_persona = a.id_persona);

-- Reemplaza la regla de 02b: la Junta Nacional ya puede ser la pertenencia (dispersos), pero solo
-- con su acta o al aprobar una solicitud dirigida a ella; y la pertenencia no puede quedar vacía.
CREATE OR REPLACE FUNCTION gobernanza.fn_validar_cambio_pertenencia()
RETURNS TRIGGER AS $$
DECLARE v_cargo RECORD; v_jdn BIGINT := gobernanza.fn_id_jdn(); v_cambia BOOLEAN;
BEGIN
    IF NEW.id_estamento_pertenencia IS NULL AND (TG_OP = 'INSERT' OR OLD.id_estamento_pertenencia IS NOT NULL) THEN
        RAISE EXCEPTION 'La pertenencia es obligatoria: indique la subdirectiva o comité del afiliado (o la Junta Directiva Nacional si es disperso).';
    END IF;
    v_cambia := TG_OP = 'INSERT' OR NEW.id_estamento_pertenencia IS DISTINCT FROM OLD.id_estamento_pertenencia;
    IF TG_OP = 'UPDATE' AND v_cambia THEN
        SELECT d.rol_estamento, e.nombre_estamento INTO v_cargo
          FROM gobernanza.directivo_estamento d JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento
         WHERE d.id_persona = NEW.id_persona AND d.nivel_cargo = 'LOCAL' AND d.fecha_retiro IS NULL;
        IF FOUND THEN
            RAISE EXCEPTION 'El afiliado es % en "%". Registre su retiro del cargo antes de cambiar su pertenencia.', v_cargo.rol_estamento, v_cargo.nombre_estamento;
        END IF;
    END IF;
    IF v_cambia AND (NEW.id_estamento_pertenencia = v_jdn OR (TG_OP = 'UPDATE' AND OLD.id_estamento_pertenencia = v_jdn))
       AND COALESCE(seguridad.fn_operacion('pertenencia.operacion'), '') <> 'disperso'
       AND COALESCE(seguridad.fn_operacion('afiliacion.operacion'), '') <> 'aprobar' THEN
        RAISE EXCEPTION 'Ser afiliado disperso (pertenecer a la Junta Directiva Nacional) o dejar de serlo lo decide la Junta Nacional con acta: use la acción «Disperso / pertenencia» del afiliado.';
    END IF;
    IF NEW.id_estamento_pertenencia IS NOT NULL AND NOT EXISTS (
        SELECT 1 FROM gobernanza.estamento WHERE id_estamento = NEW.id_estamento_pertenencia
           AND tipo_estamento IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL', 'JUNTA DIRECTIVA NACIONAL')) THEN
        RAISE EXCEPTION 'La pertenencia debe ser una subdirectiva, un comité seccional o la Junta Directiva Nacional (dispersos).';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- La Junta Nacional decide con acta: pasar a disperso o volver a una subdirectiva o comité
CREATE OR REPLACE FUNCTION gobernanza.fn_cambiar_pertenencia_disperso(p_id_persona BIGINT, p_id_estamento BIGINT, p_id_acta BIGINT, p_motivo TEXT)
RETURNS TEXT AS $$
DECLARE v_jdn BIGINT := gobernanza.fn_id_jdn(); v_a RECORD; v_acta RECORD; v_destino RECORD;
BEGIN
    IF NOT seguridad.fn_tiene_cargo(ARRAY['PRES\_NAL', 'SGEN\_NAL'], v_jdn) THEN
        RAISE EXCEPTION 'Este cambio lo registran el Presidente o el Secretario General Nacional, con el acta de la Junta Nacional.'
              USING ERRCODE = 'insufficient_privilege';
    END IF;
    SELECT * INTO v_a FROM gobernanza.afiliado WHERE id_persona = p_id_persona FOR UPDATE;
    IF NOT FOUND OR NOT v_a.activo THEN RAISE EXCEPTION 'La persona no es afiliada activa.'; END IF;
    SELECT tipo_estamento, nombre_estamento, activo INTO v_destino FROM gobernanza.estamento WHERE id_estamento = p_id_estamento;
    IF NOT FOUND OR NOT v_destino.activo THEN RAISE EXCEPTION 'La junta de destino no existe o está inactiva.'; END IF;
    IF p_id_estamento = v_a.id_estamento_pertenencia THEN RAISE EXCEPTION 'El afiliado ya pertenece a esa junta.'; END IF;
    IF p_id_estamento <> v_jdn AND v_a.id_estamento_pertenencia IS DISTINCT FROM v_jdn THEN
        RAISE EXCEPTION 'Esta acción es para pasar a disperso o dejar de serlo. El traslado entre subdirectivas y comités se hace en la ficha del afiliado.';
    END IF;
    SELECT d.id_estamento, t.sigla_tipo INTO v_acta FROM gestion_documental.documento d
      JOIN gestion_documental.tipo_documento t ON t.id_tipo_documento = d.id_tipo_documento WHERE d.id_documento = p_id_acta;
    IF v_acta.sigla_tipo IS DISTINCT FROM 'ACT' OR v_acta.id_estamento IS DISTINCT FROM v_jdn THEN
        RAISE EXCEPTION 'Indique el acta de reunión de la Junta Directiva Nacional que lo decidió (documento tipo ACT radicado).';
    END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo (mínimo 10 caracteres).'; END IF;
    PERFORM seguridad.fn_fijar_operacion('pertenencia.operacion', 'disperso');
    PERFORM seguridad.fn_fijar_operacion('pertenencia.acta', p_id_acta::TEXT);
    PERFORM seguridad.fn_fijar_operacion('pertenencia.motivo', trim(p_motivo));
    UPDATE gobernanza.afiliado SET id_estamento_pertenencia = p_id_estamento WHERE id_persona = p_id_persona;
    PERFORM seguridad.fn_fijar_operacion('pertenencia.operacion', '');
    PERFORM seguridad.fn_fijar_operacion('pertenencia.acta', '');
    PERFORM seguridad.fn_fijar_operacion('pertenencia.motivo', '');
    RETURN CASE WHEN p_id_estamento = v_jdn THEN 'DISPERSO' ELSE v_destino.nombre_estamento END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Afiliados que aún no tienen pertenencia: se listan para corregirlos; NOT NULL cuando no quede ninguno
CREATE OR REPLACE VIEW gobernanza.v_afiliados_sin_pertenencia WITH (security_invoker = true) AS
SELECT a.id_persona, p.primer_nombre || ' ' || p.primer_apellido AS afiliado, p.tipo_dni || ' ' || p.dni AS identificacion,
       a.fecha_afiliacion, a.activo,
       'ALERTA ALTA: AFILIADO SIN PERTENENCIA. ASÍGNELE SU SUBDIRECTIVA O COMITÉ (O DISPERSO, CON ACTA DE LA JUNTA NACIONAL)'::TEXT AS diagnostico
  FROM gobernanza.afiliado a JOIN gobernanza.persona p ON p.id_persona = a.id_persona
 WHERE a.id_estamento_pertenencia IS NULL;

DO $$
DECLARE n INT;
BEGIN
    SELECT count(*) INTO n FROM gobernanza.afiliado WHERE id_estamento_pertenencia IS NULL;
    IF n = 0 THEN
        ALTER TABLE gobernanza.afiliado ALTER COLUMN id_estamento_pertenencia SET NOT NULL;
    ELSE
        RAISE WARNING '% afiliado(s) sin pertenencia: corríjalos (vista gobernanza.v_afiliados_sin_pertenencia) y vuelva a ejecutar este script para fijar la regla en la columna. Mientras tanto ningún afiliado nuevo puede quedar sin pertenencia.', n;
    END IF;
END $$;

-- Aporte de un disperso: 100 % para la Junta Nacional (reemplaza la vista de 05)
CREATE OR REPLACE VIEW finanzas_interno.distribucion AS
WITH jdn AS (SELECT gobernanza.fn_id_jdn() AS id_estamento),
pct AS (SELECT finanzas.fn_parametro('PORCENTAJE_NACIONAL') AS v),
ap AS (
    SELECT a.id_aporte, a.id_consignacion, c.fecha_consignacion AS fecha, a.id_persona, a.monto_descuento_ley AS monto,
           af.id_estamento_pertenencia AS est_local,
           CASE WHEN af.id_estamento_pertenencia = (SELECT id_estamento FROM jdn) THEN a.monto_descuento_ley
                ELSE ROUND(a.monto_descuento_ley * (SELECT v FROM pct) / 100, 2) END AS parte_nacional
      FROM finanzas.aporte_afiliado a
      JOIN finanzas.consignacion_empresa c ON c.id_consignacion = a.id_consignacion
      LEFT JOIN gobernanza.afiliado af ON af.id_persona = a.id_persona
     WHERE NOT a.anulado AND NOT c.anulado
)
SELECT (SELECT id_estamento FROM jdn) AS id_estamento, fecha, id_consignacion, id_aporte, 'APORTE_NACIONAL' AS concepto, parte_nacional AS valor FROM ap
UNION ALL
SELECT est_local, fecha, id_consignacion, id_aporte, CASE WHEN est_local IS NULL THEN 'APORTE_SIN_PERTENENCIA' ELSE 'APORTE_LOCAL' END,
       monto - parte_nacional FROM ap
 WHERE est_local IS DISTINCT FROM (SELECT id_estamento FROM jdn)
UNION ALL
SELECT NULL, c.fecha_consignacion, c.id_consignacion, NULL, 'CONSIGNACION_SIN_DISCRIMINAR',
       c.monto_total_consignado - COALESCE((SELECT SUM(monto_descuento_ley) FROM finanzas.aporte_afiliado a
                                             WHERE a.id_consignacion = c.id_consignacion AND NOT a.anulado), 0)
  FROM finanzas.consignacion_empresa c
 WHERE NOT c.anulado
   AND c.monto_total_consignado - COALESCE((SELECT SUM(monto_descuento_ley) FROM finanzas.aporte_afiliado a
                                             WHERE a.id_consignacion = c.id_consignacion AND NOT a.anulado), 0) <> 0;

-- ----------------------------------------------------------------------------
-- 7. PERMISOS SOBRE EL EXPEDIENTE
-- ----------------------------------------------------------------------------
-- Junta que gestiona el expediente: la de su solicitud pendiente o, si ya es afiliado, la de su pertenencia
CREATE OR REPLACE FUNCTION gobernanza.fn_junta_expediente(p_id_persona BIGINT)
RETURNS BIGINT AS $$
    SELECT COALESCE(
        (SELECT s.id_estamento FROM gobernanza.solicitud_afiliacion s WHERE s.id_persona = p_id_persona AND s.estado = 'PENDIENTE'),
        (SELECT a.id_estamento_pertenencia FROM gobernanza.afiliado a WHERE a.id_persona = p_id_persona AND a.activo),
        (SELECT s.id_estamento FROM gobernanza.solicitud_afiliacion s WHERE s.id_persona = p_id_persona ORDER BY s.fecha_creacion DESC LIMIT 1),
        (SELECT a.id_estamento_pertenencia FROM gobernanza.afiliado a WHERE a.id_persona = p_id_persona));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Persona ligada al usuario de la sesión (afiliado o solicitante con cuenta del portal)
CREATE OR REPLACE FUNCTION seguridad.fn_mi_persona_cuenta()
RETURNS BIGINT AS $$
    SELECT u.id_persona FROM seguridad.usuario u WHERE u.id_usuario = seguridad.fn_id_usuario_actual() AND u.activo;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- GESTIONA (carga, revisa y decide) · CONSULTA (ve los archivos) · VENTANILLA (carga y ve lo que cargó)
-- TITULAR (la propia persona) · ADMIN (ve los archivos solo con motivo) · ESTADO (solo el estado) · NULL (nada)
CREATE OR REPLACE FUNCTION gobernanza.fn_permiso_expediente(p_id_persona BIGINT)
RETURNS TEXT AS $$
DECLARE v_junta BIGINT := gobernanza.fn_junta_expediente(p_id_persona); v_jdn BIGINT := gobernanza.fn_id_jdn();
        v_en_ambito BOOLEAN;
BEGIN
    IF seguridad.fn_id_usuario_actual() IS NULL THEN RETURN NULL; END IF;
    IF seguridad.fn_es_admin() THEN RETURN 'ADMIN'; END IF;
    IF seguridad.fn_rol_actual() = 'AFILIADO' THEN
        RETURN CASE WHEN p_id_persona = seguridad.fn_mi_persona_cuenta() THEN 'TITULAR' END;
    END IF;
    IF v_junta IS NOT NULL THEN
        IF v_junta = v_jdn THEN
            IF seguridad.fn_tiene_cargo(ARRAY['%\_NAL'], v_jdn) THEN RETURN 'GESTIONA'; END IF;
        ELSE
            IF seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'SGEN\_%'], v_junta) THEN RETURN 'GESTIONA'; END IF;
            IF seguridad.fn_tiene_cargo(ARRAY['VICE\_%', 'TES\_%', 'FIS\_%'], v_junta) THEN RETURN 'CONSULTA'; END IF;
        END IF;
    END IF;
    v_en_ambito := seguridad.fn_ambito_nacional() OR v_junta = ANY (seguridad.fn_ambito_estamentos());
    IF seguridad.fn_rol_actual() = 'VENTANILLA' AND v_en_ambito THEN RETURN 'VENTANILLA'; END IF;
    IF p_id_persona = seguridad.fn_mi_persona_cuenta() THEN RETURN 'TITULAR'; END IF;
    IF v_en_ambito THEN RETURN 'ESTADO'; END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Estado documental: INCOMPLETA (falta un obligatorio o fue rechazado) · EN_REVISION · COMPLETA
CREATE OR REPLACE FUNCTION gobernanza.fn_estado_documental(p_id_persona BIGINT)
RETURNS TEXT AS $$
    SELECT CASE
        WHEN bool_or(d.estado IS NULL OR d.estado NOT IN ('POR_REVISAR', 'ACEPTADO')) THEN 'INCOMPLETA'
        WHEN bool_or(d.estado = 'POR_REVISAR') THEN 'EN_REVISION'
        ELSE 'COMPLETA' END
      FROM gobernanza.tipo_documento_afiliacion t
      LEFT JOIN gobernanza.documento_afiliacion d
             ON d.id_tipo_documento_afiliacion = t.id_tipo_documento_afiliacion AND d.id_persona = p_id_persona AND d.vigente
     WHERE t.obligatorio AND t.activo;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 8. ACCIONES DEL EXPEDIENTE
-- ----------------------------------------------------------------------------
-- Registrar un archivo ya guardado por el servidor (el servidor calcula la huella y convierte las fotos a PDF)
CREATE OR REPLACE FUNCTION gobernanza.fn_registrar_documento_afiliacion(
    p_id_persona BIGINT, p_codigo_tipo TEXT, p_ruta TEXT, p_nombre TEXT, p_tamano BIGINT, p_paginas INT, p_hash TEXT)
RETURNS BIGINT AS $$
DECLARE v_permiso TEXT := gobernanza.fn_permiso_expediente(p_id_persona); v_tipo RECORD; v_sol RECORD; v_id BIGINT;
        v_afiliado BOOLEAN;
BEGIN
    IF v_permiso IS NULL OR v_permiso NOT IN ('TITULAR', 'VENTANILLA', 'GESTIONA') THEN
        RAISE EXCEPTION 'Cargan documentos la persona (en su portal), Ventanilla y el Presidente o el Secretario General de la junta.'
              USING ERRCODE = 'insufficient_privilege';
    END IF;
    SELECT * INTO v_tipo FROM gobernanza.tipo_documento_afiliacion WHERE codigo = upper(p_codigo_tipo) AND activo;
    IF NOT FOUND THEN RAISE EXCEPTION 'Tipo de documento no válido.'; END IF;
    IF p_hash !~ '^[0-9a-f]{64}$' THEN RAISE EXCEPTION 'Huella del archivo no válida.'; END IF;
    SELECT * INTO v_sol FROM gobernanza.solicitud_afiliacion WHERE id_persona = p_id_persona AND estado = 'PENDIENTE';
    v_afiliado := EXISTS (SELECT 1 FROM gobernanza.afiliado WHERE id_persona = p_id_persona AND activo);
    IF v_sol.id_solicitud_afiliacion IS NULL AND NOT v_afiliado THEN
        RAISE EXCEPTION 'La persona no tiene una solicitud de afiliación pendiente ni es afiliada activa.';
    END IF;
    IF v_sol.id_solicitud_afiliacion IS NOT NULL AND v_sol.fecha_vence < gestion_documental.fn_hoy()
       AND gobernanza.fn_estado_documental(p_id_persona) = 'INCOMPLETA' THEN
        RAISE EXCEPTION 'El plazo para completar los documentos venció el %: la solicitud se archivará. Puede presentar una nueva.',
              to_char(v_sol.fecha_vence, 'DD/MM/YYYY');
    END IF;
    PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', 'documento');
    UPDATE gobernanza.documento_afiliacion
       SET vigente = FALSE, estado = CASE WHEN estado = 'RECHAZADO' THEN estado ELSE 'REEMPLAZADO' END
     WHERE id_persona = p_id_persona AND id_tipo_documento_afiliacion = v_tipo.id_tipo_documento_afiliacion AND vigente;
    INSERT INTO gobernanza.documento_afiliacion (id_persona, id_solicitud_afiliacion, id_tipo_documento_afiliacion, ruta_archivo,
                                                 nombre_original, tamano_bytes, paginas, hash_sha256, medio_carga, id_usuario_carga)
    VALUES (p_id_persona, v_sol.id_solicitud_afiliacion, v_tipo.id_tipo_documento_afiliacion, p_ruta, left(COALESCE(NULLIF(trim(p_nombre), ''), 'documento.pdf'), 160),
            p_tamano, p_paginas, p_hash,
            CASE v_permiso WHEN 'TITULAR' THEN 'PORTAL' WHEN 'VENTANILLA' THEN 'VENTANILLA' ELSE 'JUNTA' END,
            seguridad.fn_id_usuario_actual())
    RETURNING id_documento_afiliacion INTO v_id;
    PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', '');
    RETURN v_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_revisar_documento_afiliacion(p_id_documento BIGINT, p_aceptar BOOLEAN, p_motivo TEXT DEFAULT NULL)
RETURNS TEXT AS $$
DECLARE v_d gobernanza.documento_afiliacion%ROWTYPE;
BEGIN
    SELECT * INTO v_d FROM gobernanza.documento_afiliacion WHERE id_documento_afiliacion = p_id_documento FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'El documento no existe.'; END IF;
    IF gobernanza.fn_permiso_expediente(v_d.id_persona) IS DISTINCT FROM 'GESTIONA' THEN
        RAISE EXCEPTION 'Revisan los documentos el Presidente y el Secretario General de la junta (para los dispersos, los directivos nacionales).'
              USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF v_d.id_persona = seguridad.fn_mi_persona_cuenta() THEN RAISE EXCEPTION 'Nadie revisa sus propios documentos.'; END IF;
    IF NOT v_d.vigente THEN RAISE EXCEPTION 'Este archivo ya fue reemplazado por uno más reciente.'; END IF;
    IF v_d.estado <> 'POR_REVISAR' THEN RAISE EXCEPTION 'El documento ya fue revisado (%).', lower(v_d.estado); END IF;
    IF NOT p_aceptar AND length(trim(COALESCE(p_motivo, ''))) < 10 THEN
        RAISE EXCEPTION 'Escriba el motivo del rechazo (mínimo 10 caracteres): la persona lo verá para corregirlo.';
    END IF;
    PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', 'revisar');
    UPDATE gobernanza.documento_afiliacion
       SET estado = CASE WHEN p_aceptar THEN 'ACEPTADO' ELSE 'RECHAZADO' END, usuario_revision = auditoria.fn_usuario_actual(),
           fecha_revision = now(), motivo_rechazo = CASE WHEN p_aceptar THEN NULL ELSE trim(p_motivo) END
     WHERE id_documento_afiliacion = p_id_documento;
    -- Rechazo de un obligatorio: la persona tiene al menos DIAS_TRAS_RECHAZO días para reemplazarlo,
    -- aunque el plazo general ya haya vencido o esté por vencer
    IF NOT p_aceptar AND EXISTS (SELECT 1 FROM gobernanza.tipo_documento_afiliacion t
                                  WHERE t.id_tipo_documento_afiliacion = v_d.id_tipo_documento_afiliacion AND t.obligatorio) THEN
        PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', 'prorrogar');
        UPDATE gobernanza.solicitud_afiliacion
           SET fecha_vence = gestion_documental.fn_hoy() + gobernanza.fn_parametro_afiliacion('DIAS_TRAS_RECHAZO')
         WHERE id_persona = v_d.id_persona AND estado = 'PENDIENTE'
           AND fecha_vence < gestion_documental.fn_hoy() + gobernanza.fn_parametro_afiliacion('DIAS_TRAS_RECHAZO');
    END IF;
    PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', '');
    RETURN CASE WHEN p_aceptar THEN 'ACEPTADO' ELSE 'RECHAZADO' END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Abrir el archivo: valida el permiso y lo deja en la bitácora de accesos (Ley 1581)
CREATE OR REPLACE FUNCTION gobernanza.fn_abrir_documento_afiliacion(p_id_documento BIGINT, p_motivo TEXT DEFAULT NULL)
RETURNS TABLE (ruta_archivo TEXT, nombre_original TEXT, tipo_mime TEXT, hash_sha256 TEXT) AS $$
DECLARE v_d RECORD; v_permiso TEXT;
BEGIN
    SELECT d.*, t.codigo INTO v_d FROM gobernanza.documento_afiliacion d
      JOIN gobernanza.tipo_documento_afiliacion t ON t.id_tipo_documento_afiliacion = d.id_tipo_documento_afiliacion
     WHERE d.id_documento_afiliacion = p_id_documento;
    IF NOT FOUND THEN RAISE EXCEPTION 'El documento no existe.'; END IF;
    v_permiso := gobernanza.fn_permiso_expediente(v_d.id_persona);
    IF v_permiso IS NULL OR v_permiso = 'ESTADO'
       OR (v_permiso = 'VENTANILLA' AND v_d.id_usuario_carga IS DISTINCT FROM seguridad.fn_id_usuario_actual()) THEN
        RAISE EXCEPTION 'Puede ver el estado del expediente, pero no sus archivos.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF v_permiso = 'ADMIN' AND length(trim(COALESCE(p_motivo, ''))) < 10 THEN
        RAISE EXCEPTION 'Para abrir un documento del expediente, el administrador debe escribir el motivo (mínimo 10 caracteres).';
    END IF;
    IF v_permiso <> 'TITULAR' THEN
        PERFORM seguridad.fn_registrar_acceso_dato('VER_DATO', 'expediente_afiliacion', v_d.id_persona, ARRAY[v_d.codigo], 1, p_motivo);
    END IF;
    RETURN QUERY SELECT v_d.ruta_archivo::TEXT, v_d.nombre_original::TEXT, v_d.tipo_mime::TEXT, v_d.hash_sha256::TEXT;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Expediente completo (lo que cada quien puede ver)
CREATE OR REPLACE FUNCTION gobernanza.fn_expediente_afiliacion(p_id_persona BIGINT)
RETURNS JSONB AS $$
DECLARE v_permiso TEXT := gobernanza.fn_permiso_expediente(p_id_persona); v_junta BIGINT := gobernanza.fn_junta_expediente(p_id_persona);
        v_jdn BIGINT := gobernanza.fn_id_jdn(); v_archivos BOOLEAN; v_yo BIGINT := seguridad.fn_id_usuario_actual();
BEGIN
    IF v_permiso IS NULL THEN
        RAISE EXCEPTION 'La persona está fuera de su ámbito.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    v_archivos := v_permiso IN ('GESTIONA', 'CONSULTA', 'TITULAR', 'ADMIN', 'VENTANILLA');
    RETURN (SELECT jsonb_build_object(
        'id_persona', p.id_persona,
        'nombre', p.primer_nombre || COALESCE(' ' || p.segundo_nombre, '') || ' ' || p.primer_apellido || COALESCE(' ' || p.segundo_apellido, ''),
        'identificacion', p.tipo_dni || ' ' || p.dni,
        'permiso', v_permiso,
        'puede_cargar', v_permiso IN ('GESTIONA', 'VENTANILLA', 'TITULAR'),
        'puede_revisar', v_permiso = 'GESTIONA' AND p.id_persona IS DISTINCT FROM seguridad.fn_mi_persona_cuenta(),
        'junta', (SELECT nombre_estamento FROM gobernanza.estamento WHERE id_estamento = v_junta),
        'disperso', v_junta = v_jdn,
        'afiliado_activo', COALESCE((SELECT activo FROM gobernanza.afiliado WHERE id_persona = p.id_persona), FALSE),
        'estado_documental', gobernanza.fn_estado_documental(p.id_persona),
        'solicitud', (SELECT jsonb_build_object('id_solicitud_afiliacion', s.id_solicitud_afiliacion, 'radicado', s.radicado,
                                                'estado', s.estado, 'fecha', s.fecha_creacion, 'fecha_vence', s.fecha_vence,
                                                'dias_para_vencer', s.fecha_vence - gestion_documental.fn_hoy(),
                                                'observacion_decision', s.observacion_decision,
                                                'puede_decidir', v_permiso = 'GESTIONA' AND (s.id_estamento <> v_jdn
                                                    OR seguridad.fn_tiene_cargo(ARRAY['PRES\_NAL', 'SGEN\_NAL'], v_jdn)),
                                                'requiere_acta', s.id_estamento = v_jdn)
                        FROM gobernanza.solicitud_afiliacion s WHERE s.id_persona = p.id_persona
                       ORDER BY (s.estado = 'PENDIENTE') DESC, s.fecha_creacion DESC LIMIT 1),
        'documentos', (SELECT jsonb_agg(jsonb_build_object(
                            'codigo', t.codigo, 'nombre', t.nombre, 'descripcion', t.descripcion, 'obligatorio', t.obligatorio,
                            'tiene_plantilla', t.plantilla_ruta IS NOT NULL,
                            'id_documento', d.id_documento_afiliacion, 'estado', d.estado,
                            'nombre_archivo', CASE WHEN v_archivos THEN d.nombre_original END,
                            'paginas', d.paginas, 'fecha_carga', d.fecha_carga, 'medio_carga', d.medio_carga,
                            'cargado_por', CASE WHEN v_permiso <> 'TITULAR' THEN d.usuario_carga END,
                            'revisado_por', CASE WHEN v_permiso <> 'TITULAR' THEN d.usuario_revision END,
                            'fecha_revision', d.fecha_revision, 'motivo_rechazo', d.motivo_rechazo,
                            'puede_abrir', d.id_documento_afiliacion IS NOT NULL AND (v_permiso IN ('GESTIONA', 'CONSULTA', 'TITULAR', 'ADMIN')
                                            OR (v_permiso = 'VENTANILLA' AND d.id_usuario_carga = v_yo)),
                            'anteriores', (SELECT count(*) FROM gobernanza.documento_afiliacion x
                                            WHERE x.id_persona = p.id_persona AND x.id_tipo_documento_afiliacion = t.id_tipo_documento_afiliacion
                                              AND NOT x.vigente))
                        ORDER BY t.orden, t.codigo)
                         FROM gobernanza.tipo_documento_afiliacion t
                         LEFT JOIN gobernanza.documento_afiliacion d
                                ON d.id_tipo_documento_afiliacion = t.id_tipo_documento_afiliacion AND d.id_persona = p.id_persona AND d.vigente
                        WHERE t.activo OR d.id_documento_afiliacion IS NOT NULL)
      ) FROM gobernanza.persona p WHERE p.id_persona = p_id_persona);
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Portal: el expediente propio (afiliado o solicitante)
CREATE OR REPLACE FUNCTION gobernanza.fn_mi_expediente()
RETURNS JSONB AS $$
DECLARE v BIGINT := seguridad.fn_mi_persona_cuenta();
BEGIN
    IF v IS NULL THEN RAISE EXCEPTION 'Su usuario no está ligado a una persona.' USING ERRCODE = 'insufficient_privilege'; END IF;
    RETURN gobernanza.fn_expediente_afiliacion(v);
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Plantilla de un tipo (p. ej. el formato de afiliación en blanco)
CREATE OR REPLACE FUNCTION gobernanza.fn_fijar_plantilla_afiliacion(p_codigo TEXT, p_ruta TEXT, p_nombre TEXT, p_hash TEXT)
RETURNS VOID AS $$
BEGIN
    IF NOT (seguridad.fn_es_admin() OR seguridad.fn_es_presidente_nacional()) THEN
        RAISE EXCEPTION 'Las plantillas las publican el administrador o la Presidencia Nacional.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM gobernanza.tipo_documento_afiliacion WHERE codigo = upper(p_codigo)) THEN
        RAISE EXCEPTION 'Tipo de documento no válido.';
    END IF;
    PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', 'plantilla');
    UPDATE gobernanza.tipo_documento_afiliacion SET plantilla_ruta = p_ruta, plantilla_nombre = left(p_nombre, 160), plantilla_hash = p_hash
     WHERE codigo = upper(p_codigo);
    PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', '');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_plantilla_afiliacion(p_codigo TEXT)
RETURNS TABLE (ruta TEXT, nombre TEXT) AS $$
    SELECT plantilla_ruta::TEXT, plantilla_nombre::TEXT FROM gobernanza.tipo_documento_afiliacion
     WHERE codigo = upper(p_codigo) AND activo AND plantilla_ruta IS NOT NULL AND seguridad.fn_id_usuario_actual() IS NOT NULL;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 9. DECIDIR LA SOLICITUD (con documentos completos; dispersos con acta de la Junta Nacional)
-- ----------------------------------------------------------------------------
-- La fecha de afiliación es la de la aprobación (la pone el sistema). Solo se admite una fecha anterior,
-- nunca antes de la radicación ni futura, y con un motivo que queda en la solicitud y en la auditoría.
DROP FUNCTION IF EXISTS gobernanza.fn_decidir_solicitud_afiliacion(BIGINT, BOOLEAN, DATE, TEXT);
DROP FUNCTION IF EXISTS gobernanza.fn_decidir_solicitud_afiliacion(BIGINT, BOOLEAN, DATE, TEXT, BIGINT);
CREATE OR REPLACE FUNCTION gobernanza.fn_decidir_solicitud_afiliacion(p_id BIGINT, p_aprobar BOOLEAN, p_fecha_afiliacion DATE DEFAULT NULL,
                                                                     p_observacion TEXT DEFAULT NULL, p_id_acta BIGINT DEFAULT NULL,
                                                                     p_motivo_fecha TEXT DEFAULT NULL)
RETURNS TEXT AS $$
DECLARE v_s gobernanza.solicitud_afiliacion%ROWTYPE; v_fecha DATE; v_jdn BIGINT := gobernanza.fn_id_jdn(); v_disperso BOOLEAN;
        v_acta RECORD; v_estado_doc TEXT;
BEGIN
    SELECT * INTO v_s FROM gobernanza.solicitud_afiliacion WHERE id_solicitud_afiliacion = p_id FOR UPDATE;
    IF v_s.id_solicitud_afiliacion IS NULL THEN RAISE EXCEPTION 'La solicitud no existe.'; END IF;
    IF v_s.estado <> 'PENDIENTE' THEN RAISE EXCEPTION 'La solicitud ya fue decidida o archivada.'; END IF;
    v_disperso := v_s.id_estamento = v_jdn;
    IF v_disperso THEN
        IF NOT seguridad.fn_tiene_cargo(ARRAY['PRES\_NAL', 'SGEN\_NAL'], v_jdn) THEN
            RAISE EXCEPTION 'La afiliación de un disperso la decide la Junta Directiva Nacional en reunión; la registran su Presidente o su Secretario General con el acta.';
        END IF;
    ELSIF NOT seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'SGEN\_%'], v_s.id_estamento) THEN
        RAISE EXCEPTION 'La afiliación la aprueban el Presidente o el Secretario General de la junta.';
    END IF;
    IF v_s.id_persona = seguridad.fn_mi_persona_cuenta() THEN RAISE EXCEPTION 'Nadie decide su propia solicitud.'; END IF;
    IF p_id_acta IS NOT NULL OR (v_disperso AND p_aprobar) THEN
        SELECT d.id_estamento, t.sigla_tipo INTO v_acta FROM gestion_documental.documento d
          JOIN gestion_documental.tipo_documento t ON t.id_tipo_documento = d.id_tipo_documento WHERE d.id_documento = p_id_acta;
        IF v_acta.sigla_tipo IS DISTINCT FROM 'ACT' OR v_acta.id_estamento IS DISTINCT FROM v_s.id_estamento THEN
            RAISE EXCEPTION 'Indique el acta de reunión de % que lo decidió (documento tipo ACT radicado).',
                  CASE WHEN v_disperso THEN 'la Junta Directiva Nacional' ELSE 'la junta' END;
        END IF;
    END IF;
    IF NOT p_aprobar THEN
        IF length(trim(COALESCE(p_observacion, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo del rechazo (mínimo 10 caracteres).'; END IF;
        PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', 'rechazar');
        UPDATE gobernanza.solicitud_afiliacion SET estado = 'RECHAZADA', fecha_decision = now(), usuario_decision = auditoria.fn_usuario_actual(),
               observacion_decision = trim(p_observacion), id_acta_decision = p_id_acta
         WHERE id_solicitud_afiliacion = p_id;
        PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', '');
        RETURN 'RECHAZADA';
    END IF;
    v_estado_doc := gobernanza.fn_estado_documental(v_s.id_persona);
    IF v_estado_doc <> 'COMPLETA' THEN
        RAISE EXCEPTION 'No se puede aprobar: %.', CASE v_estado_doc
            WHEN 'EN_REVISION' THEN 'hay documentos obligatorios sin revisar; acéptelos o recházelos primero'
            ELSE 'faltan documentos obligatorios aceptados (documento de identidad y formato de afiliación firmado)' END;
    END IF;
    v_fecha := COALESCE(p_fecha_afiliacion, gestion_documental.fn_hoy());
    IF v_fecha > gestion_documental.fn_hoy() THEN
        RAISE EXCEPTION 'La fecha de afiliación no puede ser futura: es la fecha en que la junta aprueba.';
    END IF;
    IF v_fecha < (v_s.fecha_creacion AT TIME ZONE gestion_documental.fn_zona())::DATE THEN
        RAISE EXCEPTION 'La fecha de afiliación no puede ser anterior a la radicación de la solicitud (%).',
              to_char((v_s.fecha_creacion AT TIME ZONE gestion_documental.fn_zona())::DATE, 'DD/MM/YYYY');
    END IF;
    IF v_fecha < gestion_documental.fn_hoy() AND length(trim(COALESCE(p_motivo_fecha, ''))) < 10 THEN
        RAISE EXCEPTION 'La fecha de afiliación es la de hoy (la de la aprobación). Para registrar una anterior, escriba el motivo (mínimo 10 caracteres).';
    END IF;
    PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', 'aprobar');
    IF p_id_acta IS NOT NULL THEN
        PERFORM seguridad.fn_fijar_operacion('pertenencia.acta', p_id_acta::TEXT);
    END IF;
    PERFORM seguridad.fn_fijar_operacion('pertenencia.motivo', 'Aprobación de la solicitud ' || v_s.radicado);
    IF EXISTS (SELECT 1 FROM gobernanza.afiliado WHERE id_persona = v_s.id_persona) THEN
        -- Reafiliación: se reactiva el mismo registro (nada se duplica)
        PERFORM seguridad.fn_fijar_operacion('sgs.operacion', 'sistema');
        UPDATE gobernanza.afiliado SET activo = TRUE, fecha_inactivacion = NULL, usuario_inactivacion = NULL, motivo_inactivacion = NULL,
               fecha_afiliacion = v_fecha, id_estamento_pertenencia = v_s.id_estamento,
               profesion_oficio = COALESCE(v_s.profesion_oficio, profesion_oficio),
               empleo_denominacion = COALESCE(v_s.empleo_denominacion, empleo_denominacion),
               empleo_codigo = COALESCE(v_s.empleo_codigo, empleo_codigo), empleo_grado = COALESCE(v_s.empleo_grado, empleo_grado)
         WHERE id_persona = v_s.id_persona;
        PERFORM seguridad.fn_fijar_operacion('sgs.operacion', '');
    ELSE
        INSERT INTO gobernanza.afiliado (id_persona, fecha_afiliacion, fecha_nacimiento, nivel_educativo, cargo_empresa, area_empresa,
                                         id_estamento_pertenencia, profesion_oficio, empleo_denominacion, empleo_codigo, empleo_grado)
        VALUES (v_s.id_persona, v_fecha, v_s.fecha_nacimiento, v_s.nivel_educativo, v_s.cargo_empresa, v_s.area_empresa, v_s.id_estamento,
                v_s.profesion_oficio, v_s.empleo_denominacion, v_s.empleo_codigo, v_s.empleo_grado);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM gobernanza.afiliado_empresa WHERE id_persona = v_s.id_persona) THEN
        INSERT INTO gobernanza.afiliado_empresa (id_persona, id_empresa, id_sede, salario_base, fecha_ingreso_empresa)
        VALUES (v_s.id_persona, v_s.id_empresa, v_s.id_sede, v_s.salario_base, v_s.fecha_ingreso_empresa);
    END IF;
    UPDATE gobernanza.solicitud_afiliacion SET estado = 'APROBADA', fecha_afiliacion = v_fecha, fecha_decision = now(),
           usuario_decision = auditoria.fn_usuario_actual(), observacion_decision = NULLIF(trim(COALESCE(p_observacion, '')), ''),
           id_acta_decision = p_id_acta,
           motivo_fecha_afiliacion = CASE WHEN v_fecha < gestion_documental.fn_hoy() THEN trim(p_motivo_fecha) END
     WHERE id_solicitud_afiliacion = p_id;
    PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', '');
    PERFORM seguridad.fn_fijar_operacion('pertenencia.acta', '');
    PERFORM seguridad.fn_fijar_operacion('pertenencia.motivo', '');
    RETURN 'APROBADA';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Archivar las solicitudes vencidas con documentos incompletos (lo ejecuta el proceso de correos cada día).
-- Si la persona no es afiliada, su cuenta del portal se desactiva. Devuelve las archivadas para avisarles.
CREATE OR REPLACE FUNCTION gobernanza.fn_archivar_solicitudes_vencidas()
RETURNS TABLE (id_solicitud_afiliacion BIGINT, radicado TEXT, id_persona BIGINT, id_estamento BIGINT, fecha_vence DATE) AS $$
DECLARE r RECORD;
BEGIN
    FOR r IN SELECT s.* FROM gobernanza.solicitud_afiliacion s
              WHERE s.estado = 'PENDIENTE' AND s.fecha_vence < gestion_documental.fn_hoy()
                AND gobernanza.fn_estado_documental(s.id_persona) = 'INCOMPLETA'
              FOR UPDATE LOOP
        PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', 'archivar');
        UPDATE gobernanza.solicitud_afiliacion x SET estado = 'ARCHIVADA', fecha_decision = now(), usuario_decision = 'sistema',
               observacion_decision = 'Archivada: venció el plazo de ' || gobernanza.fn_parametro_afiliacion('DIAS_VENCE_SOLICITUD')
                                      || ' días sin completar los documentos obligatorios.'
         WHERE x.id_solicitud_afiliacion = r.id_solicitud_afiliacion;
        PERFORM seguridad.fn_fijar_operacion('afiliacion.operacion', '');
        UPDATE seguridad.usuario u SET activo = FALSE, motivo_inactivacion = 'Solicitud de afiliación ' || r.radicado || ' archivada por vencimiento'
         WHERE u.id_persona = r.id_persona AND u.codigo_rol = 'AFILIADO' AND u.activo
           AND NOT EXISTS (SELECT 1 FROM gobernanza.afiliado a WHERE a.id_persona = r.id_persona AND a.activo);
        id_solicitud_afiliacion := r.id_solicitud_afiliacion; radicado := r.radicado; id_persona := r.id_persona;
        id_estamento := r.id_estamento; fecha_vence := r.fecha_vence;
        RETURN NEXT;
    END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 10. CUENTA DEL PORTAL DESDE LA SOLICITUD
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION seguridad.fn_crear_invitacion(p_id_persona BIGINT, p_hash_token TEXT)
RETURNS TABLE (correo TEXT, nombre TEXT, expira TIMESTAMPTZ) AS $$
DECLARE v_p RECORD; v_exp TIMESTAMPTZ := now() + INTERVAL '48 hours'; v_junta BIGINT;
BEGIN
    SELECT p.correo_electronico, p.primer_nombre, a.activo AS afiliado_activo, a.id_estamento_pertenencia,
           (SELECT s.id_estamento FROM gobernanza.solicitud_afiliacion s WHERE s.id_persona = p.id_persona AND s.estado = 'PENDIENTE') AS junta_solicitud
      INTO v_p
      FROM gobernanza.persona p LEFT JOIN gobernanza.afiliado a ON a.id_persona = p.id_persona WHERE p.id_persona = p_id_persona;
    IF v_p.correo_electronico IS NULL THEN RAISE EXCEPTION 'La persona no existe.'; END IF;
    IF NOT COALESCE(v_p.afiliado_activo, FALSE) AND v_p.junta_solicitud IS NULL THEN
        RAISE EXCEPTION 'Solo se invita al portal a afiliados activos o a quien tiene una solicitud de afiliación pendiente.';
    END IF;
    v_junta := CASE WHEN COALESCE(v_p.afiliado_activo, FALSE) THEN v_p.id_estamento_pertenencia ELSE v_p.junta_solicitud END;
    IF NOT (seguridad.fn_es_admin() OR seguridad.fn_ambito_nacional() OR v_junta = ANY (seguridad.fn_ambito_estamentos())) THEN
        RAISE EXCEPTION 'La persona está fuera de su ámbito territorial.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF seguridad.fn_rol_actual() IN ('AFILIADO') THEN RAISE EXCEPTION 'Su rol no puede invitar.'; END IF;
    IF EXISTS (SELECT 1 FROM seguridad.usuario u WHERE u.id_persona = p_id_persona AND u.activo AND u.codigo_rol = 'AFILIADO') THEN
        RAISE EXCEPTION 'La persona ya tiene una cuenta activa en el portal.';
    END IF;
    UPDATE seguridad.invitacion SET anulada = TRUE WHERE id_persona = p_id_persona AND tipo = 'CUENTA' AND usada_en IS NULL AND NOT anulada;
    INSERT INTO seguridad.invitacion (tipo, id_persona, correo, hash_token, expira)
    VALUES ('CUENTA', p_id_persona, v_p.correo_electronico, p_hash_token, v_exp);
    RETURN QUERY SELECT v_p.correo_electronico::TEXT, v_p.primer_nombre::TEXT, v_exp;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_activar_cuenta(p_hash_token TEXT, p_nombre_usuario TEXT, p_hash_contrasena TEXT,
                                                      p_acepta_politica BOOLEAN, p_acepta_comunicaciones BOOLEAN, p_acepta_imagen BOOLEAN)
RETURNS TEXT AS $$
DECLARE v_i seguridad.invitacion%ROWTYPE; v_p RECORD; v_id BIGINT; v_pol BIGINT;
BEGIN
    SELECT * INTO v_i FROM seguridad.invitacion WHERE hash_token = p_hash_token AND tipo = 'CUENTA' FOR UPDATE;
    IF v_i.id_invitacion IS NULL OR v_i.anulada THEN RAISE EXCEPTION 'El enlace no es válido. Pida a su junta una invitación nueva.'; END IF;
    IF v_i.usada_en IS NOT NULL THEN RAISE EXCEPTION 'Este enlace ya se usó. Si no fue usted, avise a su junta.'; END IF;
    IF v_i.expira <= now() THEN RAISE EXCEPTION 'El enlace venció (dura 48 horas). Pida a su junta una invitación nueva.'; END IF;
    IF NOT COALESCE(p_acepta_politica, FALSE) THEN
        RAISE EXCEPTION 'Para usar el portal debe aceptar la política de tratamiento de datos para la gestión sindical.';
    END IF;
    SELECT p.*, COALESCE(a.activo, FALSE) AS afiliado_activo,
           EXISTS (SELECT 1 FROM gobernanza.solicitud_afiliacion s WHERE s.id_persona = p.id_persona AND s.estado = 'PENDIENTE') AS solicitante
      INTO v_p FROM gobernanza.persona p
      LEFT JOIN gobernanza.afiliado a ON a.id_persona = p.id_persona WHERE p.id_persona = v_i.id_persona;
    IF NOT (v_p.afiliado_activo OR v_p.solicitante) THEN
        RAISE EXCEPTION 'La afiliación no está activa ni hay una solicitud de afiliación pendiente.';
    END IF;
    IF EXISTS (SELECT 1 FROM seguridad.usuario WHERE lower(nombre_usuario) = lower(p_nombre_usuario)) THEN
        RAISE EXCEPTION 'Ese nombre de usuario ya existe: elija otro.';
    END IF;
    INSERT INTO seguridad.usuario (nombre_usuario, nombre_completo, correo_electronico, hash_contrasena, codigo_rol, id_persona,
                                   debe_cambiar_contrasena)
    VALUES (p_nombre_usuario, v_p.primer_nombre || ' ' || v_p.primer_apellido, v_p.correo_electronico, p_hash_contrasena, 'AFILIADO',
            v_i.id_persona, FALSE)
    RETURNING id_usuario INTO v_id;
    UPDATE seguridad.invitacion SET usada_en = now(), id_usuario_creado = v_id WHERE id_invitacion = v_i.id_invitacion;
    -- Autorizaciones dadas en línea (Ley 1581), sobre la política vigente
    SELECT id_politica INTO v_pol FROM gobernanza.politica_tratamiento WHERE vigente;
    IF v_pol IS NOT NULL THEN
        INSERT INTO gobernanza.autorizacion_datos (id_persona, id_politica, codigo_finalidad, otorgada, medio, observaciones)
        VALUES (v_i.id_persona, v_pol, 'GESTION_SINDICAL', TRUE, 'PORTAL', 'Aceptada al activar la cuenta del portal'),
               (v_i.id_persona, v_pol, 'COMUNICACIONES', COALESCE(p_acepta_comunicaciones, FALSE), 'PORTAL', 'Al activar la cuenta del portal'),
               (v_i.id_persona, v_pol, 'IMAGEN', COALESCE(p_acepta_imagen, FALSE), 'PORTAL', 'Al activar la cuenta del portal');
    END IF;
    RETURN p_nombre_usuario;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 11. VISTAS
-- ----------------------------------------------------------------------------
-- Solicitudes: se agregan el estado de los documentos y el vencimiento (columnas nuevas al final)
CREATE OR REPLACE VIEW gobernanza.v_auditoria_solicitudes_afiliacion WITH (security_invoker = true) AS
SELECT s.radicado, e.nombre_estamento AS junta, p.primer_nombre || ' ' || p.primer_apellido AS solicitante,
       p.tipo_dni || ' ' || p.dni AS identificacion, em.nombre_empresa AS empresa, s.medio,
       s.fecha_creacion AS recibida, s.usuario_creacion AS recibida_por, s.estado,
       CASE
           WHEN s.estado <> 'PENDIENTE' THEN s.estado
           WHEN gobernanza.fn_estado_documental(s.id_persona) = 'COMPLETA' AND s.fecha_vence < gestion_documental.fn_hoy()
               THEN 'ALERTA CRÍTICA: DOCUMENTOS COMPLETOS Y EL PLAZO YA VENCIÓ: DECIDA LA SOLICITUD'
           WHEN gobernanza.fn_estado_documental(s.id_persona) = 'EN_REVISION' AND s.fecha_vence < gestion_documental.fn_hoy()
               THEN 'ALERTA CRÍTICA: EL PLAZO VENCIÓ CON DOCUMENTOS POR REVISAR: REVÍSELOS'
           WHEN s.fecha_vence < gestion_documental.fn_hoy() THEN 'ALERTA ALTA: VENCIÓ EL PLAZO CON DOCUMENTOS INCOMPLETOS (SE ARCHIVARÁ)'
           -- Los 15 días para decidir se cuentan desde que el expediente quedó completo, no desde la radicación
           WHEN gobernanza.fn_estado_documental(s.id_persona) = 'COMPLETA'
                AND (SELECT max(d.fecha_revision) FROM gobernanza.documento_afiliacion d
                       JOIN gobernanza.tipo_documento_afiliacion t USING (id_tipo_documento_afiliacion)
                      WHERE d.id_persona = s.id_persona AND d.vigente AND t.obligatorio) < now() - INTERVAL '15 days'
               THEN 'ALERTA ALTA: DOCUMENTOS COMPLETOS HACE MÁS DE 15 DÍAS Y LA SOLICITUD SIGUE SIN DECIDIR'
           WHEN gobernanza.fn_estado_documental(s.id_persona) = 'COMPLETA' THEN 'ALERTA MEDIA: DOCUMENTOS COMPLETOS: LISTA PARA DECIDIR'
           WHEN gobernanza.fn_estado_documental(s.id_persona) = 'EN_REVISION' THEN 'ALERTA MEDIA: HAY DOCUMENTOS POR REVISAR'
           WHEN s.fecha_vence - gestion_documental.fn_hoy() <= gobernanza.fn_parametro_afiliacion('DIAS_AVISO_VENCIMIENTO')
               THEN 'ALERTA BAJA: DOCUMENTOS INCOMPLETOS Y EL PLAZO ESTÁ POR VENCER'
           ELSE 'ESPERANDO LOS DOCUMENTOS DE LA PERSONA'
       END::VARCHAR AS diagnostico,
       s.id_solicitud_afiliacion, s.id_estamento,
       CASE WHEN s.estado = 'PENDIENTE' THEN gobernanza.fn_estado_documental(s.id_persona) END AS estado_documental,
       s.fecha_vence, s.id_persona
  FROM gobernanza.solicitud_afiliacion s
  JOIN gobernanza.persona p ON p.id_persona = s.id_persona
  JOIN gobernanza.estamento e ON e.id_estamento = s.id_estamento
  JOIN gobernanza.empresa em ON em.id_empresa = s.id_empresa;

-- Afiliados actuales con el expediente incompleto (informativa: no bloquea nada)
CREATE OR REPLACE VIEW gobernanza.v_expedientes_incompletos WITH (security_invoker = true) AS
SELECT e.nombre_estamento AS junta, p.primer_nombre || ' ' || p.primer_apellido AS afiliado, p.tipo_dni || ' ' || p.dni AS identificacion,
       a.fecha_afiliacion, gobernanza.fn_estado_documental(a.id_persona) AS estado_documental,
       (SELECT string_agg(t.nombre, ', ' ORDER BY t.orden) FROM gobernanza.tipo_documento_afiliacion t
         WHERE t.obligatorio AND t.activo AND NOT EXISTS (
               SELECT 1 FROM gobernanza.documento_afiliacion d WHERE d.id_persona = a.id_persona AND d.vigente
                  AND d.id_tipo_documento_afiliacion = t.id_tipo_documento_afiliacion AND d.estado IN ('POR_REVISAR', 'ACEPTADO'))) AS faltan,
       a.id_persona, a.id_estamento_pertenencia AS id_estamento
  FROM gobernanza.afiliado a
  JOIN gobernanza.persona p ON p.id_persona = a.id_persona
  JOIN gobernanza.estamento e ON e.id_estamento = a.id_estamento_pertenencia
 WHERE a.activo AND gobernanza.fn_estado_documental(a.id_persona) <> 'COMPLETA';

-- Historial de pertenencia legible
CREATE OR REPLACE VIEW gobernanza.v_historial_pertenencia WITH (security_invoker = true) AS
SELECT h.fecha_registro, p.primer_nombre || ' ' || p.primer_apellido AS afiliado, p.tipo_dni || ' ' || p.dni AS identificacion,
       ea.nombre_estamento AS de, en.nombre_estamento AS a, h.disperso, d.radicado_alfanumerico AS acta, h.motivo, h.usuario_registro,
       h.id_persona, h.id_estamento_nuevo AS id_estamento
  FROM gobernanza.historial_pertenencia h
  JOIN gobernanza.persona p ON p.id_persona = h.id_persona
  LEFT JOIN gobernanza.estamento ea ON ea.id_estamento = h.id_estamento_anterior
  LEFT JOIN gobernanza.estamento en ON en.id_estamento = h.id_estamento_nuevo
  LEFT JOIN gestion_documental.documento d ON d.id_documento = h.id_acta;

CREATE OR REPLACE FUNCTION seguridad.fn_tiene_cuenta_portal(p_id_persona BIGINT)
RETURNS BOOLEAN AS $$
    SELECT EXISTS (SELECT 1 FROM seguridad.usuario u WHERE u.id_persona = p_id_persona AND u.codigo_rol = 'AFILIADO' AND u.activo);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Insumo del proceso de correos: solicitudes pendientes con lo que le falta a cada una
CREATE OR REPLACE VIEW gobernanza.v_seguimiento_solicitudes_afiliacion WITH (security_invoker = true) AS
SELECT s.id_solicitud_afiliacion, s.radicado, s.id_persona, s.id_estamento, e.nombre_estamento AS junta,
       e.id_estamento = gobernanza.fn_id_jdn() AS disperso,
       p.primer_nombre, p.primer_apellido, p.correo_electronico AS correo,
       (s.fecha_creacion AT TIME ZONE gestion_documental.fn_zona())::DATE AS fecha, s.fecha_vence,
       gestion_documental.fn_hoy() - (s.fecha_creacion AT TIME ZONE gestion_documental.fn_zona())::DATE AS dias_desde,
       s.fecha_vence - gestion_documental.fn_hoy() AS dias_para_vencer,
       gobernanza.fn_estado_documental(s.id_persona) AS estado_documental,
       (SELECT count(*) FROM gobernanza.documento_afiliacion d WHERE d.id_persona = s.id_persona AND d.vigente AND d.estado = 'POR_REVISAR') AS por_revisar,
       (SELECT string_agg(t.nombre, ', ' ORDER BY t.orden) FROM gobernanza.tipo_documento_afiliacion t
         WHERE t.obligatorio AND t.activo AND NOT EXISTS (
               SELECT 1 FROM gobernanza.documento_afiliacion d WHERE d.id_persona = s.id_persona AND d.vigente
                  AND d.id_tipo_documento_afiliacion = t.id_tipo_documento_afiliacion AND d.estado IN ('POR_REVISAR', 'ACEPTADO'))) AS faltan,
       seguridad.fn_tiene_cuenta_portal(s.id_persona) AS tiene_cuenta
  FROM gobernanza.solicitud_afiliacion s
  JOIN gobernanza.persona p ON p.id_persona = s.id_persona
  JOIN gobernanza.estamento e ON e.id_estamento = s.id_estamento
 WHERE s.estado = 'PENDIENTE';

-- ----------------------------------------------------------------------------
-- 12. CORREOS AUTOMÁTICOS
-- ----------------------------------------------------------------------------
INSERT INTO notificaciones.tipo_notificacion (codigo, nombre, descripcion) VALUES
    ('EXPEDIENTE_AFILIACION', 'Documentos de las solicitudes de afiliación',
     'A la persona: recordatorios a los 3 y 10 días si le faltan documentos, aviso 10 días antes del vencimiento y aviso cuando su solicitud se archiva (60 días sin documentos completos). A la junta (para los dispersos, a los directivos nacionales): resumen diario de documentos por revisar y de solicitudes listas para decidir.')
ON CONFLICT (codigo) DO NOTHING;

-- ----------------------------------------------------------------------------
-- 13. PERMISOS
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        GRANT SELECT, UPDATE ON gobernanza.dato_institucional, gobernanza.parametro_afiliacion TO sgs_app;
        GRANT SELECT, INSERT, UPDATE ON gobernanza.tipo_documento_afiliacion TO sgs_app;
        GRANT SELECT ON gobernanza.historial_pertenencia TO sgs_app;
        GRANT SELECT ON gobernanza.v_auditoria_solicitudes_afiliacion, gobernanza.v_expedientes_incompletos,
                        gobernanza.v_historial_pertenencia, gobernanza.v_afiliados_sin_pertenencia TO sgs_app;
        -- documento_afiliacion: sin permisos directos; solo por las funciones del expediente
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_lectura') THEN
        GRANT SELECT ON gobernanza.dato_institucional, gobernanza.parametro_afiliacion, gobernanza.tipo_documento_afiliacion,
                        gobernanza.historial_pertenencia, gobernanza.v_historial_pertenencia TO sgs_lectura;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_notificador') THEN
        GRANT SELECT ON gobernanza.dato_institucional, gobernanza.v_seguimiento_solicitudes_afiliacion, gobernanza.solicitud_afiliacion,
                        gobernanza.documento_afiliacion, gobernanza.tipo_documento_afiliacion, gobernanza.parametro_afiliacion TO sgs_notificador;
    END IF;
END $$;

-- Las columnas nuevas de persona y solicitud quedan legibles (las reservadas, como el salario y el género, siguen reservadas)
DO $$ BEGIN PERFORM seguridad.fn_aplicar_reserva_columnas(); END $$;

-- Las funciones internas y el archivo de vencidas no se llaman desde la aplicación
REVOKE EXECUTE ON FUNCTION gobernanza.fn_archivar_solicitudes_vencidas() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION gobernanza.fn_rellenar_institucional(TEXT) FROM PUBLIC;
DO $$
DECLARE r TEXT;
BEGIN
    FOREACH r IN ARRAY ARRAY['sgs_app', 'sgs_lectura'] LOOP
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
            EXECUTE format('REVOKE EXECUTE ON FUNCTION gobernanza.fn_archivar_solicitudes_vencidas() FROM %I', r);
        END IF;
    END LOOP;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_notificador') THEN
        GRANT EXECUTE ON FUNCTION gobernanza.fn_archivar_solicitudes_vencidas() TO sgs_notificador;
    END IF;
END $$;

DO $$ BEGIN
    PERFORM seguridad.fn_aplicar_politicas('gobernanza.dato_institucional', 'TRUE', 'seguridad.fn_es_admin()');
    PERFORM seguridad.fn_aplicar_politicas('gobernanza.parametro_afiliacion', 'TRUE', 'seguridad.fn_es_admin()');
    PERFORM seguridad.fn_aplicar_politicas('gobernanza.tipo_documento_afiliacion', 'TRUE',
                                           'seguridad.fn_es_admin() OR seguridad.fn_es_presidente_nacional()');
    PERFORM seguridad.fn_aplicar_politicas('gobernanza.documento_afiliacion', 'FALSE', 'FALSE');
    PERFORM seguridad.fn_aplicar_politicas('gobernanza.historial_pertenencia',
        ':N OR id_estamento_nuevo = ANY (:E) OR id_estamento_anterior = ANY (:E)', 'FALSE');
END $$;
