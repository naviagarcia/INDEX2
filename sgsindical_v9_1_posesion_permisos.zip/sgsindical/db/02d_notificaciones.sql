-- ============================================================================
-- SGSINDICAL v9.1 — 02d: CORREOS AUTOMÁTICOS DE ALERTAS
-- Ejecutar DESPUÉS de 02c y ANTES de 03.
-- ----------------------------------------------------------------------------
--  · Catálogo de tipos de correo (el administrador los activa o desactiva).
--  · Registro de envíos: cada correo tiene una clave única; si ya se envió, no se repite.
--  · Informes de gestión: obligación TRIMESTRAL (90 días) por cada cargo.
-- ============================================================================
CREATE SCHEMA IF NOT EXISTS notificaciones;

CREATE TABLE IF NOT EXISTS notificaciones.tipo_notificacion (
    codigo VARCHAR(30) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    version INT NOT NULL DEFAULT 1
);

ALTER TABLE notificaciones.tipo_notificacion ADD COLUMN IF NOT EXISTS dias_umbral INT CHECK (dias_umbral > 0);
COMMENT ON COLUMN notificaciones.tipo_notificacion.dias_umbral IS 'Plazo en días que dispara la alerta (cuando aplica).';

INSERT INTO notificaciones.tipo_notificacion (codigo, nombre, descripcion, dias_umbral) VALUES
    ('ACTAS_REUNION', 'Juntas sin acta de reunión mensual',
     'Las juntas deben reunirse al menos una vez al mes. Cada semana, a todos los directivos vigentes de la junta que '
     'no radicó acta (ACT) el mes anterior ni en el mes en curso, o a la que le falta una semana para cerrar el mes sin acta. '
     'Consolidado semanal al Presidente, Secretario General y Fiscal Nacional.', NULL)
ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, descripcion = EXCLUDED.descripcion, dias_umbral = NULL;

INSERT INTO notificaciones.tipo_notificacion (codigo, nombre, descripcion) VALUES
    ('VIGENCIA_DIRECTIVO', 'Vencimiento del periodo personal',
     'Al directivo, con copia al presidente de su junta, cuando faltan 90, 60 y 30 días, y cada mes si ya venció.'),
    ('INFORME_TRIMESTRAL', 'Informe de gestión trimestral',
     'Al directivo, con copia al presidente de su junta, 15 días antes del vencimiento del trimestre y cada mes si está vencido.'),
    ('INACTIVIDAD_DOCUMENTAL', 'Inactividad documental',
     'Resumen semanal al presidente y al secretario general de cada junta con los tipos de documento sin emitir hace más de 30 días.'),
    ('CUMPLEANOS', 'Saludo de cumpleaños', 'Saludo al afiliado el día de su cumpleaños.')
ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, descripcion = EXCLUDED.descripcion;

CREATE TABLE IF NOT EXISTS notificaciones.registro_envio (
    id_envio BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    codigo_tipo VARCHAR(30) NOT NULL REFERENCES notificaciones.tipo_notificacion(codigo),
    clave VARCHAR(200) NOT NULL,
    destinatario VARCHAR(100) NOT NULL,
    copia TEXT,
    asunto VARCHAR(250) NOT NULL,
    estado VARCHAR(12) NOT NULL DEFAULT 'PENDIENTE' CHECK (estado IN ('PENDIENTE', 'ENVIADO', 'FALLIDO', 'SIMULADO')),
    detalle TEXT,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_envio TIMESTAMP WITH TIME ZONE
);
COMMENT ON TABLE notificaciones.registro_envio IS 'Historial de correos. La clave evita enviar dos veces la misma alerta; los fallidos se reintentan.';
-- Sin duplicados aunque dos procesos corran a la vez: una clave solo puede estar pendiente o enviada una vez.
CREATE UNIQUE INDEX IF NOT EXISTS ux_envio_clave ON notificaciones.registro_envio (clave) WHERE estado IN ('PENDIENTE', 'ENVIADO');
CREATE INDEX IF NOT EXISTS ix_envio_fecha ON notificaciones.registro_envio (fecha_creacion DESC);
CREATE INDEX IF NOT EXISTS ix_envio_tipo ON notificaciones.registro_envio (codigo_tipo, fecha_creacion DESC);

DROP TRIGGER IF EXISTS trg_control_version ON notificaciones.tipo_notificacion;
CREATE TRIGGER trg_control_version BEFORE UPDATE ON notificaciones.tipo_notificacion
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version();
DROP TRIGGER IF EXISTS trg_auditoria ON notificaciones.tipo_notificacion;
CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON notificaciones.tipo_notificacion
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria();

-- Presidente vigente de una junta (Presidente Nal, Reg o Comité según el tipo de estamento)
CREATE OR REPLACE FUNCTION notificaciones.fn_directivo_por_cargo(p_id_estamento BIGINT, p_prefijo TEXT)
RETURNS BIGINT AS $$
    SELECT d.id_persona FROM gobernanza.directivo_estamento d
      JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
     WHERE d.id_estamento = p_id_estamento AND d.fecha_retiro IS NULL AND c.codigo LIKE p_prefijo || '\_%'
     ORDER BY d.fecha_posesion_individual DESC LIMIT 1;
$$ LANGUAGE sql STABLE;

-- ----------------------------------------------------------------------------
-- INFORMES DE GESTIÓN: obligación trimestral, por cargo y por junta
--   Referencia = último informe (INF) emitido por el directivo en ESA junta, o su posesión.
--   Vence a los 90 días de la referencia.
-- ----------------------------------------------------------------------------
DROP VIEW IF EXISTS gestion_documental.v_auditoria_informes_directivos;
CREATE VIEW gestion_documental.v_auditoria_informes_directivos WITH (security_invoker = true) AS
WITH informes AS (
    SELECT d.id_persona_remitente, d.id_estamento, MAX(d.fecha_radicacion) AS fecha_ultimo_informe, COUNT(*) AS total
      FROM gestion_documental.documento d
      JOIN gestion_documental.tipo_documento t ON t.id_tipo_documento = d.id_tipo_documento
     WHERE t.sigla_tipo = 'INF' AND d.flujo = 'EMITIDO' AND d.estado_tramite <> 'ANULADO'
     GROUP BY d.id_persona_remitente, d.id_estamento
), base AS (
    SELECT dir.*, inf.fecha_ultimo_informe, COALESCE(inf.total, 0) AS total,
           GREATEST(COALESCE(inf.fecha_ultimo_informe::DATE, dir.fecha_posesion_individual), dir.fecha_posesion_individual) AS fecha_referencia
      FROM gobernanza.directivo_estamento dir
      LEFT JOIN informes inf ON inf.id_persona_remitente = dir.id_persona AND inf.id_estamento = dir.id_estamento
     WHERE dir.fecha_retiro IS NULL
)
SELECT
    b.id_directivo_estamento,
    p.tipo_dni || ' ' || p.dni AS identificacion,
    p.primer_nombre || ' ' || COALESCE(p.segundo_nombre || ' ', '') || p.primer_apellido AS nombre_directivo,
    b.rol_estamento AS cargo_directivo,
    e.nombre_estamento,
    e.tipo_estamento AS ambito_territorial,
    b.fecha_posesion_individual,
    b.fecha_ultimo_informe,
    b.total AS total_informes_historicos,
    (b.fecha_referencia + 90) AS fecha_limite_informe,
    ((CURRENT_DATE - b.fecha_referencia) / 30)::INT AS meses_sin_informe,
    (CURRENT_DATE - b.fecha_referencia)::INT AS dias_sin_informe,
    ((b.fecha_referencia + 90) - CURRENT_DATE)::INT AS dias_para_vencer,
    CASE
        WHEN CURRENT_DATE > b.fecha_referencia + 90 AND b.fecha_ultimo_informe IS NULL
            THEN 'ALERTA CRÍTICA: NO HA RENDIDO SU PRIMER INFORME TRIMESTRAL'
        WHEN CURRENT_DATE > b.fecha_referencia + 90 THEN 'ALERTA CRÍTICA: INFORME TRIMESTRAL VENCIDO'
        WHEN (b.fecha_referencia + 90) - CURRENT_DATE <= 15 THEN 'ALERTA ALTA: EL INFORME TRIMESTRAL VENCE EN 15 DÍAS O MENOS'
        WHEN (b.fecha_referencia + 90) - CURRENT_DATE <= 30 THEN 'ALERTA MEDIA: EL INFORME TRIMESTRAL VENCE EN MENOS DE 30 DÍAS'
        ELSE 'AL DÍA CON EL INFORME TRIMESTRAL'
    END AS diagnostico_auditoria_informe
FROM base b
JOIN gobernanza.persona p ON p.id_persona = b.id_persona
JOIN gobernanza.estamento e ON e.id_estamento = b.id_estamento;

GRANT EXECUTE ON FUNCTION notificaciones.fn_directivo_por_cargo(BIGINT, TEXT) TO PUBLIC;

-- ----------------------------------------------------------------------------
-- ACTAS DE REUNIÓN: las juntas deben reunirse AL MENOS UNA VEZ POR MES CALENDARIO
--   Inicio de la junta = posesión más antigua de sus directivos vigentes (una junta nueva
--   no responde por meses anteriores a su conformación).
-- ----------------------------------------------------------------------------
DROP VIEW IF EXISTS gestion_documental.v_auditoria_actas_juntas;
CREATE VIEW gestion_documental.v_auditoria_actas_juntas WITH (security_invoker = true) AS
WITH mes AS (
    SELECT date_trunc('month', CURRENT_DATE)::DATE AS actual,
           (date_trunc('month', CURRENT_DATE) - INTERVAL '1 month')::DATE AS anterior,
           (date_trunc('month', CURRENT_DATE) + INTERVAL '1 month' - INTERVAL '1 day')::DATE AS fin_actual
), juntas AS (
    SELECT e.id_estamento, e.nombre_estamento, e.tipo_estamento, COUNT(*) AS directivos_vigentes,
           MIN(d.fecha_posesion_individual) AS inicio_junta
      FROM gobernanza.estamento e
      JOIN gobernanza.directivo_estamento d ON d.id_estamento = e.id_estamento AND d.fecha_retiro IS NULL
     GROUP BY e.id_estamento, e.nombre_estamento, e.tipo_estamento
), actas AS (
    SELECT d.id_estamento, d.fecha_radicacion::DATE AS fecha
      FROM gestion_documental.documento d
      JOIN gestion_documental.tipo_documento t ON t.id_tipo_documento = d.id_tipo_documento
     WHERE t.sigla_tipo = 'ACT' AND d.flujo = 'EMITIDO' AND d.estado_tramite <> 'ANULADO'
), resumen AS (
    SELECT j.*, m.actual, m.anterior, m.fin_actual,
           (SELECT MAX(a.fecha) FROM actas a WHERE a.id_estamento = j.id_estamento) AS fecha_ultima_acta,
           (SELECT COUNT(*) FROM actas a WHERE a.id_estamento = j.id_estamento AND a.fecha >= m.actual) AS actas_mes_actual,
           (SELECT COUNT(*) FROM actas a WHERE a.id_estamento = j.id_estamento
               AND a.fecha >= m.anterior AND a.fecha < m.actual) AS actas_mes_anterior,
           (SELECT COUNT(*) FROM generate_series(GREATEST(date_trunc('month', j.inicio_junta)::DATE, (m.actual - INTERVAL '12 months')::DATE),
                                                 m.anterior, INTERVAL '1 month') g(mes)
             WHERE NOT EXISTS (SELECT 1 FROM actas a WHERE a.id_estamento = j.id_estamento
                                  AND a.fecha >= g.mes AND a.fecha < g.mes + INTERVAL '1 month')) AS meses_incumplidos_ultimo_anio
      FROM juntas j CROSS JOIN mes m
)
SELECT
    id_estamento,
    nombre_estamento,
    tipo_estamento AS ambito_territorial,
    directivos_vigentes,
    fecha_ultima_acta,
    (CURRENT_DATE - fecha_ultima_acta) AS dias_desde_ultima_acta,
    actas_mes_anterior,
    actas_mes_actual,
    (fin_actual - CURRENT_DATE) AS dias_para_cerrar_mes,
    meses_incumplidos_ultimo_anio,
    CASE
        WHEN inicio_junta < actual AND actas_mes_anterior = 0 AND actas_mes_actual = 0
            THEN 'ALERTA CRÍTICA: SIN ACTA EL MES ANTERIOR NI EN EL MES EN CURSO'
        WHEN actas_mes_actual = 0 AND fin_actual - CURRENT_DATE <= 7
            THEN 'ALERTA ALTA: EL MES TERMINA EN 7 DÍAS O MENOS SIN ACTA DE REUNIÓN'
        WHEN inicio_junta < actual AND actas_mes_anterior = 0
            THEN 'ALERTA MEDIA: INCUMPLIÓ LA REUNIÓN DEL MES ANTERIOR'
        WHEN actas_mes_actual = 0 THEN 'PENDIENTE LA REUNIÓN DE ESTE MES'
        ELSE 'REUNIÓN MENSUAL AL DÍA'
    END AS diagnostico
FROM resumen;
