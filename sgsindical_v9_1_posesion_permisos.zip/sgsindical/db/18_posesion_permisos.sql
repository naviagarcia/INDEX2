-- ============================================================================
-- SGSINDICAL v9.1 · 18_posesion_permisos.sql
-- Posesión de directivos con el registro del inspector y permisos sindicales.
--
--  A. POSESIÓN. La fecha de posesión de un directivo es la fecha en que el inspector de trabajo
--     emite el registro que lo incluye. Así se evita que un directivo ejerza el cargo (firme, apruebe,
--     pida permisos sindicales, vea datos de su junta) o se registre una fecha de posesión a conveniencia
--     antes de que el inspector lo registre.
--     1. La junta DESIGNA (elección, reelección o rotación) con su acta. La designación queda PENDIENTE.
--     2. Cuando se registra el registro del inspector, ARCADIO da posesión a las designaciones pendientes
--        de esa junta con la fecha del registro, y retira ese mismo día a quienes salen del cargo.
--     3. Solo ejerce el cargo quien está inscrito en un registro y ya se posesionó (vista «Cargos en
--        ejercicio»). Un nombramiento cargado directamente que no figura en ningún registro queda
--        «sin registro»: no ejerce hasta que el inspector emita el registro siguiente.
--     4. La fecha de emisión de un registro no puede ser futura.
--  B. PERMISOS SINDICALES (art. 2.2.2.5.3 y 2.2.2.5.4 del Decreto 1072 de 2015, modificados por el
--     Decreto 720 de 2024).
--     1. Solo los solicitan por escrito el Presidente o el Secretario General que ejercen hoy el cargo
--        (nacional, de subdirectiva o de comité; también quien los suple).
--     2. Pueden pedirlos para un afiliado: la Junta Directiva Nacional (para cualquiera), la junta a la que
--        pertenece y la junta del municipio de la sede central de su empresa. Se dirigen a la sede central.
--     3. Antelación: 8 días hábiles si hay delegados (asambleas, negociación colectiva, capacitación) y
--        4 si todos son directivos; 1 día en casos excepcionales, con el motivo.
--     4. La entidad responde con acto administrativo motivado, notificado al menos 3 días hábiles antes
--        del inicio. Sin respuesta a tiempo, el permiso se entiende concedido (silencio). La única causal
--        para negarlo o limitarlo es la afectación de la debida prestación del servicio.
--     5. Un afiliado no puede tener dos permisos activos que se crucen en fechas (aunque los pidan juntas
--        distintas). Se cuentan los días hábiles solicitados, concedidos y negados.
-- No modifica los scripts anteriores. Se puede ejecutar más de una vez.
-- ============================================================================
SET client_min_messages = warning;

-- ============================================================================
-- A. POSESIÓN CON EL REGISTRO DEL INSPECTOR
-- ============================================================================
-- ----------------------------------------------------------------------------
-- A1. Inscripción de cada nombramiento
-- ----------------------------------------------------------------------------
ALTER TABLE gobernanza.directivo_estamento
    ADD COLUMN IF NOT EXISTS fecha_inscripcion DATE,
    ADD COLUMN IF NOT EXISTS origen_posesion VARCHAR(10)
        CHECK (origen_posesion IN ('REGISTRO', 'DIRECTO', 'ANTERIOR'));
COMMENT ON COLUMN gobernanza.directivo_estamento.fecha_inscripcion IS
    'Fecha del registro del inspector que incluye este nombramiento. Vacía = el inspector aún no lo registra: no ejerce el cargo.';
COMMENT ON COLUMN gobernanza.directivo_estamento.origen_posesion IS
    'REGISTRO = posesión dada por ARCADIO con la fecha del registro (designación). DIRECTO = nombramiento cargado a mano. ANTERIOR = existía antes del bloque 18.';

-- Los nombramientos que ya existían se consideran inscritos con su posesión (sin volver a validar las reglas)
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM gobernanza.directivo_estamento WHERE origen_posesion IS NULL) THEN
        PERFORM set_config('session_replication_role', 'replica', true);
        UPDATE gobernanza.directivo_estamento
           SET fecha_inscripcion = fecha_posesion_individual, origen_posesion = 'ANTERIOR'
         WHERE origen_posesion IS NULL;
        PERFORM set_config('session_replication_role', 'origin', true);
    END IF;
END $$;
CREATE INDEX IF NOT EXISTS ix_directivo_sin_inscripcion ON gobernanza.directivo_estamento (id_estamento)
    WHERE fecha_inscripcion IS NULL AND fecha_retiro IS NULL;

CREATE OR REPLACE FUNCTION gobernanza.fn_fecha_registro(p_id_registro BIGINT)
RETURNS DATE AS $$
    SELECT (fecha_emision_registro AT TIME ZONE gestion_documental.fn_zona())::DATE
      FROM gobernanza.registro_inspector_estamento WHERE id_registro = p_id_registro;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Se ejecuta después de las validaciones de cargos (trg_validar_directivo): fija la inscripción
CREATE OR REPLACE FUNCTION gobernanza.fn_inscripcion_directivo()
RETURNS TRIGGER AS $$
DECLARE v_fecha_reg DATE := gobernanza.fn_fecha_registro(NEW.id_registro_inspector);
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF COALESCE(seguridad.fn_operacion('designacion.operacion'), '') = 'posesionar' THEN
            NEW.origen_posesion := 'REGISTRO';
            NEW.fecha_inscripcion := NEW.fecha_posesion_individual;
        ELSE
            NEW.origen_posesion := 'DIRECTO';
            IF v_fecha_reg >= NEW.fecha_posesion_individual THEN
                -- El registro se emitió después de la posesión: lo incluye (carga de juntas ya registradas)
                NEW.fecha_inscripcion := v_fecha_reg;
            ELSIF EXISTS (SELECT 1 FROM pg_roles r WHERE r.rolname = session_user AND r.rolsuper) THEN
                -- Carga de instalación o de mantenimiento (superusuario, fuera de la aplicación)
                NEW.fecha_inscripcion := NEW.fecha_posesion_individual;
            ELSE
                NEW.fecha_inscripcion := NULL;   -- sin registro: no ejerce hasta el próximo registro
            END IF;
        END IF;
        RETURN NEW;
    END IF;

    -- UPDATE: la inscripción y el origen no se escriben a mano
    NEW.fecha_inscripcion := OLD.fecha_inscripcion;
    NEW.origen_posesion := OLD.origen_posesion;
    IF OLD.origen_posesion = 'REGISTRO' AND NEW.fecha_posesion_individual IS DISTINCT FROM OLD.fecha_posesion_individual THEN
        RAISE EXCEPTION 'La fecha de posesión de este directivo es la del registro del inspector (%) y no se modifica.',
            to_char(OLD.fecha_posesion_individual, 'DD/MM/YYYY');
    END IF;
    -- Un registro nuevo que se emite después de la posesión inscribe a quien estaba sin registro
    IF NEW.fecha_inscripcion IS NULL AND NEW.fecha_retiro IS NULL
       AND NEW.id_registro_inspector IS DISTINCT FROM OLD.id_registro_inspector
       AND v_fecha_reg >= NEW.fecha_posesion_individual THEN
        NEW.fecha_inscripcion := v_fecha_reg;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_zz_inscripcion ON gobernanza.directivo_estamento;
CREATE TRIGGER trg_zz_inscripcion BEFORE INSERT OR UPDATE ON gobernanza.directivo_estamento
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_inscripcion_directivo();

-- La fecha de emisión de un registro no puede ser futura
CREATE OR REPLACE FUNCTION gobernanza.fn_validar_fecha_registro()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.fecha_emision_registro > now() + INTERVAL '5 minutes' THEN
        RAISE EXCEPTION 'La fecha de emisión del registro no puede ser futura: regístrelo cuando el inspector lo haya emitido.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_validar_fecha_registro ON gobernanza.registro_inspector_estamento;
CREATE TRIGGER trg_validar_fecha_registro BEFORE INSERT OR UPDATE OF fecha_emision_registro ON gobernanza.registro_inspector_estamento
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_validar_fecha_registro();

-- ----------------------------------------------------------------------------
-- A2. Quién ejerce hoy cada cargo: solo quien está inscrito y ya se posesionó (o su suplente)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW gobernanza.v_cargos_en_ejercicio WITH (security_invoker = true) AS
SELECT d.id_estamento, d.id_cargo, c.codigo, c.nombre, c.orden, c.acceso_nacional, d.id_persona,
       d.fecha_posesion_individual AS desde, FALSE AS por_suplencia, NULL::BIGINT AS id_suplencia
  FROM gobernanza.directivo_estamento d
  JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
 WHERE d.fecha_retiro IS NULL
   AND d.fecha_inscripcion IS NOT NULL
   AND d.fecha_posesion_individual <= gestion_documental.fn_hoy()
   AND NOT EXISTS (SELECT 1 FROM gobernanza.suplencia s
                    WHERE s.id_estamento = d.id_estamento AND s.id_cargo = d.id_cargo AND s.id_persona_titular = d.id_persona
                      AND s.estado = 'VIGENTE' AND gestion_documental.fn_hoy() BETWEEN s.desde AND s.hasta)
UNION ALL
SELECT s.id_estamento, s.id_cargo, c.codigo, c.nombre, c.orden, c.acceso_nacional, s.id_persona_suplente,
       s.desde, TRUE, s.id_suplencia
  FROM gobernanza.suplencia s
  JOIN gobernanza.cargo_directivo c ON c.id_cargo = s.id_cargo
 WHERE s.estado = 'VIGENTE' AND gestion_documental.fn_hoy() BETWEEN s.desde AND s.hasta;
COMMENT ON VIEW gobernanza.v_cargos_en_ejercicio IS
    'Quién ejerce hoy cada cargo: el titular inscrito en un registro del inspector y ya posesionado (si no está suplido) o su suplente.';

-- ----------------------------------------------------------------------------
-- A3. Designaciones de la junta, pendientes del registro del inspector
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.designacion_directivo (
    id_designacion BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.afiliado(id_persona) ON DELETE RESTRICT,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    id_cargo BIGINT NOT NULL REFERENCES gobernanza.cargo_directivo(id_cargo) ON DELETE RESTRICT,
    tipo_nombramiento VARCHAR(12) NOT NULL CHECK (tipo_nombramiento IN ('ELECCION', 'REELECCION', 'ROTACION')),
    id_acta BIGINT NOT NULL REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    fecha_designacion DATE NOT NULL,
    id_directivo_saliente BIGINT REFERENCES gobernanza.directivo_estamento(id_directivo_estamento) ON DELETE RESTRICT,
    observacion TEXT,
    estado VARCHAR(11) NOT NULL DEFAULT 'PENDIENTE' CHECK (estado IN ('PENDIENTE', 'POSESIONADA', 'ANULADA')),
    id_registro BIGINT REFERENCES gobernanza.registro_inspector_estamento(id_registro) ON DELETE RESTRICT,
    id_directivo_estamento BIGINT REFERENCES gobernanza.directivo_estamento(id_directivo_estamento) ON DELETE RESTRICT,
    fecha_posesion DATE,
    usuario_registra VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    fecha_registra TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    motivo_anulacion TEXT,
    usuario_anula VARCHAR(50),
    fecha_anula TIMESTAMP WITH TIME ZONE,
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_designacion_posesionada CHECK (estado <> 'POSESIONADA' OR (id_registro IS NOT NULL AND id_directivo_estamento IS NOT NULL AND fecha_posesion IS NOT NULL))
);
COMMENT ON TABLE gobernanza.designacion_directivo IS
    'Elección, reelección o rotación decidida por la junta con su acta. Queda PENDIENTE hasta que el inspector emite el registro: ese día ARCADIO da la posesión (con la fecha del registro) y retira a quien sale.';
CREATE UNIQUE INDEX IF NOT EXISTS ux_designacion_cargo_pendiente ON gobernanza.designacion_directivo (id_estamento, id_cargo) WHERE estado = 'PENDIENTE';
CREATE UNIQUE INDEX IF NOT EXISTS ux_designacion_persona_pendiente ON gobernanza.designacion_directivo (id_estamento, id_persona) WHERE estado = 'PENDIENTE';
CREATE INDEX IF NOT EXISTS ix_designacion_persona ON gobernanza.designacion_directivo (id_persona);
CREATE INDEX IF NOT EXISTS ix_designacion_cargo ON gobernanza.designacion_directivo (id_cargo);
CREATE INDEX IF NOT EXISTS ix_designacion_acta ON gobernanza.designacion_directivo (id_acta);
CREATE INDEX IF NOT EXISTS ix_designacion_saliente ON gobernanza.designacion_directivo (id_directivo_saliente);
CREATE INDEX IF NOT EXISTS ix_designacion_registro ON gobernanza.designacion_directivo (id_registro);
CREATE INDEX IF NOT EXISTS ix_designacion_directivo ON gobernanza.designacion_directivo (id_directivo_estamento);

CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_designacion()
RETURNS TRIGGER AS $$
BEGIN
    IF COALESCE(seguridad.fn_operacion('designacion.operacion'), '') = '' THEN
        RAISE EXCEPTION 'La designación se registra con sus acciones: designar o anular. La posesión la da el registro del inspector.';
    END IF;
    IF TG_OP = 'UPDATE' AND OLD.estado <> 'PENDIENTE' THEN RAISE EXCEPTION 'Una designación posesionada o anulada no se modifica.'; END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_proteger_designacion ON gobernanza.designacion_directivo;
CREATE TRIGGER trg_proteger_designacion BEFORE INSERT OR UPDATE ON gobernanza.designacion_directivo
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_proteger_designacion();
DROP TRIGGER IF EXISTS trg_no_borrar ON gobernanza.designacion_directivo;
CREATE TRIGGER trg_no_borrar BEFORE DELETE ON gobernanza.designacion_directivo FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado();
DROP TRIGGER IF EXISTS trg_auditoria ON gobernanza.designacion_directivo;
CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON gobernanza.designacion_directivo
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria();
DROP TRIGGER IF EXISTS trg_control_version ON gobernanza.designacion_directivo;
CREATE TRIGGER trg_control_version BEFORE UPDATE ON gobernanza.designacion_directivo
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version();

-- Identificación de un beneficiario de permiso: la ve la junta que lo pidió aunque no sea de su ámbito
CREATE OR REPLACE FUNCTION gobernanza.fn_identificacion_persona(p_id_persona BIGINT)
RETURNS TEXT AS $$
    SELECT p.tipo_dni || ' ' || p.dni FROM gobernanza.persona p WHERE p.id_persona = p_id_persona;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_nombre_persona(p_id_persona BIGINT)
RETURNS TEXT AS $$
    SELECT trim(p.primer_nombre || ' ' || COALESCE(p.segundo_nombre || ' ', '') || p.primer_apellido || COALESCE(' ' || p.segundo_apellido, ''))
      FROM gobernanza.persona p WHERE p.id_persona = p_id_persona;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Quien puede designar: el ámbito de la junta (nacional o la propia junta) con permiso de gobernanza
CREATE OR REPLACE FUNCTION gobernanza.fn_exigir_ambito_junta(p_id_estamento BIGINT)
RETURNS VOID AS $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles r WHERE r.rolname = session_user AND r.rolsuper)
       AND NOT seguridad.fn_ambito_nacional() AND NOT (p_id_estamento = ANY (seguridad.fn_ambito_estamentos())) THEN
        RAISE EXCEPTION 'Fuera de su ámbito: no puede designar directivos de "%".',
              (SELECT nombre_estamento FROM gobernanza.estamento WHERE id_estamento = p_id_estamento) USING ERRCODE = 'insufficient_privilege';
    END IF;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Da posesión a una designación con la fecha de un registro (y retira a quien sale ese mismo día)
CREATE OR REPLACE FUNCTION gobernanza.fn_posesionar_designacion(p_id_designacion BIGINT, p_id_registro BIGINT)
RETURNS BIGINT AS $$
DECLARE v gobernanza.designacion_directivo%ROWTYPE; v_fecha DATE := gobernanza.fn_fecha_registro(p_id_registro);
        v_num TEXT; v_cargo TEXT; v_id BIGINT;
BEGIN
    SELECT * INTO v FROM gobernanza.designacion_directivo WHERE id_designacion = p_id_designacion FOR UPDATE;
    SELECT num_registro_inspector INTO v_num FROM gobernanza.registro_inspector_estamento WHERE id_registro = p_id_registro;
    SELECT nombre INTO v_cargo FROM gobernanza.cargo_directivo WHERE id_cargo = v.id_cargo;
    BEGIN
        -- Sale quien ocupaba el cargo (o el mismo directivo, en una reelección)
        IF v.id_directivo_saliente IS NOT NULL THEN
            UPDATE gobernanza.directivo_estamento
               SET fecha_retiro = v_fecha,
                   motivo_retiro = 'Reemplazado: designación n.º ' || v.id_designacion || ' inscrita en el registro ' || v_num
             WHERE id_directivo_estamento = v.id_directivo_saliente AND fecha_retiro IS NULL;
        END IF;
        -- En una rotación, la persona deja su cargo anterior en la junta
        IF v.tipo_nombramiento = 'ROTACION' THEN
            UPDATE gobernanza.directivo_estamento
               SET fecha_retiro = v_fecha, motivo_retiro = 'Rotación a ' || v_cargo || ' (registro ' || v_num || ')'
             WHERE id_persona = v.id_persona AND id_estamento = v.id_estamento AND fecha_retiro IS NULL AND id_cargo <> v.id_cargo;
        END IF;
        PERFORM seguridad.fn_fijar_operacion('designacion.operacion', 'posesionar');
        INSERT INTO gobernanza.directivo_estamento (id_persona, id_estamento, id_cargo, tipo_nombramiento, id_registro_inspector,
                                                    fecha_posesion_individual, rol_estamento)
        VALUES (v.id_persona, v.id_estamento, v.id_cargo, v.tipo_nombramiento, p_id_registro, v_fecha, v_cargo)
        RETURNING id_directivo_estamento INTO v_id;
        UPDATE gobernanza.designacion_directivo
           SET estado = 'POSESIONADA', id_registro = p_id_registro, id_directivo_estamento = v_id, fecha_posesion = v_fecha
         WHERE id_designacion = p_id_designacion;
        PERFORM seguridad.fn_fijar_operacion('designacion.operacion', '');
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'No se pudo dar posesión a la designación n.º % (% como %): % Anule o corrija la designación y registre de nuevo el registro.',
            v.id_designacion, gobernanza.fn_nombre_persona(v.id_persona), v_cargo, SQLERRM;
    END;
    RETURN v_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Al registrarse el registro vigente de una junta, se posesionan sus designaciones pendientes
CREATE OR REPLACE FUNCTION gobernanza.fn_posesionar_por_registro()
RETURNS TRIGGER AS $$
DECLARE r RECORD; v_fecha DATE;
BEGIN
    IF NEW.id_registro <> gobernanza.fn_registro_vigente(NEW.id_estamento) THEN RETURN NULL; END IF;
    v_fecha := gobernanza.fn_fecha_registro(NEW.id_registro);
    FOR r IN SELECT id_designacion FROM gobernanza.designacion_directivo
              WHERE id_estamento = NEW.id_estamento AND estado = 'PENDIENTE' AND fecha_designacion <= v_fecha
              ORDER BY CASE tipo_nombramiento WHEN 'ROTACION' THEN 0 ELSE 1 END, id_designacion LOOP
        PERFORM gobernanza.fn_posesionar_designacion(r.id_designacion, NEW.id_registro);
    END LOOP;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
DROP TRIGGER IF EXISTS trg_zz_posesionar ON gobernanza.registro_inspector_estamento;
CREATE TRIGGER trg_zz_posesionar AFTER INSERT ON gobernanza.registro_inspector_estamento
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_posesionar_por_registro();

-- Designar: la junta decide con su acta; la posesión llega con el registro del inspector
CREATE OR REPLACE FUNCTION gobernanza.fn_designar_directivo(p_id_persona BIGINT, p_id_estamento BIGINT, p_id_cargo BIGINT,
                                                            p_tipo TEXT, p_id_acta BIGINT, p_id_saliente BIGINT DEFAULT NULL,
                                                            p_observacion TEXT DEFAULT NULL)
RETURNS BIGINT AS $$
DECLARE v_est RECORD; v_cargo gobernanza.cargo_directivo%ROWTYPE; v_ocupa RECORD; v_propio RECORD; v_fecha DATE;
        v_reg BIGINT; v_id BIGINT; v_tipo TEXT := upper(trim(COALESCE(p_tipo, 'ELECCION')));
BEGIN
    SELECT * INTO v_est FROM gobernanza.estamento WHERE id_estamento = p_id_estamento;
    IF NOT FOUND THEN RAISE EXCEPTION 'La junta no existe.'; END IF;
    PERFORM gobernanza.fn_exigir_ambito_junta(p_id_estamento);
    IF NOT v_est.activo OR v_est.tipo_estamento NOT IN ('JUNTA DIRECTIVA NACIONAL', 'SUBDIRECTIVA', 'COMITÉ SECCIONAL') THEN
        RAISE EXCEPTION '"%" no es una junta activa con cargos directivos.', v_est.nombre_estamento;
    END IF;
    IF v_tipo NOT IN ('ELECCION', 'REELECCION', 'ROTACION') THEN RAISE EXCEPTION 'Tipo de nombramiento no válido: %.', p_tipo; END IF;
    IF NOT EXISTS (SELECT 1 FROM gobernanza.afiliado WHERE id_persona = p_id_persona AND activo) THEN
        RAISE EXCEPTION 'La persona no es afiliada activa.';
    END IF;
    SELECT * INTO v_cargo FROM gobernanza.cargo_directivo WHERE id_cargo = p_id_cargo;
    IF NOT FOUND OR NOT v_cargo.activo THEN RAISE EXCEPTION 'Seleccione un cargo activo del catálogo.'; END IF;
    IF v_cargo.tipo_estamento <> v_est.tipo_estamento THEN
        RAISE EXCEPTION 'El cargo % es de %, pero "%" es de tipo %.', v_cargo.nombre, v_cargo.tipo_estamento, v_est.nombre_estamento, v_est.tipo_estamento;
    END IF;
    IF NOT gobernanza.fn_acta_de(p_id_acta, p_id_estamento) THEN
        RAISE EXCEPTION 'Indique el acta de reunión de "%" que hizo la designación (documento tipo ACT radicado).', v_est.nombre_estamento;
    END IF;
    SELECT (fecha_radicacion AT TIME ZONE gestion_documental.fn_zona())::DATE INTO v_fecha
      FROM gestion_documental.documento WHERE id_documento = p_id_acta;
    IF EXISTS (SELECT 1 FROM gobernanza.designacion_directivo WHERE id_estamento = p_id_estamento AND id_cargo = p_id_cargo AND estado = 'PENDIENTE') THEN
        RAISE EXCEPTION 'Ya hay una designación pendiente para % en "%": anúlela si la junta cambió su decisión.', v_cargo.nombre, v_est.nombre_estamento;
    END IF;
    IF EXISTS (SELECT 1 FROM gobernanza.designacion_directivo WHERE id_estamento = p_id_estamento AND id_persona = p_id_persona AND estado = 'PENDIENTE') THEN
        RAISE EXCEPTION 'Esta persona ya tiene una designación pendiente en "%".', v_est.nombre_estamento;
    END IF;

    -- ¿Quién ocupa hoy el cargo?
    SELECT d.id_directivo_estamento, d.id_persona INTO v_ocupa FROM gobernanza.directivo_estamento d
     WHERE d.id_estamento = p_id_estamento AND d.id_cargo = p_id_cargo AND d.fecha_retiro IS NULL;
    IF FOUND THEN
        IF p_id_saliente IS NULL THEN
            RAISE EXCEPTION 'El cargo % en "%" lo ocupa %. Indique que esta designación lo reemplaza: saldrá del cargo el día del registro del inspector.',
                v_cargo.nombre, v_est.nombre_estamento, gobernanza.fn_nombre_persona(v_ocupa.id_persona);
        END IF;
        IF p_id_saliente <> v_ocupa.id_directivo_estamento THEN
            RAISE EXCEPTION 'Quien sale debe ser quien ocupa hoy el cargo % (%).', v_cargo.nombre, gobernanza.fn_nombre_persona(v_ocupa.id_persona);
        END IF;
        IF v_ocupa.id_persona = p_id_persona AND v_tipo <> 'REELECCION' THEN
            RAISE EXCEPTION 'Esta persona ya ocupa el cargo %: si la junta la vuelve a elegir, regístrelo como Reelección.', v_cargo.nombre;
        END IF;
    ELSIF p_id_saliente IS NOT NULL THEN
        RAISE EXCEPTION 'El cargo % está vacante: no hay a quién reemplazar.', v_cargo.nombre;
    END IF;

    -- Cargo propio en la misma junta
    SELECT d.rol_estamento, d.id_cargo INTO v_propio FROM gobernanza.directivo_estamento d
     WHERE d.id_persona = p_id_persona AND d.id_estamento = p_id_estamento AND d.fecha_retiro IS NULL;
    IF FOUND AND v_propio.id_cargo <> p_id_cargo AND v_tipo <> 'ROTACION' THEN
        RAISE EXCEPTION 'Esta persona ya es % en "%": para pasarla a otro cargo de la misma junta regístrelo como Rotación.', v_propio.rol_estamento, v_est.nombre_estamento;
    END IF;
    IF v_tipo = 'ROTACION' AND NOT FOUND THEN
        RAISE EXCEPTION 'Una rotación es pasar de otro cargo de "%": esta persona no tiene hoy un cargo allí.', v_est.nombre_estamento;
    END IF;

    PERFORM seguridad.fn_fijar_operacion('designacion.operacion', 'designar');
    INSERT INTO gobernanza.designacion_directivo (id_persona, id_estamento, id_cargo, tipo_nombramiento, id_acta, fecha_designacion,
                                                  id_directivo_saliente, observacion)
    VALUES (p_id_persona, p_id_estamento, p_id_cargo, v_tipo, p_id_acta, v_fecha, p_id_saliente, NULLIF(trim(COALESCE(p_observacion, '')), ''))
    RETURNING id_designacion INTO v_id;
    PERFORM seguridad.fn_fijar_operacion('designacion.operacion', '');

    -- Si el registro vigente se emitió el día del acta o después, ya incluye la designación: posesión inmediata
    v_reg := gobernanza.fn_registro_vigente(p_id_estamento);
    IF v_reg IS NOT NULL AND gobernanza.fn_fecha_registro(v_reg) >= v_fecha
       AND EXISTS (SELECT 1 FROM gobernanza.registro_inspector_estamento WHERE id_registro = v_reg) THEN
        PERFORM gobernanza.fn_posesionar_designacion(v_id, v_reg);
    END IF;
    RETURN v_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_anular_designacion(p_id_designacion BIGINT, p_motivo TEXT)
RETURNS TEXT AS $$
DECLARE v gobernanza.designacion_directivo%ROWTYPE;
BEGIN
    SELECT * INTO v FROM gobernanza.designacion_directivo WHERE id_designacion = p_id_designacion FOR UPDATE;
    IF NOT FOUND OR v.estado <> 'PENDIENTE' THEN RAISE EXCEPTION 'Solo se anula una designación pendiente del registro.'; END IF;
    PERFORM gobernanza.fn_exigir_ambito_junta(v.id_estamento);
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo de la anulación (mínimo 10 caracteres).'; END IF;
    PERFORM seguridad.fn_fijar_operacion('designacion.operacion', 'anular');
    UPDATE gobernanza.designacion_directivo SET estado = 'ANULADA', motivo_anulacion = trim(p_motivo),
           usuario_anula = auditoria.fn_usuario_actual(), fecha_anula = now() WHERE id_designacion = p_id_designacion;
    PERFORM seguridad.fn_fijar_operacion('designacion.operacion', '');
    RETURN 'ANULADA';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- A4. Vistas de posesión
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW gobernanza.v_designaciones WITH (security_invoker = true) AS
SELECT dz.fecha_designacion, e.nombre_estamento AS junta, c.nombre AS cargo, gobernanza.fn_nombre_persona(dz.id_persona) AS designado,
       dz.tipo_nombramiento, a.radicado_alfanumerico AS acta, gobernanza.fn_nombre_persona(ds.id_persona) AS sale,
       dz.estado, dz.fecha_posesion, r.num_registro_inspector AS registro,
       CASE
           WHEN dz.estado = 'PENDIENTE' AND gestion_documental.fn_hoy() - dz.fecha_designacion > 60
                THEN 'ALERTA ALTA: ESPERA EL REGISTRO DEL INSPECTOR HACE ' || (gestion_documental.fn_hoy() - dz.fecha_designacion) || ' DÍAS'
           WHEN dz.estado = 'PENDIENTE' AND gestion_documental.fn_hoy() - dz.fecha_designacion > 30
                THEN 'ALERTA MEDIA: ESPERA EL REGISTRO DEL INSPECTOR HACE ' || (gestion_documental.fn_hoy() - dz.fecha_designacion) || ' DÍAS'
           WHEN dz.estado = 'PENDIENTE' THEN 'ALERTA BAJA: ESPERA EL REGISTRO DEL INSPECTOR (NO EJERCE AÚN)'
           WHEN dz.estado = 'POSESIONADA' THEN 'POSESIONADO EL ' || to_char(dz.fecha_posesion, 'DD/MM/YYYY') || ' CON EL REGISTRO ' || r.num_registro_inspector
           ELSE 'ANULADA: ' || COALESCE(dz.motivo_anulacion, '')
       END AS diagnostico,
       dz.id_designacion, dz.id_persona, dz.id_estamento
  FROM gobernanza.designacion_directivo dz
  JOIN gobernanza.estamento e ON e.id_estamento = dz.id_estamento
  JOIN gobernanza.cargo_directivo c ON c.id_cargo = dz.id_cargo
  JOIN gestion_documental.documento a ON a.id_documento = dz.id_acta
  LEFT JOIN gobernanza.directivo_estamento ds ON ds.id_directivo_estamento = dz.id_directivo_saliente
  LEFT JOIN gobernanza.registro_inspector_estamento r ON r.id_registro = dz.id_registro;

CREATE OR REPLACE VIEW gobernanza.v_inscripcion_directivos WITH (security_invoker = true) AS
SELECT e.nombre_estamento AS junta, d.rol_estamento AS cargo, gobernanza.fn_nombre_persona(d.id_persona) AS directivo,
       d.fecha_posesion_individual AS posesion, d.fecha_inscripcion AS inscripcion, d.origen_posesion AS origen,
       r.num_registro_inspector AS registro_vigente, gobernanza.fn_fecha_registro(r.id_registro) AS fecha_registro,
       CASE
           WHEN d.fecha_inscripcion IS NULL
                THEN 'ALERTA ALTA: SIN REGISTRO DEL INSPECTOR (POSESIÓN ' || to_char(d.fecha_posesion_individual, 'DD/MM/YYYY') || ' POSTERIOR AL REGISTRO VIGENTE): NO EJERCE EL CARGO'
           WHEN d.fecha_posesion_individual > gestion_documental.fn_hoy()
                THEN 'ALERTA MEDIA: POSESIÓN FUTURA (' || to_char(d.fecha_posesion_individual, 'DD/MM/YYYY') || '): AÚN NO EJERCE'
           WHEN d.origen_posesion = 'DIRECTO' AND d.fecha_inscripcion <> d.fecha_posesion_individual
                THEN 'ALERTA BAJA: POSESIÓN REGISTRADA A MANO (' || to_char(d.fecha_posesion_individual, 'DD/MM/YYYY') || ') DISTINTA DE LA FECHA DEL REGISTRO (' || to_char(d.fecha_inscripcion, 'DD/MM/YYYY') || ')'
           ELSE 'INSCRITO EN EL REGISTRO DEL INSPECTOR'
       END AS diagnostico,
       d.id_directivo_estamento, d.id_persona, d.id_estamento
  FROM gobernanza.directivo_estamento d
  JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento
  JOIN gobernanza.registro_inspector_estamento r ON r.id_registro = d.id_registro_inspector
 WHERE d.fecha_retiro IS NULL;

-- ============================================================================
-- B. PERMISOS SINDICALES
-- ============================================================================
-- ----------------------------------------------------------------------------
-- B1. Parámetros (días hábiles: en los términos de días de las normas se excluyen los feriados)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.parametro_permiso (
    codigo VARCHAR(40) PRIMARY KEY,
    valor INT NOT NULL CHECK (valor >= 0),
    descripcion TEXT NOT NULL,
    version INT NOT NULL DEFAULT 1
);
INSERT INTO gobernanza.parametro_permiso (codigo, valor, descripcion) VALUES
    ('ANTELACION_DELEGADOS', 8, 'Días hábiles mínimos entre la solicitud y el inicio del permiso cuando hay delegados (asambleas, negociación colectiva, capacitación). Art. 2.2.2.5.4 del Decreto 1072 de 2015.'),
    ('ANTELACION_DIRECTIVOS', 4, 'Días hábiles mínimos entre la solicitud y el inicio del permiso cuando todos los beneficiarios son directivos.'),
    ('ANTELACION_EXCEPCIONAL', 1, 'Días hábiles mínimos en casos excepcionales, indicando el motivo (parágrafo 1).'),
    ('DIAS_NOTIFICACION', 3, 'La entidad debe notificar su respuesta al menos estos días hábiles antes del inicio del permiso; si no, se entiende concedido.'),
    ('DIAS_AVISO_PLAZO', 2, 'Alerta a la junta cuando faltan estos días hábiles para que venza el plazo de respuesta de la entidad.')
ON CONFLICT (codigo) DO NOTHING;

CREATE OR REPLACE FUNCTION gobernanza.fn_parametro_permiso(p_codigo TEXT)
RETURNS INT AS $$
    SELECT valor FROM gobernanza.parametro_permiso WHERE codigo = p_codigo;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_no_borrar ON gobernanza.parametro_permiso;
CREATE TRIGGER trg_no_borrar BEFORE DELETE ON gobernanza.parametro_permiso FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado();
DROP TRIGGER IF EXISTS trg_auditoria ON gobernanza.parametro_permiso;
CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON gobernanza.parametro_permiso
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria();
DROP TRIGGER IF EXISTS trg_control_version ON gobernanza.parametro_permiso;
CREATE TRIGGER trg_control_version BEFORE UPDATE ON gobernanza.parametro_permiso
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version();

-- Días hábiles de un rango (ambos extremos incluidos) y fecha N días hábiles antes de otra
CREATE OR REPLACE FUNCTION gobernanza.fn_dias_habiles_rango(p_desde DATE, p_hasta DATE)
RETURNS INT AS $$
    SELECT count(*)::INT FROM generate_series(p_desde, p_hasta, INTERVAL '1 day') g WHERE gobernanza.fn_es_habil(g::DATE);
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE FUNCTION gobernanza.fn_restar_dias_habiles(p_fecha DATE, p_dias INT)
RETURNS DATE AS $$
DECLARE d DATE := p_fecha; n INT := p_dias;
BEGIN
    WHILE n > 0 LOOP
        d := d - 1;
        IF gobernanza.fn_es_habil(d) THEN n := n - 1; END IF;
    END LOOP;
    RETURN d;
END;
$$ LANGUAGE plpgsql STABLE;

-- ----------------------------------------------------------------------------
-- B2. Solicitudes y beneficiarios
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.permiso_sindical (
    id_permiso BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    consecutivo VARCHAR(20) NOT NULL UNIQUE,
    id_estamento_solicita BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    id_persona_firma BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    cargo_firma VARCHAR(80) NOT NULL,
    firma_por_suplencia BOOLEAN NOT NULL DEFAULT FALSE,
    id_empresa BIGINT NOT NULL REFERENCES gobernanza.empresa(id_empresa) ON DELETE RESTRICT,
    destinatario TEXT NOT NULL,
    finalidad VARCHAR(25) NOT NULL CHECK (finalidad IN ('ASAMBLEA', 'NEGOCIACION_COLECTIVA', 'CAPACITACION', 'ACTIVIDAD_DIRECTIVA', 'OTRA')),
    descripcion TEXT NOT NULL,
    lugar VARCHAR(200),
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL,
    jornada VARCHAR(10) NOT NULL DEFAULT 'COMPLETA' CHECK (jornada IN ('COMPLETA', 'PARCIAL')),
    horas_dia NUMERIC(4, 1) CHECK (horas_dia IS NULL OR (horas_dia > 0 AND horas_dia <= 24)),
    distribucion TEXT,
    excepcional BOOLEAN NOT NULL DEFAULT FALSE,
    motivo_excepcional TEXT,
    antelacion_requerida INT NOT NULL,
    fecha_solicitud DATE NOT NULL,
    limite_respuesta DATE NOT NULL,
    estado VARCHAR(10) NOT NULL DEFAULT 'SOLICITADO' CHECK (estado IN ('SOLICITADO', 'RESPONDIDO', 'ANULADO')),
    acto_administrativo VARCHAR(80),
    fecha_acto DATE,
    fecha_notificacion DATE,
    respuesta_extemporanea BOOLEAN,
    observacion_respuesta TEXT,
    usuario_respuesta VARCHAR(50),
    fecha_registro_respuesta TIMESTAMP WITH TIME ZONE,
    motivo_anulacion TEXT,
    usuario_anula VARCHAR(50),
    fecha_anula TIMESTAMP WITH TIME ZONE,
    usuario_registra VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    fecha_registra TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_permiso_fechas CHECK (fecha_fin >= fecha_inicio),
    CONSTRAINT ck_permiso_parcial CHECK (jornada = 'COMPLETA' OR horas_dia IS NOT NULL),
    CONSTRAINT ck_permiso_excepcional CHECK (NOT excepcional OR length(trim(COALESCE(motivo_excepcional, ''))) >= 10)
);
COMMENT ON TABLE gobernanza.permiso_sindical IS
    'Solicitud escrita de permiso sindical dirigida a la sede central de la empresa. La firman el Presidente o el Secretario General que ejercen el cargo (art. 2.2.2.5.4 del Decreto 1072 de 2015, modificado por el Decreto 720 de 2024).';
CREATE INDEX IF NOT EXISTS ix_permiso_estamento ON gobernanza.permiso_sindical (id_estamento_solicita);
CREATE INDEX IF NOT EXISTS ix_permiso_firma ON gobernanza.permiso_sindical (id_persona_firma);
CREATE INDEX IF NOT EXISTS ix_permiso_empresa ON gobernanza.permiso_sindical (id_empresa);
CREATE INDEX IF NOT EXISTS ix_permiso_fechas ON gobernanza.permiso_sindical (fecha_inicio, fecha_fin);

CREATE TABLE IF NOT EXISTS gobernanza.permiso_sindical_beneficiario (
    id_beneficiario BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_permiso BIGINT NOT NULL REFERENCES gobernanza.permiso_sindical(id_permiso) ON DELETE RESTRICT,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.afiliado(id_persona) ON DELETE RESTRICT,
    calidad VARCHAR(10) NOT NULL CHECK (calidad IN ('DIRECTIVO', 'DELEGADO')),
    cargo_directivo VARCHAR(120),
    motivo_junta VARCHAR(20) NOT NULL CHECK (motivo_junta IN ('JUNTA NACIONAL', 'PERTENENCIA', 'SEDE CENTRAL')),
    dias_solicitados INT NOT NULL CHECK (dias_solicitados > 0),
    decision VARCHAR(10) NOT NULL DEFAULT 'PENDIENTE' CHECK (decision IN ('PENDIENTE', 'CONCEDIDO', 'LIMITADO', 'NEGADO')),
    dias_concedidos INT CHECK (dias_concedidos IS NULL OR dias_concedidos >= 0),
    causal VARCHAR(20) CHECK (causal IS NULL OR causal IN ('PRESTACION_SERVICIO', 'OTRA')),
    motivo_entidad TEXT,
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT uk_permiso_persona UNIQUE (id_permiso, id_persona)
);
COMMENT ON TABLE gobernanza.permiso_sindical_beneficiario IS
    'Afiliados incluidos en una solicitud de permiso sindical, con los días hábiles solicitados y la decisión de la entidad para cada uno.';
CREATE INDEX IF NOT EXISTS ix_permiso_benef_persona ON gobernanza.permiso_sindical_beneficiario (id_persona);

CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_permiso()
RETURNS TRIGGER AS $$
BEGIN
    IF COALESCE(seguridad.fn_operacion('permiso.operacion'), '') = '' THEN
        RAISE EXCEPTION 'El permiso sindical se registra con sus acciones: solicitar, registrar la respuesta o anular.';
    END IF;
    IF TG_OP = 'UPDATE' AND TG_TABLE_NAME = 'permiso_sindical' THEN
        IF OLD.estado = 'ANULADO' THEN RAISE EXCEPTION 'Un permiso anulado no se modifica.'; END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['gobernanza.permiso_sindical', 'gobernanza.permiso_sindical_beneficiario'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_proteger_permiso ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_proteger_permiso BEFORE INSERT OR UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_proteger_permiso()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_no_borrar ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_no_borrar BEFORE DELETE ON %s FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_auditoria ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_control_version ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_control_version BEFORE UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version()', t);
    END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- B3. Reglas
-- ----------------------------------------------------------------------------
-- ¿Por qué esta junta puede pedir permiso para este afiliado? (NULL = no puede)
CREATE OR REPLACE FUNCTION gobernanza.fn_junta_puede_pedir_permiso(p_id_estamento BIGINT, p_id_persona BIGINT)
RETURNS TEXT AS $$
    SELECT CASE
        WHEN est.tipo_estamento = 'JUNTA DIRECTIVA NACIONAL' THEN 'JUNTA NACIONAL'
        WHEN a.id_estamento_pertenencia = est.id_estamento THEN 'PERTENENCIA'
        WHEN est.tipo_estamento IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL') AND est.municipio_codigo IS NOT NULL
             AND est.municipio_codigo = emp.municipio_codigo THEN 'SEDE CENTRAL'
    END
      FROM gobernanza.estamento est
      JOIN gobernanza.afiliado a ON a.id_persona = p_id_persona
      LEFT JOIN gobernanza.afiliado_empresa ae ON ae.id_persona = a.id_persona
      LEFT JOIN gobernanza.empresa emp ON emp.id_empresa = ae.id_empresa
     WHERE est.id_estamento = p_id_estamento;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Datos de la empresa destinataria: los ve quien pidió el permiso aunque la empresa no sea de su ámbito
CREATE OR REPLACE FUNCTION gobernanza.fn_empresa_permiso(p_id_empresa BIGINT)
RETURNS TABLE (nombre_empresa TEXT, nit TEXT, direccion TEXT, municipio TEXT) AS $$
    SELECT e.nombre_empresa::TEXT, e.nit::TEXT, e.direccion::TEXT, COALESCE(m.nombre, e.municipio)::TEXT
      FROM gobernanza.empresa e LEFT JOIN gobernanza.municipio m ON m.codigo = e.municipio_codigo
     WHERE e.id_empresa = p_id_empresa;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_destinatario_permiso(p_id_empresa BIGINT)
RETURNS TEXT AS $$
    SELECT COALESCE(gobernanza.fn_nombre_persona(j.id_persona) || ', Representante legal', 'Nominador o autoridad competente')
      FROM gobernanza.empresa e
      LEFT JOIN gobernanza.jefe_empresa j ON j.id_jefe = e.id_representante_legal
     WHERE e.id_empresa = p_id_empresa;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_solicitar_permiso(
    p_id_estamento BIGINT, p_personas BIGINT[], p_finalidad TEXT, p_descripcion TEXT,
    p_fecha_inicio DATE, p_fecha_fin DATE, p_jornada TEXT DEFAULT 'COMPLETA', p_horas_dia NUMERIC DEFAULT NULL,
    p_distribucion TEXT DEFAULT NULL, p_lugar TEXT DEFAULT NULL, p_excepcional BOOLEAN DEFAULT FALSE,
    p_motivo_excepcional TEXT DEFAULT NULL, p_destinatario TEXT DEFAULT NULL)
RETURNS BIGINT AS $$
DECLARE v_est RECORD; v_firma RECORD; v_hoy DATE := gestion_documental.fn_hoy(); v_persona BIGINT; v_empresa BIGINT;
        v_emp_p BIGINT; v_motivo TEXT; v_choque RECORD; v_dias INT; v_todos_directivos BOOLEAN := TRUE; v_cargo TEXT;
        v_antelacion INT; v_minima DATE; v_id BIGINT; v_consec TEXT; v_personas BIGINT[];
BEGIN
    SELECT * INTO v_est FROM gobernanza.estamento WHERE id_estamento = p_id_estamento;
    IF NOT FOUND OR v_est.tipo_estamento NOT IN ('JUNTA DIRECTIVA NACIONAL', 'SUBDIRECTIVA', 'COMITÉ SECCIONAL') THEN
        RAISE EXCEPTION 'Elija la junta que solicita el permiso.';
    END IF;
    -- Firma: el Presidente o el Secretario General que ejercen hoy el cargo en esa junta
    SELECT m.nombre, m.por_suplencia, u.id_persona INTO v_firma
      FROM seguridad.fn_mis_cargos() m
      JOIN seguridad.usuario u ON u.id_usuario = seguridad.fn_id_usuario_actual()
     WHERE m.id_estamento = p_id_estamento AND (m.codigo LIKE 'PRES\_%' OR m.codigo LIKE 'SGEN\_%')
     ORDER BY m.orden LIMIT 1;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Los permisos sindicales los solicitan por escrito el Presidente o el Secretario General de la organización sindical (art. 2.2.2.5.4 del Decreto 1072 de 2015, modificado por el Decreto 720 de 2024). Usted no ejerce hoy ninguno de esos cargos en "%".',
            v_est.nombre_estamento USING ERRCODE = 'insufficient_privilege';
    END IF;

    SELECT ARRAY(SELECT DISTINCT x FROM unnest(p_personas) x WHERE x IS NOT NULL) INTO v_personas;
    IF COALESCE(array_length(v_personas, 1), 0) = 0 THEN RAISE EXCEPTION 'Indique al menos un afiliado.'; END IF;
    IF upper(COALESCE(p_finalidad, '')) NOT IN ('ASAMBLEA', 'NEGOCIACION_COLECTIVA', 'CAPACITACION', 'ACTIVIDAD_DIRECTIVA', 'OTRA') THEN
        RAISE EXCEPTION 'Elija la finalidad del permiso.';
    END IF;
    IF length(trim(COALESCE(p_descripcion, ''))) < 10 THEN
        RAISE EXCEPTION 'Describa la finalidad del permiso (mínimo 10 caracteres): la entidad la debe indicar en el acto que lo concede.';
    END IF;
    IF p_fecha_inicio IS NULL OR p_fecha_fin IS NULL OR p_fecha_fin < p_fecha_inicio THEN
        RAISE EXCEPTION 'Revise las fechas: el permiso termina el mismo día o después de iniciar.';
    END IF;
    IF p_fecha_inicio <= v_hoy THEN RAISE EXCEPTION 'El permiso debe solicitarse antes del día en que empieza.'; END IF;
    v_dias := gobernanza.fn_dias_habiles_rango(p_fecha_inicio, p_fecha_fin);
    IF v_dias = 0 THEN RAISE EXCEPTION 'Entre esas fechas no hay días hábiles.'; END IF;
    IF upper(COALESCE(p_jornada, 'COMPLETA')) = 'PARCIAL' AND p_horas_dia IS NULL THEN
        RAISE EXCEPTION 'Para un permiso de jornada parcial indique las horas por día.';
    END IF;

    -- Cada afiliado: activo, de la misma empresa, de una junta que puede pedir para él y sin otro permiso que se cruce
    FOREACH v_persona IN ARRAY v_personas LOOP
        IF NOT EXISTS (SELECT 1 FROM gobernanza.afiliado WHERE id_persona = v_persona AND activo) THEN
            RAISE EXCEPTION '% no es afiliado activo.', COALESCE(gobernanza.fn_nombre_persona(v_persona), 'La persona ' || v_persona);
        END IF;
        SELECT id_empresa INTO v_emp_p FROM gobernanza.afiliado_empresa WHERE id_persona = v_persona;
        IF v_emp_p IS NULL THEN
            RAISE EXCEPTION '% no tiene registrada su empresa: el permiso se dirige a la sede central de la empresa.', gobernanza.fn_nombre_persona(v_persona);
        END IF;
        IF v_empresa IS NULL THEN v_empresa := v_emp_p;
        ELSIF v_empresa <> v_emp_p THEN
            RAISE EXCEPTION 'Todos los afiliados de una solicitud deben trabajar en la misma empresa (cada solicitud va a la sede central de una empresa). % es de otra: haga una solicitud aparte.',
                gobernanza.fn_nombre_persona(v_persona);
        END IF;
        v_motivo := gobernanza.fn_junta_puede_pedir_permiso(p_id_estamento, v_persona);
        IF v_motivo IS NULL THEN
            RAISE EXCEPTION '"%" no puede pedir permisos para %: los piden la Junta Directiva Nacional, la junta a la que pertenece (%) o la junta del municipio de la sede central de su empresa.',
                v_est.nombre_estamento, gobernanza.fn_nombre_persona(v_persona),
                (SELECT e.nombre_estamento FROM gobernanza.afiliado a JOIN gobernanza.estamento e ON e.id_estamento = a.id_estamento_pertenencia WHERE a.id_persona = v_persona);
        END IF;
        SELECT p.consecutivo, e.nombre_estamento, p.fecha_inicio, p.fecha_fin INTO v_choque
          FROM gobernanza.permiso_sindical_beneficiario b
          JOIN gobernanza.permiso_sindical p ON p.id_permiso = b.id_permiso
          JOIN gobernanza.estamento e ON e.id_estamento = p.id_estamento_solicita
         WHERE b.id_persona = v_persona AND p.estado <> 'ANULADO'
           AND NOT (p.estado = 'RESPONDIDO' AND b.decision = 'NEGADO' AND NOT p.respuesta_extemporanea)
           AND daterange(p.fecha_inicio, p.fecha_fin, '[]') && daterange(p_fecha_inicio, p_fecha_fin, '[]')
         LIMIT 1;
        IF FOUND THEN
            RAISE EXCEPTION '% ya tiene el permiso % solicitado por "%" del % al %, que se cruza con estas fechas.',
                gobernanza.fn_nombre_persona(v_persona), v_choque.consecutivo, v_choque.nombre_estamento,
                to_char(v_choque.fecha_inicio, 'DD/MM/YYYY'), to_char(v_choque.fecha_fin, 'DD/MM/YYYY');
        END IF;
        IF NOT EXISTS (SELECT 1 FROM gobernanza.v_cargos_en_ejercicio WHERE id_persona = v_persona) THEN v_todos_directivos := FALSE; END IF;
    END LOOP;

    -- Antelación (días hábiles)
    v_antelacion := gobernanza.fn_parametro_permiso(CASE WHEN v_todos_directivos THEN 'ANTELACION_DIRECTIVOS' ELSE 'ANTELACION_DELEGADOS' END);
    v_minima := gobernanza.fn_sumar_dias_habiles(v_hoy, v_antelacion);
    IF p_fecha_inicio < v_minima THEN
        IF NOT COALESCE(p_excepcional, FALSE) THEN
            RAISE EXCEPTION 'La solicitud debe presentarse con al menos % días hábiles de antelación (%): para iniciar el % debió pedirse antes; la fecha más cercana posible hoy es el %. En casos excepcionales se puede pedir con % día hábil indicando el motivo.',
                v_antelacion, CASE WHEN v_todos_directivos THEN 'todos son directivos' ELSE 'hay delegados que no son directivos' END,
                to_char(p_fecha_inicio, 'DD/MM/YYYY'), to_char(v_minima, 'DD/MM/YYYY'), gobernanza.fn_parametro_permiso('ANTELACION_EXCEPCIONAL');
        END IF;
        IF length(trim(COALESCE(p_motivo_excepcional, ''))) < 10 THEN
            RAISE EXCEPTION 'Explique por qué es un caso excepcional (mínimo 10 caracteres).';
        END IF;
        v_antelacion := gobernanza.fn_parametro_permiso('ANTELACION_EXCEPCIONAL');
        IF p_fecha_inicio < gobernanza.fn_sumar_dias_habiles(v_hoy, v_antelacion) THEN
            RAISE EXCEPTION 'Aun en casos excepcionales el permiso se pide con al menos % día hábil de anticipación: la fecha más cercana posible es el %.',
                v_antelacion, to_char(gobernanza.fn_sumar_dias_habiles(v_hoy, v_antelacion), 'DD/MM/YYYY');
        END IF;
    END IF;

    -- Consecutivo por año
    PERFORM pg_advisory_xact_lock(hashtext('permiso_sindical_consecutivo'));
    SELECT 'PS-' || to_char(v_hoy, 'YYYY') || '-' || lpad((count(*) + 1)::TEXT, 4, '0') INTO v_consec
      FROM gobernanza.permiso_sindical WHERE consecutivo LIKE 'PS-' || to_char(v_hoy, 'YYYY') || '-%';

    PERFORM seguridad.fn_fijar_operacion('permiso.operacion', 'solicitar');
    INSERT INTO gobernanza.permiso_sindical (consecutivo, id_estamento_solicita, id_persona_firma, cargo_firma, firma_por_suplencia, id_empresa,
                                             destinatario, finalidad, descripcion, lugar, fecha_inicio, fecha_fin, jornada, horas_dia, distribucion,
                                             excepcional, motivo_excepcional, antelacion_requerida, fecha_solicitud, limite_respuesta)
    VALUES (v_consec, p_id_estamento, v_firma.id_persona, v_firma.nombre, v_firma.por_suplencia, v_empresa,
            COALESCE(NULLIF(trim(COALESCE(p_destinatario, '')), ''), gobernanza.fn_destinatario_permiso(v_empresa)),
            upper(p_finalidad), trim(p_descripcion), NULLIF(trim(COALESCE(p_lugar, '')), ''), p_fecha_inicio, p_fecha_fin,
            upper(COALESCE(p_jornada, 'COMPLETA')), CASE WHEN upper(COALESCE(p_jornada, 'COMPLETA')) = 'PARCIAL' THEN p_horas_dia END,
            NULLIF(trim(COALESCE(p_distribucion, '')), ''),
            p_fecha_inicio < v_minima, CASE WHEN p_fecha_inicio < v_minima THEN trim(p_motivo_excepcional) END,
            v_antelacion, v_hoy,
            GREATEST(v_hoy, gobernanza.fn_restar_dias_habiles(p_fecha_inicio, gobernanza.fn_parametro_permiso('DIAS_NOTIFICACION'))))
    RETURNING id_permiso INTO v_id;
    FOREACH v_persona IN ARRAY v_personas LOOP
        SELECT string_agg(c.nombre || ' (' || e.nombre_estamento || ')', ', ') INTO v_cargo
          FROM gobernanza.v_cargos_en_ejercicio c JOIN gobernanza.estamento e ON e.id_estamento = c.id_estamento
         WHERE c.id_persona = v_persona;
        INSERT INTO gobernanza.permiso_sindical_beneficiario (id_permiso, id_persona, calidad, cargo_directivo, motivo_junta, dias_solicitados)
        VALUES (v_id, v_persona, CASE WHEN v_cargo IS NULL THEN 'DELEGADO' ELSE 'DIRECTIVO' END, v_cargo,
                gobernanza.fn_junta_puede_pedir_permiso(p_id_estamento, v_persona), v_dias);
    END LOOP;
    PERFORM seguridad.fn_fijar_operacion('permiso.operacion', '');
    RETURN v_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Juntas en las que el usuario puede firmar solicitudes (ejerce hoy Presidencia o Secretaría General)
CREATE OR REPLACE FUNCTION gobernanza.fn_juntas_para_permiso()
RETURNS TABLE (id_estamento BIGINT, junta TEXT, cargo TEXT, por_suplencia BOOLEAN) AS $$
    SELECT m.id_estamento, e.nombre_estamento::TEXT, m.nombre, m.por_suplencia
      FROM seguridad.fn_mis_cargos() m JOIN gobernanza.estamento e ON e.id_estamento = m.id_estamento
     WHERE m.codigo LIKE 'PRES\_%' OR m.codigo LIKE 'SGEN\_%'
     ORDER BY e.tipo_estamento DESC, e.nombre_estamento;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Afiliados para los que una junta puede pedir permiso (incluye los de otra junta que trabajan en una empresa con
-- sede central en su municipio). Solo para quien firma por esa junta; muestra lo mínimo para identificarlos.
CREATE OR REPLACE FUNCTION gobernanza.fn_afiliados_para_permiso(p_id_estamento BIGINT, p_q TEXT DEFAULT NULL, p_limite INT DEFAULT 30)
RETURNS TABLE (id_persona BIGINT, afiliado TEXT, identificacion TEXT, empresa TEXT, motivo_junta TEXT, directivo BOOLEAN) AS $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM gobernanza.fn_juntas_para_permiso() j WHERE j.id_estamento = p_id_estamento) THEN
        RAISE EXCEPTION 'Solo el Presidente o el Secretario General que ejercen el cargo en esa junta piden permisos sindicales.'
              USING ERRCODE = 'insufficient_privilege';
    END IF;
    RETURN QUERY
    SELECT a.id_persona, gobernanza.fn_nombre_persona(a.id_persona), p.tipo_dni || ' ' || p.dni, emp.nombre_empresa::TEXT,
           gobernanza.fn_junta_puede_pedir_permiso(p_id_estamento, a.id_persona),
           EXISTS (SELECT 1 FROM gobernanza.v_cargos_en_ejercicio c WHERE c.id_persona = a.id_persona)
      FROM gobernanza.afiliado a
      JOIN gobernanza.persona p ON p.id_persona = a.id_persona
      JOIN gobernanza.afiliado_empresa ae ON ae.id_persona = a.id_persona
      JOIN gobernanza.empresa emp ON emp.id_empresa = ae.id_empresa
     WHERE a.activo AND gobernanza.fn_junta_puede_pedir_permiso(p_id_estamento, a.id_persona) IS NOT NULL
       AND (COALESCE(trim(p_q), '') = '' OR p.dni LIKE trim(p_q) || '%'
            OR gobernanza.fn_clave_lugar(gobernanza.fn_nombre_persona(a.id_persona)) LIKE '%' || gobernanza.fn_clave_lugar(p_q) || '%')
     ORDER BY 2
     LIMIT LEAST(GREATEST(COALESCE(p_limite, 30), 1), 100);
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Quién registra la respuesta o anula: Presidente o Secretario General de la junta que lo pidió o de la Nacional
CREATE OR REPLACE FUNCTION gobernanza.fn_exigir_mesa_permiso(p_id_estamento BIGINT)
RETURNS VOID AS $$
BEGIN
    IF NOT (seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'SGEN\_%'], p_id_estamento)
            OR seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'SGEN\_%'], gobernanza.fn_id_jdn())) THEN
        RAISE EXCEPTION 'Lo registran el Presidente o el Secretario General de la junta que pidió el permiso o de la Junta Directiva Nacional.'
              USING ERRCODE = 'insufficient_privilege';
    END IF;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Respuesta de la entidad: p_decisiones = [{"id_persona": 1, "decision": "CONCEDIDO|LIMITADO|NEGADO", "dias_concedidos": 2,
--                                         "causal": "PRESTACION_SERVICIO|OTRA", "motivo": "..."}]
CREATE OR REPLACE FUNCTION gobernanza.fn_responder_permiso(p_id_permiso BIGINT, p_acto TEXT, p_fecha_acto DATE, p_fecha_notificacion DATE,
                                                           p_decisiones JSONB, p_observacion TEXT DEFAULT NULL)
RETURNS TEXT AS $$
DECLARE v gobernanza.permiso_sindical%ROWTYPE; b RECORD; d JSONB; v_dec TEXT; v_dias INT; v_causal TEXT; v_motivo TEXT;
        v_extemp BOOLEAN;
BEGIN
    SELECT * INTO v FROM gobernanza.permiso_sindical WHERE id_permiso = p_id_permiso FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'El permiso no existe.'; END IF;
    PERFORM gobernanza.fn_exigir_mesa_permiso(v.id_estamento_solicita);
    IF v.estado <> 'SOLICITADO' THEN RAISE EXCEPTION 'El permiso % ya está %.', v.consecutivo, lower(v.estado); END IF;
    IF length(trim(COALESCE(p_acto, ''))) = 0 THEN RAISE EXCEPTION 'Indique el número del acto administrativo de la entidad.'; END IF;
    IF p_fecha_notificacion IS NULL OR p_fecha_notificacion > gestion_documental.fn_hoy() OR p_fecha_notificacion < v.fecha_solicitud THEN
        RAISE EXCEPTION 'Indique la fecha en que la entidad notificó la respuesta al sindicato (entre la solicitud y hoy).';
    END IF;
    IF p_fecha_acto IS NOT NULL AND p_fecha_acto > p_fecha_notificacion THEN
        RAISE EXCEPTION 'El acto no puede ser posterior a su notificación.';
    END IF;
    v_extemp := p_fecha_notificacion > v.limite_respuesta;

    PERFORM seguridad.fn_fijar_operacion('permiso.operacion', 'responder');
    FOR b IN SELECT * FROM gobernanza.permiso_sindical_beneficiario WHERE id_permiso = p_id_permiso LOOP
        d := NULL;
        SELECT x INTO d FROM jsonb_array_elements(COALESCE(p_decisiones, '[]'::jsonb)) x WHERE (x->>'id_persona')::BIGINT = b.id_persona;
        IF d IS NULL THEN RAISE EXCEPTION 'Falta la decisión de la entidad para %.', gobernanza.fn_nombre_persona(b.id_persona); END IF;
        v_dec := upper(COALESCE(d->>'decision', ''));
        v_causal := NULLIF(upper(COALESCE(d->>'causal', '')), '');
        v_motivo := NULLIF(trim(COALESCE(d->>'motivo', '')), '');
        IF v_dec = 'CONCEDIDO' THEN v_dias := b.dias_solicitados; v_causal := NULL;
        ELSIF v_dec = 'NEGADO' THEN v_dias := 0;
        ELSIF v_dec = 'LIMITADO' THEN
            v_dias := NULLIF(d->>'dias_concedidos', '')::INT;
            IF v_dias IS NULL OR v_dias <= 0 OR v_dias >= b.dias_solicitados THEN
                RAISE EXCEPTION 'Para %, un permiso limitado concede entre 1 y % días hábiles.', gobernanza.fn_nombre_persona(b.id_persona), b.dias_solicitados - 1;
            END IF;
        ELSE RAISE EXCEPTION 'Decisión no válida para %: CONCEDIDO, LIMITADO o NEGADO.', gobernanza.fn_nombre_persona(b.id_persona);
        END IF;
        IF v_dec IN ('LIMITADO', 'NEGADO') THEN
            IF v_causal IS NULL OR v_causal NOT IN ('PRESTACION_SERVICIO', 'OTRA') THEN
                RAISE EXCEPTION 'Para %, indique la causal que invocó la entidad: la afectación de la prestación del servicio (única causal legal) u otra.', gobernanza.fn_nombre_persona(b.id_persona);
            END IF;
            IF v_motivo IS NULL THEN RAISE EXCEPTION 'Para %, copie el motivo que dio la entidad.', gobernanza.fn_nombre_persona(b.id_persona); END IF;
        END IF;
        UPDATE gobernanza.permiso_sindical_beneficiario
           SET decision = v_dec, dias_concedidos = v_dias, causal = v_causal, motivo_entidad = v_motivo
         WHERE id_beneficiario = b.id_beneficiario;
    END LOOP;
    UPDATE gobernanza.permiso_sindical
       SET estado = 'RESPONDIDO', acto_administrativo = trim(p_acto), fecha_acto = p_fecha_acto, fecha_notificacion = p_fecha_notificacion,
           respuesta_extemporanea = v_extemp, observacion_respuesta = NULLIF(trim(COALESCE(p_observacion, '')), ''),
           usuario_respuesta = auditoria.fn_usuario_actual(), fecha_registro_respuesta = now()
     WHERE id_permiso = p_id_permiso;
    PERFORM seguridad.fn_fijar_operacion('permiso.operacion', '');
    RETURN CASE WHEN v_extemp THEN 'EXTEMPORANEA' ELSE 'RESPONDIDO' END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_anular_permiso(p_id_permiso BIGINT, p_motivo TEXT)
RETURNS TEXT AS $$
DECLARE v gobernanza.permiso_sindical%ROWTYPE;
BEGIN
    SELECT * INTO v FROM gobernanza.permiso_sindical WHERE id_permiso = p_id_permiso FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'El permiso no existe.'; END IF;
    PERFORM gobernanza.fn_exigir_mesa_permiso(v.id_estamento_solicita);
    IF v.estado = 'ANULADO' THEN RAISE EXCEPTION 'El permiso ya está anulado.'; END IF;
    IF v.fecha_inicio <= gestion_documental.fn_hoy() THEN
        RAISE EXCEPTION 'El permiso ya empezó: no se anula. Si no se usó, déjelo anotado en la observación de la respuesta.';
    END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo de la anulación (mínimo 10 caracteres).'; END IF;
    PERFORM seguridad.fn_fijar_operacion('permiso.operacion', 'anular');
    UPDATE gobernanza.permiso_sindical SET estado = 'ANULADO', motivo_anulacion = trim(p_motivo),
           usuario_anula = auditoria.fn_usuario_actual(), fecha_anula = now() WHERE id_permiso = p_id_permiso;
    PERFORM seguridad.fn_fijar_operacion('permiso.operacion', '');
    RETURN 'ANULADO';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- B4. Decisión efectiva (silencio administrativo) y vistas
-- ----------------------------------------------------------------------------
-- Sin respuesta notificada a tiempo, el permiso se entiende concedido para todos los efectos
CREATE OR REPLACE FUNCTION gobernanza.fn_decision_efectiva(p gobernanza.permiso_sindical, b gobernanza.permiso_sindical_beneficiario)
RETURNS TEXT AS $$
    SELECT CASE
        WHEN p.estado = 'ANULADO' THEN 'ANULADO'
        WHEN p.estado = 'SOLICITADO' AND gestion_documental.fn_hoy() > p.limite_respuesta THEN 'CONCEDIDO POR SILENCIO'
        WHEN p.estado = 'SOLICITADO' THEN 'EN ESPERA'
        WHEN p.respuesta_extemporanea THEN 'CONCEDIDO POR SILENCIO'
        ELSE b.decision
    END;
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE FUNCTION gobernanza.fn_dias_efectivos(p gobernanza.permiso_sindical, b gobernanza.permiso_sindical_beneficiario)
RETURNS INT AS $$
    SELECT CASE gobernanza.fn_decision_efectiva(p, b)
        WHEN 'CONCEDIDO POR SILENCIO' THEN b.dias_solicitados
        WHEN 'CONCEDIDO' THEN b.dias_solicitados
        WHEN 'LIMITADO' THEN b.dias_concedidos
        WHEN 'NEGADO' THEN 0
    END;
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE VIEW gobernanza.v_permisos_sindicales WITH (security_invoker = true) AS
SELECT p.consecutivo, p.fecha_solicitud, e.nombre_estamento AS junta, gobernanza.fn_nombre_persona(p.id_persona_firma) || ' (' || p.cargo_firma
           || CASE WHEN p.firma_por_suplencia THEN ', suplente' ELSE '' END || ')' AS firma,
       (SELECT x.nombre_empresa FROM gobernanza.fn_empresa_permiso(p.id_empresa) x) AS empresa, p.finalidad, p.fecha_inicio, p.fecha_fin,
       (SELECT count(*) FROM gobernanza.permiso_sindical_beneficiario b WHERE b.id_permiso = p.id_permiso) AS afiliados,
       (SELECT sum(b.dias_solicitados) FROM gobernanza.permiso_sindical_beneficiario b WHERE b.id_permiso = p.id_permiso) AS dias_solicitados,
       (SELECT sum(gobernanza.fn_dias_efectivos(p, b)) FROM gobernanza.permiso_sindical_beneficiario b WHERE b.id_permiso = p.id_permiso) AS dias_concedidos,
       p.estado, p.limite_respuesta, p.acto_administrativo, p.fecha_notificacion,
       CASE WHEN p.excepcional THEN 'SÍ' ELSE 'NO' END AS excepcional,
       CASE
           WHEN p.estado = 'ANULADO' THEN 'ANULADO: ' || COALESCE(p.motivo_anulacion, '')
           WHEN p.estado = 'SOLICITADO' AND gestion_documental.fn_hoy() > p.limite_respuesta
                THEN 'CONCEDIDO POR SILENCIO: LA ENTIDAD NO NOTIFICÓ RESPUESTA ANTES DEL ' || to_char(p.limite_respuesta + 1, 'DD/MM/YYYY')
           WHEN p.estado = 'SOLICITADO'
                AND gestion_documental.fn_hoy() >= gobernanza.fn_restar_dias_habiles(p.limite_respuesta, gobernanza.fn_parametro_permiso('DIAS_AVISO_PLAZO'))
                THEN 'ALERTA MEDIA: LA ENTIDAD DEBE NOTIFICAR LA RESPUESTA A MÁS TARDAR EL ' || to_char(p.limite_respuesta, 'DD/MM/YYYY')
           WHEN p.estado = 'SOLICITADO' THEN 'ALERTA BAJA: ESPERA LA RESPUESTA DE LA ENTIDAD (PLAZO ' || to_char(p.limite_respuesta, 'DD/MM/YYYY') || ')'
           WHEN p.respuesta_extemporanea THEN 'RESPUESTA EXTEMPORÁNEA: SE ENTIENDE CONCEDIDO POR SILENCIO'
           WHEN EXISTS (SELECT 1 FROM gobernanza.permiso_sindical_beneficiario b WHERE b.id_permiso = p.id_permiso
                         AND b.decision IN ('LIMITADO', 'NEGADO') AND b.causal = 'OTRA')
                THEN 'ALERTA ALTA: NEGADO O LIMITADO POR UNA CAUSA DISTINTA DE LA AFECTACIÓN DEL SERVICIO (ÚNICA CAUSAL LEGAL)'
           WHEN EXISTS (SELECT 1 FROM gobernanza.permiso_sindical_beneficiario b WHERE b.id_permiso = p.id_permiso AND b.decision = 'NEGADO')
                THEN 'NEGADO (TOTAL O PARA ALGUNOS AFILIADOS)'
           WHEN EXISTS (SELECT 1 FROM gobernanza.permiso_sindical_beneficiario b WHERE b.id_permiso = p.id_permiso AND b.decision = 'LIMITADO')
                THEN 'CONCEDIDO CON LÍMITE DE DÍAS'
           ELSE 'CONCEDIDO'
       END AS diagnostico,
       p.id_permiso, p.id_estamento_solicita AS id_estamento, p.id_empresa
  FROM gobernanza.permiso_sindical p
  JOIN gobernanza.estamento e ON e.id_estamento = p.id_estamento_solicita;

CREATE OR REPLACE VIEW gobernanza.v_permisos_beneficiarios WITH (security_invoker = true) AS
SELECT p.consecutivo, gobernanza.fn_nombre_persona(b.id_persona) AS afiliado, gobernanza.fn_identificacion_persona(b.id_persona) AS identificacion, b.calidad, b.cargo_directivo, b.motivo_junta,
       p.fecha_inicio, p.fecha_fin, b.dias_solicitados, gobernanza.fn_decision_efectiva(p, b) AS decision,
       gobernanza.fn_dias_efectivos(p, b) AS dias_concedidos, b.causal, b.motivo_entidad,
       b.id_beneficiario, b.id_permiso, b.id_persona
  FROM gobernanza.permiso_sindical_beneficiario b
  JOIN gobernanza.permiso_sindical p ON p.id_permiso = b.id_permiso;

-- Días por afiliado y año (los anulados no cuentan; los que esperan respuesta se muestran aparte)
CREATE OR REPLACE VIEW gobernanza.v_permisos_por_afiliado WITH (security_invoker = true) AS
SELECT EXTRACT(YEAR FROM p.fecha_inicio)::INT AS anio, gobernanza.fn_nombre_persona(b.id_persona) AS afiliado,
       ep.nombre_estamento AS pertenece_a, count(*) AS permisos,
       sum(b.dias_solicitados) AS dias_solicitados,
       sum(COALESCE(gobernanza.fn_dias_efectivos(p, b), 0)) AS dias_concedidos,
       sum(CASE WHEN gobernanza.fn_decision_efectiva(p, b) IN ('NEGADO', 'LIMITADO') THEN b.dias_solicitados - gobernanza.fn_dias_efectivos(p, b) ELSE 0 END) AS dias_negados,
       sum(CASE WHEN gobernanza.fn_decision_efectiva(p, b) = 'EN ESPERA' THEN b.dias_solicitados ELSE 0 END) AS dias_en_espera,
       b.id_persona, a.id_estamento_pertenencia AS id_estamento
  FROM gobernanza.permiso_sindical_beneficiario b
  JOIN gobernanza.permiso_sindical p ON p.id_permiso = b.id_permiso
  JOIN gobernanza.afiliado a ON a.id_persona = b.id_persona
  LEFT JOIN gobernanza.estamento ep ON ep.id_estamento = a.id_estamento_pertenencia
 WHERE p.estado <> 'ANULADO'
 GROUP BY 1, 2, 3, b.id_persona, a.id_estamento_pertenencia;

-- Visibilidad sin recursión entre las dos tablas (funciones que no aplican RLS)
CREATE OR REPLACE FUNCTION gobernanza.fn_permiso_de_juntas(p_id_permiso BIGINT, p_juntas BIGINT[])
RETURNS BOOLEAN AS $$
    SELECT EXISTS (SELECT 1 FROM gobernanza.permiso_sindical p WHERE p.id_permiso = p_id_permiso AND p.id_estamento_solicita = ANY (p_juntas))
        OR EXISTS (SELECT 1 FROM gobernanza.permiso_sindical_beneficiario b JOIN gobernanza.afiliado a ON a.id_persona = b.id_persona
                    WHERE b.id_permiso = p_id_permiso AND a.id_estamento_pertenencia = ANY (p_juntas));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- C. CORREOS AUTOMÁTICOS
-- ----------------------------------------------------------------------------
INSERT INTO notificaciones.tipo_notificacion (codigo, nombre, descripcion) VALUES
    ('PERMISOS_SINDICALES', 'Plazos de los permisos sindicales',
     'Al Presidente y al Secretario General de la junta que pidió el permiso: aviso cuando faltan 2 días hábiles para que venza el plazo de respuesta de la entidad y cuando el permiso queda concedido por silencio.'),
    ('DESIGNACIONES_PENDIENTES', 'Designaciones sin registro del inspector',
     'Al Presidente y al Secretario General de la junta: resumen semanal de las designaciones que llevan más de 30 días esperando el registro del inspector (quien fue designado no ejerce el cargo hasta entonces).')
ON CONFLICT (codigo) DO NOTHING;

-- ----------------------------------------------------------------------------
-- D. PERMISOS DE LA BASE
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        GRANT SELECT ON gobernanza.designacion_directivo, gobernanza.permiso_sindical, gobernanza.permiso_sindical_beneficiario TO sgs_app;
        GRANT SELECT, UPDATE ON gobernanza.parametro_permiso TO sgs_app;
        GRANT SELECT ON gobernanza.v_designaciones, gobernanza.v_inscripcion_directivos, gobernanza.v_permisos_sindicales,
                        gobernanza.v_permisos_beneficiarios, gobernanza.v_permisos_por_afiliado TO sgs_app;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_lectura') THEN
        GRANT SELECT ON gobernanza.designacion_directivo, gobernanza.permiso_sindical, gobernanza.permiso_sindical_beneficiario,
                        gobernanza.parametro_permiso, gobernanza.v_designaciones, gobernanza.v_inscripcion_directivos,
                        gobernanza.v_permisos_sindicales, gobernanza.v_permisos_por_afiliado TO sgs_lectura;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_notificador') THEN
        GRANT SELECT ON gobernanza.designacion_directivo, gobernanza.permiso_sindical, gobernanza.permiso_sindical_beneficiario,
                        gobernanza.parametro_permiso, gobernanza.v_designaciones, gobernanza.v_permisos_sindicales TO sgs_notificador;
    END IF;
END $$;
DO $$ BEGIN
    PERFORM seguridad.fn_aplicar_politicas('gobernanza.designacion_directivo', ':N OR id_estamento = ANY (:E)', 'FALSE');
    PERFORM seguridad.fn_aplicar_politicas('gobernanza.parametro_permiso', 'TRUE', 'seguridad.fn_es_admin()');
    PERFORM seguridad.fn_aplicar_politicas('gobernanza.permiso_sindical',
        ':N OR id_estamento_solicita = ANY (:E) OR gobernanza.fn_permiso_de_juntas(id_permiso, :E)', 'FALSE');
    PERFORM seguridad.fn_aplicar_politicas('gobernanza.permiso_sindical_beneficiario',
        ':N OR gobernanza.fn_permiso_de_juntas(id_permiso, :E)', 'FALSE');
END $$;
