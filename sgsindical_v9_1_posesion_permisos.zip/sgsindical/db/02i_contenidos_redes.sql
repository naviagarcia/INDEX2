-- ============================================================================
-- SGSINDICAL v9.1 — 02i: ESTRATEGIA DE CONTENIDOS EN REDES (EDUCACIÓN EN DERECHOS LABORALES)
-- Ejecutar DESPUÉS de 02h y ANTES de 03.
-- ----------------------------------------------------------------------------
--  M1. POLÍTICA DE COMUNICACIONES por junta: objetivos, públicos, mensajes clave, tono, ejes, reglas
--      y frecuencia. La puede redactar la IA; rige cuando se aprueba con un acta (ACT) de la junta.
--  M2. CALENDARIO EDITORIAL: piezas programadas por fecha, red y eje temático, más las fechas clave
--      del mundo del trabajo (1 de mayo, 28 de abril, 8 de marzo…).
--  M3. PIEZAS: la IA redacta en lenguaje sencillo, a partir de un tema (y de normas o documentos
--      pegados), en el formato elegido: guion de video corto, carrusel, hilo para X, publicación,
--      mensaje de WhatsApp, boletín, infografía o preguntas y respuestas.
--  M4. REVISIÓN HUMANA OBLIGATORIA: dos aprobaciones sobre la misma versión — JURÍDICA (abogado o
--      Secretario Jurídico de la junta) y de COMUNICACIONES (Secretario de Comunicaciones; en los
--      comités, Presidente o Secretario General). Cambiar el texto anula las aprobaciones.
--  M5. PUBLICACIÓN Y MEDICIÓN: se registra en qué cuenta y con qué enlace se publicó (actualiza la
--      última publicación de la cuenta: alerta de 5 días) y luego su alcance e interacciones.
-- ============================================================================
CREATE TABLE IF NOT EXISTS gobernanza.eje_tematico (
    codigo VARCHAR(20) PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    descripcion TEXT,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gobernanza.eje_tematico IS 'Ejes temáticos de los contenidos educativos (derechos laborales del sector público).';
INSERT INTO gobernanza.eje_tematico (codigo, nombre, descripcion) VALUES
    ('CARRERA', 'Carrera administrativa y concursos', 'Mérito, concursos de la CNSC, provisionalidad, evaluación del desempeño.'),
    ('NEGOCIACION', 'Negociación colectiva en el sector público', 'Pliegos, mesas de negociación y acuerdos colectivos de empleados públicos.'),
    ('LIBERTAD_SINDICAL', 'Libertad sindical y fuero sindical', 'Derecho de asociación, fuero, permisos sindicales, Convenios 87 y 98 de la OIT.'),
    ('ACOSO', 'Acoso laboral', 'Conductas, comité de convivencia, cómo denunciar y protegerse.'),
    ('SST', 'Seguridad y salud en el trabajo', 'Riesgos laborales, salud mental, accidentes y enfermedades laborales.'),
    ('PETICION', 'Derecho de petición', 'Cómo pedir información y respuestas a la entidad, y qué hacer si no responden.'),
    ('ESTABILIDAD', 'Estabilidad laboral reforzada', 'Protección por salud, embarazo, prepensión, fuero.'),
    ('JORNADA', 'Jornada, horas extra y descansos', 'Jornada laboral, trabajo suplementario, vacaciones y licencias.'),
    ('CONTRATISTAS', 'Formalización laboral y contratistas', 'Contratos de prestación de servicios, formalización y derechos.'),
    ('IGUALDAD', 'Igualdad, género y no discriminación', 'Equidad salarial, acoso sexual, inclusión y diversidad.'),
    ('SINDICATO', 'Vida sindical y afiliación', 'Por qué afiliarse, logros del sindicato, rendición de cuentas.')
ON CONFLICT (codigo) DO NOTHING;

CREATE TABLE IF NOT EXISTS gobernanza.fecha_clave (
    id_fecha BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    mes INT NOT NULL CHECK (mes BETWEEN 1 AND 12),
    dia INT NOT NULL CHECK (dia BETWEEN 1 AND 31),
    nombre VARCHAR(150) NOT NULL,
    codigo_eje VARCHAR(20) REFERENCES gobernanza.eje_tematico(codigo) ON DELETE SET NULL,
    dias_anticipacion INT NOT NULL DEFAULT 14 CHECK (dias_anticipacion BETWEEN 1 AND 90),
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    version INT NOT NULL DEFAULT 1,
    UNIQUE (mes, dia, nombre)
);
COMMENT ON TABLE gobernanza.fecha_clave IS 'Fechas del año para preparar contenidos con anticipación (editable).';
CREATE INDEX IF NOT EXISTS ix_fecha_clave_eje ON gobernanza.fecha_clave (codigo_eje);
INSERT INTO gobernanza.fecha_clave (mes, dia, nombre, codigo_eje) VALUES
    (3, 8, 'Día Internacional de la Mujer', 'IGUALDAD'),
    (4, 28, 'Día Mundial de la Seguridad y la Salud en el Trabajo', 'SST'),
    (5, 1, 'Día Internacional de los Trabajadores', 'SINDICATO'),
    (10, 7, 'Jornada Mundial por el Trabajo Decente', 'SINDICATO'),
    (12, 10, 'Día de los Derechos Humanos', 'LIBERTAD_SINDICAL')
ON CONFLICT (mes, dia, nombre) DO NOTHING;

CREATE TABLE IF NOT EXISTS gobernanza.politica_comunicacion (
    id_politica BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    titulo VARCHAR(200) NOT NULL DEFAULT 'Política de comunicaciones y contenidos',
    objetivos TEXT,
    publicos TEXT,
    mensajes_clave TEXT,
    tono TEXT,
    reglas TEXT,
    publicaciones_por_semana INT NOT NULL DEFAULT 3 CHECK (publicaciones_por_semana BETWEEN 1 AND 50),
    texto TEXT,
    notas_ia TEXT,
    generando BOOLEAN NOT NULL DEFAULT FALSE,
    error_generacion TEXT,
    id_acta_aprobacion BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    vigente BOOLEAN NOT NULL DEFAULT FALSE,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_politica_vigente CHECK (NOT vigente OR id_acta_aprobacion IS NOT NULL)
);
COMMENT ON TABLE gobernanza.politica_comunicacion IS 'Política de comunicaciones de cada junta. Rige (vigente) cuando se aprueba con un acta de la junta.';
CREATE UNIQUE INDEX IF NOT EXISTS ux_politica_vigente ON gobernanza.politica_comunicacion (id_estamento) WHERE vigente;
CREATE INDEX IF NOT EXISTS ix_politica_estamento ON gobernanza.politica_comunicacion (id_estamento);
CREATE INDEX IF NOT EXISTS ix_politica_acta ON gobernanza.politica_comunicacion (id_acta_aprobacion);

CREATE TABLE IF NOT EXISTS gobernanza.pieza_contenido (
    id_pieza BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    titulo VARCHAR(200) NOT NULL,
    codigo_eje VARCHAR(20) REFERENCES gobernanza.eje_tematico(codigo) ON DELETE RESTRICT,
    formato VARCHAR(15) NOT NULL CHECK (formato IN ('VIDEO_CORTO', 'CARRUSEL', 'HILO', 'PUBLICACION', 'WHATSAPP', 'BOLETIN', 'INFOGRAFIA', 'PREGUNTAS')),
    publico VARCHAR(200),
    redes_destino VARCHAR(200),
    fecha_programada DATE,
    id_fecha_clave BIGINT REFERENCES gobernanza.fecha_clave(id_fecha) ON DELETE SET NULL,
    id_persona_responsable BIGINT REFERENCES gobernanza.persona(id_persona) ON DELETE SET NULL,
    instrucciones TEXT,
    material_base TEXT,
    estado VARCHAR(20) NOT NULL DEFAULT 'IDEA'
        CHECK (estado IN ('IDEA', 'EN_REVISION', 'CAMBIOS_SOLICITADOS', 'APROBADA', 'PUBLICADA', 'DESCARTADA')),
    version_actual INT NOT NULL DEFAULT 0,
    contenido TEXT,
    notas_ia TEXT,
    generando BOOLEAN NOT NULL DEFAULT FALSE,
    error_generacion TEXT,
    motivo_descarte TEXT,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gobernanza.pieza_contenido IS 'Piezas del calendario editorial: contenidos educativos sobre derechos laborales para las redes del sindicato.';
COMMENT ON COLUMN gobernanza.pieza_contenido.material_base IS 'Normas, noticias o documentos pegados que la IA debe usar como fuente.';
CREATE INDEX IF NOT EXISTS ix_pieza_estamento_fecha ON gobernanza.pieza_contenido (id_estamento, fecha_programada);
CREATE INDEX IF NOT EXISTS ix_pieza_eje ON gobernanza.pieza_contenido (codigo_eje);
CREATE INDEX IF NOT EXISTS ix_pieza_fecha_clave ON gobernanza.pieza_contenido (id_fecha_clave);
CREATE INDEX IF NOT EXISTS ix_pieza_responsable ON gobernanza.pieza_contenido (id_persona_responsable);

CREATE TABLE IF NOT EXISTS gobernanza.pieza_version (
    id_version BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_pieza BIGINT NOT NULL REFERENCES gobernanza.pieza_contenido(id_pieza) ON DELETE CASCADE,
    numero INT NOT NULL,
    origen VARCHAR(10) NOT NULL CHECK (origen IN ('IA', 'EDICION')),
    contenido TEXT NOT NULL,
    notas_ia TEXT,
    instrucciones TEXT,
    modelo_ia VARCHAR(60),
    id_usuario BIGINT REFERENCES seguridad.usuario(id_usuario) ON DELETE SET NULL,
    nombre_usuario VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    fecha TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (id_pieza, numero)
);
CREATE INDEX IF NOT EXISTS ix_pieza_version_usuario ON gobernanza.pieza_version (id_usuario);

CREATE TABLE IF NOT EXISTS gobernanza.pieza_revision (
    id_revision BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_pieza BIGINT NOT NULL REFERENCES gobernanza.pieza_contenido(id_pieza) ON DELETE CASCADE,
    numero_version INT NOT NULL,
    rol VARCHAR(14) NOT NULL CHECK (rol IN ('JURIDICA', 'COMUNICACIONES', 'COMENTARIO')),
    decision VARCHAR(10) NOT NULL CHECK (decision IN ('APRUEBA', 'CAMBIOS', 'COMENTA')),
    comentario TEXT,
    id_usuario BIGINT NOT NULL REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    nombre_usuario VARCHAR(50) NOT NULL,
    cargo VARCHAR(80),
    fecha TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_pieza_revision_comentario CHECK (decision = 'APRUEBA' OR NULLIF(trim(comentario), '') IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS ix_pieza_revision_pieza ON gobernanza.pieza_revision (id_pieza, numero_version);
CREATE INDEX IF NOT EXISTS ix_pieza_revision_usuario ON gobernanza.pieza_revision (id_usuario);
CREATE UNIQUE INDEX IF NOT EXISTS ux_pieza_aprobacion ON gobernanza.pieza_revision (id_pieza, numero_version, rol) WHERE decision = 'APRUEBA';

CREATE TABLE IF NOT EXISTS gobernanza.pieza_publicacion (
    id_publicacion BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_pieza BIGINT NOT NULL REFERENCES gobernanza.pieza_contenido(id_pieza) ON DELETE RESTRICT,
    id_cuenta_red BIGINT NOT NULL REFERENCES gobernanza.cuenta_red_social(id_cuenta_red) ON DELETE RESTRICT,
    fecha_publicacion DATE NOT NULL DEFAULT CURRENT_DATE,
    url VARCHAR(400),
    alcance INT CHECK (alcance >= 0),
    interacciones INT CHECK (interacciones >= 0),
    compartidos INT CHECK (compartidos >= 0),
    comentarios INT CHECK (comentarios >= 0),
    fecha_medicion DATE,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    UNIQUE (id_pieza, id_cuenta_red),
    CONSTRAINT ck_publicacion_fecha CHECK (fecha_publicacion <= CURRENT_DATE)
);
COMMENT ON TABLE gobernanza.pieza_publicacion IS 'Dónde se publicó cada pieza y sus resultados (alcance, interacciones).';
CREATE INDEX IF NOT EXISTS ix_publicacion_cuenta ON gobernanza.pieza_publicacion (id_cuenta_red, fecha_publicacion);

DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['gobernanza.eje_tematico', 'gobernanza.fecha_clave', 'gobernanza.politica_comunicacion',
                             'gobernanza.pieza_contenido', 'gobernanza.pieza_publicacion'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_control_version ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_control_version BEFORE UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version()', t);
    END LOOP;
    FOREACH t IN ARRAY ARRAY['gobernanza.eje_tematico', 'gobernanza.fecha_clave', 'gobernanza.politica_comunicacion',
                             'gobernanza.pieza_contenido', 'gobernanza.pieza_version', 'gobernanza.pieza_revision',
                             'gobernanza.pieza_publicacion'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_auditoria ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria()', t);
    END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- 1. PROTECCIONES
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION gobernanza.fn_contenidos_proteger()
RETURNS TRIGGER AS $$
BEGIN
    IF COALESCE(current_setting('contenidos.operacion', true), '') <> '' THEN
        RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
    END IF;
    IF TG_TABLE_NAME = 'pieza_contenido' THEN
        IF TG_OP = 'INSERT' THEN
            NEW.estado := 'IDEA'; NEW.version_actual := 0; NEW.contenido := NULL; NEW.notas_ia := NULL; NEW.generando := FALSE;
            RETURN NEW;
        END IF;
        IF TG_OP = 'DELETE' THEN
            IF OLD.version_actual > 0 THEN RAISE EXCEPTION 'Una pieza con versiones no se elimina: descártela indicando el motivo.'; END IF;
            RETURN OLD;
        END IF;
        IF OLD.estado = 'DESCARTADA' THEN RAISE EXCEPTION 'La pieza fue descartada.'; END IF;
        IF NEW.estado IS DISTINCT FROM OLD.estado OR NEW.version_actual IS DISTINCT FROM OLD.version_actual
           OR NEW.contenido IS DISTINCT FROM OLD.contenido OR NEW.notas_ia IS DISTINCT FROM OLD.notas_ia
           OR NEW.generando IS DISTINCT FROM OLD.generando OR NEW.id_estamento IS DISTINCT FROM OLD.id_estamento THEN
            RAISE EXCEPTION 'El texto y el estado de la pieza los cambian la redacción, la edición, la revisión y la publicación.';
        END IF;
        IF OLD.estado = 'PUBLICADA' AND (NEW.formato IS DISTINCT FROM OLD.formato OR NEW.titulo IS DISTINCT FROM OLD.titulo) THEN
            RAISE EXCEPTION 'La pieza ya se publicó.';
        END IF;
        RETURN NEW;
    END IF;
    IF TG_TABLE_NAME = 'politica_comunicacion' THEN
        IF TG_OP = 'INSERT' THEN NEW.vigente := FALSE; NEW.id_acta_aprobacion := NULL; NEW.generando := FALSE; RETURN NEW; END IF;
        IF TG_OP = 'DELETE' THEN
            IF OLD.id_acta_aprobacion IS NOT NULL THEN RAISE EXCEPTION 'Una política aprobada en acta no se elimina; se reemplaza por una nueva.'; END IF;
            RETURN OLD;
        END IF;
        IF OLD.id_acta_aprobacion IS NOT NULL THEN
            RAISE EXCEPTION 'La política ya fue aprobada en acta: para cambiarla, cree una versión nueva y apruébela.';
        END IF;
        IF NEW.vigente IS DISTINCT FROM OLD.vigente OR NEW.id_acta_aprobacion IS DISTINCT FROM OLD.id_acta_aprobacion
           OR NEW.generando IS DISTINCT FROM OLD.generando OR NEW.id_estamento IS DISTINCT FROM OLD.id_estamento THEN
            RAISE EXCEPTION 'La política entra en vigencia con la aprobación en acta (botón Aprobar con acta).';
        END IF;
        RETURN NEW;
    END IF;
    -- Publicaciones: solo de piezas aprobadas o ya publicadas, en cuentas de la misma junta
    IF TG_TABLE_NAME = 'pieza_publicacion' AND TG_OP = 'INSERT' THEN
        IF NOT EXISTS (SELECT 1 FROM gobernanza.pieza_contenido p WHERE p.id_pieza = NEW.id_pieza AND p.estado IN ('APROBADA', 'PUBLICADA')) THEN
            RAISE EXCEPTION 'Solo se publica una pieza aprobada (revisión jurídica y de comunicaciones).';
        END IF;
        IF NOT EXISTS (SELECT 1 FROM gobernanza.pieza_contenido p JOIN gobernanza.cuenta_red_social c ON c.id_estamento = p.id_estamento
                        WHERE p.id_pieza = NEW.id_pieza AND c.id_cuenta_red = NEW.id_cuenta_red) THEN
            RAISE EXCEPTION 'La cuenta debe ser de la misma junta que la pieza.';
        END IF;
    END IF;
    IF TG_TABLE_NAME = 'pieza_publicacion' AND TG_OP = 'UPDATE'
       AND (NEW.id_pieza IS DISTINCT FROM OLD.id_pieza OR NEW.id_cuenta_red IS DISTINCT FROM OLD.id_cuenta_red) THEN
        RAISE EXCEPTION 'Solo se actualizan el enlace, la fecha y las métricas de la publicación.';
    END IF;
    RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['gobernanza.pieza_contenido', 'gobernanza.politica_comunicacion', 'gobernanza.pieza_publicacion'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_contenidos_proteger ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_contenidos_proteger BEFORE INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_contenidos_proteger()', t);
    END LOOP;
END $$;

-- Al publicar: la pieza queda PUBLICADA y la cuenta registra su última publicación (alerta de 5 días)
CREATE OR REPLACE FUNCTION gobernanza.fn_pieza_publicada()
RETURNS TRIGGER AS $$
BEGIN
    PERFORM set_config('contenidos.operacion', 'publicar', true);
    UPDATE gobernanza.pieza_contenido SET estado = 'PUBLICADA' WHERE id_pieza = NEW.id_pieza AND estado <> 'PUBLICADA';
    PERFORM set_config('contenidos.operacion', '', true);
    UPDATE gobernanza.cuenta_red_social SET fecha_ultima_publicacion = NEW.fecha_publicacion
     WHERE id_cuenta_red = NEW.id_cuenta_red AND (fecha_ultima_publicacion IS NULL OR fecha_ultima_publicacion < NEW.fecha_publicacion);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
DROP TRIGGER IF EXISTS trg_pieza_publicada ON gobernanza.pieza_publicacion;
CREATE TRIGGER trg_pieza_publicada AFTER INSERT OR UPDATE OF fecha_publicacion ON gobernanza.pieza_publicacion
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_pieza_publicada();

-- ----------------------------------------------------------------------------
-- 2. VERSIONES, REVISIÓN Y DESCARTE DE PIEZAS
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION gobernanza.fn_ambito_pieza(p_id_estamento BIGINT)
RETURNS BOOLEAN AS $$
    SELECT seguridad.fn_ambito_nacional() OR p_id_estamento = ANY(seguridad.fn_ambito_estamentos());
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_rol_revision_pieza(p_id_pieza BIGINT, OUT rol TEXT, OUT cargo TEXT)
AS $$
DECLARE v_u seguridad.usuario; v_p gobernanza.pieza_contenido; v_c RECORD;
BEGIN
    SELECT * INTO v_u FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo;
    SELECT * INTO v_p FROM gobernanza.pieza_contenido WHERE id_pieza = p_id_pieza;
    IF v_u.id_usuario IS NULL OR v_p.id_pieza IS NULL THEN rol := NULL; RETURN; END IF;
    IF v_u.codigo_rol = 'ABOGADO' AND gobernanza.fn_ambito_pieza(v_p.id_estamento) THEN rol := 'JURIDICA'; cargo := 'Abogado'; RETURN; END IF;
    SELECT c.codigo, c.nombre, e.tipo_estamento INTO v_c
      FROM gobernanza.directivo_estamento d
      JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
      JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento
     WHERE d.id_persona = v_u.id_persona AND d.id_estamento = v_p.id_estamento AND d.fecha_retiro IS NULL
       AND (c.codigo LIKE 'SJUR\_%' OR c.codigo LIKE 'SCOM\_%' OR (e.tipo_estamento = 'COMITÉ SECCIONAL' AND (c.codigo LIKE 'PRES\_%' OR c.codigo LIKE 'SGEN\_%')))
     ORDER BY c.orden LIMIT 1;
    IF v_c.codigo LIKE 'SJUR\_%' THEN rol := 'JURIDICA'; cargo := v_c.nombre; RETURN; END IF;
    IF v_c.codigo IS NOT NULL THEN rol := 'COMUNICACIONES'; cargo := v_c.nombre; RETURN; END IF;
    rol := 'COMENTARIO'; cargo := NULL;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_guardar_version_pieza(p_id_pieza BIGINT, p_version_base INT, p_contenido TEXT, p_origen TEXT,
                                                              p_notas TEXT DEFAULT NULL, p_instrucciones TEXT DEFAULT NULL, p_modelo TEXT DEFAULT NULL)
RETURNS INT AS $$
DECLARE v_p gobernanza.pieza_contenido; v_n INT;
BEGIN
    SELECT * INTO v_p FROM gobernanza.pieza_contenido WHERE id_pieza = p_id_pieza FOR UPDATE;
    IF v_p.id_pieza IS NULL OR NOT gobernanza.fn_ambito_pieza(v_p.id_estamento) THEN
        RAISE EXCEPTION 'La pieza no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v_p.estado IN ('PUBLICADA', 'DESCARTADA') THEN RAISE EXCEPTION 'La pieza ya está %: no se modifica.', lower(v_p.estado); END IF;
    IF p_version_base IS DISTINCT FROM v_p.version_actual THEN
        RAISE EXCEPTION 'Otra persona guardó una versión nueva (versión %) mientras usted trabajaba sobre la %. Recargue y vuelva a aplicar sus cambios.',
            v_p.version_actual, p_version_base USING ERRCODE = 'serialization_failure';
    END IF;
    IF NULLIF(trim(p_contenido), '') IS NULL THEN RAISE EXCEPTION 'El texto de la pieza está vacío.'; END IF;
    IF p_contenido = v_p.contenido THEN RAISE EXCEPTION 'No hay cambios en el texto.'; END IF;
    v_n := v_p.version_actual + 1;
    INSERT INTO gobernanza.pieza_version (id_pieza, numero, origen, contenido, notas_ia, instrucciones, modelo_ia, id_usuario)
    VALUES (p_id_pieza, v_n, p_origen, p_contenido, p_notas, p_instrucciones, p_modelo, seguridad.fn_id_usuario_actual());
    PERFORM set_config('contenidos.operacion', 'version', true);
    UPDATE gobernanza.pieza_contenido SET contenido = p_contenido, version_actual = v_n, estado = 'EN_REVISION', generando = FALSE,
           error_generacion = NULL, notas_ia = CASE WHEN p_origen = 'IA' THEN p_notas ELSE notas_ia END
     WHERE id_pieza = p_id_pieza;
    PERFORM set_config('contenidos.operacion', '', true);
    RETURN v_n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_marcar_generacion_contenido(p_tabla TEXT, p_id BIGINT, p_generando BOOLEAN, p_error TEXT DEFAULT NULL)
RETURNS VOID AS $$
DECLARE v_est BIGINT; v_gen BOOLEAN; v_estado TEXT;
BEGIN
    IF p_tabla = 'pieza' THEN
        SELECT id_estamento, generando, estado INTO v_est, v_gen, v_estado FROM gobernanza.pieza_contenido WHERE id_pieza = p_id FOR UPDATE;
    ELSE
        SELECT id_estamento, generando, CASE WHEN id_acta_aprobacion IS NULL THEN 'BORRADOR' ELSE 'APROBADA' END
          INTO v_est, v_gen, v_estado FROM gobernanza.politica_comunicacion WHERE id_politica = p_id FOR UPDATE;
    END IF;
    IF v_est IS NULL OR NOT gobernanza.fn_ambito_pieza(v_est) THEN RAISE EXCEPTION 'No existe o está fuera de su ámbito territorial.'; END IF;
    IF p_generando AND v_gen THEN RAISE EXCEPTION 'La IA ya está redactando; espere a que termine.'; END IF;
    IF p_generando AND v_estado IN ('PUBLICADA', 'DESCARTADA', 'APROBADA') AND p_tabla <> 'pieza' THEN
        RAISE EXCEPTION 'La política ya fue aprobada en acta: cree una nueva para cambiarla.';
    END IF;
    IF p_generando AND p_tabla = 'pieza' AND v_estado IN ('PUBLICADA', 'DESCARTADA') THEN
        RAISE EXCEPTION 'La pieza ya está %: no se modifica.', lower(v_estado);
    END IF;
    PERFORM set_config('contenidos.operacion', 'generar', true);
    IF p_tabla = 'pieza' THEN
        UPDATE gobernanza.pieza_contenido SET generando = p_generando, error_generacion = p_error WHERE id_pieza = p_id;
    ELSE
        UPDATE gobernanza.politica_comunicacion SET generando = p_generando, error_generacion = p_error WHERE id_politica = p_id;
    END IF;
    PERFORM set_config('contenidos.operacion', '', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_guardar_politica_ia(p_id_politica BIGINT, p_texto TEXT, p_notas TEXT)
RETURNS VOID AS $$
DECLARE v_est BIGINT;
BEGIN
    SELECT id_estamento INTO v_est FROM gobernanza.politica_comunicacion WHERE id_politica = p_id_politica FOR UPDATE;
    IF v_est IS NULL OR NOT gobernanza.fn_ambito_pieza(v_est) THEN RAISE EXCEPTION 'No existe o está fuera de su ámbito territorial.'; END IF;
    PERFORM set_config('contenidos.operacion', 'generar', true);
    UPDATE gobernanza.politica_comunicacion SET texto = p_texto, notas_ia = p_notas, generando = FALSE, error_generacion = NULL
     WHERE id_politica = p_id_politica AND id_acta_aprobacion IS NULL;
    PERFORM set_config('contenidos.operacion', '', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_revisar_pieza(p_id_pieza BIGINT, p_numero_version INT, p_decision TEXT, p_comentario TEXT)
RETURNS TEXT AS $$
DECLARE v_p gobernanza.pieza_contenido; v_r RECORD; v_u seguridad.usuario; v_aprob INT; v_cambios BOOLEAN; v_estado TEXT;
BEGIN
    SELECT * INTO v_p FROM gobernanza.pieza_contenido WHERE id_pieza = p_id_pieza FOR UPDATE;
    IF v_p.id_pieza IS NULL OR NOT gobernanza.fn_ambito_pieza(v_p.id_estamento) THEN
        RAISE EXCEPTION 'La pieza no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v_p.estado NOT IN ('EN_REVISION', 'CAMBIOS_SOLICITADOS', 'APROBADA') THEN
        RAISE EXCEPTION 'La pieza no está en revisión.';
    END IF;
    IF p_numero_version IS DISTINCT FROM v_p.version_actual THEN
        RAISE EXCEPTION 'Usted revisó la versión %, pero ya existe la versión %. Revise la versión vigente.', p_numero_version, v_p.version_actual
            USING ERRCODE = 'serialization_failure';
    END IF;
    IF p_decision NOT IN ('APRUEBA', 'CAMBIOS', 'COMENTA') THEN RAISE EXCEPTION 'Decisión no válida.'; END IF;
    SELECT * INTO v_r FROM gobernanza.fn_rol_revision_pieza(p_id_pieza);
    IF p_decision = 'APRUEBA' AND v_r.rol = 'COMENTARIO' THEN
        RAISE EXCEPTION 'Aprueban el abogado o el Secretario Jurídico (revisión jurídica) y el Secretario de Comunicaciones (en comités, el Presidente o el Secretario General). Usted puede comentar.';
    END IF;
    IF p_decision = 'APRUEBA' AND EXISTS (SELECT 1 FROM gobernanza.pieza_revision WHERE id_pieza = p_id_pieza
            AND numero_version = v_p.version_actual AND rol = v_r.rol AND decision = 'APRUEBA') THEN
        RAISE EXCEPTION 'La aprobación % de esta versión ya está registrada.', CASE v_r.rol WHEN 'JURIDICA' THEN 'jurídica' ELSE 'de comunicaciones' END;
    END IF;
    SELECT * INTO v_u FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual();
    INSERT INTO gobernanza.pieza_revision (id_pieza, numero_version, rol, decision, comentario, id_usuario, nombre_usuario, cargo)
    VALUES (p_id_pieza, v_p.version_actual, CASE WHEN p_decision = 'COMENTA' THEN 'COMENTARIO' ELSE v_r.rol END, p_decision,
            NULLIF(trim(p_comentario), ''), v_u.id_usuario, v_u.nombre_usuario, v_r.cargo);
    SELECT count(DISTINCT rol) FILTER (WHERE decision = 'APRUEBA'), bool_or(decision = 'CAMBIOS') INTO v_aprob, v_cambios
      FROM gobernanza.pieza_revision WHERE id_pieza = p_id_pieza AND numero_version = v_p.version_actual;
    v_estado := CASE WHEN v_aprob = 2 THEN 'APROBADA' WHEN v_cambios THEN 'CAMBIOS_SOLICITADOS' ELSE 'EN_REVISION' END;
    PERFORM set_config('contenidos.operacion', 'revisar', true);
    UPDATE gobernanza.pieza_contenido SET estado = v_estado WHERE id_pieza = p_id_pieza;
    PERFORM set_config('contenidos.operacion', '', true);
    RETURN v_estado;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_descartar_pieza(p_id_pieza BIGINT, p_motivo TEXT)
RETURNS VOID AS $$
DECLARE v_p gobernanza.pieza_contenido;
BEGIN
    SELECT * INTO v_p FROM gobernanza.pieza_contenido WHERE id_pieza = p_id_pieza FOR UPDATE;
    IF v_p.id_pieza IS NULL OR NOT gobernanza.fn_ambito_pieza(v_p.id_estamento) THEN
        RAISE EXCEPTION 'La pieza no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v_p.estado IN ('PUBLICADA', 'DESCARTADA') THEN RAISE EXCEPTION 'La pieza ya está %.', lower(v_p.estado); END IF;
    IF NULLIF(trim(p_motivo), '') IS NULL THEN RAISE EXCEPTION 'Indique el motivo para descartar la pieza.'; END IF;
    PERFORM set_config('contenidos.operacion', 'descartar', true);
    UPDATE gobernanza.pieza_contenido SET estado = 'DESCARTADA', motivo_descarte = trim(p_motivo), generando = FALSE WHERE id_pieza = p_id_pieza;
    PERFORM set_config('contenidos.operacion', '', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- La política rige con un acta (ACT) de la misma junta; reemplaza a la anterior
CREATE OR REPLACE FUNCTION gobernanza.fn_aprobar_politica(p_id_politica BIGINT, p_id_acta BIGINT)
RETURNS VOID AS $$
DECLARE v_p gobernanza.politica_comunicacion; v_acta RECORD; v_mesa RECORD;
BEGIN
    SELECT * INTO v_p FROM gobernanza.politica_comunicacion WHERE id_politica = p_id_politica FOR UPDATE;
    IF v_p.id_politica IS NULL OR NOT gobernanza.fn_ambito_pieza(v_p.id_estamento) THEN
        RAISE EXCEPTION 'La política no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v_p.id_acta_aprobacion IS NOT NULL THEN RAISE EXCEPTION 'La política ya fue aprobada.'; END IF;
    IF NULLIF(trim(COALESCE(v_p.texto, '')), '') IS NULL AND NULLIF(trim(COALESCE(v_p.objetivos, '')), '') IS NULL THEN
        RAISE EXCEPTION 'La política está vacía.';
    END IF;
    SELECT * INTO v_mesa FROM gestion_documental.fn_cargo_mesa(v_p.id_estamento);
    IF v_mesa.rol IS NULL THEN RAISE EXCEPTION 'La aprobación la registran el Presidente o el Secretario General de la junta.'; END IF;
    SELECT d.id_estamento, t.sigla_tipo INTO v_acta FROM gestion_documental.documento d
      JOIN gestion_documental.tipo_documento t ON t.id_tipo_documento = d.id_tipo_documento WHERE d.id_documento = p_id_acta;
    IF v_acta.sigla_tipo IS DISTINCT FROM 'ACT' OR v_acta.id_estamento IS DISTINCT FROM v_p.id_estamento THEN
        RAISE EXCEPTION 'La política se aprueba con un acta de reunión (ACT) de la misma junta.';
    END IF;
    PERFORM set_config('contenidos.operacion', 'aprobar', true);
    UPDATE gobernanza.politica_comunicacion SET vigente = FALSE WHERE id_estamento = v_p.id_estamento AND vigente;
    UPDATE gobernanza.politica_comunicacion SET vigente = TRUE, id_acta_aprobacion = p_id_acta WHERE id_politica = p_id_politica;
    PERFORM set_config('contenidos.operacion', '', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 3. VISTAS: CALENDARIO, CONTROL Y RENDIMIENTO
-- ----------------------------------------------------------------------------
-- Próxima ocurrencia (hoy o después) de un día y mes; el 29 de febrero cae el 28 en años no bisiestos
CREATE OR REPLACE FUNCTION gobernanza.fn_proxima_fecha(p_mes INT, p_dia INT)
RETURNS DATE AS $$
DECLARE v_anio INT := EXTRACT(YEAR FROM CURRENT_DATE)::INT; v_f DATE;
BEGIN
    FOR i IN 0..1 LOOP
        v_f := make_date(v_anio + i, p_mes, 1);
        v_f := v_f + (LEAST(p_dia, EXTRACT(DAY FROM (v_f + INTERVAL '1 month' - INTERVAL '1 day'))::INT) - 1);
        IF v_f >= CURRENT_DATE THEN RETURN v_f; END IF;
    END LOOP;
    RETURN v_f;
END;
$$ LANGUAGE plpgsql STABLE;

DROP VIEW IF EXISTS gobernanza.v_calendario_editorial;
CREATE VIEW gobernanza.v_calendario_editorial WITH (security_invoker = true) AS
SELECT p.fecha_programada AS fecha, e.nombre_estamento AS junta, 'PIEZA' AS clase, p.titulo,
       x.nombre AS eje, p.formato, p.redes_destino, p.estado, p.id_pieza, p.id_estamento,
       CASE
           WHEN p.estado = 'PUBLICADA' THEN 'PUBLICADA'
           WHEN p.estado = 'DESCARTADA' THEN 'DESCARTADA'
           WHEN p.fecha_programada < CURRENT_DATE THEN 'ALERTA ALTA: LA FECHA PROGRAMADA PASÓ SIN PUBLICAR'
           WHEN p.fecha_programada <= CURRENT_DATE + 1 AND p.estado <> 'APROBADA' THEN 'ALERTA ALTA: SE PUBLICA PRONTO Y AÚN NO ESTÁ APROBADA'
           WHEN p.estado = 'APROBADA' THEN 'APROBADA, LISTA PARA PUBLICAR'
           ELSE 'EN PREPARACIÓN'
       END AS diagnostico
  FROM gobernanza.pieza_contenido p
  JOIN gobernanza.estamento e ON e.id_estamento = p.id_estamento
  LEFT JOIN gobernanza.eje_tematico x ON x.codigo = p.codigo_eje
 WHERE p.fecha_programada IS NOT NULL AND p.fecha_programada >= CURRENT_DATE - 30
UNION ALL
SELECT f.fecha, e.nombre_estamento, 'FECHA_CLAVE', f.nombre, x.nombre, NULL, NULL, NULL, NULL, e.id_estamento,
       CASE WHEN EXISTS (SELECT 1 FROM gobernanza.pieza_contenido p WHERE p.id_estamento = e.id_estamento AND p.id_fecha_clave = f.id_fecha
                           AND p.estado <> 'DESCARTADA' AND p.fecha_programada BETWEEN f.fecha - 30 AND f.fecha)
            THEN 'FECHA CLAVE CON CONTENIDO PREPARADO'
            WHEN f.fecha - CURRENT_DATE <= f.dias_anticipacion THEN 'ALERTA MEDIA: FECHA CLAVE SIN CONTENIDO PREPARADO'
            ELSE 'FECHA CLAVE PRÓXIMA' END
  FROM (SELECT fc.*, gobernanza.fn_proxima_fecha(fc.mes, fc.dia) AS fecha FROM gobernanza.fecha_clave fc WHERE fc.activo) f
  CROSS JOIN gobernanza.estamento e
  LEFT JOIN gobernanza.eje_tematico x ON x.codigo = f.codigo_eje
 WHERE f.fecha <= CURRENT_DATE + 60
   AND EXISTS (SELECT 1 FROM gobernanza.cuenta_red_social c WHERE c.id_estamento = e.id_estamento AND c.estado = 'ACTIVA');

DROP VIEW IF EXISTS gobernanza.v_auditoria_contenidos;
CREATE VIEW gobernanza.v_auditoria_contenidos WITH (security_invoker = true) AS
WITH juntas AS (
    SELECT e.id_estamento, e.nombre_estamento,
           (SELECT pc.publicaciones_por_semana FROM gobernanza.politica_comunicacion pc WHERE pc.id_estamento = e.id_estamento AND pc.vigente) AS meta_semana,
           EXISTS (SELECT 1 FROM gobernanza.politica_comunicacion pc WHERE pc.id_estamento = e.id_estamento AND pc.vigente) AS tiene_politica
      FROM gobernanza.estamento e
     WHERE EXISTS (SELECT 1 FROM gobernanza.cuenta_red_social c WHERE c.id_estamento = e.id_estamento AND c.estado = 'ACTIVA')
)
SELECT j.id_estamento, j.nombre_estamento AS junta, j.tiene_politica, j.meta_semana,
       (SELECT count(*) FROM gobernanza.pieza_contenido p WHERE p.id_estamento = j.id_estamento AND p.estado NOT IN ('DESCARTADA', 'PUBLICADA')
           AND p.fecha_programada BETWEEN CURRENT_DATE AND CURRENT_DATE + 6)::INT AS programadas_7_dias,
       (SELECT count(DISTINCT pp.id_pieza) FROM gobernanza.pieza_publicacion pp JOIN gobernanza.pieza_contenido p ON p.id_pieza = pp.id_pieza
         WHERE p.id_estamento = j.id_estamento AND pp.fecha_publicacion > CURRENT_DATE - 7)::INT AS publicadas_7_dias,
       (SELECT count(*) FROM gobernanza.pieza_contenido p WHERE p.id_estamento = j.id_estamento AND p.estado IN ('EN_REVISION', 'CAMBIOS_SOLICITADOS'))::INT AS en_revision,
       (SELECT count(*) FROM gobernanza.pieza_contenido p WHERE p.id_estamento = j.id_estamento AND p.estado NOT IN ('PUBLICADA', 'DESCARTADA')
           AND p.fecha_programada < CURRENT_DATE)::INT AS vencidas,
       CASE
           WHEN (SELECT count(*) FROM gobernanza.pieza_contenido p WHERE p.id_estamento = j.id_estamento AND p.estado NOT IN ('PUBLICADA', 'DESCARTADA')
                   AND p.fecha_programada < CURRENT_DATE) > 0 THEN 'ALERTA ALTA: HAY PIEZAS PROGRAMADAS QUE NO SE PUBLICARON'
           WHEN NOT j.tiene_politica THEN 'ALERTA MEDIA: LA JUNTA NO TIENE POLÍTICA DE COMUNICACIONES APROBADA'
           WHEN (SELECT count(*) FROM gobernanza.pieza_contenido p WHERE p.id_estamento = j.id_estamento AND p.estado NOT IN ('DESCARTADA', 'PUBLICADA')
                   AND p.fecha_programada BETWEEN CURRENT_DATE AND CURRENT_DATE + 6) < COALESCE(j.meta_semana, 1)
               THEN 'ALERTA MEDIA: LA PRÓXIMA SEMANA TIENE MENOS CONTENIDOS PROGRAMADOS QUE LA META (' || COALESCE(j.meta_semana, 1) || ')'
           ELSE 'CALENDARIO AL DÍA'
       END AS diagnostico
  FROM juntas j;

DROP VIEW IF EXISTS gobernanza.v_rendimiento_contenidos;
CREATE VIEW gobernanza.v_rendimiento_contenidos WITH (security_invoker = true) AS
SELECT e.nombre_estamento AS junta, COALESCE(x.nombre, 'Sin eje') AS eje, p.formato, c.red,
       count(*)::INT AS publicaciones, sum(pp.alcance)::INT AS alcance, sum(pp.interacciones)::INT AS interacciones,
       sum(pp.compartidos)::INT AS compartidos,
       CASE WHEN sum(pp.alcance) > 0 THEN round(100.0 * sum(pp.interacciones) / sum(pp.alcance), 2) END AS tasa_interaccion,
       max(pp.fecha_publicacion) AS ultima, p.id_estamento
  FROM gobernanza.pieza_publicacion pp
  JOIN gobernanza.pieza_contenido p ON p.id_pieza = pp.id_pieza
  JOIN gobernanza.cuenta_red_social c ON c.id_cuenta_red = pp.id_cuenta_red
  JOIN gobernanza.estamento e ON e.id_estamento = p.id_estamento
  LEFT JOIN gobernanza.eje_tematico x ON x.codigo = p.codigo_eje
 WHERE pp.fecha_publicacion > CURRENT_DATE - 180
 GROUP BY e.nombre_estamento, x.nombre, p.formato, c.red, p.id_estamento;

-- ----------------------------------------------------------------------------
-- 4. SEGURIDAD POR FILAS
-- ----------------------------------------------------------------------------
SELECT seguridad.fn_aplicar_politicas('gobernanza.eje_tematico', 'true', ':N');
SELECT seguridad.fn_aplicar_politicas('gobernanza.fecha_clave', 'true', ':N');
SELECT seguridad.fn_aplicar_politicas('gobernanza.politica_comunicacion', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('gobernanza.pieza_contenido', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('gobernanza.pieza_version',
    'EXISTS (SELECT 1 FROM gobernanza.pieza_contenido p WHERE p.id_pieza = pieza_version.id_pieza)', 'false');
SELECT seguridad.fn_aplicar_politicas('gobernanza.pieza_revision',
    'EXISTS (SELECT 1 FROM gobernanza.pieza_contenido p WHERE p.id_pieza = pieza_revision.id_pieza)', 'false');
SELECT seguridad.fn_aplicar_politicas('gobernanza.pieza_publicacion',
    'EXISTS (SELECT 1 FROM gobernanza.pieza_contenido p WHERE p.id_pieza = pieza_publicacion.id_pieza)',
    'EXISTS (SELECT 1 FROM gobernanza.pieza_contenido p WHERE p.id_pieza = pieza_publicacion.id_pieza)');

-- ----------------------------------------------------------------------------
-- 5. CORREO DIARIO DEL CALENDARIO EDITORIAL
-- ----------------------------------------------------------------------------
INSERT INTO notificaciones.tipo_notificacion (codigo, nombre, descripcion) VALUES
    ('CALENDARIO_CONTENIDOS', 'Calendario editorial de redes',
     'Al Secretario de Comunicaciones (en comités, al Presidente) y al responsable de cada pieza: piezas que se publican hoy o mañana, '
     'piezas sin aprobar o vencidas y fechas clave próximas sin contenido preparado. A los revisores, las piezas pendientes de su aprobación.')
ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, descripcion = EXCLUDED.descripcion;
