-- ============================================================================
-- SGSINDICAL — SCRIPT MASTER UNIFICADO v9.1 (basado en v9.0)
-- Motor: PostgreSQL 12+ (probado en PostgreSQL 16)
-- ----------------------------------------------------------------------------
-- CORRECCIONES RESPECTO A v9.0
--  1. El operador de concatenación venía como '││' (caracteres de dibujo que
--     introdujo Word). Se reemplazó por el operador SQL real '||'.
--  2. Radicados y códigos de expediente: el consecutivo se calculaba con MAX()+1
--     sin bloqueo, así que dos radicaciones simultáneas podían obtener el mismo
--     número. Ahora se serializa con pg_advisory_xact_lock (control de
--     concurrencia) y el consecutivo se calcula por PREFIJO, porque dos
--     subdirectivas del mismo municipio generaban el mismo prefijo y chocaban
--     con la restricción UNIQUE.
--  3. El radicado ahora valida que el flujo del documento coincida con el
--     flujo del tipo documental (un ACT no puede radicarse como RECIBIDO).
--  4. La auditoría y los campos usuario_creacion registran el usuario real de la
--     aplicación (variable de sesión app.usuario) y no solo el usuario de BD.
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE SCHEMA IF NOT EXISTS gobernanza;
CREATE SCHEMA IF NOT EXISTS finanzas;
CREATE SCHEMA IF NOT EXISTS auditoria;
CREATE SCHEMA IF NOT EXISTS gestion_documental;

-- Usuario efectivo: el de la aplicación si viene en la sesión, si no el de BD.
CREATE OR REPLACE FUNCTION auditoria.fn_usuario_actual()
RETURNS VARCHAR AS $$
    SELECT COALESCE(NULLIF(current_setting('app.usuario', true), ''), CURRENT_USER)::VARCHAR;
$$ LANGUAGE sql STABLE;

-- ----------------------------------------------------------------------------
-- 1. AUDITORÍA Y TRAZABILIDAD
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS auditoria.bitacora_cambios (
    id_log BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    esquema_tabla VARCHAR(50) NOT NULL,
    nombre_tabla VARCHAR(50) NOT NULL,
    operacion VARCHAR(10) NOT NULL CHECK (operacion IN ('INSERT', 'UPDATE', 'DELETE')),
    usuario_bd VARCHAR(100) NOT NULL DEFAULT CURRENT_USER,
    fecha_hora TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    datos_anteriores JSONB,
    datos_nuevos JSONB,
    ip_origen INET
);
COMMENT ON TABLE auditoria.bitacora_cambios IS 'Registro inmutable de auditoría para trazabilidad de cambios en columnas críticas.';

CREATE OR REPLACE FUNCTION auditoria.fn_generar_auditoria()
RETURNS TRIGGER AS $$
DECLARE
    v_usuario VARCHAR := auditoria.fn_usuario_actual();
    v_ip INET := COALESCE(NULLIF(current_setting('app.ip', true), '')::INET, inet_client_addr());
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO auditoria.bitacora_cambios(esquema_tabla, nombre_tabla, operacion, usuario_bd, datos_anteriores, ip_origen)
        VALUES (TG_TABLE_SCHEMA, TG_TABLE_NAME, 'DELETE', v_usuario, to_jsonb(OLD), v_ip);
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO auditoria.bitacora_cambios(esquema_tabla, nombre_tabla, operacion, usuario_bd, datos_anteriores, datos_nuevos, ip_origen)
        VALUES (TG_TABLE_SCHEMA, TG_TABLE_NAME, 'UPDATE', v_usuario, to_jsonb(OLD), to_jsonb(NEW), v_ip);
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO auditoria.bitacora_cambios(esquema_tabla, nombre_tabla, operacion, usuario_bd, datos_nuevos, ip_origen)
        VALUES (TG_TABLE_SCHEMA, TG_TABLE_NAME, 'INSERT', v_usuario, to_jsonb(NEW), v_ip);
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 2. GOBERNANZA - SUPERCLASE PERSONA Y SUBCLASES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.persona (
    id_persona BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tipo_dni VARCHAR(10) NOT NULL CHECK (tipo_dni IN ('CC', 'CE', 'PASAPORTE', 'PEP', 'TI', 'OTRO')),
    dni VARCHAR(20) NOT NULL,
    primer_nombre VARCHAR(50) NOT NULL,
    segundo_nombre VARCHAR(50),
    primer_apellido VARCHAR(50) NOT NULL,
    segundo_apellido VARCHAR(50),
    pais VARCHAR(50) DEFAULT 'COLOMBIA',
    departamento VARCHAR(50),
    municipio VARCHAR(50),
    genero VARCHAR(20) CHECK (genero IN ('FEMENINO', 'MASCULINO', 'HOMOSEXUAL', 'BISEXUAL', 'TRAVESTI', 'LESBIANA', 'NO BINARIO', 'OTRO')),
    telefono VARCHAR(20),
    correo_electronico VARCHAR(100) NOT NULL UNIQUE,
    fecha_creacion TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    usuario_creacion VARCHAR(50) DEFAULT auditoria.fn_usuario_actual() NOT NULL,
    fecha_modificacion TIMESTAMP WITH TIME ZONE,
    usuario_modificacion VARCHAR(50),
    CONSTRAINT uk_persona_documento UNIQUE (tipo_dni, dni)
);
COMMENT ON TABLE gobernanza.persona IS 'Superclase PERSONA que centraliza la identidad atómica de todos los individuos.';

CREATE TABLE IF NOT EXISTS gobernanza.afiliado (
    id_persona BIGINT PRIMARY KEY REFERENCES gobernanza.persona(id_persona) ON DELETE CASCADE,
    fecha_afiliacion DATE NOT NULL,
    fecha_nacimiento DATE NOT NULL,
    nivel_educativo VARCHAR(30) NOT NULL CHECK (nivel_educativo IN ('PRIMARIA', 'SECUNDARIA', 'TECNICO', 'TECNOLOGO', 'PROFESIONAL', 'ESPECIALIZACIÓN', 'MAESTRÍA', 'DOCTORADO')),
    area_empresa VARCHAR(100),
    cargo_empresa VARCHAR(30) NOT NULL CHECK (cargo_empresa IN ('ASISTENCIAL', 'TECNICO', 'PROFESIONAL')),
    detalles_cargo TEXT,
    tipo_alimentacion VARCHAR(20) CHECK (tipo_alimentacion IN ('VEGANA', 'VEGETARIANA', 'OMNIVORA')),
    zona_residencia VARCHAR(20) CHECK (zona_residencia IN ('URBANA', 'RURAL', 'MIXTA')),
    CONSTRAINT chk_edad_minima CHECK (fecha_nacimiento <= fecha_afiliacion - INTERVAL '14 years')
);
COMMENT ON TABLE gobernanza.afiliado IS 'Subclase AFILIADO con atributos sociodemográficos y laborales específicos.';

CREATE TABLE IF NOT EXISTS gobernanza.inspector (
    id_inspector BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    primer_nombre VARCHAR(50) NOT NULL,
    segundo_nombre VARCHAR(50),
    primer_apellido VARCHAR(50) NOT NULL,
    segundo_apellido VARCHAR(50),
    genero VARCHAR(20) CHECK (genero IN ('FEMENINO', 'MASCULINO', 'HOMOSEXUAL', 'BISEXUAL', 'TRAVESTI', 'LESBIANA', 'NO BINARIO', 'OTRO')),
    nombre_territorial VARCHAR(100) NOT NULL,
    departamento VARCHAR(50) NOT NULL,
    municipio VARCHAR(50),
    telefono VARCHAR(20),
    correo_electronico VARCHAR(100),
    fecha_registro TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ----------------------------------------------------------------------------
-- 3. GOBERNANZA - EMPRESA, SEDES Y JERARQUÍA DE JEFES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.empresa (
    id_empresa BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nit VARCHAR(20) NOT NULL UNIQUE,
    nombre_empresa VARCHAR(150) NOT NULL,
    sigla VARCHAR(30),
    pais VARCHAR(50) DEFAULT 'COLOMBIA',
    departamento VARCHAR(50) NOT NULL,
    municipio VARCHAR(50) NOT NULL,
    direccion VARCHAR(150) NOT NULL,
    sistema_carrera VARCHAR(20) DEFAULT 'GENERAL' CHECK (sistema_carrera IN ('GENERAL', 'ESPECIAL', 'ESPECÍFICO')),
    rango_empleados VARCHAR(30) NOT NULL CHECK (rango_empleados IN ('ENTRE 1 Y 50', 'ENTRE 51 Y 100', 'ENTRE 100 Y 200', 'ENTRE 201 Y 500', 'MÁS DE 500')),
    telefono_1 VARCHAR(20) NOT NULL,
    telefono_2 VARCHAR(20),
    correo_general VARCHAR(100) NOT NULL,
    correo_notificaciones_judiciales VARCHAR(100) NOT NULL,
    pagina_web VARCHAR(150),
    enlace_pqrsd VARCHAR(200),
    correo_talento_humano VARCHAR(100),
    telefono_talento_humano VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS gobernanza.sede_empresa (
    id_sede BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_empresa BIGINT NOT NULL REFERENCES gobernanza.empresa(id_empresa) ON DELETE CASCADE,
    nombre_sede VARCHAR(100) NOT NULL,
    id_encargado_persona BIGINT REFERENCES gobernanza.persona(id_persona) ON DELETE SET NULL,
    pais_sede VARCHAR(50) DEFAULT 'COLOMBIA',
    departamento_sede VARCHAR(50) NOT NULL,
    municipio_sede VARCHAR(50) NOT NULL,
    correo_sede VARCHAR(100),
    telefono_sede VARCHAR(20),
    pagina_web_sede VARCHAR(150)
);

CREATE TABLE IF NOT EXISTS gobernanza.jefe_empresa (
    id_jefe BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE CASCADE,
    id_empresa BIGINT NOT NULL REFERENCES gobernanza.empresa(id_empresa) ON DELETE CASCADE,
    cargo_nivel VARCHAR(10) NOT NULL CHECK (cargo_nivel IN ('NIVEL 1', 'NIVEL 2', 'NIVEL 3', 'NIVEL 4', 'NIVEL 5', 'NIVEL 6')),
    id_jefe_directo BIGINT REFERENCES gobernanza.jefe_empresa(id_jefe) ON DELETE SET NULL,
    CONSTRAINT chk_no_autojefe CHECK (id_jefe <> id_jefe_directo),
    CONSTRAINT uk_persona_empresa_jefe UNIQUE (id_persona, id_empresa)
);

ALTER TABLE gobernanza.empresa
    ADD COLUMN IF NOT EXISTS id_jefe_talento_humano BIGINT REFERENCES gobernanza.jefe_empresa(id_jefe) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS id_representante_legal BIGINT REFERENCES gobernanza.jefe_empresa(id_jefe) ON DELETE SET NULL;

CREATE TABLE IF NOT EXISTS gobernanza.afiliado_empresa (
    id_persona BIGINT NOT NULL REFERENCES gobernanza.afiliado(id_persona) ON DELETE CASCADE,
    id_empresa BIGINT NOT NULL REFERENCES gobernanza.empresa(id_empresa) ON DELETE RESTRICT,
    id_jefe_directo BIGINT REFERENCES gobernanza.jefe_empresa(id_jefe) ON DELETE SET NULL,
    salario_base NUMERIC(12,2) NOT NULL CHECK (salario_base > 0),
    fecha_ingreso_empresa DATE NOT NULL,
    PRIMARY KEY (id_persona, id_empresa)
);

-- ----------------------------------------------------------------------------
-- 4. GOBERNANZA - ESTAMENTOS SINDICALES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.estamento (
    id_estamento BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre_estamento VARCHAR(150) NOT NULL,
    tipo_estamento VARCHAR(30) NOT NULL CHECK (tipo_estamento IN ('JUNTA DIRECTIVA NACIONAL', 'SUBDIRECTIVA', 'COMITÉ SECCIONAL', 'ENTE DISPERSO')),
    departamento VARCHAR(50) NOT NULL,
    municipio VARCHAR(50)
);

-- ----------------------------------------------------------------------------
-- 5. GESTIÓN DOCUMENTAL - CATÁLOGO, EXPEDIENTES Y DOCUMENTOS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gestion_documental.tipo_documento (
    id_tipo_documento BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre_tipo VARCHAR(100) NOT NULL UNIQUE,
    sigla_tipo VARCHAR(10) NOT NULL UNIQUE,
    categoria_flujo VARCHAR(10) NOT NULL CHECK (categoria_flujo IN ('EMITIDO', 'RECIBIDO')),
    requiere_respuesta BOOLEAN NOT NULL DEFAULT FALSE,
    dias_termino_legal INT DEFAULT 0,
    descripcion TEXT
);
COMMENT ON TABLE gestion_documental.tipo_documento IS 'Catálogo normalizado de tipos de documentos emitidos y recibidos por el sindicato.';

CREATE OR REPLACE FUNCTION gestion_documental.fn_proteger_tipo_documento_usado()
RETURNS TRIGGER AS $$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        IF EXISTS (SELECT 1 FROM gestion_documental.documento WHERE id_tipo_documento = OLD.id_tipo_documento) THEN
            RAISE EXCEPTION 'CONTROL DE ESTANDARIZACIÓN Y AUDITORÍA: No se puede eliminar el tipo documental "%" (%) porque ya existen documentos radicados históricamente con esta categoría.', OLD.nombre_tipo, OLD.sigla_tipo;
        END IF;
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        IF (OLD.sigla_tipo <> NEW.sigla_tipo OR OLD.categoria_flujo <> NEW.categoria_flujo) THEN
            IF EXISTS (SELECT 1 FROM gestion_documental.documento WHERE id_tipo_documento = OLD.id_tipo_documento) THEN
                RAISE EXCEPTION 'CONTROL DE ESTANDARIZACIÓN Y AUDITORÍA: No se puede modificar la sigla "%" ni el flujo "%" del tipo documental porque rompería la integridad de los radicados históricos.', OLD.sigla_tipo, OLD.categoria_flujo;
            END IF;
        END IF;
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

INSERT INTO gestion_documental.tipo_documento (nombre_tipo, sigla_tipo, categoria_flujo, requiere_respuesta, dias_termino_legal, descripcion)
VALUES
    ('ACTA DE REUNIÓN CON DECISIONES', 'ACT', 'EMITIDO', FALSE, 0, 'Actas de asambleas, juntas y comités con decisiones formalizadas.'),
    ('COMUNICADO OFICIAL', 'COM', 'EMITIDO', FALSE, 0, 'Comunicaciones públicas dirigidas a la afiliación o la opinión pública.'),
    ('PUBLICACIÓN EN REDES SOCIALES', 'RED', 'EMITIDO', FALSE, 0, 'Contenido institucional divulgado en medios y redes digitales.'),
    ('CARTA O OFICIO', 'CAR', 'EMITIDO', TRUE, 15, 'Comunicaciones escritas enviadas a empresas, entidades o personas.'),
    ('SOLICITUD DE PERMISO SINDICAL', 'PER', 'EMITIDO', TRUE, 10, 'Solicitudes formales de permisos sindicales para directivos o delegados.'),
    ('DERECHO DE PETICIÓN (PQRSD)', 'PET', 'EMITIDO', TRUE, 15, 'Peticiones, quejas, reclamos, sugerencias o felicitaciones.'),
    ('INFORME DE GESTIÓN Y RESULTADOS POR CARGO', 'INF', 'EMITIDO', FALSE, 0, 'Informes obligatorios periódicos de gestión emitidos por cada directivo.'),
    ('PLAN DE ACCIÓN', 'PLA', 'EMITIDO', FALSE, 0, 'Planes de acción, cronogramas de trabajo y metas estratégicas emitidas por estamentos o directivos.'),
    ('PLIEGO DE PETICIONES DE NEGOCIACIÓN', 'PLI', 'EMITIDO', TRUE, 20, 'Pliegos de peticiones presentados formalmente ante empresas o entidades para negociación colectiva.'),
    ('CORREO ELECTRÓNICO CON RESPUESTA', 'COR', 'RECIBIDO', FALSE, 0, 'Respuestas electrónicas recibidas de empresas u organismos.'),
    ('DOCUMENTO EXTERNO (COTIZACIÓN/FACTURA)', 'EMP', 'RECIBIDO', FALSE, 0, 'Facturas, cotizaciones y propuestas de proveedores o terceros.'),
    ('CONSTANCIA DE REGISTRO MINTRABAJO', 'REG', 'RECIBIDO', FALSE, 0, 'Resoluciones y constancias de depósito del Ministerio de Trabajo.')
ON CONFLICT (sigla_tipo) DO UPDATE SET nombre_tipo = EXCLUDED.nombre_tipo, descripcion = EXCLUDED.descripcion;

-- El trigger de protección se crea después de la carga inicial del catálogo.
DROP TRIGGER IF EXISTS trg_proteger_tipo_documento_usado ON gestion_documental.tipo_documento;
CREATE TRIGGER trg_proteger_tipo_documento_usado
    BEFORE UPDATE OR DELETE ON gestion_documental.tipo_documento
    FOR EACH ROW EXECUTE FUNCTION gestion_documental.fn_proteger_tipo_documento_usado();

-- 5B. EXPEDIENTES (TRD)
CREATE TABLE IF NOT EXISTS gestion_documental.expediente (
    id_expediente BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    codigo_expediente VARCHAR(50) UNIQUE,
    titulo_expediente VARCHAR(200) NOT NULL,
    serie_documental VARCHAR(50) NOT NULL CHECK (serie_documental IN ('NEGOCIACIÓN COLECTIVA', 'CONFLICTO LABORAL / QUERELLA', 'PROCESO DISCIPLINARIO', 'FUERO SINDICAL', 'SALUD OCUPACIONAL / SST', 'ASUNTO FINANCIERO', 'OTRO')),
    id_estamento_custodio BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    id_persona_responsable BIGINT REFERENCES gobernanza.persona(id_persona) ON DELETE SET NULL,
    estado_expediente VARCHAR(20) NOT NULL DEFAULT 'ABIERTO' CHECK (estado_expediente IN ('ABIERTO', 'EN_TRAMITE', 'SUSPENDIDO', 'CERRADO', 'ARCHIVADO')),
    fecha_apertura DATE NOT NULL DEFAULT CURRENT_DATE,
    fecha_cierre DATE,
    descripcion_resumen TEXT,
    fecha_creacion TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    usuario_creacion VARCHAR(50) DEFAULT auditoria.fn_usuario_actual() NOT NULL,
    CONSTRAINT chk_fechas_expediente CHECK (fecha_cierre IS NULL OR fecha_cierre >= fecha_apertura)
);
COMMENT ON TABLE gestion_documental.expediente IS 'Carpeta o expediente virtual que agrupa documentos y trámites bajo una serie documental.';

-- Código EXP-[ESTAMENTO]-[SERIE]-[AÑO]-[SECUENCIAL], serializado con bloqueo transaccional.
CREATE OR REPLACE FUNCTION gestion_documental.fn_generar_codigo_expediente()
RETURNS TRIGGER AS $$
DECLARE
    v_codigo_estamento VARCHAR(20);
    v_serie_trigramo VARCHAR(5);
    v_anio VARCHAR(4);
    v_prefijo VARCHAR(50);
    v_secuencial INT;
BEGIN
    IF NEW.codigo_expediente IS NULL THEN
        SELECT CASE
                 WHEN tipo_estamento = 'JUNTA DIRECTIVA NACIONAL' THEN 'JDN'
                 WHEN tipo_estamento = 'SUBDIRECTIVA' THEN 'SUB_' || UPPER(COALESCE(SUBSTRING(municipio FROM 1 FOR 3), 'GEN'))
                 WHEN tipo_estamento = 'COMITÉ SECCIONAL' THEN 'CSE_' || UPPER(COALESCE(SUBSTRING(municipio FROM 1 FOR 3), 'GEN'))
                 ELSE 'EST'
               END
          INTO v_codigo_estamento
          FROM gobernanza.estamento
         WHERE id_estamento = NEW.id_estamento_custodio;

        v_serie_trigramo := CASE NEW.serie_documental
            WHEN 'NEGOCIACIÓN COLECTIVA' THEN 'NEG'
            WHEN 'CONFLICTO LABORAL / QUERELLA' THEN 'QUE'
            WHEN 'PROCESO DISCIPLINARIO' THEN 'DIS'
            WHEN 'FUERO SINDICAL' THEN 'FUE'
            WHEN 'SALUD OCUPACIONAL / SST' THEN 'SST'
            WHEN 'ASUNTO FINANCIERO' THEN 'FIN'
            ELSE 'GEN'
        END;
        v_anio := TO_CHAR(COALESCE(NEW.fecha_apertura, CURRENT_DATE), 'YYYY');
        v_prefijo := 'EXP-' || v_codigo_estamento || '-' || v_serie_trigramo || '-' || v_anio || '-';

        -- CONTROL DE CONCURRENCIA: una sola transacción a la vez por prefijo.
        PERFORM pg_advisory_xact_lock(hashtext(v_prefijo));

        SELECT COALESCE(MAX(SUBSTRING(codigo_expediente FROM '(\d+)$')::INT), 0) + 1
          INTO v_secuencial
          FROM gestion_documental.expediente
         WHERE codigo_expediente LIKE v_prefijo || '%';

        NEW.codigo_expediente := v_prefijo || LPAD(v_secuencial::TEXT, 4, '0');
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_generar_codigo_expediente ON gestion_documental.expediente;
CREATE TRIGGER trg_generar_codigo_expediente
    BEFORE INSERT ON gestion_documental.expediente
    FOR EACH ROW EXECUTE FUNCTION gestion_documental.fn_generar_codigo_expediente();

CREATE TABLE IF NOT EXISTS gestion_documental.documento (
    id_documento BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_expediente BIGINT REFERENCES gestion_documental.expediente(id_expediente) ON DELETE SET NULL,
    numero_folio INT CHECK (numero_folio >= 1),
    radicado_alfanumerico VARCHAR(50) UNIQUE,
    flujo VARCHAR(10) NOT NULL CHECK (flujo IN ('EMITIDO', 'RECIBIDO')),
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    id_tipo_documento BIGINT NOT NULL REFERENCES gestion_documental.tipo_documento(id_tipo_documento) ON DELETE RESTRICT,
    asunto VARCHAR(250) NOT NULL,
    descripcion_resumen TEXT,
    fecha_radicacion TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    id_persona_remitente BIGINT REFERENCES gobernanza.persona(id_persona) ON DELETE SET NULL,
    remitente_externo_persona VARCHAR(150),
    remitente_externo_institucion VARCHAR(150),
    destinatario_persona VARCHAR(150),
    destinatario_institucion VARCHAR(150),
    nombre_archivo_adjunto VARCHAR(200),
    hash_sha256 VARCHAR(64),
    estado_tramite VARCHAR(30) DEFAULT 'RADICADO' CHECK (estado_tramite IN ('RADICADO', 'EN_TRAMITE', 'RESPONDIDO', 'ARCHIVADO', 'ANULADO')),
    id_documento_padre BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE SET NULL,
    fecha_creacion TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    usuario_creacion VARCHAR(50) DEFAULT auditoria.fn_usuario_actual() NOT NULL
);
COMMENT ON TABLE gestion_documental.documento IS 'Tabla central de documentos emitidos y recibidos con radicado alfanumérico inmutable.';

CREATE TABLE IF NOT EXISTS gestion_documental.historial_tramite (
    id_historial BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_documento BIGINT NOT NULL REFERENCES gestion_documental.documento(id_documento) ON DELETE CASCADE,
    fecha_movimiento TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    estado_anterior VARCHAR(30),
    estado_nuevo VARCHAR(30) NOT NULL,
    observaciones TEXT,
    usuario_responsable VARCHAR(50) DEFAULT auditoria.fn_usuario_actual() NOT NULL
);

-- ----------------------------------------------------------------------------
-- 6. REGISTRO INSPECTOR DE TRABAJO, DIRECTIVOS Y COMITÉS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.registro_inspector_estamento (
    id_registro BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE CASCADE,
    id_inspector BIGINT NOT NULL REFERENCES gobernanza.inspector(id_inspector) ON DELETE RESTRICT,
    num_registro_inspector VARCHAR(50) NOT NULL,
    fecha_emision_registro TIMESTAMP WITH TIME ZONE NOT NULL,
    id_documento_radicado BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE SET NULL,
    CONSTRAINT uk_estamento_registro UNIQUE (id_estamento, num_registro_inspector)
);

CREATE TABLE IF NOT EXISTS gobernanza.directivo_estamento (
    id_directivo_estamento BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.afiliado(id_persona) ON DELETE CASCADE,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE CASCADE,
    id_registro_inspector BIGINT NOT NULL REFERENCES gobernanza.registro_inspector_estamento(id_registro) ON DELETE RESTRICT,
    rol_estamento VARCHAR(50) NOT NULL,
    fecha_posesion_individual DATE NOT NULL,
    fecha_fin_vigencia_programada DATE GENERATED ALWAYS AS ((fecha_posesion_individual + INTERVAL '2 years')::DATE) STORED
);

CREATE OR REPLACE VIEW gobernanza.v_auditoria_vigencia_directivos AS
SELECT
    d.id_directivo_estamento,
    p.dni,
    p.primer_nombre || ' ' || p.primer_apellido AS nombre_directivo,
    e.nombre_estamento,
    d.rol_estamento,
    r.num_registro_inspector,
    d.fecha_posesion_individual,
    d.fecha_fin_vigencia_programada,
    AGE(CURRENT_DATE, d.fecha_posesion_individual) AS tiempo_transcurrido,
    CASE WHEN CURRENT_DATE <= d.fecha_fin_vigencia_programada THEN AGE(d.fecha_fin_vigencia_programada, CURRENT_DATE) END AS tiempo_restante,
    CASE WHEN CURRENT_DATE > d.fecha_fin_vigencia_programada THEN AGE(CURRENT_DATE, d.fecha_fin_vigencia_programada) END AS tiempo_exceso,
    CASE
        WHEN CURRENT_DATE > d.fecha_fin_vigencia_programada THEN 'ALERTA CRÍTICA: PERÍODO EXCEDIDO'
        WHEN d.fecha_fin_vigencia_programada - CURRENT_DATE <= 30 THEN 'ALERTA ALTA: FALTA 1 MES O MENOS'
        WHEN d.fecha_fin_vigencia_programada - CURRENT_DATE <= 60 THEN 'ALERTA MEDIA: FALTAN 2 MESES'
        WHEN d.fecha_fin_vigencia_programada - CURRENT_DATE <= 90 THEN 'ALERTA BAJA: FALTAN 3 MESES'
        ELSE 'PERÍODO VIGENTE Y NORMAL'
    END AS estado_alerta
FROM gobernanza.directivo_estamento d
JOIN gobernanza.persona p ON d.id_persona = p.id_persona
JOIN gobernanza.estamento e ON d.id_estamento = e.id_estamento
JOIN gobernanza.registro_inspector_estamento r ON d.id_registro_inspector = r.id_registro;

CREATE TABLE IF NOT EXISTS gobernanza.comite (
    id_comite BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_empresa BIGINT NOT NULL REFERENCES gobernanza.empresa(id_empresa) ON DELETE CASCADE,
    tipo_comite VARCHAR(30) NOT NULL CHECK (tipo_comite IN ('PERSONAL', 'CONVIVENCIA', 'COPASST', 'BIENESTAR', 'OTRO')),
    fecha_inicio_periodo DATE NOT NULL,
    fecha_fin_periodo DATE GENERATED ALWAYS AS ((fecha_inicio_periodo + INTERVAL '2 years')::DATE) STORED
);

CREATE TABLE IF NOT EXISTS gobernanza.comite_miembro (
    id_comite BIGINT NOT NULL REFERENCES gobernanza.comite(id_comite) ON DELETE CASCADE,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE CASCADE,
    rol_comite VARCHAR(50) DEFAULT 'INTEGRANTE',
    PRIMARY KEY (id_comite, id_persona)
);

-- ----------------------------------------------------------------------------
-- 7. FINANZAS - RECAUDO Y APORTES DEL 0.7%
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS finanzas.cuenta_bancaria (
    id_cuenta BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_estamento BIGINT REFERENCES gobernanza.estamento(id_estamento) ON DELETE SET NULL,
    es_cuenta_nacional BOOLEAN NOT NULL DEFAULT FALSE,
    banco VARCHAR(100) NOT NULL,
    numero_cuenta VARCHAR(30) NOT NULL UNIQUE,
    tipo_cuenta VARCHAR(20) CHECK (tipo_cuenta IN ('AHORROS', 'CORRIENTE'))
);

CREATE TABLE IF NOT EXISTS finanzas.consignacion_empresa (
    id_consignacion BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_empresa BIGINT NOT NULL REFERENCES gobernanza.empresa(id_empresa) ON DELETE RESTRICT,
    id_cuenta_destino BIGINT NOT NULL REFERENCES finanzas.cuenta_bancaria(id_cuenta) ON DELETE RESTRICT,
    periodo_mes INT NOT NULL CHECK (periodo_mes BETWEEN 1 AND 12),
    periodo_anio INT NOT NULL CHECK (periodo_anio >= 2000),
    monto_total_consignado NUMERIC(15,2) NOT NULL CHECK (monto_total_consignado >= 0),
    fecha_consignacion DATE NOT NULL,
    reporte_discriminado_adjunto BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT uk_empresa_periodo UNIQUE (id_empresa, periodo_mes, periodo_anio)
);

CREATE TABLE IF NOT EXISTS finanzas.aporte_afiliado (
    id_aporte BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_consignacion BIGINT REFERENCES finanzas.consignacion_empresa(id_consignacion) ON DELETE CASCADE,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.afiliado(id_persona) ON DELETE RESTRICT,
    periodo_mes INT NOT NULL CHECK (periodo_mes BETWEEN 1 AND 12),
    periodo_anio INT NOT NULL CHECK (periodo_anio >= 2000),
    monto_descuento_ley NUMERIC(12,2) NOT NULL CHECK (monto_descuento_ley >= 0),
    estado_conciliacion VARCHAR(30) DEFAULT 'PENDIENTE' CHECK (estado_conciliacion IN ('CONCILIADO', 'PENDIENTE', 'DISCREPANCIA'))
);

CREATE OR REPLACE VIEW finanzas.v_auditoria_armonizacion_aportes AS
SELECT
    c.id_consignacion,
    e.nombre_empresa,
    c.periodo_mes,
    c.periodo_anio,
    c.monto_total_consignado,
    COALESCE(SUM(a.monto_descuento_ley), 0) AS suma_aportes_individuales,
    (c.monto_total_consignado - COALESCE(SUM(a.monto_descuento_ley), 0)) AS diferencia_conciliacion,
    CASE
        WHEN c.monto_total_consignado = COALESCE(SUM(a.monto_descuento_ley), 0) THEN 'ARMONIZADO / EXACTO'
        WHEN COALESCE(SUM(a.monto_descuento_ley), 0) = 0 THEN 'PENDIENTE DISCRIMINACIÓN (REPORTE CONSOLIDADO SIN DETALLE)'
        ELSE 'DISCREPANCIA FINANCIERA REQUIERE AUDITORÍA'
    END AS diagnostico_auditoria
FROM finanzas.consignacion_empresa c
JOIN gobernanza.empresa e ON c.id_empresa = e.id_empresa
LEFT JOIN finanzas.aporte_afiliado a ON c.id_consignacion = a.id_consignacion
GROUP BY c.id_consignacion, e.nombre_empresa, c.periodo_mes, c.periodo_anio, c.monto_total_consignado;

-- ----------------------------------------------------------------------------
-- 8. COMPROMISOS, TAREAS Y DELEGACIÓN INTERSECCIONAL
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gestion_documental.compromiso_tarea (
    id_compromiso BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_documento_origen BIGINT NOT NULL REFERENCES gestion_documental.documento(id_documento) ON DELETE CASCADE,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    titulo_compromiso VARCHAR(200) NOT NULL,
    descripcion_accion TEXT NOT NULL,
    prioridad VARCHAR(20) NOT NULL DEFAULT 'MEDIA' CHECK (prioridad IN ('BAJA', 'MEDIA', 'ALTA', 'CRÍTICA')),
    id_persona_responsable BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    id_persona_supervisor BIGINT REFERENCES gobernanza.persona(id_persona) ON DELETE SET NULL,
    motivo_delegacion_interseccional TEXT,
    fecha_asignacion DATE NOT NULL DEFAULT CURRENT_DATE,
    fecha_limite_cumplimiento DATE NOT NULL,
    fecha_cumplimiento_real DATE,
    porcentaje_avance INT NOT NULL DEFAULT 0 CHECK (porcentaje_avance BETWEEN 0 AND 100),
    estado_compromiso VARCHAR(30) NOT NULL DEFAULT 'PENDIENTE'
        CHECK (estado_compromiso IN ('PENDIENTE', 'EN_PROCESO', 'CUMPLIDO', 'CUMPLIDO_EXTEMPORANEO', 'INCUMPLIDO', 'CANCELADO')),
    id_documento_evidencia BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE SET NULL,
    fecha_creacion TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    usuario_creacion VARCHAR(50) DEFAULT auditoria.fn_usuario_actual() NOT NULL,
    CONSTRAINT chk_fechas_compromiso CHECK (fecha_limite_cumplimiento >= fecha_asignacion)
);

CREATE TABLE IF NOT EXISTS gestion_documental.historial_avance_compromiso (
    id_avance BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_compromiso BIGINT NOT NULL REFERENCES gestion_documental.compromiso_tarea(id_compromiso) ON DELETE CASCADE,
    fecha_registro TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    porcentaje_avance_registrado INT NOT NULL CHECK (porcentaje_avance_registrado BETWEEN 0 AND 100),
    descripcion_avance TEXT NOT NULL,
    usuario_registra VARCHAR(50) DEFAULT auditoria.fn_usuario_actual() NOT NULL,
    id_documento_soporte BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE SET NULL
);

CREATE OR REPLACE VIEW gestion_documental.v_auditoria_compromisos_tareas AS
SELECT
    c.id_compromiso,
    doc_orig.radicado_alfanumerico AS radicado_origen,
    doc_orig.asunto AS asunto_origen,
    e.nombre_estamento,
    e.tipo_estamento AS ambito_territorial,
    c.titulo_compromiso,
    c.prioridad,
    p_resp.tipo_dni || ' ' || p_resp.dni AS dni_responsable,
    p_resp.primer_nombre || ' ' || p_resp.primer_apellido AS persona_responsable,
    p_resp.correo_electronico AS correo_responsable,
    COALESCE(p_sup.primer_nombre || ' ' || p_sup.primer_apellido, 'SIN SUPERVISOR') AS supervisor_cargo,
    COALESCE(c.motivo_delegacion_interseccional, 'ASIGNACIÓN DIRECTA LOCAL') AS motivo_delegacion,
    c.fecha_asignacion,
    c.fecha_limite_cumplimiento,
    c.fecha_cumplimiento_real,
    c.porcentaje_avance,
    c.estado_compromiso,
    CURRENT_DATE - c.fecha_asignacion AS dias_transcurridos,
    CASE
        WHEN c.estado_compromiso IN ('CUMPLIDO', 'CUMPLIDO_EXTEMPORANEO') THEN 0
        WHEN CURRENT_DATE <= c.fecha_limite_cumplimiento THEN c.fecha_limite_cumplimiento - CURRENT_DATE
        ELSE 0
    END AS dias_restantes,
    CASE
        WHEN c.estado_compromiso NOT IN ('CUMPLIDO', 'CUMPLIDO_EXTEMPORANEO', 'CANCELADO')
             AND CURRENT_DATE > c.fecha_limite_cumplimiento THEN CURRENT_DATE - c.fecha_limite_cumplimiento
        ELSE 0
    END AS dias_mora,
    CASE
        WHEN c.estado_compromiso IN ('CUMPLIDO', 'CUMPLIDO_EXTEMPORANEO') THEN 'COMPROMISO FINALIZADO / CUMPLIDO'
        WHEN c.estado_compromiso = 'CANCELADO' THEN 'CANCELADO / SIN EFECTO'
        WHEN CURRENT_DATE > c.fecha_limite_cumplimiento THEN 'ALERTA CRÍTICA: COMPROMISO VENCIDO INCUMPLIDO'
        WHEN c.fecha_limite_cumplimiento - CURRENT_DATE <= 5 AND c.porcentaje_avance < 50 THEN 'ALERTA ALTA: PRÓXIMO A VENCER CON AVANCE BAJO (<50%)'
        WHEN c.fecha_limite_cumplimiento - CURRENT_DATE <= 10 THEN 'ALERTA MEDIA: VENCE EN MENOS DE 10 DÍAS'
        ELSE 'EN TRÁMITE DENTRO DEL TIEMPO PROGRAMADO'
    END AS diagnostico_auditoria,
    doc_evid.radicado_alfanumerico AS radicado_evidencia
FROM gestion_documental.compromiso_tarea c
JOIN gestion_documental.documento doc_orig ON c.id_documento_origen = doc_orig.id_documento
JOIN gobernanza.estamento e ON c.id_estamento = e.id_estamento
JOIN gobernanza.persona p_resp ON c.id_persona_responsable = p_resp.id_persona
LEFT JOIN gobernanza.persona p_sup ON c.id_persona_supervisor = p_sup.id_persona
LEFT JOIN gestion_documental.documento doc_evid ON c.id_documento_evidencia = doc_evid.id_documento;

-- ----------------------------------------------------------------------------
-- 9. VISTAS Y FUNCIONES DE INACTIVIDAD Y RENDICIÓN DE CUENTAS
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW gestion_documental.v_auditoria_inactividad_documental AS
WITH matriz_estamento_documento AS (
    SELECT e.id_estamento, e.nombre_estamento, e.tipo_estamento,
           t.id_tipo_documento, t.nombre_tipo, t.sigla_tipo
    FROM gobernanza.estamento e
    CROSS JOIN gestion_documental.tipo_documento t
    WHERE t.categoria_flujo = 'EMITIDO'
), ultimas_emisiones AS (
    SELECT id_estamento, id_tipo_documento, MAX(fecha_radicacion) AS ultima_fecha
    FROM gestion_documental.documento
    WHERE flujo = 'EMITIDO' AND estado_tramite <> 'ANULADO'
    GROUP BY id_estamento, id_tipo_documento
)
SELECT
    m.id_estamento,
    m.nombre_estamento,
    m.tipo_estamento AS ambito_territorial,
    m.nombre_tipo AS tipo_documento,
    m.sigla_tipo,
    u.ultima_fecha AS fecha_ultima_emision,
    CASE WHEN u.ultima_fecha IS NOT NULL THEN
        EXTRACT(MONTH FROM AGE(CURRENT_TIMESTAMP, u.ultima_fecha))::INT + (EXTRACT(YEAR FROM AGE(CURRENT_TIMESTAMP, u.ultima_fecha))::INT * 12)
    END AS meses_inactividad,
    CASE WHEN u.ultima_fecha IS NOT NULL THEN EXTRACT(DAY FROM (CURRENT_TIMESTAMP - u.ultima_fecha))::INT END AS dias_inactividad,
    CASE WHEN u.ultima_fecha IS NOT NULL THEN EXTRACT(HOUR FROM (CURRENT_TIMESTAMP - u.ultima_fecha))::INT END AS horas_inactividad,
    CASE WHEN u.ultima_fecha IS NOT NULL THEN
        (EXTRACT(MONTH FROM AGE(CURRENT_TIMESTAMP, u.ultima_fecha))::INT + (EXTRACT(YEAR FROM AGE(CURRENT_TIMESTAMP, u.ultima_fecha))::INT * 12))::TEXT || ' meses, ' ||
        EXTRACT(DAY FROM (CURRENT_TIMESTAMP - u.ultima_fecha))::INT::TEXT || ' días y ' ||
        EXTRACT(HOUR FROM (CURRENT_TIMESTAMP - u.ultima_fecha))::INT::TEXT || ' horas'
    ELSE 'SIN REGISTRO HISTÓRICO DE EMISIÓN'
    END AS tiempo_inactividad_formateado,
    CASE
        WHEN u.ultima_fecha IS NULL THEN 'ALERTA CRÍTICA: NUNCA HA EMITIDO ESTE TIPO DE DOCUMENTO'
        WHEN CURRENT_TIMESTAMP - u.ultima_fecha > INTERVAL '60 days' THEN 'ALERTA CRÍTICA: INACTIVIDAD GRAVE (>60 DÍAS SIN EMISIÓN)'
        WHEN CURRENT_TIMESTAMP - u.ultima_fecha > INTERVAL '30 days' THEN 'ALERTA ALTA: OMISIÓN DOCUMENTAL (>30 DÍAS SIN EMISIÓN)'
        WHEN CURRENT_TIMESTAMP - u.ultima_fecha > INTERVAL '15 days' AND m.sigla_tipo = 'ACT' THEN 'ALERTA MEDIA: INACTIVIDAD EN REUNIONES (15-29 DÍAS SIN ACTA)'
        ELSE 'ACTIVIDAD REGULAR Y DENTRO DEL PARÁMETRO'
    END AS diagnostico_inactividad
FROM matriz_estamento_documento m
LEFT JOIN ultimas_emisiones u ON m.id_estamento = u.id_estamento AND m.id_tipo_documento = u.id_tipo_documento;

CREATE OR REPLACE FUNCTION gestion_documental.fn_auditar_inactividad_estamento(p_nombre_estamento VARCHAR)
RETURNS TABLE (estamento VARCHAR, tipo_doc VARCHAR, ultima_emision TIMESTAMP WITH TIME ZONE, tiempo_formateado TEXT, diagnostico VARCHAR) AS $$
BEGIN
    RETURN QUERY
    SELECT v.nombre_estamento::VARCHAR, v.tipo_documento::VARCHAR, v.fecha_ultima_emision,
           v.tiempo_inactividad_formateado::TEXT, v.diagnostico_inactividad::VARCHAR
    FROM gestion_documental.v_auditoria_inactividad_documental v
    WHERE v.nombre_estamento ILIKE '%' || p_nombre_estamento || '%'
    ORDER BY v.sigla_tipo;
END;
$$ LANGUAGE plpgsql STABLE;

CREATE OR REPLACE VIEW gestion_documental.v_auditoria_informes_directivos AS
WITH ultimos_informes_directivo AS (
    SELECT d.id_persona_remitente,
           MAX(d.fecha_radicacion) AS fecha_ultimo_informe,
           COUNT(d.id_documento) AS total_informes_emitidos
    FROM gestion_documental.documento d
    JOIN gestion_documental.tipo_documento t ON d.id_tipo_documento = t.id_tipo_documento
    WHERE t.sigla_tipo = 'INF' AND d.flujo = 'EMITIDO' AND d.estado_tramite <> 'ANULADO'
    GROUP BY d.id_persona_remitente
)
SELECT
    dir.id_directivo_estamento,
    p.tipo_dni || ' ' || p.dni AS identificacion,
    p.primer_nombre || ' ' || COALESCE(p.segundo_nombre || ' ', '') || p.primer_apellido AS nombre_directivo,
    dir.rol_estamento AS cargo_directivo,
    e.nombre_estamento,
    e.tipo_estamento AS ambito_territorial,
    dir.fecha_posesion_individual,
    inf.fecha_ultimo_informe,
    COALESCE(inf.total_informes_emitidos, 0) AS total_informes_historicos,
    CASE WHEN inf.fecha_ultimo_informe IS NOT NULL THEN
        EXTRACT(MONTH FROM AGE(CURRENT_TIMESTAMP, inf.fecha_ultimo_informe))::INT + (EXTRACT(YEAR FROM AGE(CURRENT_TIMESTAMP, inf.fecha_ultimo_informe))::INT * 12)
    ELSE
        EXTRACT(MONTH FROM AGE(CURRENT_TIMESTAMP, dir.fecha_posesion_individual))::INT + (EXTRACT(YEAR FROM AGE(CURRENT_TIMESTAMP, dir.fecha_posesion_individual))::INT * 12)
    END AS meses_sin_informe,
    CASE WHEN inf.fecha_ultimo_informe IS NOT NULL THEN EXTRACT(DAY FROM (CURRENT_TIMESTAMP - inf.fecha_ultimo_informe))::INT
         ELSE (CURRENT_DATE - dir.fecha_posesion_individual)::INT
    END AS dias_sin_informe,
    CASE
        WHEN inf.fecha_ultimo_informe IS NULL THEN 'ALERTA CRÍTICA: NUNCA HA RENDIDO INFORME DE GESTIÓN'
        WHEN (CURRENT_TIMESTAMP - inf.fecha_ultimo_informe) > INTERVAL '90 days' THEN 'ALERTA CRÍTICA: MÁS DE 3 MESES SIN INFORME (>90 DÍAS)'
        WHEN (CURRENT_TIMESTAMP - inf.fecha_ultimo_informe) > INTERVAL '60 days' THEN 'ALERTA ALTA: MÁS DE 2 MESES SIN INFORME (>60 DÍAS)'
        WHEN (CURRENT_TIMESTAMP - inf.fecha_ultimo_informe) > INTERVAL '30 days' THEN 'ALERTA MEDIA: MÁS DE 1 MES SIN INFORME (>30 DÍAS)'
        ELSE 'AL DÍA CON RENDICIÓN DE CUENTAS (<30 DÍAS)'
    END AS diagnostico_auditoria_informe
FROM gobernanza.directivo_estamento dir
JOIN gobernanza.persona p ON dir.id_persona = p.id_persona
JOIN gobernanza.estamento e ON dir.id_estamento = e.id_estamento
LEFT JOIN ultimos_informes_directivo inf ON dir.id_persona = inf.id_persona_remitente;

CREATE OR REPLACE FUNCTION gestion_documental.fn_auditar_informe_cargo(p_cargo VARCHAR DEFAULT NULL, p_estamento VARCHAR DEFAULT NULL)
RETURNS TABLE (identificacion VARCHAR, nombre_directivo VARCHAR, cargo VARCHAR, estamento VARCHAR,
               fecha_ultimo_informe TIMESTAMP WITH TIME ZONE, meses_sin_informe INT, dias_sin_informe INT, diagnostico VARCHAR) AS $$
BEGIN
    RETURN QUERY
    SELECT v.identificacion::VARCHAR, v.nombre_directivo::VARCHAR, v.cargo_directivo::VARCHAR, v.nombre_estamento::VARCHAR,
           v.fecha_ultimo_informe, v.meses_sin_informe, v.dias_sin_informe, v.diagnostico_auditoria_informe::VARCHAR
    FROM gestion_documental.v_auditoria_informes_directivos v
    WHERE (p_cargo IS NULL OR v.cargo_directivo ILIKE '%' || p_cargo || '%')
      AND (p_estamento IS NULL OR v.nombre_estamento ILIKE '%' || p_estamento || '%')
    ORDER BY v.meses_sin_informe DESC, v.dias_sin_informe DESC;
END;
$$ LANGUAGE plpgsql STABLE;

CREATE OR REPLACE VIEW gestion_documental.v_auditoria_gestion_documental AS
SELECT
    d.id_documento,
    d.radicado_alfanumerico,
    d.flujo,
    e.nombre_estamento,
    e.tipo_estamento AS ambito_territorial,
    t.nombre_tipo AS tipo_documento,
    t.sigla_tipo,
    d.asunto,
    d.fecha_radicacion,
    COALESCE(p_rem.primer_nombre || ' ' || p_rem.primer_apellido, d.remitente_externo_persona, d.remitente_externo_institucion, 'SISTEMA') AS remitente,
    COALESCE(d.destinatario_persona, d.destinatario_institucion, 'GENERAL') AS destinatario,
    d.estado_tramite,
    t.requiere_respuesta,
    CASE WHEN t.requiere_respuesta THEN d.fecha_radicacion + (t.dias_termino_legal || ' days')::INTERVAL END AS fecha_limite_respuesta,
    EXTRACT(DAY FROM (CURRENT_TIMESTAMP - d.fecha_radicacion))::INT AS dias_transcurridos,
    CASE
        WHEN d.estado_tramite = 'RESPONDIDO' THEN 'TRÁMITE FINALIZADO CON RESPUESTA'
        WHEN d.estado_tramite = 'ARCHIVADO' THEN 'DOCUMENTO ARCHIVADO'
        WHEN d.estado_tramite = 'ANULADO' THEN 'DOCUMENTO ANULADO'
        WHEN t.requiere_respuesta AND CURRENT_TIMESTAMP > (d.fecha_radicacion + (t.dias_termino_legal || ' days')::INTERVAL)
            THEN 'ALERTA CRÍTICA: TRÁMITE VENCIDO SIN RESPUESTA'
        WHEN t.requiere_respuesta AND (d.fecha_radicacion + (t.dias_termino_legal || ' days')::INTERVAL - CURRENT_TIMESTAMP) <= INTERVAL '3 days'
            THEN 'ALERTA ALTA: PRÓXIMO A VENCER (<=3 DÍAS)'
        ELSE 'EN TRÁMITE DENTRO DEL TÉRMINO LEGAL'
    END AS diagnostico_auditoria
FROM gestion_documental.documento d
JOIN gobernanza.estamento e ON d.id_estamento = e.id_estamento
JOIN gestion_documental.tipo_documento t ON d.id_tipo_documento = t.id_tipo_documento
LEFT JOIN gobernanza.persona p_rem ON d.id_persona_remitente = p_rem.id_persona;

-- ----------------------------------------------------------------------------
-- 10. RADICADOS Y AUTOMATIZACIONES
-- ----------------------------------------------------------------------------
-- SGS-[EMI/REC]-[ESTAMENTO]-[TIPO]-[AAAAMM]-[SECUENCIAL], serializado por prefijo.
CREATE OR REPLACE FUNCTION gestion_documental.fn_generar_radicado_alfanumerico()
RETURNS TRIGGER AS $$
DECLARE
    v_sigla_estamento VARCHAR(10);
    v_sigla_tipo VARCHAR(10);
    v_flujo_tipo VARCHAR(10);
    v_periodo VARCHAR(6);
    v_prefijo VARCHAR(50);
    v_secuencial INT;
BEGIN
    SELECT sigla_tipo, categoria_flujo INTO v_sigla_tipo, v_flujo_tipo
      FROM gestion_documental.tipo_documento
     WHERE id_tipo_documento = NEW.id_tipo_documento;

    IF NEW.flujo IS DISTINCT FROM v_flujo_tipo THEN
        RAISE EXCEPTION 'El tipo documental % es de flujo %, pero el documento se intentó radicar como %.', v_sigla_tipo, v_flujo_tipo, NEW.flujo;
    END IF;

    SELECT CASE
             WHEN tipo_estamento = 'JUNTA DIRECTIVA NACIONAL' THEN 'JDN'
             WHEN tipo_estamento = 'SUBDIRECTIVA' THEN 'SUB_' || UPPER(SUBSTRING(COALESCE(municipio, departamento), 1, 3))
             WHEN tipo_estamento = 'COMITÉ SECCIONAL' THEN 'CSE_' || UPPER(SUBSTRING(COALESCE(municipio, departamento), 1, 3))
             ELSE 'DIS'
           END
      INTO v_sigla_estamento
      FROM gobernanza.estamento
     WHERE id_estamento = NEW.id_estamento;

    v_periodo := TO_CHAR(CURRENT_DATE, 'YYYYMM');
    v_prefijo := 'SGS-' || CASE WHEN NEW.flujo = 'EMITIDO' THEN 'EMI' ELSE 'REC' END || '-' ||
                 v_sigla_estamento || '-' || v_sigla_tipo || '-' || v_periodo || '-';

    -- CONTROL DE CONCURRENCIA: serializa las radicaciones del mismo prefijo.
    PERFORM pg_advisory_xact_lock(hashtext(v_prefijo));

    SELECT COALESCE(MAX(SUBSTRING(radicado_alfanumerico FROM '(\d+)$')::INT), 0) + 1
      INTO v_secuencial
      FROM gestion_documental.documento
     WHERE radicado_alfanumerico LIKE v_prefijo || '%';

    NEW.radicado_alfanumerico := v_prefijo || LPAD(v_secuencial::TEXT, 4, '0');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_generar_radicado ON gestion_documental.documento;
CREATE TRIGGER trg_generar_radicado
    BEFORE INSERT ON gestion_documental.documento
    FOR EACH ROW
    WHEN (NEW.radicado_alfanumerico IS NULL)
    EXECUTE FUNCTION gestion_documental.fn_generar_radicado_alfanumerico();

CREATE OR REPLACE FUNCTION gestion_documental.fn_actualizar_estado_compromiso()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.porcentaje_avance = 100 AND OLD.porcentaje_avance < 100 THEN
        NEW.fecha_cumplimiento_real := CURRENT_DATE;
        IF CURRENT_DATE <= NEW.fecha_limite_cumplimiento THEN
            NEW.estado_compromiso := 'CUMPLIDO';
        ELSE
            NEW.estado_compromiso := 'CUMPLIDO_EXTEMPORANEO';
        END IF;
    ELSIF NEW.porcentaje_avance BETWEEN 1 AND 99 AND NEW.estado_compromiso = 'PENDIENTE' THEN
        NEW.estado_compromiso := 'EN_PROCESO';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_actualizar_estado_compromiso ON gestion_documental.compromiso_tarea;
CREATE TRIGGER trg_actualizar_estado_compromiso
    BEFORE UPDATE ON gestion_documental.compromiso_tarea
    FOR EACH ROW EXECUTE FUNCTION gestion_documental.fn_actualizar_estado_compromiso();

-- ----------------------------------------------------------------------------
-- 11. VISTA Y FUNCIÓN DE EXPEDIENTES
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW gestion_documental.v_auditoria_expedientes AS
SELECT
    exp.id_expediente,
    exp.codigo_expediente,
    exp.titulo_expediente,
    exp.serie_documental,
    e.nombre_estamento AS estamento_custodio,
    e.tipo_estamento AS ambito_territorial,
    COALESCE(p.primer_nombre || ' ' || p.primer_apellido, 'SIN ASIGNAR') AS persona_responsable,
    exp.estado_expediente,
    exp.fecha_apertura,
    exp.fecha_cierre,
    COUNT(DISTINCT doc.id_documento) AS total_documentos_foliados,
    MAX(doc.numero_folio) AS ultimo_folio_registrado,
    COUNT(DISTINCT comp.id_compromiso) AS total_compromisos_asociados,
    COUNT(DISTINCT CASE WHEN comp.estado_compromiso NOT IN ('CUMPLIDO', 'CUMPLIDO_EXTEMPORANEO', 'CANCELADO') THEN comp.id_compromiso END) AS compromisos_pendientes,
    CURRENT_DATE - exp.fecha_apertura AS dias_abierto,
    CASE
        WHEN exp.estado_expediente IN ('CERRADO', 'ARCHIVADO') THEN 'EXPEDIENTE CERRADO / FINALIZADO'
        WHEN COUNT(DISTINCT doc.id_documento) = 0 THEN 'ALERTA MEDIA: EXPEDIENTE ABIERTO SIN DOCUMENTOS FOLIADOS'
        WHEN COUNT(DISTINCT CASE WHEN comp.estado_compromiso NOT IN ('CUMPLIDO', 'CUMPLIDO_EXTEMPORANEO', 'CANCELADO') THEN comp.id_compromiso END) > 0 THEN 'EN TRÁMITE CON COMPROMISOS PENDIENTES'
        ELSE 'EXPEDIENTE EN TRÁMITE REGULAR'
    END AS diagnostico_auditoria
FROM gestion_documental.expediente exp
JOIN gobernanza.estamento e ON exp.id_estamento_custodio = e.id_estamento
LEFT JOIN gobernanza.persona p ON exp.id_persona_responsable = p.id_persona
LEFT JOIN gestion_documental.documento doc ON exp.id_expediente = doc.id_expediente
LEFT JOIN gestion_documental.compromiso_tarea comp ON doc.id_documento = comp.id_documento_origen
GROUP BY exp.id_expediente, exp.codigo_expediente, exp.titulo_expediente, exp.serie_documental, e.nombre_estamento,
         e.tipo_estamento, p.primer_nombre, p.primer_apellido, exp.estado_expediente, exp.fecha_apertura, exp.fecha_cierre;

CREATE OR REPLACE FUNCTION gestion_documental.fn_auditar_expediente(p_codigo_expediente VARCHAR)
RETURNS TABLE (codigo_expediente VARCHAR, titulo_expediente VARCHAR, folio INT, radicado_documento VARCHAR,
               tipo_documento VARCHAR, asunto VARCHAR, fecha_radicacion TIMESTAMP WITH TIME ZONE) AS $$
BEGIN
    RETURN QUERY
    SELECT exp.codigo_expediente::VARCHAR, exp.titulo_expediente::VARCHAR, doc.numero_folio, doc.radicado_alfanumerico::VARCHAR,
           td.nombre_tipo::VARCHAR, doc.asunto::VARCHAR, doc.fecha_radicacion
    FROM gestion_documental.documento doc
    JOIN gestion_documental.expediente exp ON doc.id_expediente = exp.id_expediente
    JOIN gestion_documental.tipo_documento td ON doc.id_tipo_documento = td.id_tipo_documento
    WHERE exp.codigo_expediente = p_codigo_expediente
    ORDER BY doc.numero_folio ASC NULLS LAST, doc.fecha_radicacion ASC;
END;
$$ LANGUAGE plpgsql STABLE;

-- RLS (política del script original; el control de acceso fino lo hace 03_roles_permisos.sql)
ALTER TABLE gobernanza.persona ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS policy_persona_acceso_autorizado ON gobernanza.persona;
CREATE POLICY policy_persona_acceso_autorizado ON gobernanza.persona FOR ALL TO PUBLIC USING (true);

-- Nota: los triggers de auditoría se asignan a TODAS las tablas en 02_seguridad_auditoria.sql
-- ============================================================================
-- FIN DE LA ESTRUCTURA BASE
-- ============================================================================
