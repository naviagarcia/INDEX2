-- ============================================================================
-- SGSINDICAL v9.1 — 06: PROTECCIÓN DE DATOS PERSONALES (Ley 1581 de 2012)
-- Ejecutar DESPUÉS de 05. No modifica los scripts anteriores: los complementa.
-- ----------------------------------------------------------------------------
--  P1. DATOS SENSIBLES: la afiliación sindical, el salario y el campo género (que incluye
--      orientación sexual). Salario y género quedan RESERVADOS en la base de datos: la cuenta de la
--      aplicación ya no puede leer esas columnas; solo se entregan con una función que verifica quién
--      pregunta y deja registro. Los ven el administrador, la Presidencia y la Secretaría General de la
--      junta del afiliado (o de la Nacional) y, solo el salario, Tesorería.
--  P2. BITÁCORA DE ACCESOS: quién consultó qué dato de quién, cuándo, desde qué IP y por qué
--      (fichas, listados, exportaciones, datos revelados, reportes al titular). Es inmutable, se
--      conserva 5 años (parámetro) y solo la consultan el administrador y la Presidencia Nacional.
--  P3. CONSENTIMIENTO: política de tratamiento versionada y autorizaciones por persona y finalidad
--      (gestión sindical, comunicaciones, uso de imagen). Los afiliados sin autorización se pueden
--      registrar, pero quedan "pendientes" con alerta hasta que la firmen. Nada se inventa.
--  P4. DERECHOS DEL TITULAR (conocer, actualizar, rectificar, suprimir, revocar): solicitudes con
--      plazo legal en días hábiles (consultas 10, reclamos 15, prorrogables 5 y 8), calendario de
--      festivos de Colombia y reporte "¿qué datos tienen de mí?".
--  P5. ANONIMIZACIÓN (supresión): la pide el administrador y la aprueba la Presidencia Nacional.
--      Solo para personas inactivas, sin cargo ni afiliación vigentes. Se reemplazan los datos que
--      identifican a la persona (también en la bitácora de cambios); las cifras financieras quedan.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. PARÁMETROS Y QUIÉN ES QUIÉN
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS seguridad.parametro_privacidad (
    codigo VARCHAR(40) PRIMARY KEY,
    valor NUMERIC NOT NULL,
    descripcion TEXT NOT NULL,
    version INT NOT NULL DEFAULT 1
);
INSERT INTO seguridad.parametro_privacidad (codigo, valor, descripcion) VALUES
    ('RETENCION_BITACORA_ANOS', 5, 'Años que se conserva en línea la bitácora de accesos a datos personales.'),
    ('CONSULTAS_DIA_ALERTA', 50, 'Consultas individuales de datos de personas por usuario y día a partir de las cuales se alerta.'),
    ('DIAS_CONSULTA_TITULAR', 10, 'Días hábiles para responder una consulta del titular (Ley 1581, art. 14).'),
    ('DIAS_PRORROGA_CONSULTA', 5, 'Días hábiles de prórroga de una consulta.'),
    ('DIAS_RECLAMO_TITULAR', 15, 'Días hábiles para responder un reclamo del titular (Ley 1581, art. 15).'),
    ('DIAS_PRORROGA_RECLAMO', 8, 'Días hábiles de prórroga de un reclamo.'),
    ('HORA_CORTE_RADICACION', 17, 'Lo que se radica a partir de esta hora (o en día no hábil) se cuenta desde el siguiente día hábil.')
ON CONFLICT (codigo) DO NOTHING;

CREATE OR REPLACE FUNCTION seguridad.fn_parametro_privacidad(p_codigo TEXT)
RETURNS NUMERIC AS $$
    SELECT valor FROM seguridad.parametro_privacidad WHERE codigo = p_codigo;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_es_admin()
RETURNS BOOLEAN AS $$
    SELECT COALESCE((SELECT codigo_rol = 'ADMIN' FROM seguridad.usuario
                      WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo), FALSE);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ¿El usuario actual ocupa hoy alguno de estos cargos? (prefijos de código, p. ej. 'PRES\_NAL')
CREATE OR REPLACE FUNCTION seguridad.fn_tiene_cargo(p_patrones TEXT[], p_id_estamento BIGINT DEFAULT NULL)
RETURNS BOOLEAN AS $$
    SELECT EXISTS (
        SELECT 1 FROM seguridad.usuario u
          JOIN gobernanza.directivo_estamento d ON d.id_persona = u.id_persona AND d.fecha_retiro IS NULL
          JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
         WHERE u.id_usuario = seguridad.fn_id_usuario_actual() AND u.activo
           AND c.codigo LIKE ANY (p_patrones)
           AND (p_id_estamento IS NULL OR d.id_estamento = p_id_estamento));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_es_presidente_nacional()
RETURNS BOOLEAN AS $$
    SELECT seguridad.fn_tiene_cargo(ARRAY['PRES\_NAL']);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_ve_bitacora_accesos()
RETURNS BOOLEAN AS $$
    SELECT seguridad.fn_es_admin() OR seguridad.fn_es_presidente_nacional();
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 2. DATOS SENSIBLES: catálogo, quién los ve y reserva de columnas
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS seguridad.dato_sensible (
    tabla TEXT NOT NULL,
    columna TEXT NOT NULL,
    categoria VARCHAR(12) NOT NULL CHECK (categoria IN ('SALARIO', 'SENSIBLE')),
    descripcion TEXT NOT NULL,
    PRIMARY KEY (tabla, columna)
);
COMMENT ON TABLE seguridad.dato_sensible IS 'Columnas reservadas (Ley 1581): la aplicación no las lee directamente.';
INSERT INTO seguridad.dato_sensible (tabla, columna, categoria, descripcion) VALUES
    ('gobernanza.persona', 'genero', 'SENSIBLE', 'Género (incluye orientación sexual: dato sensible, art. 5).'),
    ('gobernanza.inspector', 'genero', 'SENSIBLE', 'Género del inspector (incluye orientación sexual).'),
    ('gobernanza.afiliado_empresa', 'salario_base', 'SALARIO', 'Salario vigente del afiliado (confidencial).'),
    ('gobernanza.salario_historico', 'salario', 'SALARIO', 'Historial de salarios del afiliado (confidencial).')
ON CONFLICT (tabla, columna) DO UPDATE SET categoria = EXCLUDED.categoria, descripcion = EXCLUDED.descripcion;

-- Quién puede ver un dato reservado de una persona:
--   · el administrador;
--   · Presidente o Secretario General vigente de la junta del afiliado o de la Junta Nacional;
--   · solo el SALARIO: además el Tesorero (cargo) de esa junta o de la Nacional, y los usuarios con rol
--     TESORERO cuyo ámbito territorial incluye a la persona.
CREATE OR REPLACE FUNCTION seguridad.fn_puede_ver_dato(p_categoria TEXT, p_id_persona BIGINT)
RETURNS BOOLEAN AS $$
DECLARE v_est BIGINT; v_jdn BIGINT; v_rol TEXT;
BEGIN
    IF seguridad.fn_es_admin() THEN RETURN TRUE; END IF;
    SELECT id_estamento INTO v_jdn FROM gobernanza.estamento WHERE tipo_estamento = 'JUNTA DIRECTIVA NACIONAL' LIMIT 1;
    SELECT id_estamento_pertenencia INTO v_est FROM gobernanza.afiliado WHERE id_persona = p_id_persona;
    IF seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'SGEN\_%'], v_jdn)
       OR (v_est IS NOT NULL AND seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'SGEN\_%'], v_est)) THEN
        RETURN TRUE;
    END IF;
    IF p_categoria = 'SALARIO' THEN
        IF seguridad.fn_tiene_cargo(ARRAY['TES\_%'], v_jdn)
           OR (v_est IS NOT NULL AND seguridad.fn_tiene_cargo(ARRAY['TES\_%'], v_est)) THEN
            RETURN TRUE;
        END IF;
        SELECT codigo_rol INTO v_rol FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo;
        IF v_rol = 'TESORERO' AND p_id_persona IS NOT NULL
           AND (seguridad.fn_ambito_nacional() OR v_est = ANY (seguridad.fn_ambito_estamentos())) THEN
            RETURN TRUE;
        END IF;
    END IF;
    RETURN FALSE;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Reserva de columnas: los roles que leían la tabla completa pasan a leer todas las columnas MENOS
-- las reservadas. Se puede volver a ejecutar si se agregan columnas nuevas a esas tablas.
CREATE OR REPLACE FUNCTION seguridad.fn_aplicar_reserva_columnas()
RETURNS VOID AS $$
DECLARE t RECORD; r TEXT; v_cols TEXT;
BEGIN
    FOR t IN SELECT DISTINCT tabla FROM seguridad.dato_sensible LOOP
        SELECT string_agg(quote_ident(a.attname), ', ' ORDER BY a.attnum) INTO v_cols
          FROM pg_attribute a
         WHERE a.attrelid = t.tabla::regclass AND a.attnum > 0 AND NOT a.attisdropped
           AND a.attname NOT IN (SELECT columna FROM seguridad.dato_sensible WHERE tabla = t.tabla);
        FOREACH r IN ARRAY ARRAY['sgs_app', 'sgs_lectura', 'sgs_notificador'] LOOP
            CONTINUE WHEN NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r);
            CONTINUE WHEN NOT (has_table_privilege(r, t.tabla, 'SELECT')
                               OR has_any_column_privilege(r, t.tabla, 'SELECT'));
            EXECUTE format('REVOKE SELECT ON %s FROM %I', t.tabla, r);
            EXECUTE format('GRANT SELECT (%s) ON %s TO %I', v_cols, t.tabla, r);
        END LOOP;
    END LOOP;
END;
$$ LANGUAGE plpgsql;
SELECT seguridad.fn_aplicar_reserva_columnas();

-- ----------------------------------------------------------------------------
-- 3. BITÁCORA DE ACCESOS A DATOS PERSONALES (inmutable)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS auditoria.acceso_dato (
    id_acceso_dato BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fecha_hora TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    id_usuario BIGINT,
    nombre_usuario VARCHAR(50) NOT NULL,
    ip_origen INET,
    tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('FICHA', 'LISTADO', 'VER_DATO', 'EXPORTACION', 'REPORTE_TITULAR',
                                              'ANONIMIZACION', 'PURGA')),
    recurso VARCHAR(60) NOT NULL,
    id_persona BIGINT,
    campos TEXT[],
    n_registros INT,
    motivo TEXT
);
COMMENT ON TABLE auditoria.acceso_dato IS 'Bitácora inmutable de consultas a datos personales (Ley 1581). Solo la consultan el administrador y la Presidencia Nacional.';
CREATE INDEX IF NOT EXISTS ix_acceso_dato_persona ON auditoria.acceso_dato (id_persona, fecha_hora DESC);
CREATE INDEX IF NOT EXISTS ix_acceso_dato_usuario ON auditoria.acceso_dato (id_usuario, fecha_hora DESC);
CREATE INDEX IF NOT EXISTS ix_acceso_dato_fecha ON auditoria.acceso_dato (fecha_hora);

CREATE OR REPLACE FUNCTION auditoria.fn_bloquear_acceso_dato()
RETURNS TRIGGER AS $$
BEGIN
    -- Única excepción: la purga por antigüedad (fn_purgar_bitacora_accesos) o la anonimización
    IF TG_OP = 'DELETE' AND COALESCE(current_setting('sgs.operacion', true), '') = 'purga' THEN RETURN OLD; END IF;
    IF TG_OP = 'UPDATE' AND COALESCE(current_setting('sgs.operacion', true), '') = 'anonimizar' THEN RETURN NEW; END IF;
    RAISE EXCEPTION 'POLÍTICA DE PRIVACIDAD: la bitácora de accesos es inmutable (operación % rechazada).', TG_OP;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_inmutable ON auditoria.acceso_dato;
CREATE TRIGGER trg_inmutable BEFORE UPDATE OR DELETE ON auditoria.acceso_dato
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_bloquear_acceso_dato();
DROP TRIGGER IF EXISTS trg_inmutable_truncate ON auditoria.acceso_dato;
CREATE TRIGGER trg_inmutable_truncate BEFORE TRUNCATE ON auditoria.acceso_dato
    FOR EACH STATEMENT EXECUTE FUNCTION auditoria.fn_bloquear_modificacion();

CREATE OR REPLACE FUNCTION seguridad.fn_registrar_acceso_dato(p_tipo TEXT, p_recurso TEXT, p_id_persona BIGINT,
                                                              p_campos TEXT[], p_n INT, p_motivo TEXT)
RETURNS VOID AS $$
    INSERT INTO auditoria.acceso_dato (id_usuario, nombre_usuario, ip_origen, tipo, recurso, id_persona, campos, n_registros, motivo)
    SELECT seguridad.fn_id_usuario_actual(), auditoria.fn_usuario_actual(), NULLIF(current_setting('app.ip', true), '')::INET,
           p_tipo, left(p_recurso, 60), p_id_persona, p_campos, p_n, NULLIF(left(trim(COALESCE(p_motivo, '')), 500), '');
$$ LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Consulta de la bitácora (solo administrador y Presidencia Nacional)
CREATE OR REPLACE FUNCTION seguridad.fn_bitacora_accesos(p_id_persona BIGINT DEFAULT NULL, p_usuario TEXT DEFAULT NULL,
                                                         p_desde DATE DEFAULT NULL, p_hasta DATE DEFAULT NULL, p_limite INT DEFAULT 500)
RETURNS TABLE (id_acceso_dato BIGINT, fecha_hora TIMESTAMPTZ, nombre_usuario VARCHAR, ip_origen INET, tipo VARCHAR,
               recurso VARCHAR, id_persona BIGINT, persona TEXT, campos TEXT[], n_registros INT, motivo TEXT) AS $$
BEGIN
    IF NOT seguridad.fn_ve_bitacora_accesos() THEN
        RAISE EXCEPTION 'La bitácora de accesos a datos personales solo la consultan el administrador y la Presidencia Nacional.'
            USING ERRCODE = 'insufficient_privilege';
    END IF;
    RETURN QUERY
    SELECT a.id_acceso_dato, a.fecha_hora, a.nombre_usuario, a.ip_origen, a.tipo, a.recurso, a.id_persona,
           CASE WHEN p.id_persona IS NOT NULL THEN p.primer_nombre || ' ' || p.primer_apellido || ' - ' || p.tipo_dni || ' ' || p.dni END,
           a.campos, a.n_registros, a.motivo
      FROM auditoria.acceso_dato a LEFT JOIN gobernanza.persona p ON p.id_persona = a.id_persona
     WHERE (p_id_persona IS NULL OR a.id_persona = p_id_persona)
       AND (p_usuario IS NULL OR a.nombre_usuario ILIKE '%' || p_usuario || '%')
       AND (p_desde IS NULL OR a.fecha_hora >= p_desde)
       AND (p_hasta IS NULL OR a.fecha_hora < p_hasta + 1)
     ORDER BY a.fecha_hora DESC, a.id_acceso_dato DESC
     LIMIT LEAST(GREATEST(COALESCE(p_limite, 500), 1), 5000);
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_purgar_bitacora_accesos()
RETURNS INT AS $$
DECLARE v_n INT; v_anios INT := seguridad.fn_parametro_privacidad('RETENCION_BITACORA_ANOS')::INT;
BEGIN
    IF NOT seguridad.fn_es_admin() THEN RAISE EXCEPTION 'Solo el administrador purga la bitácora de accesos.'; END IF;
    PERFORM set_config('sgs.operacion', 'purga', true);
    DELETE FROM auditoria.acceso_dato WHERE fecha_hora < now() - make_interval(years => v_anios) AND tipo <> 'PURGA';
    GET DIAGNOSTICS v_n = ROW_COUNT;
    PERFORM set_config('sgs.operacion', '', true);
    PERFORM seguridad.fn_registrar_acceso_dato('PURGA', 'bitacora_accesos', NULL, NULL, v_n,
        'Purga de registros de más de ' || v_anios || ' años (los backups anteriores los conservan).');
    RETURN v_n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Consultas inusuales: un usuario que en un día mira muchas fichas o datos de personas
CREATE OR REPLACE VIEW auditoria.v_accesos_inusuales AS
SELECT a.nombre_usuario, (a.fecha_hora AT TIME ZONE gestion_documental.fn_zona())::DATE AS dia,
       count(*) FILTER (WHERE a.tipo IN ('FICHA', 'VER_DATO')) AS consultas_individuales,
       count(DISTINCT a.id_persona) AS personas_distintas,
       count(*) FILTER (WHERE a.tipo = 'VER_DATO') AS datos_revelados,
       count(*) FILTER (WHERE a.tipo IN ('LISTADO', 'EXPORTACION')) AS listados_y_exportaciones,
       'ALERTA ALTA: CONSULTAS INUSUALES DE DATOS PERSONALES (MÁS DE '
           || seguridad.fn_parametro_privacidad('CONSULTAS_DIA_ALERTA')::INT || ' EN UN DÍA)' AS diagnostico
  FROM auditoria.acceso_dato a
 WHERE a.fecha_hora > now() - INTERVAL '30 days'
   AND (seguridad.fn_ve_bitacora_accesos() OR (SELECT rolbypassrls OR rolsuper FROM pg_roles WHERE rolname = session_user))
 GROUP BY a.nombre_usuario, (a.fecha_hora AT TIME ZONE gestion_documental.fn_zona())::DATE
HAVING count(*) FILTER (WHERE a.tipo IN ('FICHA', 'VER_DATO')) > seguridad.fn_parametro_privacidad('CONSULTAS_DIA_ALERTA');

-- ----------------------------------------------------------------------------
-- 4. ENTREGA DE DATOS RESERVADOS (con verificación y registro)
-- ----------------------------------------------------------------------------
-- p_tabla: 'persona' | 'inspector' | 'afiliado_empresa' | 'salario_historico'; p_id: llave en JSON
CREATE OR REPLACE FUNCTION seguridad.fn_revelar_dato(p_tabla TEXT, p_id JSONB, p_motivo TEXT DEFAULT NULL)
RETURNS TEXT AS $$
DECLARE v_valor TEXT; v_persona BIGINT; v_cat TEXT; v_col TEXT; v_existe BOOLEAN;
BEGIN
    IF p_tabla = 'persona' THEN
        v_cat := 'SENSIBLE'; v_col := 'genero'; v_persona := (p_id->>'id_persona')::BIGINT;
        SELECT TRUE, genero INTO v_existe, v_valor FROM gobernanza.persona WHERE id_persona = v_persona;
    ELSIF p_tabla = 'inspector' THEN
        v_cat := 'SENSIBLE'; v_col := 'genero'; v_persona := NULL;
        SELECT TRUE, genero INTO v_existe, v_valor FROM gobernanza.inspector WHERE id_inspector = (p_id->>'id_inspector')::BIGINT;
    ELSIF p_tabla = 'afiliado_empresa' THEN
        v_cat := 'SALARIO'; v_col := 'salario_base'; v_persona := (p_id->>'id_persona')::BIGINT;
        SELECT TRUE, salario_base::TEXT INTO v_existe, v_valor FROM gobernanza.afiliado_empresa
         WHERE id_persona = v_persona AND id_empresa = (p_id->>'id_empresa')::BIGINT;
    ELSIF p_tabla = 'salario_historico' THEN
        v_cat := 'SALARIO'; v_col := 'salario';
        SELECT TRUE, salario::TEXT, id_persona INTO v_existe, v_valor, v_persona FROM gobernanza.salario_historico
         WHERE id_salario = (p_id->>'id_salario')::BIGINT;
    ELSE
        RAISE EXCEPTION 'Este dato no es reservado.';
    END IF;
    IF NOT COALESCE(v_existe, FALSE) THEN RAISE EXCEPTION 'El registro no existe.'; END IF;
    -- Además del cargo, la persona debe estar dentro del ámbito territorial de quien consulta
    IF NOT seguridad.fn_puede_ver_dato(v_cat, v_persona)
       OR (v_persona IS NOT NULL AND NOT seguridad.fn_es_admin()
           AND NOT seguridad.fn_persona_visible(v_persona, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos())) THEN
        RAISE EXCEPTION 'Dato reservado (Ley 1581): su cargo no le permite verlo.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    PERFORM seguridad.fn_registrar_acceso_dato('VER_DATO', p_tabla, v_persona, ARRAY[v_col], 1, p_motivo);
    RETURN v_valor;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- La bitácora de cambios guarda copias completas de los registros: sin el permiso, los datos
-- reservados se ocultan también ahí.
CREATE OR REPLACE FUNCTION auditoria.fn_json_sin_reservados(p_datos JSONB)
RETURNS JSONB AS $$
    SELECT CASE WHEN p_datos IS NULL THEN NULL
                ELSE p_datos - ARRAY(SELECT DISTINCT columna FROM seguridad.dato_sensible)
                     || CASE WHEN p_datos ?| ARRAY(SELECT DISTINCT columna FROM seguridad.dato_sensible)
                             THEN '{"_reservado": "dato sensible oculto (Ley 1581)"}'::JSONB ELSE '{}'::JSONB END END;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE VIEW auditoria.v_bitacora_cambios AS
SELECT b.id_log, b.esquema_tabla, b.nombre_tabla, b.operacion, b.usuario_bd, b.fecha_hora,
       CASE WHEN seguridad.fn_es_admin() THEN b.datos_anteriores ELSE auditoria.fn_json_sin_reservados(b.datos_anteriores) END AS datos_anteriores,
       CASE WHEN seguridad.fn_es_admin() THEN b.datos_nuevos ELSE auditoria.fn_json_sin_reservados(b.datos_nuevos) END AS datos_nuevos,
       b.ip_origen
  FROM auditoria.bitacora_cambios b
 WHERE (SELECT seguridad.fn_ambito_nacional())   -- igual que la seguridad por filas de la tabla (02c)
    OR (SELECT rolbypassrls OR rolsuper FROM pg_roles WHERE rolname = session_user);
COMMENT ON VIEW auditoria.v_bitacora_cambios IS 'Bitácora de cambios con los datos reservados ocultos, salvo para el administrador.';

-- ----------------------------------------------------------------------------
-- 5. CALENDARIO DE DÍAS HÁBILES (festivos de Colombia, Ley 51 de 1983 "Emiliani")
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.festivo (
    fecha DATE PRIMARY KEY,
    nombre VARCHAR(80) NOT NULL,
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gobernanza.festivo IS 'Festivos de Colombia. Si un año no está cargado, el sistema los calcula; los cargados aquí mandan.';

CREATE OR REPLACE FUNCTION gobernanza.fn_pascua(p_anio INT)
RETURNS DATE AS $$
DECLARE a INT; b INT; c INT; d INT; e INT; f INT; g INT; h INT; i INT; k INT; l INT; m INT;
BEGIN
    a := p_anio % 19; b := p_anio / 100; c := p_anio % 100; d := b / 4; e := b % 4; f := (b + 8) / 25;
    g := (b - f + 1) / 3; h := (19 * a + b - d - g + 15) % 30; i := c / 4; k := c % 4;
    l := (32 + 2 * e + 2 * i - h - k) % 7; m := (a + 11 * h + 22 * l) / 451;
    RETURN make_date(p_anio, (h + l - 7 * m + 114) / 31, ((h + l - 7 * m + 114) % 31) + 1);
END;
$$ LANGUAGE plpgsql IMMUTABLE;

CREATE OR REPLACE FUNCTION gobernanza.fn_festivos_colombia(p_anio INT)
RETURNS TABLE (fecha DATE, nombre TEXT) AS $$
    WITH p AS (SELECT gobernanza.fn_pascua(p_anio) AS e),
    lunes AS (   -- festivos que se trasladan al lunes siguiente
        SELECT x.d + ((8 - EXTRACT(ISODOW FROM x.d)::INT) % 7) AS fecha, x.n AS nombre
          FROM (VALUES (make_date(p_anio, 1, 6), 'Día de los Reyes Magos'), (make_date(p_anio, 3, 19), 'Día de San José'),
                       (make_date(p_anio, 6, 29), 'San Pedro y San Pablo'), (make_date(p_anio, 8, 15), 'La Asunción de la Virgen'),
                       (make_date(p_anio, 10, 12), 'Día de la Raza'), (make_date(p_anio, 11, 1), 'Todos los Santos'),
                       (make_date(p_anio, 11, 11), 'Independencia de Cartagena')) x(d, n)
    )
    SELECT * FROM (VALUES (make_date(p_anio, 1, 1), 'Año Nuevo'), (make_date(p_anio, 5, 1), 'Día del Trabajo'),
                          (make_date(p_anio, 7, 20), 'Día de la Independencia'), (make_date(p_anio, 8, 7), 'Batalla de Boyacá'),
                          (make_date(p_anio, 12, 8), 'La Inmaculada Concepción'), (make_date(p_anio, 12, 25), 'Navidad')) f(fecha, nombre)
    UNION ALL SELECT fecha, nombre FROM lunes
    UNION ALL SELECT e - 3, 'Jueves Santo' FROM p
    UNION ALL SELECT e - 2, 'Viernes Santo' FROM p
    UNION ALL SELECT e + 43, 'Ascensión del Señor' FROM p
    UNION ALL SELECT e + 64, 'Corpus Christi' FROM p
    UNION ALL SELECT e + 71, 'Sagrado Corazón de Jesús' FROM p
    ORDER BY 1;
$$ LANGUAGE sql IMMUTABLE;

INSERT INTO gobernanza.festivo (fecha, nombre)
SELECT fecha, nombre FROM gobernanza.fn_festivos_colombia(2026)
UNION ALL SELECT fecha, nombre FROM gobernanza.fn_festivos_colombia(2027)
ON CONFLICT (fecha) DO NOTHING;

CREATE OR REPLACE FUNCTION gobernanza.fn_es_festivo(p_fecha DATE)
RETURNS BOOLEAN AS $$
    SELECT CASE WHEN EXISTS (SELECT 1 FROM gobernanza.festivo WHERE EXTRACT(YEAR FROM fecha) = EXTRACT(YEAR FROM p_fecha))
                THEN EXISTS (SELECT 1 FROM gobernanza.festivo WHERE fecha = p_fecha)
                ELSE EXISTS (SELECT 1 FROM gobernanza.fn_festivos_colombia(EXTRACT(YEAR FROM p_fecha)::INT) f WHERE f.fecha = p_fecha) END;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_es_habil(p_fecha DATE)
RETURNS BOOLEAN AS $$
    SELECT EXTRACT(ISODOW FROM p_fecha) < 6 AND NOT gobernanza.fn_es_festivo(p_fecha);
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE FUNCTION gobernanza.fn_sumar_dias_habiles(p_desde DATE, p_dias INT)
RETURNS DATE AS $$
DECLARE d DATE := p_desde; n INT := p_dias;
BEGIN
    WHILE n > 0 LOOP
        d := d + 1;
        IF gobernanza.fn_es_habil(d) THEN n := n - 1; END IF;
    END LOOP;
    RETURN d;
END;
$$ LANGUAGE plpgsql STABLE;

CREATE OR REPLACE FUNCTION gobernanza.fn_dias_habiles_entre(p_desde DATE, p_hasta DATE)
RETURNS INT AS $$
    SELECT count(*)::INT FROM generate_series(p_desde + 1, p_hasta, INTERVAL '1 day') g WHERE gobernanza.fn_es_habil(g::DATE);
$$ LANGUAGE sql STABLE;

-- Día desde el que se cuenta un término: lo radicado después de la hora de corte o en día no hábil
-- se entiende radicado el siguiente día hábil; los días se cuentan a partir del día siguiente.
CREATE OR REPLACE FUNCTION gobernanza.fn_dia_base_radicacion(p_momento TIMESTAMPTZ)
RETURNS DATE AS $$
DECLARE v_local TIMESTAMP := p_momento AT TIME ZONE gestion_documental.fn_zona(); d DATE;
BEGIN
    d := v_local::DATE;
    IF EXTRACT(HOUR FROM v_local) >= seguridad.fn_parametro_privacidad('HORA_CORTE_RADICACION') OR NOT gobernanza.fn_es_habil(d) THEN
        d := gobernanza.fn_sumar_dias_habiles(d, 1);
    END IF;
    RETURN d;
END;
$$ LANGUAGE plpgsql STABLE;

-- ----------------------------------------------------------------------------
-- 6. CONSENTIMIENTO: política de tratamiento, finalidades y autorizaciones
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.politica_tratamiento (
    id_politica BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    numero_version VARCHAR(20) NOT NULL UNIQUE,
    titulo VARCHAR(200) NOT NULL,
    texto TEXT NOT NULL,
    id_acta_aprobacion BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    vigente BOOLEAN NOT NULL DEFAULT FALSE,
    fecha_vigencia TIMESTAMP WITH TIME ZONE,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS ix_politica_tratamiento_acta ON gobernanza.politica_tratamiento (id_acta_aprobacion);
CREATE UNIQUE INDEX IF NOT EXISTS ux_politica_tratamiento_vigente ON gobernanza.politica_tratamiento ((TRUE)) WHERE vigente;
COMMENT ON TABLE gobernanza.politica_tratamiento IS 'Política de tratamiento de datos personales. Cada versión publicada es inmutable.';

CREATE TABLE IF NOT EXISTS gobernanza.finalidad_tratamiento (
    codigo VARCHAR(20) PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    descripcion TEXT NOT NULL,
    obligatoria BOOLEAN NOT NULL DEFAULT FALSE,
    orden INT NOT NULL DEFAULT 0,
    version INT NOT NULL DEFAULT 1
);
INSERT INTO gobernanza.finalidad_tratamiento (codigo, nombre, descripcion, obligatoria, orden) VALUES
    ('GESTION_SINDICAL', 'Gestión sindical',
     'Afiliación, representación, defensa de derechos, cobro de la cuota sindical, reuniones y actas. Incluye datos sensibles (afiliación sindical).', TRUE, 1),
    ('COMUNICACIONES', 'Comunicaciones del sindicato',
     'Correos, mensajes y saludos (p. ej. de cumpleaños) sobre la actividad sindical.', FALSE, 2),
    ('IMAGEN', 'Uso de imagen',
     'Fotos y videos en actividades del sindicato para publicarlos en sus redes y medios.', FALSE, 3)
ON CONFLICT (codigo) DO NOTHING;

INSERT INTO gobernanza.politica_tratamiento (numero_version, titulo, texto, vigente, fecha_vigencia)
SELECT '1.0', 'Política de tratamiento de datos personales (borrador para revisión del abogado)',
       'BORRADOR — debe revisarlo y ajustarlo el abogado del sindicato antes de usarlo.' || E'\n\n' ||
       'Responsable: el sindicato, con domicilio y canales de contacto registrados en sus estatutos.' || E'\n' ||
       'Datos que se tratan: identificación, contacto, empresa, cargo, salario, afiliación sindical y género. ' ||
       'La afiliación sindical y la orientación sexual son datos sensibles: su suministro es facultativo y su tratamiento ' ||
       'requiere autorización explícita (Ley 1581 de 2012, arts. 5 y 6).' || E'\n' ||
       'Finalidades: (1) gestión sindical; (2) comunicaciones del sindicato; (3) uso de imagen en actividades sindicales.' || E'\n' ||
       'Derechos del titular: conocer, actualizar, rectificar y suprimir sus datos, revocar la autorización y presentar quejas ' ||
       'ante la Superintendencia de Industria y Comercio. Las consultas se responden en máximo 10 días hábiles y los reclamos ' ||
       'en máximo 15 días hábiles.' || E'\n' ||
       'Seguridad: acceso solo por cargo y territorio, registro de quién consulta los datos y cifrado de las claves.',
       TRUE, now()
 WHERE NOT EXISTS (SELECT 1 FROM gobernanza.politica_tratamiento);

CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_politica_tratamiento()
RETURNS TRIGGER AS $$
BEGIN
    IF COALESCE(current_setting('privacidad.operacion', true), '') = 'publicar' THEN RETURN NEW; END IF;
    IF TG_OP = 'INSERT' THEN
        NEW.vigente := FALSE; NEW.fecha_vigencia := NULL; RETURN NEW;
    END IF;
    IF OLD.fecha_vigencia IS NOT NULL THEN
        RAISE EXCEPTION 'Una versión ya publicada de la política no se modifica: cree una versión nueva.';
    END IF;
    IF NEW.vigente IS DISTINCT FROM OLD.vigente OR NEW.fecha_vigencia IS DISTINCT FROM OLD.fecha_vigencia THEN
        RAISE EXCEPTION 'La política se publica con la acción Publicar.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_proteger_politica ON gobernanza.politica_tratamiento;
CREATE TRIGGER trg_proteger_politica BEFORE INSERT OR UPDATE ON gobernanza.politica_tratamiento
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_proteger_politica_tratamiento();

-- Publicar una versión: la anterior deja de regir y las autorizaciones dadas con ella quedan
-- "desactualizadas" (hay que recoger la autorización con el texto nuevo).
CREATE OR REPLACE FUNCTION gobernanza.fn_publicar_politica_tratamiento(p_id_politica BIGINT)
RETURNS VOID AS $$
DECLARE v_p gobernanza.politica_tratamiento%ROWTYPE;
BEGIN
    IF NOT (seguridad.fn_es_admin() OR seguridad.fn_es_presidente_nacional()) THEN
        RAISE EXCEPTION 'La política la publican el administrador o la Presidencia Nacional.';
    END IF;
    SELECT * INTO v_p FROM gobernanza.politica_tratamiento WHERE id_politica = p_id_politica FOR UPDATE;
    IF v_p.id_politica IS NULL THEN RAISE EXCEPTION 'La versión no existe.'; END IF;
    IF v_p.fecha_vigencia IS NOT NULL THEN RAISE EXCEPTION 'Esta versión ya fue publicada.'; END IF;
    IF v_p.id_acta_aprobacion IS NULL THEN
        RAISE EXCEPTION 'Antes de publicarla, asocie el acta de la Junta Nacional que aprobó esta versión.';
    END IF;
    PERFORM set_config('privacidad.operacion', 'publicar', true);
    UPDATE gobernanza.politica_tratamiento SET vigente = FALSE WHERE vigente;
    UPDATE gobernanza.politica_tratamiento SET vigente = TRUE, fecha_vigencia = now() WHERE id_politica = p_id_politica;
    PERFORM set_config('privacidad.operacion', '', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE TABLE IF NOT EXISTS gobernanza.autorizacion_datos (
    id_autorizacion BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    id_politica BIGINT NOT NULL REFERENCES gobernanza.politica_tratamiento(id_politica) ON DELETE RESTRICT,
    codigo_finalidad VARCHAR(20) NOT NULL REFERENCES gobernanza.finalidad_tratamiento(codigo) ON DELETE RESTRICT,
    otorgada BOOLEAN NOT NULL,
    medio VARCHAR(16) NOT NULL CHECK (medio IN ('FISICO', 'DIGITAL', 'VERBAL_GRABADO', 'PORTAL')),
    fecha_otorgamiento TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    id_documento_soporte BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    observaciones TEXT,
    estado VARCHAR(12) NOT NULL DEFAULT 'VIGENTE' CHECK (estado IN ('VIGENTE', 'REVOCADA', 'REEMPLAZADA')),
    fecha_revocacion TIMESTAMP WITH TIME ZONE,
    motivo_revocacion TEXT,
    usuario_revocacion VARCHAR(50),
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_autorizacion_soporte CHECK (medio IN ('DIGITAL', 'PORTAL') OR id_documento_soporte IS NOT NULL)
);
COMMENT ON TABLE gobernanza.autorizacion_datos IS 'Autorizaciones (o negativas) de tratamiento de datos por persona y finalidad. No se editan: se revocan o se reemplazan.';
CREATE INDEX IF NOT EXISTS ix_autorizacion_persona ON gobernanza.autorizacion_datos (id_persona, codigo_finalidad);
CREATE INDEX IF NOT EXISTS ix_autorizacion_politica ON gobernanza.autorizacion_datos (id_politica);
CREATE INDEX IF NOT EXISTS ix_autorizacion_soporte ON gobernanza.autorizacion_datos (id_documento_soporte);
CREATE INDEX IF NOT EXISTS ix_autorizacion_finalidad ON gobernanza.autorizacion_datos (codigo_finalidad);
CREATE UNIQUE INDEX IF NOT EXISTS ux_autorizacion_vigente ON gobernanza.autorizacion_datos (id_persona, codigo_finalidad)
    WHERE estado = 'VIGENTE';

CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_autorizacion()
RETURNS TRIGGER AS $$
DECLARE v_obligatoria BOOLEAN;
BEGIN
    IF COALESCE(current_setting('privacidad.operacion', true), '') IN ('revocar', 'reemplazar', 'anonimizar') THEN RETURN NEW; END IF;
    IF TG_OP = 'INSERT' THEN
        NEW.estado := 'VIGENTE'; NEW.fecha_revocacion := NULL; NEW.motivo_revocacion := NULL; NEW.usuario_revocacion := NULL;
        NEW.fecha_otorgamiento := COALESCE(NEW.fecha_otorgamiento, now());
        IF NEW.fecha_otorgamiento > now() + INTERVAL '1 hour' THEN RAISE EXCEPTION 'La fecha de la autorización no puede ser futura.'; END IF;
        IF NOT EXISTS (SELECT 1 FROM gobernanza.politica_tratamiento WHERE id_politica = NEW.id_politica AND fecha_vigencia IS NOT NULL) THEN
            RAISE EXCEPTION 'La autorización se da sobre una versión publicada de la política de tratamiento.';
        END IF;
        -- La autorización nueva reemplaza a la anterior de la misma persona y finalidad
        PERFORM set_config('privacidad.operacion', 'reemplazar', true);
        UPDATE gobernanza.autorizacion_datos SET estado = 'REEMPLAZADA'
         WHERE id_persona = NEW.id_persona AND codigo_finalidad = NEW.codigo_finalidad AND estado = 'VIGENTE';
        PERFORM set_config('privacidad.operacion', '', true);
        RETURN NEW;
    END IF;
    RAISE EXCEPTION 'Una autorización no se modifica: si la persona cambia de decisión, registre una nueva o revóquela.';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
DROP TRIGGER IF EXISTS trg_proteger_autorizacion ON gobernanza.autorizacion_datos;
CREATE TRIGGER trg_proteger_autorizacion BEFORE INSERT OR UPDATE ON gobernanza.autorizacion_datos
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_proteger_autorizacion();

CREATE OR REPLACE FUNCTION gobernanza.fn_revocar_autorizacion(p_id_autorizacion BIGINT, p_motivo TEXT)
RETURNS VOID AS $$
DECLARE v_a gobernanza.autorizacion_datos%ROWTYPE;
BEGIN
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo de la revocación (mínimo 10 caracteres).'; END IF;
    SELECT * INTO v_a FROM gobernanza.autorizacion_datos WHERE id_autorizacion = p_id_autorizacion FOR UPDATE;
    IF v_a.id_autorizacion IS NULL
       OR NOT seguridad.fn_persona_visible(v_a.id_persona, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos()) THEN
        RAISE EXCEPTION 'La autorización no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v_a.estado <> 'VIGENTE' THEN RAISE EXCEPTION 'Solo se revoca una autorización vigente.'; END IF;
    PERFORM set_config('privacidad.operacion', 'revocar', true);
    UPDATE gobernanza.autorizacion_datos SET estado = 'REVOCADA', fecha_revocacion = now(), motivo_revocacion = trim(p_motivo),
           usuario_revocacion = auditoria.fn_usuario_actual()
     WHERE id_autorizacion = p_id_autorizacion;
    PERFORM set_config('privacidad.operacion', '', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Estado de la autorización de una persona para una finalidad
CREATE OR REPLACE FUNCTION gobernanza.fn_estado_autorizacion(p_id_persona BIGINT, p_finalidad TEXT)
RETURNS TEXT AS $$
    SELECT COALESCE((
        SELECT CASE WHEN NOT a.otorgada THEN 'NEGADA'
                    WHEN p.vigente THEN 'AUTORIZADA'
                    ELSE 'DESACTUALIZADA' END
          FROM gobernanza.autorizacion_datos a JOIN gobernanza.politica_tratamiento p ON p.id_politica = a.id_politica
         WHERE a.id_persona = p_id_persona AND a.codigo_finalidad = p_finalidad AND a.estado = 'VIGENTE'),
        (SELECT 'REVOCADA' FROM gobernanza.autorizacion_datos a
          WHERE a.id_persona = p_id_persona AND a.codigo_finalidad = p_finalidad AND a.estado = 'REVOCADA'
            AND NOT EXISTS (SELECT 1 FROM gobernanza.autorizacion_datos b WHERE b.id_persona = a.id_persona
                              AND b.codigo_finalidad = a.codigo_finalidad AND b.estado = 'VIGENTE')
          LIMIT 1),
        'PENDIENTE');
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ¿Se le pueden enviar comunicaciones? (no si negó o revocó esa finalidad)
CREATE OR REPLACE FUNCTION gobernanza.fn_acepta_comunicaciones(p_id_persona BIGINT)
RETURNS BOOLEAN AS $$
    SELECT gobernanza.fn_estado_autorizacion(p_id_persona, 'COMUNICACIONES') NOT IN ('NEGADA', 'REVOCADA');
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Control: afiliados activos sin autorización vigente para la gestión sindical
CREATE OR REPLACE VIEW gobernanza.v_auditoria_consentimiento WITH (security_invoker = true) AS
SELECT e.nombre_estamento AS junta,
       p.primer_nombre || ' ' || p.primer_apellido AS afiliado,
       p.tipo_dni || ' ' || p.dni AS identificacion,
       a.fecha_afiliacion,
       gobernanza.fn_estado_autorizacion(a.id_persona, 'GESTION_SINDICAL') AS gestion_sindical,
       gobernanza.fn_estado_autorizacion(a.id_persona, 'COMUNICACIONES') AS comunicaciones,
       gobernanza.fn_estado_autorizacion(a.id_persona, 'IMAGEN') AS uso_imagen,
       CASE gobernanza.fn_estado_autorizacion(a.id_persona, 'GESTION_SINDICAL')
            WHEN 'AUTORIZADA' THEN 'AUTORIZACIÓN VIGENTE'
            WHEN 'DESACTUALIZADA' THEN 'ALERTA MEDIA: AUTORIZÓ UNA VERSIÓN ANTERIOR DE LA POLÍTICA (RECOGER LA NUEVA)'
            WHEN 'PENDIENTE' THEN 'ALERTA ALTA: AFILIADO SIN AUTORIZACIÓN DE TRATAMIENTO DE DATOS'
            ELSE 'ALERTA CRÍTICA: NEGÓ O REVOCÓ LA AUTORIZACIÓN PARA LA GESTIÓN SINDICAL' END AS diagnostico,
       a.id_persona, a.id_estamento_pertenencia AS id_estamento
  FROM gobernanza.afiliado a
  JOIN gobernanza.persona p ON p.id_persona = a.id_persona
  LEFT JOIN gobernanza.estamento e ON e.id_estamento = a.id_estamento_pertenencia
 WHERE a.activo;

-- ----------------------------------------------------------------------------
-- 7. SOLICITUDES DEL TITULAR (consultas y reclamos)
-- ----------------------------------------------------------------------------
CREATE SEQUENCE IF NOT EXISTS gobernanza.seq_solicitud_titular;
CREATE TABLE IF NOT EXISTS gobernanza.solicitud_titular (
    id_solicitud BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    radicado VARCHAR(20) NOT NULL UNIQUE,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    tipo VARCHAR(16) NOT NULL CHECK (tipo IN ('CONSULTA', 'ACTUALIZACION', 'RECTIFICACION', 'SUPRESION', 'REVOCACION', 'RECLAMO')),
    descripcion TEXT NOT NULL,
    medio VARCHAR(10) NOT NULL DEFAULT 'CORREO' CHECK (medio IN ('CORREO', 'FISICO', 'PORTAL', 'VERBAL')),
    fecha_radicacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_base DATE NOT NULL,
    fecha_limite DATE NOT NULL,
    prorrogada BOOLEAN NOT NULL DEFAULT FALSE,
    motivo_prorroga TEXT,
    estado VARCHAR(12) NOT NULL DEFAULT 'RADICADA' CHECK (estado IN ('RADICADA', 'EN_TRAMITE', 'RESPONDIDA')),
    respuesta TEXT,
    fecha_respuesta TIMESTAMP WITH TIME ZONE,
    usuario_respuesta VARCHAR(50),
    id_documento_respuesta BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gobernanza.solicitud_titular IS 'Consultas y reclamos de los titulares (Ley 1581, arts. 14 y 15) con su plazo en días hábiles.';
CREATE INDEX IF NOT EXISTS ix_solicitud_titular_persona ON gobernanza.solicitud_titular (id_persona);
CREATE INDEX IF NOT EXISTS ix_solicitud_titular_documento ON gobernanza.solicitud_titular (id_documento_respuesta);
CREATE INDEX IF NOT EXISTS ix_solicitud_titular_abiertas ON gobernanza.solicitud_titular (fecha_limite) WHERE estado <> 'RESPONDIDA';

CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_solicitud_titular()
RETURNS TRIGGER AS $$
DECLARE v_dias INT;
BEGIN
    IF COALESCE(current_setting('privacidad.operacion', true), '') IN ('prorrogar', 'responder', 'anonimizar') THEN RETURN NEW; END IF;
    IF TG_OP = 'INSERT' THEN
        NEW.fecha_radicacion := COALESCE(NEW.fecha_radicacion, now());
        IF NEW.fecha_radicacion > now() + INTERVAL '1 hour' THEN RAISE EXCEPTION 'La fecha de radicación no puede ser futura.'; END IF;
        NEW.radicado := 'SOL-' || to_char(NEW.fecha_radicacion AT TIME ZONE gestion_documental.fn_zona(), 'YYYY') || '-'
                        || lpad(nextval('gobernanza.seq_solicitud_titular')::TEXT, 5, '0');
        v_dias := CASE WHEN NEW.tipo = 'CONSULTA' THEN seguridad.fn_parametro_privacidad('DIAS_CONSULTA_TITULAR')
                       ELSE seguridad.fn_parametro_privacidad('DIAS_RECLAMO_TITULAR') END;
        NEW.fecha_base := gobernanza.fn_dia_base_radicacion(NEW.fecha_radicacion);
        NEW.fecha_limite := gobernanza.fn_sumar_dias_habiles(NEW.fecha_base, v_dias);
        NEW.prorrogada := FALSE; NEW.motivo_prorroga := NULL;
        NEW.estado := 'RADICADA'; NEW.respuesta := NULL; NEW.fecha_respuesta := NULL; NEW.usuario_respuesta := NULL;
        RETURN NEW;
    END IF;
    IF OLD.estado = 'RESPONDIDA' THEN RAISE EXCEPTION 'Una solicitud respondida no se modifica.'; END IF;
    IF NEW.radicado IS DISTINCT FROM OLD.radicado OR NEW.fecha_radicacion IS DISTINCT FROM OLD.fecha_radicacion
       OR NEW.fecha_base IS DISTINCT FROM OLD.fecha_base OR NEW.fecha_limite IS DISTINCT FROM OLD.fecha_limite
       OR NEW.tipo IS DISTINCT FROM OLD.tipo OR NEW.id_persona IS DISTINCT FROM OLD.id_persona
       OR NEW.prorrogada IS DISTINCT FROM OLD.prorrogada OR NEW.respuesta IS DISTINCT FROM OLD.respuesta
       OR NEW.fecha_respuesta IS DISTINCT FROM OLD.fecha_respuesta THEN
        RAISE EXCEPTION 'El radicado, el tipo, las fechas y la respuesta los registra el sistema (use Prorrogar o Responder).';
    END IF;
    IF NEW.estado NOT IN ('RADICADA', 'EN_TRAMITE') THEN RAISE EXCEPTION 'La solicitud se responde con la acción Responder.'; END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_proteger_solicitud ON gobernanza.solicitud_titular;
CREATE TRIGGER trg_proteger_solicitud BEFORE INSERT OR UPDATE ON gobernanza.solicitud_titular
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_proteger_solicitud_titular();

CREATE OR REPLACE FUNCTION gobernanza.fn_prorrogar_solicitud_titular(p_id BIGINT, p_motivo TEXT)
RETURNS DATE AS $$
DECLARE v_s gobernanza.solicitud_titular%ROWTYPE; v_nueva DATE;
BEGIN
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo de la prórroga (mínimo 10 caracteres).'; END IF;
    SELECT * INTO v_s FROM gobernanza.solicitud_titular WHERE id_solicitud = p_id FOR UPDATE;
    IF v_s.id_solicitud IS NULL
       OR NOT seguridad.fn_persona_visible(v_s.id_persona, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos()) THEN
        RAISE EXCEPTION 'La solicitud no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v_s.estado = 'RESPONDIDA' THEN RAISE EXCEPTION 'La solicitud ya fue respondida.'; END IF;
    IF v_s.prorrogada THEN RAISE EXCEPTION 'La solicitud ya fue prorrogada una vez (la ley no permite más).'; END IF;
    IF (now() AT TIME ZONE gestion_documental.fn_zona())::DATE > v_s.fecha_limite THEN
        RAISE EXCEPTION 'El plazo ya venció: la prórroga se informa al titular antes del vencimiento.';
    END IF;
    v_nueva := gobernanza.fn_sumar_dias_habiles(v_s.fecha_limite,
        CASE WHEN v_s.tipo = 'CONSULTA' THEN seguridad.fn_parametro_privacidad('DIAS_PRORROGA_CONSULTA')
             ELSE seguridad.fn_parametro_privacidad('DIAS_PRORROGA_RECLAMO') END::INT);
    PERFORM set_config('privacidad.operacion', 'prorrogar', true);
    UPDATE gobernanza.solicitud_titular SET prorrogada = TRUE, motivo_prorroga = trim(p_motivo), fecha_limite = v_nueva,
           estado = 'EN_TRAMITE'
     WHERE id_solicitud = p_id;
    PERFORM set_config('privacidad.operacion', '', true);
    RETURN v_nueva;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_responder_solicitud_titular(p_id BIGINT, p_respuesta TEXT, p_id_documento BIGINT DEFAULT NULL)
RETURNS VOID AS $$
DECLARE v_s gobernanza.solicitud_titular%ROWTYPE;
BEGIN
    IF length(trim(COALESCE(p_respuesta, ''))) < 20 THEN RAISE EXCEPTION 'Escriba la respuesta dada al titular (mínimo 20 caracteres).'; END IF;
    SELECT * INTO v_s FROM gobernanza.solicitud_titular WHERE id_solicitud = p_id FOR UPDATE;
    IF v_s.id_solicitud IS NULL
       OR NOT seguridad.fn_persona_visible(v_s.id_persona, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos()) THEN
        RAISE EXCEPTION 'La solicitud no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v_s.estado = 'RESPONDIDA' THEN RAISE EXCEPTION 'La solicitud ya fue respondida.'; END IF;
    PERFORM set_config('privacidad.operacion', 'responder', true);
    UPDATE gobernanza.solicitud_titular SET estado = 'RESPONDIDA', respuesta = trim(p_respuesta), fecha_respuesta = now(),
           usuario_respuesta = auditoria.fn_usuario_actual(), id_documento_respuesta = COALESCE(p_id_documento, id_documento_respuesta)
     WHERE id_solicitud = p_id;
    PERFORM set_config('privacidad.operacion', '', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE VIEW gobernanza.v_auditoria_solicitudes_titular WITH (security_invoker = true) AS
WITH s AS (
    SELECT st.*, (now() AT TIME ZONE gestion_documental.fn_zona())::DATE AS hoy,
           GREATEST(gobernanza.fn_dias_habiles_entre(st.fecha_base, st.fecha_limite), 1) AS plazo,
           gobernanza.fn_dias_habiles_entre(st.fecha_base, LEAST((now() AT TIME ZONE gestion_documental.fn_zona())::DATE, st.fecha_limite)) AS usados
      FROM gobernanza.solicitud_titular st
)
SELECT s.radicado, s.tipo, p.primer_nombre || ' ' || p.primer_apellido AS titular, e.nombre_estamento AS junta,
       s.fecha_radicacion, s.fecha_limite, s.prorrogada, s.estado,
       CASE WHEN s.estado = 'RESPONDIDA' THEN NULL
            ELSE gobernanza.fn_dias_habiles_entre(s.hoy, s.fecha_limite) END AS dias_habiles_restantes,
       CASE WHEN s.estado = 'RESPONDIDA' AND (s.fecha_respuesta AT TIME ZONE gestion_documental.fn_zona())::DATE > s.fecha_limite
                THEN 'RESPONDIDA FUERA DE TÉRMINO'
            WHEN s.estado = 'RESPONDIDA' THEN 'RESPONDIDA A TIEMPO'
            WHEN s.hoy > s.fecha_limite THEN 'ALERTA CRÍTICA: PLAZO VENCIDO SIN RESPUESTA'
            WHEN s.usados >= s.plazo * 0.8 THEN 'ALERTA ALTA: SE HA CONSUMIDO EL 80 % DEL PLAZO'
            WHEN s.usados >= s.plazo * 0.5 THEN 'ALERTA MEDIA: SE HA CONSUMIDO LA MITAD DEL PLAZO'
            ELSE 'EN TÉRMINO' END AS diagnostico,
       s.id_solicitud, s.id_persona, a.id_estamento_pertenencia AS id_estamento
  FROM s
  JOIN gobernanza.persona p ON p.id_persona = s.id_persona
  LEFT JOIN gobernanza.afiliado a ON a.id_persona = s.id_persona
  LEFT JOIN gobernanza.estamento e ON e.id_estamento = a.id_estamento_pertenencia;

-- ----------------------------------------------------------------------------
-- 8. ANONIMIZACIÓN (supresión de datos) con doble control
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.anonimizacion (
    id_anonimizacion BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    id_solicitud BIGINT REFERENCES gobernanza.solicitud_titular(id_solicitud) ON DELETE RESTRICT,
    motivo TEXT NOT NULL,
    estado VARCHAR(10) NOT NULL DEFAULT 'PENDIENTE' CHECK (estado IN ('PENDIENTE', 'EJECUTADA', 'RECHAZADA')),
    id_usuario_solicita BIGINT NOT NULL REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    fecha_solicitud TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    id_usuario_decide BIGINT REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    fecha_decision TIMESTAMP WITH TIME ZONE,
    observacion_decision TEXT,
    registros_bitacora INT,
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gobernanza.anonimizacion IS 'Supresión de datos de una persona: la pide el administrador y la aprueba la Presidencia Nacional.';
CREATE INDEX IF NOT EXISTS ix_anonimizacion_persona ON gobernanza.anonimizacion (id_persona);
CREATE INDEX IF NOT EXISTS ix_anonimizacion_solicitud ON gobernanza.anonimizacion (id_solicitud);
CREATE INDEX IF NOT EXISTS ix_anonimizacion_solicita ON gobernanza.anonimizacion (id_usuario_solicita);
CREATE INDEX IF NOT EXISTS ix_anonimizacion_decide ON gobernanza.anonimizacion (id_usuario_decide);
CREATE UNIQUE INDEX IF NOT EXISTS ux_anonimizacion_pendiente ON gobernanza.anonimizacion (id_persona) WHERE estado = 'PENDIENTE';

CREATE OR REPLACE FUNCTION gobernanza.fn_impedimento_anonimizar(p_id_persona BIGINT)
RETURNS TEXT AS $$
    SELECT CASE
        WHEN NOT EXISTS (SELECT 1 FROM gobernanza.persona WHERE id_persona = p_id_persona) THEN 'La persona no existe.'
        WHEN EXISTS (SELECT 1 FROM gobernanza.persona WHERE id_persona = p_id_persona AND dni LIKE 'ANON-%') THEN 'La persona ya fue anonimizada.'
        WHEN EXISTS (SELECT 1 FROM gobernanza.persona WHERE id_persona = p_id_persona AND activo) THEN
             'Primero inactive a la persona (y antes su afiliación): solo se anonimiza a quien ya no tiene vínculo con el sindicato.'
        WHEN EXISTS (SELECT 1 FROM gobernanza.afiliado WHERE id_persona = p_id_persona AND activo) THEN 'La persona tiene una afiliación activa.'
        WHEN EXISTS (SELECT 1 FROM gobernanza.directivo_estamento WHERE id_persona = p_id_persona AND fecha_retiro IS NULL) THEN
             'La persona tiene un cargo directivo vigente.'
        WHEN EXISTS (SELECT 1 FROM seguridad.usuario WHERE id_persona = p_id_persona AND activo) THEN 'La persona tiene un usuario activo.'
        WHEN EXISTS (SELECT 1 FROM gobernanza.solicitud_titular WHERE id_persona = p_id_persona AND estado <> 'RESPONDIDA'
                        AND tipo <> 'SUPRESION') THEN
             'La persona tiene solicitudes abiertas distintas de la supresión: respóndalas primero.'
        END;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_solicitar_anonimizacion(p_id_persona BIGINT, p_motivo TEXT, p_id_solicitud BIGINT DEFAULT NULL)
RETURNS BIGINT AS $$
DECLARE v_imp TEXT; v_id BIGINT;
BEGIN
    IF NOT seguridad.fn_es_admin() THEN RAISE EXCEPTION 'La anonimización la solicita el administrador.'; END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo (mínimo 10 caracteres).'; END IF;
    v_imp := gobernanza.fn_impedimento_anonimizar(p_id_persona);
    IF v_imp IS NOT NULL THEN RAISE EXCEPTION '%', v_imp; END IF;
    IF p_id_solicitud IS NOT NULL AND NOT EXISTS (SELECT 1 FROM gobernanza.solicitud_titular
                                                   WHERE id_solicitud = p_id_solicitud AND id_persona = p_id_persona) THEN
        RAISE EXCEPTION 'La solicitud del titular no corresponde a esta persona.';
    END IF;
    INSERT INTO gobernanza.anonimizacion (id_persona, id_solicitud, motivo, id_usuario_solicita)
    VALUES (p_id_persona, p_id_solicitud, trim(p_motivo), seguridad.fn_id_usuario_actual())
    RETURNING id_anonimizacion INTO v_id;
    RETURN v_id;
EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION 'Ya hay una solicitud de anonimización pendiente para esta persona.';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Reemplaza los valores que identifican a la persona dentro de una copia JSON de un registro
CREATE OR REPLACE FUNCTION auditoria.fn_json_anonimizado(p_datos JSONB)
RETURNS JSONB AS $$
    SELECT CASE WHEN p_datos IS NULL THEN NULL ELSE
        p_datos || COALESCE((SELECT jsonb_object_agg(k, 'ANONIMIZADO') FROM unnest(ARRAY[
            'dni', 'primer_nombre', 'segundo_nombre', 'primer_apellido', 'segundo_apellido', 'correo_electronico', 'telefono',
            'genero', 'fecha_nacimiento', 'municipio', 'departamento', 'area_empresa', 'detalles_cargo', 'nombre_completo',
            'tipo_alimentacion', 'zona_residencia']) k WHERE p_datos ? k), '{}'::JSONB) END;
$$ LANGUAGE sql IMMUTABLE;

CREATE OR REPLACE FUNCTION gobernanza.fn_decidir_anonimizacion(p_id BIGINT, p_aprobar BOOLEAN, p_observacion TEXT DEFAULT NULL)
RETURNS TEXT AS $$
DECLARE v_a gobernanza.anonimizacion%ROWTYPE; v_imp TEXT; v_n INT := 0; p BIGINT; v_correo TEXT;
BEGIN
    IF NOT seguridad.fn_es_presidente_nacional() THEN
        RAISE EXCEPTION 'La anonimización la aprueba o rechaza la Presidencia Nacional.';
    END IF;
    SELECT * INTO v_a FROM gobernanza.anonimizacion WHERE id_anonimizacion = p_id FOR UPDATE;
    IF v_a.id_anonimizacion IS NULL THEN RAISE EXCEPTION 'La solicitud no existe.'; END IF;
    IF v_a.estado <> 'PENDIENTE' THEN RAISE EXCEPTION 'La solicitud ya fue decidida.'; END IF;
    IF v_a.id_usuario_solicita = seguridad.fn_id_usuario_actual() THEN
        RAISE EXCEPTION 'Quien solicita la anonimización no puede aprobarla (doble control).';
    END IF;
    IF NOT p_aprobar THEN
        IF length(trim(COALESCE(p_observacion, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo del rechazo (mínimo 10 caracteres).'; END IF;
        UPDATE gobernanza.anonimizacion SET estado = 'RECHAZADA', id_usuario_decide = seguridad.fn_id_usuario_actual(),
               fecha_decision = now(), observacion_decision = trim(p_observacion)
         WHERE id_anonimizacion = p_id;
        RETURN 'RECHAZADA';
    END IF;
    v_imp := gobernanza.fn_impedimento_anonimizar(v_a.id_persona);
    IF v_imp IS NOT NULL THEN RAISE EXCEPTION '%', v_imp; END IF;
    p := v_a.id_persona;
    SELECT correo_electronico INTO v_correo FROM gobernanza.persona WHERE id_persona = p;

    -- Operación del sistema: permite modificar registros inactivos e históricos
    PERFORM set_config('sgs.operacion', 'sistema', true);
    PERFORM set_config('privacidad.operacion', 'anonimizar', true);
    UPDATE gobernanza.persona SET tipo_dni = 'OTRO', dni = 'ANON-' || p, primer_nombre = 'ANONIMIZADO', segundo_nombre = NULL,
           primer_apellido = 'ANONIMIZADO', segundo_apellido = NULL, pais = NULL, departamento = NULL, municipio = NULL,
           genero = NULL, telefono = NULL, correo_electronico = 'anonimizado.' || p || '@anonimizado.invalid'
     WHERE id_persona = p;
    UPDATE gobernanza.afiliado SET fecha_nacimiento = date_trunc('year', fecha_nacimiento)::DATE, area_empresa = NULL,
           detalles_cargo = NULL, tipo_alimentacion = NULL, zona_residencia = NULL
     WHERE id_persona = p;
    UPDATE seguridad.usuario SET nombre_completo = 'ANONIMIZADO', correo_electronico = NULL WHERE id_persona = p;
    -- Copias en la bitácora de cambios (las cifras y fechas de los movimientos se conservan)
    PERFORM set_config('sgs.operacion', 'anonimizar', true);
    UPDATE auditoria.bitacora_cambios
       SET datos_anteriores = auditoria.fn_json_anonimizado(datos_anteriores), datos_nuevos = auditoria.fn_json_anonimizado(datos_nuevos)
     WHERE nombre_tabla IN ('persona', 'afiliado', 'afiliado_empresa', 'salario_historico', 'usuario', 'jefe_empresa', 'comite_miembro')
       AND ((datos_anteriores->>'id_persona')::BIGINT = p OR (datos_nuevos->>'id_persona')::BIGINT = p);
    GET DIAGNOSTICS v_n = ROW_COUNT;
    -- Historial de correos enviados a esa persona
    IF v_correo IS NOT NULL THEN
        UPDATE notificaciones.registro_envio SET destinatario = 'anonimizado.' || p || '@anonimizado.invalid'
         WHERE lower(destinatario) = lower(v_correo);
    END IF;
    PERFORM set_config('sgs.operacion', '', true);
    PERFORM set_config('privacidad.operacion', '', true);

    UPDATE gobernanza.anonimizacion SET estado = 'EJECUTADA', id_usuario_decide = seguridad.fn_id_usuario_actual(),
           fecha_decision = now(), observacion_decision = NULLIF(trim(COALESCE(p_observacion, '')), ''), registros_bitacora = v_n
     WHERE id_anonimizacion = p_id;
    PERFORM seguridad.fn_registrar_acceso_dato('ANONIMIZACION', 'persona', p, NULL, v_n, v_a.motivo);
    RETURN 'EJECUTADA';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- La bitácora de cambios admite la anonimización (y nada más)
CREATE OR REPLACE FUNCTION auditoria.fn_bloquear_modificacion()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'UPDATE' AND TG_TABLE_NAME = 'bitacora_cambios'
       AND COALESCE(current_setting('sgs.operacion', true), '') = 'anonimizar' THEN
        RETURN NEW;
    END IF;
    RAISE EXCEPTION 'POLÍTICA DE AUDITORÍA: la tabla %.% es inmutable (operación % rechazada).', TG_TABLE_SCHEMA, TG_TABLE_NAME, TG_OP;
END;
$$ LANGUAGE plpgsql;

-- ----------------------------------------------------------------------------
-- 9. DATOS DEL TITULAR (para el reporte "¿qué datos tienen de mí?")
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION seguridad.fn_datos_del_titular(p_id_persona BIGINT)
RETURNS JSONB AS $$
DECLARE v JSONB;
BEGIN
    IF NOT seguridad.fn_puede_ver_dato('SENSIBLE', p_id_persona) OR NOT seguridad.fn_puede_ver_dato('SALARIO', p_id_persona)
       OR (NOT seguridad.fn_es_admin()
           AND NOT seguridad.fn_persona_visible(p_id_persona, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos())) THEN
        RAISE EXCEPTION 'El reporte completo de datos del titular lo generan el administrador, la Presidencia o la Secretaría General de su junta.'
            USING ERRCODE = 'insufficient_privilege';
    END IF;
    SELECT jsonb_build_object(
        'persona', (SELECT to_jsonb(x) - 'version' FROM gobernanza.persona x WHERE x.id_persona = p_id_persona),
        'afiliado', (SELECT to_jsonb(a) - 'version' || jsonb_build_object('junta', e.nombre_estamento)
                       FROM gobernanza.afiliado a LEFT JOIN gobernanza.estamento e ON e.id_estamento = a.id_estamento_pertenencia
                      WHERE a.id_persona = p_id_persona),
        'empresa', (SELECT jsonb_build_object('empresa', em.nombre_empresa, 'nit', em.nit, 'sede', s.nombre_sede,
                                              'fecha_ingreso', ae.fecha_ingreso_empresa, 'salario', ae.salario_base)
                      FROM gobernanza.afiliado_empresa ae JOIN gobernanza.empresa em ON em.id_empresa = ae.id_empresa
                      LEFT JOIN gobernanza.sede_empresa s ON s.id_sede = ae.id_sede WHERE ae.id_persona = p_id_persona),
        'salarios', (SELECT jsonb_agg(jsonb_build_object('vigente_desde', vigente_desde, 'salario', salario) ORDER BY vigente_desde)
                       FROM gobernanza.salario_historico WHERE id_persona = p_id_persona),
        'cargos', (SELECT jsonb_agg(jsonb_build_object('junta', e.nombre_estamento, 'cargo', c.nombre, 'posesion', d.fecha_posesion_individual,
                                                       'retiro', d.fecha_retiro) ORDER BY d.fecha_posesion_individual)
                     FROM gobernanza.directivo_estamento d JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
                     JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento WHERE d.id_persona = p_id_persona),
        'aportes', (SELECT jsonb_build_object('meses', count(*), 'total', COALESCE(sum(monto_descuento_ley), 0),
                                              'ultimo', max(make_date(periodo_anio, periodo_mes, 1)))
                      FROM finanzas.aporte_afiliado WHERE id_persona = p_id_persona AND NOT anulado),
        'autorizaciones', (SELECT jsonb_agg(jsonb_build_object('finalidad', f.nombre, 'otorgada', a.otorgada, 'medio', a.medio,
                                                               'fecha', a.fecha_otorgamiento, 'estado', a.estado,
                                                               'politica', p.numero_version) ORDER BY a.fecha_otorgamiento)
                             FROM gobernanza.autorizacion_datos a JOIN gobernanza.finalidad_tratamiento f ON f.codigo = a.codigo_finalidad
                             JOIN gobernanza.politica_tratamiento p ON p.id_politica = a.id_politica WHERE a.id_persona = p_id_persona),
        'solicitudes', (SELECT jsonb_agg(jsonb_build_object('radicado', radicado, 'tipo', tipo, 'fecha', fecha_radicacion, 'estado', estado)
                                         ORDER BY fecha_radicacion)
                          FROM gobernanza.solicitud_titular WHERE id_persona = p_id_persona),
        'accesos', (SELECT jsonb_agg(jsonb_build_object('fecha', fecha_hora, 'usuario', nombre_usuario, 'tipo', tipo,
                                                        'recurso', recurso, 'motivo', motivo) ORDER BY fecha_hora DESC)
                      FROM (SELECT * FROM auditoria.acceso_dato WHERE id_persona = p_id_persona ORDER BY fecha_hora DESC LIMIT 200) q)
    ) INTO v;
    PERFORM seguridad.fn_registrar_acceso_dato('REPORTE_TITULAR', 'persona', p_id_persona, ARRAY['todos'], 1, 'Reporte de datos para el titular');
    RETURN v;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 10. VERSIÓN, AUDITORÍA, SEGURIDAD POR FILAS, NO BORRAR Y PERMISOS DE LAS TABLAS NUEVAS
-- ----------------------------------------------------------------------------
DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['gobernanza.politica_tratamiento', 'gobernanza.finalidad_tratamiento', 'gobernanza.autorizacion_datos',
                             'gobernanza.solicitud_titular', 'gobernanza.anonimizacion', 'gobernanza.festivo',
                             'seguridad.parametro_privacidad'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_control_version ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_control_version BEFORE UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_auditoria ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_no_borrar ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_no_borrar BEFORE DELETE ON %s FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado()', t);
    END LOOP;
END $$;

SELECT seguridad.fn_aplicar_politicas('gobernanza.politica_tratamiento', 'true', ':N');
SELECT seguridad.fn_aplicar_politicas('gobernanza.finalidad_tratamiento', 'true', ':N');
SELECT seguridad.fn_aplicar_politicas('gobernanza.festivo', 'true', ':N');
SELECT seguridad.fn_aplicar_politicas('gobernanza.autorizacion_datos',
    'seguridad.fn_persona_visible(id_persona, :N, :E)', 'seguridad.fn_persona_visible(id_persona, :N, :E)');
SELECT seguridad.fn_aplicar_politicas('gobernanza.solicitud_titular',
    'seguridad.fn_persona_visible(id_persona, :N, :E)', 'seguridad.fn_persona_visible(id_persona, :N, :E)');
SELECT seguridad.fn_aplicar_politicas('gobernanza.anonimizacion',
    'seguridad.fn_es_admin() OR seguridad.fn_es_presidente_nacional()', 'false');

DO $$
DECLARE r TEXT;
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        GRANT SELECT, INSERT, UPDATE ON gobernanza.politica_tratamiento, gobernanza.finalidad_tratamiento, gobernanza.autorizacion_datos,
                                        gobernanza.solicitud_titular, gobernanza.festivo TO sgs_app;
        GRANT SELECT ON gobernanza.anonimizacion, seguridad.dato_sensible, seguridad.parametro_privacidad TO sgs_app;
        GRANT UPDATE ON seguridad.parametro_privacidad TO sgs_app;
        REVOKE INSERT, UPDATE, DELETE ON gobernanza.anonimizacion FROM sgs_app;
        REVOKE DELETE ON gobernanza.politica_tratamiento, gobernanza.finalidad_tratamiento, gobernanza.autorizacion_datos,
                         gobernanza.solicitud_titular, gobernanza.festivo FROM sgs_app;
        GRANT USAGE ON SEQUENCE gobernanza.seq_solicitud_titular TO sgs_app;
        GRANT SELECT ON gobernanza.v_auditoria_consentimiento, gobernanza.v_auditoria_solicitudes_titular,
                        auditoria.v_accesos_inusuales, auditoria.v_bitacora_cambios TO sgs_app;
        -- La bitácora de cambios se lee a través de la vista (con los datos reservados ocultos)
        REVOKE SELECT ON auditoria.bitacora_cambios FROM sgs_app;
        -- La bitácora de accesos solo se toca con sus funciones
        REVOKE ALL ON auditoria.acceso_dato FROM sgs_app;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_lectura') THEN
        GRANT SELECT ON gobernanza.politica_tratamiento, gobernanza.finalidad_tratamiento, gobernanza.festivo,
                        gobernanza.v_auditoria_consentimiento, gobernanza.v_auditoria_solicitudes_titular, auditoria.v_bitacora_cambios TO sgs_lectura;
        GRANT SELECT ON gobernanza.autorizacion_datos, gobernanza.solicitud_titular TO sgs_lectura;
        REVOKE SELECT ON auditoria.bitacora_cambios, auditoria.acceso_dato, gobernanza.anonimizacion FROM sgs_lectura;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_notificador') THEN
        GRANT USAGE ON SCHEMA auditoria TO sgs_notificador;
        GRANT SELECT ON gobernanza.politica_tratamiento, gobernanza.finalidad_tratamiento, gobernanza.autorizacion_datos,
                        gobernanza.solicitud_titular, gobernanza.festivo TO sgs_notificador;
        GRANT SELECT ON gobernanza.v_auditoria_consentimiento, gobernanza.v_auditoria_solicitudes_titular,
                        auditoria.v_accesos_inusuales TO sgs_notificador;
    END IF;
    -- Funciones que solo usa la aplicación con un usuario identificado
    FOREACH r IN ARRAY ARRAY['sgs_lectura', 'sgs_notificador'] LOOP
        CONTINUE WHEN NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r);
        EXECUTE format('REVOKE EXECUTE ON FUNCTION seguridad.fn_revelar_dato(TEXT, JSONB, TEXT), seguridad.fn_purgar_bitacora_accesos(), '
                       'seguridad.fn_datos_del_titular(BIGINT), gobernanza.fn_decidir_anonimizacion(BIGINT, BOOLEAN, TEXT), '
                       'gobernanza.fn_solicitar_anonimizacion(BIGINT, TEXT, BIGINT), gobernanza.fn_revocar_autorizacion(BIGINT, TEXT), '
                       'gobernanza.fn_publicar_politica_tratamiento(BIGINT), gobernanza.fn_prorrogar_solicitud_titular(BIGINT, TEXT), '
                       'gobernanza.fn_responder_solicitud_titular(BIGINT, TEXT, BIGINT) FROM %I', r);
    END LOOP;
END $$;
REVOKE EXECUTE ON FUNCTION seguridad.fn_registrar_acceso_dato(TEXT, TEXT, BIGINT, TEXT[], INT, TEXT) FROM PUBLIC;
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        GRANT EXECUTE ON FUNCTION seguridad.fn_registrar_acceso_dato(TEXT, TEXT, BIGINT, TEXT[], INT, TEXT) TO sgs_app;
    END IF;
END $$;

-- ----------------------------------------------------------------------------
-- 11. CORREOS AUTOMÁTICOS
-- ----------------------------------------------------------------------------
INSERT INTO notificaciones.tipo_notificacion (codigo, nombre, descripcion) VALUES
    ('CONSENTIMIENTO_DATOS', 'Afiliados sin autorización de datos',
     'Cada mes, al Presidente y al Secretario General de cada junta, la lista de sus afiliados sin autorización de tratamiento de datos vigente.'),
    ('SOLICITUDES_TITULAR', 'Solicitudes de titulares por vencer',
     'Cada día, al Presidente y al Secretario General de la junta del titular, las consultas y reclamos de datos que consumieron la mitad del plazo, el 80 % o ya vencieron.'),
    ('ACCESOS_INUSUALES', 'Consultas inusuales de datos personales',
     'Cada día, a la Presidencia Nacional, los usuarios que consultaron un número inusual de datos de personas.')
ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, descripcion = EXCLUDED.descripcion;
