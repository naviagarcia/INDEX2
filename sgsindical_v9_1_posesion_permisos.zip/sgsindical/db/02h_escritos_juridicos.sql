-- ============================================================================
-- SGSINDICAL v9.1 — 02h: ESCRITOS JURÍDICOS ASISTIDOS POR INTELIGENCIA ARTIFICIAL
-- Ejecutar DESPUÉS de 02g y ANTES de 03.
-- ----------------------------------------------------------------------------
--  J1. A partir de documentos fuente (texto, PDF, Word, audio o video — el audio y el video se
--      transcriben) y de las instrucciones del usuario, la IA redacta un PROYECTO de: derecho de
--      petición, queja, comunicado de denuncia pública, acción de tutela, recurso de reposición y en
--      subsidio de apelación, o queja por acoso laboral. El texto va directo, sin preliminares.
--  J2. Todo proyecto está SUJETO A REVISIÓN: se aprueba con tres aprobaciones sobre la MISMA versión
--      del texto: ABOGADO (usuario con rol ABOGADO y ámbito sobre la junta), PRESIDENCIA y SECRETARÍA
--      GENERAL de la junta. Los demás pueden comentar. Cualquier cambio del texto crea una versión
--      nueva y las aprobaciones anteriores dejan de valer.
--  J3. Solo un escrito APROBADO se radica (documento EMITIDO con PDF y huella SHA-256). Después ya no
--      se modifica. Cada versión, comentario y decisión queda en el historial.
-- ============================================================================
INSERT INTO seguridad.rol_app (codigo_rol, nombre_rol, descripcion, es_sistema) VALUES
    ('ABOGADO', 'Abogado / asesor jurídico', 'Revisa y aprueba los escritos jurídicos de las juntas de su ámbito.', FALSE)
ON CONFLICT (codigo_rol) DO NOTHING;
INSERT INTO seguridad.permiso_rol (codigo_rol, modulo, puede_consultar, puede_registrar, puede_actualizar, puede_eliminar, puede_ver_vistas) VALUES
    ('ABOGADO', 'GOBERNANZA', TRUE, FALSE, FALSE, FALSE, TRUE),
    ('ABOGADO', 'DOCUMENTAL', TRUE, TRUE, TRUE, FALSE, TRUE)
ON CONFLICT (codigo_rol, modulo) DO NOTHING;

-- Tipos documentales para radicar los escritos
INSERT INTO gestion_documental.tipo_documento (nombre_tipo, sigla_tipo, categoria_flujo, requiere_respuesta, dias_termino_legal, descripcion) VALUES
    ('QUEJA', 'QUE', 'EMITIDO', TRUE, 15, 'Quejas administrativas o disciplinarias presentadas por el sindicato.'),
    ('COMUNICADO DE DENUNCIA PÚBLICA', 'DEN', 'EMITIDO', FALSE, 0, 'Pronunciamientos públicos del sindicato que denuncian hechos.'),
    ('ACCIÓN DE TUTELA', 'TUT', 'EMITIDO', TRUE, 10, 'Acciones de tutela presentadas por el sindicato o con su apoyo.'),
    ('RECURSO DE REPOSICIÓN Y/O APELACIÓN', 'REC', 'EMITIDO', TRUE, 60, 'Recursos contra actos administrativos.'),
    ('QUEJA POR ACOSO LABORAL', 'ACO', 'EMITIDO', TRUE, 10, 'Quejas por acoso laboral (Ley 1010 de 2006).')
ON CONFLICT (sigla_tipo) DO NOTHING;

CREATE TABLE IF NOT EXISTS gestion_documental.tipo_escrito (
    codigo VARCHAR(20) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    sigla_tipo_documento VARCHAR(10) NOT NULL REFERENCES gestion_documental.tipo_documento(sigla_tipo) ON UPDATE CASCADE,
    orientacion TEXT NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    orden INT NOT NULL DEFAULT 0,
    version INT NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS ix_tipo_escrito_sigla ON gestion_documental.tipo_escrito (sigla_tipo_documento);
COMMENT ON TABLE gestion_documental.tipo_escrito IS
    'Tipos de escrito que redacta la IA. "orientacion" es la guía de estructura y normas que se le da (la ajusta el abogado o el administrador).';

INSERT INTO gestion_documental.tipo_escrito (codigo, nombre, sigla_tipo_documento, orden, orientacion) VALUES
('DERECHO_PETICION', 'Derecho de petición', 'PET', 1,
 'Derecho de petición (artículo 23 de la Constitución Política; Ley 1755 de 2015, que regula el derecho fundamental de petición en el CPACA). '
 'Estructura: ciudad y fecha; destinatario (autoridad o entidad, cargo y dirección); referencia ("Derecho de petición en interés general/particular"); '
 'identificación del peticionario (el sindicato, su representante y la junta); HECHOS numerados, claros y verificables; PETICIONES numeradas, concretas '
 'y respondibles una a una; FUNDAMENTOS DE DERECHO; ANEXOS; NOTIFICACIONES (dirección y correo); firma. Recuerde el término de respuesta '
 '(por regla general 15 días hábiles; 10 para solicitudes de documentos e información y 30 para consultas). Si se piden documentos o '
 'información de un trabajador, fundamente el interés legítimo del sindicato.'),
('QUEJA', 'Queja', 'QUE', 2,
 'Queja administrativa o disciplinaria (Ley 1755 de 2015; si es contra servidores públicos, Código General Disciplinario, Ley 1952 de 2019, '
 'ante la oficina de control interno disciplinario, la Personería o la Procuraduría). Estructura: destinatario competente; quejoso; servidor o '
 'dependencia contra quien se dirige (si se conoce); HECHOS en orden cronológico con circunstancias de tiempo, modo y lugar; conductas presuntamente '
 'irregulares; PRUEBAS que se aportan o solicitan; SOLICITUD (que se investigue, se adopten correctivos, se informe el resultado); notificaciones; firma. '
 'Use lenguaje de presunción ("presuntamente"), sin calificar penalmente las conductas.'),
('DENUNCIA_PUBLICA', 'Comunicado de denuncia pública', 'DEN', 3,
 'Comunicado público de la junta directiva. Estructura: título claro; encabezado con el nombre del sindicato y la junta; lugar y fecha; párrafo inicial '
 'que diga qué se denuncia; HECHOS verificables en orden; posición del sindicato con fundamento en la libertad de expresión (artículo 20 de la '
 'Constitución), el derecho de asociación sindical (artículo 39) y los Convenios 87 y 98 de la OIT; EXIGENCIAS concretas a la entidad o autoridad; '
 'llamado a la afiliación o a la opinión pública; firma de la junta directiva. Cuidados: solo hechos comprobables, lenguaje de presunción cuando no '
 'hay decisión de autoridad, respeto a la presunción de inocencia, sin datos personales ni de salud de trabajadores, sin expresiones que puedan '
 'constituir injuria o calumnia. Tono firme, sereno y comprensible para cualquier persona.'),
('TUTELA', 'Acción de tutela', 'TUT', 4,
 'Acción de tutela (artículo 86 de la Constitución; Decreto 2591 de 1991). Estructura: "Señor Juez (reparto)"; ACCIONANTE (y si actúa el sindicato, '
 'su legitimación: derechos de la organización o agencia oficiosa/representación del trabajador); ACCIONADO; HECHOS numerados; DERECHOS FUNDAMENTALES '
 'VULNERADOS (por ejemplo, asociación sindical, debido proceso, petición, trabajo, mínimo vital, estabilidad laboral reforzada); FUNDAMENTOS (con '
 'jurisprudencia solo si está seguro de la cita); PROCEDENCIA (subsidiariedad e inmediatez, y por qué otro medio no es idóneo o hay perjuicio '
 'irremediable); PRETENSIONES; MEDIDA PROVISIONAL si se justifica; JURAMENTO de no haber presentado otra tutela por los mismos hechos; PRUEBAS; '
 'ANEXOS; NOTIFICACIONES; firma.'),
('RECURSO', 'Recurso de reposición y en subsidio de apelación', 'REC', 5,
 'Recurso de reposición y en subsidio de apelación contra un acto administrativo (Ley 1437 de 2011, CPACA, artículos 74 a 77; se interpone por '
 'escrito dentro de los 10 días hábiles siguientes a la notificación). Estructura: autoridad que expidió el acto; identificación del acto (número, '
 'fecha, asunto) y fecha de notificación; recurrente y su interés; OPORTUNIDAD (por qué está en término); MOTIVOS DE INCONFORMIDAD expresados con '
 'precisión; FUNDAMENTOS DE DERECHO; PRUEBAS que se aportan o solicitan; PETICIÓN (revocar, modificar o aclarar; en subsidio, conceder la apelación '
 'ante el superior); notificaciones; firma. Si el acto es un traslado, una sanción o una desvinculación, revise también el fuero sindical.'),
('ACOSO_LABORAL', 'Queja por acoso laboral', 'ACO', 6,
 'Queja por acoso laboral (Ley 1010 de 2006: modalidades del artículo 2 y conductas del artículo 7). Destinatario: el Comité de Convivencia Laboral de '
 'la entidad y, según el caso, el Ministerio Público (Procuraduría o Personería) por tratarse de servidores públicos, o el inspector de trabajo. '
 'Estructura: destinatario; presunta víctima (con su consentimiento) y apoyo del sindicato; presunto acosador y cargo; HECHOS con fechas, lugares, '
 'testigos y frecuencia; modalidad de acoso; afectaciones; PRUEBAS; SOLICITUDES (medidas preventivas y correctivas, no represalias — garantías del '
 'artículo 11, confidencialidad); notificaciones; firma. Confidencialidad: no incluya datos de salud sin autorización.')
ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, sigla_tipo_documento = EXCLUDED.sigla_tipo_documento, orden = EXCLUDED.orden;

CREATE TABLE IF NOT EXISTS gestion_documental.escrito (
    id_escrito BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    codigo_tipo VARCHAR(20) NOT NULL REFERENCES gestion_documental.tipo_escrito(codigo) ON DELETE RESTRICT,
    titulo VARCHAR(250) NOT NULL,
    destinatario_persona VARCHAR(150),
    destinatario_institucion VARCHAR(150),
    instrucciones TEXT,
    estado VARCHAR(20) NOT NULL DEFAULT 'BORRADOR'
        CHECK (estado IN ('BORRADOR', 'EN_REVISION', 'CAMBIOS_SOLICITADOS', 'APROBADO', 'RADICADO', 'DESCARTADO')),
    version_actual INT NOT NULL DEFAULT 0,
    contenido TEXT,
    notas_revision TEXT,
    generando BOOLEAN NOT NULL DEFAULT FALSE,
    error_generacion TEXT,
    id_documento BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    motivo_descarte TEXT,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gestion_documental.escrito IS 'Escritos jurídicos (proyectos redactados con IA) sujetos a revisión del abogado, la presidencia y la secretaría.';
COMMENT ON COLUMN gestion_documental.escrito.notas_revision IS 'Lo que la IA pide verificar o completar (no forma parte del escrito).';
CREATE INDEX IF NOT EXISTS ix_escrito_estamento ON gestion_documental.escrito (id_estamento, estado);
CREATE INDEX IF NOT EXISTS ix_escrito_tipo ON gestion_documental.escrito (codigo_tipo);
CREATE INDEX IF NOT EXISTS ix_escrito_documento ON gestion_documental.escrito (id_documento);

CREATE TABLE IF NOT EXISTS gestion_documental.escrito_fuente (
    id_fuente BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_escrito BIGINT NOT NULL REFERENCES gestion_documental.escrito(id_escrito) ON DELETE CASCADE,
    clase VARCHAR(10) NOT NULL CHECK (clase IN ('TEXTO', 'PDF', 'WORD', 'AUDIO', 'VIDEO')),
    nombre_archivo VARCHAR(200),
    hash_sha256 VARCHAR(64),
    tamano_bytes BIGINT,
    duracion_segundos INT,
    estado VARCHAR(12) NOT NULL DEFAULT 'PENDIENTE' CHECK (estado IN ('PENDIENTE', 'PROCESANDO', 'LISTO', 'ERROR')),
    texto TEXT,
    detalle_error TEXT,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gestion_documental.escrito_fuente IS 'Documentos fuente del escrito (texto, PDF, Word, audio o video) y su texto extraído o transcrito.';
CREATE INDEX IF NOT EXISTS ix_escrito_fuente_escrito ON gestion_documental.escrito_fuente (id_escrito);

CREATE TABLE IF NOT EXISTS gestion_documental.escrito_version (
    id_version BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_escrito BIGINT NOT NULL REFERENCES gestion_documental.escrito(id_escrito) ON DELETE CASCADE,
    numero INT NOT NULL,
    origen VARCHAR(10) NOT NULL CHECK (origen IN ('IA', 'EDICION')),
    contenido TEXT NOT NULL,
    notas_revision TEXT,
    instrucciones TEXT,
    modelo_ia VARCHAR(60),
    id_usuario BIGINT REFERENCES seguridad.usuario(id_usuario) ON DELETE SET NULL,
    nombre_usuario VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    fecha TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (id_escrito, numero)
);
COMMENT ON TABLE gestion_documental.escrito_version IS 'Historial inmutable de versiones del texto (redactadas por la IA o editadas por una persona).';

CREATE TABLE IF NOT EXISTS gestion_documental.escrito_revision (
    id_revision BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_escrito BIGINT NOT NULL REFERENCES gestion_documental.escrito(id_escrito) ON DELETE CASCADE,
    numero_version INT NOT NULL,
    rol VARCHAR(12) NOT NULL CHECK (rol IN ('ABOGADO', 'PRESIDENCIA', 'SECRETARIA', 'COMENTARIO')),
    decision VARCHAR(10) NOT NULL CHECK (decision IN ('APRUEBA', 'CAMBIOS', 'COMENTA')),
    comentario TEXT,
    id_usuario BIGINT NOT NULL REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    nombre_usuario VARCHAR(50) NOT NULL,
    id_persona BIGINT REFERENCES gobernanza.persona(id_persona) ON DELETE SET NULL,
    cargo VARCHAR(80),
    fecha TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_revision_comentario CHECK (decision = 'APRUEBA' OR NULLIF(trim(comentario), '') IS NOT NULL)
);
COMMENT ON TABLE gestion_documental.escrito_revision IS 'Comentarios, solicitudes de cambio y aprobaciones de cada versión.';
CREATE INDEX IF NOT EXISTS ix_escrito_revision_escrito ON gestion_documental.escrito_revision (id_escrito, numero_version);
CREATE INDEX IF NOT EXISTS ix_escrito_revision_usuario ON gestion_documental.escrito_revision (id_usuario);
CREATE INDEX IF NOT EXISTS ix_escrito_revision_persona ON gestion_documental.escrito_revision (id_persona);
CREATE INDEX IF NOT EXISTS ix_escrito_version_usuario ON gestion_documental.escrito_version (id_usuario);
CREATE UNIQUE INDEX IF NOT EXISTS ux_escrito_aprobacion ON gestion_documental.escrito_revision (id_escrito, numero_version, rol)
    WHERE decision = 'APRUEBA';

DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['gestion_documental.tipo_escrito', 'gestion_documental.escrito', 'gestion_documental.escrito_fuente'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_control_version ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_control_version BEFORE UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version()', t);
    END LOOP;
    FOREACH t IN ARRAY ARRAY['gestion_documental.tipo_escrito', 'gestion_documental.escrito', 'gestion_documental.escrito_fuente',
                             'gestion_documental.escrito_version', 'gestion_documental.escrito_revision'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_auditoria ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria()', t);
    END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- 1. PROTECCIÓN: estado, versión y texto solo cambian con las funciones
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION gestion_documental.fn_escrito_proteger()
RETURNS TRIGGER AS $$
BEGIN
    IF COALESCE(current_setting('escritos.operacion', true), '') <> '' THEN
        RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
    END IF;
    IF TG_TABLE_NAME = 'escrito' THEN
        IF TG_OP = 'INSERT' THEN
            NEW.estado := 'BORRADOR'; NEW.version_actual := 0; NEW.contenido := NULL; NEW.notas_revision := NULL;
            NEW.generando := FALSE; NEW.id_documento := NULL;
            RETURN NEW;
        END IF;
        IF TG_OP = 'DELETE' THEN
            IF OLD.estado IN ('APROBADO', 'RADICADO') OR OLD.version_actual > 0 THEN
                RAISE EXCEPTION 'Un escrito con versiones no se elimina: descártelo indicando el motivo.';
            END IF;
            RETURN OLD;
        END IF;
        IF OLD.estado IN ('RADICADO', 'DESCARTADO') THEN
            RAISE EXCEPTION 'El escrito está %: ya no se modifica.', lower(OLD.estado);
        END IF;
        IF NEW.estado IS DISTINCT FROM OLD.estado OR NEW.version_actual IS DISTINCT FROM OLD.version_actual
           OR NEW.contenido IS DISTINCT FROM OLD.contenido OR NEW.notas_revision IS DISTINCT FROM OLD.notas_revision
           OR NEW.id_documento IS DISTINCT FROM OLD.id_documento OR NEW.generando IS DISTINCT FROM OLD.generando
           OR NEW.codigo_tipo IS DISTINCT FROM OLD.codigo_tipo OR NEW.id_estamento IS DISTINCT FROM OLD.id_estamento THEN
            RAISE EXCEPTION 'El texto, el estado, el tipo y la junta del escrito los cambian la redacción, la edición, la revisión y la radicación.';
        END IF;
        RETURN NEW;
    END IF;
    -- Fuentes: no se cambian cuando el escrito ya está radicado o descartado
    IF EXISTS (SELECT 1 FROM gestion_documental.escrito e
                WHERE e.id_escrito = CASE WHEN TG_OP = 'DELETE' THEN OLD.id_escrito ELSE NEW.id_escrito END
                  AND e.estado IN ('RADICADO', 'DESCARTADO')) THEN
        RAISE EXCEPTION 'El escrito ya no se modifica.';
    END IF;
    IF TG_OP = 'UPDATE' AND (NEW.texto IS DISTINCT FROM OLD.texto OR NEW.estado IS DISTINCT FROM OLD.estado
                             OR NEW.hash_sha256 IS DISTINCT FROM OLD.hash_sha256) AND OLD.clase <> 'TEXTO' THEN
        RAISE EXCEPTION 'El texto de una fuente de archivo lo extrae el sistema; para corregirlo, agregue una fuente de texto.';
    END IF;
    RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_escrito_proteger ON gestion_documental.escrito;
CREATE TRIGGER trg_escrito_proteger BEFORE INSERT OR UPDATE OR DELETE ON gestion_documental.escrito
    FOR EACH ROW EXECUTE FUNCTION gestion_documental.fn_escrito_proteger();
DROP TRIGGER IF EXISTS trg_escrito_proteger ON gestion_documental.escrito_fuente;
CREATE TRIGGER trg_escrito_proteger BEFORE INSERT OR UPDATE OR DELETE ON gestion_documental.escrito_fuente
    FOR EACH ROW EXECUTE FUNCTION gestion_documental.fn_escrito_proteger();

-- ----------------------------------------------------------------------------
-- 2. ROL DE REVISIÓN DEL USUARIO
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION gestion_documental.fn_rol_revision(p_id_escrito BIGINT, OUT rol TEXT, OUT cargo TEXT)
AS $$
DECLARE v_u seguridad.usuario; v_e gestion_documental.escrito; v_m RECORD;
BEGIN
    SELECT * INTO v_u FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo;
    SELECT * INTO v_e FROM gestion_documental.escrito WHERE id_escrito = p_id_escrito;
    IF v_u.id_usuario IS NULL OR v_e.id_escrito IS NULL THEN rol := NULL; RETURN; END IF;
    IF v_u.codigo_rol = 'ABOGADO' AND (seguridad.fn_ambito_nacional() OR v_e.id_estamento = ANY(seguridad.fn_ambito_estamentos())) THEN
        rol := 'ABOGADO'; cargo := 'Abogado'; RETURN;
    END IF;
    SELECT * INTO v_m FROM gestion_documental.fn_cargo_mesa(v_e.id_estamento);
    IF v_m.rol IS NOT NULL THEN rol := v_m.rol; cargo := v_m.cargo; RETURN; END IF;
    rol := 'COMENTARIO'; cargo := NULL;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Estado de aprobación de la versión vigente
CREATE OR REPLACE FUNCTION gestion_documental.fn_estado_revision(p_id_escrito BIGINT)
RETURNS TEXT AS $$
DECLARE v_e gestion_documental.escrito; v_aprob INT; v_cambios BOOLEAN;
BEGIN
    SELECT * INTO v_e FROM gestion_documental.escrito WHERE id_escrito = p_id_escrito;
    SELECT count(DISTINCT rol) FILTER (WHERE decision = 'APRUEBA'),
           bool_or(decision = 'CAMBIOS')
      INTO v_aprob, v_cambios
      FROM gestion_documental.escrito_revision WHERE id_escrito = p_id_escrito AND numero_version = v_e.version_actual;
    IF v_aprob = 3 THEN RETURN 'APROBADO'; END IF;
    IF COALESCE(v_cambios, FALSE) THEN RETURN 'CAMBIOS_SOLICITADOS'; END IF;
    RETURN 'EN_REVISION';
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 3. NUEVA VERSIÓN (redactada por la IA o editada), REVISIÓN, RADICACIÓN Y DESCARTE
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION gestion_documental.fn_guardar_version_escrito(
    p_id_escrito BIGINT, p_version_base INT, p_contenido TEXT, p_origen TEXT,
    p_notas TEXT DEFAULT NULL, p_instrucciones TEXT DEFAULT NULL, p_modelo TEXT DEFAULT NULL)
RETURNS INT AS $$
DECLARE v_e gestion_documental.escrito; v_n INT;
BEGIN
    SELECT * INTO v_e FROM gestion_documental.escrito WHERE id_escrito = p_id_escrito FOR UPDATE;
    IF v_e.id_escrito IS NULL THEN RAISE EXCEPTION 'El escrito no existe.'; END IF;
    IF NOT (seguridad.fn_ambito_nacional() OR v_e.id_estamento = ANY(seguridad.fn_ambito_estamentos())) THEN
        RAISE EXCEPTION 'Fuera de su ámbito territorial.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF v_e.estado IN ('RADICADO', 'DESCARTADO') THEN RAISE EXCEPTION 'El escrito está %: ya no se modifica.', lower(v_e.estado); END IF;
    IF p_version_base IS DISTINCT FROM v_e.version_actual THEN
        RAISE EXCEPTION 'Otra persona guardó una versión nueva (versión %) mientras usted trabajaba sobre la %. Recargue y vuelva a aplicar sus cambios.',
            v_e.version_actual, p_version_base USING ERRCODE = 'serialization_failure';
    END IF;
    IF NULLIF(trim(p_contenido), '') IS NULL THEN RAISE EXCEPTION 'El texto del escrito está vacío.'; END IF;
    IF p_contenido = v_e.contenido THEN RAISE EXCEPTION 'No hay cambios en el texto.'; END IF;
    v_n := v_e.version_actual + 1;
    INSERT INTO gestion_documental.escrito_version (id_escrito, numero, origen, contenido, notas_revision, instrucciones, modelo_ia, id_usuario)
    VALUES (p_id_escrito, v_n, p_origen, p_contenido, p_notas, p_instrucciones, p_modelo, seguridad.fn_id_usuario_actual());
    PERFORM set_config('escritos.operacion', 'version', true);
    UPDATE gestion_documental.escrito
       SET contenido = p_contenido, version_actual = v_n, estado = 'EN_REVISION', generando = FALSE, error_generacion = NULL,
           notas_revision = CASE WHEN p_origen = 'IA' THEN p_notas ELSE notas_revision END
     WHERE id_escrito = p_id_escrito;
    PERFORM set_config('escritos.operacion', '', true);
    RETURN v_n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gestion_documental.fn_marcar_generacion(p_id_escrito BIGINT, p_generando BOOLEAN, p_error TEXT DEFAULT NULL)
RETURNS VOID AS $$
DECLARE v_e gestion_documental.escrito;
BEGIN
    SELECT * INTO v_e FROM gestion_documental.escrito WHERE id_escrito = p_id_escrito FOR UPDATE;
    IF NOT (seguridad.fn_ambito_nacional() OR v_e.id_estamento = ANY(seguridad.fn_ambito_estamentos())) THEN
        RAISE EXCEPTION 'Fuera de su ámbito territorial.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF p_generando AND v_e.generando THEN RAISE EXCEPTION 'La IA ya está redactando este escrito; espere a que termine.'; END IF;
    IF v_e.estado IN ('RADICADO', 'DESCARTADO') THEN RAISE EXCEPTION 'El escrito está %: ya no se modifica.', lower(v_e.estado); END IF;
    PERFORM set_config('escritos.operacion', 'generar', true);
    UPDATE gestion_documental.escrito SET generando = p_generando, error_generacion = p_error WHERE id_escrito = p_id_escrito;
    PERFORM set_config('escritos.operacion', '', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gestion_documental.fn_revisar_escrito(p_id_escrito BIGINT, p_numero_version INT, p_decision TEXT, p_comentario TEXT)
RETURNS TEXT AS $$
DECLARE v_e gestion_documental.escrito; v_r RECORD; v_u seguridad.usuario; v_estado TEXT;
BEGIN
    SELECT * INTO v_e FROM gestion_documental.escrito WHERE id_escrito = p_id_escrito FOR UPDATE;
    IF v_e.id_escrito IS NULL OR NOT (seguridad.fn_ambito_nacional() OR v_e.id_estamento = ANY(seguridad.fn_ambito_estamentos())) THEN
        RAISE EXCEPTION 'El escrito no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v_e.estado IN ('RADICADO', 'DESCARTADO', 'BORRADOR') THEN
        RAISE EXCEPTION 'El escrito % no está en revisión.', CASE v_e.estado WHEN 'BORRADOR' THEN 'aún no tiene texto y' ELSE 'está ' || lower(v_e.estado) || ' y' END;
    END IF;
    IF p_numero_version IS DISTINCT FROM v_e.version_actual THEN
        RAISE EXCEPTION 'Usted revisó la versión %, pero ya existe la versión %. Revise la versión vigente.', p_numero_version, v_e.version_actual
            USING ERRCODE = 'serialization_failure';
    END IF;
    SELECT * INTO v_r FROM gestion_documental.fn_rol_revision(p_id_escrito);
    SELECT * INTO v_u FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual();
    IF p_decision = 'APRUEBA' AND v_r.rol = 'COMENTARIO' THEN
        RAISE EXCEPTION 'Aprueban el abogado, el Presidente y el Secretario General de la junta. Usted puede dejar comentarios.';
    END IF;
    IF p_decision NOT IN ('APRUEBA', 'CAMBIOS', 'COMENTA') THEN RAISE EXCEPTION 'Decisión no válida.'; END IF;
    IF p_decision = 'APRUEBA' AND EXISTS (SELECT 1 FROM gestion_documental.escrito_revision
            WHERE id_escrito = p_id_escrito AND numero_version = v_e.version_actual AND rol = v_r.rol AND decision = 'APRUEBA') THEN
        RAISE EXCEPTION 'La aprobación de % para esta versión ya está registrada.', lower(v_r.rol);
    END IF;
    INSERT INTO gestion_documental.escrito_revision (id_escrito, numero_version, rol, decision, comentario, id_usuario, nombre_usuario, id_persona, cargo)
    VALUES (p_id_escrito, v_e.version_actual, CASE WHEN p_decision = 'COMENTA' THEN 'COMENTARIO' ELSE v_r.rol END, p_decision,
            NULLIF(trim(p_comentario), ''), v_u.id_usuario, v_u.nombre_usuario, v_u.id_persona, v_r.cargo);
    v_estado := gestion_documental.fn_estado_revision(p_id_escrito);
    PERFORM set_config('escritos.operacion', 'revisar', true);
    UPDATE gestion_documental.escrito SET estado = v_estado WHERE id_escrito = p_id_escrito;
    PERFORM set_config('escritos.operacion', '', true);
    RETURN v_estado;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gestion_documental.fn_radicar_escrito(p_id_escrito BIGINT)
RETURNS BIGINT AS $$
DECLARE v_e gestion_documental.escrito; v_t gestion_documental.tipo_escrito; v_id BIGINT; v_mesa RECORD;
BEGIN
    SELECT * INTO v_e FROM gestion_documental.escrito WHERE id_escrito = p_id_escrito FOR UPDATE;
    IF v_e.id_escrito IS NULL OR NOT (seguridad.fn_ambito_nacional() OR v_e.id_estamento = ANY(seguridad.fn_ambito_estamentos())) THEN
        RAISE EXCEPTION 'El escrito no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v_e.estado <> 'APROBADO' OR gestion_documental.fn_estado_revision(p_id_escrito) <> 'APROBADO' THEN
        RAISE EXCEPTION 'Solo se radica un escrito aprobado por el abogado, la Presidencia y la Secretaría General sobre la versión vigente.';
    END IF;
    SELECT * INTO v_mesa FROM gestion_documental.fn_cargo_mesa(v_e.id_estamento);
    IF v_mesa.rol IS NULL THEN
        RAISE EXCEPTION 'Radican el Presidente o el Secretario General de la junta.';
    END IF;
    SELECT * INTO v_t FROM gestion_documental.tipo_escrito WHERE codigo = v_e.codigo_tipo;
    INSERT INTO gestion_documental.documento (flujo, id_estamento, id_tipo_documento, asunto, descripcion_resumen, id_persona_remitente,
                                              destinatario_persona, destinatario_institucion, estado_tramite)
    SELECT 'EMITIDO', v_e.id_estamento, t.id_tipo_documento, left(v_e.titulo, 250),
           v_t.nombre || ' — versión ' || v_e.version_actual || ' aprobada por el abogado, la Presidencia y la Secretaría General.',
           v_mesa.id_persona, v_e.destinatario_persona, v_e.destinatario_institucion, 'RADICADO'
      FROM gestion_documental.tipo_documento t WHERE t.sigla_tipo = v_t.sigla_tipo_documento
    RETURNING id_documento INTO v_id;
    PERFORM set_config('escritos.operacion', 'radicar', true);
    UPDATE gestion_documental.escrito SET estado = 'RADICADO', id_documento = v_id WHERE id_escrito = p_id_escrito;
    PERFORM set_config('escritos.operacion', '', true);
    RETURN v_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gestion_documental.fn_descartar_escrito(p_id_escrito BIGINT, p_motivo TEXT)
RETURNS VOID AS $$
DECLARE v_e gestion_documental.escrito;
BEGIN
    SELECT * INTO v_e FROM gestion_documental.escrito WHERE id_escrito = p_id_escrito FOR UPDATE;
    IF v_e.id_escrito IS NULL OR NOT (seguridad.fn_ambito_nacional() OR v_e.id_estamento = ANY(seguridad.fn_ambito_estamentos())) THEN
        RAISE EXCEPTION 'El escrito no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v_e.estado IN ('RADICADO', 'DESCARTADO') THEN RAISE EXCEPTION 'El escrito ya está %.', lower(v_e.estado); END IF;
    IF NULLIF(trim(p_motivo), '') IS NULL THEN RAISE EXCEPTION 'Indique el motivo para descartar el escrito.'; END IF;
    PERFORM set_config('escritos.operacion', 'descartar', true);
    UPDATE gestion_documental.escrito SET estado = 'DESCARTADO', motivo_descarte = trim(p_motivo), generando = FALSE WHERE id_escrito = p_id_escrito;
    PERFORM set_config('escritos.operacion', '', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Texto extraído o transcrito de una fuente de archivo (lo registra el proceso de extracción)
CREATE OR REPLACE FUNCTION gestion_documental.fn_registrar_extraccion(p_id_fuente BIGINT, p_estado TEXT, p_texto TEXT,
                                                                     p_error TEXT DEFAULT NULL, p_duracion INT DEFAULT NULL)
RETURNS VOID AS $$
BEGIN
    PERFORM set_config('escritos.operacion', 'extraer', true);
    UPDATE gestion_documental.escrito_fuente
       SET estado = p_estado, texto = p_texto, detalle_error = p_error, duracion_segundos = COALESCE(p_duracion, duracion_segundos)
     WHERE id_fuente = p_id_fuente;
    PERFORM set_config('escritos.operacion', '', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 4. VISTA DE CONTROL
-- ----------------------------------------------------------------------------
DROP VIEW IF EXISTS gestion_documental.v_auditoria_escritos;
CREATE VIEW gestion_documental.v_auditoria_escritos WITH (security_invoker = true) AS
WITH a AS (
    SELECT e.id_escrito,
           bool_or(r.rol = 'ABOGADO' AND r.decision = 'APRUEBA') AS abogado,
           bool_or(r.rol = 'PRESIDENCIA' AND r.decision = 'APRUEBA') AS presidencia,
           bool_or(r.rol = 'SECRETARIA' AND r.decision = 'APRUEBA') AS secretaria,
           count(r.*) FILTER (WHERE r.decision IN ('CAMBIOS', 'COMENTA')) AS comentarios,
           max(r.fecha) AS ultima_revision
      FROM gestion_documental.escrito e
      LEFT JOIN gestion_documental.escrito_revision r ON r.id_escrito = e.id_escrito AND r.numero_version = e.version_actual
     GROUP BY e.id_escrito
)
SELECT e.id_escrito, j.nombre_estamento AS junta, t.nombre AS tipo, e.titulo, e.estado, e.version_actual AS version_texto,
       COALESCE(a.abogado, FALSE) AS aprobo_abogado, COALESCE(a.presidencia, FALSE) AS aprobo_presidencia,
       COALESCE(a.secretaria, FALSE) AS aprobo_secretaria, a.comentarios,
       (SELECT max(v.fecha) FROM gestion_documental.escrito_version v WHERE v.id_escrito = e.id_escrito) AS ultima_version,
       d.radicado_alfanumerico AS radicado, e.fecha_creacion::DATE AS creado,
       CASE
           WHEN e.estado = 'RADICADO' THEN 'RADICADO'
           WHEN e.estado = 'DESCARTADO' THEN 'DESCARTADO: ' || COALESCE(e.motivo_descarte, '')
           WHEN e.error_generacion IS NOT NULL THEN 'ALERTA ALTA: FALLÓ LA REDACCIÓN CON IA — ' || left(e.error_generacion, 120)
           WHEN e.estado = 'APROBADO' THEN 'ALERTA MEDIA: APROBADO, PENDIENTE DE RADICAR'
           WHEN e.estado = 'CAMBIOS_SOLICITADOS' THEN 'ALERTA MEDIA: CAMBIOS SOLICITADOS POR UN REVISOR'
           WHEN e.estado = 'EN_REVISION' AND now() - (SELECT max(v.fecha) FROM gestion_documental.escrito_version v WHERE v.id_escrito = e.id_escrito) > INTERVAL '3 days'
               THEN 'ALERTA MEDIA: EN REVISIÓN HACE MÁS DE 3 DÍAS (FALTA: '
                    || concat_ws(', ', CASE WHEN NOT COALESCE(a.abogado, FALSE) THEN 'ABOGADO' END,
                                       CASE WHEN NOT COALESCE(a.presidencia, FALSE) THEN 'PRESIDENCIA' END,
                                       CASE WHEN NOT COALESCE(a.secretaria, FALSE) THEN 'SECRETARÍA' END) || ')'
           WHEN e.estado = 'EN_REVISION' THEN 'EN REVISIÓN'
           ELSE 'BORRADOR (SIN TEXTO)'
       END AS diagnostico
  FROM gestion_documental.escrito e
  JOIN gobernanza.estamento j ON j.id_estamento = e.id_estamento
  JOIN gestion_documental.tipo_escrito t ON t.codigo = e.codigo_tipo
  LEFT JOIN a ON a.id_escrito = e.id_escrito
  LEFT JOIN gestion_documental.documento d ON d.id_documento = e.id_documento;

-- ----------------------------------------------------------------------------
-- 5. SEGURIDAD POR FILAS
-- ----------------------------------------------------------------------------
SELECT seguridad.fn_aplicar_politicas('gestion_documental.tipo_escrito', 'true', ':N');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.escrito', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.escrito_fuente',
    'EXISTS (SELECT 1 FROM gestion_documental.escrito e WHERE e.id_escrito = escrito_fuente.id_escrito)',
    'EXISTS (SELECT 1 FROM gestion_documental.escrito e WHERE e.id_escrito = escrito_fuente.id_escrito)');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.escrito_version',
    'EXISTS (SELECT 1 FROM gestion_documental.escrito e WHERE e.id_escrito = escrito_version.id_escrito)', 'false');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.escrito_revision',
    'EXISTS (SELECT 1 FROM gestion_documental.escrito e WHERE e.id_escrito = escrito_revision.id_escrito)', 'false');

-- ----------------------------------------------------------------------------
-- 6. CORREO DE ESCRITOS PENDIENTES DE REVISIÓN
-- ----------------------------------------------------------------------------
INSERT INTO notificaciones.tipo_notificacion (codigo, nombre, descripcion) VALUES
    ('REVISION_ESCRITOS', 'Escritos jurídicos por revisar',
     'Cuando hay una versión nueva de un escrito, a quienes deben aprobarla (abogados del ámbito, Presidente y Secretario General de la junta). '
     'Recordatorio cada 3 días mientras falte su aprobación.')
ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, descripcion = EXCLUDED.descripcion;
