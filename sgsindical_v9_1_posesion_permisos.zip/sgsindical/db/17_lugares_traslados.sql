-- ============================================================================
-- SGSINDICAL v9.1 · 17_lugares_traslados.sql
-- Lugares oficiales, traslados entre juntas y grupo Palmira.
--
--  1. Listas oficiales: países (ISO 3166-1, 249, en español, Colombia primero), departamentos
--     (DIVIPOLA del DANE: 32 y Bogotá, D.C.) y municipios (DIVIPOLA, se cargan del archivo oficial
--     del DANE: el script 17b trae la lista oficial y la acción «Cargar archivo DIVIPOLA» la actualiza). Nada se
--     borra: un municipio que desaparezca queda inactivo.
--  2. Persona, empresa, sede y junta guardan el código del país, del departamento y del municipio.
--     El texto anterior se conserva y se llena solo a partir del código. Los datos que ya existían
--     se pasan a código cuando el nombre se reconoce sin ambigüedad; los demás quedan en la vista
--     «Lugares por corregir». El municipio debe ser del departamento elegido y, fuera de Colombia,
--     no hay departamento ni municipio.
--  3. La regla de pertenencia compara códigos de municipio (ya no nombres escritos a mano).
--  4. Traslado entre subdirectivas o comités: lo deciden las dos juntas, cada una con su acta. Una lo
--     propone y la otra lo acepta o lo rechaza. Si el destino no corresponde al municipio de trabajo
--     ni al de la sede principal, es una EXCEPCIÓN: se admite con las dos actas y queda marcada.
--     Fuera de esta acción (y de la de dispersos) la subdirectiva o comité de un afiliado no se cambia.
--  5. Palmira, sede nacional: no puede tener subdirectiva ni comité. Quien trabaja allí pertenece a la
--     Junta Directiva Nacional, que distingue dos grupos que el sistema calcula solo: «Palmira (sede
--     nacional)» y «Dispersos». Su aporte es 100 % de la Nacional y los gestiona cualquier directivo nacional.
-- No modifica los scripts anteriores. Se puede ejecutar más de una vez.
-- ============================================================================
SET client_min_messages = warning;

-- ----------------------------------------------------------------------------
-- 1. LISTAS OFICIALES
-- ----------------------------------------------------------------------------
-- Clave para comparar nombres de lugares: sin tildes, sin signos, sin «D.C.» ni «Santafé de»
CREATE OR REPLACE FUNCTION gobernanza.fn_clave_lugar(p TEXT)
RETURNS TEXT AS $$
    SELECT NULLIF(regexp_replace(regexp_replace(regexp_replace(trim(regexp_replace(regexp_replace(
               upper(translate(COALESCE(p, ''), 'áéíóúüàèìòùÁÉÍÓÚÜÀÈÌÒÙ', 'aeiouuaeiouAEIOUUAEIOU')),
               '[^A-ZÑ0-9 ]', ' ', 'g'), '\s+', ' ', 'g')),
               ' D C$', ''), '^SANTA ?FE DE ', ''), '^DISTRITO CAPITAL( DE)? ', ''), '');
$$ LANGUAGE sql IMMUTABLE;

CREATE TABLE IF NOT EXISTS gobernanza.pais (
    codigo CHAR(2) PRIMARY KEY CHECK (codigo ~ '^[A-Z]{2}$'),
    codigo_alfa3 CHAR(3) NOT NULL UNIQUE,
    codigo_numerico CHAR(3) NOT NULL,
    nombre VARCHAR(80) NOT NULL,
    orden INT NOT NULL DEFAULT 1,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gobernanza.pais IS 'Países según la norma ISO 3166-1, con su nombre en español. Colombia va primero en las listas.';

CREATE TABLE IF NOT EXISTS gobernanza.departamento (
    codigo CHAR(2) PRIMARY KEY CHECK (codigo ~ '^[0-9]{2}$'),
    nombre VARCHAR(80) NOT NULL,
    pais_codigo CHAR(2) NOT NULL DEFAULT 'CO' REFERENCES gobernanza.pais(codigo) ON DELETE RESTRICT,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gobernanza.departamento IS 'Departamentos de Colombia y Bogotá, D.C., con su código DIVIPOLA del DANE.';
CREATE INDEX IF NOT EXISTS ix_departamento_pais ON gobernanza.departamento (pais_codigo);

CREATE TABLE IF NOT EXISTS gobernanza.municipio (
    codigo CHAR(5) PRIMARY KEY CHECK (codigo ~ '^[0-9]{5}$'),
    departamento_codigo CHAR(2) NOT NULL REFERENCES gobernanza.departamento(codigo) ON DELETE RESTRICT,
    nombre VARCHAR(80) NOT NULL,
    tipo VARCHAR(30) NOT NULL DEFAULT 'Municipio',
    clave TEXT GENERATED ALWAYS AS (gobernanza.fn_clave_lugar(nombre)) STORED,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    fecha_carga TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_municipio_de_su_departamento CHECK (left(codigo, 2) = departamento_codigo)
);
COMMENT ON TABLE gobernanza.municipio IS
    'Municipios de Colombia con su código DIVIPOLA (5 dígitos: 2 del departamento y 3 del municipio). Se cargan del archivo oficial del DANE.';
ALTER TABLE gobernanza.municipio ADD COLUMN IF NOT EXISTS tipo VARCHAR(30) NOT NULL DEFAULT 'Municipio';
COMMENT ON COLUMN gobernanza.municipio.tipo IS 'Municipio, Isla o Área no municipalizada, según el DANE.';
CREATE INDEX IF NOT EXISTS ix_municipio_departamento ON gobernanza.municipio (departamento_codigo);
CREATE INDEX IF NOT EXISTS ix_municipio_clave ON gobernanza.municipio (clave);

-- Las listas solo cambian con la carga oficial (o al instalar)
CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_lista_lugares()
RETURNS TRIGGER AS $$
BEGIN
    IF seguridad.fn_ejecuta_sistema() OR COALESCE(seguridad.fn_operacion('divipola.operacion'), '') = 'cargar' THEN
        RETURN COALESCE(NEW, OLD);
    END IF;
    RAISE EXCEPTION 'Las listas de países, departamentos y municipios son oficiales: se actualizan con la carga del archivo DIVIPOLA del DANE.';
END;
$$ LANGUAGE plpgsql;
DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['gobernanza.pais', 'gobernanza.departamento', 'gobernanza.municipio'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_proteger_lista ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_proteger_lista BEFORE INSERT OR UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_proteger_lista_lugares()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_no_borrar ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_no_borrar BEFORE DELETE ON %s FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_control_version ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_control_version BEFORE UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version()', t);
    END LOOP;
END $$;

INSERT INTO gobernanza.pais (codigo, codigo_alfa3, codigo_numerico, nombre, orden) VALUES
('AD', 'AND', '020', 'Andorra', 1),
('AE', 'ARE', '784', 'Emiratos Árabes Unidos', 1),
('AF', 'AFG', '004', 'Afganistán', 1),
('AG', 'ATG', '028', 'Antigua y Barbuda', 1),
('AI', 'AIA', '660', 'Anguila', 1),
('AL', 'ALB', '008', 'Albania', 1),
('AM', 'ARM', '051', 'Armenia', 1),
('AO', 'AGO', '024', 'Angola', 1),
('AQ', 'ATA', '010', 'Antártida', 1),
('AR', 'ARG', '032', 'Argentina', 1),
('AS', 'ASM', '016', 'Samoa Americana', 1),
('AT', 'AUT', '040', 'Austria', 1),
('AU', 'AUS', '036', 'Australia', 1),
('AW', 'ABW', '533', 'Aruba', 1),
('AX', 'ALA', '248', 'Islas Aland', 1),
('AZ', 'AZE', '031', 'Azerbaiyán', 1),
('BA', 'BIH', '070', 'Bosnia y Herzegovina', 1),
('BB', 'BRB', '052', 'Barbados', 1),
('BD', 'BGD', '050', 'Bangladés', 1),
('BE', 'BEL', '056', 'Bélgica', 1),
('BF', 'BFA', '854', 'Burkina Faso', 1),
('BG', 'BGR', '100', 'Bulgaria', 1),
('BH', 'BHR', '048', 'Baréin', 1),
('BI', 'BDI', '108', 'Burundi', 1),
('BJ', 'BEN', '204', 'Benín', 1),
('BL', 'BLM', '652', 'San Bartolomé', 1),
('BM', 'BMU', '060', 'Bermudas', 1),
('BN', 'BRN', '096', 'Brunéi', 1),
('BO', 'BOL', '068', 'Bolivia', 1),
('BQ', 'BES', '535', 'Caribe neerlandés', 1),
('BR', 'BRA', '076', 'Brasil', 1),
('BS', 'BHS', '044', 'Bahamas', 1),
('BT', 'BTN', '064', 'Bután', 1),
('BV', 'BVT', '074', 'Isla Bouvet', 1),
('BW', 'BWA', '072', 'Botsuana', 1),
('BY', 'BLR', '112', 'Bielorrusia', 1),
('BZ', 'BLZ', '084', 'Belice', 1),
('CA', 'CAN', '124', 'Canadá', 1),
('CC', 'CCK', '166', 'Islas Cocos', 1),
('CD', 'COD', '180', 'República Democrática del Congo', 1),
('CF', 'CAF', '140', 'República Centroafricana', 1),
('CG', 'COG', '178', 'Congo', 1),
('CH', 'CHE', '756', 'Suiza', 1),
('CI', 'CIV', '384', 'Côte d’Ivoire', 1),
('CK', 'COK', '184', 'Islas Cook', 1),
('CL', 'CHL', '152', 'Chile', 1),
('CM', 'CMR', '120', 'Camerún', 1),
('CN', 'CHN', '156', 'China', 1),
('CO', 'COL', '170', 'Colombia', 0),
('CR', 'CRI', '188', 'Costa Rica', 1),
('CU', 'CUB', '192', 'Cuba', 1),
('CV', 'CPV', '132', 'Cabo Verde', 1),
('CW', 'CUW', '531', 'Curazao', 1),
('CX', 'CXR', '162', 'Isla de Navidad', 1),
('CY', 'CYP', '196', 'Chipre', 1),
('CZ', 'CZE', '203', 'Chequia', 1),
('DE', 'DEU', '276', 'Alemania', 1),
('DJ', 'DJI', '262', 'Yibuti', 1),
('DK', 'DNK', '208', 'Dinamarca', 1),
('DM', 'DMA', '212', 'Dominica', 1),
('DO', 'DOM', '214', 'República Dominicana', 1),
('DZ', 'DZA', '012', 'Argelia', 1),
('EC', 'ECU', '218', 'Ecuador', 1),
('EE', 'EST', '233', 'Estonia', 1),
('EG', 'EGY', '818', 'Egipto', 1),
('EH', 'ESH', '732', 'Sáhara Occidental', 1),
('ER', 'ERI', '232', 'Eritrea', 1),
('ES', 'ESP', '724', 'España', 1),
('ET', 'ETH', '231', 'Etiopía', 1),
('FI', 'FIN', '246', 'Finlandia', 1),
('FJ', 'FJI', '242', 'Fiyi', 1),
('FK', 'FLK', '238', 'Islas Malvinas', 1),
('FM', 'FSM', '583', 'Micronesia', 1),
('FO', 'FRO', '234', 'Islas Feroe', 1),
('FR', 'FRA', '250', 'Francia', 1),
('GA', 'GAB', '266', 'Gabón', 1),
('GB', 'GBR', '826', 'Reino Unido', 1),
('GD', 'GRD', '308', 'Granada', 1),
('GE', 'GEO', '268', 'Georgia', 1),
('GF', 'GUF', '254', 'Guayana Francesa', 1),
('GG', 'GGY', '831', 'Guernesey', 1),
('GH', 'GHA', '288', 'Ghana', 1),
('GI', 'GIB', '292', 'Gibraltar', 1),
('GL', 'GRL', '304', 'Groenlandia', 1),
('GM', 'GMB', '270', 'Gambia', 1),
('GN', 'GIN', '324', 'Guinea', 1),
('GP', 'GLP', '312', 'Guadalupe', 1),
('GQ', 'GNQ', '226', 'Guinea Ecuatorial', 1),
('GR', 'GRC', '300', 'Grecia', 1),
('GS', 'SGS', '239', 'Islas Georgia del Sur y Sandwich del Sur', 1),
('GT', 'GTM', '320', 'Guatemala', 1),
('GU', 'GUM', '316', 'Guam', 1),
('GW', 'GNB', '624', 'Guinea-Bisáu', 1),
('GY', 'GUY', '328', 'Guyana', 1),
('HK', 'HKG', '344', 'RAE de Hong Kong (China)', 1),
('HM', 'HMD', '334', 'Islas Heard y McDonald', 1),
('HN', 'HND', '340', 'Honduras', 1),
('HR', 'HRV', '191', 'Croacia', 1),
('HT', 'HTI', '332', 'Haití', 1),
('HU', 'HUN', '348', 'Hungría', 1),
('ID', 'IDN', '360', 'Indonesia', 1),
('IE', 'IRL', '372', 'Irlanda', 1),
('IL', 'ISR', '376', 'Israel', 1),
('IM', 'IMN', '833', 'Isla de Man', 1),
('IN', 'IND', '356', 'India', 1),
('IO', 'IOT', '086', 'Territorio Británico del Océano Índico', 1),
('IQ', 'IRQ', '368', 'Irak', 1),
('IR', 'IRN', '364', 'Irán', 1),
('IS', 'ISL', '352', 'Islandia', 1),
('IT', 'ITA', '380', 'Italia', 1),
('JE', 'JEY', '832', 'Jersey', 1),
('JM', 'JAM', '388', 'Jamaica', 1),
('JO', 'JOR', '400', 'Jordania', 1),
('JP', 'JPN', '392', 'Japón', 1),
('KE', 'KEN', '404', 'Kenia', 1),
('KG', 'KGZ', '417', 'Kirguistán', 1),
('KH', 'KHM', '116', 'Camboya', 1),
('KI', 'KIR', '296', 'Kiribati', 1),
('KM', 'COM', '174', 'Comoras', 1),
('KN', 'KNA', '659', 'San Cristóbal y Nieves', 1),
('KP', 'PRK', '408', 'Corea del Norte', 1),
('KR', 'KOR', '410', 'Corea del Sur', 1),
('KW', 'KWT', '414', 'Kuwait', 1),
('KY', 'CYM', '136', 'Islas Caimán', 1),
('KZ', 'KAZ', '398', 'Kazajistán', 1),
('LA', 'LAO', '418', 'Laos', 1),
('LB', 'LBN', '422', 'Líbano', 1),
('LC', 'LCA', '662', 'Santa Lucía', 1),
('LI', 'LIE', '438', 'Liechtenstein', 1),
('LK', 'LKA', '144', 'Sri Lanka', 1),
('LR', 'LBR', '430', 'Liberia', 1),
('LS', 'LSO', '426', 'Lesoto', 1),
('LT', 'LTU', '440', 'Lituania', 1),
('LU', 'LUX', '442', 'Luxemburgo', 1),
('LV', 'LVA', '428', 'Letonia', 1),
('LY', 'LBY', '434', 'Libia', 1),
('MA', 'MAR', '504', 'Marruecos', 1),
('MC', 'MCO', '492', 'Mónaco', 1),
('MD', 'MDA', '498', 'Moldavia', 1),
('ME', 'MNE', '499', 'Montenegro', 1),
('MF', 'MAF', '663', 'San Martín', 1),
('MG', 'MDG', '450', 'Madagascar', 1),
('MH', 'MHL', '584', 'Islas Marshall', 1),
('MK', 'MKD', '807', 'Macedonia del Norte', 1),
('ML', 'MLI', '466', 'Mali', 1),
('MM', 'MMR', '104', 'Myanmar (Birmania)', 1),
('MN', 'MNG', '496', 'Mongolia', 1),
('MO', 'MAC', '446', 'RAE de Macao (China)', 1),
('MP', 'MNP', '580', 'Islas Marianas del Norte', 1),
('MQ', 'MTQ', '474', 'Martinica', 1),
('MR', 'MRT', '478', 'Mauritania', 1),
('MS', 'MSR', '500', 'Montserrat', 1),
('MT', 'MLT', '470', 'Malta', 1),
('MU', 'MUS', '480', 'Mauricio', 1),
('MV', 'MDV', '462', 'Maldivas', 1),
('MW', 'MWI', '454', 'Malaui', 1),
('MX', 'MEX', '484', 'México', 1),
('MY', 'MYS', '458', 'Malasia', 1),
('MZ', 'MOZ', '508', 'Mozambique', 1),
('NA', 'NAM', '516', 'Namibia', 1),
('NC', 'NCL', '540', 'Nueva Caledonia', 1),
('NE', 'NER', '562', 'Níger', 1),
('NF', 'NFK', '574', 'Isla Norfolk', 1),
('NG', 'NGA', '566', 'Nigeria', 1),
('NI', 'NIC', '558', 'Nicaragua', 1),
('NL', 'NLD', '528', 'Países Bajos', 1),
('NO', 'NOR', '578', 'Noruega', 1),
('NP', 'NPL', '524', 'Nepal', 1),
('NR', 'NRU', '520', 'Nauru', 1),
('NU', 'NIU', '570', 'Niue', 1),
('NZ', 'NZL', '554', 'Nueva Zelanda', 1),
('OM', 'OMN', '512', 'Omán', 1),
('PA', 'PAN', '591', 'Panamá', 1),
('PE', 'PER', '604', 'Perú', 1),
('PF', 'PYF', '258', 'Polinesia Francesa', 1),
('PG', 'PNG', '598', 'Papúa Nueva Guinea', 1),
('PH', 'PHL', '608', 'Filipinas', 1),
('PK', 'PAK', '586', 'Pakistán', 1),
('PL', 'POL', '616', 'Polonia', 1),
('PM', 'SPM', '666', 'San Pedro y Miquelón', 1),
('PN', 'PCN', '612', 'Islas Pitcairn', 1),
('PR', 'PRI', '630', 'Puerto Rico', 1),
('PS', 'PSE', '275', 'Territorios Palestinos', 1),
('PT', 'PRT', '620', 'Portugal', 1),
('PW', 'PLW', '585', 'Palaos', 1),
('PY', 'PRY', '600', 'Paraguay', 1),
('QA', 'QAT', '634', 'Catar', 1),
('RE', 'REU', '638', 'Reunión', 1),
('RO', 'ROU', '642', 'Rumanía', 1),
('RS', 'SRB', '688', 'Serbia', 1),
('RU', 'RUS', '643', 'Rusia', 1),
('RW', 'RWA', '646', 'Ruanda', 1),
('SA', 'SAU', '682', 'Arabia Saudí', 1),
('SB', 'SLB', '090', 'Islas Salomón', 1),
('SC', 'SYC', '690', 'Seychelles', 1),
('SD', 'SDN', '729', 'Sudán', 1),
('SE', 'SWE', '752', 'Suecia', 1),
('SG', 'SGP', '702', 'Singapur', 1),
('SH', 'SHN', '654', 'Santa Elena', 1),
('SI', 'SVN', '705', 'Eslovenia', 1),
('SJ', 'SJM', '744', 'Svalbard y Jan Mayen', 1),
('SK', 'SVK', '703', 'Eslovaquia', 1),
('SL', 'SLE', '694', 'Sierra Leona', 1),
('SM', 'SMR', '674', 'San Marino', 1),
('SN', 'SEN', '686', 'Senegal', 1),
('SO', 'SOM', '706', 'Somalia', 1),
('SR', 'SUR', '740', 'Surinam', 1),
('SS', 'SSD', '728', 'Sudán del Sur', 1),
('ST', 'STP', '678', 'Santo Tomé y Príncipe', 1),
('SV', 'SLV', '222', 'El Salvador', 1),
('SX', 'SXM', '534', 'Sint Maarten', 1),
('SY', 'SYR', '760', 'Siria', 1),
('SZ', 'SWZ', '748', 'Esuatini', 1),
('TC', 'TCA', '796', 'Islas Turcas y Caicos', 1),
('TD', 'TCD', '148', 'Chad', 1),
('TF', 'ATF', '260', 'Territorios Australes Franceses', 1),
('TG', 'TGO', '768', 'Togo', 1),
('TH', 'THA', '764', 'Tailandia', 1),
('TJ', 'TJK', '762', 'Tayikistán', 1),
('TK', 'TKL', '772', 'Tokelau', 1),
('TL', 'TLS', '626', 'Timor-Leste', 1),
('TM', 'TKM', '795', 'Turkmenistán', 1),
('TN', 'TUN', '788', 'Túnez', 1),
('TO', 'TON', '776', 'Tonga', 1),
('TR', 'TUR', '792', 'Turquía', 1),
('TT', 'TTO', '780', 'Trinidad y Tobago', 1),
('TV', 'TUV', '798', 'Tuvalu', 1),
('TW', 'TWN', '158', 'Taiwán', 1),
('TZ', 'TZA', '834', 'Tanzania', 1),
('UA', 'UKR', '804', 'Ucrania', 1),
('UG', 'UGA', '800', 'Uganda', 1),
('UM', 'UMI', '581', 'Islas menores alejadas de EE. UU.', 1),
('US', 'USA', '840', 'Estados Unidos', 1),
('UY', 'URY', '858', 'Uruguay', 1),
('UZ', 'UZB', '860', 'Uzbekistán', 1),
('VA', 'VAT', '336', 'Ciudad del Vaticano', 1),
('VC', 'VCT', '670', 'San Vicente y las Granadinas', 1),
('VE', 'VEN', '862', 'Venezuela', 1),
('VG', 'VGB', '092', 'Islas Vírgenes Británicas', 1),
('VI', 'VIR', '850', 'Islas Vírgenes de EE. UU.', 1),
('VN', 'VNM', '704', 'Vietnam', 1),
('VU', 'VUT', '548', 'Vanuatu', 1),
('WF', 'WLF', '876', 'Wallis y Futuna', 1),
('WS', 'WSM', '882', 'Samoa', 1),
('YE', 'YEM', '887', 'Yemen', 1),
('YT', 'MYT', '175', 'Mayotte', 1),
('ZA', 'ZAF', '710', 'Sudáfrica', 1),
('ZM', 'ZMB', '894', 'Zambia', 1),
('ZW', 'ZWE', '716', 'Zimbabue', 1)
ON CONFLICT (codigo) DO NOTHING;

INSERT INTO gobernanza.departamento (codigo, nombre) VALUES
    ('05', 'ANTIOQUIA'), ('08', 'ATLÁNTICO'), ('11', 'BOGOTÁ, D.C.'), ('13', 'BOLÍVAR'), ('15', 'BOYACÁ'), ('17', 'CALDAS'),
    ('18', 'CAQUETÁ'), ('19', 'CAUCA'), ('20', 'CESAR'), ('23', 'CÓRDOBA'), ('25', 'CUNDINAMARCA'), ('27', 'CHOCÓ'),
    ('41', 'HUILA'), ('44', 'LA GUAJIRA'), ('47', 'MAGDALENA'), ('50', 'META'), ('52', 'NARIÑO'), ('54', 'NORTE DE SANTANDER'),
    ('63', 'QUINDÍO'), ('66', 'RISARALDA'), ('68', 'SANTANDER'), ('70', 'SUCRE'), ('73', 'TOLIMA'), ('76', 'VALLE DEL CAUCA'),
    ('81', 'ARAUCA'), ('85', 'CASANARE'), ('86', 'PUTUMAYO'), ('88', 'ARCHIPIÉLAGO DE SAN ANDRÉS, PROVIDENCIA Y SANTA CATALINA'),
    ('91', 'AMAZONAS'), ('94', 'GUAINÍA'), ('95', 'GUAVIARE'), ('97', 'VAUPÉS'), ('99', 'VICHADA')
ON CONFLICT (codigo) DO NOTHING;

-- Municipio de la sede nacional del sindicato (Palmira, Valle del Cauca)
INSERT INTO gobernanza.dato_institucional (clave, nombre, valor, descripcion) VALUES
    ('MUNICIPIO_SEDE_NACIONAL', 'Municipio de la sede nacional (código DIVIPOLA)', '76520',
     'Allí no puede haber subdirectiva ni comité; quienes trabajan en ese municipio pertenecen a la Junta Directiva Nacional (grupo Palmira).')
ON CONFLICT (clave) DO NOTHING;

CREATE OR REPLACE FUNCTION gobernanza.fn_municipio_sede_nacional()
RETURNS CHAR(5) AS $$
    SELECT valor::CHAR(5) FROM gobernanza.dato_institucional WHERE clave = 'MUNICIPIO_SEDE_NACIONAL';
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Reconocer un departamento o un municipio por su nombre (para los datos que ya existían)
CREATE OR REPLACE FUNCTION gobernanza.fn_resolver_departamento(p_texto TEXT)
RETURNS CHAR(2) AS $$
    WITH k AS (SELECT gobernanza.fn_clave_lugar(p_texto) AS c)
    SELECT COALESCE(
        (SELECT d.codigo FROM gobernanza.departamento d, k WHERE gobernanza.fn_clave_lugar(d.nombre) = k.c),
        (SELECT a.codigo FROM k, (VALUES ('VALLE', '76'), ('BOGOTA', '11'), ('SAN ANDRES', '88'), ('SAN ANDRES Y PROVIDENCIA', '88'),
                                          ('GUAJIRA', '44'), ('NORTE SANTANDER', '54'), ('ATLANTICO', '08')) a(alias, codigo)
          WHERE a.alias = k.c),
        (SELECT d.codigo FROM gobernanza.departamento d, k WHERE p_texto ~ '^[0-9]{2}$' AND d.codigo = p_texto));
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE FUNCTION gobernanza.fn_resolver_municipio(p_texto TEXT, p_departamento CHAR(2))
RETURNS CHAR(5) AS $$
    WITH k AS (SELECT gobernanza.fn_clave_lugar(p_texto) AS c),
    en_dep AS (SELECT m.codigo FROM gobernanza.municipio m, k WHERE m.clave = k.c AND m.departamento_codigo = p_departamento),
    pais AS (SELECT m.codigo FROM gobernanza.municipio m, k WHERE m.clave = k.c)
    SELECT CASE
        WHEN p_texto ~ '^[0-9]{5}$' AND EXISTS (SELECT 1 FROM gobernanza.municipio WHERE codigo = p_texto) THEN p_texto::CHAR(5)
        WHEN (SELECT count(*) FROM en_dep) = 1 THEN (SELECT codigo FROM en_dep)
        WHEN (SELECT count(*) FROM pais) = 1 THEN (SELECT codigo FROM pais)   -- nombre único en el país (p. ej. Bogotá)
        -- nombre corto de un nombre oficial largo (p. ej. «Buga» → «Guadalajara de Buga»), si no hay duda
        WHEN (SELECT count(*) FROM gobernanza.municipio m, k WHERE m.departamento_codigo = p_departamento AND m.clave LIKE '% ' || k.c) = 1
            THEN (SELECT m.codigo FROM gobernanza.municipio m, k WHERE m.departamento_codigo = p_departamento AND m.clave LIKE '% ' || k.c)
        END;
$$ LANGUAGE sql STABLE;

-- ----------------------------------------------------------------------------
-- 2. CÓDIGOS EN PERSONA, EMPRESA, SEDE Y JUNTA
-- ----------------------------------------------------------------------------
ALTER TABLE gobernanza.persona ADD COLUMN IF NOT EXISTS pais_codigo CHAR(2) REFERENCES gobernanza.pais(codigo) ON DELETE RESTRICT;
DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['gobernanza.persona', 'gobernanza.empresa', 'gobernanza.sede_empresa', 'gobernanza.estamento'] LOOP
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS departamento_codigo CHAR(2) REFERENCES gobernanza.departamento(codigo) ON DELETE RESTRICT', t);
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS municipio_codigo CHAR(5) REFERENCES gobernanza.municipio(codigo) ON DELETE RESTRICT', t);
        EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON %s (departamento_codigo)', 'ix_' || split_part(t, '.', 2) || '_dep_cod', t);
        EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON %s (municipio_codigo)', 'ix_' || split_part(t, '.', 2) || '_mun_cod', t);
    END LOOP;
END $$;
CREATE INDEX IF NOT EXISTS ix_persona_pais_cod ON gobernanza.persona (pais_codigo);
COMMENT ON COLUMN gobernanza.persona.municipio_codigo IS 'Municipio de residencia (DIVIPOLA). Vacío si no se conoce o si reside fuera de Colombia.';
COMMENT ON COLUMN gobernanza.sede_empresa.municipio_codigo IS 'Municipio de la sede (DIVIPOLA). Define a qué subdirectiva o comité pueden pertenecer quienes trabajan allí.';

-- Sincroniza código y texto. Argumentos: columna de texto del país ('' si no hay), del departamento y del municipio.
CREATE OR REPLACE FUNCTION gobernanza.fn_sincronizar_lugar()
RETURNS TRIGGER AS $$
DECLARE
    c_pais TEXT := TG_ARGV[0]; c_dep TEXT := TG_ARGV[1]; c_mun TEXT := TG_ARGV[2];
    j JSONB := to_jsonb(NEW); o JSONB := CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE '{}'::jsonb END;
    p_cod TEXT := j->>'pais_codigo'; d_cod TEXT := j->>'departamento_codigo'; m_cod TEXT := j->>'municipio_codigo';
    p_txt TEXT := CASE WHEN c_pais <> '' THEN j->>c_pais END; d_txt TEXT := j->>c_dep; m_txt TEXT := j->>c_mun;
    v_cambio_texto BOOLEAN;
BEGIN
    -- Si cambió el texto (cargas antiguas o importaciones) y no el código, el código se vuelve a buscar
    v_cambio_texto := TG_OP = 'INSERT'
        OR ((j->>c_mun) IS DISTINCT FROM (o->>c_mun) AND m_cod IS NOT DISTINCT FROM (o->>'municipio_codigo'))
        OR ((j->>c_dep) IS DISTINCT FROM (o->>c_dep) AND d_cod IS NOT DISTINCT FROM (o->>'departamento_codigo'));
    IF TG_OP = 'UPDATE' AND v_cambio_texto AND m_cod IS NOT DISTINCT FROM (o->>'municipio_codigo') THEN
        IF (j->>c_mun) IS DISTINCT FROM (o->>c_mun) THEN m_cod := NULL; END IF;
        IF (j->>c_dep) IS DISTINCT FROM (o->>c_dep) THEN d_cod := NULL; END IF;
    END IF;
    -- País
    IF c_pais <> '' AND p_cod IS NULL AND p_txt IS NOT NULL THEN
        SELECT codigo INTO p_cod FROM gobernanza.pais
         WHERE codigo = upper(trim(p_txt)) OR codigo_alfa3 = upper(trim(p_txt)) OR gobernanza.fn_clave_lugar(nombre) = gobernanza.fn_clave_lugar(p_txt)
         ORDER BY orden LIMIT 1;
    END IF;
    -- Departamento y municipio a partir del texto, si no vienen con código
    IF d_cod IS NULL AND d_txt IS NOT NULL THEN d_cod := gobernanza.fn_resolver_departamento(d_txt); END IF;
    IF m_cod IS NULL AND m_txt IS NOT NULL THEN
        m_cod := gobernanza.fn_resolver_municipio(m_txt, d_cod);
        IF m_cod IS NOT NULL AND d_cod IS DISTINCT FROM left(m_cod, 2)
           AND (d_cod IS NULL OR NOT EXISTS (SELECT 1 FROM gobernanza.municipio WHERE clave = gobernanza.fn_clave_lugar(m_txt) AND departamento_codigo = d_cod)) THEN
            d_cod := left(m_cod, 2);          -- p. ej. «Bogotá» anotado en Cundinamarca
        END IF;
    END IF;
    -- Coherencia
    IF m_cod IS NOT NULL THEN
        IF d_cod IS NULL THEN d_cod := left(m_cod, 2); END IF;
        IF left(m_cod, 2) <> d_cod THEN
            RAISE EXCEPTION 'El municipio % no pertenece al departamento %.',
                  (SELECT nombre FROM gobernanza.municipio WHERE codigo = m_cod), (SELECT nombre FROM gobernanza.departamento WHERE codigo = d_cod);
        END IF;
    END IF;
    IF c_pais <> '' THEN
        IF p_cod IS NULL AND d_cod IS NOT NULL THEN p_cod := 'CO'; END IF;
        IF p_cod IS DISTINCT FROM 'CO' AND (d_cod IS NOT NULL OR (j->>'municipio_codigo') IS NOT NULL) AND p_cod IS NOT NULL THEN
            RAISE EXCEPTION 'El departamento y el municipio solo se registran para Colombia.';
        END IF;
    END IF;
    -- Lo que la persona escribe o cambia debe estar en la lista oficial (una vez cargada la DIVIPOLA)
    IF TG_OP = 'INSERT' OR (j->>c_mun) IS DISTINCT FROM (o->>c_mun) OR (j->>c_dep) IS DISTINCT FROM (o->>c_dep)
       OR (j->>'municipio_codigo') IS DISTINCT FROM (o->>'municipio_codigo') OR (j->>'departamento_codigo') IS DISTINCT FROM (o->>'departamento_codigo') THEN
        IF m_cod IS NULL AND m_txt IS NOT NULL AND COALESCE(p_cod, 'CO') = 'CO' AND EXISTS (SELECT 1 FROM gobernanza.municipio) THEN
            RAISE EXCEPTION 'El municipio «%» no se reconoce en la lista oficial DIVIPOLA%: elíjalo de la lista.', m_txt,
                  COALESCE(' de ' || (SELECT nombre FROM gobernanza.departamento WHERE codigo = d_cod), '');
        END IF;
        IF d_cod IS NULL AND d_txt IS NOT NULL AND COALESCE(p_cod, 'CO') = 'CO' THEN
            RAISE EXCEPTION 'El departamento «%» no se reconoce en la lista oficial DIVIPOLA: elíjalo de la lista.', d_txt;
        END IF;
        IF TG_ARGV[3] = 'obligatorio' AND m_cod IS NULL AND EXISTS (SELECT 1 FROM gobernanza.municipio) THEN
            RAISE EXCEPTION 'Elija el municipio de la lista oficial DIVIPOLA.';
        END IF;
    END IF;
    -- El texto se toma de las listas oficiales
    j := j || jsonb_build_object('departamento_codigo', d_cod, 'municipio_codigo', m_cod);
    IF d_cod IS NOT NULL THEN j := j || jsonb_build_object(c_dep, (SELECT nombre FROM gobernanza.departamento WHERE codigo = d_cod)); END IF;
    IF m_cod IS NOT NULL THEN j := j || jsonb_build_object(c_mun, (SELECT nombre FROM gobernanza.municipio WHERE codigo = m_cod)); END IF;
    IF c_pais <> '' THEN
        j := j || jsonb_build_object('pais_codigo', p_cod);
        IF p_cod IS NOT NULL THEN j := j || jsonb_build_object(c_pais, (SELECT nombre FROM gobernanza.pais WHERE codigo = p_cod)); END IF;
    END IF;
    NEW := jsonb_populate_record(NEW, j);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_lugar_codigos ON gobernanza.persona;
CREATE TRIGGER trg_lugar_codigos BEFORE INSERT OR UPDATE ON gobernanza.persona
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_sincronizar_lugar('pais', 'departamento', 'municipio', '');
DROP TRIGGER IF EXISTS trg_lugar_codigos ON gobernanza.empresa;
CREATE TRIGGER trg_lugar_codigos BEFORE INSERT OR UPDATE ON gobernanza.empresa
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_sincronizar_lugar('', 'departamento', 'municipio', 'obligatorio');
DROP TRIGGER IF EXISTS trg_lugar_codigos ON gobernanza.sede_empresa;
CREATE TRIGGER trg_lugar_codigos BEFORE INSERT OR UPDATE ON gobernanza.sede_empresa
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_sincronizar_lugar('', 'departamento_sede', 'municipio_sede', 'obligatorio');
DROP TRIGGER IF EXISTS trg_lugar_codigos ON gobernanza.estamento;
CREATE TRIGGER trg_lugar_codigos BEFORE INSERT OR UPDATE ON gobernanza.estamento
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_sincronizar_lugar('', 'departamento', 'municipio', '');

-- Palmira: la ley no permite subdirectiva ni comité en el municipio de la sede nacional
CREATE OR REPLACE FUNCTION gobernanza.fn_sin_junta_local_en_sede_nacional()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.tipo_estamento IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL') AND NEW.activo
       AND NEW.municipio_codigo = gobernanza.fn_municipio_sede_nacional() THEN
        RAISE EXCEPTION 'En % está la sede nacional del sindicato: allí no puede haber subdirectiva ni comité. Quienes trabajan en ese municipio pertenecen a la Junta Directiva Nacional.',
              (SELECT initcap(nombre) FROM gobernanza.municipio WHERE codigo = NEW.municipio_codigo);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_z_sede_nacional ON gobernanza.estamento;
CREATE TRIGGER trg_z_sede_nacional BEFORE INSERT OR UPDATE ON gobernanza.estamento
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_sin_junta_local_en_sede_nacional();

-- Vuelve a buscar los códigos de los registros que aún tienen solo texto (al instalar y tras cargar la DIVIPOLA)
CREATE OR REPLACE FUNCTION gobernanza.fn_resolver_lugares()
RETURNS INT AS $$
DECLARE n INT := 0; k INT;
BEGIN
    PERFORM seguridad.fn_fijar_operacion('sgs.operacion', 'sistema');
    UPDATE gobernanza.persona SET pais = pais
     WHERE (municipio_codigo IS NULL AND municipio IS NOT NULL) OR (departamento_codigo IS NULL AND departamento IS NOT NULL)
        OR (pais_codigo IS NULL AND (pais IS NOT NULL OR departamento IS NOT NULL));
    GET DIAGNOSTICS k = ROW_COUNT; n := n + k;
    UPDATE gobernanza.empresa SET municipio = municipio
     WHERE (municipio_codigo IS NULL AND municipio IS NOT NULL) OR (departamento_codigo IS NULL AND departamento IS NOT NULL);
    GET DIAGNOSTICS k = ROW_COUNT; n := n + k;
    UPDATE gobernanza.sede_empresa SET municipio_sede = municipio_sede
     WHERE (municipio_codigo IS NULL AND municipio_sede IS NOT NULL) OR (departamento_codigo IS NULL AND departamento_sede IS NOT NULL);
    GET DIAGNOSTICS k = ROW_COUNT; n := n + k;
    UPDATE gobernanza.estamento SET municipio = municipio
     WHERE (municipio_codigo IS NULL AND municipio IS NOT NULL) OR (departamento_codigo IS NULL AND departamento IS NOT NULL);
    GET DIAGNOSTICS k = ROW_COUNT; n := n + k;
    PERFORM seguridad.fn_fijar_operacion('sgs.operacion', '');
    RETURN n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Cargar el archivo oficial DIVIPOLA (lo procesa el servidor: [{dep, dep_nombre, mun, mun_nombre}, ...])
CREATE OR REPLACE FUNCTION gobernanza.fn_cargar_divipola(p_filas JSONB)
RETURNS JSONB AS $$
DECLARE v_total INT; v_nuevos INT; v_inactivos INT := 0; v_resueltos INT;
BEGIN
    IF NOT seguridad.fn_es_admin() THEN
        RAISE EXCEPTION 'La lista oficial de municipios la carga el administrador.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    v_total := jsonb_array_length(COALESCE(p_filas, '[]'::jsonb));
    IF v_total = 0 THEN RAISE EXCEPTION 'El archivo no trae municipios.'; END IF;
    IF EXISTS (SELECT 1 FROM jsonb_array_elements(p_filas) f
                WHERE (f->>'mun') !~ '^[0-9]{5}$' OR left(f->>'mun', 2) <> (f->>'dep')
                   OR NOT EXISTS (SELECT 1 FROM gobernanza.departamento d WHERE d.codigo = f->>'dep')
                   OR length(trim(COALESCE(f->>'mun_nombre', ''))) = 0) THEN
        RAISE EXCEPTION 'El archivo tiene códigos que no son DIVIPOLA (5 dígitos y departamento existente). Revise que sea el archivo del DANE.';
    END IF;
    PERFORM seguridad.fn_fijar_operacion('divipola.operacion', 'cargar');
    SELECT count(*) INTO v_nuevos FROM jsonb_array_elements(p_filas) f
     WHERE NOT EXISTS (SELECT 1 FROM gobernanza.municipio m WHERE m.codigo = f->>'mun');
    INSERT INTO gobernanza.municipio (codigo, departamento_codigo, nombre, tipo)
    SELECT DISTINCT ON (f->>'mun') f->>'mun', f->>'dep', upper(trim(f->>'mun_nombre')), COALESCE(NULLIF(trim(f->>'tipo'), ''), 'Municipio')
      FROM jsonb_array_elements(p_filas) f
    ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, tipo = EXCLUDED.tipo, activo = TRUE, fecha_carga = now()
     WHERE gobernanza.municipio.nombre IS DISTINCT FROM EXCLUDED.nombre OR gobernanza.municipio.tipo IS DISTINCT FROM EXCLUDED.tipo
        OR NOT gobernanza.municipio.activo;
    -- Un archivo completo (más de 1.000 municipios) deja inactivos los que ya no aparecen
    IF v_total > 1000 THEN
        UPDATE gobernanza.municipio m SET activo = FALSE
         WHERE m.activo AND NOT EXISTS (SELECT 1 FROM jsonb_array_elements(p_filas) f WHERE f->>'mun' = m.codigo);
        GET DIAGNOSTICS v_inactivos = ROW_COUNT;
    END IF;
    PERFORM seguridad.fn_fijar_operacion('divipola.operacion', '');
    v_resueltos := gobernanza.fn_resolver_lugares();
    RETURN jsonb_build_object('municipios', (SELECT count(*) FROM gobernanza.municipio WHERE activo), 'nuevos', v_nuevos,
                              'inactivados', v_inactivos, 'registros_revisados', v_resueltos,
                              'por_corregir', (SELECT count(*) FROM gobernanza.v_lugares_por_corregir));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 3. TRASLADOS ENTRE SUBDIRECTIVAS O COMITÉS (dos juntas, dos actas)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.traslado_pertenencia (
    id_traslado BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.afiliado(id_persona) ON DELETE RESTRICT,
    id_estamento_origen BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    id_estamento_destino BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    motivo TEXT NOT NULL,
    excepcion BOOLEAN NOT NULL DEFAULT FALSE,
    estado VARCHAR(10) NOT NULL DEFAULT 'PROPUESTO' CHECK (estado IN ('PROPUESTO', 'APROBADO', 'RECHAZADO', 'ANULADO')),
    id_estamento_propone BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    id_acta_propone BIGINT NOT NULL REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    usuario_propone VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    fecha_propone TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    id_acta_responde BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    usuario_responde VARCHAR(50),
    fecha_responde TIMESTAMP WITH TIME ZONE,
    motivo_respuesta TEXT,
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_traslado_distinto CHECK (id_estamento_origen <> id_estamento_destino),
    CONSTRAINT ck_traslado_propone CHECK (id_estamento_propone IN (id_estamento_origen, id_estamento_destino))
);
COMMENT ON TABLE gobernanza.traslado_pertenencia IS
    'Traslado de un afiliado entre subdirectivas o comités: una junta lo propone con su acta y la otra lo acepta o lo rechaza con la suya. EXCEPCIÓN = el destino no corresponde a su municipio de trabajo ni al de la sede principal.';
CREATE UNIQUE INDEX IF NOT EXISTS ux_traslado_propuesto ON gobernanza.traslado_pertenencia (id_persona) WHERE estado = 'PROPUESTO';
CREATE INDEX IF NOT EXISTS ix_traslado_persona ON gobernanza.traslado_pertenencia (id_persona);
CREATE INDEX IF NOT EXISTS ix_traslado_origen ON gobernanza.traslado_pertenencia (id_estamento_origen);
CREATE INDEX IF NOT EXISTS ix_traslado_destino ON gobernanza.traslado_pertenencia (id_estamento_destino);
CREATE INDEX IF NOT EXISTS ix_traslado_propone ON gobernanza.traslado_pertenencia (id_estamento_propone);
CREATE INDEX IF NOT EXISTS ix_traslado_acta_p ON gobernanza.traslado_pertenencia (id_acta_propone);
CREATE INDEX IF NOT EXISTS ix_traslado_acta_r ON gobernanza.traslado_pertenencia (id_acta_responde);

CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_traslado()
RETURNS TRIGGER AS $$
BEGIN
    IF COALESCE(seguridad.fn_operacion('traslado.operacion'), '') = '' THEN
        RAISE EXCEPTION 'El traslado se registra con sus acciones: proponer, aceptar, rechazar o anular.';
    END IF;
    IF TG_OP = 'UPDATE' AND OLD.estado <> 'PROPUESTO' THEN RAISE EXCEPTION 'Un traslado ya decidido no se modifica.'; END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_proteger_traslado ON gobernanza.traslado_pertenencia;
CREATE TRIGGER trg_proteger_traslado BEFORE INSERT OR UPDATE ON gobernanza.traslado_pertenencia
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_proteger_traslado();
DROP TRIGGER IF EXISTS trg_no_borrar ON gobernanza.traslado_pertenencia;
CREATE TRIGGER trg_no_borrar BEFORE DELETE ON gobernanza.traslado_pertenencia FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado();
DROP TRIGGER IF EXISTS trg_auditoria ON gobernanza.traslado_pertenencia;
CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON gobernanza.traslado_pertenencia
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria();
DROP TRIGGER IF EXISTS trg_control_version ON gobernanza.traslado_pertenencia;
CREATE TRIGGER trg_control_version BEFORE UPDATE ON gobernanza.traslado_pertenencia
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version();

ALTER TABLE gobernanza.historial_pertenencia ADD COLUMN IF NOT EXISTS id_traslado BIGINT
    REFERENCES gobernanza.traslado_pertenencia(id_traslado) ON DELETE RESTRICT;
CREATE INDEX IF NOT EXISTS ix_hist_pert_traslado ON gobernanza.historial_pertenencia (id_traslado);

CREATE OR REPLACE FUNCTION gobernanza.fn_registrar_historial_pertenencia()
RETURNS TRIGGER AS $$
DECLARE v_jdn BIGINT := gobernanza.fn_id_jdn();
BEGIN
    IF TG_OP = 'UPDATE' AND NEW.id_estamento_pertenencia IS NOT DISTINCT FROM OLD.id_estamento_pertenencia THEN RETURN NULL; END IF;
    INSERT INTO gobernanza.historial_pertenencia (id_persona, id_estamento_anterior, id_estamento_nuevo, disperso, id_acta, motivo, id_traslado)
    VALUES (NEW.id_persona, CASE WHEN TG_OP = 'UPDATE' THEN OLD.id_estamento_pertenencia END, NEW.id_estamento_pertenencia,
            NEW.id_estamento_pertenencia = v_jdn,
            NULLIF(COALESCE(seguridad.fn_operacion('pertenencia.acta'), ''), '')::BIGINT,
            COALESCE(NULLIF(COALESCE(seguridad.fn_operacion('pertenencia.motivo'), ''), ''),
                     CASE WHEN TG_OP = 'INSERT' THEN 'Afiliación' WHEN NEW.activo AND NOT OLD.activo THEN 'Reafiliación' ELSE 'Cambio de pertenencia' END),
            NULLIF(COALESCE(seguridad.fn_operacion('pertenencia.traslado'), ''), '')::BIGINT);
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Lugares donde puede pertenecer el afiliado: municipio de su sede de trabajo, municipio de la sede principal
-- y, si el último traslado aprobado fue una excepción, la junta de destino de ese traslado
CREATE OR REPLACE VIEW gobernanza.v_pertenencia_permitida WITH (security_invoker = true) AS
WITH lugares AS (
    SELECT ae.id_persona, 'SEDE DE TRABAJO' AS motivo, s.departamento_sede AS departamento, s.municipio_sede AS municipio,
           s.departamento_codigo AS dep_cod, s.municipio_codigo AS mun_cod
      FROM gobernanza.afiliado_empresa ae JOIN gobernanza.sede_empresa s ON s.id_sede = ae.id_sede
    UNION ALL
    SELECT ae.id_persona, 'SEDE CENTRAL', e.departamento, e.municipio, e.departamento_codigo, e.municipio_codigo
      FROM gobernanza.afiliado_empresa ae JOIN gobernanza.empresa e ON e.id_empresa = ae.id_empresa
),
geografia AS (
    SELECT l.id_persona, est.id_estamento, est.nombre_estamento, est.tipo_estamento, l.motivo, l.municipio
      FROM lugares l
      JOIN gobernanza.estamento est
        ON est.tipo_estamento IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL')
       AND (CASE WHEN est.municipio_codigo IS NOT NULL AND l.mun_cod IS NOT NULL THEN est.municipio_codigo = l.mun_cod
                 WHEN est.municipio IS NULL AND est.departamento_codigo IS NOT NULL AND l.dep_cod IS NOT NULL THEN est.departamento_codigo = l.dep_cod
                 ELSE gobernanza.fn_clave_lugar(est.municipio) = gobernanza.fn_clave_lugar(l.municipio)
                      OR (est.municipio IS NULL AND gobernanza.fn_clave_lugar(est.departamento) = gobernanza.fn_clave_lugar(l.departamento)) END)
),
excepcion AS (
    SELECT DISTINCT ON (t.id_persona) t.id_persona, est.id_estamento, est.nombre_estamento, est.tipo_estamento,
           'EXCEPCIÓN APROBADA POR LAS DOS JUNTAS'::TEXT AS motivo, est.municipio, t.excepcion
      FROM gobernanza.traslado_pertenencia t JOIN gobernanza.estamento est ON est.id_estamento = t.id_estamento_destino
     WHERE t.estado = 'APROBADO'
     ORDER BY t.id_persona, t.fecha_responde DESC
),
todo AS (
    SELECT * FROM geografia
    UNION ALL
    SELECT id_persona, id_estamento, nombre_estamento, tipo_estamento, motivo, municipio FROM excepcion WHERE excepcion
)
SELECT DISTINCT ON (id_persona, id_estamento) id_persona, id_estamento, nombre_estamento, tipo_estamento, motivo, municipio
  FROM todo
 ORDER BY id_persona, id_estamento, (motivo = 'EXCEPCIÓN APROBADA POR LAS DOS JUNTAS'), motivo DESC;

-- Grupo dentro de la Junta Nacional: PALMIRA (trabaja en el municipio de la sede nacional) o DISPERSO.
-- Para una solicitud pendiente dirigida a la Junta Nacional, se usa la empresa y la sede de la solicitud.
CREATE OR REPLACE FUNCTION gobernanza.fn_grupo_nacional(p_id_persona BIGINT)
RETURNS TEXT AS $$
    WITH jdn AS (SELECT gobernanza.fn_id_jdn() AS id),
    afi AS (
        SELECT a.id_estamento_pertenencia AS junta, COALESCE(s.municipio_codigo, e.municipio_codigo) AS mun
          FROM gobernanza.afiliado a
          LEFT JOIN gobernanza.afiliado_empresa ae ON ae.id_persona = a.id_persona
          LEFT JOIN gobernanza.sede_empresa s ON s.id_sede = ae.id_sede
          LEFT JOIN gobernanza.empresa e ON e.id_empresa = ae.id_empresa
         WHERE a.id_persona = p_id_persona AND a.activo),
    sol AS (
        SELECT so.id_estamento AS junta, COALESCE(s.municipio_codigo, e.municipio_codigo) AS mun
          FROM gobernanza.solicitud_afiliacion so
          LEFT JOIN gobernanza.sede_empresa s ON s.id_sede = so.id_sede
          LEFT JOIN gobernanza.empresa e ON e.id_empresa = so.id_empresa
         WHERE so.id_persona = p_id_persona AND so.estado = 'PENDIENTE'),
    x AS (SELECT * FROM sol UNION ALL SELECT * FROM afi LIMIT 1)
    SELECT CASE WHEN x.junta IS DISTINCT FROM (SELECT id FROM jdn) THEN NULL
                WHEN x.mun = gobernanza.fn_municipio_sede_nacional() THEN 'PALMIRA'
                ELSE 'DISPERSO' END
      FROM x;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- La subdirectiva o comité de un afiliado solo cambia con un traslado (dos actas), con la acción de dispersos
-- (Junta Nacional con acta) o al aprobar su afiliación. Reemplaza la versión de 16.
CREATE OR REPLACE FUNCTION gobernanza.fn_validar_cambio_pertenencia()
RETURNS TRIGGER AS $$
DECLARE v_cargo RECORD; v_jdn BIGINT := gobernanza.fn_id_jdn(); v_cambia BOOLEAN;
        v_op TEXT := COALESCE(seguridad.fn_operacion('pertenencia.operacion'), '');
        v_aprobar BOOLEAN := COALESCE(seguridad.fn_operacion('afiliacion.operacion'), '') = 'aprobar';
BEGIN
    IF NEW.id_estamento_pertenencia IS NULL AND (TG_OP = 'INSERT' OR OLD.id_estamento_pertenencia IS NOT NULL) THEN
        RAISE EXCEPTION 'La pertenencia es obligatoria: indique la subdirectiva o comité del afiliado (o la Junta Directiva Nacional si es disperso o trabaja en Palmira).';
    END IF;
    v_cambia := TG_OP = 'INSERT' OR NEW.id_estamento_pertenencia IS DISTINCT FROM OLD.id_estamento_pertenencia;
    IF TG_OP = 'UPDATE' AND v_cambia THEN
        SELECT d.rol_estamento, e.nombre_estamento INTO v_cargo
          FROM gobernanza.directivo_estamento d JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento
         WHERE d.id_persona = NEW.id_persona AND d.nivel_cargo = 'LOCAL' AND d.fecha_retiro IS NULL;
        IF FOUND THEN
            RAISE EXCEPTION 'El afiliado es % en "%". Registre su retiro del cargo antes de cambiar su pertenencia.', v_cargo.rol_estamento, v_cargo.nombre_estamento;
        END IF;
        IF OLD.id_estamento_pertenencia IS NOT NULL AND v_op NOT IN ('disperso', 'traslado') AND NOT v_aprobar THEN
            RAISE EXCEPTION 'El cambio de subdirectiva o comité es un traslado: lo deciden las dos juntas, cada una con su acta (acción «Trasladar» del afiliado). Para dispersos o Palmira, use «Disperso / pertenencia».';
        END IF;
    END IF;
    IF v_cambia AND (NEW.id_estamento_pertenencia = v_jdn OR (TG_OP = 'UPDATE' AND OLD.id_estamento_pertenencia = v_jdn))
       AND v_op <> 'disperso' AND NOT v_aprobar THEN
        RAISE EXCEPTION 'Pertenecer a la Junta Directiva Nacional (dispersos y Palmira) o dejar de hacerlo lo decide la Junta Nacional con acta: use la acción «Disperso / pertenencia» del afiliado.';
    END IF;
    IF NEW.id_estamento_pertenencia IS NOT NULL AND NOT EXISTS (
        SELECT 1 FROM gobernanza.estamento WHERE id_estamento = NEW.id_estamento_pertenencia
           AND tipo_estamento IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL', 'JUNTA DIRECTIVA NACIONAL')) THEN
        RAISE EXCEPTION 'La pertenencia debe ser una subdirectiva, un comité seccional o la Junta Directiva Nacional.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Mensaje de la regla: indica también la Junta Nacional para quien trabaja en Palmira
CREATE OR REPLACE FUNCTION gobernanza.fn_verificar_pertenencia(p_id_persona BIGINT)
RETURNS VOID AS $$
DECLARE
    v_pert BIGINT; v_tipo VARCHAR(30); v_nombre VARCHAR(150);
    v_trabajo TEXT; v_central TEXT; v_empresa TEXT; v_opciones TEXT; v_mun_trabajo CHAR(5);
BEGIN
    SELECT a.id_estamento_pertenencia, e.tipo_estamento, e.nombre_estamento INTO v_pert, v_tipo, v_nombre
      FROM gobernanza.afiliado a LEFT JOIN gobernanza.estamento e ON e.id_estamento = a.id_estamento_pertenencia
     WHERE a.id_persona = p_id_persona;
    IF v_pert IS NULL OR v_tipo NOT IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL') THEN RETURN; END IF;
    IF NOT EXISTS (SELECT 1 FROM gobernanza.afiliado_empresa WHERE id_persona = p_id_persona) THEN RETURN; END IF;
    IF EXISTS (SELECT 1 FROM gobernanza.v_pertenencia_permitida WHERE id_persona = p_id_persona AND id_estamento = v_pert) THEN RETURN; END IF;

    SELECT emp.nombre_empresa, COALESCE(s.municipio_sede, emp.municipio), emp.municipio, COALESCE(s.municipio_codigo, emp.municipio_codigo)
      INTO v_empresa, v_trabajo, v_central, v_mun_trabajo
      FROM gobernanza.afiliado_empresa ae JOIN gobernanza.empresa emp ON emp.id_empresa = ae.id_empresa
      LEFT JOIN gobernanza.sede_empresa s ON s.id_sede = ae.id_sede
     WHERE ae.id_persona = p_id_persona;
    SELECT string_agg('"' || nombre_estamento || '"', ' o ' ORDER BY motivo DESC, nombre_estamento) INTO v_opciones
      FROM gobernanza.v_pertenencia_permitida WHERE id_persona = p_id_persona;
    IF v_mun_trabajo = gobernanza.fn_municipio_sede_nacional() THEN
        v_opciones := COALESCE(v_opciones || ' o ', '') || 'la Junta Directiva Nacional (trabaja en el municipio de la sede nacional)';
    END IF;
    RAISE EXCEPTION 'El afiliado trabaja en % (%), con sede principal en %, y no puede pertenecer a "%". Puede pertenecer a: %. Para otra junta se requiere un traslado por excepción con las actas de las dos juntas.',
        v_empresa, v_trabajo, v_central, v_nombre,
        COALESCE(v_opciones, 'ninguna; no hay subdirectiva ni comité registrados en esos municipios');
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION gobernanza.fn_acta_de(p_id_acta BIGINT, p_id_estamento BIGINT)
RETURNS BOOLEAN AS $$
    SELECT EXISTS (SELECT 1 FROM gestion_documental.documento d JOIN gestion_documental.tipo_documento t ON t.id_tipo_documento = d.id_tipo_documento
                    WHERE d.id_documento = p_id_acta AND t.sigla_tipo = 'ACT' AND d.id_estamento = p_id_estamento);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_es_excepcion_traslado(p_id_persona BIGINT, p_destino BIGINT)
RETURNS BOOLEAN AS $$
    WITH lugares AS (
        SELECT COALESCE(s.municipio_codigo, e.municipio_codigo) AS mun_trabajo, e.municipio_codigo AS mun_central,
               COALESCE(s.departamento_codigo, e.departamento_codigo) AS dep_trabajo, e.departamento_codigo AS dep_central
          FROM gobernanza.afiliado_empresa ae JOIN gobernanza.empresa e ON e.id_empresa = ae.id_empresa
          LEFT JOIN gobernanza.sede_empresa s ON s.id_sede = ae.id_sede WHERE ae.id_persona = p_id_persona)
    SELECT NOT EXISTS (
        SELECT 1 FROM lugares l, gobernanza.estamento est
         WHERE est.id_estamento = p_destino
           AND (est.municipio_codigo IN (l.mun_trabajo, l.mun_central)
                OR (est.municipio_codigo IS NULL AND est.departamento_codigo IN (l.dep_trabajo, l.dep_central))));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Proponer: el Presidente o el Secretario General de una de las dos juntas, con el acta de su junta
CREATE OR REPLACE FUNCTION gobernanza.fn_proponer_traslado(p_id_persona BIGINT, p_destino BIGINT, p_id_acta BIGINT, p_motivo TEXT)
RETURNS BIGINT AS $$
DECLARE v_a RECORD; v_dest RECORD; v_propone BIGINT; v_id BIGINT; v_cargo RECORD;
BEGIN
    SELECT a.*, e.tipo_estamento AS tipo_origen INTO v_a FROM gobernanza.afiliado a
      JOIN gobernanza.estamento e ON e.id_estamento = a.id_estamento_pertenencia WHERE a.id_persona = p_id_persona;
    IF NOT FOUND OR NOT v_a.activo THEN RAISE EXCEPTION 'La persona no es afiliada activa.'; END IF;
    IF v_a.tipo_origen NOT IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL') THEN
        RAISE EXCEPTION 'El afiliado pertenece a la Junta Directiva Nacional: su paso a una subdirectiva o comité se registra con «Disperso / pertenencia».';
    END IF;
    SELECT * INTO v_dest FROM gobernanza.estamento WHERE id_estamento = p_destino;
    IF NOT FOUND OR NOT v_dest.activo OR v_dest.tipo_estamento NOT IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL') THEN
        RAISE EXCEPTION 'El destino debe ser una subdirectiva o un comité activo. Para la Junta Nacional (dispersos o Palmira) use «Disperso / pertenencia».';
    END IF;
    IF p_destino = v_a.id_estamento_pertenencia THEN RAISE EXCEPTION 'El afiliado ya pertenece a esa junta.'; END IF;
    IF seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'SGEN\_%'], v_a.id_estamento_pertenencia) THEN v_propone := v_a.id_estamento_pertenencia;
    ELSIF seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'SGEN\_%'], p_destino) THEN v_propone := p_destino;
    ELSE
        RAISE EXCEPTION 'El traslado lo proponen el Presidente o el Secretario General de una de las dos juntas.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF NOT gobernanza.fn_acta_de(p_id_acta, v_propone) THEN
        RAISE EXCEPTION 'Indique el acta de reunión de su junta que decidió el traslado (documento tipo ACT radicado).';
    END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo del traslado (mínimo 10 caracteres).'; END IF;
    SELECT d.rol_estamento, e.nombre_estamento INTO v_cargo FROM gobernanza.directivo_estamento d
      JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento
     WHERE d.id_persona = p_id_persona AND d.nivel_cargo = 'LOCAL' AND d.fecha_retiro IS NULL;
    IF FOUND THEN
        RAISE EXCEPTION 'El afiliado es % en "%": registre su retiro del cargo antes del traslado.', v_cargo.rol_estamento, v_cargo.nombre_estamento;
    END IF;
    IF EXISTS (SELECT 1 FROM gobernanza.traslado_pertenencia WHERE id_persona = p_id_persona AND estado = 'PROPUESTO') THEN
        RAISE EXCEPTION 'Ya hay un traslado propuesto para este afiliado: la otra junta debe responderlo o quien lo propuso, anularlo.';
    END IF;
    PERFORM seguridad.fn_fijar_operacion('traslado.operacion', 'proponer');
    INSERT INTO gobernanza.traslado_pertenencia (id_persona, id_estamento_origen, id_estamento_destino, motivo, excepcion,
                                                 id_estamento_propone, id_acta_propone)
    VALUES (p_id_persona, v_a.id_estamento_pertenencia, p_destino, trim(p_motivo),
            gobernanza.fn_es_excepcion_traslado(p_id_persona, p_destino), v_propone, p_id_acta)
    RETURNING id_traslado INTO v_id;
    PERFORM seguridad.fn_fijar_operacion('traslado.operacion', '');
    RETURN v_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Responder: el Presidente o el Secretario General de la OTRA junta, con el acta de su junta
CREATE OR REPLACE FUNCTION gobernanza.fn_responder_traslado(p_id_traslado BIGINT, p_aceptar BOOLEAN, p_id_acta BIGINT, p_motivo TEXT DEFAULT NULL)
RETURNS TEXT AS $$
DECLARE v_t gobernanza.traslado_pertenencia%ROWTYPE; v_responde BIGINT;
BEGIN
    SELECT * INTO v_t FROM gobernanza.traslado_pertenencia WHERE id_traslado = p_id_traslado FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'El traslado no existe.'; END IF;
    IF v_t.estado <> 'PROPUESTO' THEN RAISE EXCEPTION 'El traslado ya fue %.', lower(v_t.estado); END IF;
    v_responde := CASE WHEN v_t.id_estamento_propone = v_t.id_estamento_origen THEN v_t.id_estamento_destino ELSE v_t.id_estamento_origen END;
    IF NOT seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'SGEN\_%'], v_responde) THEN
        RAISE EXCEPTION 'Este traslado lo responden el Presidente o el Secretario General de %.',
              (SELECT nombre_estamento FROM gobernanza.estamento WHERE id_estamento = v_responde) USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF NOT gobernanza.fn_acta_de(p_id_acta, v_responde) THEN
        RAISE EXCEPTION 'Indique el acta de reunión de su junta que decidió sobre el traslado (documento tipo ACT radicado).';
    END IF;
    IF NOT p_aceptar AND length(trim(COALESCE(p_motivo, ''))) < 10 THEN
        RAISE EXCEPTION 'Escriba el motivo del rechazo (mínimo 10 caracteres).';
    END IF;
    PERFORM seguridad.fn_fijar_operacion('traslado.operacion', 'responder');
    UPDATE gobernanza.traslado_pertenencia
       SET estado = CASE WHEN p_aceptar THEN 'APROBADO' ELSE 'RECHAZADO' END, id_acta_responde = p_id_acta,
           usuario_responde = auditoria.fn_usuario_actual(), fecha_responde = now(), motivo_respuesta = NULLIF(trim(COALESCE(p_motivo, '')), ''),
           excepcion = CASE WHEN p_aceptar THEN gobernanza.fn_es_excepcion_traslado(v_t.id_persona, v_t.id_estamento_destino) ELSE excepcion END
     WHERE id_traslado = p_id_traslado;
    PERFORM seguridad.fn_fijar_operacion('traslado.operacion', '');
    IF NOT p_aceptar THEN RETURN 'RECHAZADO'; END IF;
    IF (SELECT id_estamento_pertenencia FROM gobernanza.afiliado WHERE id_persona = v_t.id_persona) <> v_t.id_estamento_origen THEN
        RAISE EXCEPTION 'El afiliado ya no pertenece a la junta de origen: el traslado no se puede aplicar.';
    END IF;
    PERFORM seguridad.fn_fijar_operacion('pertenencia.operacion', 'traslado');
    PERFORM seguridad.fn_fijar_operacion('pertenencia.acta', p_id_acta::TEXT);
    PERFORM seguridad.fn_fijar_operacion('pertenencia.traslado', p_id_traslado::TEXT);
    PERFORM seguridad.fn_fijar_operacion('pertenencia.motivo',
            'Traslado' || CASE WHEN (SELECT excepcion FROM gobernanza.traslado_pertenencia WHERE id_traslado = p_id_traslado) THEN ' por excepción' ELSE '' END
            || ': ' || v_t.motivo);
    UPDATE gobernanza.afiliado SET id_estamento_pertenencia = v_t.id_estamento_destino WHERE id_persona = v_t.id_persona;
    PERFORM seguridad.fn_fijar_operacion('pertenencia.operacion', '');
    PERFORM seguridad.fn_fijar_operacion('pertenencia.acta', '');
    PERFORM seguridad.fn_fijar_operacion('pertenencia.traslado', '');
    PERFORM seguridad.fn_fijar_operacion('pertenencia.motivo', '');
    RETURN 'APROBADO';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Anular: la junta que lo propuso, mientras la otra no haya respondido
CREATE OR REPLACE FUNCTION gobernanza.fn_anular_traslado(p_id_traslado BIGINT, p_motivo TEXT)
RETURNS TEXT AS $$
DECLARE v_t gobernanza.traslado_pertenencia%ROWTYPE;
BEGIN
    SELECT * INTO v_t FROM gobernanza.traslado_pertenencia WHERE id_traslado = p_id_traslado FOR UPDATE;
    IF NOT FOUND OR v_t.estado <> 'PROPUESTO' THEN RAISE EXCEPTION 'Solo se anula un traslado propuesto y sin responder.'; END IF;
    IF NOT seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'SGEN\_%'], v_t.id_estamento_propone) THEN
        RAISE EXCEPTION 'Lo anulan el Presidente o el Secretario General de la junta que lo propuso.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo de la anulación (mínimo 10 caracteres).'; END IF;
    PERFORM seguridad.fn_fijar_operacion('traslado.operacion', 'anular');
    UPDATE gobernanza.traslado_pertenencia SET estado = 'ANULADO', motivo_respuesta = trim(p_motivo), fecha_responde = now(),
           usuario_responde = auditoria.fn_usuario_actual() WHERE id_traslado = p_id_traslado;
    PERFORM seguridad.fn_fijar_operacion('traslado.operacion', '');
    RETURN 'ANULADO';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 4. VISTAS
-- ----------------------------------------------------------------------------
-- Pertenencia: se marca la excepción aprobada y el grupo de la Junta Nacional (columnas nuevas al final)
CREATE OR REPLACE VIEW gobernanza.v_auditoria_pertenencia AS
SELECT
    p.tipo_dni || ' ' || p.dni AS identificacion,
    p.primer_nombre || ' ' || p.primer_apellido AS afiliado,
    emp.nombre_empresa,
    COALESCE(s.nombre_sede, 'SEDE CENTRAL') AS sede_trabajo,
    COALESCE(s.municipio_sede, emp.municipio) AS municipio_trabajo,
    emp.municipio AS municipio_sede_central,
    est.nombre_estamento AS pertenencia,
    (SELECT string_agg(pp.nombre_estamento, ' / ' ORDER BY pp.nombre_estamento)
       FROM gobernanza.v_pertenencia_permitida pp WHERE pp.id_persona = a.id_persona) AS opciones_permitidas,
    CASE
        WHEN ae.id_persona IS NULL THEN 'ALERTA MEDIA: SIN EMPRESA REGISTRADA'
        WHEN a.id_estamento_pertenencia IS NULL THEN 'ALERTA ALTA: SIN SUBDIRECTIVA O COMITÉ'
        WHEN est.tipo_estamento IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL') AND NOT EXISTS (
             SELECT 1 FROM gobernanza.v_pertenencia_permitida pp
              WHERE pp.id_persona = a.id_persona AND pp.id_estamento = a.id_estamento_pertenencia)
             THEN 'ALERTA CRÍTICA: PERTENENCIA NO CORRESPONDE A SU SEDE'
        WHEN est.tipo_estamento IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL') AND NOT EXISTS (
             SELECT 1 FROM gobernanza.v_pertenencia_permitida pp
              WHERE pp.id_persona = a.id_persona AND pp.id_estamento = a.id_estamento_pertenencia
                AND pp.motivo <> 'EXCEPCIÓN APROBADA POR LAS DOS JUNTAS')
             THEN 'EXCEPCIÓN APROBADA POR LAS DOS JUNTAS (CON ACTAS)'
        WHEN est.tipo_estamento = 'JUNTA DIRECTIVA NACIONAL' AND gobernanza.fn_grupo_nacional(a.id_persona) = 'PALMIRA'
             THEN 'JUNTA NACIONAL · PALMIRA (SEDE NACIONAL)'
        WHEN est.tipo_estamento = 'JUNTA DIRECTIVA NACIONAL' THEN 'JUNTA NACIONAL · DISPERSO'
        ELSE 'PERTENENCIA CORRECTA'
    END AS diagnostico,
    a.id_persona,
    a.id_estamento_pertenencia AS id_estamento,
    (SELECT 'Actas ' || dp.radicado_alfanumerico || ' y ' || dr.radicado_alfanumerico
       FROM gobernanza.traslado_pertenencia t
       JOIN gestion_documental.documento dp ON dp.id_documento = t.id_acta_propone
       JOIN gestion_documental.documento dr ON dr.id_documento = t.id_acta_responde
      WHERE t.id_persona = a.id_persona AND t.estado = 'APROBADO' AND t.excepcion
        AND t.id_estamento_destino = a.id_estamento_pertenencia
      ORDER BY t.fecha_responde DESC LIMIT 1) AS actas_excepcion
FROM gobernanza.afiliado a
JOIN gobernanza.persona p ON p.id_persona = a.id_persona
LEFT JOIN gobernanza.estamento est ON est.id_estamento = a.id_estamento_pertenencia
LEFT JOIN gobernanza.afiliado_empresa ae ON ae.id_persona = a.id_persona
LEFT JOIN gobernanza.empresa emp ON emp.id_empresa = ae.id_empresa
LEFT JOIN gobernanza.sede_empresa s ON s.id_sede = ae.id_sede;
ALTER VIEW gobernanza.v_auditoria_pertenencia SET (security_invoker = true);

-- Afiliados de la Junta Nacional, en sus dos grupos (censos separados)
CREATE OR REPLACE VIEW gobernanza.v_afiliados_junta_nacional WITH (security_invoker = true) AS
SELECT CASE gobernanza.fn_grupo_nacional(a.id_persona) WHEN 'PALMIRA' THEN 'PALMIRA (SEDE NACIONAL)' ELSE 'DISPERSOS' END AS grupo,
       p.primer_nombre || ' ' || p.primer_apellido AS afiliado, p.tipo_dni || ' ' || p.dni AS identificacion,
       emp.nombre_empresa AS empresa, COALESCE(m.nombre, s.municipio_sede, emp.municipio) AS municipio_trabajo,
       d.nombre AS departamento_trabajo, a.fecha_afiliacion, a.id_persona, a.id_estamento_pertenencia AS id_estamento
  FROM gobernanza.afiliado a
  JOIN gobernanza.persona p ON p.id_persona = a.id_persona
  LEFT JOIN gobernanza.afiliado_empresa ae ON ae.id_persona = a.id_persona
  LEFT JOIN gobernanza.empresa emp ON emp.id_empresa = ae.id_empresa
  LEFT JOIN gobernanza.sede_empresa s ON s.id_sede = ae.id_sede
  LEFT JOIN gobernanza.municipio m ON m.codigo = COALESCE(s.municipio_codigo, emp.municipio_codigo)
  LEFT JOIN gobernanza.departamento d ON d.codigo = left(COALESCE(s.municipio_codigo, emp.municipio_codigo), 2)
 WHERE a.activo AND a.id_estamento_pertenencia = gobernanza.fn_id_jdn();

-- Dónde se concentran los afiliados de la Junta Nacional (p. ej. para decidir si conviene crear un comité)
CREATE OR REPLACE VIEW gobernanza.v_junta_nacional_por_municipio WITH (security_invoker = true) AS
SELECT grupo, COALESCE(departamento_trabajo, 'SIN MUNICIPIO REGISTRADO') AS departamento, COALESCE(municipio_trabajo, '—') AS municipio,
       count(*) AS afiliados
  FROM gobernanza.v_afiliados_junta_nacional
 GROUP BY 1, 2, 3;

-- Traslados, con lo que falta para cada uno
CREATE OR REPLACE VIEW gobernanza.v_traslados WITH (security_invoker = true) AS
SELECT t.fecha_propone AS propuesto, p.primer_nombre || ' ' || p.primer_apellido AS afiliado, p.tipo_dni || ' ' || p.dni AS identificacion,
       eo.nombre_estamento AS de, ed.nombre_estamento AS a, t.estado,
       CASE WHEN t.excepcion THEN 'SÍ' ELSE 'NO' END AS excepcion,
       dp.radicado_alfanumerico AS acta_propone, ep.nombre_estamento AS propone,
       dr.radicado_alfanumerico AS acta_responde, t.motivo, t.motivo_respuesta,
       CASE WHEN t.estado = 'PROPUESTO' AND t.fecha_propone < now() - INTERVAL '30 days'
                 THEN 'ALERTA MEDIA: TRASLADO SIN RESPUESTA DE ' || upper(CASE WHEN t.id_estamento_propone = t.id_estamento_origen THEN ed.nombre_estamento ELSE eo.nombre_estamento END) || ' HACE MÁS DE 30 DÍAS'
            WHEN t.estado = 'PROPUESTO' THEN 'ALERTA BAJA: ESPERA LA RESPUESTA DE ' || upper(CASE WHEN t.id_estamento_propone = t.id_estamento_origen THEN ed.nombre_estamento ELSE eo.nombre_estamento END)
            ELSE t.estado END AS diagnostico,
       t.id_traslado, t.id_persona, t.id_estamento_origen, t.id_estamento_destino
  FROM gobernanza.traslado_pertenencia t
  JOIN gobernanza.persona p ON p.id_persona = t.id_persona
  JOIN gobernanza.estamento eo ON eo.id_estamento = t.id_estamento_origen
  JOIN gobernanza.estamento ed ON ed.id_estamento = t.id_estamento_destino
  JOIN gobernanza.estamento ep ON ep.id_estamento = t.id_estamento_propone
  JOIN gestion_documental.documento dp ON dp.id_documento = t.id_acta_propone
  LEFT JOIN gestion_documental.documento dr ON dr.id_documento = t.id_acta_responde;

-- Registros con un lugar escrito que no se pudo pasar a código (nombre ambiguo, mal escrito o DIVIPOLA sin cargar)
CREATE OR REPLACE VIEW gobernanza.v_lugares_por_corregir WITH (security_invoker = true) AS
SELECT 'Persona'::TEXT AS registro, p.primer_nombre || ' ' || p.primer_apellido || ' (' || p.tipo_dni || ' ' || p.dni || ')' AS nombre,
       p.departamento, p.municipio, 'ALERTA BAJA: MUNICIPIO DE RESIDENCIA SIN CÓDIGO DIVIPOLA'::TEXT AS diagnostico, p.id_persona AS id
  FROM gobernanza.persona p
 WHERE p.municipio IS NOT NULL AND p.municipio_codigo IS NULL AND COALESCE(p.pais_codigo, 'CO') = 'CO'
UNION ALL
SELECT 'Empresa', e.nombre_empresa, e.departamento, e.municipio, 'ALERTA ALTA: EMPRESA SIN MUNICIPIO DIVIPOLA (AFECTA LA REGLA DE PERTENENCIA)', e.id_empresa
  FROM gobernanza.empresa e WHERE e.municipio_codigo IS NULL
UNION ALL
SELECT 'Sede', s.nombre_sede, s.departamento_sede, s.municipio_sede, 'ALERTA ALTA: SEDE SIN MUNICIPIO DIVIPOLA (AFECTA LA REGLA DE PERTENENCIA)', s.id_sede
  FROM gobernanza.sede_empresa s WHERE s.municipio_codigo IS NULL
UNION ALL
SELECT 'Junta', es.nombre_estamento, es.departamento, es.municipio,
       CASE WHEN es.departamento_codigo IS NULL THEN 'ALERTA ALTA: JUNTA SIN DEPARTAMENTO DIVIPOLA' ELSE 'ALERTA ALTA: JUNTA SIN MUNICIPIO DIVIPOLA' END,
       es.id_estamento
  FROM gobernanza.estamento es
 WHERE es.tipo_estamento IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL')
   AND (es.departamento_codigo IS NULL OR (es.municipio IS NOT NULL AND es.municipio_codigo IS NULL));

-- ----------------------------------------------------------------------------
-- 5. PERMISOS Y DATOS QUE YA EXISTÍAN
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        GRANT SELECT ON gobernanza.pais, gobernanza.departamento, gobernanza.municipio, gobernanza.traslado_pertenencia TO sgs_app;
        GRANT SELECT ON gobernanza.v_pertenencia_permitida, gobernanza.v_auditoria_pertenencia, gobernanza.v_afiliados_junta_nacional,
                        gobernanza.v_junta_nacional_por_municipio, gobernanza.v_traslados, gobernanza.v_lugares_por_corregir TO sgs_app;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_lectura') THEN
        GRANT SELECT ON gobernanza.pais, gobernanza.departamento, gobernanza.municipio, gobernanza.traslado_pertenencia,
                        gobernanza.v_afiliados_junta_nacional, gobernanza.v_junta_nacional_por_municipio, gobernanza.v_traslados TO sgs_lectura;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_notificador') THEN
        GRANT SELECT ON gobernanza.pais, gobernanza.departamento, gobernanza.municipio, gobernanza.traslado_pertenencia,
                        gobernanza.v_traslados TO sgs_notificador;
    END IF;
END $$;
REVOKE EXECUTE ON FUNCTION gobernanza.fn_resolver_lugares() FROM PUBLIC;
DO $$
DECLARE r TEXT;
BEGIN
    FOREACH r IN ARRAY ARRAY['sgs_app', 'sgs_lectura', 'sgs_notificador'] LOOP
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
            EXECUTE format('REVOKE EXECUTE ON FUNCTION gobernanza.fn_resolver_lugares() FROM %I', r);
        END IF;
    END LOOP;
END $$;
DO $$ BEGIN
    PERFORM seguridad.fn_aplicar_politicas('gobernanza.pais', 'TRUE', 'FALSE');
    PERFORM seguridad.fn_aplicar_politicas('gobernanza.departamento', 'TRUE', 'FALSE');
    PERFORM seguridad.fn_aplicar_politicas('gobernanza.municipio', 'TRUE', 'FALSE');
    PERFORM seguridad.fn_aplicar_politicas('gobernanza.traslado_pertenencia',
        ':N OR id_estamento_origen = ANY (:E) OR id_estamento_destino = ANY (:E)', 'FALSE');
    -- Columnas nuevas de persona legibles (las reservadas siguen reservadas)
    PERFORM seguridad.fn_aplicar_reserva_columnas();
    -- Los lugares que ya estaban escritos se pasan a código cuando se reconocen
    PERFORM gobernanza.fn_resolver_lugares();
END $$;
