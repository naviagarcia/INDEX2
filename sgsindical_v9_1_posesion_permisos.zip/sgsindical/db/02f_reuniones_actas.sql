-- ============================================================================
-- SGSINDICAL v9.1 — 02f: REUNIONES Y ACTAS (quórum, decisiones, firmas, aprobación)
-- Ejecutar DESPUÉS de 02e y ANTES de 03.
-- ----------------------------------------------------------------------------
--  A0. CONVOCATORIA: no hay frecuencia fija; la junta se reúne cuando lo considera necesario.
--      Convocan solo el Presidente o el Secretario General vigentes de la junta, por correo a cada
--      directivo, con al menos 12 horas de anticipación y a más tardar a las 8:00 p. m. (hora local).
--      La convocatoria incluye el orden del día propuesto (al menos un punto); al iniciar la reunión
--      el orden del día se puede modificar y el acta deja constancia del orden convocado.
--  A0b. TIPO: la primera reunión de cada trimestre calendario (ene–mar, abr–jun, jul–sep, oct–dic)
--      es ORDINARIA; las demás del trimestre son EXTRAORDINARIAS. Lo calcula el sistema y se recalcula
--      si una reunión se cancela o se convoca otra anterior en el mismo trimestre.
--  A1. Cada reunión de junta registra fecha, modalidad, asistencia, orden del día y decisiones.
--  A2. ASISTENCIA DE TODOS: los directivos vigentes en la fecha de la reunión se cargan solos; se
--      agregan los invitados (personas registradas o externos con nombre, documento e institución).
--      Para cada uno: asistió, modalidad (presencial/virtual), hora de llegada y salida, o excusa.
--      Los invitados quedan en el acta pero no cuentan para el quórum ni votan.
--  A3. QUÓRUM: asisten la mitad más uno de los directivos vigentes. Sin quórum no se adoptan
--      decisiones y el acta no cuenta como la reunión del mes.
--  A4. Decisiones con votación (a favor, en contra, abstenciones); se aprueban por mayoría de los
--      votos emitidos y pueden generar compromisos con responsable y fecha límite.
--  A5. FIRMAS: Presidente y Secretario General de la junta. Desde la primera firma el contenido no
--      se modifica. Con la segunda se cierra: se radica el acta (ACT) y se crean los compromisos.
--  A6. APROBACIÓN: el acta se aprueba en la SIGUIENTE reunión con quórum de la misma junta.
-- ============================================================================
CREATE TABLE IF NOT EXISTS gestion_documental.reunion (
    id_reunion BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    fecha DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME,
    tipo_reunion VARCHAR(15) NOT NULL CHECK (tipo_reunion IN ('ORDINARIA', 'EXTRAORDINARIA')),
    modalidad VARCHAR(10) NOT NULL DEFAULT 'PRESENCIAL' CHECK (modalidad IN ('PRESENCIAL', 'VIRTUAL', 'MIXTA')),
    lugar VARCHAR(200) NOT NULL,
    -- Convocatoria
    id_persona_convoca BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    cargo_convoca VARCHAR(80) NOT NULL,
    fecha_convocatoria TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    orden_del_dia_convocado JSONB NOT NULL,
    -- Cancelación (solo antes de la hora de inicio)
    motivo_cancelacion TEXT,
    fecha_cancelacion TIMESTAMP WITH TIME ZONE,
    id_persona_cancela BIGINT REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    estado VARCHAR(12) NOT NULL DEFAULT 'CONVOCADA' CHECK (estado IN ('CONVOCADA', 'CERRADA', 'APROBADA', 'CANCELADA')),
    hay_quorum BOOLEAN,
    directivos_vigentes INT,
    directivos_asistentes INT,
    aprueba_acta_anterior BOOLEAN NOT NULL DEFAULT TRUE,
    observaciones_acta_anterior TEXT,
    id_reunion_acta_anterior BIGINT REFERENCES gestion_documental.reunion(id_reunion) ON DELETE RESTRICT,
    id_documento_acta BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    id_reunion_aprobacion BIGINT REFERENCES gestion_documental.reunion(id_reunion) ON DELETE RESTRICT,
    fecha_cierre TIMESTAMP WITH TIME ZONE,
    fecha_aprobacion DATE,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_reunion_horas CHECK (hora_fin IS NULL OR hora_fin > hora_inicio)
);
COMMENT ON TABLE gestion_documental.reunion IS 'Reuniones de junta directiva: convocatoria, asistencia, quórum, orden del día, decisiones, firmas y aprobación del acta.';
COMMENT ON COLUMN gestion_documental.reunion.estado IS 'CONVOCADA (acta en elaboración) → CERRADA (dos firmas) → APROBADA (en la siguiente reunión con quórum). CANCELADA antes de la hora de inicio.';
COMMENT ON COLUMN gestion_documental.reunion.orden_del_dia_convocado IS 'Copia del orden del día enviado en la convocatoria ([{orden, tema}]); el orden del día tratado está en reunion_punto.';
CREATE INDEX IF NOT EXISTS ix_reunion_convoca ON gestion_documental.reunion (id_persona_convoca);
CREATE INDEX IF NOT EXISTS ix_reunion_cancela ON gestion_documental.reunion (id_persona_cancela);

-- Zona horaria del sindicato (la fija el backend por transacción; por defecto Colombia)
CREATE OR REPLACE FUNCTION gestion_documental.fn_zona()
RETURNS TEXT AS $$
    SELECT COALESCE(NULLIF(current_setting('app.zona', true), ''), 'America/Bogota');
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE FUNCTION gestion_documental.fn_inicio_reunion(p_fecha DATE, p_hora TIME)
RETURNS TIMESTAMP WITH TIME ZONE AS $$
    SELECT (p_fecha + p_hora) AT TIME ZONE gestion_documental.fn_zona();
$$ LANGUAGE sql STABLE;

CREATE TABLE IF NOT EXISTS gestion_documental.reunion_asistente (
    id_asistente BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_reunion BIGINT NOT NULL REFERENCES gestion_documental.reunion(id_reunion) ON DELETE CASCADE,
    -- Persona registrada en el sistema (directivos, afiliados, funcionarios conocidos)...
    id_persona BIGINT REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    -- ...o invitado externo que no está registrado como persona
    nombre_invitado VARCHAR(150),
    documento_invitado VARCHAR(30),
    institucion VARCHAR(150),
    correo_invitado VARCHAR(120),
    calidad VARCHAR(10) NOT NULL DEFAULT 'INVITADO' CHECK (calidad IN ('DIRECTIVO', 'INVITADO')),
    cargo VARCHAR(80),
    asistio BOOLEAN NOT NULL DEFAULT FALSE,
    modalidad_asistencia VARCHAR(10) CHECK (modalidad_asistencia IN ('PRESENCIAL', 'VIRTUAL')),
    hora_llegada TIME,
    hora_salida TIME,
    excusa TEXT,
    version INT NOT NULL DEFAULT 1,
    UNIQUE (id_reunion, id_persona),
    CONSTRAINT ck_asistente_directivo_persona CHECK (calidad = 'INVITADO' OR id_persona IS NOT NULL),
    CONSTRAINT ck_asistente_identidad CHECK ((id_persona IS NULL) <> (nombre_invitado IS NULL)),
    CONSTRAINT ck_asistente_no_asistio CHECK (asistio OR (modalidad_asistencia IS NULL AND hora_llegada IS NULL AND hora_salida IS NULL)),
    CONSTRAINT ck_asistente_excusa CHECK (NOT asistio OR excusa IS NULL),
    CONSTRAINT ck_asistente_horas CHECK (hora_salida IS NULL OR hora_llegada IS NULL OR hora_salida > hora_llegada)
);
COMMENT ON TABLE gestion_documental.reunion_asistente IS
    'Asistencia de TODOS los participantes: directivos de la junta (cargados por el sistema, cuentan para el quórum) e invitados, registrados como persona o externos (no cuentan para el quórum).';
CREATE UNIQUE INDEX IF NOT EXISTS ux_reunion_invitado_documento
    ON gestion_documental.reunion_asistente (id_reunion, upper(documento_invitado)) WHERE documento_invitado IS NOT NULL;

CREATE TABLE IF NOT EXISTS gestion_documental.reunion_punto (
    id_punto BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_reunion BIGINT NOT NULL REFERENCES gestion_documental.reunion(id_reunion) ON DELETE CASCADE,
    orden INT NOT NULL CHECK (orden > 0),
    tema VARCHAR(250) NOT NULL,
    desarrollo TEXT,
    version INT NOT NULL DEFAULT 1,
    UNIQUE (id_reunion, orden)
);

CREATE TABLE IF NOT EXISTS gestion_documental.reunion_decision (
    id_decision BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_reunion BIGINT NOT NULL REFERENCES gestion_documental.reunion(id_reunion) ON DELETE CASCADE,
    id_punto BIGINT REFERENCES gestion_documental.reunion_punto(id_punto) ON DELETE SET NULL,
    texto TEXT NOT NULL,
    votos_favor INT NOT NULL DEFAULT 0 CHECK (votos_favor >= 0),
    votos_contra INT NOT NULL DEFAULT 0 CHECK (votos_contra >= 0),
    abstenciones INT NOT NULL DEFAULT 0 CHECK (abstenciones >= 0),
    aprobada BOOLEAN GENERATED ALWAYS AS (votos_favor > votos_contra) STORED,
    compromiso_titulo VARCHAR(200),
    id_persona_responsable BIGINT REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    fecha_limite DATE,
    id_compromiso BIGINT REFERENCES gestion_documental.compromiso_tarea(id_compromiso) ON DELETE SET NULL,
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_decision_compromiso CHECK ((compromiso_titulo IS NULL) = (id_persona_responsable IS NULL) AND (compromiso_titulo IS NULL) = (fecha_limite IS NULL))
);
COMMENT ON COLUMN gestion_documental.reunion_decision.compromiso_titulo IS 'Si se diligencia (con responsable y fecha límite), al cerrar el acta se crea el compromiso.';

CREATE TABLE IF NOT EXISTS gestion_documental.reunion_firma (
    id_reunion BIGINT NOT NULL REFERENCES gestion_documental.reunion(id_reunion) ON DELETE CASCADE,
    rol VARCHAR(12) NOT NULL CHECK (rol IN ('PRESIDENCIA', 'SECRETARIA')),
    id_usuario BIGINT NOT NULL REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    cargo VARCHAR(80) NOT NULL,
    fecha TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_reunion, rol)
);

CREATE INDEX IF NOT EXISTS ix_reunion_estamento_fecha ON gestion_documental.reunion (id_estamento, fecha DESC);
CREATE INDEX IF NOT EXISTS ix_reunion_acta_anterior ON gestion_documental.reunion (id_reunion_acta_anterior);
CREATE INDEX IF NOT EXISTS ix_reunion_documento ON gestion_documental.reunion (id_documento_acta);
CREATE INDEX IF NOT EXISTS ix_reunion_aprobacion ON gestion_documental.reunion (id_reunion_aprobacion);
CREATE INDEX IF NOT EXISTS ix_reunion_asistente_persona ON gestion_documental.reunion_asistente (id_persona);
CREATE INDEX IF NOT EXISTS ix_reunion_decision_reunion ON gestion_documental.reunion_decision (id_reunion);
CREATE INDEX IF NOT EXISTS ix_reunion_decision_punto ON gestion_documental.reunion_decision (id_punto);
CREATE INDEX IF NOT EXISTS ix_reunion_decision_responsable ON gestion_documental.reunion_decision (id_persona_responsable);
CREATE INDEX IF NOT EXISTS ix_reunion_decision_compromiso ON gestion_documental.reunion_decision (id_compromiso);
CREATE INDEX IF NOT EXISTS ix_reunion_firma_usuario ON gestion_documental.reunion_firma (id_usuario);
CREATE INDEX IF NOT EXISTS ix_reunion_firma_persona ON gestion_documental.reunion_firma (id_persona);

DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['gestion_documental.reunion', 'gestion_documental.reunion_asistente',
                             'gestion_documental.reunion_punto', 'gestion_documental.reunion_decision'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_control_version ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_control_version BEFORE UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version()', t);
    END LOOP;
    FOREACH t IN ARRAY ARRAY['gestion_documental.reunion', 'gestion_documental.reunion_asistente', 'gestion_documental.reunion_punto',
                             'gestion_documental.reunion_decision', 'gestion_documental.reunion_firma'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_auditoria ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria()', t);
    END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- 1. CONVOCATORIA, TIPO (ORDINARIA / EXTRAORDINARIA) Y CANCELACIÓN
-- ----------------------------------------------------------------------------
-- Cargo de convocante/firmante (Presidente o Secretario General vigente) del usuario actual en la junta
CREATE OR REPLACE FUNCTION gestion_documental.fn_cargo_mesa(p_id_estamento BIGINT, OUT rol TEXT, OUT cargo TEXT, OUT id_persona BIGINT)
AS $$
    SELECT CASE WHEN c.codigo LIKE 'PRES\_%' THEN 'PRESIDENCIA' ELSE 'SECRETARIA' END, c.nombre, d.id_persona
      FROM seguridad.usuario u
      JOIN gobernanza.directivo_estamento d ON d.id_persona = u.id_persona AND d.id_estamento = p_id_estamento
                                           AND d.fecha_retiro IS NULL AND d.fecha_posesion_individual <= CURRENT_DATE
      JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
     WHERE u.id_usuario = seguridad.fn_id_usuario_actual() AND u.activo
       AND (c.codigo LIKE 'PRES\_%' OR c.codigo LIKE 'SGEN\_%')
     ORDER BY 1 LIMIT 1;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- La primera reunión (no cancelada) de cada trimestre es ORDINARIA; las demás, EXTRAORDINARIAS.
CREATE OR REPLACE FUNCTION gestion_documental.fn_recalcular_tipos(p_id_estamento BIGINT, p_fecha DATE)
RETURNS VOID AS $$
DECLARE v_ini DATE := date_trunc('quarter', p_fecha)::DATE;
BEGIN
    PERFORM set_config('documental.operacion', 'tipo', true);
    UPDATE gestion_documental.reunion r SET tipo_reunion = x.tipo
      FROM (SELECT id_reunion,
                   CASE WHEN row_number() OVER (ORDER BY fecha, hora_inicio, id_reunion) = 1 THEN 'ORDINARIA' ELSE 'EXTRAORDINARIA' END AS tipo
              FROM gestion_documental.reunion
             WHERE id_estamento = p_id_estamento AND estado <> 'CANCELADA'
               AND fecha >= v_ini AND fecha < v_ini + INTERVAL '3 months') x
     WHERE r.id_reunion = x.id_reunion AND r.tipo_reunion IS DISTINCT FROM x.tipo;
    PERFORM set_config('documental.operacion', '', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gestion_documental.fn_convocar_reunion(
    p_id_estamento BIGINT, p_fecha DATE, p_hora_inicio TIME, p_modalidad TEXT, p_lugar TEXT, p_orden_del_dia JSONB)
RETURNS BIGINT AS $$
DECLARE
    v_mesa RECORD; v_ahora TIMESTAMP; v_inicio TIMESTAMPTZ; v_id BIGINT; v_punto JSONB; v_n INT := 0;
    v_hora_max TIME := '20:00'; v_anticipacion INTERVAL := INTERVAL '12 hours';
BEGIN
    SELECT * INTO v_mesa FROM gestion_documental.fn_cargo_mesa(p_id_estamento);
    IF v_mesa.rol IS NULL THEN
        RAISE EXCEPTION 'Solo el Presidente o el Secretario General vigentes de la junta pueden convocar a reunión.';
    END IF;
    v_ahora := now() AT TIME ZONE gestion_documental.fn_zona();
    IF v_ahora::TIME > v_hora_max THEN
        RAISE EXCEPTION 'Las convocatorias se envían a más tardar a las 8:00 p. m. Envíela mañana desde las 00:00 (con 12 horas de anticipación).';
    END IF;
    v_inicio := gestion_documental.fn_inicio_reunion(p_fecha, p_hora_inicio);
    IF v_inicio - now() < v_anticipacion THEN
        RAISE EXCEPTION 'La convocatoria debe enviarse con al menos 12 horas de anticipación: la reunión puede ser desde el % a las %.',
            to_char(v_ahora + v_anticipacion, 'YYYY-MM-DD'), to_char(v_ahora + v_anticipacion, 'HH24:MI');
    END IF;
    IF NULLIF(trim(p_lugar), '') IS NULL THEN
        RAISE EXCEPTION 'Indique el lugar o el enlace de la reunión.';
    END IF;
    IF p_orden_del_dia IS NULL OR jsonb_typeof(p_orden_del_dia) <> 'array' OR jsonb_array_length(p_orden_del_dia) = 0 THEN
        RAISE EXCEPTION 'La convocatoria debe incluir el orden del día (al menos un punto).';
    END IF;
    IF EXISTS (SELECT 1 FROM jsonb_array_elements(p_orden_del_dia) e
                WHERE NULLIF(trim(CASE jsonb_typeof(e) WHEN 'string' THEN e #>> '{}' ELSE e ->> 'tema' END), '') IS NULL) THEN
        RAISE EXCEPTION 'Cada punto del orden del día debe tener un tema.';
    END IF;
    -- Dos convocatorias simultáneas de la misma junta se serializan (el tipo depende del orden)
    PERFORM pg_advisory_xact_lock(hashtext('reunion_junta'), p_id_estamento::INT);
    IF EXISTS (SELECT 1 FROM gestion_documental.reunion WHERE id_estamento = p_id_estamento AND estado <> 'CANCELADA'
                  AND fecha = p_fecha AND hora_inicio = p_hora_inicio) THEN
        RAISE EXCEPTION 'La junta ya tiene una reunión convocada para esa fecha y hora.';
    END IF;

    PERFORM set_config('documental.operacion', 'convocar', true);
    INSERT INTO gestion_documental.reunion (id_estamento, fecha, hora_inicio, tipo_reunion, modalidad, lugar,
                                            id_persona_convoca, cargo_convoca, orden_del_dia_convocado)
    VALUES (p_id_estamento, p_fecha, p_hora_inicio, 'EXTRAORDINARIA', COALESCE(p_modalidad, 'PRESENCIAL'), trim(p_lugar),
            v_mesa.id_persona, v_mesa.cargo,
            (SELECT jsonb_agg(jsonb_build_object('orden', o.n, 'tema',
                     trim(CASE jsonb_typeof(o.e) WHEN 'string' THEN o.e #>> '{}' ELSE o.e ->> 'tema' END)) ORDER BY o.n)
               FROM jsonb_array_elements(p_orden_del_dia) WITH ORDINALITY o(e, n)))
    RETURNING id_reunion INTO v_id;
    -- El orden del día convocado es el punto de partida del orden del día tratado
    INSERT INTO gestion_documental.reunion_punto (id_reunion, orden, tema)
    SELECT v_id, (x ->> 'orden')::INT, x ->> 'tema'
      FROM jsonb_array_elements((SELECT orden_del_dia_convocado FROM gestion_documental.reunion WHERE id_reunion = v_id)) x;
    PERFORM set_config('documental.operacion', '', true);
    PERFORM gestion_documental.fn_recalcular_tipos(p_id_estamento, p_fecha);
    RETURN v_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gestion_documental.fn_cancelar_reunion(p_id_reunion BIGINT, p_motivo TEXT)
RETURNS VOID AS $$
DECLARE v_r gestion_documental.reunion%ROWTYPE; v_mesa RECORD;
BEGIN
    SELECT * INTO v_r FROM gestion_documental.reunion WHERE id_reunion = p_id_reunion FOR UPDATE;
    IF v_r.id_reunion IS NULL THEN RAISE EXCEPTION 'La reunión no existe.'; END IF;
    SELECT * INTO v_mesa FROM gestion_documental.fn_cargo_mesa(v_r.id_estamento);
    IF v_mesa.rol IS NULL THEN
        RAISE EXCEPTION 'Solo el Presidente o el Secretario General vigentes de la junta pueden cancelar la reunión.';
    END IF;
    IF v_r.estado <> 'CONVOCADA' THEN RAISE EXCEPTION 'Solo se cancela una reunión convocada (esta está %).', lower(v_r.estado); END IF;
    IF now() >= gestion_documental.fn_inicio_reunion(v_r.fecha, v_r.hora_inicio) THEN
        RAISE EXCEPTION 'La reunión ya empezó: no se cancela. Si no hubo quórum, firme el acta dejando constancia.';
    END IF;
    IF NULLIF(trim(p_motivo), '') IS NULL THEN RAISE EXCEPTION 'Indique el motivo de la cancelación.'; END IF;
    PERFORM pg_advisory_xact_lock(hashtext('reunion_junta'), v_r.id_estamento::INT);
    PERFORM set_config('documental.operacion', 'cancelar', true);
    UPDATE gestion_documental.reunion SET estado = 'CANCELADA', motivo_cancelacion = trim(p_motivo),
           fecha_cancelacion = now(), id_persona_cancela = v_mesa.id_persona
     WHERE id_reunion = p_id_reunion;
    PERFORM set_config('documental.operacion', '', true);
    PERFORM gestion_documental.fn_recalcular_tipos(v_r.id_estamento, v_r.fecha);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 1b. ASISTENCIA AUTOMÁTICA Y BLOQUEO DEL CONTENIDO
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION gestion_documental.fn_reunion_cargar_asistencia()
RETURNS TRIGGER AS $$
BEGIN
    -- Directivos vigentes de la junta en la fecha de la reunión (son los convocados)
    INSERT INTO gestion_documental.reunion_asistente (id_reunion, id_persona, calidad, cargo)
    SELECT NEW.id_reunion, d.id_persona, 'DIRECTIVO', c.nombre
      FROM gobernanza.directivo_estamento d
      LEFT JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
     WHERE d.id_estamento = NEW.id_estamento AND d.fecha_posesion_individual <= NEW.fecha
       AND (d.fecha_retiro IS NULL OR d.fecha_retiro > NEW.fecha)
    ON CONFLICT DO NOTHING;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_reunion_asistencia ON gestion_documental.reunion;
CREATE TRIGGER trg_reunion_asistencia AFTER INSERT ON gestion_documental.reunion
    FOR EACH ROW EXECUTE FUNCTION gestion_documental.fn_reunion_cargar_asistencia();

CREATE OR REPLACE FUNCTION gestion_documental.fn_reunion_proteger()
RETURNS TRIGGER AS $$
DECLARE v_id BIGINT; v_r gestion_documental.reunion%ROWTYPE; v_firmas INT; v_op TEXT; v_empezo BOOLEAN;
BEGIN
    v_op := COALESCE(current_setting('documental.operacion', true), '');
    IF TG_TABLE_NAME = 'reunion' THEN
        IF TG_OP = 'INSERT' THEN
            IF v_op <> 'convocar' THEN
                RAISE EXCEPTION 'Las reuniones se crean con la convocatoria (Presidente o Secretario General de la junta).';
            END IF;
            RETURN NEW;
        END IF;
        IF v_op IN ('cerrar', 'cancelar', 'tipo') THEN RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END; END IF;
        IF TG_OP = 'DELETE' THEN
            RAISE EXCEPTION 'Las reuniones no se eliminan: si aún no empieza, cancélela indicando el motivo.';
        END IF;
        IF NEW.estado IS DISTINCT FROM OLD.estado OR NEW.hay_quorum IS DISTINCT FROM OLD.hay_quorum
           OR NEW.id_documento_acta IS DISTINCT FROM OLD.id_documento_acta OR NEW.id_reunion_aprobacion IS DISTINCT FROM OLD.id_reunion_aprobacion
           OR NEW.tipo_reunion IS DISTINCT FROM OLD.tipo_reunion THEN
            RAISE EXCEPTION 'El estado y el tipo de la reunión los calcula el sistema (convocatoria, firmas, cancelación y aprobación).';
        END IF;
        IF NEW.fecha IS DISTINCT FROM OLD.fecha OR NEW.id_estamento IS DISTINCT FROM OLD.id_estamento
           OR NEW.hora_inicio IS DISTINCT FROM OLD.hora_inicio OR NEW.modalidad IS DISTINCT FROM OLD.modalidad
           OR NEW.lugar IS DISTINCT FROM OLD.lugar OR NEW.orden_del_dia_convocado IS DISTINCT FROM OLD.orden_del_dia_convocado
           OR NEW.id_persona_convoca IS DISTINCT FROM OLD.id_persona_convoca OR NEW.fecha_convocatoria IS DISTINCT FROM OLD.fecha_convocatoria THEN
            RAISE EXCEPTION 'Los datos de la convocatoria no se cambian: cancele la reunión y convoque de nuevo.';
        END IF;
        v_id := OLD.id_reunion;
    ELSE
        v_id := CASE WHEN TG_OP = 'DELETE' THEN OLD.id_reunion ELSE NEW.id_reunion END;
        IF v_op IN ('cerrar', 'convocar') THEN RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END; END IF;
    END IF;

    SELECT * INTO v_r FROM gestion_documental.reunion WHERE id_reunion = v_id;
    SELECT count(*) INTO v_firmas FROM gestion_documental.reunion_firma WHERE id_reunion = v_id;
    IF v_r.estado = 'CANCELADA' THEN RAISE EXCEPTION 'La reunión fue cancelada.'; END IF;
    IF v_r.estado IS DISTINCT FROM 'CONVOCADA' OR v_firmas > 0 THEN
        RAISE EXCEPTION 'El acta ya fue firmada: su contenido no se modifica.';
    END IF;
    v_empezo := now() >= gestion_documental.fn_inicio_reunion(v_r.fecha, v_r.hora_inicio);

    IF TG_TABLE_NAME = 'reunion_punto' AND NOT v_empezo THEN
        RAISE EXCEPTION 'El orden del día convocado se modifica al iniciar la reunión (desde las % del %).',
            to_char(v_r.hora_inicio, 'HH24:MI'), to_char(v_r.fecha, 'YYYY-MM-DD');
    END IF;
    IF TG_TABLE_NAME = 'reunion_decision' AND NOT v_empezo THEN
        RAISE EXCEPTION 'Las decisiones se registran desde la hora de inicio de la reunión.';
    END IF;
    IF TG_TABLE_NAME = 'reunion_asistente' THEN
        IF TG_OP = 'DELETE' AND OLD.calidad = 'DIRECTIVO' THEN
            RAISE EXCEPTION 'Los directivos de la junta no se quitan de la lista: marque si asistió o registre su excusa.';
        END IF;
        IF TG_OP = 'INSERT' THEN
            NEW.calidad := 'INVITADO';   -- los directivos los carga el sistema
        END IF;
        IF TG_OP = 'UPDATE' AND (NEW.calidad IS DISTINCT FROM OLD.calidad OR NEW.id_persona IS DISTINCT FROM OLD.id_persona) THEN
            RAISE EXCEPTION 'No se cambia la persona ni su calidad: elimine al invitado y regístrelo de nuevo.';
        END IF;
        IF TG_OP <> 'DELETE' AND NEW.asistio AND NOT v_empezo THEN
            RAISE EXCEPTION 'La asistencia se registra desde la hora de inicio de la reunión.';
        END IF;
    END IF;
    RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['gestion_documental.reunion_asistente', 'gestion_documental.reunion_punto',
                             'gestion_documental.reunion_decision'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_reunion_proteger ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_reunion_proteger BEFORE INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION gestion_documental.fn_reunion_proteger()', t);
    END LOOP;
END $$;
DROP TRIGGER IF EXISTS trg_reunion_proteger ON gestion_documental.reunion;
CREATE TRIGGER trg_reunion_proteger BEFORE INSERT OR UPDATE OR DELETE ON gestion_documental.reunion
    FOR EACH ROW EXECUTE FUNCTION gestion_documental.fn_reunion_proteger();

-- ----------------------------------------------------------------------------
-- 2. FIRMA Y CIERRE DEL ACTA
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION gestion_documental.fn_firmar_acta(p_id_reunion BIGINT)
RETURNS TEXT AS $$
DECLARE
    v_r gestion_documental.reunion%ROWTYPE;
    v_u seguridad.usuario%ROWTYPE;
    v_rol TEXT; v_cargo TEXT;
    v_n INT; v_asist INT; v_quorum BOOLEAN;
    v_dec RECORD; v_id_doc BIGINT; v_id_comp BIGINT; v_anterior BIGINT;
    v_tipo_act BIGINT; v_nombre_est TEXT;
BEGIN
    SELECT * INTO v_u FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo;
    IF v_u.id_usuario IS NULL THEN RAISE EXCEPTION 'Usuario no identificado.'; END IF;
    SELECT * INTO v_r FROM gestion_documental.reunion WHERE id_reunion = p_id_reunion FOR UPDATE;
    IF v_r.id_reunion IS NULL THEN RAISE EXCEPTION 'La reunión no existe.'; END IF;
    IF v_r.estado = 'CANCELADA' THEN RAISE EXCEPTION 'La reunión fue cancelada: no tiene acta.'; END IF;
    IF v_r.estado <> 'CONVOCADA' THEN RAISE EXCEPTION 'El acta ya está cerrada.'; END IF;
    IF now() < gestion_documental.fn_inicio_reunion(v_r.fecha, v_r.hora_inicio) THEN
        RAISE EXCEPTION 'El acta se firma después de iniciada la reunión.';
    END IF;

    SELECT m.rol, m.cargo INTO v_rol, v_cargo FROM gestion_documental.fn_cargo_mesa(v_r.id_estamento) m;
    IF v_rol IS NULL THEN
        RAISE EXCEPTION 'El acta la firman el Presidente y el Secretario General de la junta.';
    END IF;
    IF EXISTS (SELECT 1 FROM gestion_documental.reunion_firma WHERE id_reunion = p_id_reunion AND rol = v_rol) THEN
        RAISE EXCEPTION 'La firma de % ya está registrada; falta la otra firma.', CASE v_rol WHEN 'PRESIDENCIA' THEN 'la Presidencia' ELSE 'la Secretaría' END;
    END IF;

    -- Validaciones del contenido (antes de la primera firma, que lo congela)
    SELECT count(*), count(*) FILTER (WHERE asistio) INTO v_n, v_asist
      FROM gestion_documental.reunion_asistente WHERE id_reunion = p_id_reunion AND calidad = 'DIRECTIVO';
    IF NOT EXISTS (SELECT 1 FROM gestion_documental.reunion_punto WHERE id_reunion = p_id_reunion) THEN
        RAISE EXCEPTION 'El acta debe tener al menos un punto en el orden del día.';
    END IF;
    IF v_n = 0 THEN RAISE EXCEPTION 'La junta no tenía directivos vigentes en la fecha de la reunión.'; END IF;
    v_quorum := v_asist >= (v_n / 2) + 1;
    IF NOT v_quorum AND EXISTS (SELECT 1 FROM gestion_documental.reunion_decision WHERE id_reunion = p_id_reunion) THEN
        RAISE EXCEPTION 'Sin quórum no se pueden adoptar decisiones: asistieron % de % directivos y se requieren %.', v_asist, v_n, (v_n / 2) + 1;
    END IF;
    SELECT * INTO v_dec FROM gestion_documental.reunion_decision
     WHERE id_reunion = p_id_reunion AND votos_favor + votos_contra + abstenciones > v_asist LIMIT 1;
    IF FOUND THEN
        RAISE EXCEPTION 'Una decisión registra más votos (%) que directivos asistentes (%).',
            v_dec.votos_favor + v_dec.votos_contra + v_dec.abstenciones, v_asist;
    END IF;
    IF EXISTS (SELECT 1 FROM gestion_documental.reunion_decision
                WHERE id_reunion = p_id_reunion AND compromiso_titulo IS NOT NULL AND NOT aprobada) THEN
        RAISE EXCEPTION 'Solo las decisiones aprobadas generan compromisos: revise las decisiones con compromiso que no fueron aprobadas.';
    END IF;

    INSERT INTO gestion_documental.reunion_firma (id_reunion, rol, id_usuario, id_persona, cargo)
    VALUES (p_id_reunion, v_rol, v_u.id_usuario, v_u.id_persona, v_cargo);
    IF (SELECT count(*) FROM gestion_documental.reunion_firma WHERE id_reunion = p_id_reunion) < 2 THEN
        RETURN 'PENDIENTE: registrada la firma de ' || CASE v_rol WHEN 'PRESIDENCIA' THEN 'la Presidencia' ELSE 'la Secretaría' END || '; falta la otra firma.';
    END IF;

    -- Segunda firma: se cierra el acta
    PERFORM set_config('documental.operacion', 'cerrar', true);
    SELECT nombre_estamento INTO v_nombre_est FROM gobernanza.estamento WHERE id_estamento = v_r.id_estamento;
    SELECT id_tipo_documento INTO v_tipo_act FROM gestion_documental.tipo_documento WHERE sigla_tipo = 'ACT';
    INSERT INTO gestion_documental.documento (flujo, id_estamento, id_tipo_documento, asunto, descripcion_resumen,
                                              fecha_radicacion, id_persona_remitente, estado_tramite)
    VALUES ('EMITIDO', v_r.id_estamento, v_tipo_act,
            'Acta de reunión ' || lower(v_r.tipo_reunion) || ' de ' || v_nombre_est || ' del ' || to_char(v_r.fecha, 'YYYY-MM-DD')
                || CASE WHEN v_quorum THEN '' ELSE ' (SIN QUÓRUM)' END,
            'Asistieron ' || v_asist || ' de ' || v_n || ' directivos y '
                || (SELECT count(*) FROM gestion_documental.reunion_asistente
                     WHERE id_reunion = p_id_reunion AND calidad = 'INVITADO' AND asistio) || ' invitado(s). '
                || (SELECT count(*) FROM gestion_documental.reunion_decision WHERE id_reunion = p_id_reunion) || ' decisión(es).',
            (v_r.fecha + v_r.hora_inicio)::TIMESTAMP AT TIME ZONE COALESCE(NULLIF(current_setting('app.zona', true), ''), 'America/Bogota'),
            (SELECT id_persona FROM gestion_documental.reunion_firma WHERE id_reunion = p_id_reunion AND rol = 'SECRETARIA'),
            'RADICADO')
    RETURNING id_documento INTO v_id_doc;

    FOR v_dec IN SELECT * FROM gestion_documental.reunion_decision
                  WHERE id_reunion = p_id_reunion AND compromiso_titulo IS NOT NULL ORDER BY id_decision LOOP
        INSERT INTO gestion_documental.compromiso_tarea (id_documento_origen, id_estamento, titulo_compromiso, descripcion_accion,
                                                         prioridad, id_persona_responsable, fecha_asignacion, fecha_limite_cumplimiento)
        VALUES (v_id_doc, v_r.id_estamento, v_dec.compromiso_titulo, v_dec.texto, 'MEDIA', v_dec.id_persona_responsable,
                v_r.fecha, v_dec.fecha_limite)
        RETURNING id_compromiso INTO v_id_comp;
        UPDATE gestion_documental.reunion_decision SET id_compromiso = v_id_comp WHERE id_decision = v_dec.id_decision;
    END LOOP;

    -- Acta anterior pendiente de aprobación (de la misma junta)
    SELECT id_reunion INTO v_anterior FROM gestion_documental.reunion
     WHERE id_estamento = v_r.id_estamento AND estado = 'CERRADA' AND fecha < v_r.fecha AND id_reunion <> p_id_reunion
     ORDER BY fecha DESC, id_reunion DESC LIMIT 1;
    UPDATE gestion_documental.reunion
       SET estado = 'CERRADA', hay_quorum = v_quorum, directivos_vigentes = v_n, directivos_asistentes = v_asist,
           id_documento_acta = v_id_doc, fecha_cierre = now(), id_reunion_acta_anterior = v_anterior
     WHERE id_reunion = p_id_reunion;
    IF v_anterior IS NOT NULL AND v_quorum AND v_r.aprueba_acta_anterior THEN
        UPDATE gestion_documental.reunion SET estado = 'APROBADA', id_reunion_aprobacion = p_id_reunion, fecha_aprobacion = v_r.fecha
         WHERE id_reunion = v_anterior;
    END IF;
    PERFORM set_config('documental.operacion', '', true);
    RETURN 'CERRADA';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 3. VISTAS
-- ----------------------------------------------------------------------------
DROP VIEW IF EXISTS gestion_documental.v_auditoria_reuniones;
CREATE VIEW gestion_documental.v_auditoria_reuniones WITH (security_invoker = true) AS
SELECT
    r.id_reunion,
    e.nombre_estamento AS junta,
    r.fecha,
    to_char(r.hora_inicio, 'HH24:MI') AS hora,
    r.tipo_reunion,
    r.modalidad,
    r.estado,
    r.cargo_convoca AS convoca,
    COALESCE(r.directivos_asistentes, (SELECT count(*) FROM gestion_documental.reunion_asistente a
                                         WHERE a.id_reunion = r.id_reunion AND a.calidad = 'DIRECTIVO' AND a.asistio))::INT AS asistentes,
    COALESCE(r.directivos_vigentes, (SELECT count(*) FROM gestion_documental.reunion_asistente a
                                       WHERE a.id_reunion = r.id_reunion AND a.calidad = 'DIRECTIVO'))::INT AS directivos,
    (SELECT count(*) FROM gestion_documental.reunion_asistente a
      WHERE a.id_reunion = r.id_reunion AND a.calidad = 'INVITADO' AND a.asistio)::INT AS invitados,
    CASE WHEN r.hay_quorum IS NULL THEN 'Por determinar' WHEN r.hay_quorum THEN 'Sí' ELSE 'No' END AS quorum,
    (SELECT count(*) FROM gestion_documental.reunion_decision dd WHERE dd.id_reunion = r.id_reunion)::INT AS decisiones,
    (SELECT count(*) FROM gestion_documental.reunion_decision dd WHERE dd.id_reunion = r.id_reunion AND dd.id_compromiso IS NOT NULL)::INT AS compromisos,
    (SELECT string_agg(f.cargo, ' y ' ORDER BY f.rol) FROM gestion_documental.reunion_firma f WHERE f.id_reunion = r.id_reunion) AS firmas,
    d.radicado_alfanumerico AS radicado_acta,
    r.fecha_aprobacion,
    CASE
        WHEN r.estado IN ('CERRADA', 'APROBADA') AND NOT r.hay_quorum THEN 'ALERTA ALTA: REUNIÓN SIN QUÓRUM (NO CUENTA COMO REUNIÓN DEL MES)'
        WHEN r.estado = 'CANCELADA' THEN 'CANCELADA: ' || COALESCE(r.motivo_cancelacion, '')
        WHEN r.estado = 'CONVOCADA' AND CURRENT_DATE - r.fecha > 7 THEN 'ALERTA MEDIA: ACTA SIN FIRMAR HACE MÁS DE 7 DÍAS'
        WHEN r.estado = 'CONVOCADA' AND gestion_documental.fn_inicio_reunion(r.fecha, r.hora_inicio) > now()
            THEN 'CONVOCADA PARA EL ' || to_char(r.fecha, 'YYYY-MM-DD') || ' A LAS ' || to_char(r.hora_inicio, 'HH24:MI')
        WHEN r.estado = 'CERRADA' AND CURRENT_DATE - r.fecha > 45 THEN 'ALERTA MEDIA: ACTA PENDIENTE DE APROBACIÓN HACE MÁS DE 45 DÍAS'
        WHEN r.estado = 'APROBADA' THEN 'ACTA APROBADA'
        WHEN r.estado = 'CERRADA' THEN 'ACTA FIRMADA, PENDIENTE DE APROBACIÓN EN LA SIGUIENTE REUNIÓN'
        ELSE 'ACTA EN ELABORACIÓN'
    END AS diagnostico
FROM gestion_documental.reunion r
JOIN gobernanza.estamento e ON e.id_estamento = r.id_estamento
LEFT JOIN gestion_documental.documento d ON d.id_documento = r.id_documento_acta;


-- Asistencia de cada directivo vigente a las reuniones cerradas de su junta (últimos 12 meses)
DROP VIEW IF EXISTS gestion_documental.v_auditoria_asistencia;
CREATE VIEW gestion_documental.v_auditoria_asistencia WITH (security_invoker = true) AS
WITH base AS (
    SELECT d.id_persona, d.id_estamento, e.nombre_estamento AS junta, c.nombre AS cargo,
           p.primer_nombre || ' ' || p.primer_apellido AS directivo,
           r.id_reunion, r.fecha, a.asistio, a.excusa
      FROM gobernanza.directivo_estamento d
      JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento
      JOIN gobernanza.persona p ON p.id_persona = d.id_persona
      LEFT JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
      LEFT JOIN gestion_documental.reunion r ON r.id_estamento = d.id_estamento AND r.estado IN ('CERRADA', 'APROBADA')
                                            AND r.fecha >= CURRENT_DATE - INTERVAL '12 months'
      LEFT JOIN gestion_documental.reunion_asistente a ON a.id_reunion = r.id_reunion AND a.id_persona = d.id_persona
     WHERE d.fecha_retiro IS NULL
), ultimas AS (
    SELECT b.*, row_number() OVER (PARTITION BY b.id_persona, b.id_estamento ORDER BY b.fecha DESC, b.id_reunion DESC) AS n
      FROM base b WHERE b.id_reunion IS NOT NULL AND b.asistio IS NOT NULL
), resumen AS (
    SELECT b.id_persona, b.id_estamento, b.junta, b.cargo, b.directivo,
           count(*) FILTER (WHERE b.asistio IS NOT NULL) AS reuniones,
           count(*) FILTER (WHERE b.asistio) AS asistidas,
           count(*) FILTER (WHERE NOT b.asistio AND b.excusa IS NOT NULL) AS con_excusa,
           count(*) FILTER (WHERE NOT b.asistio AND b.excusa IS NULL) AS sin_excusa,
           max(b.fecha) FILTER (WHERE b.asistio) AS ultima_asistencia
      FROM base b
     GROUP BY b.id_persona, b.id_estamento, b.junta, b.cargo, b.directivo
)
SELECT r.id_persona, r.id_estamento, r.junta, r.cargo, r.directivo, r.reuniones, r.asistidas, r.con_excusa, r.sin_excusa,
       CASE WHEN r.reuniones > 0 THEN round(100.0 * r.asistidas / r.reuniones, 1) END AS porcentaje_asistencia,
       r.ultima_asistencia,
       (SELECT count(*) FROM ultimas u WHERE u.id_persona = r.id_persona AND u.id_estamento = r.id_estamento AND u.n <= 3
           AND NOT u.asistio AND u.excusa IS NULL)::INT AS faltas_sin_excusa_ultimas_3,
       CASE
           WHEN (SELECT count(*) FROM ultimas u WHERE u.id_persona = r.id_persona AND u.id_estamento = r.id_estamento AND u.n <= 3
                    AND NOT u.asistio AND u.excusa IS NULL) = 3
               THEN 'ALERTA ALTA: FALTÓ SIN EXCUSA A LAS ÚLTIMAS 3 REUNIONES'
           WHEN r.reuniones >= 3 AND r.asistidas * 2 < r.reuniones
               THEN 'ALERTA MEDIA: ASISTENCIA INFERIOR AL 50% EN EL ÚLTIMO AÑO'
           WHEN r.reuniones = 0 THEN 'SIN REUNIONES REGISTRADAS'
           ELSE 'ASISTENCIA NORMAL'
       END AS diagnostico
FROM resumen r;

-- Las actas de reuniones SIN QUÓRUM no cuentan para la reunión mensual
DROP VIEW IF EXISTS gestion_documental.v_auditoria_actas_juntas;
CREATE VIEW gestion_documental.v_auditoria_actas_juntas WITH (security_invoker = true) AS
WITH mes AS (
    SELECT date_trunc('month', CURRENT_DATE)::DATE AS actual,
           (date_trunc('month', CURRENT_DATE) - INTERVAL '1 month')::DATE AS anterior,
           (date_trunc('month', CURRENT_DATE) + INTERVAL '1 month' - INTERVAL '1 day')::DATE AS fin_actual
), juntas AS (
    SELECT e.id_estamento, e.nombre_estamento, e.tipo_estamento, COUNT(*) AS directivos_vigentes,
           MIN(d.fecha_posesion_individual) AS inicio_junta
      FROM gobernanza.estamento e
      JOIN gobernanza.directivo_estamento d ON d.id_estamento = e.id_estamento AND d.fecha_retiro IS NULL
     GROUP BY e.id_estamento, e.nombre_estamento, e.tipo_estamento
), actas AS (
    SELECT d.id_estamento, d.fecha_radicacion::DATE AS fecha
      FROM gestion_documental.documento d
      JOIN gestion_documental.tipo_documento t ON t.id_tipo_documento = d.id_tipo_documento
     WHERE t.sigla_tipo = 'ACT' AND d.flujo = 'EMITIDO' AND d.estado_tramite <> 'ANULADO'
       -- Un acta de una reunión SIN QUÓRUM no cuenta como la reunión del mes
       AND NOT EXISTS (SELECT 1 FROM gestion_documental.reunion r WHERE r.id_documento_acta = d.id_documento AND NOT r.hay_quorum)
), resumen AS (
    SELECT j.*, m.actual, m.anterior, m.fin_actual,
           (SELECT MAX(a.fecha) FROM actas a WHERE a.id_estamento = j.id_estamento) AS fecha_ultima_acta,
           (SELECT COUNT(*) FROM actas a WHERE a.id_estamento = j.id_estamento AND a.fecha >= m.actual) AS actas_mes_actual,
           (SELECT COUNT(*) FROM actas a WHERE a.id_estamento = j.id_estamento
               AND a.fecha >= m.anterior AND a.fecha < m.actual) AS actas_mes_anterior,
           (SELECT COUNT(*) FROM generate_series(GREATEST(date_trunc('month', j.inicio_junta)::DATE, (m.actual - INTERVAL '12 months')::DATE),
                                                 m.anterior, INTERVAL '1 month') g(mes)
             WHERE NOT EXISTS (SELECT 1 FROM actas a WHERE a.id_estamento = j.id_estamento
                                  AND a.fecha >= g.mes AND a.fecha < g.mes + INTERVAL '1 month')) AS meses_incumplidos_ultimo_anio
      FROM juntas j CROSS JOIN mes m
)
SELECT
    id_estamento,
    nombre_estamento,
    tipo_estamento AS ambito_territorial,
    directivos_vigentes,
    fecha_ultima_acta,
    (CURRENT_DATE - fecha_ultima_acta) AS dias_desde_ultima_acta,
    actas_mes_anterior,
    actas_mes_actual,
    (fin_actual - CURRENT_DATE) AS dias_para_cerrar_mes,
    meses_incumplidos_ultimo_anio,
    CASE
        WHEN inicio_junta < actual AND actas_mes_anterior = 0 AND actas_mes_actual = 0
            THEN 'ALERTA CRÍTICA: SIN ACTA EL MES ANTERIOR NI EN EL MES EN CURSO'
        WHEN actas_mes_actual = 0 AND fin_actual - CURRENT_DATE <= 7
            THEN 'ALERTA ALTA: EL MES TERMINA EN 7 DÍAS O MENOS SIN ACTA DE REUNIÓN'
        WHEN inicio_junta < actual AND actas_mes_anterior = 0
            THEN 'ALERTA MEDIA: INCUMPLIÓ LA REUNIÓN DEL MES ANTERIOR'
        WHEN actas_mes_actual = 0 THEN 'PENDIENTE LA REUNIÓN DE ESTE MES'
        ELSE 'REUNIÓN MENSUAL AL DÍA'
    END AS diagnostico
FROM resumen;

-- ----------------------------------------------------------------------------
-- 4. SEGURIDAD POR FILAS
-- ----------------------------------------------------------------------------
SELECT seguridad.fn_aplicar_politicas('gestion_documental.reunion', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.reunion_asistente',
    'EXISTS (SELECT 1 FROM gestion_documental.reunion r WHERE r.id_reunion = reunion_asistente.id_reunion)',
    'EXISTS (SELECT 1 FROM gestion_documental.reunion r WHERE r.id_reunion = reunion_asistente.id_reunion)');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.reunion_punto',
    'EXISTS (SELECT 1 FROM gestion_documental.reunion r WHERE r.id_reunion = reunion_punto.id_reunion)',
    'EXISTS (SELECT 1 FROM gestion_documental.reunion r WHERE r.id_reunion = reunion_punto.id_reunion)');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.reunion_decision',
    'EXISTS (SELECT 1 FROM gestion_documental.reunion r WHERE r.id_reunion = reunion_decision.id_reunion)',
    'EXISTS (SELECT 1 FROM gestion_documental.reunion r WHERE r.id_reunion = reunion_decision.id_reunion)');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.reunion_firma',
    'EXISTS (SELECT 1 FROM gestion_documental.reunion r WHERE r.id_reunion = reunion_firma.id_reunion)', 'false');

-- ----------------------------------------------------------------------------
-- 5. CORREOS DE CONVOCATORIA Y CANCELACIÓN (los envía el proceso de notificaciones)
-- ----------------------------------------------------------------------------
INSERT INTO notificaciones.tipo_notificacion (codigo, nombre, descripcion) VALUES
    ('CONVOCATORIA', 'Convocatoria a reunión de junta',
     'A cada directivo vigente de la junta, al registrar la convocatoria: tipo, fecha, hora, modalidad, lugar y orden del día. '
     'Si el envío falla se reintenta hasta las 8:00 p. m. y mientras la reunión no haya empezado.'),
    ('CANCELACION_REUNION', 'Cancelación de reunión de junta',
     'A cada directivo vigente de la junta cuando el Presidente o el Secretario General cancela una reunión convocada.')
ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, descripcion = EXCLUDED.descripcion;
