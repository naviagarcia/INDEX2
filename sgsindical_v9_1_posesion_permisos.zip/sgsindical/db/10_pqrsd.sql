-- ============================================================================
-- SGSINDICAL v9.1 — 10: PQRSD RECIBIDAS (peticiones, quejas, reclamos, sugerencias, denuncias,
-- consultas, solicitudes de documentos y felicitaciones que llegan AL sindicato)
-- Ejecutar DESPUÉS de 09. No modifica los scripts anteriores: los complementa.
-- ----------------------------------------------------------------------------
--  Base legal: Ley 1755 de 2015 (derecho de petición, también ante organizaciones privadas, arts. 32-33).
--  Decisiones de la Junta (todas son parámetros que se pueden ajustar):
--   Q1. PLAZOS en días hábiles: petición, queja, reclamo, sugerencia, denuncia y felicitación 15;
--       solicitud de documentos o información 10 (si vence sin respuesta se entiende aceptada y los
--       documentos se entregan dentro de los 3 días siguientes); consulta 30.
--   Q2. RECEPCIÓN solo por el correo institucional (el papel se escanea y se envía al buzón). Lo que llega
--       a partir de las 5 p. m. o en día no hábil se cuenta desde el día hábil siguiente; los días
--       empiezan a contar al día siguiente. Los cierres internos del sindicato NO suspenden plazos.
--   Q3. NO SE TRAMITAN ANÓNIMAS: se registran y se archivan con la constancia "anónima, no se tramita".
--   Q4. PRÓRROGA: antes del vencimiento, con motivo y aviso al peticionario; el plazo total no puede
--       pasar del doble del inicial (art. 14, parágrafo).
--   Q5. SOLICITUD INCOMPLETA (art. 17): se pide completarla dentro de los 10 días hábiles siguientes a la
--       radicación; el plazo para responder se suspende. El peticionario tiene 1 mes, prorrogable por otro
--       mes si lo pide. Si no completa, se declara el desistimiento tácito y se archiva (puede volver a
--       presentarla). Al completarla, el plazo se reanuda con los días que le quedaban.
--   Q6. TRASLADO (art. 21): dentro de los 5 días hábiles siguientes al recibo, con copia al peticionario.
--       A otra junta del sindicato: el plazo vuelve a empezar desde que la recibe. A una entidad externa:
--       el trámite termina aquí.
--   Q7. DENUNCIAS: revisión jurídica obligatoria (abogado del ámbito o Secretario Jurídico) antes de
--       responder.
--   Q8. QUIÉN DECIDE: prórroga, requerimiento, desistimiento, traslado y firma de la respuesta los hace
--       el Presidente, el Vicepresidente, el Secretario General o el Fiscal de la junta (o los nacionales).
--       Registrar la PQRSD lo pueden hacer ellos y la Ventanilla de la junta.
--   Q9. ALERTAS al 50 % y al 80 % del plazo y al vencer (tablero y correo a esos cuatro cargos).
--  Todo queda en una historia inmutable de actuaciones; nada se borra.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. TIPOS, PLAZOS Y PARÁMETROS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gestion_documental.tipo_pqrsd (
    codigo VARCHAR(14) PRIMARY KEY,
    nombre VARCHAR(60) NOT NULL,
    dias_habiles INT NOT NULL CHECK (dias_habiles BETWEEN 1 AND 90),
    revision_juridica BOOLEAN NOT NULL DEFAULT FALSE,
    silencio_positivo BOOLEAN NOT NULL DEFAULT FALSE,
    fundamento TEXT NOT NULL,
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gestion_documental.tipo_pqrsd IS 'Tipos de PQRSD recibidas y su plazo de respuesta en días hábiles (Ley 1755 de 2015, art. 14).';
INSERT INTO gestion_documental.tipo_pqrsd (codigo, nombre, dias_habiles, revision_juridica, silencio_positivo, fundamento) VALUES
    ('PETICION', 'Petición', 15, FALSE, FALSE, 'Ley 1755 de 2015, art. 14: término general de 15 días hábiles.'),
    ('QUEJA', 'Queja', 15, FALSE, FALSE, 'Ley 1755 de 2015, arts. 13 y 14: término general.'),
    ('RECLAMO', 'Reclamo', 15, FALSE, FALSE, 'Ley 1755 de 2015, arts. 13 y 14: término general.'),
    ('SUGERENCIA', 'Sugerencia', 15, FALSE, FALSE, 'Ley 1755 de 2015, art. 14: término general.'),
    ('DENUNCIA', 'Denuncia', 15, TRUE, FALSE, 'Ley 1755 de 2015, art. 14: término general. Revisión jurídica obligatoria (decisión de la Junta).'),
    ('CONSULTA', 'Consulta', 30, FALSE, FALSE, 'Ley 1755 de 2015, art. 14, num. 2: consultas en 30 días hábiles.'),
    ('DOCUMENTOS', 'Solicitud de documentos o información', 10, FALSE, TRUE,
     'Ley 1755 de 2015, art. 14, num. 1: 10 días hábiles; si no se responde a tiempo se entiende aceptada y se entregan dentro de los 3 días siguientes.'),
    ('FELICITACION', 'Felicitación', 15, FALSE, FALSE, 'No es una petición; se responde en el término general por cortesía (decisión de la Junta).')
ON CONFLICT (codigo) DO NOTHING;

CREATE TABLE IF NOT EXISTS gestion_documental.parametro_pqrsd (
    codigo VARCHAR(40) PRIMARY KEY,
    valor NUMERIC NOT NULL,
    descripcion TEXT NOT NULL,
    version INT NOT NULL DEFAULT 1
);
INSERT INTO gestion_documental.parametro_pqrsd (codigo, valor, descripcion) VALUES
    ('DIAS_PEDIR_COMPLETAR', 10, 'Días hábiles desde la radicación para pedir al peticionario que complete la solicitud (art. 17).'),
    ('MESES_COMPLETAR', 1, 'Meses que tiene el peticionario para completar la solicitud (art. 17).'),
    ('MESES_PRORROGA_COMPLETAR', 1, 'Meses adicionales si el peticionario pide más tiempo para completar (art. 17).'),
    ('DIAS_TRASLADO', 5, 'Días hábiles desde el recibo para trasladar por falta de competencia (art. 21).'),
    ('DIAS_ENTREGA_SILENCIO', 3, 'Días hábiles para entregar los documentos cuando la solicitud se entiende aceptada (art. 14, num. 1).'),
    ('ALERTA_MEDIA_PCT', 50, 'Porcentaje del plazo consumido para la alerta media.'),
    ('ALERTA_ALTA_PCT', 80, 'Porcentaje del plazo consumido para la alerta alta.'),
    ('DIAS_REGISTRO_TARDIO', 2, 'Días hábiles después de recibido el correo a partir de los cuales el registro exige explicar la demora.')
ON CONFLICT (codigo) DO NOTHING;

CREATE OR REPLACE FUNCTION gestion_documental.fn_parametro_pqrsd(p_codigo TEXT)
RETURNS NUMERIC AS $$
    SELECT valor FROM gestion_documental.parametro_pqrsd WHERE codigo = p_codigo;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gestion_documental.fn_hoy()
RETURNS DATE AS $$
    SELECT (now() AT TIME ZONE gestion_documental.fn_zona())::DATE;
$$ LANGUAGE sql STABLE;

-- ----------------------------------------------------------------------------
-- 2. QUIÉN PUEDE HACER QUÉ
-- ----------------------------------------------------------------------------
-- Presidente, Vicepresidente, Secretario General o Fiscal de la junta, o los nacionales
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_autorizado(p_id_estamento BIGINT)
RETURNS BOOLEAN AS $$
    SELECT seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'VICE\_%', 'SGEN\_%', 'FIS\_%'], p_id_estamento)
        OR seguridad.fn_tiene_cargo(ARRAY['PRES\_NAL', 'VICE\_NAL', 'SGEN\_NAL', 'FIS\_NAL']);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Cargo con el que firma el usuario actual (el de la junta primero, si no el nacional)
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_cargo_firmante(p_id_estamento BIGINT)
RETURNS TEXT AS $$
    SELECT c.nombre || ' — ' || e.nombre_estamento
      FROM seguridad.usuario u
      JOIN gobernanza.directivo_estamento d ON d.id_persona = u.id_persona AND d.fecha_retiro IS NULL
      JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
      JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento
     WHERE u.id_usuario = seguridad.fn_id_usuario_actual()
       AND (c.codigo LIKE ANY (ARRAY['PRES\_%', 'VICE\_%', 'SGEN\_%', 'FIS\_%']) AND d.id_estamento = p_id_estamento
            OR c.codigo IN ('PRES_NAL', 'VICE_NAL', 'SGEN_NAL', 'FIS_NAL'))
     ORDER BY (d.id_estamento = p_id_estamento) DESC,
              array_position(ARRAY['PRES', 'VICE', 'SGEN', 'FIS'], split_part(c.codigo, '_', 1))
     LIMIT 1;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Revisión jurídica: usuario con rol ABOGADO y ámbito sobre la junta, o Secretario Jurídico (de la junta o nacional)
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_es_juridico(p_id_estamento BIGINT)
RETURNS BOOLEAN AS $$
    SELECT (seguridad.fn_rol_actual() = 'ABOGADO'
            AND (seguridad.fn_ambito_nacional() OR p_id_estamento = ANY(seguridad.fn_ambito_estamentos())))
        OR seguridad.fn_tiene_cargo(ARRAY['SJUR\_%'], p_id_estamento)
        OR seguridad.fn_tiene_cargo(ARRAY['SJUR\_NAL']);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_exigir_autorizado(p_id_estamento BIGINT, p_accion TEXT)
RETURNS VOID AS $$
BEGIN
    IF NOT gestion_documental.fn_pqrsd_autorizado(p_id_estamento) THEN
        RAISE EXCEPTION '% lo hacen el Presidente, el Vicepresidente, el Secretario General o el Fiscal de la junta.', p_accion
            USING ERRCODE = 'insufficient_privilege';
    END IF;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 3. LA PQRSD Y SU HISTORIA
-- ----------------------------------------------------------------------------
CREATE SEQUENCE IF NOT EXISTS gestion_documental.seq_pqrsd;
CREATE TABLE IF NOT EXISTS gestion_documental.pqrsd (
    id_pqrsd BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    radicado VARCHAR(24) NOT NULL UNIQUE,
    tipo VARCHAR(14) NOT NULL REFERENCES gestion_documental.tipo_pqrsd(codigo) ON DELETE RESTRICT,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    -- Peticionario
    anonima BOOLEAN NOT NULL DEFAULT FALSE,
    nombre_peticionario VARCHAR(150),
    tipo_documento VARCHAR(10),
    numero_documento VARCHAR(20),
    correo_peticionario VARCHAR(150),
    telefono_peticionario VARCHAR(20),
    id_persona BIGINT REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    -- Contenido y recepción
    asunto VARCHAR(200) NOT NULL,
    descripcion TEXT NOT NULL,
    medio VARCHAR(10) NOT NULL DEFAULT 'CORREO' CHECK (medio = 'CORREO'),
    fecha_recepcion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    motivo_registro_tardio TEXT,
    id_documento_soporte BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    -- Términos
    fecha_base DATE NOT NULL,
    plazo_dias INT NOT NULL,
    dias_prorroga INT NOT NULL DEFAULT 0,
    fecha_limite DATE NOT NULL,
    motivo_prorroga TEXT,
    fecha_prorroga TIMESTAMP WITH TIME ZONE,
    -- Solicitud incompleta (art. 17)
    texto_requerimiento TEXT,
    fecha_requerimiento DATE,
    dias_restantes_suspension INT,
    fecha_limite_completar DATE,
    prorroga_completar BOOLEAN NOT NULL DEFAULT FALSE,
    fecha_completada TIMESTAMP WITH TIME ZONE,
    -- Traslado
    id_estamento_origen BIGINT REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    entidad_traslado VARCHAR(200),
    traslado_tardio BOOLEAN NOT NULL DEFAULT FALSE,
    -- Revisión jurídica
    concepto_juridico TEXT,
    fecha_concepto TIMESTAMP WITH TIME ZONE,
    usuario_concepto VARCHAR(50),
    -- Respuesta
    estado VARCHAR(18) NOT NULL DEFAULT 'RADICADA'
        CHECK (estado IN ('RADICADA', 'EN_TRAMITE', 'EN_REQUERIMIENTO', 'RESPONDIDA', 'TRASLADADA', 'DESISTIDA', 'ARCHIVADA_ANONIMA')),
    respuesta TEXT,
    fecha_respuesta TIMESTAMP WITH TIME ZONE,
    usuario_respuesta VARCHAR(50),
    cargo_firma VARCHAR(200),
    huella_respuesta VARCHAR(64),
    id_documento_respuesta BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    fecha_cierre TIMESTAMP WITH TIME ZONE,
    observacion_cierre TEXT,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_pqrsd_identificada CHECK (anonima OR (nombre_peticionario IS NOT NULL AND numero_documento IS NOT NULL
                                                        AND correo_peticionario IS NOT NULL)),
    CONSTRAINT ck_pqrsd_correo CHECK (correo_peticionario IS NULL OR correo_peticionario ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$')
);
COMMENT ON TABLE gestion_documental.pqrsd IS 'PQRSD que recibe el sindicato por su correo institucional, con plazos en días hábiles (Ley 1755 de 2015).';
CREATE INDEX IF NOT EXISTS ix_pqrsd_estamento ON gestion_documental.pqrsd (id_estamento);
CREATE INDEX IF NOT EXISTS ix_pqrsd_persona ON gestion_documental.pqrsd (id_persona);
CREATE INDEX IF NOT EXISTS ix_pqrsd_soporte ON gestion_documental.pqrsd (id_documento_soporte);
CREATE INDEX IF NOT EXISTS ix_pqrsd_respuesta ON gestion_documental.pqrsd (id_documento_respuesta);
CREATE INDEX IF NOT EXISTS ix_pqrsd_origen ON gestion_documental.pqrsd (id_estamento_origen);
CREATE INDEX IF NOT EXISTS ix_pqrsd_tipo ON gestion_documental.pqrsd (tipo);
CREATE INDEX IF NOT EXISTS ix_pqrsd_abiertas ON gestion_documental.pqrsd (fecha_limite)
    WHERE estado IN ('RADICADA', 'EN_TRAMITE', 'EN_REQUERIMIENTO');

CREATE TABLE IF NOT EXISTS gestion_documental.pqrsd_actuacion (
    id_actuacion BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_pqrsd BIGINT NOT NULL REFERENCES gestion_documental.pqrsd(id_pqrsd) ON DELETE RESTRICT,
    fecha TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    tipo VARCHAR(22) NOT NULL CHECK (tipo IN ('RADICACION', 'ARCHIVO_ANONIMA', 'EN_TRAMITE', 'PRORROGA', 'REQUERIMIENTO',
                                             'PRORROGA_COMPLETAR', 'COMPLETADA', 'DESISTIMIENTO', 'TRASLADO_INTERNO',
                                             'TRASLADO_EXTERNO', 'CONCEPTO_JURIDICO', 'RESPUESTA', 'CORREO_ENVIADO',
                                             'CORREO_NO_ENVIADO', 'NOTA')),
    detalle TEXT NOT NULL,
    usuario VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual()
);
COMMENT ON TABLE gestion_documental.pqrsd_actuacion IS 'Historia inmutable de cada PQRSD: radicación, prórrogas, requerimientos, traslados, concepto jurídico, respuesta y correos.';
CREATE INDEX IF NOT EXISTS ix_pqrsd_actuacion ON gestion_documental.pqrsd_actuacion (id_pqrsd, fecha);

DROP TRIGGER IF EXISTS trg_actuacion_inmutable ON gestion_documental.pqrsd_actuacion;
CREATE TRIGGER trg_actuacion_inmutable BEFORE UPDATE OR DELETE ON gestion_documental.pqrsd_actuacion
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_bloquear_modificacion();

CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_anotar(p_id BIGINT, p_tipo TEXT, p_detalle TEXT)
RETURNS VOID AS $$
    INSERT INTO gestion_documental.pqrsd_actuacion (id_pqrsd, tipo, detalle) VALUES (p_id, p_tipo, p_detalle);
$$ LANGUAGE sql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 4. REGLAS AL RADICAR Y AL MODIFICAR
-- ----------------------------------------------------------------------------
-- ¿El cambio lo hace una función autorizada de este script? La variable pqrsd.operacion la puede fijar
-- cualquiera, así que además se exige que quien ejecuta sea el dueño de la tabla (las funciones SECURITY
-- DEFINER corren como él) o un superusuario. La cuenta de la aplicación nunca cumple esa condición.
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_operacion_interna()
RETURNS BOOLEAN AS $$
    SELECT COALESCE(current_setting('pqrsd.operacion', true), '') <> ''
       AND EXISTS (SELECT 1 FROM pg_roles r WHERE r.rolname = current_user
                      AND (r.rolsuper OR r.oid = (SELECT relowner FROM pg_class WHERE oid = 'gestion_documental.pqrsd'::regclass)));
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE FUNCTION gestion_documental.fn_proteger_pqrsd()
RETURNS TRIGGER AS $$
DECLARE v_tipo gestion_documental.tipo_pqrsd%ROWTYPE; v_rol TEXT := seguridad.fn_rol_actual();
BEGIN
    IF gestion_documental.fn_pqrsd_operacion_interna() THEN RETURN NEW; END IF;
    IF TG_OP = 'INSERT' THEN
        -- Registran los cuatro cargos de la junta y la Ventanilla (con ámbito sobre la junta, lo controla la seguridad por filas)
        IF NOT (gestion_documental.fn_pqrsd_autorizado(NEW.id_estamento) OR v_rol = 'VENTANILLA'
                OR session_user IN (SELECT rolname FROM pg_roles WHERE rolsuper)) THEN
            RAISE EXCEPTION 'Registran las PQRSD la Ventanilla y el Presidente, Vicepresidente, Secretario General o Fiscal de la junta.'
                USING ERRCODE = 'insufficient_privilege';
        END IF;
        SELECT * INTO v_tipo FROM gestion_documental.tipo_pqrsd WHERE codigo = NEW.tipo;
        NEW.fecha_recepcion := COALESCE(NEW.fecha_recepcion, now());
        IF NEW.fecha_recepcion > now() + INTERVAL '10 minutes' THEN
            RAISE EXCEPTION 'La fecha y hora de recepción del correo no puede ser futura.';
        END IF;
        NEW.medio := 'CORREO';
        NEW.asunto := trim(NEW.asunto); NEW.descripcion := trim(NEW.descripcion);
        NEW.nombre_peticionario := NULLIF(upper(trim(COALESCE(NEW.nombre_peticionario, ''))), '');
        NEW.numero_documento := NULLIF(regexp_replace(COALESCE(NEW.numero_documento, ''), '[^0-9A-Za-z]', '', 'g'), '');
        NEW.correo_peticionario := NULLIF(lower(trim(COALESCE(NEW.correo_peticionario, ''))), '');
        IF length(NEW.descripcion) < 10 THEN RAISE EXCEPTION 'Copie el contenido de la solicitud (mínimo 10 caracteres).'; END IF;
        -- La anónima (sin nombre ni documento) se registra y se archiva (Q3); si el peticionario se identifica,
        -- faltar el documento o el correo es un error de registro, no una PQRSD anónima.
        NEW.anonima := COALESCE(NEW.anonima, FALSE) OR (NEW.nombre_peticionario IS NULL AND NEW.numero_documento IS NULL);
        IF NOT NEW.anonima AND (NEW.nombre_peticionario IS NULL OR NEW.numero_documento IS NULL OR NEW.correo_peticionario IS NULL) THEN
            RAISE EXCEPTION 'Registre el nombre, el documento y el correo del peticionario. Si la PQRSD llegó sin identificar, márquela como anónima (se archiva sin trámite).';
        END IF;
        NEW.radicado := 'PQRSD-' || to_char(NEW.fecha_recepcion AT TIME ZONE gestion_documental.fn_zona(), 'YYYY') || '-'
                        || lpad(nextval('gestion_documental.seq_pqrsd')::TEXT, 6, '0');
        NEW.fecha_base := gobernanza.fn_dia_base_radicacion(NEW.fecha_recepcion);
        NEW.plazo_dias := v_tipo.dias_habiles;
        NEW.dias_prorroga := 0;
        NEW.fecha_limite := gobernanza.fn_sumar_dias_habiles(NEW.fecha_base, v_tipo.dias_habiles);
        IF NOT NEW.anonima
           AND gobernanza.fn_dias_habiles_entre(NEW.fecha_base, gestion_documental.fn_hoy())
               > gestion_documental.fn_parametro_pqrsd('DIAS_REGISTRO_TARDIO')
           AND length(trim(COALESCE(NEW.motivo_registro_tardio, ''))) < 10 THEN
            RAISE EXCEPTION 'El correo se recibió hace más de % días hábiles: explique por qué se registra tarde (el plazo corre desde que llegó).',
                gestion_documental.fn_parametro_pqrsd('DIAS_REGISTRO_TARDIO');
        END IF;
        NEW.estado := CASE WHEN NEW.anonima THEN 'ARCHIVADA_ANONIMA' ELSE 'RADICADA' END;
        NEW.fecha_cierre := CASE WHEN NEW.anonima THEN now() END;
        NEW.observacion_cierre := CASE WHEN NEW.anonima THEN 'Anónima, no se tramita (decisión de la Junta). Queda la constancia de recibido.' END;
        NEW.motivo_prorroga := NULL; NEW.fecha_prorroga := NULL; NEW.texto_requerimiento := NULL; NEW.fecha_requerimiento := NULL;
        NEW.dias_restantes_suspension := NULL; NEW.fecha_limite_completar := NULL; NEW.prorroga_completar := FALSE;
        NEW.fecha_completada := NULL; NEW.id_estamento_origen := NULL; NEW.entidad_traslado := NULL; NEW.traslado_tardio := FALSE;
        NEW.concepto_juridico := NULL; NEW.fecha_concepto := NULL; NEW.usuario_concepto := NULL;
        NEW.respuesta := NULL; NEW.fecha_respuesta := NULL; NEW.usuario_respuesta := NULL; NEW.cargo_firma := NULL;
        NEW.huella_respuesta := NULL; NEW.id_documento_respuesta := NULL;
        RETURN NEW;
    END IF;
    -- Modificación directa: solo datos de contacto, vínculo con la persona, soporte y pasar a "en trámite"
    IF OLD.estado IN ('RESPONDIDA', 'TRASLADADA', 'DESISTIDA', 'ARCHIVADA_ANONIMA') THEN
        RAISE EXCEPTION 'Una PQRSD cerrada (%) no se modifica.', lower(replace(OLD.estado, '_', ' '));
    END IF;
    IF NOT (gestion_documental.fn_pqrsd_autorizado(OLD.id_estamento) OR v_rol = 'VENTANILLA'
            OR session_user IN (SELECT rolname FROM pg_roles WHERE rolsuper)) THEN
        RAISE EXCEPTION 'Completan los datos de una PQRSD la Ventanilla y los cuatro cargos de la junta.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF (to_jsonb(NEW) - ARRAY['telefono_peticionario', 'id_persona', 'id_documento_soporte', 'version'])
       IS DISTINCT FROM (to_jsonb(OLD) - ARRAY['telefono_peticionario', 'id_persona', 'id_documento_soporte', 'version']) THEN
        RAISE EXCEPTION 'El radicado, el peticionario, el contenido, el estado y los plazos no se cambian: use las acciones (en trámite, prorrogar, pedir completar, trasladar, responder).';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_proteger_pqrsd ON gestion_documental.pqrsd;
CREATE TRIGGER trg_proteger_pqrsd BEFORE INSERT OR UPDATE ON gestion_documental.pqrsd
    FOR EACH ROW EXECUTE FUNCTION gestion_documental.fn_proteger_pqrsd();

CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_al_radicar()
RETURNS TRIGGER AS $$
BEGIN
    PERFORM gestion_documental.fn_pqrsd_anotar(NEW.id_pqrsd, 'RADICACION',
        format('Recibida por correo el %s. Tipo: %s. Plazo: %s días hábiles, vence el %s.%s',
               to_char(NEW.fecha_recepcion AT TIME ZONE gestion_documental.fn_zona(), 'DD/MM/YYYY HH24:MI'),
               (SELECT nombre FROM gestion_documental.tipo_pqrsd WHERE codigo = NEW.tipo), NEW.plazo_dias,
               to_char(NEW.fecha_limite, 'DD/MM/YYYY'),
               CASE WHEN NEW.motivo_registro_tardio IS NOT NULL THEN ' Registro tardío: ' || NEW.motivo_registro_tardio ELSE '' END));
    IF NEW.anonima THEN
        PERFORM gestion_documental.fn_pqrsd_anotar(NEW.id_pqrsd, 'ARCHIVO_ANONIMA', NEW.observacion_cierre);
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
DROP TRIGGER IF EXISTS trg_pqrsd_al_radicar ON gestion_documental.pqrsd;
CREATE TRIGGER trg_pqrsd_al_radicar AFTER INSERT ON gestion_documental.pqrsd
    FOR EACH ROW EXECUTE FUNCTION gestion_documental.fn_pqrsd_al_radicar();

-- Carga una PQRSD abierta y visible para el usuario, bloqueándola
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_cargar(p_id BIGINT)
RETURNS gestion_documental.pqrsd AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE;
BEGIN
    SELECT * INTO v FROM gestion_documental.pqrsd WHERE id_pqrsd = p_id FOR UPDATE;
    IF v.id_pqrsd IS NULL OR NOT (seguridad.fn_ambito_nacional() OR v.id_estamento = ANY(seguridad.fn_ambito_estamentos())) THEN
        RAISE EXCEPTION 'La PQRSD no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v.estado IN ('RESPONDIDA', 'TRASLADADA', 'DESISTIDA', 'ARCHIVADA_ANONIMA') THEN
        RAISE EXCEPTION 'La PQRSD % ya está cerrada (%).', v.radicado, lower(replace(v.estado, '_', ' '));
    END IF;
    RETURN v;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 5. ACCIONES
-- ----------------------------------------------------------------------------
-- Pasar a trámite (la Ventanilla o los cuatro cargos)
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_en_tramite(p_id BIGINT)
RETURNS VOID AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    IF NOT (gestion_documental.fn_pqrsd_autorizado(v.id_estamento) OR seguridad.fn_rol_actual() = 'VENTANILLA') THEN
        RAISE EXCEPTION 'Pasan a trámite la Ventanilla y los cuatro cargos de la junta.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF v.estado <> 'RADICADA' THEN RAISE EXCEPTION 'La PQRSD ya está en trámite.'; END IF;
    PERFORM set_config('pqrsd.operacion', 'tramite', true);
    UPDATE gestion_documental.pqrsd SET estado = 'EN_TRAMITE' WHERE id_pqrsd = p_id;
    PERFORM set_config('pqrsd.operacion', '', true);
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'EN_TRAMITE', 'La PQRSD pasó a trámite.');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Prórroga (art. 14, parágrafo): antes del vencimiento; el plazo total no pasa del doble del inicial
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_prorrogar(p_id BIGINT, p_dias INT, p_motivo TEXT)
RETURNS DATE AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE; v_nueva DATE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    PERFORM gestion_documental.fn_pqrsd_exigir_autorizado(v.id_estamento, 'La prórroga la autorizan');
    IF length(trim(COALESCE(p_motivo, ''))) < 15 THEN RAISE EXCEPTION 'Escriba el motivo de la prórroga que se le informará al peticionario (mínimo 15 caracteres).'; END IF;
    IF v.estado = 'EN_REQUERIMIENTO' THEN RAISE EXCEPTION 'El plazo está suspendido mientras el peticionario completa la solicitud.'; END IF;
    IF v.dias_prorroga > 0 THEN RAISE EXCEPTION 'Esta PQRSD ya fue prorrogada.'; END IF;
    IF gestion_documental.fn_hoy() > v.fecha_limite THEN
        RAISE EXCEPTION 'El plazo venció el %: la prórroga se informa antes del vencimiento.', to_char(v.fecha_limite, 'DD/MM/YYYY');
    END IF;
    IF p_dias IS NULL OR p_dias < 1 OR p_dias > v.plazo_dias THEN
        RAISE EXCEPTION 'La prórroga va de 1 a % días hábiles: el plazo total no puede pasar del doble del inicial (Ley 1755, art. 14).', v.plazo_dias;
    END IF;
    v_nueva := gobernanza.fn_sumar_dias_habiles(v.fecha_limite, p_dias);
    PERFORM set_config('pqrsd.operacion', 'prorrogar', true);
    UPDATE gestion_documental.pqrsd SET dias_prorroga = p_dias, fecha_limite = v_nueva, motivo_prorroga = trim(p_motivo),
           fecha_prorroga = now(), estado = 'EN_TRAMITE' WHERE id_pqrsd = p_id;
    PERFORM set_config('pqrsd.operacion', '', true);
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'PRORROGA',
        format('Prórroga de %s días hábiles: nueva fecha límite %s. Motivo: %s', p_dias, to_char(v_nueva, 'DD/MM/YYYY'), trim(p_motivo)));
    RETURN v_nueva;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Solicitud incompleta (art. 17): pedir completar dentro de los 10 días hábiles; el plazo se suspende
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_pedir_completar(p_id BIGINT, p_texto TEXT)
RETURNS DATE AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE; v_hoy DATE := gestion_documental.fn_hoy(); v_hasta DATE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    PERFORM gestion_documental.fn_pqrsd_exigir_autorizado(v.id_estamento, 'El requerimiento para completar lo hacen');
    IF length(trim(COALESCE(p_texto, ''))) < 20 THEN RAISE EXCEPTION 'Explique qué información o documentos faltan (mínimo 20 caracteres).'; END IF;
    IF v.estado = 'EN_REQUERIMIENTO' OR v.fecha_requerimiento IS NOT NULL THEN
        RAISE EXCEPTION 'Ya se le pidió al peticionario completar esta solicitud.';
    END IF;
    IF gobernanza.fn_dias_habiles_entre(v.fecha_base, v_hoy) > gestion_documental.fn_parametro_pqrsd('DIAS_PEDIR_COMPLETAR') THEN
        RAISE EXCEPTION 'Pasaron más de % días hábiles desde la radicación: ya no se puede pedir completar (Ley 1755, art. 17); hay que resolver con lo que hay.',
            gestion_documental.fn_parametro_pqrsd('DIAS_PEDIR_COMPLETAR');
    END IF;
    v_hasta := v_hoy + make_interval(months => gestion_documental.fn_parametro_pqrsd('MESES_COMPLETAR')::INT);
    PERFORM set_config('pqrsd.operacion', 'requerir', true);
    UPDATE gestion_documental.pqrsd SET estado = 'EN_REQUERIMIENTO', texto_requerimiento = trim(p_texto), fecha_requerimiento = v_hoy,
           dias_restantes_suspension = GREATEST(gobernanza.fn_dias_habiles_entre(GREATEST(v_hoy, v.fecha_base), v.fecha_limite), 1),
           fecha_limite_completar = v_hasta WHERE id_pqrsd = p_id;
    PERFORM set_config('pqrsd.operacion', '', true);
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'REQUERIMIENTO',
        format('Se pidió completar la solicitud; el plazo para responder queda suspendido. Tiene hasta el %s. Falta: %s',
               to_char(v_hasta, 'DD/MM/YYYY'), trim(p_texto)));
    RETURN v_hasta;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- El peticionario pide más tiempo para completar: un mes más, una sola vez
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_prorrogar_completar(p_id BIGINT, p_motivo TEXT)
RETURNS DATE AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE; v_hasta DATE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    PERFORM gestion_documental.fn_pqrsd_exigir_autorizado(v.id_estamento, 'La ampliación del plazo para completar la conceden');
    IF v.estado <> 'EN_REQUERIMIENTO' THEN RAISE EXCEPTION 'La PQRSD no está esperando que el peticionario la complete.'; END IF;
    IF v.prorroga_completar THEN RAISE EXCEPTION 'El plazo para completar ya se amplió una vez (la ley permite solo una).'; END IF;
    IF gestion_documental.fn_hoy() > v.fecha_limite_completar THEN
        RAISE EXCEPTION 'El plazo para completar venció el %: la ampliación se pide antes.', to_char(v.fecha_limite_completar, 'DD/MM/YYYY');
    END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Anote cómo y cuándo lo pidió el peticionario (mínimo 10 caracteres).'; END IF;
    v_hasta := v.fecha_limite_completar + make_interval(months => gestion_documental.fn_parametro_pqrsd('MESES_PRORROGA_COMPLETAR')::INT);
    PERFORM set_config('pqrsd.operacion', 'prorrogar_completar', true);
    UPDATE gestion_documental.pqrsd SET prorroga_completar = TRUE, fecha_limite_completar = v_hasta WHERE id_pqrsd = p_id;
    PERFORM set_config('pqrsd.operacion', '', true);
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'PRORROGA_COMPLETAR',
        format('El peticionario pidió más tiempo; tiene hasta el %s. %s', to_char(v_hasta, 'DD/MM/YYYY'), trim(p_motivo)));
    RETURN v_hasta;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- El peticionario completó: el plazo se reanuda con los días que quedaban, desde el día siguiente
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_completada(p_id BIGINT, p_detalle TEXT, p_momento TIMESTAMPTZ DEFAULT NULL)
RETURNS DATE AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE; v_momento TIMESTAMPTZ := COALESCE(p_momento, now()); v_nueva DATE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    IF NOT (gestion_documental.fn_pqrsd_autorizado(v.id_estamento) OR seguridad.fn_rol_actual() = 'VENTANILLA') THEN
        RAISE EXCEPTION 'Registran la información recibida la Ventanilla y los cuatro cargos de la junta.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF v.estado <> 'EN_REQUERIMIENTO' THEN RAISE EXCEPTION 'La PQRSD no está esperando que el peticionario la complete.'; END IF;
    IF v_momento > now() + INTERVAL '10 minutes' OR (v_momento AT TIME ZONE gestion_documental.fn_zona())::DATE < v.fecha_requerimiento THEN
        RAISE EXCEPTION 'La fecha de recibo de la información no es válida.';
    END IF;
    IF (v_momento AT TIME ZONE gestion_documental.fn_zona())::DATE > v.fecha_limite_completar THEN
        RAISE EXCEPTION 'La información llegó después del plazo para completar (%): corresponde declarar el desistimiento; el peticionario puede presentarla de nuevo.',
            to_char(v.fecha_limite_completar, 'DD/MM/YYYY');
    END IF;
    IF length(trim(COALESCE(p_detalle, ''))) < 10 THEN RAISE EXCEPTION 'Describa qué aportó el peticionario (mínimo 10 caracteres).'; END IF;
    v_nueva := gobernanza.fn_sumar_dias_habiles(gobernanza.fn_dia_base_radicacion(v_momento), v.dias_restantes_suspension);
    PERFORM set_config('pqrsd.operacion', 'completar', true);
    UPDATE gestion_documental.pqrsd SET estado = 'EN_TRAMITE', fecha_completada = v_momento, fecha_limite = v_nueva WHERE id_pqrsd = p_id;
    PERFORM set_config('pqrsd.operacion', '', true);
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'COMPLETADA',
        format('El peticionario completó la solicitud. El plazo se reanuda con %s día(s) hábil(es): nueva fecha límite %s. %s',
               v.dias_restantes_suspension, to_char(v_nueva, 'DD/MM/YYYY'), trim(p_detalle)));
    RETURN v_nueva;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Desistimiento tácito (art. 17): venció el plazo para completar sin respuesta del peticionario
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_desistimiento(p_id BIGINT, p_motivo TEXT)
RETURNS VOID AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    PERFORM gestion_documental.fn_pqrsd_exigir_autorizado(v.id_estamento, 'El desistimiento lo declaran');
    IF v.estado <> 'EN_REQUERIMIENTO' THEN RAISE EXCEPTION 'Solo se declara el desistimiento de una solicitud que se pidió completar.'; END IF;
    IF gestion_documental.fn_hoy() <= v.fecha_limite_completar THEN
        RAISE EXCEPTION 'El peticionario todavía tiene plazo para completar (hasta el %).', to_char(v.fecha_limite_completar, 'DD/MM/YYYY');
    END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 15 THEN RAISE EXCEPTION 'Escriba la decisión motivada del desistimiento (mínimo 15 caracteres).'; END IF;
    PERFORM set_config('pqrsd.operacion', 'desistir', true);
    UPDATE gestion_documental.pqrsd SET estado = 'DESISTIDA', fecha_cierre = now(), observacion_cierre = trim(p_motivo),
           usuario_respuesta = auditoria.fn_usuario_actual(), cargo_firma = gestion_documental.fn_pqrsd_cargo_firmante(v.id_estamento)
     WHERE id_pqrsd = p_id;
    PERFORM set_config('pqrsd.operacion', '', true);
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'DESISTIMIENTO',
        'Desistimiento tácito: el peticionario no completó la solicitud a tiempo. Puede presentarla de nuevo. ' || trim(p_motivo));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Traslado por falta de competencia (art. 21): a otra junta (el plazo vuelve a empezar) o a una entidad externa (se cierra)
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_trasladar(p_id BIGINT, p_id_estamento_destino BIGINT, p_entidad TEXT, p_motivo TEXT)
RETURNS TEXT AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE; v_tardio BOOLEAN; v_base DATE; v_dias_usados INT; v_destino TEXT;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    PERFORM gestion_documental.fn_pqrsd_exigir_autorizado(v.id_estamento, 'El traslado lo hacen');
    IF (p_id_estamento_destino IS NULL) = (NULLIF(trim(COALESCE(p_entidad, '')), '') IS NULL) THEN
        RAISE EXCEPTION 'Indique la junta del sindicato o la entidad externa competente (solo una).';
    END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 15 THEN RAISE EXCEPTION 'Explique por qué no es competente esta junta (mínimo 15 caracteres).'; END IF;
    IF v.estado = 'EN_REQUERIMIENTO' THEN RAISE EXCEPTION 'Primero resuelva el requerimiento al peticionario.'; END IF;
    v_dias_usados := gobernanza.fn_dias_habiles_entre(v.fecha_base, gestion_documental.fn_hoy());
    v_tardio := v_dias_usados > gestion_documental.fn_parametro_pqrsd('DIAS_TRASLADO');
    PERFORM set_config('pqrsd.operacion', 'trasladar', true);
    IF p_id_estamento_destino IS NOT NULL THEN
        IF p_id_estamento_destino = v.id_estamento THEN RAISE EXCEPTION 'La junta de destino es la misma.'; END IF;
        SELECT nombre_estamento INTO v_destino FROM gobernanza.estamento WHERE id_estamento = p_id_estamento_destino;
        IF v_destino IS NULL THEN RAISE EXCEPTION 'La junta de destino no existe.'; END IF;
        v_base := gobernanza.fn_dia_base_radicacion(now());
        UPDATE gestion_documental.pqrsd SET id_estamento_origen = COALESCE(id_estamento_origen, id_estamento),
               id_estamento = p_id_estamento_destino, fecha_base = v_base,
               fecha_limite = gobernanza.fn_sumar_dias_habiles(v_base, plazo_dias), dias_prorroga = 0, motivo_prorroga = NULL,
               fecha_prorroga = NULL, fecha_requerimiento = NULL, texto_requerimiento = NULL, dias_restantes_suspension = NULL,
               fecha_limite_completar = NULL, prorroga_completar = FALSE, fecha_completada = NULL, estado = 'RADICADA',
               traslado_tardio = traslado_tardio OR v_tardio
         WHERE id_pqrsd = p_id;
        PERFORM set_config('pqrsd.operacion', '', true);
        PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'TRASLADO_INTERNO',
            format('Trasladada a %s. El plazo de %s días hábiles empieza de nuevo y vence el %s.%s Motivo: %s',
                   v_destino, v.plazo_dias, to_char(gobernanza.fn_sumar_dias_habiles(v_base, v.plazo_dias), 'DD/MM/YYYY'),
                   CASE WHEN v_tardio THEN format(' TRASLADO TARDÍO: pasaron %s días hábiles (máximo %s).', v_dias_usados,
                                                   gestion_documental.fn_parametro_pqrsd('DIAS_TRASLADO')) ELSE '' END,
                   trim(p_motivo)));
        RETURN 'INTERNO';
    END IF;
    UPDATE gestion_documental.pqrsd SET estado = 'TRASLADADA', entidad_traslado = trim(p_entidad), fecha_cierre = now(),
           observacion_cierre = trim(p_motivo), traslado_tardio = traslado_tardio OR v_tardio,
           usuario_respuesta = auditoria.fn_usuario_actual(), cargo_firma = gestion_documental.fn_pqrsd_cargo_firmante(v.id_estamento)
     WHERE id_pqrsd = p_id;
    PERFORM set_config('pqrsd.operacion', '', true);
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'TRASLADO_EXTERNO',
        format('Trasladada por competencia a %s, con copia al peticionario.%s Motivo: %s', trim(p_entidad),
               CASE WHEN v_tardio THEN format(' TRASLADO TARDÍO: pasaron %s días hábiles (máximo %s).', v_dias_usados,
                                               gestion_documental.fn_parametro_pqrsd('DIAS_TRASLADO')) ELSE '' END,
               trim(p_motivo)));
    RETURN 'EXTERNO';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Datos para avisar al peticionario después de un traslado interno (la junta de origen puede dejar de verla)
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_resumen_traslado(p_id BIGINT)
RETURNS SETOF gestion_documental.pqrsd AS $$
    SELECT * FROM gestion_documental.pqrsd
     WHERE id_pqrsd = p_id
       AND (seguridad.fn_ambito_nacional() OR id_estamento = ANY(seguridad.fn_ambito_estamentos())
            OR id_estamento_origen = ANY(seguridad.fn_ambito_estamentos()));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Concepto jurídico (obligatorio para denuncias)
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_concepto(p_id BIGINT, p_concepto TEXT)
RETURNS VOID AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    IF NOT gestion_documental.fn_pqrsd_es_juridico(v.id_estamento) THEN
        RAISE EXCEPTION 'El concepto jurídico lo da el abogado del ámbito de la junta o el Secretario Jurídico.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF length(trim(COALESCE(p_concepto, ''))) < 30 THEN RAISE EXCEPTION 'Escriba el concepto jurídico (mínimo 30 caracteres).'; END IF;
    PERFORM set_config('pqrsd.operacion', 'concepto', true);
    UPDATE gestion_documental.pqrsd SET concepto_juridico = trim(p_concepto), fecha_concepto = now(), usuario_concepto = auditoria.fn_usuario_actual(),
           estado = CASE WHEN estado = 'RADICADA' THEN 'EN_TRAMITE' ELSE estado END
     WHERE id_pqrsd = p_id;
    PERFORM set_config('pqrsd.operacion', '', true);
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'CONCEPTO_JURIDICO', 'Concepto jurídico: ' || trim(p_concepto));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Respuesta firmada por uno de los cuatro cargos
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_responder(p_id BIGINT, p_respuesta TEXT, p_id_documento BIGINT DEFAULT NULL)
RETURNS TEXT AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE; v_tipo gestion_documental.tipo_pqrsd%ROWTYPE; v_cargo TEXT; v_huella TEXT; v_ahora TIMESTAMPTZ := now();
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    PERFORM gestion_documental.fn_pqrsd_exigir_autorizado(v.id_estamento, 'La respuesta la firman');
    SELECT * INTO v_tipo FROM gestion_documental.tipo_pqrsd WHERE codigo = v.tipo;
    IF v.estado = 'EN_REQUERIMIENTO' THEN RAISE EXCEPTION 'La PQRSD espera que el peticionario la complete (o el desistimiento).'; END IF;
    IF v_tipo.revision_juridica AND v.concepto_juridico IS NULL THEN
        RAISE EXCEPTION 'Las % requieren el concepto jurídico antes de responder.', lower(v_tipo.nombre) || 's';
    END IF;
    IF length(trim(COALESCE(p_respuesta, ''))) < 40 THEN RAISE EXCEPTION 'Escriba la respuesta de fondo al peticionario (mínimo 40 caracteres).'; END IF;
    v_cargo := gestion_documental.fn_pqrsd_cargo_firmante(v.id_estamento);
    v_huella := encode(sha256(convert_to(v.radicado || '|' || trim(p_respuesta) || '|' || v_cargo || '|' || v_ahora::TEXT, 'UTF8')), 'hex');
    PERFORM set_config('pqrsd.operacion', 'responder', true);
    UPDATE gestion_documental.pqrsd SET estado = 'RESPONDIDA', respuesta = trim(p_respuesta), fecha_respuesta = v_ahora,
           usuario_respuesta = auditoria.fn_usuario_actual(), cargo_firma = v_cargo, huella_respuesta = v_huella,
           id_documento_respuesta = p_id_documento, fecha_cierre = v_ahora
     WHERE id_pqrsd = p_id;
    PERFORM set_config('pqrsd.operacion', '', true);
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'RESPUESTA',
        format('Respondida y firmada por %s (%s)%s.', auditoria.fn_usuario_actual(), v_cargo,
               CASE WHEN gestion_documental.fn_hoy() > v.fecha_limite THEN ' FUERA DE TÉRMINO (venció el ' || to_char(v.fecha_limite, 'DD/MM/YYYY') || ')'
                    ELSE ' dentro del término' END));
    RETURN v_huella;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- La aplicación deja constancia de los correos enviados al peticionario
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_registrar_correo(p_id BIGINT, p_enviado BOOLEAN, p_detalle TEXT)
RETURNS VOID AS $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM gestion_documental.pqrsd WHERE id_pqrsd = p_id
                    AND (seguridad.fn_ambito_nacional() OR id_estamento = ANY(seguridad.fn_ambito_estamentos())
                         OR id_estamento_origen = ANY(seguridad.fn_ambito_estamentos()))) THEN
        RAISE EXCEPTION 'La PQRSD no existe o está fuera de su ámbito territorial.';
    END IF;
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, CASE WHEN p_enviado THEN 'CORREO_ENVIADO' ELSE 'CORREO_NO_ENVIADO' END, left(p_detalle, 500));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Nota interna en la historia (cualquiera con acceso a la PQRSD)
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_nota(p_id BIGINT, p_nota TEXT)
RETURNS VOID AS $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM gestion_documental.pqrsd WHERE id_pqrsd = p_id
                    AND (seguridad.fn_ambito_nacional() OR id_estamento = ANY(seguridad.fn_ambito_estamentos()))) THEN
        RAISE EXCEPTION 'La PQRSD no existe o está fuera de su ámbito territorial.';
    END IF;
    IF seguridad.fn_rol_actual() IN ('CONSULTA', 'AFILIADO') THEN RAISE EXCEPTION 'Su rol solo consulta.' USING ERRCODE = 'insufficient_privilege'; END IF;
    IF length(trim(COALESCE(p_nota, ''))) < 5 THEN RAISE EXCEPTION 'Escriba la nota.'; END IF;
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'NOTA', trim(p_nota));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 6. ESTADO DE LOS PLAZOS Y ALERTAS
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW gestion_documental.v_auditoria_pqrsd WITH (security_invoker = true) AS
WITH q AS (
    SELECT p.*, gestion_documental.fn_hoy() AS hoy, t.nombre AS nombre_tipo, t.silencio_positivo, t.revision_juridica,
           GREATEST(p.plazo_dias + p.dias_prorroga, 1) AS plazo_vigente,
           CASE WHEN p.estado IN ('RADICADA', 'EN_TRAMITE')
                THEN gobernanza.fn_dias_habiles_entre(GREATEST(gestion_documental.fn_hoy(), p.fecha_base), p.fecha_limite) END AS restantes
      FROM gestion_documental.pqrsd p
      JOIN gestion_documental.tipo_pqrsd t ON t.codigo = p.tipo
)
SELECT q.radicado, q.nombre_tipo AS tipo, e.nombre_estamento AS junta, q.asunto,
       CASE WHEN q.anonima THEN 'ANÓNIMA' ELSE q.nombre_peticionario END AS peticionario,
       q.fecha_recepcion AS recibida, q.fecha_limite, q.estado,
       CASE WHEN q.estado IN ('RADICADA', 'EN_TRAMITE') AND q.hoy <= q.fecha_limite THEN q.restantes END AS dias_habiles_restantes,
       CASE WHEN q.estado IN ('RADICADA', 'EN_TRAMITE')
            THEN LEAST(100, GREATEST(0, round(100.0 * (q.plazo_vigente - CASE WHEN q.hoy > q.fecha_limite THEN 0 ELSE q.restantes END)
                                              / q.plazo_vigente)))::INT END AS porcentaje_consumido,
       CASE
            WHEN q.estado = 'ARCHIVADA_ANONIMA' THEN 'ARCHIVADA: ANÓNIMA, NO SE TRAMITA'
            WHEN q.estado = 'DESISTIDA' THEN 'CERRADA: DESISTIMIENTO TÁCITO'
            WHEN q.estado = 'TRASLADADA' THEN 'CERRADA: TRASLADADA A ' || upper(q.entidad_traslado)
                                              || CASE WHEN q.traslado_tardio THEN ' (FUERA DEL PLAZO DE TRASLADO)' ELSE '' END
            WHEN q.estado = 'RESPONDIDA' AND (q.fecha_respuesta AT TIME ZONE gestion_documental.fn_zona())::DATE > q.fecha_limite
                 THEN 'RESPONDIDA FUERA DE TÉRMINO'
            WHEN q.estado = 'RESPONDIDA' THEN 'RESPONDIDA A TIEMPO'
            WHEN q.estado = 'EN_REQUERIMIENTO' AND q.hoy > q.fecha_limite_completar
                 THEN 'ALERTA ALTA: VENCIÓ EL PLAZO PARA COMPLETAR, DECLARE EL DESISTIMIENTO'
            WHEN q.estado = 'EN_REQUERIMIENTO' THEN 'SUSPENDIDA: ESPERANDO QUE EL PETICIONARIO COMPLETE (HASTA EL '
                                                    || to_char(q.fecha_limite_completar, 'DD/MM/YYYY') || ')'
            WHEN q.hoy > q.fecha_limite AND q.silencio_positivo
                 THEN 'ALERTA CRÍTICA: VENCIDA, SE ENTIENDE ACEPTADA; ENTREGUE LOS DOCUMENTOS A MÁS TARDAR EL '
                      || to_char(gobernanza.fn_sumar_dias_habiles(q.fecha_limite, gestion_documental.fn_parametro_pqrsd('DIAS_ENTREGA_SILENCIO')::INT), 'DD/MM/YYYY')
            WHEN q.hoy > q.fecha_limite THEN 'ALERTA CRÍTICA: PLAZO VENCIDO SIN RESPUESTA'
            WHEN q.hoy = q.fecha_limite THEN 'ALERTA CRÍTICA: VENCE HOY'
            WHEN q.revision_juridica AND q.concepto_juridico IS NULL
                 AND (q.plazo_vigente - q.restantes) >= q.plazo_vigente * gestion_documental.fn_parametro_pqrsd('ALERTA_MEDIA_PCT') / 100
                 THEN 'ALERTA ALTA: DENUNCIA SIN CONCEPTO JURÍDICO Y MÁS DE LA MITAD DEL PLAZO CONSUMIDO'
            WHEN (q.plazo_vigente - q.restantes) >= q.plazo_vigente * gestion_documental.fn_parametro_pqrsd('ALERTA_ALTA_PCT') / 100
                 THEN 'ALERTA ALTA: SE HA CONSUMIDO EL 80 % DEL PLAZO'
            WHEN (q.plazo_vigente - q.restantes) >= q.plazo_vigente * gestion_documental.fn_parametro_pqrsd('ALERTA_MEDIA_PCT') / 100
                 THEN 'ALERTA MEDIA: SE HA CONSUMIDO LA MITAD DEL PLAZO'
            WHEN q.revision_juridica AND q.concepto_juridico IS NULL THEN 'EN TÉRMINO: PENDIENTE EL CONCEPTO JURÍDICO'
            ELSE 'EN TÉRMINO' END AS diagnostico,
       CASE WHEN q.estado = 'EN_REQUERIMIENTO' AND q.hoy > q.fecha_limite_completar THEN 'COMPLETAR_VENCIDO'
            WHEN q.estado IN ('RADICADA', 'EN_TRAMITE') AND q.hoy > q.fecha_limite THEN 'VENCIDA'
            WHEN q.estado IN ('RADICADA', 'EN_TRAMITE') AND q.hoy = q.fecha_limite THEN 'VENCE_HOY'
            WHEN q.estado IN ('RADICADA', 'EN_TRAMITE')
                 AND (q.plazo_vigente - q.restantes) >= q.plazo_vigente * gestion_documental.fn_parametro_pqrsd('ALERTA_ALTA_PCT') / 100 THEN 'ALTA'
            WHEN q.estado IN ('RADICADA', 'EN_TRAMITE')
                 AND (q.plazo_vigente - q.restantes) >= q.plazo_vigente * gestion_documental.fn_parametro_pqrsd('ALERTA_MEDIA_PCT') / 100 THEN 'MEDIA'
            END AS nivel_alerta,
       q.dias_prorroga > 0 AS prorrogada, q.traslado_tardio, q.revision_juridica AND q.concepto_juridico IS NULL AS falta_concepto,
       q.id_pqrsd, q.id_estamento, q.tipo AS codigo_tipo
  FROM q
  JOIN gobernanza.estamento e ON e.id_estamento = q.id_estamento;
COMMENT ON VIEW gestion_documental.v_auditoria_pqrsd IS 'PQRSD recibidas con sus días hábiles restantes y alertas al 50 %, 80 % y al vencer.';

-- Calendario de un plazo: lo usa la aplicación para mostrar cuándo vencería una PQRSD antes de registrarla
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_simular_plazo(p_tipo TEXT, p_recepcion TIMESTAMPTZ DEFAULT NULL)
RETURNS TABLE (fecha_base DATE, plazo_dias INT, fecha_limite DATE) AS $$
    SELECT gobernanza.fn_dia_base_radicacion(COALESCE(p_recepcion, now())), t.dias_habiles,
           gobernanza.fn_sumar_dias_habiles(gobernanza.fn_dia_base_radicacion(COALESCE(p_recepcion, now())), t.dias_habiles)
      FROM gestion_documental.tipo_pqrsd t WHERE t.codigo = p_tipo;
$$ LANGUAGE sql STABLE;

-- ----------------------------------------------------------------------------
-- 7. VERSIÓN, AUDITORÍA, SEGURIDAD POR FILAS, NO BORRAR Y PERMISOS
-- ----------------------------------------------------------------------------
DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['gestion_documental.tipo_pqrsd', 'gestion_documental.parametro_pqrsd', 'gestion_documental.pqrsd'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_control_version ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_control_version BEFORE UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_auditoria ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_no_borrar ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_no_borrar BEFORE DELETE ON %s FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado()', t);
    END LOOP;
END $$;

SELECT seguridad.fn_aplicar_politicas('gestion_documental.tipo_pqrsd', 'true', 'seguridad.fn_es_admin() OR seguridad.fn_es_presidente_nacional()');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.parametro_pqrsd', 'true', 'seguridad.fn_es_admin() OR seguridad.fn_es_presidente_nacional()');
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_parametro_pqrsd_rango') THEN
        ALTER TABLE gestion_documental.parametro_pqrsd ADD CONSTRAINT ck_parametro_pqrsd_rango CHECK (
            CASE codigo WHEN 'ALERTA_MEDIA_PCT' THEN valor BETWEEN 10 AND 90 WHEN 'ALERTA_ALTA_PCT' THEN valor BETWEEN 50 AND 99
                        WHEN 'MESES_COMPLETAR' THEN valor BETWEEN 1 AND 3 WHEN 'MESES_PRORROGA_COMPLETAR' THEN valor BETWEEN 0 AND 3
                        ELSE valor BETWEEN 0 AND 30 END);
    END IF;
END $$;
SELECT seguridad.fn_aplicar_politicas('gestion_documental.pqrsd', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.pqrsd_actuacion',
    'EXISTS (SELECT 1 FROM gestion_documental.pqrsd q WHERE q.id_pqrsd = pqrsd_actuacion.id_pqrsd)', 'false');

-- Recursos que la Ventanilla puede escribir (bloque 3)
INSERT INTO seguridad.recurso_permitido_rol (codigo_rol, recurso, operaciones) VALUES ('VENTANILLA', 'pqrsd', ARRAY['crear'])
ON CONFLICT DO NOTHING;

DO $$
DECLARE r TEXT; f TEXT;
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        GRANT SELECT, UPDATE ON gestion_documental.tipo_pqrsd, gestion_documental.parametro_pqrsd TO sgs_app;
        GRANT SELECT, INSERT, UPDATE ON gestion_documental.pqrsd TO sgs_app;
        GRANT SELECT ON gestion_documental.pqrsd_actuacion, gestion_documental.v_auditoria_pqrsd TO sgs_app;
        REVOKE INSERT, UPDATE, DELETE ON gestion_documental.pqrsd_actuacion FROM sgs_app;
        REVOKE DELETE ON gestion_documental.tipo_pqrsd, gestion_documental.parametro_pqrsd, gestion_documental.pqrsd FROM sgs_app;
        GRANT USAGE ON SEQUENCE gestion_documental.seq_pqrsd TO sgs_app;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_lectura') THEN
        GRANT SELECT ON gestion_documental.tipo_pqrsd, gestion_documental.parametro_pqrsd, gestion_documental.pqrsd,
                        gestion_documental.pqrsd_actuacion, gestion_documental.v_auditoria_pqrsd TO sgs_lectura;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_notificador') THEN
        GRANT SELECT ON gestion_documental.tipo_pqrsd, gestion_documental.parametro_pqrsd, gestion_documental.pqrsd,
                        gestion_documental.v_auditoria_pqrsd TO sgs_notificador;
    END IF;
    -- Las acciones solo las usa la aplicación con un usuario identificado
    FOREACH f IN ARRAY ARRAY['gestion_documental.fn_pqrsd_anotar(BIGINT, TEXT, TEXT)',
                             'gestion_documental.fn_pqrsd_cargar(BIGINT)',
                             'gestion_documental.fn_pqrsd_prorrogar(BIGINT, INT, TEXT)',
                             'gestion_documental.fn_pqrsd_pedir_completar(BIGINT, TEXT)',
                             'gestion_documental.fn_pqrsd_prorrogar_completar(BIGINT, TEXT)',
                             'gestion_documental.fn_pqrsd_completada(BIGINT, TEXT, TIMESTAMPTZ)',
                             'gestion_documental.fn_pqrsd_desistimiento(BIGINT, TEXT)',
                             'gestion_documental.fn_pqrsd_trasladar(BIGINT, BIGINT, TEXT, TEXT)',
                             'gestion_documental.fn_pqrsd_concepto(BIGINT, TEXT)',
                             'gestion_documental.fn_pqrsd_responder(BIGINT, TEXT, BIGINT)',
                             'gestion_documental.fn_pqrsd_registrar_correo(BIGINT, BOOLEAN, TEXT)',
                             'gestion_documental.fn_pqrsd_nota(BIGINT, TEXT)',
                             'gestion_documental.fn_pqrsd_resumen_traslado(BIGINT)',
                             'gestion_documental.fn_pqrsd_en_tramite(BIGINT)'] LOOP
        EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC', f);
        FOREACH r IN ARRAY ARRAY['sgs_lectura', 'sgs_notificador'] LOOP
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM %I', f, r); END IF;
        END LOOP;
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') AND f NOT LIKE '%fn_pqrsd_anotar%' AND f NOT LIKE '%fn_pqrsd_cargar%' THEN
            EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO sgs_app', f);
        END IF;
    END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- 8. CORREOS AUTOMÁTICOS (alertas de plazos a la junta)
-- ----------------------------------------------------------------------------
INSERT INTO notificaciones.tipo_notificacion (codigo, nombre, descripcion) VALUES
    ('PQRSD_PLAZOS', 'PQRSD por vencer o vencidas',
     'A los cuatro cargos de la junta (Presidente, Vicepresidente, Secretario General y Fiscal): un aviso por PQRSD cuando consume la mitad del plazo, otro al 80 % y otro al vencer.')
ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, descripcion = EXCLUDED.descripcion;
