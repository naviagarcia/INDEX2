-- ============================================================================
-- SGSINDICAL v9.1 — 07: PORCENTAJE DEL APORTE (0,6 % / 0,7 %), NOVEDADES Y EXONERACIONES
-- Ejecutar DESPUÉS de 06. No modifica los scripts anteriores: los complementa.
-- ----------------------------------------------------------------------------
--  A1. PORCENTAJE DE CADA JUNTA y DE CADA AFILIADO, con historial mes a mes. Solo puede SUBIR
--      (0,6 % → 0,7 %), nunca bajar. Los valores permitidos están en una tabla.
--  A2. Un afiliado sin porcentaje propio aporta el de su junta. Puede tener uno mayor que el de su
--      junta, nunca menor: en una junta que ya pasó al 0,7 % no se registra a nadie al 0,6 %.
--  A3. TRANSICIÓN: cuando una junta pasa al 0,7 % (con el acta que lo decidió), sus afiliados que
--      seguían en 0,6 % pasan con ella desde el mismo mes. No se aplica a meses cerrados.
--  A4. CORRECCIÓN DE DIGITACIÓN: solo el administrador baja un porcentaje, con motivo, y solo si
--      todavía no se generaron aportes con él.
--  A5. CÁLCULO: cada mes se usa el porcentaje vigente de cada afiliado; se redondea al peso.
--      Novedades: ingreso entre el día 1 y el 7 → se cobra ese mes; del 8 en adelante → desde el
--      siguiente. Retiro → se cobra el mes del retiro. Licencias, suspensiones, incapacidades y
--      vacaciones → se cobra normalmente. Cambio de salario → el vigente al cierre del mes.
--  A6. EXONERACIONES: el afiliado las pide; las aprueba su junta con un acta (ACT). En los meses
--      exonerados no se espera su aporte ni se le genera; si la empresa igual consignó, se avisa.
--  A7. SEGUIMIENTO: vista "Transición al 0,7 %" por junta y vista de exoneraciones.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. VALORES PERMITIDOS Y PORCENTAJE DE CADA JUNTA
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS finanzas.porcentaje_permitido (
    valor NUMERIC(5,3) PRIMARY KEY CHECK (valor > 0 AND valor < 10),
    descripcion VARCHAR(120) NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    version INT NOT NULL DEFAULT 1
);
INSERT INTO finanzas.porcentaje_permitido (valor, descripcion) VALUES
    (0.6, 'Porcentaje anterior (juntas que aún no aplican la actualización)'),
    (0.7, 'Porcentaje actualizado')
ON CONFLICT (valor) DO NOTHING;

CREATE TABLE IF NOT EXISTS finanzas.porcentaje_junta (
    id_porcentaje_junta BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    porcentaje NUMERIC(5,3) NOT NULL REFERENCES finanzas.porcentaje_permitido(valor) ON DELETE RESTRICT,
    vigente_desde DATE NOT NULL,
    id_acta BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    observacion TEXT,
    afiliados_actualizados INT,
    corregido BOOLEAN NOT NULL DEFAULT FALSE,
    motivo_correccion TEXT,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_porcentaje_junta_mes CHECK (vigente_desde = date_trunc('month', vigente_desde)::DATE),
    CONSTRAINT uk_porcentaje_junta_mes UNIQUE (id_estamento, vigente_desde)
);
COMMENT ON TABLE finanzas.porcentaje_junta IS 'Porcentaje del aporte que aplica cada junta, desde qué mes. Solo sube.';
CREATE INDEX IF NOT EXISTS ix_porcentaje_junta_acta ON finanzas.porcentaje_junta (id_acta);
CREATE INDEX IF NOT EXISTS ix_porcentaje_junta_valor ON finanzas.porcentaje_junta (porcentaje);

CREATE TABLE IF NOT EXISTS finanzas.porcentaje_afiliado (
    id_porcentaje_afiliado BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.afiliado(id_persona) ON DELETE RESTRICT,
    porcentaje NUMERIC(5,3) NOT NULL REFERENCES finanzas.porcentaje_permitido(valor) ON DELETE RESTRICT,
    vigente_desde DATE NOT NULL,
    origen VARCHAR(12) NOT NULL DEFAULT 'INDIVIDUAL' CHECK (origen IN ('INDIVIDUAL', 'TRANSICION')),
    observacion TEXT,
    corregido BOOLEAN NOT NULL DEFAULT FALSE,
    motivo_correccion TEXT,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_porcentaje_afiliado_mes CHECK (vigente_desde = date_trunc('month', vigente_desde)::DATE),
    CONSTRAINT uk_porcentaje_afiliado_mes UNIQUE (id_persona, vigente_desde)
);
COMMENT ON TABLE finanzas.porcentaje_afiliado IS 'Porcentaje propio de un afiliado desde qué mes (si no tiene, aplica el de su junta). Solo sube.';
CREATE INDEX IF NOT EXISTS ix_porcentaje_afiliado_valor ON finanzas.porcentaje_afiliado (porcentaje);

-- Porcentaje de la junta en un mes (si la junta no ha registrado ninguno: el parámetro general)
CREATE OR REPLACE FUNCTION finanzas.fn_porcentaje_junta(p_id_estamento BIGINT, p_mes DATE)
RETURNS NUMERIC AS $$
    SELECT trim_scale(COALESCE((SELECT porcentaje FROM finanzas.porcentaje_junta
                      WHERE id_estamento = p_id_estamento AND vigente_desde <= p_mes
                      ORDER BY vigente_desde DESC LIMIT 1),
                    finanzas.fn_parametro('PORCENTAJE_APORTE')));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Porcentaje de un afiliado en un mes: el propio vigente o, si no tiene, el de su junta (el mayor de los dos)
CREATE OR REPLACE FUNCTION finanzas.fn_porcentaje_afiliado(p_id_persona BIGINT, p_mes DATE)
RETURNS NUMERIC AS $$
    SELECT trim_scale(GREATEST(
        COALESCE((SELECT porcentaje FROM finanzas.porcentaje_afiliado
                   WHERE id_persona = p_id_persona AND vigente_desde <= p_mes ORDER BY vigente_desde DESC LIMIT 1), 0),
        finanzas.fn_porcentaje_junta((SELECT id_estamento_pertenencia FROM gobernanza.afiliado WHERE id_persona = p_id_persona), p_mes)));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 2. REGLAS: solo sube, nunca en un mes cerrado, nunca por debajo de la junta
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION finanzas.fn_validar_porcentaje()
RETURNS TRIGGER AS $$
DECLARE v_anterior NUMERIC; v_junta BIGINT; v_ultimo DATE; v_tipo TEXT;
BEGIN
    IF COALESCE(current_setting('finanzas.operacion', true), '') = 'corregir_porcentaje' THEN RETURN NEW; END IF;
    IF TG_OP = 'UPDATE' THEN
        IF NEW.porcentaje IS DISTINCT FROM OLD.porcentaje OR NEW.vigente_desde IS DISTINCT FROM OLD.vigente_desde
           OR NEW.corregido IS DISTINCT FROM OLD.corregido THEN
            RAISE EXCEPTION 'El porcentaje y su fecha no se modifican. Si fue un error de digitación, el administrador lo corrige (acción Corregir).';
        END IF;
        RETURN NEW;
    END IF;
    NEW.vigente_desde := date_trunc('month', NEW.vigente_desde)::DATE;
    NEW.corregido := FALSE; NEW.motivo_correccion := NULL;
    IF NOT EXISTS (SELECT 1 FROM finanzas.porcentaje_permitido WHERE valor = NEW.porcentaje AND activo) THEN
        RAISE EXCEPTION 'Porcentaje no permitido: use uno de los valores autorizados (%).',
            (SELECT string_agg(replace(valor::TEXT, '.', ',') || ' %', ' o ' ORDER BY valor) FROM finanzas.porcentaje_permitido WHERE activo);
    END IF;

    IF TG_TABLE_NAME = 'porcentaje_junta' THEN
        v_junta := NEW.id_estamento;
        SELECT tipo_estamento INTO v_tipo FROM gobernanza.estamento WHERE id_estamento = v_junta;
        IF v_tipo NOT IN ('JUNTA DIRECTIVA NACIONAL', 'SUBDIRECTIVA', 'COMITÉ SECCIONAL') THEN
            RAISE EXCEPTION 'El porcentaje se registra para la Nacional, una subdirectiva o un comité.';
        END IF;
        -- El primer registro de una junta es la carga inicial de su situación actual; los cambios posteriores, con acta
        IF (NEW.id_acta IS NOT NULL OR EXISTS (SELECT 1 FROM finanzas.porcentaje_junta WHERE id_estamento = v_junta)) AND NOT EXISTS (
               SELECT 1 FROM gestion_documental.documento d JOIN gestion_documental.tipo_documento t USING (id_tipo_documento)
                WHERE d.id_documento = NEW.id_acta AND t.sigla_tipo = 'ACT' AND d.id_estamento = v_junta) THEN
            RAISE EXCEPTION 'El cambio de porcentaje de la junta se registra con el acta (ACT) de la junta que lo decidió.';
        END IF;
        SELECT max(vigente_desde) INTO v_ultimo FROM finanzas.porcentaje_junta WHERE id_estamento = v_junta;
        SELECT porcentaje INTO v_anterior FROM finanzas.porcentaje_junta WHERE id_estamento = v_junta ORDER BY vigente_desde DESC LIMIT 1;
        IF v_anterior IS NOT NULL AND NEW.porcentaje < v_anterior THEN
            RAISE EXCEPTION 'El aporte de la junta no puede bajar del % %% al % %%.', replace(v_anterior::TEXT, '.', ','), replace(NEW.porcentaje::TEXT, '.', ',');
        END IF;
    ELSE
        SELECT id_estamento_pertenencia INTO v_junta FROM gobernanza.afiliado WHERE id_persona = NEW.id_persona;
        SELECT max(vigente_desde) INTO v_ultimo FROM finanzas.porcentaje_afiliado WHERE id_persona = NEW.id_persona;
        v_anterior := finanzas.fn_porcentaje_afiliado(NEW.id_persona, GREATEST(NEW.vigente_desde, COALESCE(v_ultimo, NEW.vigente_desde)));
        IF EXISTS (SELECT 1 FROM finanzas.porcentaje_afiliado WHERE id_persona = NEW.id_persona) AND NEW.porcentaje < v_anterior THEN
            RAISE EXCEPTION 'El aporte de un afiliado no puede bajar del % %% al % %%.', replace(v_anterior::TEXT, '.', ','), replace(NEW.porcentaje::TEXT, '.', ',');
        END IF;
        IF NEW.porcentaje < finanzas.fn_porcentaje_junta(v_junta, NEW.vigente_desde) THEN
            RAISE EXCEPTION 'La junta del afiliado ya aplica el % %%: no se puede registrar a nadie con un porcentaje menor.',
                replace(finanzas.fn_porcentaje_junta(v_junta, NEW.vigente_desde)::TEXT, '.', ',');
        END IF;
    END IF;
    IF v_ultimo IS NOT NULL AND NEW.vigente_desde <= v_ultimo THEN
        RAISE EXCEPTION 'Ya hay un porcentaje registrado desde %: el nuevo debe regir desde un mes posterior.', to_char(v_ultimo, 'YYYY-MM');
    END IF;
    IF finanzas.fn_mes_cerrado(v_junta, NEW.vigente_desde) THEN
        RAISE EXCEPTION 'El mes % ya está cerrado para la junta: el cambio debe regir desde un mes abierto.', to_char(NEW.vigente_desde, 'YYYY-MM');
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_validar_porcentaje ON finanzas.porcentaje_junta;
CREATE TRIGGER trg_validar_porcentaje BEFORE INSERT OR UPDATE ON finanzas.porcentaje_junta
    FOR EACH ROW EXECUTE FUNCTION finanzas.fn_validar_porcentaje();
DROP TRIGGER IF EXISTS trg_validar_porcentaje ON finanzas.porcentaje_afiliado;
CREATE TRIGGER trg_validar_porcentaje BEFORE INSERT OR UPDATE ON finanzas.porcentaje_afiliado
    FOR EACH ROW EXECUTE FUNCTION finanzas.fn_validar_porcentaje();

-- Transición: los afiliados de la junta que quedarían por debajo pasan con ella desde el mismo mes
CREATE OR REPLACE FUNCTION finanzas.fn_transicion_junta()
RETURNS TRIGGER AS $$
DECLARE v_n INT;
BEGIN
    IF COALESCE(current_setting('finanzas.operacion', true), '') = 'corregir_porcentaje' THEN RETURN NEW; END IF;
    INSERT INTO finanzas.porcentaje_afiliado (id_persona, porcentaje, vigente_desde, origen, observacion)
    SELECT a.id_persona, NEW.porcentaje, NEW.vigente_desde, 'TRANSICION', 'Transición de la junta' || COALESCE(' (acta ' || NEW.id_acta || ')', '')
      FROM gobernanza.afiliado a
     WHERE a.id_estamento_pertenencia = NEW.id_estamento AND a.activo
       AND EXISTS (SELECT 1 FROM finanzas.porcentaje_afiliado x WHERE x.id_persona = a.id_persona)   -- quienes tienen porcentaje propio
       AND finanzas.fn_porcentaje_afiliado(a.id_persona, NEW.vigente_desde) < NEW.porcentaje
       AND NOT EXISTS (SELECT 1 FROM finanzas.porcentaje_afiliado x WHERE x.id_persona = a.id_persona AND x.vigente_desde >= NEW.vigente_desde);
    GET DIAGNOSTICS v_n = ROW_COUNT;
    -- Afiliados que siguen el porcentaje de la junta (sin porcentaje propio) más los que se subieron ahora
    NEW.afiliados_actualizados := v_n + (SELECT count(*) FROM gobernanza.afiliado a
                                           WHERE a.id_estamento_pertenencia = NEW.id_estamento AND a.activo
                                             AND NOT EXISTS (SELECT 1 FROM finanzas.porcentaje_afiliado x WHERE x.id_persona = a.id_persona));
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
-- Se ejecuta después de la validación (los triggers BEFORE corren en orden alfabético)
DROP TRIGGER IF EXISTS trg_transicion_junta ON finanzas.porcentaje_junta;
DROP TRIGGER IF EXISTS trg_validar_porcentaje_transicion ON finanzas.porcentaje_junta;
CREATE TRIGGER trg_validar_porcentaje_transicion BEFORE INSERT ON finanzas.porcentaje_junta
    FOR EACH ROW EXECUTE FUNCTION finanzas.fn_transicion_junta();

-- Corrección de un error de digitación: solo el administrador, con motivo, sin aportes generados
CREATE OR REPLACE FUNCTION finanzas.fn_corregir_porcentaje(p_tabla TEXT, p_id BIGINT, p_nuevo NUMERIC, p_motivo TEXT)
RETURNS TEXT AS $$
DECLARE v_desde DATE; v_persona BIGINT; v_junta BIGINT; v_actual NUMERIC; v_n INT;
BEGIN
    IF NOT seguridad.fn_es_admin() THEN RAISE EXCEPTION 'Solo el administrador corrige un porcentaje mal digitado.'; END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo de la corrección (mínimo 10 caracteres).'; END IF;
    IF NOT EXISTS (SELECT 1 FROM finanzas.porcentaje_permitido WHERE valor = p_nuevo AND activo) THEN
        RAISE EXCEPTION 'Porcentaje no permitido.';
    END IF;
    IF p_tabla = 'porcentaje_afiliado' THEN
        SELECT vigente_desde, id_persona, porcentaje INTO v_desde, v_persona, v_actual FROM finanzas.porcentaje_afiliado
         WHERE id_porcentaje_afiliado = p_id FOR UPDATE;
        IF v_desde IS NULL THEN RAISE EXCEPTION 'El registro no existe.'; END IF;
        SELECT count(*) INTO v_n FROM finanzas.aporte_afiliado
         WHERE id_persona = v_persona AND NOT anulado AND make_date(periodo_anio, periodo_mes, 1) >= v_desde;
    ELSIF p_tabla = 'porcentaje_junta' THEN
        SELECT vigente_desde, id_estamento, porcentaje INTO v_desde, v_junta, v_actual FROM finanzas.porcentaje_junta
         WHERE id_porcentaje_junta = p_id FOR UPDATE;
        IF v_desde IS NULL THEN RAISE EXCEPTION 'El registro no existe.'; END IF;
        SELECT count(*) INTO v_n FROM finanzas.aporte_afiliado ap JOIN gobernanza.afiliado a ON a.id_persona = ap.id_persona
         WHERE a.id_estamento_pertenencia = v_junta AND NOT ap.anulado AND make_date(ap.periodo_anio, ap.periodo_mes, 1) >= v_desde;
    ELSE
        RAISE EXCEPTION 'Tipo de registro no válido.';
    END IF;
    IF p_nuevo = v_actual THEN RAISE EXCEPTION 'El porcentaje ya es ese.'; END IF;
    IF v_n > 0 THEN
        RAISE EXCEPTION 'Ya se generaron % aporte(s) con este porcentaje desde %: no se puede corregir. Si hubo un cobro de más, regístrelo como ajuste.',
            v_n, to_char(v_desde, 'YYYY-MM');
    END IF;
    PERFORM set_config('finanzas.operacion', 'corregir_porcentaje', true);
    IF p_tabla = 'porcentaje_afiliado' THEN
        UPDATE finanzas.porcentaje_afiliado SET porcentaje = p_nuevo, corregido = TRUE,
               motivo_correccion = trim(p_motivo) || ' (antes ' || v_actual || ' %)'
         WHERE id_porcentaje_afiliado = p_id;
    ELSE
        UPDATE finanzas.porcentaje_junta SET porcentaje = p_nuevo, corregido = TRUE,
               motivo_correccion = trim(p_motivo) || ' (antes ' || v_actual || ' %)'
         WHERE id_porcentaje_junta = p_id;
        -- Los afiliados que la transición había subido vuelven con ella
        UPDATE finanzas.porcentaje_afiliado SET porcentaje = p_nuevo, corregido = TRUE,
               motivo_correccion = 'Corrección del porcentaje de la junta: ' || trim(p_motivo)
         WHERE origen = 'TRANSICION' AND vigente_desde = v_desde AND porcentaje = v_actual
           AND id_persona IN (SELECT id_persona FROM gobernanza.afiliado WHERE id_estamento_pertenencia = v_junta);
    END IF;
    PERFORM set_config('finanzas.operacion', '', true);
    RETURN 'CORREGIDO';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 3. EXONERACIONES (las aprueba la junta con acta)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS finanzas.exoneracion (
    id_exoneracion BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.afiliado(id_persona) ON DELETE RESTRICT,
    desde_mes DATE NOT NULL,
    hasta_mes DATE NOT NULL,
    motivo TEXT NOT NULL,
    id_documento_solicitud BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    estado VARCHAR(10) NOT NULL DEFAULT 'SOLICITADA' CHECK (estado IN ('SOLICITADA', 'APROBADA', 'NEGADA')),
    id_acta BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    fecha_decision TIMESTAMP WITH TIME ZONE,
    usuario_decision VARCHAR(50),
    observacion_decision TEXT,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT ck_exoneracion_meses CHECK (desde_mes = date_trunc('month', desde_mes)::DATE
                                           AND hasta_mes = date_trunc('month', hasta_mes)::DATE AND hasta_mes >= desde_mes),
    CONSTRAINT ck_exoneracion_motivo CHECK (length(trim(motivo)) >= 10)
);
COMMENT ON TABLE finanzas.exoneracion IS 'Exoneración del aporte de un afiliado por unos meses; la aprueba su junta con un acta.';
CREATE INDEX IF NOT EXISTS ix_exoneracion_persona ON finanzas.exoneracion (id_persona, desde_mes);
CREATE INDEX IF NOT EXISTS ix_exoneracion_acta ON finanzas.exoneracion (id_acta);
CREATE INDEX IF NOT EXISTS ix_exoneracion_solicitud ON finanzas.exoneracion (id_documento_solicitud);

CREATE OR REPLACE FUNCTION finanzas.fn_proteger_exoneracion()
RETURNS TRIGGER AS $$
BEGIN
    IF COALESCE(current_setting('finanzas.operacion', true), '') = 'decidir_exoneracion' THEN RETURN NEW; END IF;
    IF TG_OP = 'INSERT' THEN
        NEW.desde_mes := date_trunc('month', NEW.desde_mes)::DATE;
        NEW.hasta_mes := date_trunc('month', NEW.hasta_mes)::DATE;
        NEW.estado := 'SOLICITADA'; NEW.id_acta := NULL; NEW.fecha_decision := NULL; NEW.usuario_decision := NULL;
        NEW.observacion_decision := NULL;
        RETURN NEW;
    END IF;
    IF OLD.estado <> 'SOLICITADA' THEN RAISE EXCEPTION 'Una exoneración ya decidida no se modifica.'; END IF;
    IF NEW.estado IS DISTINCT FROM OLD.estado OR NEW.id_acta IS DISTINCT FROM OLD.id_acta THEN
        RAISE EXCEPTION 'La exoneración se aprueba o se niega con su acción (con el acta de la junta).';
    END IF;
    NEW.desde_mes := date_trunc('month', NEW.desde_mes)::DATE;
    NEW.hasta_mes := date_trunc('month', NEW.hasta_mes)::DATE;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_proteger_exoneracion ON finanzas.exoneracion;
CREATE TRIGGER trg_proteger_exoneracion BEFORE INSERT OR UPDATE ON finanzas.exoneracion
    FOR EACH ROW EXECUTE FUNCTION finanzas.fn_proteger_exoneracion();

CREATE OR REPLACE FUNCTION finanzas.fn_decidir_exoneracion(p_id BIGINT, p_aprobar BOOLEAN, p_id_acta BIGINT, p_observacion TEXT DEFAULT NULL)
RETURNS TEXT AS $$
DECLARE v_e finanzas.exoneracion%ROWTYPE; v_junta BIGINT; v_m DATE;
BEGIN
    SELECT * INTO v_e FROM finanzas.exoneracion WHERE id_exoneracion = p_id FOR UPDATE;
    IF v_e.id_exoneracion IS NULL THEN RAISE EXCEPTION 'La solicitud no existe.'; END IF;
    IF v_e.estado <> 'SOLICITADA' THEN RAISE EXCEPTION 'La solicitud ya fue decidida.'; END IF;
    SELECT id_estamento_pertenencia INTO v_junta FROM gobernanza.afiliado WHERE id_persona = v_e.id_persona;
    IF NOT (seguridad.fn_es_admin() OR seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'SGEN\_%'], v_junta)) THEN
        RAISE EXCEPTION 'La decisión de la junta la registran su Presidente o su Secretario General.';
    END IF;
    IF p_id_acta IS NULL OR NOT EXISTS (
           SELECT 1 FROM gestion_documental.documento d JOIN gestion_documental.tipo_documento t USING (id_tipo_documento)
            WHERE d.id_documento = p_id_acta AND t.sigla_tipo = 'ACT' AND d.id_estamento = v_junta) THEN
        RAISE EXCEPTION 'La decisión se registra con el acta (ACT) de la reunión de la junta del afiliado.';
    END IF;
    IF p_aprobar THEN
        FOR v_m IN SELECT g::DATE FROM generate_series(v_e.desde_mes, v_e.hasta_mes, INTERVAL '1 month') g LOOP
            IF finanzas.fn_mes_cerrado(v_junta, v_m) THEN
                RAISE EXCEPTION 'El mes % ya está cerrado: la exoneración solo cubre meses abiertos.', to_char(v_m, 'YYYY-MM');
            END IF;
        END LOOP;
        IF EXISTS (SELECT 1 FROM finanzas.exoneracion x WHERE x.id_persona = v_e.id_persona AND x.estado = 'APROBADA'
                      AND x.desde_mes <= v_e.hasta_mes AND x.hasta_mes >= v_e.desde_mes) THEN
            RAISE EXCEPTION 'Ya hay una exoneración aprobada que cubre parte de esos meses.';
        END IF;
    ELSIF length(trim(COALESCE(p_observacion, ''))) < 10 THEN
        RAISE EXCEPTION 'Escriba por qué la junta negó la exoneración (mínimo 10 caracteres).';
    END IF;
    PERFORM set_config('finanzas.operacion', 'decidir_exoneracion', true);
    UPDATE finanzas.exoneracion SET estado = CASE WHEN p_aprobar THEN 'APROBADA' ELSE 'NEGADA' END, id_acta = p_id_acta,
           fecha_decision = now(), usuario_decision = auditoria.fn_usuario_actual(),
           observacion_decision = NULLIF(trim(COALESCE(p_observacion, '')), '')
     WHERE id_exoneracion = p_id;
    PERFORM set_config('finanzas.operacion', '', true);
    RETURN CASE WHEN p_aprobar THEN 'APROBADA' ELSE 'NEGADA' END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION finanzas.fn_exonerado(p_id_persona BIGINT, p_mes DATE)
RETURNS BOOLEAN AS $$
    SELECT EXISTS (SELECT 1 FROM finanzas.exoneracion WHERE id_persona = p_id_persona AND estado = 'APROBADA'
                      AND date_trunc('month', p_mes)::DATE BETWEEN desde_mes AND hasta_mes);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 4. ¿SE COBRA EL MES? Novedades de ingreso y retiro, exoneraciones
-- ----------------------------------------------------------------------------
-- Primer mes que se cobra: el del ingreso (a la empresa o al sindicato, el último) si fue entre el
-- día 1 y el 7; si fue del 8 en adelante, el mes siguiente.
CREATE OR REPLACE FUNCTION finanzas.fn_primer_mes_cobro(p_fecha_afiliacion DATE, p_fecha_ingreso DATE)
RETURNS DATE AS $$
    SELECT CASE WHEN EXTRACT(DAY FROM f) <= 7 THEN date_trunc('month', f)::DATE
                ELSE (date_trunc('month', f) + INTERVAL '1 month')::DATE END
      FROM (SELECT GREATEST(COALESCE(p_fecha_afiliacion, p_fecha_ingreso), COALESCE(p_fecha_ingreso, p_fecha_afiliacion)) AS f) x;
$$ LANGUAGE sql IMMUTABLE;

CREATE OR REPLACE FUNCTION finanzas.fn_se_cobra(p_id_persona BIGINT, p_mes DATE)
RETURNS BOOLEAN AS $$
    SELECT COALESCE((
        SELECT gobernanza.fn_afiliado_cotiza(a.activo, a.fecha_inactivacion, date_trunc('month', p_mes)::DATE)
               AND date_trunc('month', p_mes)::DATE >= finanzas.fn_primer_mes_cobro(a.fecha_afiliacion, ae.fecha_ingreso_empresa)
               AND NOT finanzas.fn_exonerado(a.id_persona, p_mes)
          FROM gobernanza.afiliado a LEFT JOIN gobernanza.afiliado_empresa ae ON ae.id_persona = a.id_persona
         WHERE a.id_persona = p_id_persona), FALSE);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Aporte esperado de un afiliado en un mes (al peso): salario vigente al cierre del mes × su porcentaje
CREATE OR REPLACE FUNCTION finanzas.fn_aporte_esperado(p_id_persona BIGINT, p_id_empresa BIGINT, p_mes DATE)
RETURNS NUMERIC AS $$
    SELECT ROUND(gobernanza.fn_salario_vigente(p_id_persona, p_id_empresa,
                     (date_trunc('month', p_mes) + INTERVAL '1 month' - INTERVAL '1 day')::DATE)
                 * finanzas.fn_porcentaje_afiliado(p_id_persona, date_trunc('month', p_mes)::DATE) / 100, 0);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

ALTER TABLE finanzas.aporte_afiliado ADD COLUMN IF NOT EXISTS porcentaje_aplicado NUMERIC(5,3);
COMMENT ON COLUMN finanzas.aporte_afiliado.porcentaje_aplicado IS 'Porcentaje con el que se calculó el aporte (vacío en los registrados antes del bloque 07).';

CREATE OR REPLACE FUNCTION finanzas.fn_generar_aportes(p_id_consignacion BIGINT, p_solo_junta BOOLEAN DEFAULT FALSE)
RETURNS INT AS $$
DECLARE v_c RECORD; v_n INT; v_mes DATE;
BEGIN
    SELECT ce.*, cb.es_cuenta_nacional, cb.id_estamento AS est_cuenta INTO v_c
      FROM finanzas.consignacion_empresa ce JOIN finanzas.cuenta_bancaria cb ON cb.id_cuenta = ce.id_cuenta_destino
     WHERE ce.id_consignacion = p_id_consignacion FOR UPDATE OF ce;
    IF v_c.id_consignacion IS NULL
       OR NOT finanzas.fn_consignacion_visible(v_c.id_empresa, v_c.id_cuenta_destino, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos()) THEN
        RAISE EXCEPTION 'La consignación no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v_c.anulado THEN RAISE EXCEPTION 'La consignación está anulada: no se le generan aportes.'; END IF;
    v_mes := make_date(v_c.periodo_anio, v_c.periodo_mes, 1);
    PERFORM pg_advisory_xact_lock(hashtext('aportes_empresa'), (v_c.id_empresa * 100000 + v_c.periodo_anio * 100 + v_c.periodo_mes)::INT);
    INSERT INTO finanzas.aporte_afiliado (id_consignacion, id_persona, periodo_mes, periodo_anio, monto_descuento_ley, porcentaje_aplicado)
    SELECT p_id_consignacion, ae.id_persona, v_c.periodo_mes, v_c.periodo_anio,
           finanzas.fn_aporte_esperado(ae.id_persona, ae.id_empresa, v_mes), finanzas.fn_porcentaje_afiliado(ae.id_persona, v_mes)
      FROM gobernanza.afiliado_empresa ae
      JOIN gobernanza.afiliado a ON a.id_persona = ae.id_persona
     WHERE ae.id_empresa = v_c.id_empresa
       AND finanzas.fn_se_cobra(ae.id_persona, v_mes)
       AND (NOT p_solo_junta OR v_c.es_cuenta_nacional OR a.id_estamento_pertenencia = v_c.est_cuenta)
       AND NOT EXISTS (SELECT 1 FROM finanzas.aporte_afiliado x
                        WHERE x.id_persona = ae.id_persona AND x.periodo_anio = v_c.periodo_anio AND x.periodo_mes = v_c.periodo_mes
                          AND NOT x.anulado);
    GET DIAGNOSTICS v_n = ROW_COUNT;
    RETURN v_n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE VIEW finanzas.vf_mora_empresas AS
WITH meses AS (
    SELECT g::DATE AS mes FROM generate_series(date_trunc('month', CURRENT_DATE) - INTERVAL '12 months',
                                               date_trunc('month', CURRENT_DATE) - INTERVAL '1 month', INTERVAL '1 month') g
     WHERE g + INTERVAL '1 month' + (finanzas.fn_parametro('DIA_LIMITE_CONSIGNACION')::INT - 1) * INTERVAL '1 day' < CURRENT_DATE
), esperado AS (
    SELECT ae.id_empresa, m.mes, COUNT(*) AS afiliados,
           SUM(finanzas.fn_aporte_esperado(ae.id_persona, ae.id_empresa, m.mes)) AS valor
      FROM gobernanza.afiliado_empresa ae
      JOIN meses m ON finanzas.fn_se_cobra(ae.id_persona, m.mes)
     GROUP BY ae.id_empresa, m.mes
)
SELECT emp.nombre_empresa AS empresa, emp.nit, to_char(es.mes, 'YYYY-MM') AS periodo, es.afiliados,
       es.valor AS esperado, COALESCE(c.monto_total_consignado, 0) AS consignado,
       COALESCE(c.monto_total_consignado, 0) - es.valor AS diferencia, c.fecha_consignacion, c.cuentas AS consignado_en,
       CASE WHEN c.id_consignacion IS NULL THEN 'ALERTA CRÍTICA: NO CONSIGNÓ LOS APORTES DEL MES'
            WHEN c.monto_total_consignado < es.valor - finanzas.fn_parametro('TOLERANCIA_PESOS') THEN 'ALERTA ALTA: CONSIGNÓ MENOS DE LO ESPERADO'
            ELSE 'AL DÍA' END AS diagnostico,
       emp.id_empresa
  FROM esperado es
  JOIN gobernanza.empresa emp ON emp.id_empresa = es.id_empresa
  LEFT JOIN (SELECT ce.id_empresa, ce.periodo_anio, ce.periodo_mes, SUM(ce.monto_total_consignado) AS monto_total_consignado,
                    MAX(ce.fecha_consignacion) AS fecha_consignacion, MIN(ce.id_consignacion) AS id_consignacion,
                    string_agg(CASE WHEN cb.es_cuenta_nacional THEN 'Cuenta nacional' ELSE 'Subcuenta ' || e2.nombre_estamento END
                               || ' (' || ce.monto_total_consignado || ')', '; ' ORDER BY cb.es_cuenta_nacional DESC, e2.nombre_estamento) AS cuentas
               FROM finanzas.consignacion_empresa ce
               JOIN finanzas.cuenta_bancaria cb ON cb.id_cuenta = ce.id_cuenta_destino
               LEFT JOIN gobernanza.estamento e2 ON e2.id_estamento = cb.id_estamento
              WHERE NOT ce.anulado
              GROUP BY ce.id_empresa, ce.periodo_anio, ce.periodo_mes) c
         ON c.id_empresa = es.id_empresa
        AND c.periodo_anio = EXTRACT(YEAR FROM es.mes)::INT AND c.periodo_mes = EXTRACT(MONTH FROM es.mes)::INT
 WHERE es.afiliados > 0
   AND ((SELECT rolbypassrls OR rolsuper FROM pg_roles WHERE rolname = session_user)
    OR seguridad.fn_empresa_visible(emp.id_empresa, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos()));

-- ----------------------------------------------------------------------------
-- 5. SEGUIMIENTO
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW finanzas.vf_transicion_aporte AS
WITH hoy AS (SELECT date_trunc('month', CURRENT_DATE)::DATE AS mes, (SELECT max(valor) FROM finanzas.porcentaje_permitido WHERE activo) AS meta),
af AS (
    SELECT a.id_estamento_pertenencia AS id_estamento, a.id_persona,
           finanzas.fn_porcentaje_afiliado(a.id_persona, (SELECT mes FROM hoy)) AS pct,
           gobernanza.fn_salario_vigente(ae.id_persona, ae.id_empresa, CURRENT_DATE) AS salario
      FROM gobernanza.afiliado a LEFT JOIN gobernanza.afiliado_empresa ae ON ae.id_persona = a.id_persona
     WHERE a.activo
)
SELECT e.nombre_estamento AS junta, e.tipo_estamento,
       finanzas.fn_porcentaje_junta(e.id_estamento, (SELECT mes FROM hoy)) AS porcentaje_junta,
       (SELECT to_char(max(vigente_desde), 'YYYY-MM') FROM finanzas.porcentaje_junta pj WHERE pj.id_estamento = e.id_estamento) AS desde,
       count(af.id_persona) AS afiliados_activos,
       count(af.id_persona) FILTER (WHERE af.pct < (SELECT meta FROM hoy)) AS afiliados_por_debajo,
       COALESCE(ROUND(SUM(af.salario * ((SELECT meta FROM hoy) - af.pct) / 100) FILTER (WHERE af.pct < (SELECT meta FROM hoy)), 0), 0) AS diferencia_mensual,
       CASE WHEN finanzas.fn_porcentaje_junta(e.id_estamento, (SELECT mes FROM hoy)) < (SELECT meta FROM hoy)
                THEN 'ALERTA MEDIA: LA JUNTA AÚN NO APLICA EL ' || replace((SELECT meta FROM hoy)::TEXT, '.', ',') || ' %'
            ELSE 'APLICA EL ' || replace((SELECT meta FROM hoy)::TEXT, '.', ',') || ' %' END AS diagnostico,
       e.id_estamento
  FROM gobernanza.estamento e
  LEFT JOIN af ON af.id_estamento = e.id_estamento
 WHERE e.activo AND e.tipo_estamento IN ('JUNTA DIRECTIVA NACIONAL', 'SUBDIRECTIVA', 'COMITÉ SECCIONAL')
   AND seguridad.fn_ve_estamento(e.id_estamento)
 GROUP BY e.id_estamento, e.nombre_estamento, e.tipo_estamento;

CREATE OR REPLACE VIEW finanzas.vf_exoneraciones AS
SELECT es.nombre_estamento AS junta, p.primer_nombre || ' ' || p.primer_apellido AS afiliado,
       to_char(x.desde_mes, 'YYYY-MM') AS desde, to_char(x.hasta_mes, 'YYYY-MM') AS hasta,
       (EXTRACT(YEAR FROM age(x.hasta_mes, x.desde_mes)) * 12 + EXTRACT(MONTH FROM age(x.hasta_mes, x.desde_mes)) + 1)::INT AS meses,
       (SELECT COALESCE(SUM(finanzas.fn_aporte_esperado(x.id_persona, ae.id_empresa, g::DATE)), 0)
          FROM generate_series(x.desde_mes, x.hasta_mes, INTERVAL '1 month') g) AS valor_exonerado,
       x.estado, x.motivo,
       (SELECT string_agg(to_char(make_date(c.periodo_anio, c.periodo_mes, 1), 'YYYY-MM'), ', ' ORDER BY c.periodo_anio, c.periodo_mes)
          FROM finanzas.consignacion_empresa c
         WHERE c.id_empresa = ae.id_empresa AND NOT c.anulado
           AND make_date(c.periodo_anio, c.periodo_mes, 1) BETWEEN x.desde_mes AND x.hasta_mes) AS meses_con_consignacion,
       CASE WHEN x.estado = 'SOLICITADA' THEN 'ALERTA MEDIA: SOLICITUD PENDIENTE DE DECISIÓN DE LA JUNTA'
            WHEN x.estado = 'APROBADA' AND EXISTS (
                     SELECT 1 FROM finanzas.consignacion_empresa c WHERE c.id_empresa = ae.id_empresa AND NOT c.anulado
                        AND make_date(c.periodo_anio, c.periodo_mes, 1) BETWEEN x.desde_mes AND x.hasta_mes)
                THEN 'ALERTA MEDIA: LA EMPRESA CONSIGNÓ EN MESES EXONERADOS (VERIFIQUE SI INCLUYÓ EL DESCUENTO PARA DEVOLVERLO O ABONARLO)'
            WHEN x.estado = 'APROBADA' THEN 'EXONERACIÓN VIGENTE O CUMPLIDA'
            ELSE 'NEGADA' END AS diagnostico,
       x.id_exoneracion, x.id_persona, a.id_estamento_pertenencia AS id_estamento
  FROM finanzas.exoneracion x
  JOIN gobernanza.afiliado a ON a.id_persona = x.id_persona
  JOIN gobernanza.persona p ON p.id_persona = x.id_persona
  LEFT JOIN gobernanza.afiliado_empresa ae ON ae.id_persona = x.id_persona
  LEFT JOIN gobernanza.estamento es ON es.id_estamento = a.id_estamento_pertenencia
 WHERE seguridad.fn_ve_estamento(a.id_estamento_pertenencia);

-- ----------------------------------------------------------------------------
-- 6. VERSIÓN, AUDITORÍA, NO BORRAR, SEGURIDAD POR FILAS Y PERMISOS
-- ----------------------------------------------------------------------------
DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['finanzas.porcentaje_permitido', 'finanzas.porcentaje_junta', 'finanzas.porcentaje_afiliado',
                             'finanzas.exoneracion'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_control_version ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_control_version BEFORE UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_auditoria ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_no_borrar ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_no_borrar BEFORE DELETE ON %s FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado()', t);
    END LOOP;
END $$;

SELECT seguridad.fn_aplicar_politicas('finanzas.porcentaje_permitido', 'true', ':N');
SELECT seguridad.fn_aplicar_politicas('finanzas.porcentaje_junta', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('finanzas.porcentaje_afiliado',
    ':N OR EXISTS (SELECT 1 FROM gobernanza.afiliado a WHERE a.id_persona = porcentaje_afiliado.id_persona AND a.id_estamento_pertenencia = ANY(:E))',
    ':N OR EXISTS (SELECT 1 FROM gobernanza.afiliado a WHERE a.id_persona = porcentaje_afiliado.id_persona AND a.id_estamento_pertenencia = ANY(:E))');
SELECT seguridad.fn_aplicar_politicas('finanzas.exoneracion',
    ':N OR EXISTS (SELECT 1 FROM gobernanza.afiliado a WHERE a.id_persona = exoneracion.id_persona AND a.id_estamento_pertenencia = ANY(:E))',
    ':N OR EXISTS (SELECT 1 FROM gobernanza.afiliado a WHERE a.id_persona = exoneracion.id_persona AND a.id_estamento_pertenencia = ANY(:E))');

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        GRANT SELECT, INSERT, UPDATE ON finanzas.porcentaje_permitido, finanzas.porcentaje_junta, finanzas.porcentaje_afiliado,
                                        finanzas.exoneracion TO sgs_app;
        REVOKE DELETE ON finanzas.porcentaje_permitido, finanzas.porcentaje_junta, finanzas.porcentaje_afiliado, finanzas.exoneracion FROM sgs_app;
        GRANT SELECT ON finanzas.vf_transicion_aporte, finanzas.vf_exoneraciones TO sgs_app;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_lectura') THEN
        GRANT SELECT ON finanzas.porcentaje_permitido, finanzas.porcentaje_junta, finanzas.porcentaje_afiliado, finanzas.exoneracion,
                        finanzas.vf_transicion_aporte, finanzas.vf_exoneraciones TO sgs_lectura;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_notificador') THEN
        GRANT SELECT ON finanzas.vf_transicion_aporte, finanzas.vf_exoneraciones TO sgs_notificador;
    END IF;
END $$;
