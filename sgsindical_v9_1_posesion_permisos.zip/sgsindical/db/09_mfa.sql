-- ============================================================================
-- SGSINDICAL v9.1 — 09: SEGUNDO FACTOR DE AUTENTICACIÓN (MFA)
-- Ejecutar DESPUÉS de 08. No modifica los scripts anteriores: los complementa.
-- ----------------------------------------------------------------------------
--  M1. Método principal: aplicación autenticadora (código de 6 dígitos, estándar TOTP). El sistema
--      acepta el código hasta 3 minutos después de que aparece. Alterno: código por correo (10 min).
--      Sin SMS. 10 códigos de recuperación de un solo uso (se guardan solo sus huellas).
--  M2. Obligatorio para los roles que ven datos de otras personas (marca requiere_mfa del rol);
--      opcional para los afiliados. Los usuarios tienen 7 días de plazo para activarlo.
--  M3. Ingreso en dos pasos: con la contraseña la sesión queda "por verificar" 5 minutos; sin el
--      código no se accede a nada. Cinco códigos errados bloquean la cuenta. Un código ya usado no se
--      acepta otra vez. "Recordar este equipo" 30 días (no para el administrador).
--  M4. Doble verificación en acciones críticas (ver claves de redes, roles y permisos, anonimizar,
--      rotar la llave, corregir porcentajes): el código se pide otra vez (vale 5 minutos).
--  M5. Pérdida del celular: códigos de recuperación; si tampoco los tiene, el administrador solicita el
--      reinicio y lo aprueba la Presidencia Nacional; el administrador no se reinicia a sí mismo.
--  M6. La clave secreta del autenticador se guarda CIFRADA (AES-256, la misma llave de las claves de
--      redes) en el esquema secretos, al que la aplicación no tiene acceso directo.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. COLUMNAS NUEVAS
-- ----------------------------------------------------------------------------
ALTER TABLE seguridad.rol_app ADD COLUMN IF NOT EXISTS requiere_mfa BOOLEAN NOT NULL DEFAULT TRUE;
UPDATE seguridad.rol_app SET requiere_mfa = (codigo_rol <> 'AFILIADO') WHERE requiere_mfa IS DISTINCT FROM (codigo_rol <> 'AFILIADO');
COMMENT ON COLUMN seguridad.rol_app.requiere_mfa IS 'El rol exige segundo factor (los que ven datos de otras personas).';

ALTER TABLE seguridad.usuario ADD COLUMN IF NOT EXISTS mfa_activo BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE seguridad.usuario ADD COLUMN IF NOT EXISTS mfa_plazo_hasta TIMESTAMP WITH TIME ZONE;
UPDATE seguridad.usuario SET mfa_plazo_hasta = now() + INTERVAL '7 days' WHERE mfa_plazo_hasta IS NULL;
ALTER TABLE seguridad.usuario ALTER COLUMN mfa_plazo_hasta SET DEFAULT (now() + INTERVAL '7 days');
COMMENT ON COLUMN seguridad.usuario.mfa_plazo_hasta IS 'Hasta cuándo puede ingresar sin haber activado el MFA (si su rol lo exige).';

ALTER TABLE seguridad.sesion ADD COLUMN IF NOT EXISTS mfa_verificada BOOLEAN NOT NULL DEFAULT TRUE;
ALTER TABLE seguridad.sesion ALTER COLUMN mfa_verificada SET DEFAULT FALSE;   -- las sesiones nuevas nacen sin verificar
ALTER TABLE seguridad.sesion ADD COLUMN IF NOT EXISTS mfa_reciente_en TIMESTAMP WITH TIME ZONE;
ALTER TABLE seguridad.sesion ADD COLUMN IF NOT EXISTS mfa_metodo VARCHAR(16);

ALTER TABLE auditoria.registro_acceso DROP CONSTRAINT IF EXISTS registro_acceso_evento_check;
ALTER TABLE auditoria.registro_acceso ADD CONSTRAINT registro_acceso_evento_check CHECK (evento IN (
    'LOGIN_OK', 'LOGIN_FALLIDO', 'CUENTA_BLOQUEADA', 'LOGOUT', 'CAMBIO_CONTRASENA', 'ACCESO_DENEGADO', 'SESION_REVOCADA',
    'MFA_OK', 'MFA_FALLIDO', 'MFA_ACTIVADO', 'MFA_RECUPERACION', 'MFA_REINICIADO', 'MFA_PASO_ADICIONAL'));

-- ----------------------------------------------------------------------------
-- 2. TABLAS (secreto cifrado, códigos de recuperación, códigos por correo, equipos, reinicios)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS secretos.mfa_secreto (
    id_usuario BIGINT PRIMARY KEY REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    secreto_cifrado BYTEA NOT NULL CHECK (octet_length(secreto_cifrado) > 28),
    version_llave INT NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT FALSE,
    ultimo_paso BIGINT NOT NULL DEFAULT 0,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_activacion TIMESTAMP WITH TIME ZONE
);
COMMENT ON TABLE secretos.mfa_secreto IS 'Clave del autenticador de cada usuario, cifrada con AES-256-GCM. La aplicación solo la usa por funciones.';

CREATE TABLE IF NOT EXISTS seguridad.mfa_recuperacion (
    id_codigo BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_usuario BIGINT NOT NULL REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    hash_codigo VARCHAR(64) NOT NULL,
    vigente BOOLEAN NOT NULL DEFAULT TRUE,
    usado_en TIMESTAMP WITH TIME ZONE,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_mfa_recuperacion_usuario ON seguridad.mfa_recuperacion (id_usuario) WHERE vigente;

CREATE TABLE IF NOT EXISTS seguridad.mfa_codigo_correo (
    id_codigo BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_usuario BIGINT NOT NULL REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    hash_codigo VARCHAR(64) NOT NULL,
    expira TIMESTAMP WITH TIME ZONE NOT NULL,
    usado_en TIMESTAMP WITH TIME ZONE,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_mfa_correo_usuario ON seguridad.mfa_codigo_correo (id_usuario, fecha_creacion DESC);

CREATE TABLE IF NOT EXISTS seguridad.mfa_equipo (
    id_equipo BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_usuario BIGINT NOT NULL REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    hash_token VARCHAR(64) NOT NULL UNIQUE,
    descripcion VARCHAR(200),
    expira TIMESTAMP WITH TIME ZONE NOT NULL,
    revocado BOOLEAN NOT NULL DEFAULT FALSE,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_mfa_equipo_usuario ON seguridad.mfa_equipo (id_usuario);
COMMENT ON TABLE seguridad.mfa_equipo IS 'Equipos recordados 30 días (no aplica al administrador). Se revocan al cambiar la contraseña o reiniciar el MFA.';

CREATE TABLE IF NOT EXISTS seguridad.mfa_reinicio (
    id_reinicio BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_usuario BIGINT NOT NULL REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    motivo TEXT NOT NULL CHECK (length(trim(motivo)) >= 10),
    estado VARCHAR(10) NOT NULL DEFAULT 'PENDIENTE' CHECK (estado IN ('PENDIENTE', 'APROBADO', 'RECHAZADO')),
    id_usuario_solicita BIGINT NOT NULL REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    fecha_solicitud TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    id_usuario_decide BIGINT REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    fecha_decision TIMESTAMP WITH TIME ZONE,
    observacion TEXT,
    version INT NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS ix_mfa_reinicio_usuario ON seguridad.mfa_reinicio (id_usuario);
CREATE INDEX IF NOT EXISTS ix_mfa_reinicio_solicita ON seguridad.mfa_reinicio (id_usuario_solicita);
CREATE INDEX IF NOT EXISTS ix_mfa_reinicio_decide ON seguridad.mfa_reinicio (id_usuario_decide);
CREATE UNIQUE INDEX IF NOT EXISTS ux_mfa_reinicio_pendiente ON seguridad.mfa_reinicio (id_usuario) WHERE estado = 'PENDIENTE';
COMMENT ON TABLE seguridad.mfa_reinicio IS 'Reinicio del MFA de un usuario que perdió su celular y sus códigos: lo pide el administrador y lo aprueba la Presidencia Nacional.';

-- ----------------------------------------------------------------------------
-- 3. FUNCIONES DEL USUARIO ACTUAL (la aplicación no lee las tablas directamente)
-- ----------------------------------------------------------------------------
-- Estado para decidir el ingreso (se llama antes de crear la sesión)
CREATE OR REPLACE FUNCTION seguridad.fn_mfa_estado_ingreso(p_id_usuario BIGINT, p_hash_equipo TEXT)
RETURNS TABLE (requiere BOOLEAN, activo BOOLEAN, plazo_hasta TIMESTAMPTZ, equipo_valido BOOLEAN, es_admin BOOLEAN) AS $$
    SELECT r.requiere_mfa, u.mfa_activo, u.mfa_plazo_hasta,
           p_hash_equipo IS NOT NULL AND u.codigo_rol <> 'ADMIN' AND EXISTS (
               SELECT 1 FROM seguridad.mfa_equipo e WHERE e.id_usuario = u.id_usuario AND e.hash_token = p_hash_equipo
                  AND NOT e.revocado AND e.expira > now()),
           u.codigo_rol = 'ADMIN'
      FROM seguridad.usuario u JOIN seguridad.rol_app r ON r.codigo_rol = u.codigo_rol
     WHERE u.id_usuario = p_id_usuario;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Secreto del autenticador del usuario actual (cifrado; se descifra en el servidor de aplicación)
CREATE OR REPLACE FUNCTION seguridad.fn_mfa_mi_secreto()
RETURNS TABLE (secreto_cifrado BYTEA, version_llave INT, activo BOOLEAN, ultimo_paso BIGINT) AS $$
    SELECT s.secreto_cifrado, s.version_llave, s.activo, s.ultimo_paso FROM secretos.mfa_secreto s
     WHERE s.id_usuario = seguridad.fn_id_usuario_actual();
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Configurar: guarda un secreto nuevo pendiente de confirmación (no toca uno ya activo)
CREATE OR REPLACE FUNCTION seguridad.fn_mfa_guardar_pendiente(p_cifrado BYTEA, p_version INT)
RETURNS VOID AS $$
DECLARE v_u BIGINT := seguridad.fn_id_usuario_actual();
BEGIN
    IF v_u IS NULL THEN RAISE EXCEPTION 'Usuario no identificado.'; END IF;
    IF EXISTS (SELECT 1 FROM secretos.mfa_secreto WHERE id_usuario = v_u AND activo) THEN
        RAISE EXCEPTION 'Ya tiene el MFA activo. Si cambió de celular, ingrese con un código de recuperación y vuelva a configurarlo desde «Mi seguridad».';
    END IF;
    INSERT INTO secretos.mfa_secreto (id_usuario, secreto_cifrado, version_llave) VALUES (v_u, p_cifrado, p_version)
    ON CONFLICT (id_usuario) DO UPDATE SET secreto_cifrado = EXCLUDED.secreto_cifrado, version_llave = EXCLUDED.version_llave,
                                           activo = FALSE, ultimo_paso = 0, fecha_creacion = now(), fecha_activacion = NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Reconfigurar (celular nuevo): solo con la sesión verificada; desactiva el factor actual
CREATE OR REPLACE FUNCTION seguridad.fn_mfa_reconfigurar(p_cifrado BYTEA, p_version INT, p_id_sesion UUID)
RETURNS VOID AS $$
DECLARE v_u BIGINT := seguridad.fn_id_usuario_actual();
BEGIN
    IF NOT EXISTS (SELECT 1 FROM seguridad.sesion WHERE id_sesion = p_id_sesion AND id_usuario = v_u AND mfa_verificada AND NOT revocada) THEN
        RAISE EXCEPTION 'Verifique primero su sesión.';
    END IF;
    UPDATE secretos.mfa_secreto SET secreto_cifrado = p_cifrado, version_llave = p_version, activo = FALSE, ultimo_paso = 0,
           fecha_creacion = now(), fecha_activacion = NULL
     WHERE id_usuario = v_u;
    IF NOT FOUND THEN
        INSERT INTO secretos.mfa_secreto (id_usuario, secreto_cifrado, version_llave) VALUES (v_u, p_cifrado, p_version);
    END IF;
    UPDATE seguridad.usuario SET mfa_activo = FALSE WHERE id_usuario = v_u;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Anti-repetición: un paso de tiempo (código) solo se acepta una vez y en orden
CREATE OR REPLACE FUNCTION seguridad.fn_mfa_usar_paso(p_paso BIGINT)
RETURNS BOOLEAN AS $$
    WITH u AS (
        UPDATE secretos.mfa_secreto SET ultimo_paso = p_paso
         WHERE id_usuario = seguridad.fn_id_usuario_actual() AND ultimo_paso < p_paso RETURNING 1)
    SELECT EXISTS (SELECT 1 FROM u);
$$ LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Activación: confirma el secreto pendiente y deja los 10 códigos de recuperación
CREATE OR REPLACE FUNCTION seguridad.fn_mfa_activar(p_hashes TEXT[])
RETURNS VOID AS $$
DECLARE v_u BIGINT := seguridad.fn_id_usuario_actual();
BEGIN
    UPDATE secretos.mfa_secreto SET activo = TRUE, fecha_activacion = now() WHERE id_usuario = v_u;
    IF NOT FOUND THEN RAISE EXCEPTION 'Primero genere el código QR.'; END IF;
    UPDATE seguridad.usuario SET mfa_activo = TRUE WHERE id_usuario = v_u;
    UPDATE seguridad.mfa_recuperacion SET vigente = FALSE WHERE id_usuario = v_u AND vigente;
    INSERT INTO seguridad.mfa_recuperacion (id_usuario, hash_codigo) SELECT v_u, h FROM unnest(p_hashes) h;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_mfa_regenerar_recuperacion(p_hashes TEXT[])
RETURNS VOID AS $$
DECLARE v_u BIGINT := seguridad.fn_id_usuario_actual();
BEGIN
    IF NOT EXISTS (SELECT 1 FROM seguridad.usuario WHERE id_usuario = v_u AND mfa_activo) THEN RAISE EXCEPTION 'Active primero el MFA.'; END IF;
    UPDATE seguridad.mfa_recuperacion SET vigente = FALSE WHERE id_usuario = v_u AND vigente;
    INSERT INTO seguridad.mfa_recuperacion (id_usuario, hash_codigo) SELECT v_u, h FROM unnest(p_hashes) h;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Usa un código de recuperación; devuelve cuántos quedan (o -1 si no es válido)
CREATE OR REPLACE FUNCTION seguridad.fn_mfa_usar_recuperacion(p_hash TEXT)
RETURNS INT AS $$
DECLARE v_u BIGINT := seguridad.fn_id_usuario_actual(); v_id BIGINT;
BEGIN
    UPDATE seguridad.mfa_recuperacion SET vigente = FALSE, usado_en = now()
     WHERE id_codigo = (SELECT id_codigo FROM seguridad.mfa_recuperacion WHERE id_usuario = v_u AND hash_codigo = p_hash AND vigente LIMIT 1)
    RETURNING id_codigo INTO v_id;
    IF v_id IS NULL THEN RETURN -1; END IF;
    RETURN (SELECT count(*) FROM seguridad.mfa_recuperacion WHERE id_usuario = v_u AND vigente);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_mfa_codigos_restantes()
RETURNS INT AS $$
    SELECT count(*)::INT FROM seguridad.mfa_recuperacion WHERE id_usuario = seguridad.fn_id_usuario_actual() AND vigente;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Código por correo (10 minutos; como máximo uno por minuto)
CREATE OR REPLACE FUNCTION seguridad.fn_mfa_crear_codigo_correo(p_hash TEXT)
RETURNS TEXT AS $$
DECLARE v_u BIGINT := seguridad.fn_id_usuario_actual(); v_correo TEXT;
BEGIN
    SELECT correo_electronico INTO v_correo FROM seguridad.usuario WHERE id_usuario = v_u AND activo;
    IF v_correo IS NULL THEN RAISE EXCEPTION 'Su usuario no tiene correo registrado: use la aplicación o un código de recuperación.'; END IF;
    IF EXISTS (SELECT 1 FROM seguridad.mfa_codigo_correo WHERE id_usuario = v_u AND fecha_creacion > now() - INTERVAL '1 minute') THEN
        RAISE EXCEPTION 'Ya se envió un código hace menos de un minuto. Revise su correo.';
    END IF;
    UPDATE seguridad.mfa_codigo_correo SET usado_en = now() WHERE id_usuario = v_u AND usado_en IS NULL;
    INSERT INTO seguridad.mfa_codigo_correo (id_usuario, hash_codigo, expira) VALUES (v_u, p_hash, now() + INTERVAL '10 minutes');
    RETURN v_correo;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_mfa_usar_codigo_correo(p_hash TEXT)
RETURNS BOOLEAN AS $$
    WITH u AS (
        UPDATE seguridad.mfa_codigo_correo SET usado_en = now()
         WHERE id_usuario = seguridad.fn_id_usuario_actual() AND hash_codigo = p_hash AND usado_en IS NULL AND expira > now()
        RETURNING 1)
    SELECT EXISTS (SELECT 1 FROM u);
$$ LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Marca la sesión: verificada (ingreso) o con verificación reciente (acciones críticas)
CREATE OR REPLACE FUNCTION seguridad.fn_mfa_marcar_sesion(p_id_sesion UUID, p_metodo TEXT)
RETURNS VOID AS $$
    UPDATE seguridad.sesion SET mfa_verificada = TRUE, mfa_reciente_en = now(), mfa_metodo = left(p_metodo, 16)
     WHERE id_sesion = p_id_sesion AND id_usuario = seguridad.fn_id_usuario_actual();
$$ LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_mfa_recordar_equipo(p_hash TEXT, p_descripcion TEXT)
RETURNS TIMESTAMPTZ AS $$
DECLARE v_u BIGINT := seguridad.fn_id_usuario_actual(); v_exp TIMESTAMPTZ := now() + INTERVAL '30 days';
BEGIN
    IF EXISTS (SELECT 1 FROM seguridad.usuario WHERE id_usuario = v_u AND codigo_rol = 'ADMIN') THEN
        RAISE EXCEPTION 'El administrador no puede recordar equipos: siempre debe escribir el código.';
    END IF;
    INSERT INTO seguridad.mfa_equipo (id_usuario, hash_token, descripcion, expira) VALUES (v_u, p_hash, left(p_descripcion, 200), v_exp);
    RETURN v_exp;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_mfa_revocar_equipos(p_id_usuario BIGINT)
RETURNS INT AS $$
DECLARE n INT;
BEGIN
    IF p_id_usuario IS DISTINCT FROM seguridad.fn_id_usuario_actual() AND NOT seguridad.fn_es_admin() THEN
        RAISE EXCEPTION 'Solo puede cerrar sus propios equipos.';
    END IF;
    UPDATE seguridad.mfa_equipo SET revocado = TRUE WHERE id_usuario = p_id_usuario AND NOT revocado;
    GET DIAGNOSTICS n = ROW_COUNT;
    RETURN n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 4. REINICIO DEL MFA (doble control: administrador + Presidencia Nacional)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION seguridad.fn_mfa_solicitar_reinicio(p_id_usuario BIGINT, p_motivo TEXT)
RETURNS BIGINT AS $$
DECLARE v_id BIGINT;
BEGIN
    IF NOT seguridad.fn_es_admin() THEN RAISE EXCEPTION 'El reinicio del MFA lo solicita el administrador.'; END IF;
    IF p_id_usuario = seguridad.fn_id_usuario_actual() THEN
        RAISE EXCEPTION 'El administrador no puede reiniciar su propio MFA (doble control). Use sus códigos de recuperación u otro administrador.';
    END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo (mínimo 10 caracteres).'; END IF;
    IF NOT EXISTS (SELECT 1 FROM seguridad.usuario WHERE id_usuario = p_id_usuario) THEN RAISE EXCEPTION 'El usuario no existe.'; END IF;
    INSERT INTO seguridad.mfa_reinicio (id_usuario, motivo, id_usuario_solicita) VALUES (p_id_usuario, trim(p_motivo), seguridad.fn_id_usuario_actual())
    RETURNING id_reinicio INTO v_id;
    RETURN v_id;
EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION 'Ya hay un reinicio pendiente para ese usuario.';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_mfa_decidir_reinicio(p_id BIGINT, p_aprobar BOOLEAN, p_observacion TEXT DEFAULT NULL)
RETURNS TABLE (estado TEXT, correo TEXT, nombre TEXT) AS $$
DECLARE v_r seguridad.mfa_reinicio%ROWTYPE;
BEGIN
    IF NOT seguridad.fn_es_presidente_nacional() THEN RAISE EXCEPTION 'El reinicio del MFA lo aprueba la Presidencia Nacional.'; END IF;
    SELECT * INTO v_r FROM seguridad.mfa_reinicio WHERE id_reinicio = p_id FOR UPDATE;
    IF v_r.id_reinicio IS NULL THEN RAISE EXCEPTION 'La solicitud no existe.'; END IF;
    IF v_r.estado <> 'PENDIENTE' THEN RAISE EXCEPTION 'La solicitud ya fue decidida.'; END IF;
    IF v_r.id_usuario_solicita = seguridad.fn_id_usuario_actual() OR v_r.id_usuario = seguridad.fn_id_usuario_actual() THEN
        RAISE EXCEPTION 'No puede decidir una solicitud que usted pidió o que es sobre su propio usuario.';
    END IF;
    UPDATE seguridad.mfa_reinicio SET estado = CASE WHEN p_aprobar THEN 'APROBADO' ELSE 'RECHAZADO' END,
           id_usuario_decide = seguridad.fn_id_usuario_actual(), fecha_decision = now(), observacion = NULLIF(trim(COALESCE(p_observacion, '')), '')
     WHERE id_reinicio = p_id;
    IF p_aprobar THEN
        UPDATE secretos.mfa_secreto SET activo = FALSE, ultimo_paso = 0 WHERE id_usuario = v_r.id_usuario;
        UPDATE seguridad.usuario SET mfa_activo = FALSE, mfa_plazo_hasta = now() WHERE id_usuario = v_r.id_usuario;
        UPDATE seguridad.mfa_recuperacion SET vigente = FALSE WHERE id_usuario = v_r.id_usuario AND vigente;
        UPDATE seguridad.mfa_equipo SET revocado = TRUE WHERE id_usuario = v_r.id_usuario AND NOT revocado;
        UPDATE seguridad.sesion SET revocada = TRUE WHERE id_usuario = v_r.id_usuario AND NOT revocada;
        INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, detalle)
        SELECT u.nombre_usuario, 'MFA_REINICIADO', 'Reinicio ' || p_id || ': ' || v_r.motivo FROM seguridad.usuario u WHERE u.id_usuario = v_r.id_usuario;
    END IF;
    RETURN QUERY SELECT CASE WHEN p_aprobar THEN 'APROBADO' ELSE 'RECHAZADO' END, u.correo_electronico::TEXT, u.nombre_completo::TEXT
                   FROM seguridad.usuario u WHERE u.id_usuario = v_r.id_usuario;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Rotación de la llave de cifrado: los secretos del MFA también se re-cifran
CREATE OR REPLACE FUNCTION seguridad.fn_mfa_secretos_para_rotar()
RETURNS TABLE (id_usuario BIGINT, secreto_cifrado BYTEA, version_llave INT) AS $$
BEGIN
    IF NOT seguridad.fn_es_admin() THEN RAISE EXCEPTION 'Solo el administrador rota la llave.'; END IF;
    RETURN QUERY SELECT s.id_usuario, s.secreto_cifrado, s.version_llave FROM secretos.mfa_secreto s;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_mfa_reemplazar_cifrado(p_id_usuario BIGINT, p_cifrado BYTEA, p_version INT)
RETURNS VOID AS $$
BEGIN
    IF NOT seguridad.fn_es_admin() THEN RAISE EXCEPTION 'Solo el administrador rota la llave.'; END IF;
    UPDATE secretos.mfa_secreto SET secreto_cifrado = p_cifrado, version_llave = p_version WHERE id_usuario = p_id_usuario;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Control: usuarios cuyo rol exige MFA y aún no lo activan
CREATE OR REPLACE VIEW auditoria.v_mfa_pendiente AS
SELECT u.nombre_usuario, u.nombre_completo, r.nombre_rol AS rol, u.mfa_plazo_hasta AS plazo,
       CASE WHEN u.mfa_plazo_hasta < now() THEN 'ALERTA ALTA: PLAZO VENCIDO (DEBE ACTIVAR EL MFA AL INGRESAR)'
            ELSE 'ALERTA MEDIA: AÚN NO ACTIVA EL SEGUNDO FACTOR' END AS diagnostico,
       u.id_usuario
  FROM seguridad.usuario u JOIN seguridad.rol_app r ON r.codigo_rol = u.codigo_rol
 WHERE u.activo AND r.requiere_mfa AND NOT u.mfa_activo
   AND (seguridad.fn_es_admin() OR (SELECT rolbypassrls OR rolsuper FROM pg_roles WHERE rolname = session_user));

-- ----------------------------------------------------------------------------
-- 5. PERMISOS, AUDITORÍA Y NO BORRAR
-- ----------------------------------------------------------------------------
DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['seguridad.mfa_reinicio'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_control_version ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_control_version BEFORE UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version()', t);
    END LOOP;
    FOREACH t IN ARRAY ARRAY['seguridad.mfa_reinicio', 'seguridad.mfa_equipo', 'seguridad.mfa_recuperacion'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_auditoria ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_no_borrar ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_no_borrar BEFORE DELETE ON %s FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado()', t);
    END LOOP;
END $$;

DO $$
DECLARE r TEXT;
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        REVOKE ALL ON secretos.mfa_secreto FROM sgs_app;
        REVOKE ALL ON seguridad.mfa_recuperacion, seguridad.mfa_codigo_correo, seguridad.mfa_equipo FROM sgs_app;
        GRANT SELECT ON seguridad.mfa_reinicio, auditoria.v_mfa_pendiente TO sgs_app;
        REVOKE INSERT, UPDATE, DELETE ON seguridad.mfa_reinicio FROM sgs_app;
    END IF;
    FOREACH r IN ARRAY ARRAY['sgs_lectura', 'sgs_notificador'] LOOP
        CONTINUE WHEN NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r);
        EXECUTE format('REVOKE ALL ON secretos.mfa_secreto, seguridad.mfa_recuperacion, seguridad.mfa_codigo_correo, seguridad.mfa_equipo FROM %I', r);
    END LOOP;
END $$;
-- Las funciones del MFA solo las usa la aplicación con un usuario identificado
DO $$
DECLARE f TEXT;
BEGIN
    FOR f IN SELECT p.oid::regprocedure::TEXT FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
              WHERE n.nspname = 'seguridad' AND p.proname LIKE 'fn\_mfa\_%' LOOP
        EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC', f);
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
            EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO sgs_app', f);
        END IF;
    END LOOP;
END $$;
-- Nota: las sesiones abiertas al instalar este script quedan verificadas (la columna se creó con valor TRUE);
-- las nuevas nacen sin verificar. Volver a ejecutar el script no cambia sesiones existentes.
