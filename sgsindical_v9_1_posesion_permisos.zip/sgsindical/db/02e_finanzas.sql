-- ============================================================================
-- SGSINDICAL v9.1 — 02e: GESTIÓN FINANCIERA
-- Ejecutar DESPUÉS de 02d y ANTES de 03.
-- ----------------------------------------------------------------------------
--  F1. Cuentas: una cuenta nacional (de la Junta Nacional) y, opcionalmente, UNA subcuenta hija
--      por Subdirectiva o Comité. Sin subcuenta, su dinero vive en la cuenta nacional.
--  F2. Fondos: cada junta tiene su fondo. Cada aporte se reparte 20 % Junta Nacional y 80 % la
--      subdirectiva o comité de pertenencia del afiliado (parámetro PORCENTAJE_NACIONAL).
--  F3. Transferencias pendientes: diferencia entre el fondo de la junta y el saldo de su subcuenta.
--  F3b. Las empresas y demás personas pueden consignar en la subcuenta de la subdirectiva o comité, o
--      en la cuenta nacional (padre). Una empresa puede repartir el pago de un mes entre ambas (una
--      consignación por cuenta y mes). El dinero se reparte por fondos según la pertenencia de cada
--      afiliado, sin importar a qué cuenta llegó; Transferencias pendientes indica cómo equilibrar.
--  F4. Egresos con soporte PDF (huella SHA-256), rubro y DOBLE APROBACIÓN: Tesorero y Presidente
--      de la junta (en comités: Secretario General y Presidente). El Fiscal revisa, no aprueba.
--      Un egreso aprobado no se modifica: se anula con motivo.
--  F5. Presupuesto anual por junta y rubro, aprobado con acta (ACT). Pasar del 100 % exige un
--      acta de autorización.
--  F6. Historial de salarios: el 0.7 % y la mora se calculan con el salario vigente en cada mes.
--  F7. Mora de empresas: meses sin consignación o con consignación menor a la esperada.
--  F8. Cierre contable mensual por junta y conciliación bancaria.
--  F9. Informes y alertas financieras para el Fiscal.
-- ============================================================================
CREATE SCHEMA IF NOT EXISTS finanzas_interno;   -- vistas base sin filtro territorial (sin permisos para la app)
REVOKE ALL ON SCHEMA finanzas_interno FROM PUBLIC;

-- ----------------------------------------------------------------------------
-- 0. PARÁMETROS Y CATÁLOGO DE RUBROS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS finanzas.parametro (
    codigo VARCHAR(40) PRIMARY KEY,
    valor NUMERIC NOT NULL,
    descripcion TEXT NOT NULL,
    version INT NOT NULL DEFAULT 1
);
INSERT INTO finanzas.parametro (codigo, valor, descripcion) VALUES
    ('PORCENTAJE_APORTE', 0.7, 'Porcentaje del salario que se descuenta como aporte sindical.'),
    ('PORCENTAJE_NACIONAL', 20, 'Porcentaje de cada aporte que corresponde a la Junta Directiva Nacional (el resto es de la subdirectiva o comité).'),
    ('DIA_LIMITE_CONSIGNACION', 15, 'Día del mes siguiente hasta el cual la empresa puede consignar los aportes del mes.'),
    ('TOLERANCIA_PESOS', 1000, 'Diferencia máxima (en pesos) que se acepta en conciliaciones y transferencias.'),
    ('EXIGIR_PRESUPUESTO', 1, '1 = un egreso solo se aprueba dentro de un presupuesto aprobado (o con acta de autorización); 0 = no se exige.'),
    ('DIAS_EGRESO_SIN_APROBAR', 15, 'Días tras los cuales un egreso registrado y no aprobado genera alerta.')
ON CONFLICT (codigo) DO UPDATE SET descripcion = EXCLUDED.descripcion;

CREATE OR REPLACE FUNCTION finanzas.fn_parametro(p_codigo TEXT)
RETURNS NUMERIC AS $$ SELECT valor FROM finanzas.parametro WHERE codigo = p_codigo; $$
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE TABLE IF NOT EXISTS finanzas.rubro (
    id_rubro BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    codigo VARCHAR(20) NOT NULL UNIQUE,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    version INT NOT NULL DEFAULT 1
);
INSERT INTO finanzas.rubro (codigo, nombre) VALUES
    ('VIATICOS', 'VIÁTICOS Y TRANSPORTE'), ('HONORARIOS', 'HONORARIOS JURÍDICOS Y PROFESIONALES'),
    ('PAPELERIA', 'PAPELERÍA Y ÚTILES'), ('EVENTOS', 'ASAMBLEAS, REUNIONES Y EVENTOS'),
    ('EDUCACION', 'EDUCACIÓN Y FORMACIÓN SINDICAL'), ('SOLIDARIDAD', 'AUXILIOS Y SOLIDARIDAD'),
    ('COMUNICACIONES', 'COMUNICACIONES Y PUBLICIDAD'), ('SEDE', 'ARRIENDO Y SERVICIOS DE LA SEDE'),
    ('BANCARIOS', 'GASTOS BANCARIOS'), ('OTROS', 'OTROS GASTOS')
ON CONFLICT (codigo) DO NOTHING;

-- ----------------------------------------------------------------------------
-- 1. CUENTAS: NACIONAL Y SUBCUENTAS HIJAS
-- ----------------------------------------------------------------------------
ALTER TABLE finanzas.cuenta_bancaria
    ADD COLUMN IF NOT EXISTS id_cuenta_padre BIGINT REFERENCES finanzas.cuenta_bancaria(id_cuenta) ON DELETE RESTRICT;
CREATE INDEX IF NOT EXISTS ix_cuenta_padre ON finanzas.cuenta_bancaria (id_cuenta_padre);
CREATE UNIQUE INDEX IF NOT EXISTS ux_una_subcuenta_por_estamento ON finanzas.cuenta_bancaria (id_estamento) WHERE NOT es_cuenta_nacional;

CREATE OR REPLACE FUNCTION finanzas.fn_validar_cuenta()
RETURNS TRIGGER AS $$
DECLARE v_tipo VARCHAR(30); v_padre_nacional BOOLEAN;
BEGIN
    IF NEW.es_cuenta_nacional THEN
        IF NEW.id_estamento IS NULL THEN
            SELECT id_estamento INTO NEW.id_estamento FROM gobernanza.estamento WHERE tipo_estamento = 'JUNTA DIRECTIVA NACIONAL';
        END IF;
        SELECT tipo_estamento INTO v_tipo FROM gobernanza.estamento WHERE id_estamento = NEW.id_estamento;
        IF v_tipo IS DISTINCT FROM 'JUNTA DIRECTIVA NACIONAL' THEN
            RAISE EXCEPTION 'Una cuenta nacional pertenece a la Junta Directiva Nacional.';
        END IF;
        IF NEW.id_cuenta_padre IS NOT NULL THEN
            RAISE EXCEPTION 'Una cuenta nacional no tiene cuenta padre.';
        END IF;
    ELSE
        SELECT tipo_estamento INTO v_tipo FROM gobernanza.estamento WHERE id_estamento = NEW.id_estamento;
        IF v_tipo IS NULL OR v_tipo NOT IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL') THEN
            RAISE EXCEPTION 'Una subcuenta pertenece a una Subdirectiva o Comité Seccional.';
        END IF;
        SELECT es_cuenta_nacional INTO v_padre_nacional FROM finanzas.cuenta_bancaria WHERE id_cuenta = NEW.id_cuenta_padre;
        IF NEW.id_cuenta_padre IS NULL OR NOT COALESCE(v_padre_nacional, FALSE) THEN
            RAISE EXCEPTION 'La subcuenta de una subdirectiva o comité debe ser hija de una cuenta nacional.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_validar_cuenta ON finanzas.cuenta_bancaria;
CREATE TRIGGER trg_validar_cuenta BEFORE INSERT OR UPDATE ON finanzas.cuenta_bancaria
    FOR EACH ROW EXECUTE FUNCTION finanzas.fn_validar_cuenta();

-- ¿Desde qué cuenta puede mover dinero una junta? Su subcuenta, o la nacional si no tiene subcuenta.
CREATE OR REPLACE FUNCTION finanzas.fn_cuenta_valida(p_id_estamento BIGINT, p_id_cuenta BIGINT)
RETURNS BOOLEAN AS $$
    SELECT EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria c WHERE c.id_cuenta = p_id_cuenta AND c.id_estamento = p_id_estamento)
        OR (EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria c WHERE c.id_cuenta = p_id_cuenta AND c.es_cuenta_nacional)
            AND NOT EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria s WHERE s.id_estamento = p_id_estamento AND NOT s.es_cuenta_nacional));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Una junta sin subcuenta necesita ver la cuenta nacional (donde está su dinero) para registrar movimientos
CREATE OR REPLACE FUNCTION seguridad.fn_usa_cuenta_nacional(p_estamentos BIGINT[])
RETURNS BOOLEAN AS $$
    SELECT EXISTS (SELECT 1 FROM unnest(p_estamentos) x(id)
                    WHERE NOT EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria s WHERE s.id_estamento = x.id AND NOT s.es_cuenta_nacional));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Filtro territorial de las vistas financieras (roles con BYPASSRLS ven todo: reportes y correos)
CREATE OR REPLACE FUNCTION seguridad.fn_ve_estamento(p_id_estamento BIGINT)
RETURNS BOOLEAN AS $$
    SELECT (SELECT rolbypassrls OR rolsuper FROM pg_roles WHERE rolname = session_user)
        OR seguridad.fn_ambito_nacional()
        OR COALESCE(p_id_estamento = ANY(seguridad.fn_ambito_estamentos()), FALSE);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 2. HISTORIAL DE SALARIOS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.salario_historico (
    id_salario BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_persona BIGINT NOT NULL,
    id_empresa BIGINT NOT NULL,
    salario NUMERIC(12,2) NOT NULL CHECK (salario > 0),
    vigente_desde DATE NOT NULL,
    fecha_registro TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_registro VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    FOREIGN KEY (id_persona, id_empresa) REFERENCES gobernanza.afiliado_empresa (id_persona, id_empresa) ON DELETE CASCADE,
    UNIQUE (id_persona, id_empresa, vigente_desde)
);
CREATE INDEX IF NOT EXISTS ix_salario_historico_empresa ON gobernanza.salario_historico (id_empresa);

INSERT INTO gobernanza.salario_historico (id_persona, id_empresa, salario, vigente_desde)
SELECT id_persona, id_empresa, salario_base, fecha_ingreso_empresa FROM gobernanza.afiliado_empresa
ON CONFLICT DO NOTHING;

CREATE OR REPLACE FUNCTION gobernanza.fn_registrar_salario()
RETURNS TRIGGER AS $$
DECLARE v_desde DATE;
BEGIN
    IF TG_OP = 'INSERT' THEN
        v_desde := COALESCE(NULLIF(current_setting('app.salario_desde', true), '')::DATE, NEW.fecha_ingreso_empresa);
    ELSIF NEW.salario_base IS DISTINCT FROM OLD.salario_base THEN
        v_desde := COALESCE(NULLIF(current_setting('app.salario_desde', true), '')::DATE, CURRENT_DATE);
    ELSE
        RETURN NEW;
    END IF;
    INSERT INTO gobernanza.salario_historico (id_persona, id_empresa, salario, vigente_desde)
    VALUES (NEW.id_persona, NEW.id_empresa, NEW.salario_base, v_desde)
    ON CONFLICT (id_persona, id_empresa, vigente_desde) DO UPDATE SET salario = EXCLUDED.salario;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_registrar_salario ON gobernanza.afiliado_empresa;
CREATE TRIGGER trg_registrar_salario AFTER INSERT OR UPDATE OF salario_base ON gobernanza.afiliado_empresa
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_registrar_salario();

CREATE OR REPLACE FUNCTION gobernanza.fn_salario_vigente(p_id_persona BIGINT, p_id_empresa BIGINT, p_fecha DATE)
RETURNS NUMERIC AS $$
    SELECT COALESCE(
        (SELECT salario FROM gobernanza.salario_historico
          WHERE id_persona = p_id_persona AND id_empresa = p_id_empresa AND vigente_desde <= p_fecha
          ORDER BY vigente_desde DESC LIMIT 1),
        (SELECT salario_base FROM gobernanza.afiliado_empresa WHERE id_persona = p_id_persona AND id_empresa = p_id_empresa));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 3. PRESUPUESTO, INGRESOS, EGRESOS, TRANSFERENCIAS, CIERRES Y CONCILIACIONES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS finanzas.presupuesto (
    id_presupuesto BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    anio INT NOT NULL CHECK (anio BETWEEN 2000 AND 2100),
    id_rubro BIGINT NOT NULL REFERENCES finanzas.rubro(id_rubro) ON DELETE RESTRICT,
    valor_aprobado NUMERIC(15,2) NOT NULL CHECK (valor_aprobado >= 0),
    id_acta BIGINT NOT NULL REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    UNIQUE (id_estamento, anio, id_rubro)
);

CREATE TABLE IF NOT EXISTS finanzas.ingreso (
    id_ingreso BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    id_cuenta BIGINT NOT NULL REFERENCES finanzas.cuenta_bancaria(id_cuenta) ON DELETE RESTRICT,
    fecha DATE NOT NULL DEFAULT CURRENT_DATE,
    valor NUMERIC(15,2) NOT NULL CHECK (valor > 0),
    concepto VARCHAR(250) NOT NULL,
    origen VARCHAR(150),
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE finanzas.ingreso IS 'Ingresos distintos a los aportes de nómina: donaciones, rendimientos, cuotas extraordinarias, etc.';

CREATE TABLE IF NOT EXISTS finanzas.egreso (
    id_egreso BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    id_cuenta BIGINT NOT NULL REFERENCES finanzas.cuenta_bancaria(id_cuenta) ON DELETE RESTRICT,
    id_rubro BIGINT NOT NULL REFERENCES finanzas.rubro(id_rubro) ON DELETE RESTRICT,
    fecha DATE NOT NULL DEFAULT CURRENT_DATE,
    valor NUMERIC(15,2) NOT NULL CHECK (valor > 0),
    concepto VARCHAR(250) NOT NULL,
    beneficiario_nombre VARCHAR(150) NOT NULL,
    beneficiario_documento VARCHAR(30),
    nombre_archivo_soporte VARCHAR(200),
    hash_soporte VARCHAR(64),
    id_acta_autorizacion BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    estado VARCHAR(12) NOT NULL DEFAULT 'REGISTRADO' CHECK (estado IN ('REGISTRADO', 'APROBADO', 'ANULADO')),
    fecha_aprobacion TIMESTAMP WITH TIME ZONE,
    motivo_anulacion TEXT,
    fecha_anulacion TIMESTAMP WITH TIME ZONE,
    usuario_anulacion VARCHAR(50),
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS finanzas.egreso_aprobacion (
    id_egreso BIGINT NOT NULL REFERENCES finanzas.egreso(id_egreso) ON DELETE CASCADE,
    rol VARCHAR(12) NOT NULL CHECK (rol IN ('TESORERIA', 'PRESIDENCIA')),
    id_usuario BIGINT NOT NULL REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    cargo VARCHAR(80) NOT NULL,
    fecha TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_egreso, rol)
);

CREATE TABLE IF NOT EXISTS finanzas.transferencia (
    id_transferencia BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_cuenta_origen BIGINT NOT NULL REFERENCES finanzas.cuenta_bancaria(id_cuenta) ON DELETE RESTRICT,
    id_cuenta_destino BIGINT NOT NULL REFERENCES finanzas.cuenta_bancaria(id_cuenta) ON DELETE RESTRICT,
    fecha DATE NOT NULL DEFAULT CURRENT_DATE,
    valor NUMERIC(15,2) NOT NULL CHECK (valor > 0),
    concepto VARCHAR(250) NOT NULL DEFAULT 'Distribución de aportes',
    referencia_bancaria VARCHAR(60),
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    CHECK (id_cuenta_origen <> id_cuenta_destino)
);

CREATE TABLE IF NOT EXISTS finanzas.cierre_mes (
    id_cierre BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    anio INT NOT NULL,
    mes INT NOT NULL CHECK (mes BETWEEN 1 AND 12),
    saldo_fondo NUMERIC(15,2) NOT NULL,
    fecha_cierre TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_cierre VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    reabierto BOOLEAN NOT NULL DEFAULT FALSE,
    motivo_reapertura TEXT,
    fecha_reapertura TIMESTAMP WITH TIME ZONE,
    usuario_reapertura VARCHAR(50),
    version INT NOT NULL DEFAULT 1
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_cierre_vigente ON finanzas.cierre_mes (id_estamento, anio, mes) WHERE NOT reabierto;

CREATE TABLE IF NOT EXISTS finanzas.conciliacion_bancaria (
    id_conciliacion BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_cuenta BIGINT NOT NULL REFERENCES finanzas.cuenta_bancaria(id_cuenta) ON DELETE RESTRICT,
    anio INT NOT NULL,
    mes INT NOT NULL CHECK (mes BETWEEN 1 AND 12),
    saldo_extracto NUMERIC(15,2) NOT NULL,
    observaciones TEXT,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    UNIQUE (id_cuenta, anio, mes)
);

CREATE INDEX IF NOT EXISTS ix_presupuesto_rubro ON finanzas.presupuesto (id_rubro);
CREATE INDEX IF NOT EXISTS ix_presupuesto_acta ON finanzas.presupuesto (id_acta);
CREATE INDEX IF NOT EXISTS ix_ingreso_estamento_fecha ON finanzas.ingreso (id_estamento, fecha);
CREATE INDEX IF NOT EXISTS ix_ingreso_cuenta ON finanzas.ingreso (id_cuenta);
CREATE INDEX IF NOT EXISTS ix_egreso_estamento_fecha ON finanzas.egreso (id_estamento, fecha);
CREATE INDEX IF NOT EXISTS ix_egreso_cuenta ON finanzas.egreso (id_cuenta);
CREATE INDEX IF NOT EXISTS ix_egreso_rubro ON finanzas.egreso (id_rubro);
CREATE INDEX IF NOT EXISTS ix_egreso_acta ON finanzas.egreso (id_acta_autorizacion);
CREATE INDEX IF NOT EXISTS ix_egreso_pendientes ON finanzas.egreso (fecha) WHERE estado = 'REGISTRADO';
CREATE INDEX IF NOT EXISTS ix_egreso_aprobacion_usuario ON finanzas.egreso_aprobacion (id_usuario);
CREATE INDEX IF NOT EXISTS ix_egreso_aprobacion_persona ON finanzas.egreso_aprobacion (id_persona);
CREATE INDEX IF NOT EXISTS ix_transferencia_origen ON finanzas.transferencia (id_cuenta_origen, fecha);
CREATE INDEX IF NOT EXISTS ix_transferencia_destino ON finanzas.transferencia (id_cuenta_destino, fecha);
CREATE INDEX IF NOT EXISTS ix_consignacion_fecha ON finanzas.consignacion_empresa (fecha_consignacion);

-- Una empresa puede pagar un mismo mes en la cuenta nacional y/o en una subcuenta: una consignación por cuenta y mes
ALTER TABLE finanzas.consignacion_empresa DROP CONSTRAINT IF EXISTS uk_empresa_periodo;
CREATE UNIQUE INDEX IF NOT EXISTS ux_consignacion_empresa_periodo_cuenta
    ON finanzas.consignacion_empresa (id_empresa, periodo_anio, periodo_mes, id_cuenta_destino);
CREATE INDEX IF NOT EXISTS ix_consignacion_empresa_periodo ON finanzas.consignacion_empresa (id_empresa, periodo_anio, periodo_mes);
-- Un afiliado tiene un solo aporte por mes, aunque la empresa haya repartido el pago entre varias cuentas
CREATE UNIQUE INDEX IF NOT EXISTS ux_aporte_persona_periodo ON finanzas.aporte_afiliado (id_persona, periodo_anio, periodo_mes);

-- Auditoría y concurrencia optimista en las tablas nuevas
DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['finanzas.parametro', 'finanzas.rubro', 'finanzas.presupuesto', 'finanzas.ingreso', 'finanzas.egreso',
                             'finanzas.transferencia', 'finanzas.cierre_mes', 'finanzas.conciliacion_bancaria'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_control_version ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_control_version BEFORE UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_auditoria ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria()', t);
    END LOOP;
    FOREACH t IN ARRAY ARRAY['finanzas.egreso_aprobacion', 'gobernanza.salario_historico'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_auditoria ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria()', t);
    END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- 4. CIERRE MENSUAL: lo cerrado no se modifica
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION finanzas.fn_mes_cerrado(p_id_estamento BIGINT, p_fecha DATE)
RETURNS BOOLEAN AS $$
    SELECT p_id_estamento IS NOT NULL AND p_fecha IS NOT NULL AND EXISTS (
        SELECT 1 FROM finanzas.cierre_mes
         WHERE id_estamento = p_id_estamento AND NOT reabierto
           AND anio = EXTRACT(YEAR FROM p_fecha)::INT AND mes = EXTRACT(MONTH FROM p_fecha)::INT);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION finanzas.fn_verificar_mes_abierto()
RETURNS TRIGGER AS $$
DECLARE
    r RECORD;
    v_pares JSONB := '[]'::JSONB;
    v_fila RECORD;
BEGIN
    FOR v_fila IN SELECT * FROM (VALUES (1), (2)) x(n) LOOP
        IF v_fila.n = 1 AND TG_OP = 'INSERT' THEN CONTINUE; END IF;
        IF v_fila.n = 2 AND TG_OP = 'DELETE' THEN CONTINUE; END IF;
        r := CASE WHEN v_fila.n = 1 THEN OLD ELSE NEW END;
        IF TG_TABLE_NAME IN ('egreso', 'ingreso') THEN
            v_pares := v_pares || jsonb_build_array(jsonb_build_object('e', r.id_estamento, 'f', r.fecha));
        ELSIF TG_TABLE_NAME = 'transferencia' THEN
            v_pares := v_pares || COALESCE((SELECT jsonb_agg(jsonb_build_object('e', id_estamento, 'f', r.fecha))
                                     FROM finanzas.cuenta_bancaria WHERE id_cuenta IN (r.id_cuenta_origen, r.id_cuenta_destino)), '[]'::JSONB);
        ELSIF TG_TABLE_NAME = 'consignacion_empresa' THEN
            v_pares := v_pares || COALESCE((SELECT jsonb_agg(jsonb_build_object('e', id_estamento, 'f', r.fecha_consignacion))
                                     FROM finanzas.cuenta_bancaria WHERE id_cuenta = r.id_cuenta_destino), '[]'::JSONB);
        ELSIF TG_TABLE_NAME = 'aporte_afiliado' THEN
            v_pares := v_pares || COALESCE((SELECT jsonb_agg(jsonb_build_object('e', x.e, 'f', c.fecha_consignacion))
                                     FROM finanzas.consignacion_empresa c
                                     JOIN finanzas.cuenta_bancaria cb ON cb.id_cuenta = c.id_cuenta_destino
                                     CROSS JOIN LATERAL (VALUES (cb.id_estamento),
                                         ((SELECT id_estamento_pertenencia FROM gobernanza.afiliado WHERE id_persona = r.id_persona))) x(e)
                                    WHERE c.id_consignacion = r.id_consignacion), '[]'::JSONB);
        END IF;
    END LOOP;
    IF EXISTS (SELECT 1 FROM jsonb_array_elements(v_pares) p
                WHERE finanzas.fn_mes_cerrado((p->>'e')::BIGINT, (p->>'f')::DATE)) THEN
        RAISE EXCEPTION 'El mes contable de esta operación ya está cerrado. Solo el administrador puede reabrirlo (con motivo).';
    END IF;
    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['finanzas.egreso', 'finanzas.ingreso', 'finanzas.transferencia', 'finanzas.consignacion_empresa',
                             'finanzas.aporte_afiliado'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_mes_abierto ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_mes_abierto BEFORE INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION finanzas.fn_verificar_mes_abierto()', t);
    END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- 5. VALIDACIONES DE MOVIMIENTOS
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION finanzas.fn_validar_movimiento()
RETURNS TRIGGER AS $$
DECLARE v_acta RECORD; v_origen RECORD; v_destino RECORD;
BEGIN
    IF TG_TABLE_NAME = 'egreso' THEN
        IF NOT finanzas.fn_cuenta_valida(NEW.id_estamento, NEW.id_cuenta) THEN
            RAISE EXCEPTION 'La cuenta no corresponde a la junta: use su subcuenta, o la cuenta nacional si la junta no tiene subcuenta.';
        END IF;
    END IF;
    -- Un ingreso puede llegar a la subcuenta de la junta o a la cuenta nacional (padre)
    IF TG_TABLE_NAME = 'ingreso' THEN
        IF NOT (finanzas.fn_cuenta_valida(NEW.id_estamento, NEW.id_cuenta)
                OR EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria c WHERE c.id_cuenta = NEW.id_cuenta AND c.es_cuenta_nacional)) THEN
            RAISE EXCEPTION 'Un ingreso de la junta llega a su subcuenta o a la cuenta nacional, no a la subcuenta de otra junta.';
        END IF;
    END IF;
    -- Consignación de una empresa: a la cuenta nacional o a la subcuenta de una junta con afiliados en esa empresa
    IF TG_TABLE_NAME = 'consignacion_empresa' THEN
        SELECT * INTO v_destino FROM finanzas.cuenta_bancaria WHERE id_cuenta = NEW.id_cuenta_destino;
        IF NOT v_destino.es_cuenta_nacional AND NOT EXISTS (
               SELECT 1 FROM gobernanza.afiliado_empresa ae JOIN gobernanza.afiliado a ON a.id_persona = ae.id_persona
                WHERE ae.id_empresa = NEW.id_empresa AND a.id_estamento_pertenencia = v_destino.id_estamento) THEN
            RAISE EXCEPTION 'La empresa no tiene afiliados de la junta dueña de esa subcuenta: la consignación debe ir a la cuenta nacional o a la subcuenta de una junta con afiliados en la empresa.';
        END IF;
    END IF;

    IF TG_TABLE_NAME = 'egreso' THEN
        IF TG_OP = 'INSERT' THEN
            NEW.estado := 'REGISTRADO'; NEW.fecha_aprobacion := NULL;
            NEW.motivo_anulacion := NULL; NEW.fecha_anulacion := NULL; NEW.usuario_anulacion := NULL;
        ELSE
            IF OLD.estado <> 'REGISTRADO' AND current_setting('finanzas.operacion', true) IS DISTINCT FROM 'anular' THEN
                RAISE EXCEPTION 'Un egreso % no se modifica. Si hay un error, anúlelo con su motivo y registre uno nuevo.', lower(OLD.estado);
            END IF;
            IF NEW.estado IS DISTINCT FROM OLD.estado AND NULLIF(current_setting('finanzas.operacion', true), '') IS NULL THEN
                RAISE EXCEPTION 'El estado del egreso solo cambia al aprobarlo o anularlo.';
            END IF;
            IF NEW.hash_soporte IS DISTINCT FROM OLD.hash_soporte AND OLD.hash_soporte IS NOT NULL THEN
                RAISE EXCEPTION 'El egreso ya tiene un soporte con huella SHA-256 registrada; no puede reemplazarse.';
            END IF;
        END IF;
        IF NULLIF(current_setting('finanzas.operacion', true), '') IS NULL
           AND NOT EXISTS (SELECT 1 FROM finanzas.rubro WHERE id_rubro = NEW.id_rubro AND activo) THEN
            RAISE EXCEPTION 'El rubro está inactivo.';
        END IF;
        IF NEW.id_acta_autorizacion IS NOT NULL THEN
            SELECT d.id_estamento, t.sigla_tipo INTO v_acta FROM gestion_documental.documento d
              JOIN gestion_documental.tipo_documento t ON t.id_tipo_documento = d.id_tipo_documento
             WHERE d.id_documento = NEW.id_acta_autorizacion;
            IF v_acta.sigla_tipo <> 'ACT' OR v_acta.id_estamento <> NEW.id_estamento THEN
                RAISE EXCEPTION 'El acta de autorización debe ser un acta (ACT) de la misma junta.';
            END IF;
        END IF;
    END IF;

    IF TG_TABLE_NAME = 'presupuesto' THEN
        SELECT d.id_estamento, t.sigla_tipo INTO v_acta FROM gestion_documental.documento d
          JOIN gestion_documental.tipo_documento t ON t.id_tipo_documento = d.id_tipo_documento
         WHERE d.id_documento = NEW.id_acta;
        IF v_acta.sigla_tipo IS DISTINCT FROM 'ACT' OR v_acta.id_estamento IS DISTINCT FROM NEW.id_estamento THEN
            RAISE EXCEPTION 'El presupuesto se aprueba con un acta de reunión (ACT) de la misma junta.';
        END IF;
    END IF;

    IF TG_TABLE_NAME = 'transferencia' THEN
        SELECT * INTO v_origen FROM finanzas.cuenta_bancaria WHERE id_cuenta = NEW.id_cuenta_origen;
        SELECT * INTO v_destino FROM finanzas.cuenta_bancaria WHERE id_cuenta = NEW.id_cuenta_destino;
        IF NOT ((v_origen.es_cuenta_nacional AND v_destino.id_cuenta_padre = v_origen.id_cuenta)
             OR (v_destino.es_cuenta_nacional AND v_origen.id_cuenta_padre = v_destino.id_cuenta)) THEN
            RAISE EXCEPTION 'Las transferencias son entre la cuenta nacional y una de sus subcuentas hijas.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['finanzas.ingreso', 'finanzas.egreso', 'finanzas.presupuesto', 'finanzas.transferencia',
                             'finanzas.consignacion_empresa'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_validar_movimiento ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_validar_movimiento BEFORE INSERT OR UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION finanzas.fn_validar_movimiento()', t);
    END LOOP;
END $$;

CREATE OR REPLACE FUNCTION finanzas.fn_proteger_borrado_egreso()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.estado <> 'REGISTRADO' THEN
        RAISE EXCEPTION 'Un egreso % no se elimina; queda en el historial.', lower(OLD.estado);
    END IF;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_proteger_borrado_egreso ON finanzas.egreso;
CREATE TRIGGER trg_proteger_borrado_egreso BEFORE DELETE ON finanzas.egreso
    FOR EACH ROW EXECUTE FUNCTION finanzas.fn_proteger_borrado_egreso();

-- ----------------------------------------------------------------------------
-- 6. LIBROS BASE (sin filtro; solo los usan las vistas filtradas y las funciones)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW finanzas_interno.distribucion AS
WITH jdn AS (SELECT id_estamento FROM gobernanza.estamento WHERE tipo_estamento = 'JUNTA DIRECTIVA NACIONAL' LIMIT 1),
pct AS (SELECT finanzas.fn_parametro('PORCENTAJE_NACIONAL') AS v),
ap AS (
    SELECT a.id_aporte, a.id_consignacion, c.fecha_consignacion AS fecha, a.id_persona, a.monto_descuento_ley AS monto,
           af.id_estamento_pertenencia AS est_local, ROUND(a.monto_descuento_ley * (SELECT v FROM pct) / 100, 2) AS parte_nacional
      FROM finanzas.aporte_afiliado a
      JOIN finanzas.consignacion_empresa c ON c.id_consignacion = a.id_consignacion
      LEFT JOIN gobernanza.afiliado af ON af.id_persona = a.id_persona
)
SELECT (SELECT id_estamento FROM jdn) AS id_estamento, fecha, id_consignacion, id_aporte, 'APORTE_NACIONAL' AS concepto, parte_nacional AS valor FROM ap
UNION ALL
SELECT est_local, fecha, id_consignacion, id_aporte, CASE WHEN est_local IS NULL THEN 'APORTE_SIN_PERTENENCIA' ELSE 'APORTE_LOCAL' END,
       monto - parte_nacional FROM ap
UNION ALL
SELECT NULL, c.fecha_consignacion, c.id_consignacion, NULL, 'CONSIGNACION_SIN_DISCRIMINAR',
       c.monto_total_consignado - COALESCE((SELECT SUM(monto_descuento_ley) FROM finanzas.aporte_afiliado a WHERE a.id_consignacion = c.id_consignacion), 0)
  FROM finanzas.consignacion_empresa c
 WHERE c.monto_total_consignado - COALESCE((SELECT SUM(monto_descuento_ley) FROM finanzas.aporte_afiliado a WHERE a.id_consignacion = c.id_consignacion), 0) <> 0;

CREATE OR REPLACE VIEW finanzas_interno.mov_fondo AS
SELECT id_estamento, fecha, concepto AS tipo, 'Aporte ' || COALESCE(id_aporte::TEXT, 'sin discriminar') || ' (consignación ' || id_consignacion || ')' AS detalle, valor
  FROM finanzas_interno.distribucion
UNION ALL
SELECT id_estamento, fecha, 'OTRO_INGRESO', concepto, valor FROM finanzas.ingreso
UNION ALL
SELECT id_estamento, fecha, 'EGRESO', concepto || ' — ' || beneficiario_nombre, -valor FROM finanzas.egreso WHERE estado = 'APROBADO';

CREATE OR REPLACE VIEW finanzas_interno.mov_cuenta AS
SELECT id_cuenta_destino AS id_cuenta, fecha_consignacion AS fecha, 'CONSIGNACION' AS tipo,
       'Consignación empresa ' || id_empresa || ' periodo ' || periodo_mes || '/' || periodo_anio AS detalle, monto_total_consignado AS valor
  FROM finanzas.consignacion_empresa
UNION ALL SELECT id_cuenta, fecha, 'OTRO_INGRESO', concepto, valor FROM finanzas.ingreso
UNION ALL SELECT id_cuenta_destino, fecha, 'TRANSFERENCIA_RECIBIDA', concepto, valor FROM finanzas.transferencia
UNION ALL SELECT id_cuenta_origen, fecha, 'TRANSFERENCIA_ENVIADA', concepto, -valor FROM finanzas.transferencia
UNION ALL SELECT id_cuenta, fecha, 'EGRESO', concepto || ' — ' || beneficiario_nombre, -valor FROM finanzas.egreso WHERE estado = 'APROBADO';

CREATE OR REPLACE FUNCTION finanzas.fn_saldo_fondo(p_id_estamento BIGINT, p_hasta DATE DEFAULT NULL)
RETURNS NUMERIC AS $$
    SELECT COALESCE(SUM(valor), 0) FROM finanzas_interno.mov_fondo
     WHERE id_estamento IS NOT DISTINCT FROM p_id_estamento AND (p_hasta IS NULL OR fecha <= p_hasta);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION finanzas.fn_saldo_cuenta(p_id_cuenta BIGINT, p_hasta DATE DEFAULT NULL)
RETURNS NUMERIC AS $$
    SELECT COALESCE(SUM(valor), 0) FROM finanzas_interno.mov_cuenta
     WHERE id_cuenta = p_id_cuenta AND (p_hasta IS NULL OR fecha <= p_hasta);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 7. OPERACIONES CONTROLADAS: aprobar y anular egresos, cerrar y reabrir meses
-- ----------------------------------------------------------------------------
-- Rol financiero de quien opera, según su cargo vigente en la junta
CREATE OR REPLACE FUNCTION finanzas.fn_rol_financiero(p_id_persona BIGINT, p_id_estamento BIGINT, OUT rol TEXT, OUT cargo TEXT)
AS $$
    SELECT CASE WHEN c.codigo LIKE 'TES\_%' OR c.codigo = 'SGEN_COM' THEN 'TESORERIA'
                WHEN c.codigo LIKE 'PRES\_%' THEN 'PRESIDENCIA' END, c.nombre
      FROM gobernanza.directivo_estamento d JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
     WHERE d.id_persona = p_id_persona AND d.id_estamento = p_id_estamento AND d.fecha_retiro IS NULL
       AND d.fecha_posesion_individual <= CURRENT_DATE
       AND (c.codigo LIKE 'TES\_%' OR c.codigo LIKE 'PRES\_%' OR c.codigo = 'SGEN_COM')
     LIMIT 1;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION finanzas.fn_aprobar_egreso(p_id_egreso BIGINT)
RETURNS TEXT AS $$
DECLARE
    v_e finanzas.egreso%ROWTYPE;
    v_u seguridad.usuario%ROWTYPE;
    v_rol RECORD;
    v_presupuesto NUMERIC;
    v_ejecutado NUMERIC;
    v_fondo NUMERIC;
    v_cuenta NUMERIC;
BEGIN
    SELECT * INTO v_u FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo;
    IF v_u.id_usuario IS NULL THEN RAISE EXCEPTION 'Usuario no identificado.'; END IF;
    SELECT * INTO v_e FROM finanzas.egreso WHERE id_egreso = p_id_egreso FOR UPDATE;
    IF v_e.id_egreso IS NULL THEN RAISE EXCEPTION 'El egreso no existe.'; END IF;
    IF v_e.estado <> 'REGISTRADO' THEN RAISE EXCEPTION 'El egreso ya está %.', lower(v_e.estado); END IF;
    IF finanzas.fn_mes_cerrado(v_e.id_estamento, v_e.fecha) THEN RAISE EXCEPTION 'El mes contable del egreso está cerrado.'; END IF;
    IF v_e.hash_soporte IS NULL THEN
        RAISE EXCEPTION 'Adjunte el soporte (factura o cuenta de cobro en PDF) antes de aprobar el egreso.';
    END IF;

    SELECT * INTO v_rol FROM finanzas.fn_rol_financiero(v_u.id_persona, v_e.id_estamento);
    IF v_rol.rol IS NULL THEN
        RAISE EXCEPTION 'Solo aprueban egresos el Tesorero y el Presidente de la junta (en comités, el Secretario General y el Presidente). El Fiscal revisa pero no aprueba.';
    END IF;
    IF EXISTS (SELECT 1 FROM finanzas.egreso_aprobacion WHERE id_egreso = p_id_egreso AND rol = v_rol.rol) THEN
        RAISE EXCEPTION 'La aprobación de % ya está registrada; falta la otra firma.', lower(v_rol.rol);
    END IF;
    INSERT INTO finanzas.egreso_aprobacion (id_egreso, rol, id_usuario, id_persona, cargo)
    VALUES (p_id_egreso, v_rol.rol, v_u.id_usuario, v_u.id_persona, v_rol.cargo);

    IF (SELECT count(*) FROM finanzas.egreso_aprobacion WHERE id_egreso = p_id_egreso) < 2 THEN
        RETURN 'PENDIENTE: registrada la firma de ' || lower(v_rol.rol) || '; falta la otra firma.';
    END IF;

    -- Segunda firma: controles de presupuesto y de fondos (serializados por junta y por cuenta)
    PERFORM pg_advisory_xact_lock(hashtext('fondo_' || v_e.id_estamento));
    PERFORM pg_advisory_xact_lock(hashtext('cuenta_' || v_e.id_cuenta));
    IF finanzas.fn_parametro('EXIGIR_PRESUPUESTO') = 1 AND v_e.id_acta_autorizacion IS NULL THEN
        SELECT valor_aprobado INTO v_presupuesto FROM finanzas.presupuesto
         WHERE id_estamento = v_e.id_estamento AND id_rubro = v_e.id_rubro AND anio = EXTRACT(YEAR FROM v_e.fecha)::INT;
        IF v_presupuesto IS NULL THEN
            RAISE EXCEPTION 'No hay presupuesto aprobado para este rubro en %. Registre el presupuesto o un acta de autorización.',
                EXTRACT(YEAR FROM v_e.fecha)::INT;
        END IF;
        SELECT COALESCE(SUM(valor), 0) INTO v_ejecutado FROM finanzas.egreso
         WHERE id_estamento = v_e.id_estamento AND id_rubro = v_e.id_rubro AND estado = 'APROBADO'
           AND EXTRACT(YEAR FROM fecha) = EXTRACT(YEAR FROM v_e.fecha);
        IF v_ejecutado + v_e.valor > v_presupuesto THEN
            RAISE EXCEPTION 'El egreso supera el presupuesto del rubro (aprobado %, ejecutado %, este egreso %). Requiere un acta de autorización.',
                to_char(v_presupuesto, 'FM999G999G999D00'), to_char(v_ejecutado, 'FM999G999G999D00'), to_char(v_e.valor, 'FM999G999G999D00');
        END IF;
    END IF;
    v_fondo := finanzas.fn_saldo_fondo(v_e.id_estamento);
    v_cuenta := finanzas.fn_saldo_cuenta(v_e.id_cuenta);
    IF v_fondo < v_e.valor THEN
        RAISE EXCEPTION 'Fondos insuficientes: el saldo del fondo de la junta es % y el egreso es %.',
            to_char(v_fondo, 'FM999G999G999D00'), to_char(v_e.valor, 'FM999G999G999D00');
    END IF;
    IF v_cuenta < v_e.valor THEN
        RAISE EXCEPTION 'Saldo insuficiente en la cuenta: % disponible para un egreso de %.',
            to_char(v_cuenta, 'FM999G999G999D00'), to_char(v_e.valor, 'FM999G999G999D00');
    END IF;
    PERFORM set_config('finanzas.operacion', 'aprobar', true);
    UPDATE finanzas.egreso SET estado = 'APROBADO', fecha_aprobacion = now() WHERE id_egreso = p_id_egreso;
    PERFORM set_config('finanzas.operacion', '', true);
    RETURN 'APROBADO';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION finanzas.fn_anular_egreso(p_id_egreso BIGINT, p_motivo TEXT)
RETURNS TEXT AS $$
DECLARE v_e finanzas.egreso%ROWTYPE; v_u seguridad.usuario%ROWTYPE; v_rol RECORD;
BEGIN
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo de la anulación (mínimo 10 caracteres).'; END IF;
    SELECT * INTO v_u FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo;
    SELECT * INTO v_e FROM finanzas.egreso WHERE id_egreso = p_id_egreso FOR UPDATE;
    IF v_e.id_egreso IS NULL THEN RAISE EXCEPTION 'El egreso no existe.'; END IF;
    IF v_e.estado = 'ANULADO' THEN RAISE EXCEPTION 'El egreso ya está anulado.'; END IF;
    SELECT * INTO v_rol FROM finanzas.fn_rol_financiero(v_u.id_persona, v_e.id_estamento);
    IF v_rol.rol IS NULL THEN RAISE EXCEPTION 'Solo el Tesorero o el Presidente de la junta pueden anular egresos.'; END IF;
    PERFORM set_config('finanzas.operacion', 'anular', true);
    UPDATE finanzas.egreso SET estado = 'ANULADO', motivo_anulacion = trim(p_motivo), fecha_anulacion = now(),
                               usuario_anulacion = v_u.nombre_usuario
     WHERE id_egreso = p_id_egreso;
    PERFORM set_config('finanzas.operacion', '', true);
    RETURN 'ANULADO';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION finanzas.fn_cerrar_mes(p_id_estamento BIGINT, p_anio INT, p_mes INT)
RETURNS BIGINT AS $$
DECLARE v_u seguridad.usuario%ROWTYPE; v_rol RECORD; v_fin DATE; v_id BIGINT;
BEGIN
    SELECT * INTO v_u FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo;
    IF v_u.id_usuario IS NULL THEN RAISE EXCEPTION 'Usuario no identificado.'; END IF;
    SELECT * INTO v_rol FROM finanzas.fn_rol_financiero(v_u.id_persona, p_id_estamento);
    IF v_u.codigo_rol <> 'ADMIN' AND v_rol.rol IS DISTINCT FROM 'TESORERIA' THEN
        RAISE EXCEPTION 'El cierre mensual lo hace el Tesorero de la junta (en comités, el Secretario General) o el administrador.';
    END IF;
    v_fin := (make_date(p_anio, p_mes, 1) + INTERVAL '1 month' - INTERVAL '1 day')::DATE;
    IF v_fin >= CURRENT_DATE THEN RAISE EXCEPTION 'Solo se pueden cerrar meses terminados.'; END IF;
    PERFORM pg_advisory_xact_lock(hashtext('fondo_' || p_id_estamento));
    INSERT INTO finanzas.cierre_mes (id_estamento, anio, mes, saldo_fondo)
    VALUES (p_id_estamento, p_anio, p_mes, finanzas.fn_saldo_fondo(p_id_estamento, v_fin))
    RETURNING id_cierre INTO v_id;
    RETURN v_id;
EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION 'Ese mes ya está cerrado para esta junta.';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION finanzas.fn_reabrir_mes(p_id_cierre BIGINT, p_motivo TEXT)
RETURNS VOID AS $$
DECLARE v_u seguridad.usuario%ROWTYPE;
BEGIN
    SELECT * INTO v_u FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo;
    IF v_u.codigo_rol IS DISTINCT FROM 'ADMIN' THEN RAISE EXCEPTION 'Solo el administrador puede reabrir un mes cerrado.'; END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo de la reapertura (mínimo 10 caracteres).'; END IF;
    UPDATE finanzas.cierre_mes SET reabierto = TRUE, motivo_reapertura = trim(p_motivo), fecha_reapertura = now(),
                                   usuario_reapertura = v_u.nombre_usuario
     WHERE id_cierre = p_id_cierre AND NOT reabierto;
    IF NOT FOUND THEN RAISE EXCEPTION 'El cierre no existe o ya fue reabierto.'; END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 8. VISTAS FINANCIERAS (prefijo vf_: calculadas sobre todo el país y filtradas por ámbito)
-- ----------------------------------------------------------------------------
DROP VIEW IF EXISTS finanzas.vf_saldo_fondos, finanzas.vf_saldo_cuentas, finanzas.vf_transferencias_pendientes,
    finanzas.vf_movimientos_fondo, finanzas.vf_mora_empresas, finanzas.vf_ejecucion_presupuestal,
    finanzas.vf_estado_ingresos_egresos, finanzas.vf_alertas_financieras, finanzas.vf_conciliacion_bancaria CASCADE;

CREATE VIEW finanzas.vf_movimientos_fondo AS
SELECT m.fecha, COALESCE(e.nombre_estamento, 'PENDIENTE DE DISTRIBUIR') AS fondo, m.tipo, m.detalle, m.valor, m.id_estamento
  FROM finanzas_interno.mov_fondo m LEFT JOIN gobernanza.estamento e ON e.id_estamento = m.id_estamento
 WHERE seguridad.fn_ve_estamento(m.id_estamento);

CREATE VIEW finanzas.vf_saldo_fondos AS
WITH f AS (
    SELECT id_estamento,
           SUM(valor) FILTER (WHERE tipo LIKE 'APORTE%' OR tipo = 'CONSIGNACION_SIN_DISCRIMINAR') AS aportes,
           SUM(valor) FILTER (WHERE tipo = 'OTRO_INGRESO') AS otros_ingresos,
           -SUM(valor) FILTER (WHERE tipo = 'EGRESO') AS egresos,
           SUM(valor) AS saldo
      FROM finanzas_interno.mov_fondo GROUP BY id_estamento
)
SELECT COALESCE(e.nombre_estamento, 'PENDIENTE DE DISTRIBUIR') AS fondo, e.tipo_estamento,
       (SELECT c.banco || ' ' || c.numero_cuenta FROM finanzas.cuenta_bancaria c
         WHERE c.id_estamento = COALESCE(e.id_estamento, -1) AND NOT c.es_cuenta_nacional LIMIT 1) AS subcuenta,
       COALESCE(f.aportes, 0) AS aportes, COALESCE(f.otros_ingresos, 0) AS otros_ingresos,
       COALESCE(f.egresos, 0) AS egresos, COALESCE(f.saldo, 0) AS saldo,
       CASE WHEN e.id_estamento IS NULL AND COALESCE(f.saldo, 0) > 0
                THEN 'ALERTA ALTA: APORTES SIN DISTRIBUIR (AFILIADOS SIN PERTENENCIA O CONSIGNACIÓN SIN DISCRIMINAR)'
            WHEN e.id_estamento IS NULL AND COALESCE(f.saldo, 0) < 0
                THEN 'ALERTA ALTA: LOS APORTES DISCRIMINADOS SUPERAN LO CONSIGNADO POR LA EMPRESA'
            WHEN COALESCE(f.saldo, 0) < 0 THEN 'ALERTA CRÍTICA: FONDO EN NEGATIVO'
            ELSE 'NORMAL' END AS diagnostico,
       e.id_estamento
  FROM f FULL JOIN gobernanza.estamento e ON e.id_estamento = f.id_estamento
 WHERE (e.id_estamento IS NULL OR e.tipo_estamento IN ('JUNTA DIRECTIVA NACIONAL', 'SUBDIRECTIVA', 'COMITÉ SECCIONAL'))
   AND seguridad.fn_ve_estamento(COALESCE(e.id_estamento, f.id_estamento));

CREATE VIEW finanzas.vf_saldo_cuentas AS
SELECT c.banco, c.numero_cuenta, c.tipo_cuenta, CASE WHEN c.es_cuenta_nacional THEN 'NACIONAL' ELSE 'SUBCUENTA' END AS clase,
       e.nombre_estamento AS titular, finanzas.fn_saldo_cuenta(c.id_cuenta) AS saldo, c.id_cuenta, c.id_estamento
  FROM finanzas.cuenta_bancaria c LEFT JOIN gobernanza.estamento e ON e.id_estamento = c.id_estamento
 WHERE seguridad.fn_ve_estamento(c.id_estamento);

CREATE VIEW finanzas.vf_transferencias_pendientes AS
WITH s AS (
    SELECT e.id_estamento, e.nombre_estamento, c.id_cuenta, c.banco || ' ' || c.numero_cuenta AS subcuenta,
           p.banco || ' ' || p.numero_cuenta AS cuenta_nacional,
           finanzas.fn_saldo_fondo(e.id_estamento) AS saldo_fondo, finanzas.fn_saldo_cuenta(c.id_cuenta) AS saldo_subcuenta
      FROM gobernanza.estamento e
      JOIN finanzas.cuenta_bancaria c ON c.id_estamento = e.id_estamento AND NOT c.es_cuenta_nacional
      JOIN finanzas.cuenta_bancaria p ON p.id_cuenta = c.id_cuenta_padre
)
SELECT nombre_estamento AS junta, subcuenta, cuenta_nacional, saldo_fondo, saldo_subcuenta,
       saldo_fondo - saldo_subcuenta AS diferencia,
       CASE WHEN abs(saldo_fondo - saldo_subcuenta) <= finanzas.fn_parametro('TOLERANCIA_PESOS') THEN 'Sin transferencias pendientes'
            WHEN saldo_fondo > saldo_subcuenta THEN 'La cuenta nacional debe transferir a la subcuenta'
            ELSE 'La subcuenta debe transferir a la cuenta nacional' END AS accion,
       CASE WHEN abs(saldo_fondo - saldo_subcuenta) <= finanzas.fn_parametro('TOLERANCIA_PESOS') THEN 'AL DÍA'
            ELSE 'ALERTA ALTA: TRANSFERENCIA PENDIENTE' END AS diagnostico,
       id_estamento
  FROM s WHERE seguridad.fn_ve_estamento(id_estamento);

CREATE VIEW finanzas.vf_mora_empresas AS
WITH meses AS (
    SELECT g::DATE AS mes FROM generate_series(date_trunc('month', CURRENT_DATE) - INTERVAL '12 months',
                                               date_trunc('month', CURRENT_DATE) - INTERVAL '1 month', INTERVAL '1 month') g
     WHERE g + INTERVAL '1 month' + (finanzas.fn_parametro('DIA_LIMITE_CONSIGNACION')::INT - 1) * INTERVAL '1 day' < CURRENT_DATE
), esperado AS (
    SELECT ae.id_empresa, m.mes, COUNT(*) AS afiliados,
           ROUND(SUM(gobernanza.fn_salario_vigente(ae.id_persona, ae.id_empresa, (m.mes + INTERVAL '1 month' - INTERVAL '1 day')::DATE))
                 * finanzas.fn_parametro('PORCENTAJE_APORTE') / 100, 2) AS valor
      FROM gobernanza.afiliado_empresa ae JOIN meses m ON ae.fecha_ingreso_empresa <= (m.mes + INTERVAL '1 month' - INTERVAL '1 day')::DATE
     GROUP BY ae.id_empresa, m.mes
)
SELECT emp.nombre_empresa AS empresa, emp.nit, to_char(es.mes, 'YYYY-MM') AS periodo, es.afiliados,
       es.valor AS esperado, COALESCE(c.monto_total_consignado, 0) AS consignado,
       COALESCE(c.monto_total_consignado, 0) - es.valor AS diferencia, c.fecha_consignacion, c.cuentas AS consignado_en,
       CASE WHEN c.id_consignacion IS NULL THEN 'ALERTA CRÍTICA: NO CONSIGNÓ LOS APORTES DEL MES'
            WHEN c.monto_total_consignado < es.valor - finanzas.fn_parametro('TOLERANCIA_PESOS') THEN 'ALERTA ALTA: CONSIGNÓ MENOS DE LO ESPERADO'
            ELSE 'AL DÍA' END AS diagnostico,
       emp.id_empresa
  FROM esperado es
  JOIN gobernanza.empresa emp ON emp.id_empresa = es.id_empresa
  LEFT JOIN (SELECT ce.id_empresa, ce.periodo_anio, ce.periodo_mes, SUM(ce.monto_total_consignado) AS monto_total_consignado,
                    MAX(ce.fecha_consignacion) AS fecha_consignacion, MIN(ce.id_consignacion) AS id_consignacion,
                    string_agg(CASE WHEN cb.es_cuenta_nacional THEN 'Cuenta nacional' ELSE 'Subcuenta ' || e2.nombre_estamento END
                               || ' (' || ce.monto_total_consignado || ')', '; ' ORDER BY cb.es_cuenta_nacional DESC, e2.nombre_estamento) AS cuentas
               FROM finanzas.consignacion_empresa ce
               JOIN finanzas.cuenta_bancaria cb ON cb.id_cuenta = ce.id_cuenta_destino
               LEFT JOIN gobernanza.estamento e2 ON e2.id_estamento = cb.id_estamento
              GROUP BY ce.id_empresa, ce.periodo_anio, ce.periodo_mes) c
         ON c.id_empresa = es.id_empresa
        AND c.periodo_anio = EXTRACT(YEAR FROM es.mes)::INT AND c.periodo_mes = EXTRACT(MONTH FROM es.mes)::INT
 WHERE (SELECT rolbypassrls OR rolsuper FROM pg_roles WHERE rolname = session_user)
    OR seguridad.fn_empresa_visible(emp.id_empresa, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos());

CREATE VIEW finanzas.vf_ejecucion_presupuestal AS
WITH ej AS (
    SELECT id_estamento, EXTRACT(YEAR FROM fecha)::INT AS anio, id_rubro, SUM(valor) AS ejecutado
      FROM finanzas.egreso WHERE estado = 'APROBADO' GROUP BY 1, 2, 3
), base AS (
    SELECT COALESCE(p.id_estamento, ej.id_estamento) AS id_estamento, COALESCE(p.anio, ej.anio) AS anio,
           COALESCE(p.id_rubro, ej.id_rubro) AS id_rubro, p.valor_aprobado, COALESCE(ej.ejecutado, 0) AS ejecutado
      FROM finanzas.presupuesto p FULL JOIN ej ON ej.id_estamento = p.id_estamento AND ej.anio = p.anio AND ej.id_rubro = p.id_rubro
)
SELECT e.nombre_estamento AS junta, b.anio, r.nombre AS rubro, b.valor_aprobado AS aprobado, b.ejecutado,
       b.valor_aprobado - b.ejecutado AS disponible,
       CASE WHEN b.valor_aprobado > 0 THEN ROUND(b.ejecutado * 100 / b.valor_aprobado, 1) END AS porcentaje_ejecucion,
       CASE WHEN b.valor_aprobado IS NULL THEN 'ALERTA CRÍTICA: GASTO SIN PRESUPUESTO (APROBADO CON ACTA)'
            WHEN b.ejecutado > b.valor_aprobado THEN 'ALERTA CRÍTICA: PRESUPUESTO SUPERADO (APROBADO CON ACTA)'
            WHEN b.ejecutado >= b.valor_aprobado * 0.8 THEN 'ALERTA ALTA: EJECUCIÓN DEL 80 % O MÁS'
            ELSE 'NORMAL' END AS diagnostico,
       b.id_estamento
  FROM base b JOIN gobernanza.estamento e ON e.id_estamento = b.id_estamento JOIN finanzas.rubro r ON r.id_rubro = b.id_rubro
 WHERE seguridad.fn_ve_estamento(b.id_estamento);

CREATE VIEW finanzas.vf_estado_ingresos_egresos AS
SELECT COALESCE(e.nombre_estamento, 'PENDIENTE DE DISTRIBUIR') AS junta, EXTRACT(YEAR FROM m.fecha)::INT AS anio,
       EXTRACT(MONTH FROM m.fecha)::INT AS mes,
       COALESCE(SUM(m.valor) FILTER (WHERE m.tipo LIKE 'APORTE%' OR m.tipo = 'CONSIGNACION_SIN_DISCRIMINAR'), 0) AS ingresos_aportes,
       COALESCE(SUM(m.valor) FILTER (WHERE m.tipo = 'OTRO_INGRESO'), 0) AS otros_ingresos,
       COALESCE(-SUM(m.valor) FILTER (WHERE m.tipo = 'EGRESO'), 0) AS egresos,
       SUM(m.valor) AS resultado_neto, m.id_estamento
  FROM finanzas_interno.mov_fondo m LEFT JOIN gobernanza.estamento e ON e.id_estamento = m.id_estamento
 WHERE seguridad.fn_ve_estamento(m.id_estamento)
 GROUP BY e.nombre_estamento, m.id_estamento, EXTRACT(YEAR FROM m.fecha), EXTRACT(MONTH FROM m.fecha);

CREATE VIEW finanzas.vf_conciliacion_bancaria AS
SELECT c.banco || ' ' || c.numero_cuenta AS cuenta, e.nombre_estamento AS titular, cb.anio, cb.mes, cb.saldo_extracto,
       finanzas.fn_saldo_cuenta(c.id_cuenta, (make_date(cb.anio, cb.mes, 1) + INTERVAL '1 month' - INTERVAL '1 day')::DATE) AS saldo_sistema,
       cb.saldo_extracto - finanzas.fn_saldo_cuenta(c.id_cuenta, (make_date(cb.anio, cb.mes, 1) + INTERVAL '1 month' - INTERVAL '1 day')::DATE) AS diferencia,
       CASE WHEN abs(cb.saldo_extracto - finanzas.fn_saldo_cuenta(c.id_cuenta, (make_date(cb.anio, cb.mes, 1) + INTERVAL '1 month' - INTERVAL '1 day')::DATE))
                 <= finanzas.fn_parametro('TOLERANCIA_PESOS') THEN 'CONCILIADA'
            ELSE 'ALERTA CRÍTICA: EL EXTRACTO NO COINCIDE CON EL SISTEMA' END AS diagnostico,
       cb.observaciones, c.id_estamento
  FROM finanzas.conciliacion_bancaria cb
  JOIN finanzas.cuenta_bancaria c ON c.id_cuenta = cb.id_cuenta
  LEFT JOIN gobernanza.estamento e ON e.id_estamento = c.id_estamento
 WHERE seguridad.fn_ve_estamento(c.id_estamento);

CREATE VIEW finanzas.vf_alertas_financieras AS
WITH a AS (
    SELECT e.id_estamento, 'EGRESO SIN APROBAR' AS tipo,
           e.concepto || ' — ' || e.beneficiario_nombre || ' (registrado el ' || to_char(e.fecha_creacion, 'YYYY-MM-DD') || ')' AS detalle,
           e.valor, 'ALERTA ALTA: EGRESO REGISTRADO HACE MÁS DE ' || finanzas.fn_parametro('DIAS_EGRESO_SIN_APROBAR')::INT || ' DÍAS SIN APROBAR' AS diagnostico
      FROM finanzas.egreso e
     WHERE e.estado = 'REGISTRADO' AND e.fecha_creacion < now() - finanzas.fn_parametro('DIAS_EGRESO_SIN_APROBAR')::INT * INTERVAL '1 day'
    UNION ALL
    SELECT e.id_estamento, 'EGRESO SIN SOPORTE', e.concepto || ' — ' || e.beneficiario_nombre, e.valor,
           'ALERTA MEDIA: EGRESO SIN FACTURA O CUENTA DE COBRO ADJUNTA'
      FROM finanzas.egreso e WHERE e.estado = 'REGISTRADO' AND e.hash_soporte IS NULL
    UNION ALL
    SELECT e.id_estamento, 'EGRESO CON ACTA DE AUTORIZACIÓN', e.concepto || ' — ' || e.beneficiario_nombre, e.valor,
           'ALERTA MEDIA: EGRESO APROBADO FUERA DE PRESUPUESTO CON ACTA'
      FROM finanzas.egreso e WHERE e.estado = 'APROBADO' AND e.id_acta_autorizacion IS NOT NULL
    UNION ALL
    SELECT e.id_estamento, 'EGRESO ANULADO', e.concepto || ' — motivo: ' || e.motivo_anulacion, e.valor,
           'ALERTA MEDIA: EGRESO ANULADO'
      FROM finanzas.egreso e WHERE e.estado = 'ANULADO' AND e.fecha_anulacion > now() - INTERVAL '90 days'
    UNION ALL
    SELECT t.id_estamento, 'TRANSFERENCIA PENDIENTE', t.accion || ': ' || t.subcuenta, abs(t.diferencia), t.diagnostico
      FROM finanzas.vf_transferencias_pendientes t WHERE t.diagnostico <> 'AL DÍA'
    UNION ALL
    SELECT f.id_estamento, 'FONDO', f.fondo, f.saldo, f.diagnostico FROM finanzas.vf_saldo_fondos f WHERE f.diagnostico <> 'NORMAL'
    UNION ALL
    SELECT c.id_estamento, 'CONCILIACIÓN BANCARIA', c.cuenta || ' ' || c.anio || '-' || lpad(c.mes::TEXT, 2, '0'), c.diferencia, c.diagnostico
      FROM finanzas.vf_conciliacion_bancaria c WHERE c.diagnostico <> 'CONCILIADA'
    UNION ALL
    SELECT j.id_estamento, 'MES SIN CIERRE', to_char(g, 'YYYY-MM'), NULL::NUMERIC, 'ALERTA MEDIA: MES SIN CIERRE CONTABLE'
      FROM (SELECT DISTINCT id_estamento, MIN(fecha) OVER (PARTITION BY id_estamento) AS desde FROM finanzas_interno.mov_fondo WHERE id_estamento IS NOT NULL) j
      CROSS JOIN LATERAL generate_series(date_trunc('month', j.desde), date_trunc('month', CURRENT_DATE) - INTERVAL '2 months', INTERVAL '1 month') g
     WHERE NOT EXISTS (SELECT 1 FROM finanzas.cierre_mes cm WHERE cm.id_estamento = j.id_estamento AND NOT cm.reabierto
                         AND cm.anio = EXTRACT(YEAR FROM g)::INT AND cm.mes = EXTRACT(MONTH FROM g)::INT)
)
SELECT COALESCE(es.nombre_estamento, 'TODO EL SINDICATO') AS junta, a.tipo, a.detalle, a.valor, a.diagnostico, a.id_estamento
  FROM a LEFT JOIN gobernanza.estamento es ON es.id_estamento = a.id_estamento
 WHERE seguridad.fn_ve_estamento(a.id_estamento);

-- ----------------------------------------------------------------------------
-- 9. SEGURIDAD POR FILAS DE LAS TABLAS NUEVAS
-- ----------------------------------------------------------------------------
SELECT seguridad.fn_aplicar_politicas('finanzas.parametro', 'true', ':N');
SELECT seguridad.fn_aplicar_politicas('finanzas.rubro', 'true', ':N');
SELECT seguridad.fn_aplicar_politicas('finanzas.presupuesto', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('finanzas.ingreso', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('finanzas.egreso', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('finanzas.cierre_mes', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('finanzas.egreso_aprobacion',
    'EXISTS (SELECT 1 FROM finanzas.egreso e WHERE e.id_egreso = egreso_aprobacion.id_egreso)', 'false');
SELECT seguridad.fn_aplicar_politicas('finanzas.transferencia',
    ':N OR EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria c WHERE c.id_cuenta IN (transferencia.id_cuenta_origen, transferencia.id_cuenta_destino) AND c.id_estamento = ANY(:E))',
    ':N OR EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria c WHERE c.id_cuenta IN (transferencia.id_cuenta_origen, transferencia.id_cuenta_destino) AND c.id_estamento = ANY(:E))');
SELECT seguridad.fn_aplicar_politicas('finanzas.conciliacion_bancaria',
    ':N OR EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria c WHERE c.id_cuenta = conciliacion_bancaria.id_cuenta AND c.id_estamento = ANY(:E))',
    ':N OR EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria c WHERE c.id_cuenta = conciliacion_bancaria.id_cuenta AND c.id_estamento = ANY(:E))');
SELECT seguridad.fn_aplicar_politicas('gobernanza.salario_historico',
    'EXISTS (SELECT 1 FROM gobernanza.afiliado a WHERE a.id_persona = salario_historico.id_persona)', 'false');
-- Una junta sin subcuenta ve la cuenta nacional para registrar sus movimientos (no su saldo total)
SELECT seguridad.fn_aplicar_politicas('finanzas.cuenta_bancaria',
    ':N OR id_estamento = ANY(:E) OR (es_cuenta_nacional AND seguridad.fn_usa_cuenta_nacional(:E))',
    ':N OR id_estamento = ANY(:E)');

GRANT EXECUTE ON FUNCTION seguridad.fn_ve_estamento(BIGINT), seguridad.fn_usa_cuenta_nacional(BIGINT[]) TO PUBLIC;

-- Consignaciones: en la subcuenta, las ve su junta; en la cuenta nacional, la Nacional y las juntas con
-- afiliados en esa empresa (pueden registrar la consignación que su empresa hizo a la cuenta padre).
CREATE OR REPLACE FUNCTION finanzas.fn_consignacion_visible(p_id_empresa BIGINT, p_id_cuenta BIGINT, p_nacional BOOLEAN, p_estamentos BIGINT[])
RETURNS BOOLEAN AS $$
    SELECT p_nacional OR EXISTS (
        SELECT 1 FROM finanzas.cuenta_bancaria c
         WHERE c.id_cuenta = p_id_cuenta
           AND ((NOT c.es_cuenta_nacional AND c.id_estamento = ANY(p_estamentos))
                OR (c.es_cuenta_nacional AND EXISTS (
                        SELECT 1 FROM gobernanza.afiliado_empresa ae JOIN gobernanza.afiliado a ON a.id_persona = ae.id_persona
                         WHERE ae.id_empresa = p_id_empresa AND a.id_estamento_pertenencia = ANY(p_estamentos)))));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;
GRANT EXECUTE ON FUNCTION finanzas.fn_consignacion_visible(BIGINT, BIGINT, BOOLEAN, BIGINT[]) TO PUBLIC;

SELECT seguridad.fn_aplicar_politicas('finanzas.consignacion_empresa',
    'finanzas.fn_consignacion_visible(id_empresa, id_cuenta_destino, :N, :E)',
    'finanzas.fn_consignacion_visible(id_empresa, id_cuenta_destino, :N, :E)');
-- La cuenta nacional es visible para todos (sin su saldo, que solo ve la Nacional): es la cuenta padre
-- a la que también pueden llegar consignaciones e ingresos de cualquier junta.
SELECT seguridad.fn_aplicar_politicas('finanzas.cuenta_bancaria',
    ':N OR id_estamento = ANY(:E) OR es_cuenta_nacional', ':N OR id_estamento = ANY(:E)');

-- Genera los aportes de una consignación sin duplicar los de otra consignación del mismo mes.
--   p_solo_junta = TRUE: solo los afiliados que pertenecen a la junta dueña de la subcuenta.
CREATE OR REPLACE FUNCTION finanzas.fn_generar_aportes(p_id_consignacion BIGINT, p_solo_junta BOOLEAN DEFAULT FALSE)
RETURNS INT AS $$
DECLARE v_c RECORD; v_n INT;
BEGIN
    SELECT ce.*, cb.es_cuenta_nacional, cb.id_estamento AS est_cuenta INTO v_c
      FROM finanzas.consignacion_empresa ce JOIN finanzas.cuenta_bancaria cb ON cb.id_cuenta = ce.id_cuenta_destino
     WHERE ce.id_consignacion = p_id_consignacion FOR UPDATE OF ce;
    IF v_c.id_consignacion IS NULL
       OR NOT finanzas.fn_consignacion_visible(v_c.id_empresa, v_c.id_cuenta_destino, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos()) THEN
        RAISE EXCEPTION 'La consignación no existe o está fuera de su ámbito territorial.';
    END IF;
    -- Dos generaciones simultáneas de la misma empresa y mes se serializan
    PERFORM pg_advisory_xact_lock(hashtext('aportes_empresa'), (v_c.id_empresa * 100000 + v_c.periodo_anio * 100 + v_c.periodo_mes)::INT);
    INSERT INTO finanzas.aporte_afiliado (id_consignacion, id_persona, periodo_mes, periodo_anio, monto_descuento_ley)
    SELECT p_id_consignacion, ae.id_persona, v_c.periodo_mes, v_c.periodo_anio,
           ROUND(gobernanza.fn_salario_vigente(ae.id_persona, ae.id_empresa, f.fin_mes) * finanzas.fn_parametro('PORCENTAJE_APORTE') / 100, 2)
      FROM gobernanza.afiliado_empresa ae
      JOIN gobernanza.afiliado a ON a.id_persona = ae.id_persona
     CROSS JOIN (SELECT (make_date(v_c.periodo_anio, v_c.periodo_mes, 1) + INTERVAL '1 month' - INTERVAL '1 day')::DATE AS fin_mes) f
     WHERE ae.id_empresa = v_c.id_empresa AND ae.fecha_ingreso_empresa <= f.fin_mes
       AND (NOT p_solo_junta OR v_c.es_cuenta_nacional OR a.id_estamento_pertenencia = v_c.est_cuenta)
       AND NOT EXISTS (SELECT 1 FROM finanzas.aporte_afiliado x
                        WHERE x.id_persona = ae.id_persona AND x.periodo_anio = v_c.periodo_anio AND x.periodo_mes = v_c.periodo_mes);
    GET DIAGNOSTICS v_n = ROW_COUNT;
    RETURN v_n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Cuenta donde debe estar el dinero de cada fondo: su subcuenta, o la nacional si no tiene
CREATE OR REPLACE FUNCTION finanzas.fn_cuenta_del_fondo(p_id_estamento BIGINT)
RETURNS BIGINT AS $$
    SELECT COALESCE((SELECT id_cuenta FROM finanzas.cuenta_bancaria WHERE id_estamento = p_id_estamento AND NOT es_cuenta_nacional),
                    (SELECT id_cuenta FROM finanzas.cuenta_bancaria WHERE es_cuenta_nacional ORDER BY id_cuenta LIMIT 1));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- A qué cuenta llegó cada consignación y a qué fondos corresponde ese dinero
DROP VIEW IF EXISTS finanzas.vf_consignaciones_por_cuenta;
CREATE VIEW finanzas.vf_consignaciones_por_cuenta AS
WITH d AS (
    SELECT x.id_consignacion, x.id_estamento, SUM(x.valor) AS valor
      FROM finanzas_interno.distribucion x GROUP BY x.id_consignacion, x.id_estamento
), r AS (
    SELECT ce.id_consignacion, ce.id_empresa, ce.periodo_anio, ce.periodo_mes, ce.fecha_consignacion, ce.monto_total_consignado,
           ce.id_cuenta_destino, cb.es_cuenta_nacional, cb.id_estamento AS est_cuenta,
           COALESCE(SUM(d.valor) FILTER (WHERE d.id_estamento IS NOT NULL AND finanzas.fn_cuenta_del_fondo(d.id_estamento) = ce.id_cuenta_destino), 0) AS para_esta_cuenta,
           COALESCE(SUM(d.valor) FILTER (WHERE d.id_estamento IS NOT NULL AND finanzas.fn_cuenta_del_fondo(d.id_estamento) <> ce.id_cuenta_destino), 0) AS para_otras_cuentas,
           COALESCE(SUM(d.valor) FILTER (WHERE d.id_estamento IS NULL), 0) AS sin_distribuir,
           string_agg(e.nombre_estamento || ': ' || d.valor, '; ' ORDER BY e.nombre_estamento) FILTER (WHERE d.id_estamento IS NOT NULL) AS reparto,
           array_agg(d.id_estamento) FILTER (WHERE d.id_estamento IS NOT NULL) AS fondos
      FROM finanzas.consignacion_empresa ce
      JOIN finanzas.cuenta_bancaria cb ON cb.id_cuenta = ce.id_cuenta_destino
      LEFT JOIN d ON d.id_consignacion = ce.id_consignacion
      LEFT JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento
     GROUP BY ce.id_consignacion, cb.es_cuenta_nacional, cb.id_estamento
)
SELECT emp.nombre_empresa AS empresa, r.periodo_anio || '-' || lpad(r.periodo_mes::TEXT, 2, '0') AS periodo, r.fecha_consignacion,
       CASE WHEN r.es_cuenta_nacional THEN 'Cuenta nacional' ELSE 'Subcuenta ' || et.nombre_estamento END AS consignada_en,
       r.monto_total_consignado AS valor, r.para_esta_cuenta, r.para_otras_cuentas, r.sin_distribuir, r.reparto,
       CASE WHEN r.sin_distribuir > finanzas.fn_parametro('TOLERANCIA_PESOS') THEN 'ALERTA MEDIA: CONSIGNACIÓN SIN DISCRIMINAR POR AFILIADO (GENERE LOS APORTES)'
            WHEN r.para_otras_cuentas > finanzas.fn_parametro('TOLERANCIA_PESOS') THEN 'INCLUYE DINERO DE OTROS FONDOS: SE EQUILIBRA CON LAS TRANSFERENCIAS PENDIENTES'
            ELSE 'TODO EL DINERO CORRESPONDE A ESTA CUENTA' END AS diagnostico,
       r.id_consignacion, r.id_empresa, r.id_cuenta_destino
  FROM r
  JOIN gobernanza.empresa emp ON emp.id_empresa = r.id_empresa
  LEFT JOIN gobernanza.estamento et ON et.id_estamento = r.est_cuenta
 WHERE (SELECT rolbypassrls OR rolsuper FROM pg_roles WHERE rolname = session_user)
    OR finanzas.fn_consignacion_visible(r.id_empresa, r.id_cuenta_destino, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos())
    OR EXISTS (SELECT 1 FROM unnest(r.fondos) f(id) WHERE f.id = ANY(seguridad.fn_ambito_estamentos()));

-- ----------------------------------------------------------------------------
-- 10. CORREOS FINANCIEROS
-- ----------------------------------------------------------------------------
INSERT INTO notificaciones.tipo_notificacion (codigo, nombre, descripcion) VALUES
    ('MORA_EMPRESAS', 'Mora de empresas',
     'Cada semana, al Tesorero de cada junta (en comités, al Secretario General), con copia al Presidente, la lista de empresas '
     'con afiliados de su junta que no consignaron o consignaron menos de lo esperado. El Tesorero Nacional recibe la de todo el país.'),
    ('RESUMEN_FISCAL', 'Resumen financiero para el Fiscal',
     'Cada mes, al Fiscal de cada junta (en comités, al Presidente), las alertas financieras de su junta. El Fiscal Nacional recibe las de todo el país.')
ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, descripcion = EXCLUDED.descripcion;
