-- ============================================================================
-- SGSINDICAL v9.1 — 02c: ACCESO POR ÁMBITO TERRITORIAL (SEGURIDAD POR FILAS)
-- Ejecutar DESPUÉS de 02b y ANTES de 03. Requiere PostgreSQL 15 o superior.
-- Si se vuelve a ejecutar 01 o 02b, ejecute de nuevo este script.
-- ----------------------------------------------------------------------------
-- ÁMBITO DE UN USUARIO
--   Nacional (ve y modifica todo el país):
--     · rol ADMIN, o
--     · usuario marcado con "acceso nacional", o
--     · quien ocupe un cargo vigente marcado con "acceso nacional" en el catálogo de cargos.
--   Territorial (los demás): los estamentos donde ocupa un cargo vigente (incluida la Junta
--     Nacional, solo para la información propia de la Nacional) + los estamentos que el
--     administrador le asigne (personal de apoyo).
--   Sin ámbito: solo ve el directorio común.
-- QUÉ SE FILTRA
--   · Afiliados (y su empresa/salario): por estamento de pertenencia.
--   · Empresas, sedes, jefes y comités de empresa: solo las empresas donde el ámbito tiene
--     afiliados (o empresas aún sin afiliados, para poder registrarlas).
--   · Directivos: los del ámbito; la composición de la Junta Nacional es visible para todos.
--   · Documentos, expedientes, compromisos, cuentas, consignaciones y aportes: por estamento.
--   · Auditoría (bitácora, accesos, backups): solo ámbito nacional.
--   Directorio común (todos lo ven): estamentos, inspectores, registros, tipos documentales, cargos.
-- ============================================================================
DO $$ BEGIN
    IF current_setting('server_version_num')::INT < 150000 THEN
        RAISE EXCEPTION 'El acceso territorial requiere PostgreSQL 15 o superior (vistas con security_invoker).';
    END IF;
END $$;

-- ----------------------------------------------------------------------------
-- 1. CONFIGURACIÓN DEL ÁMBITO
-- ----------------------------------------------------------------------------
ALTER TABLE seguridad.usuario ADD COLUMN IF NOT EXISTS ambito_nacional BOOLEAN NOT NULL DEFAULT FALSE;
COMMENT ON COLUMN seguridad.usuario.ambito_nacional IS 'TRUE = ve y modifica la información de todo el país.';

ALTER TABLE gobernanza.cargo_directivo ADD COLUMN IF NOT EXISTS acceso_nacional BOOLEAN NOT NULL DEFAULT FALSE;
COMMENT ON COLUMN gobernanza.cargo_directivo.acceso_nacional IS 'TRUE = quien ocupe este cargo tiene acceso a todo el país.';

CREATE TABLE IF NOT EXISTS seguridad.usuario_ambito (
    id_usuario BIGINT NOT NULL REFERENCES seguridad.usuario(id_usuario) ON DELETE CASCADE,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE CASCADE,
    fecha_asignacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_asignacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    PRIMARY KEY (id_usuario, id_estamento)
);
COMMENT ON TABLE seguridad.usuario_ambito IS 'Estamentos asignados manualmente a un usuario (personal de apoyo sin cargo directivo).';
CREATE INDEX IF NOT EXISTS ix_usuario_ambito_estamento ON seguridad.usuario_ambito (id_estamento);
DROP TRIGGER IF EXISTS trg_control_version ON seguridad.usuario_ambito;
CREATE TRIGGER trg_control_version BEFORE UPDATE ON seguridad.usuario_ambito
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version();
DROP TRIGGER IF EXISTS trg_auditoria ON seguridad.usuario_ambito;
CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON seguridad.usuario_ambito
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria();

-- ----------------------------------------------------------------------------
-- 2. FUNCIONES DE ÁMBITO (la aplicación fija app.id_usuario en cada transacción)
--    SECURITY DEFINER: leen usuarios y cargos sin quedar sujetas al propio filtro.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION seguridad.fn_id_usuario_actual()
RETURNS BIGINT AS $$
    SELECT NULLIF(current_setting('app.id_usuario', true), '')::BIGINT;
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE FUNCTION seguridad.fn_ambito_nacional()
RETURNS BOOLEAN AS $$
    SELECT COALESCE((
        SELECT u.codigo_rol = 'ADMIN' OR u.ambito_nacional OR EXISTS (
                   SELECT 1 FROM gobernanza.directivo_estamento d
                   JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
                  WHERE d.id_persona = u.id_persona AND d.fecha_retiro IS NULL AND c.acceso_nacional)
          FROM seguridad.usuario u
         WHERE u.id_usuario = seguridad.fn_id_usuario_actual() AND u.activo), FALSE);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_ambito_estamentos()
RETURNS BIGINT[] AS $$
    SELECT COALESCE(ARRAY(
        SELECT d.id_estamento FROM seguridad.usuario u
          JOIN gobernanza.directivo_estamento d ON d.id_persona = u.id_persona AND d.fecha_retiro IS NULL
         WHERE u.id_usuario = seguridad.fn_id_usuario_actual() AND u.activo
        UNION
        SELECT a.id_estamento FROM seguridad.usuario_ambito a JOIN seguridad.usuario u USING (id_usuario)
         WHERE a.id_usuario = seguridad.fn_id_usuario_actual() AND u.activo
    ), '{}');
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Empresa visible: el ámbito tiene afiliados en ella, o todavía no tiene afiliados
CREATE OR REPLACE FUNCTION seguridad.fn_empresa_visible(p_id_empresa BIGINT, p_nacional BOOLEAN, p_estamentos BIGINT[])
RETURNS BOOLEAN AS $$
    SELECT p_nacional
        OR EXISTS (SELECT 1 FROM gobernanza.afiliado_empresa ae JOIN gobernanza.afiliado a ON a.id_persona = ae.id_persona
                    WHERE ae.id_empresa = p_id_empresa AND a.id_estamento_pertenencia = ANY(p_estamentos))
        OR NOT EXISTS (SELECT 1 FROM gobernanza.afiliado_empresa ae WHERE ae.id_empresa = p_id_empresa);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Persona visible: afiliado del ámbito, directivo (cargo público) o persona que no es afiliada (contactos)
CREATE OR REPLACE FUNCTION seguridad.fn_persona_visible(p_id_persona BIGINT, p_nacional BOOLEAN, p_estamentos BIGINT[])
RETURNS BOOLEAN AS $$
    SELECT p_nacional
        OR NOT EXISTS (SELECT 1 FROM gobernanza.afiliado a WHERE a.id_persona = p_id_persona)
        OR EXISTS (SELECT 1 FROM gobernanza.afiliado a WHERE a.id_persona = p_id_persona
                      AND a.id_estamento_pertenencia = ANY(p_estamentos))
        OR EXISTS (SELECT 1 FROM gobernanza.directivo_estamento d WHERE d.id_persona = p_id_persona);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Búsquedas permitidas fuera del ámbito (solo datos mínimos), para vincular afiliados
-- a una empresa que ya existe con afiliados de otros estamentos.
CREATE OR REPLACE FUNCTION seguridad.fn_buscar_empresa_por_nit(p_nit TEXT)
RETURNS TABLE (valor BIGINT, etiqueta TEXT) AS $$
    SELECT id_empresa, nombre_empresa || ' (' || nit || ')' FROM gobernanza.empresa
     WHERE length(regexp_replace(p_nit, '[^0-9]', '', 'g')) >= 6
       AND regexp_replace(p_nit, '[^0-9]', '', 'g') IN (regexp_replace(nit, '[^0-9]', '', 'g'),                    -- con dígito de verificación
                                                        regexp_replace(split_part(nit, '-', 1), '[^0-9]', '', 'g')); -- sin él
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_sedes_de_empresa(p_id_empresa BIGINT)
RETURNS TABLE (valor BIGINT, etiqueta TEXT) AS $$
    SELECT id_sede, nombre_sede || ' - ' || municipio_sede FROM gobernanza.sede_empresa
     WHERE id_empresa = p_id_empresa ORDER BY nombre_sede;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Descripción del ámbito para mostrarla en la aplicación
CREATE OR REPLACE FUNCTION seguridad.fn_describir_ambito()
RETURNS TABLE (nacional BOOLEAN, estamentos TEXT[]) AS $$
    SELECT seguridad.fn_ambito_nacional(),
           ARRAY(SELECT nombre_estamento FROM gobernanza.estamento
                  WHERE id_estamento = ANY(seguridad.fn_ambito_estamentos()) ORDER BY nombre_estamento);
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 3. FUNCIONES DE REGLAS QUE DEBEN VER TODO EL PAÍS (consecutivos, unicidad, registros)
-- ----------------------------------------------------------------------------
DO $$
DECLARE f TEXT;
BEGIN
    FOREACH f IN ARRAY ARRAY[
        'gestion_documental.fn_generar_radicado_alfanumerico()',
        'gestion_documental.fn_generar_codigo_expediente()',
        'gestion_documental.fn_proteger_tipo_documento_usado()',
        'gestion_documental.fn_registrar_historial_tramite()',
        'gestion_documental.fn_aplicar_avance_compromiso()',
        'gobernanza.fn_validar_directivo()',
        'gobernanza.fn_validar_cambio_pertenencia()',
        'gobernanza.fn_verificar_pertenencia(bigint)',
        'gobernanza.fn_ck_pertenencia()',
        'gobernanza.fn_asociar_directivos_registro_vigente()',
        'gobernanza.fn_historial_registro_directivo()',
        'gobernanza.fn_registro_vigente(bigint)'] LOOP
        EXECUTE format('ALTER FUNCTION %s SECURITY DEFINER SET search_path = pg_catalog, public', f);
    END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- 4. POLÍTICAS POR TABLA
--    N = ámbito nacional ; E = estamentos del ámbito. Se evalúan una sola vez por consulta.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION seguridad.fn_aplicar_politicas(p_tabla TEXT, p_ver TEXT, p_modificar TEXT)
RETURNS VOID AS $$
DECLARE
    n TEXT := '(SELECT seguridad.fn_ambito_nacional())';
    e TEXT := '((SELECT seguridad.fn_ambito_estamentos())::BIGINT[])';
    v TEXT := replace(replace(p_ver, ':N', n), ':E', e);
    m TEXT := replace(replace(p_modificar, ':N', n), ':E', e);
    pol TEXT;
BEGIN
    EXECUTE format('ALTER TABLE %s ENABLE ROW LEVEL SECURITY', p_tabla);
    FOR pol IN SELECT policyname FROM pg_policies WHERE schemaname || '.' || tablename = p_tabla LOOP
        EXECUTE format('DROP POLICY %I ON %s', pol, p_tabla);
    END LOOP;
    EXECUTE format('CREATE POLICY p_ver ON %s FOR SELECT USING (%s)', p_tabla, v);
    EXECUTE format('CREATE POLICY p_registrar ON %s FOR INSERT WITH CHECK (%s)', p_tabla, m);
    EXECUTE format('CREATE POLICY p_actualizar ON %s FOR UPDATE USING (%s) WITH CHECK (%s)', p_tabla, m, m);
    EXECUTE format('CREATE POLICY p_eliminar ON %s FOR DELETE USING (%s)', p_tabla, m);
END;
$$ LANGUAGE plpgsql;

-- Directorio común: todos ven; solo el ámbito nacional modifica estamentos y catálogos
SELECT seguridad.fn_aplicar_politicas('gobernanza.estamento', 'true', ':N');
SELECT seguridad.fn_aplicar_politicas('gobernanza.cargo_directivo', 'true', ':N');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.tipo_documento', 'true', ':N');
SELECT seguridad.fn_aplicar_politicas('gobernanza.registro_inspector_estamento', 'true', ':N OR id_estamento = ANY(:E)');

-- Personas y afiliados
SELECT seguridad.fn_aplicar_politicas('gobernanza.persona',
    'seguridad.fn_persona_visible(id_persona, :N, :E)', 'seguridad.fn_persona_visible(id_persona, :N, :E)');
SELECT seguridad.fn_aplicar_politicas('gobernanza.afiliado',
    ':N OR id_estamento_pertenencia = ANY(:E)', ':N OR id_estamento_pertenencia = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('gobernanza.afiliado_empresa',
    'EXISTS (SELECT 1 FROM gobernanza.afiliado a WHERE a.id_persona = afiliado_empresa.id_persona)',
    'EXISTS (SELECT 1 FROM gobernanza.afiliado a WHERE a.id_persona = afiliado_empresa.id_persona)');

-- Empresas y lo que depende de ellas
SELECT seguridad.fn_aplicar_politicas('gobernanza.empresa',
    'seguridad.fn_empresa_visible(id_empresa, :N, :E)', 'seguridad.fn_empresa_visible(id_empresa, :N, :E)');
SELECT seguridad.fn_aplicar_politicas('gobernanza.sede_empresa',
    'EXISTS (SELECT 1 FROM gobernanza.empresa e WHERE e.id_empresa = sede_empresa.id_empresa)',
    'EXISTS (SELECT 1 FROM gobernanza.empresa e WHERE e.id_empresa = sede_empresa.id_empresa)');
SELECT seguridad.fn_aplicar_politicas('gobernanza.jefe_empresa',
    'EXISTS (SELECT 1 FROM gobernanza.empresa e WHERE e.id_empresa = jefe_empresa.id_empresa)',
    'EXISTS (SELECT 1 FROM gobernanza.empresa e WHERE e.id_empresa = jefe_empresa.id_empresa)');
SELECT seguridad.fn_aplicar_politicas('gobernanza.comite',
    'EXISTS (SELECT 1 FROM gobernanza.empresa e WHERE e.id_empresa = comite.id_empresa)',
    'EXISTS (SELECT 1 FROM gobernanza.empresa e WHERE e.id_empresa = comite.id_empresa)');
SELECT seguridad.fn_aplicar_politicas('gobernanza.comite_miembro',
    'EXISTS (SELECT 1 FROM gobernanza.comite c WHERE c.id_comite = comite_miembro.id_comite)',
    'EXISTS (SELECT 1 FROM gobernanza.comite c WHERE c.id_comite = comite_miembro.id_comite)');

-- Directivos: la composición de la Junta Nacional es pública; se modifica solo dentro del ámbito
SELECT seguridad.fn_aplicar_politicas('gobernanza.directivo_estamento',
    ':N OR id_estamento = ANY(:E) OR EXISTS (SELECT 1 FROM gobernanza.estamento e WHERE e.id_estamento = directivo_estamento.id_estamento AND e.tipo_estamento = ''JUNTA DIRECTIVA NACIONAL'')',
    ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('gobernanza.directivo_registro',
    'EXISTS (SELECT 1 FROM gobernanza.directivo_estamento d WHERE d.id_directivo_estamento = directivo_registro.id_directivo_estamento)',
    'EXISTS (SELECT 1 FROM gobernanza.directivo_estamento d WHERE d.id_directivo_estamento = directivo_registro.id_directivo_estamento)');

-- Gestión documental
SELECT seguridad.fn_aplicar_politicas('gestion_documental.documento', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.expediente', ':N OR id_estamento_custodio = ANY(:E)', ':N OR id_estamento_custodio = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.compromiso_tarea', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.historial_tramite',
    'EXISTS (SELECT 1 FROM gestion_documental.documento d WHERE d.id_documento = historial_tramite.id_documento)',
    'EXISTS (SELECT 1 FROM gestion_documental.documento d WHERE d.id_documento = historial_tramite.id_documento)');
SELECT seguridad.fn_aplicar_politicas('gestion_documental.historial_avance_compromiso',
    'EXISTS (SELECT 1 FROM gestion_documental.compromiso_tarea c WHERE c.id_compromiso = historial_avance_compromiso.id_compromiso)',
    'EXISTS (SELECT 1 FROM gestion_documental.compromiso_tarea c WHERE c.id_compromiso = historial_avance_compromiso.id_compromiso)');

-- Finanzas (las cuentas nacionales sin estamento solo las ve el ámbito nacional)
SELECT seguridad.fn_aplicar_politicas('finanzas.cuenta_bancaria', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('finanzas.consignacion_empresa',
    ':N OR EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria c WHERE c.id_cuenta = consignacion_empresa.id_cuenta_destino)',
    ':N OR EXISTS (SELECT 1 FROM finanzas.cuenta_bancaria c WHERE c.id_cuenta = consignacion_empresa.id_cuenta_destino)');
SELECT seguridad.fn_aplicar_politicas('finanzas.aporte_afiliado',
    ':N OR EXISTS (SELECT 1 FROM finanzas.consignacion_empresa c WHERE c.id_consignacion = aporte_afiliado.id_consignacion)'
    ' OR (id_consignacion IS NULL AND EXISTS (SELECT 1 FROM gobernanza.afiliado a WHERE a.id_persona = aporte_afiliado.id_persona))',
    ':N OR EXISTS (SELECT 1 FROM finanzas.consignacion_empresa c WHERE c.id_consignacion = aporte_afiliado.id_consignacion)'
    ' OR (id_consignacion IS NULL AND EXISTS (SELECT 1 FROM gobernanza.afiliado a WHERE a.id_persona = aporte_afiliado.id_persona))');

-- Auditoría: lectura solo con ámbito nacional; la aplicación puede registrar accesos y backups
DO $$
DECLARE t TEXT; pol TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['auditoria.bitacora_cambios', 'auditoria.registro_acceso', 'auditoria.registro_backup'] LOOP
        EXECUTE format('ALTER TABLE %s ENABLE ROW LEVEL SECURITY', t);
        FOR pol IN SELECT policyname FROM pg_policies WHERE schemaname || '.' || tablename = t LOOP
            EXECUTE format('DROP POLICY %I ON %s', pol, t);
        END LOOP;
        EXECUTE format('CREATE POLICY p_ver ON %s FOR SELECT USING ((SELECT seguridad.fn_ambito_nacional()))', t);
        EXECUTE format('CREATE POLICY p_registrar ON %s FOR INSERT WITH CHECK (true)', t);
    END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- 5. LAS VISTAS DE ALERTAS RESPETAN EL ÁMBITO DE QUIEN CONSULTA
-- ----------------------------------------------------------------------------
DO $$
DECLARE v RECORD;
BEGIN
    FOR v IN SELECT schemaname, viewname FROM pg_views
              WHERE schemaname IN ('gobernanza', 'gestion_documental', 'finanzas')
                AND viewname NOT LIKE 'vf\_%' LOOP   -- las vistas financieras vf_ aplican su propio filtro de ámbito
        EXECUTE format('ALTER VIEW %I.%I SET (security_invoker = true)', v.schemaname, v.viewname);
    END LOOP;
END $$;

GRANT EXECUTE ON FUNCTION seguridad.fn_id_usuario_actual(), seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos(),
    seguridad.fn_empresa_visible(BIGINT, BOOLEAN, BIGINT[]), seguridad.fn_persona_visible(BIGINT, BOOLEAN, BIGINT[]),
    seguridad.fn_buscar_empresa_por_nit(TEXT), seguridad.fn_sedes_de_empresa(BIGINT), seguridad.fn_describir_ambito()
    TO PUBLIC;
