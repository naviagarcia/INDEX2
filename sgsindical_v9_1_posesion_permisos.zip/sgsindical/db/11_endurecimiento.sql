-- ============================================================================
-- SGSINDICAL v9.1 — 11: ENDURECIMIENTO DE LA BASE DE DATOS
-- Ejecutar DESPUÉS de 10 (y de nuevo cada vez que se vuelva a ejecutar alguno de los scripts 02e a 10).
-- No modifica los archivos anteriores: ajusta en la base las funciones que ellos crearon.
-- ----------------------------------------------------------------------------
-- Objetivo: que la contraseña de la cuenta de la aplicación (sgs_app) no baste para saltarse las reglas.
--  E1. OPERACIONES AUTORIZADAS: las funciones que hacen cambios especiales (anular, aprobar, prorrogar…)
--      avisaban con una variable que cualquiera podía fijar. Ahora, además, dejan una marca en una tabla a
--      la que sgs_app no tiene acceso, ligada a la transacción. Los controles exigen las dos cosas.
--  E2. IDENTIDAD: la base ya no cree en "app.id_usuario". Sabe quién es el usuario por el token de una
--      sesión vigente ("app.sesion"); en la tabla de sesiones solo se guarda la huella del token, y las
--      sesiones solo se crean con la contraseña correcta (función de ingreso).
--  E3. USUARIOS Y PERMISOS: la aplicación ya no lee el hash de las contraseñas. Usuarios, roles, matriz de
--      permisos, ámbitos y parámetros solo los cambia un administrador con sesión vigente (o las funciones
--      de este sistema). Cambiar la propia contraseña y contar intentos fallidos van por funciones.
--  E4. VIGILANCIA: conexiones con las cuentas de la aplicación que no vienen de la aplicación e intentos
--      bloqueados que llegan por la aplicación: vista de alertas y correo al administrador y a la
--      Presidencia Nacional.
--  Al instalarlo se cierran todas las sesiones abiertas (cambia la forma de guardarlas).
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 0. ¿Quién ejecuta? Dueño de las tablas (funciones SECURITY DEFINER) o superusuario
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION seguridad.fn_ejecuta_sistema()
RETURNS BOOLEAN AS $$
    SELECT EXISTS (SELECT 1 FROM pg_roles r WHERE r.rolname = current_user
                      AND (r.rolsuper OR r.oid = (SELECT relowner FROM pg_class WHERE oid = 'seguridad.usuario'::regclass)))
        OR EXISTS (SELECT 1 FROM pg_roles r WHERE r.rolname = session_user AND r.rolsuper);
$$ LANGUAGE sql STABLE;

-- ----------------------------------------------------------------------------
-- E1. OPERACIONES AUTORIZADAS
-- ----------------------------------------------------------------------------
CREATE UNLOGGED TABLE IF NOT EXISTS seguridad.operacion_autorizada (
    xid XID8 NOT NULL,
    nombre TEXT NOT NULL,
    valor TEXT NOT NULL,
    creada TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    PRIMARY KEY (xid, nombre)
);
COMMENT ON TABLE seguridad.operacion_autorizada IS 'Marcas de las operaciones especiales en curso. Solo las escriben las funciones del sistema.';
REVOKE ALL ON seguridad.operacion_autorizada FROM PUBLIC;

-- Lo usan las funciones del sistema en lugar de set_config('x.operacion', …)
CREATE OR REPLACE FUNCTION seguridad.fn_fijar_operacion(p_nombre TEXT, p_valor TEXT)
RETURNS TEXT AS $$
BEGIN
    DELETE FROM seguridad.operacion_autorizada WHERE xid = pg_current_xact_id() AND nombre = p_nombre;
    IF COALESCE(p_valor, '') <> '' THEN
        INSERT INTO seguridad.operacion_autorizada (xid, nombre, valor) VALUES (pg_current_xact_id(), p_nombre, p_valor);
    END IF;
    IF random() < 0.01 THEN   -- limpieza ocasional de marcas viejas (cada transacción tiene un número distinto)
        DELETE FROM seguridad.operacion_autorizada WHERE creada < now() - INTERVAL '1 day';
    END IF;
    RETURN set_config(p_nombre, COALESCE(p_valor, ''), true);
END;
$$ LANGUAGE plpgsql SET search_path = pg_catalog, public;
REVOKE EXECUTE ON FUNCTION seguridad.fn_fijar_operacion(TEXT, TEXT) FROM PUBLIC;

-- Lo usan los controles en lugar de current_setting('x.operacion'): solo vale si hay marca (o si es un superusuario)
CREATE OR REPLACE FUNCTION seguridad.fn_operacion(p_nombre TEXT)
RETURNS TEXT AS $$
    SELECT CASE WHEN x.v = '' THEN ''
                WHEN EXISTS (SELECT 1 FROM pg_roles r WHERE r.rolname = session_user AND r.rolsuper) THEN x.v
                WHEN EXISTS (SELECT 1 FROM seguridad.operacion_autorizada o
                              WHERE o.xid = pg_current_xact_id_if_assigned() AND o.nombre = p_nombre AND o.valor = x.v) THEN x.v
                ELSE '' END
      FROM (SELECT COALESCE(current_setting(p_nombre, true), '') AS v) x;
$$ LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Reescribe las funciones de los scripts 02e a 10 que usan esas variables
DO $$
DECLARE f RECORD; v_def TEXT; v_nuevo TEXT; n INT := 0; v_quedan INT;
BEGIN
    FOR f IN SELECT p.oid, p.oid::regprocedure AS firma
               FROM pg_proc p JOIN pg_namespace s ON s.oid = p.pronamespace
              WHERE s.nspname IN ('seguridad', 'gobernanza', 'gestion_documental', 'finanzas', 'auditoria', 'notificaciones', 'secretos')
                AND p.prokind = 'f'
                AND p.proname NOT IN ('fn_operacion', 'fn_fijar_operacion')
                AND p.prosrc ~ '(current_setting|set_config)\(''[a-z_]+\.operacion'''
    LOOP
        v_def := pg_get_functiondef(f.oid);
        v_nuevo := regexp_replace(v_def, 'set_config\(''([a-z_]+\.operacion)'',\s*''([a-z_]*)'',\s*true\)',
                                  'seguridad.fn_fijar_operacion(''\1'', ''\2'')', 'g');
        v_nuevo := regexp_replace(v_nuevo, 'current_setting\(''([a-z_]+\.operacion)'',\s*true\)',
                                  'seguridad.fn_operacion(''\1'')', 'g');
        IF v_nuevo <> v_def THEN
            EXECUTE v_nuevo;
            n := n + 1;
        END IF;
    END LOOP;
    SELECT count(*) INTO v_quedan
      FROM pg_proc p JOIN pg_namespace s ON s.oid = p.pronamespace
     WHERE s.nspname IN ('seguridad', 'gobernanza', 'gestion_documental', 'finanzas', 'auditoria', 'notificaciones', 'secretos')
       AND p.proname NOT IN ('fn_operacion', 'fn_fijar_operacion')
       AND p.prosrc ~ '(current_setting|set_config)\(''[a-z_]+\.operacion''';
    IF v_quedan > 0 THEN
        RAISE EXCEPTION 'Quedaron % funciones con variables de operación sin proteger: revise el script.', v_quedan;
    END IF;
    RAISE NOTICE 'Funciones protegidas: %', n;
END $$;

-- ----------------------------------------------------------------------------
-- E2. IDENTIDAD POR SESIÓN
-- ----------------------------------------------------------------------------
-- Huella del token de sesión (la tabla de sesiones nunca guarda el token)
CREATE OR REPLACE FUNCTION seguridad.fn_huella_sesion(p_token TEXT)
RETURNS UUID AS $$
    SELECT substr(encode(sha256(convert_to(p_token, 'UTF8')), 'hex'), 1, 32)::UUID;
$$ LANGUAGE sql IMMUTABLE STRICT;

-- Sesión vigente de esta transacción (la aplicación fija app.sesion con el token)
CREATE OR REPLACE FUNCTION seguridad.fn_sesion_actual()
RETURNS UUID AS $$
    SELECT s.id_sesion FROM seguridad.sesion s JOIN seguridad.usuario u ON u.id_usuario = s.id_usuario
     WHERE s.id_sesion = seguridad.fn_huella_sesion(NULLIF(current_setting('app.sesion', true), ''))
       AND NOT s.revocada AND s.fecha_expiracion > now() AND u.activo;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_id_usuario_actual()
RETURNS BIGINT AS $$
    SELECT CASE
        WHEN NULLIF(current_setting('app.sesion', true), '') IS NOT NULL THEN
            (SELECT s.id_usuario FROM seguridad.sesion s JOIN seguridad.usuario u ON u.id_usuario = s.id_usuario
              WHERE s.id_sesion = seguridad.fn_huella_sesion(current_setting('app.sesion', true))
                AND NOT s.revocada AND s.fecha_expiracion > now() AND u.activo)
        -- Mantenimiento como superusuario (scripts y pruebas): se respeta el usuario indicado
        WHEN EXISTS (SELECT 1 FROM pg_roles r WHERE r.rolname = session_user AND r.rolsuper) THEN
            NULLIF(current_setting('app.id_usuario', true), '')::BIGINT
        END;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;
COMMENT ON FUNCTION seguridad.fn_id_usuario_actual() IS 'Usuario de la sesión vigente (por la huella del token). app.id_usuario ya no basta.';

-- El nombre que queda en la auditoría también sale de la sesión cuando la hay
CREATE OR REPLACE FUNCTION auditoria.fn_usuario_actual()
RETURNS VARCHAR AS $$
    SELECT COALESCE(
        (SELECT u.nombre_usuario FROM seguridad.sesion s JOIN seguridad.usuario u ON u.id_usuario = s.id_usuario
          WHERE NULLIF(current_setting('app.sesion', true), '') IS NOT NULL
            AND s.id_sesion = seguridad.fn_huella_sesion(current_setting('app.sesion', true)) AND NOT s.revocada),
        NULLIF(current_setting('app.usuario', true), ''), session_user)::VARCHAR;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Las sesiones abiertas se guardaron con el token: se cierran (los usuarios vuelven a ingresar)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_description WHERE objoid = 'seguridad.sesion'::regclass AND description LIKE '%huella%') THEN
        UPDATE seguridad.sesion SET revocada = TRUE WHERE NOT revocada;
        COMMENT ON TABLE seguridad.sesion IS 'Sesiones. id_sesion es la huella (SHA-256 truncada) del token; el token nunca se guarda.';
    END IF;
END $$;

-- Contraseñas: la aplicación recibe la sal (no el hash) y entrega el hash calculado para compararlo aquí
CREATE OR REPLACE FUNCTION seguridad.fn_sal_contrasena(p_nombre_usuario TEXT)
RETURNS TEXT AS $$
    SELECT COALESCE(
        (SELECT split_part(hash_contrasena, '$', 1) || '$' || split_part(hash_contrasena, '$', 2) || '$' || split_part(hash_contrasena, '$', 3)
           FROM seguridad.usuario WHERE nombre_usuario = p_nombre_usuario),
        -- Usuario inexistente: una sal fija y creíble para no revelar si existe
        'pbkdf2_sha256$' || COALESCE((SELECT split_part(hash_contrasena, '$', 2) FROM seguridad.usuario ORDER BY id_usuario LIMIT 1), '390000')
        || '$' || encode(substr(sha256(convert_to('sgs:' || COALESCE(p_nombre_usuario, ''), 'UTF8')), 1, 16), 'base64'));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Ingreso: compara el hash, cuenta intentos, bloquea, decide el segundo factor y crea la sesión
CREATE OR REPLACE FUNCTION seguridad.fn_iniciar_sesion(
    p_nombre_usuario TEXT, p_hash_calculado TEXT, p_huella UUID, p_ip INET, p_equipo TEXT, p_hash_equipo TEXT,
    p_max_intentos INT, p_bloqueo_minutos INT, p_dias_vigencia INT, p_horas_sesion INT)
RETURNS TABLE (resultado TEXT, detalle TEXT, id_usuario BIGINT, nombre_usuario TEXT, bloqueado_hasta TIMESTAMPTZ,
               debe_cambiar BOOLEAN, vencida BOOLEAN, mfa TEXT, mfa_dias INT, expira TIMESTAMPTZ) AS $$
DECLARE u seguridad.usuario%ROWTYPE; e RECORD; v_verificada BOOLEAN; v_mfa TEXT; v_dias INT; v_vencida BOOLEAN;
        v_debe BOOLEAN; v_expira TIMESTAMPTZ := now() + make_interval(hours => p_horas_sesion); v_int INT;
BEGIN
    SELECT * INTO u FROM seguridad.usuario x WHERE x.nombre_usuario = p_nombre_usuario FOR UPDATE;
    IF u.id_usuario IS NULL THEN
        RETURN QUERY SELECT 'FALLIDO', 'usuario inexistente', NULL::BIGINT, p_nombre_usuario, NULL::TIMESTAMPTZ, NULL::BOOLEAN, NULL::BOOLEAN, NULL, NULL::INT, NULL::TIMESTAMPTZ;
        RETURN;
    END IF;
    IF u.bloqueado_hasta IS NOT NULL AND u.bloqueado_hasta > now() THEN
        RETURN QUERY SELECT 'BLOQUEADA', 'cuenta bloqueada', u.id_usuario, u.nombre_usuario::TEXT, u.bloqueado_hasta, NULL::BOOLEAN, NULL::BOOLEAN, NULL, NULL::INT, NULL::TIMESTAMPTZ;
        RETURN;
    END IF;
    IF NOT u.activo THEN
        RETURN QUERY SELECT 'FALLIDO', 'usuario inactivo', u.id_usuario, u.nombre_usuario::TEXT, NULL::TIMESTAMPTZ, NULL::BOOLEAN, NULL::BOOLEAN, NULL, NULL::INT, NULL::TIMESTAMPTZ;
        RETURN;
    END IF;
    IF p_hash_calculado IS DISTINCT FROM u.hash_contrasena THEN
        v_int := u.intentos_fallidos + 1;
        IF v_int >= p_max_intentos THEN
            UPDATE seguridad.usuario x SET intentos_fallidos = 0, bloqueado_hasta = now() + make_interval(mins => p_bloqueo_minutos)
             WHERE x.id_usuario = u.id_usuario;
            RETURN QUERY SELECT 'BLOQUEO_NUEVO', v_int || ' intentos fallidos', u.id_usuario, u.nombre_usuario::TEXT,
                                now() + make_interval(mins => p_bloqueo_minutos), NULL::BOOLEAN, NULL::BOOLEAN, NULL, v_int, NULL::TIMESTAMPTZ;
        ELSE
            UPDATE seguridad.usuario x SET intentos_fallidos = v_int WHERE x.id_usuario = u.id_usuario;
            RETURN QUERY SELECT 'FALLIDO', 'intento ' || v_int, u.id_usuario, u.nombre_usuario::TEXT, NULL::TIMESTAMPTZ, NULL::BOOLEAN, NULL::BOOLEAN, NULL, v_int, NULL::TIMESTAMPTZ;
        END IF;
        RETURN;
    END IF;
    v_vencida := u.fecha_cambio_contrasena IS NULL OR u.fecha_cambio_contrasena < now() - make_interval(days => p_dias_vigencia);
    v_debe := u.debe_cambiar_contrasena OR v_vencida;
    UPDATE seguridad.usuario x SET intentos_fallidos = 0, bloqueado_hasta = NULL, fecha_ultimo_acceso = now(), debe_cambiar_contrasena = v_debe
     WHERE x.id_usuario = u.id_usuario;
    SELECT * INTO e FROM seguridad.fn_mfa_estado_ingreso(u.id_usuario, p_hash_equipo);
    IF e.activo THEN
        v_verificada := COALESCE(e.equipo_valido, FALSE); v_mfa := CASE WHEN v_verificada THEN NULL ELSE 'VERIFICAR' END;
    ELSIF e.requiere THEN
        v_verificada := e.plazo_hasta IS NOT NULL AND e.plazo_hasta > now();
        v_mfa := CASE WHEN v_verificada THEN 'PLAZO' ELSE 'CONFIGURAR' END;
        v_dias := CASE WHEN v_verificada THEN GREATEST(0, ceil(extract(epoch FROM e.plazo_hasta - now()) / 86400))::INT ELSE 0 END;
    ELSE
        v_verificada := TRUE;
    END IF;
    INSERT INTO seguridad.sesion (id_sesion, id_usuario, fecha_expiracion, ip_origen, equipo, mfa_verificada, mfa_metodo)
    VALUES (p_huella, u.id_usuario, v_expira, p_ip, left(p_equipo, 200), v_verificada, CASE WHEN e.activo AND v_verificada THEN 'EQUIPO' END);
    RETURN QUERY SELECT 'OK', NULL::TEXT, u.id_usuario, u.nombre_usuario::TEXT, NULL::TIMESTAMPTZ, v_debe, v_vencida AND NOT u.debe_cambiar_contrasena,
                        v_mfa, v_dias, v_expira;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Uso de la sesión actual
CREATE OR REPLACE FUNCTION seguridad.fn_sesion_actividad()
RETURNS VOID AS $$
    UPDATE seguridad.sesion SET ultima_actividad = now() WHERE id_sesion = seguridad.fn_sesion_actual();
$$ LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_sesion_cerrar_actual()
RETURNS VOID AS $$
    UPDATE seguridad.sesion SET revocada = TRUE
     WHERE id_sesion = seguridad.fn_huella_sesion(NULLIF(current_setting('app.sesion', true), ''));
$$ LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Cerrar una sesión (propia o, si es administrador, de cualquiera)
CREATE OR REPLACE FUNCTION seguridad.fn_revocar_sesion(p_id_sesion UUID)
RETURNS TEXT AS $$
DECLARE v_nombre TEXT;
BEGIN
    UPDATE seguridad.sesion s SET revocada = TRUE FROM seguridad.usuario u
     WHERE s.id_sesion = p_id_sesion AND u.id_usuario = s.id_usuario
       AND (seguridad.fn_es_admin() OR s.id_usuario = seguridad.fn_id_usuario_actual())
    RETURNING u.nombre_usuario INTO v_nombre;
    RETURN v_nombre;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Cerrar las sesiones de un usuario (las propias o, si es administrador, las de cualquiera)
CREATE OR REPLACE FUNCTION seguridad.fn_revocar_sesiones_usuario(p_id_usuario BIGINT, p_excepto_actual BOOLEAN DEFAULT FALSE)
RETURNS INT AS $$
DECLARE n INT;
BEGIN
    IF p_id_usuario IS DISTINCT FROM seguridad.fn_id_usuario_actual() AND NOT seguridad.fn_es_admin() THEN
        RAISE EXCEPTION 'SEGURIDAD: solo puede cerrar sus propias sesiones.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    UPDATE seguridad.sesion SET revocada = TRUE
     WHERE id_usuario = p_id_usuario AND NOT revocada
       AND (NOT p_excepto_actual OR id_sesion IS DISTINCT FROM seguridad.fn_sesion_actual());
    GET DIAGNOSTICS n = ROW_COUNT;
    RETURN n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- El segundo factor solo marca la sesión con la que se está trabajando
CREATE OR REPLACE FUNCTION seguridad.fn_mfa_marcar_sesion(p_id_sesion UUID, p_metodo TEXT)
RETURNS VOID AS $$
    UPDATE seguridad.sesion SET mfa_verificada = TRUE, mfa_reciente_en = now(), mfa_metodo = left(p_metodo, 16)
     WHERE id_sesion = p_id_sesion AND id_sesion = seguridad.fn_sesion_actual()
       AND id_usuario = seguridad.fn_id_usuario_actual();
$$ LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Códigos del segundo factor errados: cuenta, bloquea y cierra la sesión actual
CREATE OR REPLACE FUNCTION seguridad.fn_registrar_fallo_codigo(p_max_intentos INT, p_bloqueo_minutos INT)
RETURNS TABLE (intentos INT, bloqueada BOOLEAN) AS $$
DECLARE v_u BIGINT := seguridad.fn_id_usuario_actual(); v_n INT;
BEGIN
    IF v_u IS NULL THEN RAISE EXCEPTION 'SEGURIDAD: sesión no válida.' USING ERRCODE = 'insufficient_privilege'; END IF;
    UPDATE seguridad.usuario SET intentos_fallidos = intentos_fallidos + 1 WHERE id_usuario = v_u RETURNING intentos_fallidos INTO v_n;
    IF v_n >= p_max_intentos THEN
        UPDATE seguridad.usuario SET intentos_fallidos = 0, bloqueado_hasta = now() + make_interval(mins => p_bloqueo_minutos) WHERE id_usuario = v_u;
        UPDATE seguridad.sesion SET revocada = TRUE WHERE id_sesion = seguridad.fn_sesion_actual();
        RETURN QUERY SELECT v_n, TRUE;
    ELSE
        RETURN QUERY SELECT v_n, FALSE;
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_reiniciar_mis_intentos()
RETURNS VOID AS $$
    UPDATE seguridad.usuario SET intentos_fallidos = 0 WHERE id_usuario = seguridad.fn_id_usuario_actual();
$$ LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Cambio de la propia contraseña: compara el hash de la actual y guarda el nuevo
CREATE OR REPLACE FUNCTION seguridad.fn_cambiar_mi_contrasena(p_hash_actual TEXT, p_hash_nuevo TEXT)
RETURNS BOOLEAN AS $$
DECLARE v_u BIGINT := seguridad.fn_id_usuario_actual(); v_ok BOOLEAN;
BEGIN
    IF v_u IS NULL THEN RAISE EXCEPTION 'SEGURIDAD: sesión no válida.' USING ERRCODE = 'insufficient_privilege'; END IF;
    SELECT hash_contrasena = p_hash_actual INTO v_ok FROM seguridad.usuario WHERE id_usuario = v_u FOR UPDATE;
    IF NOT COALESCE(v_ok, FALSE) THEN RETURN FALSE; END IF;
    IF p_hash_nuevo IS NULL OR p_hash_nuevo NOT LIKE 'pbkdf2_sha256$%$%$%' THEN RAISE EXCEPTION 'Formato de contraseña no válido.'; END IF;
    UPDATE seguridad.usuario SET hash_contrasena = p_hash_nuevo, debe_cambiar_contrasena = FALSE, fecha_cambio_contrasena = now()
     WHERE id_usuario = v_u;
    RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- E3. USUARIOS, ROLES, PERMISOS, ÁMBITOS Y PARÁMETROS
-- ----------------------------------------------------------------------------
-- La aplicación deja de leer el hash de las contraseñas
DO $$
DECLARE v_cols TEXT;
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        SELECT string_agg(quote_ident(column_name), ', ' ORDER BY ordinal_position) INTO v_cols
          FROM information_schema.columns WHERE table_schema = 'seguridad' AND table_name = 'usuario' AND column_name <> 'hash_contrasena';
        REVOKE SELECT ON seguridad.usuario FROM sgs_app;
        REVOKE SELECT (hash_contrasena) ON seguridad.usuario FROM sgs_app;
        EXECUTE format('GRANT SELECT (%s) ON seguridad.usuario TO sgs_app', v_cols);
        -- Sesiones: solo con funciones
        REVOKE INSERT, UPDATE, DELETE ON seguridad.sesion FROM sgs_app;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_lectura') THEN
        REVOKE SELECT (hash_contrasena) ON seguridad.usuario FROM sgs_lectura;
    END IF;
END $$;

-- Usuarios: solo un administrador con sesión vigente (o las funciones del sistema). Arranque: si no hay
-- ningún administrador activo, se permite crear el primero (instalación nueva).
CREATE OR REPLACE FUNCTION seguridad.fn_proteger_usuario()
RETURNS TRIGGER AS $$
BEGIN
    IF seguridad.fn_ejecuta_sistema() OR seguridad.fn_es_admin() THEN RETURN NEW; END IF;
    IF NOT EXISTS (SELECT 1 FROM seguridad.usuario WHERE codigo_rol = 'ADMIN' AND activo) THEN
        RETURN NEW;   -- creación del primer administrador
    END IF;
    RAISE EXCEPTION 'SEGURIDAD: los usuarios solo los modifica un administrador con sesión vigente.' USING ERRCODE = 'insufficient_privilege';
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_proteger_usuario ON seguridad.usuario;
CREATE TRIGGER trg_proteger_usuario BEFORE INSERT OR UPDATE ON seguridad.usuario
    FOR EACH ROW EXECUTE FUNCTION seguridad.fn_proteger_usuario();

-- Tablas sin seguridad por filas que la aplicación escribe: solo el administrador (o con sesión, según el caso)
CREATE OR REPLACE FUNCTION seguridad.fn_solo_administrador()
RETURNS TRIGGER AS $$
BEGIN
    IF seguridad.fn_ejecuta_sistema() OR seguridad.fn_es_admin() THEN
        RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
    END IF;
    IF TG_ARGV[0] = 'sesion' AND seguridad.fn_id_usuario_actual() IS NOT NULL THEN
        RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
    END IF;
    RAISE EXCEPTION 'SEGURIDAD: % solo la modifica %.', replace(TG_TABLE_NAME, '_', ' '),
        CASE WHEN TG_ARGV[0] = 'sesion' THEN 'un usuario con sesión vigente' ELSE 'un administrador con sesión vigente' END
        USING ERRCODE = 'insufficient_privilege';
END;
$$ LANGUAGE plpgsql;
DO $$
DECLARE t TEXT[];
BEGIN
    FOREACH t SLICE 1 IN ARRAY ARRAY[
        ARRAY['seguridad.permiso_rol', 'admin'], ARRAY['seguridad.rol_app', 'admin'], ARRAY['seguridad.usuario_ambito', 'admin'],
        ARRAY['seguridad.parametro_privacidad', 'admin'], ARRAY['notificaciones.tipo_notificacion', 'admin'],
        ARRAY['gobernanza.inspector', 'sesion']] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_solo_administrador ON %s', t[1]);
        EXECUTE format('CREATE TRIGGER trg_solo_administrador BEFORE INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION seguridad.fn_solo_administrador(%L)', t[1], t[2]);
    END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- E4. VIGILANCIA
-- ----------------------------------------------------------------------------
ALTER TABLE auditoria.registro_acceso DROP CONSTRAINT IF EXISTS registro_acceso_evento_check;
ALTER TABLE auditoria.registro_acceso ADD CONSTRAINT registro_acceso_evento_check CHECK (evento IN (
    'LOGIN_OK', 'LOGIN_FALLIDO', 'CUENTA_BLOQUEADA', 'LOGOUT', 'CAMBIO_CONTRASENA', 'ACCESO_DENEGADO', 'SESION_REVOCADA',
    'MFA_OK', 'MFA_FALLIDO', 'MFA_ACTIVADO', 'MFA_RECUPERACION', 'MFA_REINICIADO', 'MFA_PASO_ADICIONAL', 'SEGURIDAD_BLOQUEO'));

CREATE TABLE IF NOT EXISTS auditoria.conexion_ajena (
    id_conexion BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    pid INT NOT NULL,
    inicio TIMESTAMP WITH TIME ZONE NOT NULL,
    usuario_bd TEXT NOT NULL,
    aplicacion TEXT,
    ip INET,
    detectada_en TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    CONSTRAINT uk_conexion_ajena UNIQUE (pid, inicio)
);
COMMENT ON TABLE auditoria.conexion_ajena IS 'Conexiones con las cuentas de la aplicación o del notificador que no vienen de esos programas.';
DROP TRIGGER IF EXISTS trg_inmutable ON auditoria.conexion_ajena;
CREATE TRIGGER trg_inmutable BEFORE UPDATE OR DELETE ON auditoria.conexion_ajena
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_bloquear_modificacion();

-- Revisa las conexiones activas (lo llaman el ingreso a la aplicación y el proceso de correos)
CREATE OR REPLACE FUNCTION auditoria.fn_detectar_conexiones_ajenas()
RETURNS INT AS $$
DECLARE n INT;
BEGIN
    INSERT INTO auditoria.conexion_ajena (pid, inicio, usuario_bd, aplicacion, ip)
    SELECT a.pid, a.backend_start, a.usename, NULLIF(a.application_name, ''), a.client_addr
      FROM pg_stat_activity a
     WHERE a.backend_type = 'client backend'
       AND ((a.usename = 'sgs_app' AND COALESCE(a.application_name, '') <> 'sgsindical_api')
            OR (a.usename = 'sgs_notificador' AND COALESCE(a.application_name, '') <> 'sgsindical_notificaciones'))
    ON CONFLICT (pid, inicio) DO NOTHING;
    GET DIAGNOSTICS n = ROW_COUNT;
    RETURN n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE VIEW auditoria.v_alertas_seguridad AS
SELECT 'CONEXIÓN AJENA' AS tipo, c.detectada_en AS fecha, c.usuario_bd AS cuenta,
       'Programa: ' || COALESCE(c.aplicacion, '(sin nombre)') || COALESCE(' · IP ' || host(c.ip), ' · conexión local') AS detalle,
       'ALERTA CRÍTICA: ALGUIEN SE CONECTÓ CON LA CONTRASEÑA DE LA APLICACIÓN FUERA DE ELLA' AS diagnostico
  FROM auditoria.conexion_ajena c WHERE c.detectada_en > now() - INTERVAL '30 days'
UNION ALL
SELECT 'INTENTO BLOQUEADO', r.fecha_hora, r.nombre_usuario, r.detalle,
       'ALERTA ALTA: LA BASE DE DATOS BLOQUEÓ UNA OPERACIÓN NO AUTORIZADA'
  FROM auditoria.registro_acceso r WHERE r.evento = 'SEGURIDAD_BLOQUEO' AND r.fecha_hora > now() - INTERVAL '30 days';
COMMENT ON VIEW auditoria.v_alertas_seguridad IS 'Últimos 30 días: conexiones ajenas a la aplicación e intentos bloqueados por la base.';

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        GRANT SELECT ON auditoria.v_alertas_seguridad, auditoria.conexion_ajena TO sgs_app;
        GRANT EXECUTE ON FUNCTION auditoria.fn_detectar_conexiones_ajenas() TO sgs_app;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_notificador') THEN
        GRANT SELECT ON auditoria.v_alertas_seguridad, auditoria.conexion_ajena TO sgs_notificador;
        GRANT EXECUTE ON FUNCTION auditoria.fn_detectar_conexiones_ajenas() TO sgs_notificador;
    END IF;
END $$;

INSERT INTO notificaciones.tipo_notificacion (codigo, nombre, descripcion) VALUES
    ('SEGURIDAD_BD', 'Alertas de seguridad de la base de datos',
     'Al administrador y a la Presidencia Nacional: conexiones con la contraseña de la aplicación hechas fuera de ella e intentos bloqueados por la base.')
ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, descripcion = EXCLUDED.descripcion;

-- ----------------------------------------------------------------------------
-- PERMISOS DE LAS FUNCIONES NUEVAS
-- ----------------------------------------------------------------------------
DO $$
DECLARE f TEXT; r TEXT;
BEGIN
    FOREACH f IN ARRAY ARRAY[
        'seguridad.fn_sal_contrasena(TEXT)',
        'seguridad.fn_iniciar_sesion(TEXT, TEXT, UUID, INET, TEXT, TEXT, INT, INT, INT, INT)',
        'seguridad.fn_sesion_actividad()', 'seguridad.fn_sesion_cerrar_actual()', 'seguridad.fn_revocar_sesion(UUID)',
        'seguridad.fn_revocar_sesiones_usuario(BIGINT, BOOLEAN)', 'seguridad.fn_registrar_fallo_codigo(INT, INT)',
        'seguridad.fn_reiniciar_mis_intentos()', 'seguridad.fn_cambiar_mi_contrasena(TEXT, TEXT)'] LOOP
        EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC', f);
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO sgs_app', f); END IF;
    END LOOP;
    FOREACH r IN ARRAY ARRAY['sgs_lectura', 'sgs_notificador', 'sgs_backup'] LOOP
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
            EXECUTE format('REVOKE EXECUTE ON FUNCTION seguridad.fn_fijar_operacion(TEXT, TEXT) FROM %I', r);
        END IF;
    END LOOP;
    -- Funciones internas (las usan solo otras funciones del sistema o sus disparadores): no se llaman directamente.
    -- Sin esto, quien tuviera la contraseña de la aplicación podría ejecutar en cascada inactivaciones o
    -- cierres de sesión ajenos, o recalcular el tipo de las reuniones de cualquier junta.
    FOREACH f IN ARRAY ARRAY['seguridad.fn_reglas_inactivar(TEXT, JSONB, TEXT)',
                             'gestion_documental.fn_recalcular_tipos(BIGINT, DATE)'] LOOP
        EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC', f);
        FOREACH r IN ARRAY ARRAY['sgs_app', 'sgs_lectura', 'sgs_notificador'] LOOP
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM %I', f, r); END IF;
        END LOOP;
    END LOOP;
END $$;
