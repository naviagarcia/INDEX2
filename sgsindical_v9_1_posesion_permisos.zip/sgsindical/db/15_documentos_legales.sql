-- ============================================================================
-- SGSINDICAL v9.1 · 15_documentos_legales.sql
-- Textos legales del sindicato y criterio para contar los plazos dudosos.
--
--  1. Política de tratamiento de datos personales, versión 2.0 (borrador completo según la Ley 1581
--     de 2012 y el Decreto 1074 de 2015, cap. 25), aviso de privacidad y reglamento interno de PQRSD
--     (Ley 1755 de 2015, art. 22). Quedan como BORRADOR: no se pueden publicar mientras tengan marcas
--     [COMPLETAR] o [VERIFICAR], que debe resolver el abogado; se publican con el acta de la Junta Nacional.
--  2. Las versiones vigentes se pueden consultar sin iniciar sesión (#/legal/...).
--  3. Criterio de cautela: si una norma admite dos formas de contar un plazo, se usa la que da la
--     fecha de respuesta más temprana. Por eso la aclaración (art. 19) ya no reinicia el plazo: se
--     reanuda con los días que quedaban, igual que al completar (art. 17).
--  4. El recurso de reposición se decide dentro de los 15 días hábiles siguientes (regla interna).
-- No modifica los scripts anteriores. Se puede ejecutar más de una vez.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. TEXTOS INSTITUCIONALES (aviso de privacidad y reglamento de PQRSD), con versiones
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.texto_institucional (
    id_texto BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    codigo VARCHAR(30) NOT NULL CHECK (codigo IN ('AVISO_PRIVACIDAD', 'REGLAMENTO_PQRSD')),
    numero_version VARCHAR(20) NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    texto TEXT NOT NULL,
    id_acta_aprobacion BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    vigente BOOLEAN NOT NULL DEFAULT FALSE,
    fecha_vigencia TIMESTAMP WITH TIME ZONE,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1,
    CONSTRAINT uk_texto_version UNIQUE (codigo, numero_version)
);
COMMENT ON TABLE gobernanza.texto_institucional IS
    'Aviso de privacidad y reglamento interno de PQRSD. Cada versión publicada es inmutable; rige una por texto.';
CREATE UNIQUE INDEX IF NOT EXISTS ux_texto_vigente ON gobernanza.texto_institucional (codigo) WHERE vigente;
CREATE INDEX IF NOT EXISTS ix_texto_acta ON gobernanza.texto_institucional (id_acta_aprobacion);

CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_texto_institucional()
RETURNS TRIGGER AS $$
BEGIN
    IF COALESCE(seguridad.fn_operacion('privacidad.operacion'), '') = 'publicar' THEN RETURN NEW; END IF;
    IF TG_OP = 'INSERT' THEN
        NEW.vigente := FALSE; NEW.fecha_vigencia := NULL; RETURN NEW;
    END IF;
    IF OLD.fecha_vigencia IS NOT NULL THEN
        RAISE EXCEPTION 'Una versión ya publicada no se modifica: cree una versión nueva.';
    END IF;
    IF NEW.vigente IS DISTINCT FROM OLD.vigente OR NEW.fecha_vigencia IS DISTINCT FROM OLD.fecha_vigencia THEN
        RAISE EXCEPTION 'El texto se publica con la acción Publicar.';
    END IF;
    IF NEW.codigo IS DISTINCT FROM OLD.codigo THEN RAISE EXCEPTION 'El tipo de texto no se cambia.'; END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_proteger_texto ON gobernanza.texto_institucional;
CREATE TRIGGER trg_proteger_texto BEFORE INSERT OR UPDATE ON gobernanza.texto_institucional
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_proteger_texto_institucional();
DROP TRIGGER IF EXISTS trg_no_borrar ON gobernanza.texto_institucional;
CREATE TRIGGER trg_no_borrar BEFORE DELETE ON gobernanza.texto_institucional FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado();
DROP TRIGGER IF EXISTS trg_auditoria ON gobernanza.texto_institucional;
CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON gobernanza.texto_institucional
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria();
DROP TRIGGER IF EXISTS trg_control_version ON gobernanza.texto_institucional;
CREATE TRIGGER trg_control_version BEFORE UPDATE ON gobernanza.texto_institucional
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version();

-- Marcas pendientes de un texto (lo que falta completar o verificar)
CREATE OR REPLACE FUNCTION gobernanza.fn_marcas_pendientes(p_texto TEXT)
RETURNS INT AS $$
    SELECT count(*)::INT FROM regexp_matches(COALESCE(p_texto, ''), '\[(COMPLETAR|VERIFICAR)[^\]]*\]', 'g');
$$ LANGUAGE sql IMMUTABLE;

CREATE OR REPLACE FUNCTION gobernanza.fn_publicar_texto_institucional(p_id_texto BIGINT)
RETURNS VOID AS $$
DECLARE v gobernanza.texto_institucional%ROWTYPE; v_marcas INT;
BEGIN
    IF NOT (seguridad.fn_es_admin() OR seguridad.fn_es_presidente_nacional()) THEN
        RAISE EXCEPTION 'Los textos institucionales los publican el administrador o la Presidencia Nacional.';
    END IF;
    SELECT * INTO v FROM gobernanza.texto_institucional WHERE id_texto = p_id_texto FOR UPDATE;
    IF v.id_texto IS NULL THEN RAISE EXCEPTION 'La versión no existe.'; END IF;
    IF v.fecha_vigencia IS NOT NULL THEN RAISE EXCEPTION 'Esta versión ya fue publicada.'; END IF;
    v_marcas := gobernanza.fn_marcas_pendientes(v.texto);
    IF v_marcas > 0 THEN
        RAISE EXCEPTION 'El texto tiene % marca(s) [COMPLETAR] o [VERIFICAR] sin resolver: el abogado debe revisarlo antes de publicarlo.', v_marcas;
    END IF;
    IF v.id_acta_aprobacion IS NULL THEN
        RAISE EXCEPTION 'Antes de publicarlo, asocie el acta de la Junta Nacional que aprobó esta versión.';
    END IF;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', 'publicar');
    UPDATE gobernanza.texto_institucional SET vigente = FALSE WHERE vigente AND codigo = v.codigo;
    UPDATE gobernanza.texto_institucional SET vigente = TRUE, fecha_vigencia = now() WHERE id_texto = p_id_texto;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', '');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- La política tampoco se publica con marcas pendientes
CREATE OR REPLACE FUNCTION gobernanza.fn_publicar_politica_tratamiento(p_id_politica BIGINT)
RETURNS VOID AS $$
DECLARE v_p gobernanza.politica_tratamiento%ROWTYPE; v_marcas INT;
BEGIN
    IF NOT (seguridad.fn_es_admin() OR seguridad.fn_es_presidente_nacional()) THEN
        RAISE EXCEPTION 'La política la publican el administrador o la Presidencia Nacional.';
    END IF;
    SELECT * INTO v_p FROM gobernanza.politica_tratamiento WHERE id_politica = p_id_politica FOR UPDATE;
    IF v_p.id_politica IS NULL THEN RAISE EXCEPTION 'La versión no existe.'; END IF;
    IF v_p.fecha_vigencia IS NOT NULL THEN RAISE EXCEPTION 'Esta versión ya fue publicada.'; END IF;
    v_marcas := gobernanza.fn_marcas_pendientes(v_p.texto);
    IF v_marcas > 0 THEN
        RAISE EXCEPTION 'La política tiene % marca(s) [COMPLETAR] o [VERIFICAR] sin resolver: el abogado debe revisarla antes de publicarla.', v_marcas;
    END IF;
    IF v_p.id_acta_aprobacion IS NULL THEN
        RAISE EXCEPTION 'Antes de publicarla, asocie el acta de la Junta Nacional que aprobó esta versión.';
    END IF;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', 'publicar');
    UPDATE gobernanza.politica_tratamiento SET vigente = FALSE WHERE vigente;
    UPDATE gobernanza.politica_tratamiento SET vigente = TRUE, fecha_vigencia = now() WHERE id_politica = p_id_politica;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', '');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Consulta pública (sin iniciar sesión) de la versión vigente
CREATE OR REPLACE FUNCTION gobernanza.fn_texto_publico(p_codigo TEXT)
RETURNS TABLE (titulo TEXT, numero_version TEXT, texto TEXT, fecha_vigencia TIMESTAMPTZ) AS $$
    SELECT p.titulo::TEXT, p.numero_version::TEXT, p.texto, p.fecha_vigencia
      FROM gobernanza.politica_tratamiento p WHERE p_codigo = 'POLITICA_DATOS' AND p.vigente
    UNION ALL
    SELECT t.titulo::TEXT, t.numero_version::TEXT, t.texto, t.fecha_vigencia
      FROM gobernanza.texto_institucional t WHERE t.codigo = p_codigo AND t.vigente;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 2. BORRADORES PARA EL ABOGADO
-- ----------------------------------------------------------------------------
INSERT INTO gobernanza.politica_tratamiento (numero_version, titulo, texto)
SELECT '2.0-borrador', 'Política de Tratamiento de Datos Personales de SINTRACAD', $txt$POLÍTICA DE TRATAMIENTO DE DATOS PERSONALES
SINTRACAD – Sindicato de Trabajadores Defensores de la Carrera Administrativa
Versión 2.0 · Borrador para revisión del abogado

1. RESPONSABLE DEL TRATAMIENTO
SINTRACAD – Sindicato de Trabajadores Defensores de la Carrera Administrativa, organización sindical de primer grado.
NIT: [COMPLETAR: NIT].
Registro sindical ante el Ministerio del Trabajo: [COMPLETAR: número y fecha].
Domicilio principal y dirección: [COMPLETAR: ciudad y dirección].
Correo para asuntos de datos personales: [COMPLETAR: p. ej. datospersonales@dominio].
Teléfono: [COMPLETAR].
Página web: [COMPLETAR: dirección de la plataforma ARCADIO].

2. MARCO LEGAL
Artículos 15 y 20 de la Constitución Política; Ley Estatutaria 1581 de 2012; Decreto 1074 de 2015, Libro 2, Parte 2, Título 2, Capítulo 25 (que compiló el Decreto 1377 de 2013), y las instrucciones de la Superintendencia de Industria y Comercio.

3. DEFINICIONES
Dato personal: información que identifica o puede identificar a una persona natural.
Dato sensible: el que afecta la intimidad del titular o cuyo uso indebido puede generar discriminación; entre ellos, la pertenencia a sindicatos y los datos de salud.
Titular: la persona a quien se refieren los datos.
Tratamiento: cualquier operación sobre los datos (recolección, almacenamiento, uso, circulación o supresión).
Responsable: quien decide sobre el tratamiento; en esta política, el sindicato.
Encargado: quien trata los datos por cuenta del responsable (por ejemplo, el proveedor del servidor).
Autorización: el consentimiento previo, expreso e informado del titular.

4. A QUIÉNES APLICA
A los datos de afiliados y de quienes solicitan afiliarse; directivos y suplentes; usuarios de la plataforma; personas que presentan peticiones, quejas, reclamos, sugerencias y denuncias (PQRSD); jefes, representantes legales y funcionarios de las empresas donde trabajan los afiliados; inspectores de trabajo; invitados a reuniones, y cualquier otra persona cuyos datos trate el sindicato en sus subdirectivas y comités.

5. DATOS QUE SE TRATAN
a) Identificación: nombres, apellidos, tipo y número de documento, fecha de nacimiento y género.
b) Contacto: correo electrónico, teléfono y dirección.
c) Laborales: empresa, sede, cargo, nivel, jefe directo, salario, fecha de ingreso y novedades de nómina que afectan la cuota sindical.
d) Sindicales: afiliación, subdirectiva o comité al que pertenece, aportes, cargos directivos, suplencias, asistencia a reuniones, decisiones y actas.
e) Contenido de las PQRSD y de los documentos que el titular aporta.
f) Imagen: fotografías y videos de actividades sindicales.
g) Uso de la plataforma: usuario, registros de ingreso, direcciones IP y registro de quién consultó datos personales.
El sindicato no recoge datos de niños, niñas o adolescentes. [VERIFICAR: confirmar que no se registran beneficiarios menores de edad.]

6. DATOS SENSIBLES
La pertenencia al sindicato es un dato sensible (Ley 1581, art. 5). El sindicato la trata en el curso de sus actividades legítimas y solo respecto de sus miembros y de quienes mantienen contacto regular con él por su finalidad (Ley 1581, art. 6, lit. c), y con la autorización explícita del titular.
El titular no está obligado a autorizar el tratamiento de datos sensibles ni a responder preguntas sobre ellos. Sin embargo, la afiliación implica necesariamente conocer la pertenencia al sindicato para gestionarla.
Si para un trámite (por ejemplo, una exoneración del aporte o una licencia) el titular aporta información de salud, esta se usa solo para ese trámite y con acceso restringido.
El salario y el género son datos reservados: solo los ven los cargos que los necesitan, y cada consulta queda registrada.

7. FINALIDADES
a) Gestión sindical (necesaria para ser afiliado): afiliar y desafiliar; representar y defender los derechos laborales y sindicales; negociar colectivamente; recaudar y conciliar la cuota sindical con las empresas; expedir certificados; convocar reuniones, llevar actas y elegir directivos; inscribir juntas ante el Ministerio del Trabajo; tramitar PQRSD; escalar quejas ante los jefes y representantes legales de las empresas; cumplir obligaciones legales y estatutarias, y proteger la seguridad de la información.
b) Comunicaciones del sindicato (opcional): enviar información, convocatorias generales, boletines y saludos, por correo o mensajería.
c) Uso de imagen (opcional): publicar fotos y videos de actividades sindicales en los medios y redes del sindicato.
Los datos de jefes y representantes de las empresas se tratan para comunicarse con ellas, escalar quejas y negociar; los de peticionarios, para tramitar y responder su solicitud.
Las finalidades opcionales se pueden aceptar, negar o revocar en cualquier momento sin afectar la afiliación.

8. DERECHOS DEL TITULAR (Ley 1581, art. 8)
a) Conocer, actualizar y rectificar sus datos.
b) Pedir prueba de la autorización otorgada.
c) Ser informado, previa solicitud, del uso que se ha dado a sus datos.
d) Presentar quejas ante la Superintendencia de Industria y Comercio, después de agotar el trámite ante el sindicato.
e) Revocar la autorización o pedir la supresión de sus datos, cuando no exista un deber legal o estatutario de conservarlos.
f) Acceder gratis a sus datos, al menos una vez cada mes calendario y cada vez que haya cambios sustanciales en esta política.
Los afiliados pueden consultar sus datos, aportes, solicitudes y autorizaciones, y quién ha consultado su información, en el portal del afiliado.

9. CÓMO EJERCER LOS DERECHOS
Canales: el correo [COMPLETAR: correo de datos personales], el portal del afiliado o la ventanilla de cada subdirectiva o comité.
Área responsable: [COMPLETAR: cargo o dependencia que atiende las solicitudes, p. ej. la Secretaría General Nacional].
Consultas: se responden dentro de los 10 días hábiles siguientes a su recibo. Si no es posible, se informan los motivos antes del vencimiento y se responde dentro de los 5 días hábiles siguientes.
Reclamos (actualización, rectificación, supresión o revocación): deben indicar la identificación del titular, la descripción de los hechos, la dirección y los documentos que se quieran hacer valer.
- Si el reclamo está incompleto, se le pide al interesado completarlo dentro de los 5 días siguientes a su recibo; si pasan 2 meses sin que lo haga, se entiende que desistió.
- Si el sindicato no es competente, lo traslada a quien corresponda dentro de 2 días hábiles y le informa al interesado.
- Recibido el reclamo completo, los datos llevan la leyenda «reclamo en trámite» y su motivo en no más de 2 días hábiles, hasta que se decida.
- El reclamo se responde dentro de los 15 días hábiles siguientes al día de su recibo; si no es posible, se informan los motivos y se responde dentro de los 8 días hábiles siguientes.
Lo que se recibe a partir de las 5:00 p. m., o en sábado, domingo o festivo, se entiende recibido el día hábil siguiente.

10. SEGURIDAD
El sindicato protege los datos con estas medidas: acceso según el cargo y la subdirectiva o comité; verificación en dos pasos para quienes ven datos de otras personas; registro de cada consulta a datos personales y de cada cambio; cifrado de las claves; conexiones seguras (HTTPS); copias de seguridad verificadas, y conservación de la información sin borrado, mediante inactivación y anulación con motivo.

11. ENCARGADOS Y TRANSFERENCIAS
El sindicato puede encargar el tratamiento a terceros que le prestan servicios, bajo contrato y con las mismas garantías de esta política:
- Alojamiento del servidor: [COMPLETAR: proveedor y país del centro de datos].
- Envío de correos: [COMPLETAR: proveedor].
- Asistencia de inteligencia artificial para redactar escritos: [COMPLETAR: proveedor y país]. Al usarla se evita incluir datos sensibles que no sean necesarios para el escrito.
Cuando el encargado está fuera de Colombia, la transmisión se rige por la Ley 1581 (art. 26) y el Decreto 1074 de 2015 (arts. 2.2.2.25.5.1 y 2.2.2.25.5.2), mediante contrato de transmisión o autorización del titular. [VERIFICAR: contratos de transmisión vigentes con cada proveedor.]
El sindicato no vende ni cede datos personales. Solo los entrega a autoridades que los pidan en ejercicio de sus funciones, y a las empresas en lo necesario para el descuento y la consignación de la cuota sindical (Código Sustantivo del Trabajo, art. 400).

12. CONSERVACIÓN
Los datos se conservan mientras dure la relación con el sindicato y, después, durante el tiempo que exijan la ley, los estatutos y las tablas de retención documental del sindicato. Las actas, los registros de aportes y la información contable se conservan aunque el titular pida la supresión, por su valor legal; en ese caso se suprime lo demás y se anonimiza lo que lo identifica. [VERIFICAR: plazos de conservación de actas, aportes y contabilidad.]
El registro de consultas a datos personales se conserva 5 años.

13. VIGENCIA Y CAMBIOS
Esta política rige desde su publicación, aprobada por la Junta Directiva Nacional en el acta [COMPLETAR: número y fecha]. Las bases de datos se mantienen mientras el sindicato exista y la finalidad lo requiera.
Los cambios sustanciales se informarán a los titulares antes de aplicarse; si cambian las finalidades, se pedirá una nueva autorización.
[VERIFICAR: si los activos del sindicato superan 100.000 UVT, inscribir sus bases de datos en el Registro Nacional de Bases de Datos de la SIC (Decreto 1074 de 2015, art. 2.2.2.26.1.2).]$txt$
WHERE NOT EXISTS (SELECT 1 FROM gobernanza.politica_tratamiento WHERE numero_version = '2.0-borrador');

INSERT INTO gobernanza.texto_institucional (codigo, numero_version, titulo, texto)
SELECT 'AVISO_PRIVACIDAD', '1.0-borrador', 'Aviso de privacidad de SINTRACAD', $txt$AVISO DE PRIVACIDAD
SINTRACAD – Sindicato de Trabajadores Defensores de la Carrera Administrativa, NIT [COMPLETAR: NIT], con domicilio en [COMPLETAR: ciudad y dirección], es el responsable del tratamiento de sus datos personales.

Para qué usamos sus datos: para la gestión sindical (afiliación, representación, defensa de derechos, cuota sindical, certificados, reuniones, actas y PQRSD) y, solo si usted lo autoriza, para enviarle comunicaciones del sindicato y para publicar su imagen en actividades sindicales.

La pertenencia al sindicato es un dato sensible. Usted no está obligado a autorizar el tratamiento de datos sensibles ni a responder preguntas sobre ellos.

Sus derechos: conocer, actualizar, rectificar y suprimir sus datos, revocar la autorización, pedir prueba de ella y presentar quejas ante la Superintendencia de Industria y Comercio. Puede ejercerlos en el correo [COMPLETAR: correo de datos personales], en el portal del afiliado o en la ventanilla de su subdirectiva o comité.

La política de tratamiento completa está publicada en la plataforma del sindicato: [COMPLETAR: dirección]/#/legal/politica-datos.$txt$
WHERE NOT EXISTS (SELECT 1 FROM gobernanza.texto_institucional WHERE codigo = 'AVISO_PRIVACIDAD');

INSERT INTO gobernanza.texto_institucional (codigo, numero_version, titulo, texto)
SELECT 'REGLAMENTO_PQRSD', '1.0-borrador', 'Reglamento interno para el trámite de PQRSD', $txt$REGLAMENTO INTERNO PARA EL TRÁMITE DE PETICIONES, QUEJAS, RECLAMOS, SUGERENCIAS Y DENUNCIAS (PQRSD)
SINTRACAD – Sindicato de Trabajadores Defensores de la Carrera Administrativa
Versión 1.0 · Borrador para revisión del abogado
Expedido por la Junta Directiva Nacional en el acta [COMPLETAR: número y fecha], en cumplimiento del artículo 22 de la Ley 1437 de 2011, sustituido por la Ley 1755 de 2015, aplicable a las organizaciones privadas según su artículo 32.

ARTÍCULO 1. OBJETO. Este reglamento fija cómo el sindicato recibe, tramita y responde las PQRSD que le presentan afiliados y terceros.

ARTÍCULO 2. CANAL DE RECEPCIÓN. Las PQRSD se reciben en el correo institucional [COMPLETAR: correo]. Las que lleguen en papel o de forma verbal se digitalizan o se transcriben y se remiten a ese correo. Al registrarla, el sistema asigna un radicado y envía al peticionario un acuse con la fecha límite de respuesta.

ARTÍCULO 3. HORA DE CORTE. Las PQRSD que lleguen a partir de las 5:00 p. m., o en sábado, domingo o festivo, se entienden recibidas el día hábil siguiente. Los plazos se cuentan en días hábiles, a partir del día siguiente al de la recepción.

ARTÍCULO 4. PLAZOS DE RESPUESTA (Ley 1755 de 2015, art. 14).
- Peticiones, quejas, reclamos, sugerencias y denuncias: 15 días hábiles.
- Solicitudes de documentos o de información: 10 días hábiles. Si no se responden a tiempo, se entienden aceptadas y los documentos se entregan dentro de los 3 días hábiles siguientes.
- Consultas: 30 días hábiles.
- Las felicitaciones se responden por cortesía dentro de los 15 días hábiles.
El sindicato puede fijar plazos más cortos, pero nunca más largos que los de la ley.

ARTÍCULO 5. CRITERIO DE CAUTELA. Cuando una norma admita más de una forma de contar un plazo, se aplicará la que produzca la fecha de respuesta más temprana.

ARTÍCULO 6. PRÓRROGA. Cuando excepcionalmente no sea posible responder a tiempo, se informará al peticionario antes del vencimiento, con los motivos y la nueva fecha, que no podrá exceder del doble del plazo inicial. Solo se prorroga una vez.

ARTÍCULO 7. SOLICITUD INCOMPLETA (art. 17). Si a la solicitud le falta información o documentos, se le pedirá al peticionario completarla dentro de los 10 días hábiles siguientes a la radicación. El plazo para responder queda suspendido. El peticionario tiene 1 mes para completarla, ampliable por 1 mes más si lo pide antes del vencimiento. Cuando la complete, el plazo se reanuda con los días hábiles que quedaban.

ARTÍCULO 8. DESISTIMIENTO TÁCITO. Si el peticionario no completa la solicitud a tiempo, se declarará el desistimiento mediante decisión motivada, que se le notificará por correo. Contra ella procede el recurso de reposición, que puede presentar dentro de los 10 días hábiles siguientes a la notificación (Ley 1437 de 2011, art. 76). La junta lo decidirá dentro de los 15 días hábiles siguientes a su recibo. Si se revoca el desistimiento, el trámite continúa con los días hábiles que quedaban. El peticionario siempre puede presentar de nuevo la solicitud.

ARTÍCULO 9. PETICIÓN QUE NO SE ENTIENDE (art. 19). Si no se comprende la finalidad u objeto de la petición, se le devolverá al peticionario para que la aclare dentro de los 10 días hábiles siguientes, sin ampliación. El plazo para responder queda suspendido y, al aclararse, se reanuda con los días hábiles que quedaban. Si no se aclara, se archiva.

ARTÍCULO 10. TRASLADO POR COMPETENCIA (art. 21). Si la PQRSD corresponde a otra subdirectiva o comité, o a otra entidad, se trasladará dentro de los 5 días hábiles siguientes a su recepción, con copia al peticionario. Cuando se traslada a otra junta del sindicato, el plazo se cuenta desde que esta la recibe.

ARTÍCULO 11. ATENCIÓN PRIORITARIA (art. 20). Las peticiones que busquen evitar un perjuicio irremediable a un derecho fundamental se tramitarán con prioridad. Si hay riesgo para la vida o la integridad del peticionario, se adoptarán de inmediato las medidas de urgencia que estén al alcance del sindicato.

ARTÍCULO 12. DENUNCIAS. Antes de responder una denuncia se requiere el concepto jurídico del abogado o de la Secretaría Jurídica.

ARTÍCULO 13. ANÓNIMAS. Las PQRSD anónimas se registran y se archivan sin trámite. [VERIFICAR: si las denuncias anónimas con hechos concretos y verificables deben tramitarse.]

ARTÍCULO 14. QUIÉN TRAMITA Y FIRMA. Registran las PQRSD la Ventanilla y el Presidente, el Vicepresidente, el Secretario General o el Fiscal de la junta que la atiende. Esos cuatro cargos prorrogan, piden completar o aclarar, declaran el desistimiento, trasladan y firman la respuesta.

ARTÍCULO 15. RESPUESTA. La respuesta es de fondo, clara y congruente con lo pedido. Sale firmada con el cargo de quien responde, en PDF con huella de integridad, al correo del peticionario. Cada PQRSD conserva una historia que no se puede alterar.

ARTÍCULO 16. DATOS PERSONALES. Los datos de los peticionarios se tratan según la Política de Tratamiento de Datos Personales del sindicato.

ARTÍCULO 17. VIGENCIA. Este reglamento rige desde su publicación en la plataforma del sindicato.$txt$
WHERE NOT EXISTS (SELECT 1 FROM gobernanza.texto_institucional WHERE codigo = 'REGLAMENTO_PQRSD');

-- ----------------------------------------------------------------------------
-- 3. CRITERIO DE CAUTELA EN LA ACLARACIÓN (art. 19): el plazo se reanuda, no se reinicia
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_pedir_aclaracion(p_id BIGINT, p_texto TEXT)
RETURNS DATE AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE; v_hoy DATE := gestion_documental.fn_hoy(); v_hasta DATE; v_quedan INT;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    PERFORM gestion_documental.fn_pqrsd_exigir_autorizado(v.id_estamento, 'La solicitud de aclaración la hacen');
    IF length(trim(COALESCE(p_texto, ''))) < 20 THEN RAISE EXCEPTION 'Explique qué no se entiende de la petición (mínimo 20 caracteres).'; END IF;
    IF v.estado = 'EN_REQUERIMIENTO' OR v.fecha_requerimiento IS NOT NULL THEN
        RAISE EXCEPTION 'Ya se le hizo un requerimiento al peticionario en esta solicitud.';
    END IF;
    IF v.dias_prorroga > 0 THEN RAISE EXCEPTION 'La PQRSD ya fue prorrogada: la aclaración se pide antes, cuando se recibe.'; END IF;
    v_hasta := gobernanza.fn_sumar_dias_habiles(v_hoy, gestion_documental.fn_parametro_pqrsd('DIAS_ACLARAR')::INT);
    v_quedan := GREATEST(gobernanza.fn_dias_habiles_entre(GREATEST(v_hoy, v.fecha_base), v.fecha_limite), 1);
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', 'requerir');
    UPDATE gestion_documental.pqrsd SET estado = 'EN_REQUERIMIENTO', tipo_requerimiento = 'ACLARAR', texto_requerimiento = trim(p_texto),
           fecha_requerimiento = v_hoy, dias_restantes_suspension = v_quedan, fecha_limite_completar = v_hasta
     WHERE id_pqrsd = p_id;
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', '');
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'ACLARACION',
        format('No se comprende el objeto de la petición: se devolvió para que la aclare a más tardar el %s (Ley 1755, art. 19). '
               || 'El plazo queda suspendido con %s día(s) hábil(es) por correr, que se reanudan al aclararla. Qué debe aclarar: %s',
               to_char(v_hasta, 'DD/MM/YYYY'), v_quedan, trim(p_texto)));
    RETURN v_hasta;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_completada(p_id BIGINT, p_detalle TEXT, p_momento TIMESTAMPTZ DEFAULT NULL)
RETURNS DATE AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE; v_momento TIMESTAMPTZ := COALESCE(p_momento, now()); v_nueva DATE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    IF NOT (gestion_documental.fn_pqrsd_autorizado(v.id_estamento) OR seguridad.fn_rol_actual() = 'VENTANILLA') THEN
        RAISE EXCEPTION 'Registran la información recibida la Ventanilla y los cuatro cargos de la junta.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF v.estado <> 'EN_REQUERIMIENTO' THEN RAISE EXCEPTION 'La PQRSD no está esperando que el peticionario la complete o aclare.'; END IF;
    IF v_momento > now() + INTERVAL '10 minutes' OR (v_momento AT TIME ZONE gestion_documental.fn_zona())::DATE < v.fecha_requerimiento THEN
        RAISE EXCEPTION 'La fecha de recibo de la información no es válida.';
    END IF;
    IF (v_momento AT TIME ZONE gestion_documental.fn_zona())::DATE > v.fecha_limite_completar THEN
        RAISE EXCEPTION 'La información llegó después del plazo (%): corresponde % ; el peticionario puede presentarla de nuevo.',
            to_char(v.fecha_limite_completar, 'DD/MM/YYYY'),
            CASE WHEN v.tipo_requerimiento = 'ACLARAR' THEN 'archivar la petición' ELSE 'declarar el desistimiento' END;
    END IF;
    IF length(trim(COALESCE(p_detalle, ''))) < 10 THEN RAISE EXCEPTION 'Describa qué aportó el peticionario (mínimo 10 caracteres).'; END IF;
    v_nueva := gobernanza.fn_sumar_dias_habiles(gobernanza.fn_dia_base_radicacion(v_momento), v.dias_restantes_suspension);
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', 'completar');
    UPDATE gestion_documental.pqrsd SET estado = 'EN_TRAMITE', fecha_completada = v_momento, fecha_limite = v_nueva WHERE id_pqrsd = p_id;
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', '');
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'COMPLETADA',
        format('El peticionario %s. El plazo se reanuda con %s día(s) hábil(es): nueva fecha límite %s. %s',
               CASE WHEN v.tipo_requerimiento = 'ACLARAR' THEN 'aclaró la petición' ELSE 'completó la solicitud' END,
               v.dias_restantes_suspension, to_char(v_nueva, 'DD/MM/YYYY'), trim(p_detalle)));
    RETURN v_nueva;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 4. PLAZO INTERNO PARA DECIDIR EL RECURSO DE REPOSICIÓN
-- ----------------------------------------------------------------------------
INSERT INTO gestion_documental.parametro_pqrsd (codigo, valor, descripcion) VALUES
    ('DIAS_DECIDIR_RECURSO', 15, 'Días hábiles que tiene la junta para decidir el recurso de reposición (regla interna del reglamento de PQRSD).')
ON CONFLICT (codigo) DO NOTHING;

-- La vista de PQRSD: alerta crítica si el recurso no se decide en el plazo interno
CREATE OR REPLACE VIEW gestion_documental.v_auditoria_pqrsd WITH (security_invoker = true) AS
 WITH q AS (
         SELECT p.id_pqrsd,
            p.radicado,
            p.tipo,
            p.id_estamento,
            p.anonima,
            p.nombre_peticionario,
            p.tipo_documento,
            p.numero_documento,
            p.correo_peticionario,
            p.telefono_peticionario,
            p.id_persona,
            p.asunto,
            p.descripcion,
            p.medio,
            p.fecha_recepcion,
            p.motivo_registro_tardio,
            p.id_documento_soporte,
            p.fecha_base,
            p.plazo_dias,
            p.dias_prorroga,
            p.fecha_limite,
            p.motivo_prorroga,
            p.fecha_prorroga,
            p.texto_requerimiento,
            p.fecha_requerimiento,
            p.dias_restantes_suspension,
            p.fecha_limite_completar,
            p.prorroga_completar,
            p.fecha_completada,
            p.id_estamento_origen,
            p.entidad_traslado,
            p.traslado_tardio,
            p.concepto_juridico,
            p.fecha_concepto,
            p.usuario_concepto,
            p.estado,
            p.respuesta,
            p.fecha_respuesta,
            p.usuario_respuesta,
            p.cargo_firma,
            p.huella_respuesta,
            p.id_documento_respuesta,
            p.fecha_cierre,
            p.observacion_cierre,
            p.fecha_creacion,
            p.usuario_creacion,
            p.version,
            p.tipo_requerimiento,
            p.fecha_recurso,
            p.decision_recurso,
            gestion_documental.fn_hoy() AS hoy,
            t.nombre AS nombre_tipo,
            t.silencio_positivo,
            t.revision_juridica,
            GREATEST((p.plazo_dias + p.dias_prorroga), 1) AS plazo_vigente,
                CASE
                    WHEN ((p.estado)::text = ANY (ARRAY[('RADICADA'::character varying)::text, ('EN_TRAMITE'::character varying)::text])) THEN gobernanza.fn_dias_habiles_entre(GREATEST(gestion_documental.fn_hoy(), p.fecha_base), p.fecha_limite)
                    ELSE NULL::integer
                END AS restantes
           FROM (gestion_documental.pqrsd p
             JOIN gestion_documental.tipo_pqrsd t ON (((t.codigo)::text = (p.tipo)::text)))
        )
 SELECT q.radicado,
    q.nombre_tipo AS tipo,
    e.nombre_estamento AS junta,
    q.asunto,
        CASE
            WHEN q.anonima THEN 'ANÓNIMA'::character varying
            ELSE q.nombre_peticionario
        END AS peticionario,
    q.fecha_recepcion AS recibida,
    q.fecha_limite,
    q.estado,
        CASE
            WHEN (((q.estado)::text = ANY (ARRAY[('RADICADA'::character varying)::text, ('EN_TRAMITE'::character varying)::text])) AND (q.hoy <= q.fecha_limite)) THEN q.restantes
            ELSE NULL::integer
        END AS dias_habiles_restantes,
        CASE
            WHEN ((q.estado)::text = ANY (ARRAY[('RADICADA'::character varying)::text, ('EN_TRAMITE'::character varying)::text])) THEN (LEAST((100)::numeric, GREATEST((0)::numeric, round(((100.0 * ((q.plazo_vigente -
            CASE
                WHEN (q.hoy > q.fecha_limite) THEN 0
                ELSE q.restantes
            END))::numeric) / (q.plazo_vigente)::numeric)))))::integer
            ELSE NULL::integer
        END AS porcentaje_consumido,
        CASE
            WHEN ((q.estado)::text = 'ARCHIVADA_ANONIMA'::text) THEN 'ARCHIVADA: ANÓNIMA, NO SE TRAMITA'::text
            WHEN (((q.estado)::text = 'DESISTIDA'::text) AND (q.fecha_recurso IS NOT NULL) AND (q.decision_recurso IS NULL)
                  AND (gobernanza.fn_dias_habiles_entre(((q.fecha_recurso AT TIME ZONE gestion_documental.fn_zona()))::date, q.hoy) > (gestion_documental.fn_parametro_pqrsd('DIAS_DECIDIR_RECURSO'::text))::integer))
                 THEN 'ALERTA CRÍTICA: EL RECURSO DE REPOSICIÓN SUPERÓ EL PLAZO PARA DECIDIRLO'::text
            WHEN (((q.estado)::text = 'DESISTIDA'::text) AND (q.fecha_recurso IS NOT NULL) AND (q.decision_recurso IS NULL)) THEN 'ALERTA ALTA: RECURSO DE REPOSICIÓN PENDIENTE DE DECIDIR'::text
            WHEN (((q.estado)::text = 'DESISTIDA'::text) AND ((q.tipo_requerimiento)::text = 'ACLARAR'::text)) THEN 'CERRADA: ARCHIVADA POR FALTA DE ACLARACIÓN'::text
            WHEN ((q.estado)::text = 'DESISTIDA'::text) THEN 'CERRADA: DESISTIMIENTO TÁCITO'::text
            WHEN ((q.estado)::text = 'TRASLADADA'::text) THEN (('CERRADA: TRASLADADA A '::text || upper((q.entidad_traslado)::text)) ||
            CASE
                WHEN q.traslado_tardio THEN ' (FUERA DEL PLAZO DE TRASLADO)'::text
                ELSE ''::text
            END)
            WHEN (((q.estado)::text = 'RESPONDIDA'::text) AND (((q.fecha_respuesta AT TIME ZONE gestion_documental.fn_zona()))::date > q.fecha_limite)) THEN 'RESPONDIDA FUERA DE TÉRMINO'::text
            WHEN ((q.estado)::text = 'RESPONDIDA'::text) THEN 'RESPONDIDA A TIEMPO'::text
            WHEN (((q.estado)::text = 'EN_REQUERIMIENTO'::text) AND (q.hoy > q.fecha_limite_completar)) THEN
            CASE
                WHEN ((q.tipo_requerimiento)::text = 'ACLARAR'::text) THEN 'ALERTA ALTA: VENCIÓ EL PLAZO PARA ACLARAR, ARCHIVE LA PETICIÓN'::text
                ELSE 'ALERTA ALTA: VENCIÓ EL PLAZO PARA COMPLETAR, DECLARE EL DESISTIMIENTO'::text
            END
            WHEN ((q.estado)::text = 'EN_REQUERIMIENTO'::text) THEN ((
            CASE
                WHEN ((q.tipo_requerimiento)::text = 'ACLARAR'::text) THEN 'SUSPENDIDA: ESPERANDO QUE EL PETICIONARIO ACLARE (HASTA EL '::text
                ELSE 'SUSPENDIDA: ESPERANDO QUE EL PETICIONARIO COMPLETE (HASTA EL '::text
            END || to_char((q.fecha_limite_completar)::timestamp with time zone, 'DD/MM/YYYY'::text)) || ')'::text)
            WHEN ((q.hoy > q.fecha_limite) AND q.silencio_positivo) THEN ('ALERTA CRÍTICA: VENCIDA, SE ENTIENDE ACEPTADA; ENTREGUE LOS DOCUMENTOS A MÁS TARDAR EL '::text || to_char((gobernanza.fn_sumar_dias_habiles(q.fecha_limite, (gestion_documental.fn_parametro_pqrsd('DIAS_ENTREGA_SILENCIO'::text))::integer))::timestamp with time zone, 'DD/MM/YYYY'::text))
            WHEN (q.hoy > q.fecha_limite) THEN 'ALERTA CRÍTICA: PLAZO VENCIDO SIN RESPUESTA'::text
            WHEN (q.hoy = q.fecha_limite) THEN 'ALERTA CRÍTICA: VENCE HOY'::text
            WHEN (q.revision_juridica AND (q.concepto_juridico IS NULL) AND (((q.plazo_vigente - q.restantes))::numeric >= (((q.plazo_vigente)::numeric * gestion_documental.fn_parametro_pqrsd('ALERTA_MEDIA_PCT'::text)) / (100)::numeric))) THEN 'ALERTA ALTA: DENUNCIA SIN CONCEPTO JURÍDICO Y MÁS DE LA MITAD DEL PLAZO CONSUMIDO'::text
            WHEN (((q.plazo_vigente - q.restantes))::numeric >= (((q.plazo_vigente)::numeric * gestion_documental.fn_parametro_pqrsd('ALERTA_ALTA_PCT'::text)) / (100)::numeric)) THEN 'ALERTA ALTA: SE HA CONSUMIDO EL 80 % DEL PLAZO'::text
            WHEN (((q.plazo_vigente - q.restantes))::numeric >= (((q.plazo_vigente)::numeric * gestion_documental.fn_parametro_pqrsd('ALERTA_MEDIA_PCT'::text)) / (100)::numeric)) THEN 'ALERTA MEDIA: SE HA CONSUMIDO LA MITAD DEL PLAZO'::text
            WHEN (q.revision_juridica AND (q.concepto_juridico IS NULL)) THEN 'EN TÉRMINO: PENDIENTE EL CONCEPTO JURÍDICO'::text
            ELSE 'EN TÉRMINO'::text
        END AS diagnostico,
        CASE
            WHEN (((q.estado)::text = 'DESISTIDA'::text) AND (q.fecha_recurso IS NOT NULL) AND (q.decision_recurso IS NULL)) THEN 'ALTA'::text
            WHEN (((q.estado)::text = 'EN_REQUERIMIENTO'::text) AND (q.hoy > q.fecha_limite_completar)) THEN 'COMPLETAR_VENCIDO'::text
            WHEN (((q.estado)::text = ANY (ARRAY[('RADICADA'::character varying)::text, ('EN_TRAMITE'::character varying)::text])) AND (q.hoy > q.fecha_limite)) THEN 'VENCIDA'::text
            WHEN (((q.estado)::text = ANY (ARRAY[('RADICADA'::character varying)::text, ('EN_TRAMITE'::character varying)::text])) AND (q.hoy = q.fecha_limite)) THEN 'VENCE_HOY'::text
            WHEN (((q.estado)::text = ANY (ARRAY[('RADICADA'::character varying)::text, ('EN_TRAMITE'::character varying)::text])) AND (((q.plazo_vigente - q.restantes))::numeric >= (((q.plazo_vigente)::numeric * gestion_documental.fn_parametro_pqrsd('ALERTA_ALTA_PCT'::text)) / (100)::numeric))) THEN 'ALTA'::text
            WHEN (((q.estado)::text = ANY (ARRAY[('RADICADA'::character varying)::text, ('EN_TRAMITE'::character varying)::text])) AND (((q.plazo_vigente - q.restantes))::numeric >= (((q.plazo_vigente)::numeric * gestion_documental.fn_parametro_pqrsd('ALERTA_MEDIA_PCT'::text)) / (100)::numeric))) THEN 'MEDIA'::text
            ELSE NULL::text
        END AS nivel_alerta,
    (q.dias_prorroga > 0) AS prorrogada,
    q.traslado_tardio,
    (q.revision_juridica AND (q.concepto_juridico IS NULL)) AS falta_concepto,
    q.id_pqrsd,
    q.id_estamento,
    q.tipo AS codigo_tipo
   FROM (q
     JOIN gobernanza.estamento e ON ((e.id_estamento = q.id_estamento)));

-- ----------------------------------------------------------------------------
-- 5. PERMISOS
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        GRANT SELECT, INSERT, UPDATE ON gobernanza.texto_institucional TO sgs_app;
        GRANT SELECT ON gestion_documental.v_auditoria_pqrsd TO sgs_app;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_lectura') THEN
        GRANT SELECT ON gobernanza.texto_institucional TO sgs_lectura;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_notificador') THEN
        GRANT SELECT ON gestion_documental.v_auditoria_pqrsd TO sgs_notificador;
    END IF;
END $$;
-- Solo el administrador o la Presidencia Nacional crean y editan los textos (la publicación ya lo exige)
DO $$ BEGIN PERFORM seguridad.fn_aplicar_politicas('gobernanza.texto_institucional',
    'TRUE', 'seguridad.fn_es_admin() OR seguridad.fn_es_presidente_nacional()'); END $$;
