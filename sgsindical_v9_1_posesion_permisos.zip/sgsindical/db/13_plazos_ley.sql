-- ============================================================================
-- SGSINDICAL v9.1 · 13_plazos_ley.sql
-- Plazos de ley: el sistema aplica los términos que fijan las leyes y no deja
-- configurarlos por encima (o, en los del peticionario, distintos) de la ley.
--
--   Ley 1755 de 2015 (derecho de petición; art. 32 la extiende a organizaciones privadas)
--     art. 14  15 / 10 / 30 días; silencio positivo en documentos (entrega en 3 días); prórroga hasta el doble
--     art. 17  pedir completar en 10 días; 1 mes para completar + 1 mes si lo pide; desistimiento
--              motivado y notificado, contra el que procede el recurso de reposición
--     art. 19  petición que no se entiende: se devuelve para que se aclare dentro de 10 días; si no, se archiva
--     art. 21  traslado por competencia dentro de 5 días
--   Ley 1437 de 2011 (CPACA) art. 76: el recurso de reposición se presenta dentro de los 10 días siguientes
--   Ley 1581 de 2012 (datos personales)
--     art. 14  consulta: 10 días hábiles, prórroga de hasta 5
--     art. 15  reclamo: 15 días hábiles, prórroga de hasta 8; reclamo incompleto: requerir en 5 días,
--              desistimiento a los 2 meses; traslado en 2 días hábiles; leyenda «reclamo en trámite»
--              en no más de 2 días hábiles
--
-- Lo que no fija la ley (corte de las 5 p. m., alertas, registro tardío, plazos de estatutos) sigue
-- siendo configurable. No modifica los scripts anteriores. Se puede ejecutar más de una vez.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. TABLA DE PLAZOS LEGALES Y CONTROL DE LOS PARÁMETROS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.plazo_legal (
    codigo VARCHAR(40) PRIMARY KEY,
    ambito VARCHAR(16) NOT NULL CHECK (ambito IN ('TIPO_PQRSD', 'PARAMETRO_PQRSD', 'PRIVACIDAD')),
    descripcion TEXT NOT NULL,
    minimo NUMERIC NOT NULL,
    maximo NUMERIC NOT NULL,
    valor_ley NUMERIC NOT NULL,
    unidad VARCHAR(20) NOT NULL,
    norma TEXT NOT NULL,
    CHECK (minimo <= valor_ley AND valor_ley <= maximo)
);
-- Inmutable salvo para este script (se quita el candado mientras carga y se vuelve a poner al final de la sección)
DROP TRIGGER IF EXISTS trg_solo_sistema ON gobernanza.plazo_legal;
COMMENT ON TABLE gobernanza.plazo_legal IS
    'Plazos fijados por la ley. Los del sindicato pueden ser más cortos (mínimo) pero nunca más largos (máximo); los del peticionario son exactamente los de la ley.';

INSERT INTO gobernanza.plazo_legal (codigo, ambito, descripcion, minimo, maximo, valor_ley, unidad, norma) VALUES
    ('PETICION',    'TIPO_PQRSD', 'Responder una petición', 1, 15, 15, 'días hábiles', 'Ley 1755 de 2015, art. 14'),
    ('QUEJA',       'TIPO_PQRSD', 'Responder una queja', 1, 15, 15, 'días hábiles', 'Ley 1755 de 2015, arts. 13 y 14'),
    ('RECLAMO',     'TIPO_PQRSD', 'Responder un reclamo', 1, 15, 15, 'días hábiles', 'Ley 1755 de 2015, arts. 13 y 14'),
    ('SUGERENCIA',  'TIPO_PQRSD', 'Responder una sugerencia', 1, 15, 15, 'días hábiles', 'Ley 1755 de 2015, art. 14'),
    ('DENUNCIA',    'TIPO_PQRSD', 'Responder una denuncia', 1, 15, 15, 'días hábiles', 'Ley 1755 de 2015, art. 14'),
    ('CONSULTA',    'TIPO_PQRSD', 'Responder una consulta', 1, 30, 30, 'días hábiles', 'Ley 1755 de 2015, art. 14, num. 2'),
    ('DOCUMENTOS',  'TIPO_PQRSD', 'Responder una solicitud de documentos o información', 1, 10, 10, 'días hábiles', 'Ley 1755 de 2015, art. 14, num. 1'),
    ('DIAS_PEDIR_COMPLETAR',     'PARAMETRO_PQRSD', 'Pedir al peticionario que complete la solicitud', 1, 10, 10, 'días hábiles', 'Ley 1755 de 2015, art. 17'),
    ('MESES_COMPLETAR',          'PARAMETRO_PQRSD', 'Plazo del peticionario para completar', 1, 1, 1, 'mes', 'Ley 1755 de 2015, art. 17'),
    ('MESES_PRORROGA_COMPLETAR', 'PARAMETRO_PQRSD', 'Ampliación del plazo para completar, si la pide', 1, 1, 1, 'mes', 'Ley 1755 de 2015, art. 17 («hasta por un término igual»)'),
    ('DIAS_TRASLADO',            'PARAMETRO_PQRSD', 'Trasladar por falta de competencia', 1, 5, 5, 'días hábiles', 'Ley 1755 de 2015, art. 21'),
    ('DIAS_ENTREGA_SILENCIO',    'PARAMETRO_PQRSD', 'Entregar los documentos cuando la solicitud se entiende aceptada', 1, 3, 3, 'días hábiles', 'Ley 1755 de 2015, art. 14, num. 1'),
    ('DIAS_ACLARAR',             'PARAMETRO_PQRSD', 'Plazo del peticionario para aclarar una petición que no se entiende', 10, 10, 10, 'días hábiles', 'Ley 1755 de 2015, art. 19'),
    ('DIAS_RECURSO_REPOSICION',  'PARAMETRO_PQRSD', 'Presentar el recurso de reposición contra el desistimiento', 10, 10, 10, 'días hábiles', 'Ley 1755 de 2015, art. 17; Ley 1437 de 2011, art. 76'),
    ('DIAS_CONSULTA_TITULAR',    'PRIVACIDAD', 'Responder una consulta del titular', 1, 10, 10, 'días hábiles', 'Ley 1581 de 2012, art. 14'),
    ('DIAS_PRORROGA_CONSULTA',   'PRIVACIDAD', 'Prórroga de una consulta del titular', 1, 5, 5, 'días hábiles', 'Ley 1581 de 2012, art. 14'),
    ('DIAS_RECLAMO_TITULAR',     'PRIVACIDAD', 'Responder un reclamo del titular', 1, 15, 15, 'días hábiles', 'Ley 1581 de 2012, art. 15, num. 3'),
    ('DIAS_PRORROGA_RECLAMO',    'PRIVACIDAD', 'Prórroga de un reclamo del titular', 1, 8, 8, 'días hábiles', 'Ley 1581 de 2012, art. 15, num. 3'),
    ('DIAS_REQUERIR_RECLAMO',    'PRIVACIDAD', 'Requerir al titular que subsane un reclamo incompleto', 1, 5, 5, 'días hábiles', 'Ley 1581 de 2012, art. 15, num. 1'),
    ('MESES_DESISTIMIENTO_RECLAMO', 'PRIVACIDAD', 'Desistimiento del reclamo si el titular no lo completa', 2, 2, 2, 'meses', 'Ley 1581 de 2012, art. 15, num. 1'),
    ('DIAS_TRASLADO_RECLAMO',    'PRIVACIDAD', 'Trasladar el reclamo a quien sea competente', 1, 2, 2, 'días hábiles', 'Ley 1581 de 2012, art. 15, num. 1'),
    ('DIAS_LEYENDA_RECLAMO',     'PRIVACIDAD', 'Incluir la leyenda «reclamo en trámite» en la base de datos', 0, 2, 2, 'días hábiles', 'Ley 1581 de 2012, art. 15, num. 2')
ON CONFLICT (codigo) DO NOTHING;

-- Parámetros nuevos
INSERT INTO gestion_documental.parametro_pqrsd (codigo, valor, descripcion) VALUES
    ('DIAS_ACLARAR', 10, 'Días hábiles que tiene el peticionario para aclarar una petición que no se entiende (art. 19).'),
    ('DIAS_RECURSO_REPOSICION', 10, 'Días hábiles para presentar el recurso de reposición contra el desistimiento (art. 17; CPACA art. 76).')
ON CONFLICT (codigo) DO NOTHING;

DO $$
BEGIN
    -- La tabla de parámetros de privacidad solo la toca el administrador; la instalación corre como dueño.
    INSERT INTO seguridad.parametro_privacidad (codigo, valor, descripcion) VALUES
        ('DIAS_REQUERIR_RECLAMO', 5, 'Días hábiles para requerir al titular que subsane un reclamo incompleto (Ley 1581, art. 15).'),
        ('MESES_DESISTIMIENTO_RECLAMO', 2, 'Meses desde el requerimiento tras los cuales se entiende que el titular desistió del reclamo (art. 15).'),
        ('DIAS_TRASLADO_RECLAMO', 2, 'Días hábiles para trasladar un reclamo a quien sea competente (art. 15).'),
        ('DIAS_LEYENDA_RECLAMO', 2, 'Días hábiles para incluir la leyenda «reclamo en trámite» (art. 15). El sistema la muestra al instante.')
    ON CONFLICT (codigo) DO NOTHING;
END $$;

-- Ajustar a la ley lo que una instalación anterior tuviera por fuera (solo si lo hubiera)
DO $$
DECLARE r RECORD;
BEGIN
    PERFORM set_config('pqrsd.operacion', 'instalar', true);
    FOR r IN SELECT * FROM gobernanza.plazo_legal LOOP
        IF r.ambito = 'TIPO_PQRSD' THEN
            UPDATE gestion_documental.tipo_pqrsd SET dias_habiles = r.maximo WHERE codigo = r.codigo AND dias_habiles > r.maximo;
        ELSIF r.ambito = 'PARAMETRO_PQRSD' THEN
            UPDATE gestion_documental.parametro_pqrsd SET valor = r.valor_ley
             WHERE codigo = r.codigo AND (valor < r.minimo OR valor > r.maximo);
        ELSE
            UPDATE seguridad.parametro_privacidad SET valor = r.valor_ley
             WHERE codigo = r.codigo AND (valor < r.minimo OR valor > r.maximo);
        END IF;
    END LOOP;
END $$;

CREATE OR REPLACE FUNCTION gobernanza.fn_validar_plazo_legal()
RETURNS TRIGGER AS $$
DECLARE v gobernanza.plazo_legal%ROWTYPE; v_valor NUMERIC;
BEGIN
    SELECT * INTO v FROM gobernanza.plazo_legal WHERE codigo = NEW.codigo AND ambito = TG_ARGV[0];
    IF v.codigo IS NULL THEN RETURN NEW; END IF;
    v_valor := CASE WHEN TG_ARGV[0] = 'TIPO_PQRSD' THEN to_jsonb(NEW) ->> 'dias_habiles' ELSE to_jsonb(NEW) ->> 'valor' END;
    IF v.minimo = v.maximo AND v_valor <> v.valor_ley THEN
        RAISE EXCEPTION '«%»: es un plazo del peticionario y la ley lo fija en % % (%); no se cambia.', v.descripcion, v.valor_ley, v.unidad, v.norma;
    END IF;
    IF v_valor > v.maximo THEN
        RAISE EXCEPTION '«%»: la ley fija % % (%); el sindicato puede fijar un plazo más corto, pero no uno más largo.',
            v.descripcion, v.maximo, v.unidad, v.norma;
    END IF;
    IF v_valor < v.minimo THEN
        RAISE EXCEPTION '«%»: el valor mínimo es % %.', v.descripcion, v.minimo, v.unidad;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_plazo_legal ON gestion_documental.tipo_pqrsd;
CREATE TRIGGER trg_plazo_legal BEFORE INSERT OR UPDATE ON gestion_documental.tipo_pqrsd
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_validar_plazo_legal('TIPO_PQRSD');
DROP TRIGGER IF EXISTS trg_plazo_legal ON gestion_documental.parametro_pqrsd;
CREATE TRIGGER trg_plazo_legal BEFORE INSERT OR UPDATE ON gestion_documental.parametro_pqrsd
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_validar_plazo_legal('PARAMETRO_PQRSD');
DROP TRIGGER IF EXISTS trg_plazo_legal ON seguridad.parametro_privacidad;
CREATE TRIGGER trg_plazo_legal BEFORE INSERT OR UPDATE ON seguridad.parametro_privacidad
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_validar_plazo_legal('PRIVACIDAD');

DROP TRIGGER IF EXISTS trg_no_borrar ON gobernanza.plazo_legal;
CREATE TRIGGER trg_no_borrar BEFORE DELETE ON gobernanza.plazo_legal FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado();
CREATE TRIGGER trg_solo_sistema BEFORE INSERT OR UPDATE ON gobernanza.plazo_legal
    FOR EACH STATEMENT EXECUTE FUNCTION auditoria.fn_bloquear_modificacion();
-- La tabla la cargó este script antes del disparador; una ley nueva se refleja con un script nuevo.

-- ----------------------------------------------------------------------------
-- 2. PQRSD: ACLARACIÓN (art. 19) Y RECURSO DE REPOSICIÓN (art. 17)
-- ----------------------------------------------------------------------------
ALTER TABLE gestion_documental.pqrsd
    ADD COLUMN IF NOT EXISTS tipo_requerimiento VARCHAR(10) CHECK (tipo_requerimiento IN ('COMPLETAR', 'ACLARAR')),
    ADD COLUMN IF NOT EXISTS fecha_recurso TIMESTAMP WITH TIME ZONE,
    ADD COLUMN IF NOT EXISTS texto_recurso TEXT,
    ADD COLUMN IF NOT EXISTS decision_recurso VARCHAR(8) CHECK (decision_recurso IN ('CONFIRMA', 'REVOCA')),
    ADD COLUMN IF NOT EXISTS motivo_decision_recurso TEXT,
    ADD COLUMN IF NOT EXISTS fecha_decision_recurso TIMESTAMP WITH TIME ZONE,
    ADD COLUMN IF NOT EXISTS usuario_decision_recurso VARCHAR(50);
COMMENT ON COLUMN gestion_documental.pqrsd.tipo_requerimiento IS
    'COMPLETAR: faltan datos o documentos (art. 17). ACLARAR: no se entiende el objeto de la petición (art. 19).';

DO $$
BEGIN
    PERFORM set_config('pqrsd.operacion', 'instalar', true);
    UPDATE gestion_documental.pqrsd SET tipo_requerimiento = 'COMPLETAR'
     WHERE fecha_requerimiento IS NOT NULL AND tipo_requerimiento IS NULL;
END $$;

ALTER TABLE gestion_documental.pqrsd_actuacion DROP CONSTRAINT IF EXISTS pqrsd_actuacion_tipo_check;
ALTER TABLE gestion_documental.pqrsd_actuacion ADD CONSTRAINT pqrsd_actuacion_tipo_check CHECK (tipo IN (
    'RADICACION', 'ARCHIVO_ANONIMA', 'EN_TRAMITE', 'PRORROGA', 'REQUERIMIENTO', 'PRORROGA_COMPLETAR', 'COMPLETADA',
    'DESISTIMIENTO', 'TRASLADO_INTERNO', 'TRASLADO_EXTERNO', 'CONCEPTO_JURIDICO', 'RESPUESTA', 'CORREO_ENVIADO',
    'CORREO_NO_ENVIADO', 'NOTA', 'ACLARACION', 'RECURSO', 'DECISION_RECURSO'));

-- Las columnas nuevas solo las escriben las acciones (al radicar quedan vacías)
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_campos_ley()
RETURNS TRIGGER AS $$
BEGIN
    IF gestion_documental.fn_pqrsd_operacion_interna() THEN RETURN NEW; END IF;
    IF TG_OP = 'INSERT' THEN
        NEW.tipo_requerimiento := NULL; NEW.fecha_recurso := NULL; NEW.texto_recurso := NULL; NEW.decision_recurso := NULL;
        NEW.motivo_decision_recurso := NULL; NEW.fecha_decision_recurso := NULL; NEW.usuario_decision_recurso := NULL;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_pqrsd_campos_ley ON gestion_documental.pqrsd;
CREATE TRIGGER trg_pqrsd_campos_ley BEFORE INSERT ON gestion_documental.pqrsd
    FOR EACH ROW EXECUTE FUNCTION gestion_documental.fn_pqrsd_campos_ley();

-- Pedir completar (art. 17): igual que antes, ahora marca el tipo de requerimiento
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_pedir_completar(p_id BIGINT, p_texto TEXT)
RETURNS DATE AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE; v_hoy DATE := gestion_documental.fn_hoy(); v_hasta DATE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    PERFORM gestion_documental.fn_pqrsd_exigir_autorizado(v.id_estamento, 'El requerimiento para completar lo hacen');
    IF length(trim(COALESCE(p_texto, ''))) < 20 THEN RAISE EXCEPTION 'Explique qué información o documentos faltan (mínimo 20 caracteres).'; END IF;
    IF v.estado = 'EN_REQUERIMIENTO' OR v.fecha_requerimiento IS NOT NULL THEN
        RAISE EXCEPTION 'Ya se le hizo un requerimiento al peticionario en esta solicitud.';
    END IF;
    IF gobernanza.fn_dias_habiles_entre(v.fecha_base, v_hoy) > gestion_documental.fn_parametro_pqrsd('DIAS_PEDIR_COMPLETAR') THEN
        RAISE EXCEPTION 'Pasaron más de % días hábiles desde la radicación: ya no se puede pedir completar (Ley 1755, art. 17); hay que resolver con lo que hay.',
            gestion_documental.fn_parametro_pqrsd('DIAS_PEDIR_COMPLETAR');
    END IF;
    v_hasta := v_hoy + make_interval(months => gestion_documental.fn_parametro_pqrsd('MESES_COMPLETAR')::INT);
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', 'requerir');
    UPDATE gestion_documental.pqrsd SET estado = 'EN_REQUERIMIENTO', tipo_requerimiento = 'COMPLETAR', texto_requerimiento = trim(p_texto),
           fecha_requerimiento = v_hoy,
           dias_restantes_suspension = GREATEST(gobernanza.fn_dias_habiles_entre(GREATEST(v_hoy, v.fecha_base), v.fecha_limite), 1),
           fecha_limite_completar = v_hasta WHERE id_pqrsd = p_id;
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', '');
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'REQUERIMIENTO',
        format('Se pidió completar la solicitud; el plazo para responder queda suspendido. Tiene hasta el %s. Falta: %s',
               to_char(v_hasta, 'DD/MM/YYYY'), trim(p_texto)));
    RETURN v_hasta;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Petición que no se entiende (art. 19): se devuelve para que se aclare dentro de 10 días hábiles;
-- al aclararse el plazo para responder empieza de nuevo; si no se aclara, se archiva.
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_pedir_aclaracion(p_id BIGINT, p_texto TEXT)
RETURNS DATE AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE; v_hoy DATE := gestion_documental.fn_hoy(); v_hasta DATE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    PERFORM gestion_documental.fn_pqrsd_exigir_autorizado(v.id_estamento, 'La solicitud de aclaración la hacen');
    IF length(trim(COALESCE(p_texto, ''))) < 20 THEN RAISE EXCEPTION 'Explique qué no se entiende de la petición (mínimo 20 caracteres).'; END IF;
    IF v.estado = 'EN_REQUERIMIENTO' OR v.fecha_requerimiento IS NOT NULL THEN
        RAISE EXCEPTION 'Ya se le hizo un requerimiento al peticionario en esta solicitud.';
    END IF;
    IF v.dias_prorroga > 0 THEN RAISE EXCEPTION 'La PQRSD ya fue prorrogada: la aclaración se pide antes, cuando se recibe.'; END IF;
    v_hasta := gobernanza.fn_sumar_dias_habiles(v_hoy, gestion_documental.fn_parametro_pqrsd('DIAS_ACLARAR')::INT);
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', 'requerir');
    UPDATE gestion_documental.pqrsd SET estado = 'EN_REQUERIMIENTO', tipo_requerimiento = 'ACLARAR', texto_requerimiento = trim(p_texto),
           fecha_requerimiento = v_hoy, dias_restantes_suspension = plazo_dias, fecha_limite_completar = v_hasta
     WHERE id_pqrsd = p_id;
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', '');
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'ACLARACION',
        format('No se comprende el objeto de la petición: se devolvió para que la aclare a más tardar el %s (Ley 1755, art. 19). '
               || 'Al aclararla, el plazo para responder empieza de nuevo. Qué debe aclarar: %s', to_char(v_hasta, 'DD/MM/YYYY'), trim(p_texto)));
    RETURN v_hasta;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Ampliar el plazo para completar: solo en el requerimiento del art. 17
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_prorrogar_completar(p_id BIGINT, p_motivo TEXT)
RETURNS DATE AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE; v_hasta DATE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    PERFORM gestion_documental.fn_pqrsd_exigir_autorizado(v.id_estamento, 'La ampliación del plazo para completar la conceden');
    IF v.estado <> 'EN_REQUERIMIENTO' THEN RAISE EXCEPTION 'La PQRSD no está esperando que el peticionario la complete.'; END IF;
    IF v.tipo_requerimiento = 'ACLARAR' THEN
        RAISE EXCEPTION 'El plazo de 10 días hábiles para aclarar una petición no se amplía (Ley 1755, art. 19).';
    END IF;
    IF v.prorroga_completar THEN RAISE EXCEPTION 'El plazo para completar ya se amplió una vez (la ley permite solo una).'; END IF;
    IF gestion_documental.fn_hoy() > v.fecha_limite_completar THEN
        RAISE EXCEPTION 'El plazo para completar venció el %: la ampliación se pide antes.', to_char(v.fecha_limite_completar, 'DD/MM/YYYY');
    END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Anote cómo y cuándo lo pidió el peticionario (mínimo 10 caracteres).'; END IF;
    v_hasta := v.fecha_limite_completar + make_interval(months => gestion_documental.fn_parametro_pqrsd('MESES_PRORROGA_COMPLETAR')::INT);
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', 'prorrogar_completar');
    UPDATE gestion_documental.pqrsd SET prorroga_completar = TRUE, fecha_limite_completar = v_hasta WHERE id_pqrsd = p_id;
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', '');
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'PRORROGA_COMPLETAR',
        format('El peticionario pidió más tiempo; tiene hasta el %s. %s', to_char(v_hasta, 'DD/MM/YYYY'), trim(p_motivo)));
    RETURN v_hasta;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Llegó la información o la aclaración
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_completada(p_id BIGINT, p_detalle TEXT, p_momento TIMESTAMPTZ DEFAULT NULL)
RETURNS DATE AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE; v_momento TIMESTAMPTZ := COALESCE(p_momento, now()); v_nueva DATE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    IF NOT (gestion_documental.fn_pqrsd_autorizado(v.id_estamento) OR seguridad.fn_rol_actual() = 'VENTANILLA') THEN
        RAISE EXCEPTION 'Registran la información recibida la Ventanilla y los cuatro cargos de la junta.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF v.estado <> 'EN_REQUERIMIENTO' THEN RAISE EXCEPTION 'La PQRSD no está esperando que el peticionario la complete o aclare.'; END IF;
    IF v_momento > now() + INTERVAL '10 minutes' OR (v_momento AT TIME ZONE gestion_documental.fn_zona())::DATE < v.fecha_requerimiento THEN
        RAISE EXCEPTION 'La fecha de recibo de la información no es válida.';
    END IF;
    IF (v_momento AT TIME ZONE gestion_documental.fn_zona())::DATE > v.fecha_limite_completar THEN
        RAISE EXCEPTION 'La información llegó después del plazo (%): corresponde % ; el peticionario puede presentarla de nuevo.',
            to_char(v.fecha_limite_completar, 'DD/MM/YYYY'),
            CASE WHEN v.tipo_requerimiento = 'ACLARAR' THEN 'archivar la petición' ELSE 'declarar el desistimiento' END;
    END IF;
    IF length(trim(COALESCE(p_detalle, ''))) < 10 THEN RAISE EXCEPTION 'Describa qué aportó el peticionario (mínimo 10 caracteres).'; END IF;
    v_nueva := gobernanza.fn_sumar_dias_habiles(gobernanza.fn_dia_base_radicacion(v_momento), v.dias_restantes_suspension);
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', 'completar');
    UPDATE gestion_documental.pqrsd SET estado = 'EN_TRAMITE', fecha_completada = v_momento, fecha_limite = v_nueva WHERE id_pqrsd = p_id;
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', '');
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'COMPLETADA',
        CASE WHEN v.tipo_requerimiento = 'ACLARAR' THEN
            format('El peticionario aclaró la petición. El plazo de %s día(s) hábil(es) empieza de nuevo: nueva fecha límite %s. %s',
                   v.dias_restantes_suspension, to_char(v_nueva, 'DD/MM/YYYY'), trim(p_detalle))
        ELSE
            format('El peticionario completó la solicitud. El plazo se reanuda con %s día(s) hábil(es): nueva fecha límite %s. %s',
                   v.dias_restantes_suspension, to_char(v_nueva, 'DD/MM/YYYY'), trim(p_detalle)) END);
    RETURN v_nueva;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Desistimiento (art. 17) o archivo por falta de aclaración (art. 19)
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_desistimiento(p_id BIGINT, p_motivo TEXT)
RETURNS VOID AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar(p_id);
    PERFORM gestion_documental.fn_pqrsd_exigir_autorizado(v.id_estamento, 'El desistimiento o el archivo lo declaran');
    IF v.estado <> 'EN_REQUERIMIENTO' THEN RAISE EXCEPTION 'Solo se declara el desistimiento de una solicitud que se pidió completar o aclarar.'; END IF;
    IF gestion_documental.fn_hoy() <= v.fecha_limite_completar THEN
        RAISE EXCEPTION 'El peticionario todavía tiene plazo (hasta el %).', to_char(v.fecha_limite_completar, 'DD/MM/YYYY');
    END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 15 THEN RAISE EXCEPTION 'Escriba la decisión motivada (mínimo 15 caracteres).'; END IF;
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', 'desistir');
    UPDATE gestion_documental.pqrsd SET estado = 'DESISTIDA', fecha_cierre = now(), observacion_cierre = trim(p_motivo),
           usuario_respuesta = auditoria.fn_usuario_actual(), cargo_firma = gestion_documental.fn_pqrsd_cargo_firmante(v.id_estamento)
     WHERE id_pqrsd = p_id;
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', '');
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'DESISTIMIENTO',
        CASE WHEN v.tipo_requerimiento = 'ACLARAR' THEN
            'Archivo por falta de aclaración (Ley 1755, art. 19): el peticionario no aclaró la petición a tiempo. Puede presentarla de nuevo. ' || trim(p_motivo)
        ELSE
            format('Desistimiento tácito (Ley 1755, art. 17): el peticionario no completó la solicitud a tiempo. Puede presentarla de nuevo. '
                   || 'Contra esta decisión procede el recurso de reposición, dentro de los %s días hábiles siguientes. %s',
                   gestion_documental.fn_parametro_pqrsd('DIAS_RECURSO_REPOSICION'), trim(p_motivo)) END);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Fecha hasta la cual se puede presentar el recurso contra un desistimiento (NULL si no aplica)
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_limite_recurso(p_id BIGINT)
RETURNS DATE AS $$
    SELECT CASE WHEN p.estado = 'DESISTIDA' AND p.tipo_requerimiento = 'COMPLETAR' THEN
                gobernanza.fn_sumar_dias_habiles((p.fecha_cierre AT TIME ZONE gestion_documental.fn_zona())::DATE,
                                                 gestion_documental.fn_parametro_pqrsd('DIAS_RECURSO_REPOSICION')::INT) END
      FROM gestion_documental.pqrsd p WHERE p.id_pqrsd = p_id;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Carga una PQRSD desistida y visible (para el recurso)
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_cargar_desistida(p_id BIGINT)
RETURNS gestion_documental.pqrsd AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE;
BEGIN
    SELECT * INTO v FROM gestion_documental.pqrsd WHERE id_pqrsd = p_id FOR UPDATE;
    IF v.id_pqrsd IS NULL OR NOT (seguridad.fn_ambito_nacional() OR v.id_estamento = ANY(seguridad.fn_ambito_estamentos())) THEN
        RAISE EXCEPTION 'La PQRSD no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v.estado <> 'DESISTIDA' OR v.tipo_requerimiento IS DISTINCT FROM 'COMPLETAR' THEN
        RAISE EXCEPTION 'El recurso de reposición procede solo contra el desistimiento tácito (Ley 1755, art. 17).';
    END IF;
    RETURN v;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- El peticionario presenta el recurso de reposición contra el desistimiento
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_recurso(p_id BIGINT, p_texto TEXT, p_momento TIMESTAMPTZ DEFAULT NULL)
RETURNS VOID AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE; v_momento TIMESTAMPTZ := COALESCE(p_momento, now()); v_limite DATE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar_desistida(p_id);
    IF NOT (gestion_documental.fn_pqrsd_autorizado(v.id_estamento) OR seguridad.fn_rol_actual() = 'VENTANILLA') THEN
        RAISE EXCEPTION 'Registran el recurso la Ventanilla y los cuatro cargos de la junta.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF v.fecha_recurso IS NOT NULL THEN RAISE EXCEPTION 'Ya se registró un recurso contra este desistimiento.'; END IF;
    IF v_momento > now() + INTERVAL '10 minutes' OR v_momento < v.fecha_cierre THEN RAISE EXCEPTION 'La fecha de recibo del recurso no es válida.'; END IF;
    v_limite := gestion_documental.fn_pqrsd_limite_recurso(p_id);
    IF (v_momento AT TIME ZONE gestion_documental.fn_zona())::DATE > v_limite THEN
        RAISE EXCEPTION 'El recurso llegó fuera de término: se podía presentar hasta el % (% días hábiles). El peticionario puede presentar de nuevo su solicitud.',
            to_char(v_limite, 'DD/MM/YYYY'), gestion_documental.fn_parametro_pqrsd('DIAS_RECURSO_REPOSICION');
    END IF;
    IF length(trim(COALESCE(p_texto, ''))) < 15 THEN RAISE EXCEPTION 'Copie o resuma los argumentos del recurso (mínimo 15 caracteres).'; END IF;
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', 'recurso');
    UPDATE gestion_documental.pqrsd SET fecha_recurso = v_momento, texto_recurso = trim(p_texto) WHERE id_pqrsd = p_id;
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', '');
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'RECURSO', 'Recurso de reposición contra el desistimiento: ' || trim(p_texto));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Decidir el recurso: CONFIRMA (sigue archivada) o REVOCA (el trámite sigue con los días que quedaban)
CREATE OR REPLACE FUNCTION gestion_documental.fn_pqrsd_decidir_recurso(p_id BIGINT, p_revoca BOOLEAN, p_motivo TEXT)
RETURNS DATE AS $$
DECLARE v gestion_documental.pqrsd%ROWTYPE; v_nueva DATE;
BEGIN
    v := gestion_documental.fn_pqrsd_cargar_desistida(p_id);
    PERFORM gestion_documental.fn_pqrsd_exigir_autorizado(v.id_estamento, 'El recurso lo deciden');
    IF v.fecha_recurso IS NULL THEN RAISE EXCEPTION 'No hay un recurso registrado.'; END IF;
    IF v.decision_recurso IS NOT NULL THEN RAISE EXCEPTION 'El recurso ya fue decidido.'; END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 15 THEN RAISE EXCEPTION 'Escriba la decisión motivada del recurso (mínimo 15 caracteres).'; END IF;
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', 'decidir_recurso');
    IF COALESCE(p_revoca, FALSE) THEN
        v_nueva := gobernanza.fn_sumar_dias_habiles(gobernanza.fn_dia_base_radicacion(now()), GREATEST(COALESCE(v.dias_restantes_suspension, 1), 1));
        UPDATE gestion_documental.pqrsd SET decision_recurso = 'REVOCA', motivo_decision_recurso = trim(p_motivo), fecha_decision_recurso = now(),
               usuario_decision_recurso = auditoria.fn_usuario_actual(), estado = 'EN_TRAMITE', fecha_limite = v_nueva,
               fecha_cierre = NULL, observacion_cierre = NULL, usuario_respuesta = NULL, cargo_firma = NULL
         WHERE id_pqrsd = p_id;
    ELSE
        UPDATE gestion_documental.pqrsd SET decision_recurso = 'CONFIRMA', motivo_decision_recurso = trim(p_motivo), fecha_decision_recurso = now(),
               usuario_decision_recurso = auditoria.fn_usuario_actual()
         WHERE id_pqrsd = p_id;
    END IF;
    PERFORM seguridad.fn_fijar_operacion('pqrsd.operacion', '');
    PERFORM gestion_documental.fn_pqrsd_anotar(p_id, 'DECISION_RECURSO',
        CASE WHEN COALESCE(p_revoca, FALSE)
             THEN format('Se revoca el desistimiento. El trámite sigue con %s día(s) hábil(es): nueva fecha límite %s. %s',
                         GREATEST(COALESCE(v.dias_restantes_suspension, 1), 1), to_char(v_nueva, 'DD/MM/YYYY'), trim(p_motivo))
             ELSE 'Se confirma el desistimiento. ' || trim(p_motivo) END);
    RETURN v_nueva;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 3. SOLICITUDES DEL TITULAR (Ley 1581, art. 15): RECLAMO INCOMPLETO, DESISTIMIENTO, TRASLADO Y LEYENDA
-- ----------------------------------------------------------------------------
ALTER TABLE gobernanza.solicitud_titular
    ADD COLUMN IF NOT EXISTS texto_requerimiento TEXT,
    ADD COLUMN IF NOT EXISTS fecha_requerimiento DATE,
    ADD COLUMN IF NOT EXISTS fecha_limite_completar DATE,
    ADD COLUMN IF NOT EXISTS fecha_completada TIMESTAMP WITH TIME ZONE,
    ADD COLUMN IF NOT EXISTS entidad_traslado VARCHAR(200),
    ADD COLUMN IF NOT EXISTS traslado_tardio BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS fecha_cierre TIMESTAMP WITH TIME ZONE,
    ADD COLUMN IF NOT EXISTS observacion_cierre TEXT;

-- Estados nuevos: REQUERIDA (esperando que el titular complete el reclamo), DESISTIDA y TRASLADADA
ALTER TABLE gobernanza.solicitud_titular DROP CONSTRAINT IF EXISTS solicitud_titular_estado_check;
ALTER TABLE gobernanza.solicitud_titular ADD CONSTRAINT solicitud_titular_estado_check
    CHECK (estado IN ('RADICADA', 'EN_TRAMITE', 'REQUERIDA', 'RESPONDIDA', 'DESISTIDA', 'TRASLADADA'));

CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_solicitud_titular()
RETURNS TRIGGER AS $$
DECLARE v_dias INT;
BEGIN
    IF COALESCE(seguridad.fn_operacion('privacidad.operacion'), '') IN
       ('prorrogar', 'responder', 'anonimizar', 'requerir', 'completar', 'desistir', 'trasladar') THEN RETURN NEW; END IF;
    IF TG_OP = 'INSERT' THEN
        NEW.fecha_radicacion := COALESCE(NEW.fecha_radicacion, now());
        IF NEW.fecha_radicacion > now() + INTERVAL '1 hour' THEN RAISE EXCEPTION 'La fecha de radicación no puede ser futura.'; END IF;
        NEW.radicado := 'SOL-' || to_char(NEW.fecha_radicacion AT TIME ZONE gestion_documental.fn_zona(), 'YYYY') || '-'
                        || lpad(nextval('gobernanza.seq_solicitud_titular')::TEXT, 5, '0');
        v_dias := CASE WHEN NEW.tipo = 'CONSULTA' THEN seguridad.fn_parametro_privacidad('DIAS_CONSULTA_TITULAR')
                       ELSE seguridad.fn_parametro_privacidad('DIAS_RECLAMO_TITULAR') END;
        NEW.fecha_base := gobernanza.fn_dia_base_radicacion(NEW.fecha_radicacion);
        NEW.fecha_limite := gobernanza.fn_sumar_dias_habiles(NEW.fecha_base, v_dias);
        NEW.prorrogada := FALSE; NEW.motivo_prorroga := NULL;
        NEW.estado := 'RADICADA'; NEW.respuesta := NULL; NEW.fecha_respuesta := NULL; NEW.usuario_respuesta := NULL;
        NEW.texto_requerimiento := NULL; NEW.fecha_requerimiento := NULL; NEW.fecha_limite_completar := NULL; NEW.fecha_completada := NULL;
        NEW.entidad_traslado := NULL; NEW.traslado_tardio := FALSE; NEW.fecha_cierre := NULL; NEW.observacion_cierre := NULL;
        RETURN NEW;
    END IF;
    IF OLD.estado IN ('RESPONDIDA', 'DESISTIDA', 'TRASLADADA') THEN
        RAISE EXCEPTION 'Una solicitud cerrada (%) no se modifica.', lower(OLD.estado);
    END IF;
    IF NEW.radicado IS DISTINCT FROM OLD.radicado OR NEW.fecha_radicacion IS DISTINCT FROM OLD.fecha_radicacion
       OR NEW.fecha_base IS DISTINCT FROM OLD.fecha_base OR NEW.fecha_limite IS DISTINCT FROM OLD.fecha_limite
       OR NEW.tipo IS DISTINCT FROM OLD.tipo OR NEW.id_persona IS DISTINCT FROM OLD.id_persona
       OR NEW.prorrogada IS DISTINCT FROM OLD.prorrogada OR NEW.respuesta IS DISTINCT FROM OLD.respuesta
       OR NEW.fecha_respuesta IS DISTINCT FROM OLD.fecha_respuesta
       OR NEW.texto_requerimiento IS DISTINCT FROM OLD.texto_requerimiento OR NEW.fecha_requerimiento IS DISTINCT FROM OLD.fecha_requerimiento
       OR NEW.fecha_limite_completar IS DISTINCT FROM OLD.fecha_limite_completar OR NEW.fecha_completada IS DISTINCT FROM OLD.fecha_completada
       OR NEW.entidad_traslado IS DISTINCT FROM OLD.entidad_traslado OR NEW.traslado_tardio IS DISTINCT FROM OLD.traslado_tardio
       OR NEW.fecha_cierre IS DISTINCT FROM OLD.fecha_cierre OR NEW.observacion_cierre IS DISTINCT FROM OLD.observacion_cierre THEN
        RAISE EXCEPTION 'El radicado, el tipo, las fechas y la respuesta los registra el sistema (use las acciones de la solicitud).';
    END IF;
    IF OLD.estado = 'REQUERIDA' AND NEW.estado IS DISTINCT FROM OLD.estado THEN
        RAISE EXCEPTION 'La solicitud espera que el titular complete el reclamo: registre lo recibido o declare el desistimiento.';
    END IF;
    IF NEW.estado NOT IN ('RADICADA', 'EN_TRAMITE', 'REQUERIDA') THEN RAISE EXCEPTION 'La solicitud se cierra con sus acciones (responder, desistimiento o traslado).'; END IF;
    IF NEW.estado = 'REQUERIDA' AND OLD.estado <> 'REQUERIDA' THEN RAISE EXCEPTION 'El requerimiento se hace con la acción Pedir completar.'; END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Carga una solicitud abierta y visible, bloqueándola
CREATE OR REPLACE FUNCTION gobernanza.fn_cargar_solicitud_titular(p_id BIGINT)
RETURNS gobernanza.solicitud_titular AS $$
DECLARE v gobernanza.solicitud_titular%ROWTYPE;
BEGIN
    SELECT * INTO v FROM gobernanza.solicitud_titular WHERE id_solicitud = p_id FOR UPDATE;
    IF v.id_solicitud IS NULL
       OR NOT seguridad.fn_persona_visible(v.id_persona, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos()) THEN
        RAISE EXCEPTION 'La solicitud no existe o está fuera de su ámbito territorial.';
    END IF;
    IF v.estado IN ('RESPONDIDA', 'DESISTIDA', 'TRASLADADA') THEN
        RAISE EXCEPTION 'La solicitud % ya está cerrada (%).', v.radicado, lower(v.estado);
    END IF;
    RETURN v;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Prórroga: no mientras el titular debe completar el reclamo
CREATE OR REPLACE FUNCTION gobernanza.fn_prorrogar_solicitud_titular(p_id BIGINT, p_motivo TEXT)
RETURNS DATE AS $$
DECLARE v_s gobernanza.solicitud_titular%ROWTYPE; v_nueva DATE;
BEGIN
    IF length(trim(COALESCE(p_motivo, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo de la prórroga (mínimo 10 caracteres).'; END IF;
    v_s := gobernanza.fn_cargar_solicitud_titular(p_id);
    IF v_s.estado = 'REQUERIDA' THEN RAISE EXCEPTION 'El plazo no corre mientras el titular completa el reclamo.'; END IF;
    IF v_s.prorrogada THEN RAISE EXCEPTION 'La solicitud ya fue prorrogada una vez (la ley no permite más).'; END IF;
    IF (now() AT TIME ZONE gestion_documental.fn_zona())::DATE > v_s.fecha_limite THEN
        RAISE EXCEPTION 'El plazo ya venció: la prórroga se informa al titular antes del vencimiento.';
    END IF;
    v_nueva := gobernanza.fn_sumar_dias_habiles(v_s.fecha_limite,
        CASE WHEN v_s.tipo = 'CONSULTA' THEN seguridad.fn_parametro_privacidad('DIAS_PRORROGA_CONSULTA')
             ELSE seguridad.fn_parametro_privacidad('DIAS_PRORROGA_RECLAMO') END::INT);
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', 'prorrogar');
    UPDATE gobernanza.solicitud_titular SET prorrogada = TRUE, motivo_prorroga = trim(p_motivo), fecha_limite = v_nueva,
           estado = 'EN_TRAMITE'
     WHERE id_solicitud = p_id;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', '');
    RETURN v_nueva;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Responder: solo con la solicitud completa
CREATE OR REPLACE FUNCTION gobernanza.fn_responder_solicitud_titular(p_id BIGINT, p_respuesta TEXT, p_id_documento BIGINT DEFAULT NULL)
RETURNS VOID AS $$
DECLARE v_s gobernanza.solicitud_titular%ROWTYPE;
BEGIN
    IF length(trim(COALESCE(p_respuesta, ''))) < 20 THEN RAISE EXCEPTION 'Escriba la respuesta dada al titular (mínimo 20 caracteres).'; END IF;
    v_s := gobernanza.fn_cargar_solicitud_titular(p_id);
    IF v_s.estado = 'REQUERIDA' THEN
        RAISE EXCEPTION 'El reclamo está incompleto y se le pidió al titular completarlo: registre lo recibido o declare el desistimiento.';
    END IF;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', 'responder');
    UPDATE gobernanza.solicitud_titular SET estado = 'RESPONDIDA', respuesta = trim(p_respuesta), fecha_respuesta = now(),
           usuario_respuesta = auditoria.fn_usuario_actual(), id_documento_respuesta = COALESCE(p_id_documento, id_documento_respuesta)
     WHERE id_solicitud = p_id;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', '');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Reclamo incompleto: se requiere al titular dentro de los 5 días siguientes al recibo; el plazo queda suspendido
CREATE OR REPLACE FUNCTION gobernanza.fn_requerir_solicitud_titular(p_id BIGINT, p_texto TEXT)
RETURNS DATE AS $$
DECLARE v gobernanza.solicitud_titular%ROWTYPE; v_hoy DATE := (now() AT TIME ZONE gestion_documental.fn_zona())::DATE; v_hasta DATE;
        v_max INT := seguridad.fn_parametro_privacidad('DIAS_REQUERIR_RECLAMO')::INT;
BEGIN
    v := gobernanza.fn_cargar_solicitud_titular(p_id);
    IF v.tipo = 'CONSULTA' THEN RAISE EXCEPTION 'El requerimiento para subsanar aplica a los reclamos, no a las consultas (Ley 1581, art. 15).'; END IF;
    IF v.estado = 'REQUERIDA' OR v.fecha_requerimiento IS NOT NULL THEN RAISE EXCEPTION 'Ya se le pidió al titular completar este reclamo.'; END IF;
    IF v.prorrogada THEN RAISE EXCEPTION 'El reclamo ya fue prorrogado: el requerimiento se hace al recibirlo.'; END IF;
    IF length(trim(COALESCE(p_texto, ''))) < 20 THEN RAISE EXCEPTION 'Explique qué falta para resolver el reclamo (mínimo 20 caracteres).'; END IF;
    IF gobernanza.fn_dias_habiles_entre(v.fecha_base, v_hoy) > v_max THEN
        RAISE EXCEPTION 'Pasaron más de % días hábiles desde el recibo: ya no se puede requerir al titular (Ley 1581, art. 15); resuelva con lo que hay.', v_max;
    END IF;
    v_hasta := v_hoy + make_interval(months => seguridad.fn_parametro_privacidad('MESES_DESISTIMIENTO_RECLAMO')::INT);
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', 'requerir');
    UPDATE gobernanza.solicitud_titular SET estado = 'REQUERIDA', texto_requerimiento = trim(p_texto), fecha_requerimiento = v_hoy,
           fecha_limite_completar = v_hasta WHERE id_solicitud = p_id;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', '');
    RETURN v_hasta;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- El titular completó el reclamo: los 15 días hábiles cuentan desde el día siguiente al recibo del reclamo completo
CREATE OR REPLACE FUNCTION gobernanza.fn_completar_solicitud_titular(p_id BIGINT, p_detalle TEXT, p_momento TIMESTAMPTZ DEFAULT NULL)
RETURNS DATE AS $$
DECLARE v gobernanza.solicitud_titular%ROWTYPE; v_momento TIMESTAMPTZ := COALESCE(p_momento, now()); v_base DATE; v_nueva DATE;
BEGIN
    v := gobernanza.fn_cargar_solicitud_titular(p_id);
    IF v.estado <> 'REQUERIDA' THEN RAISE EXCEPTION 'La solicitud no está esperando que el titular complete el reclamo.'; END IF;
    IF v_momento > now() + INTERVAL '10 minutes' OR (v_momento AT TIME ZONE gestion_documental.fn_zona())::DATE < v.fecha_requerimiento THEN
        RAISE EXCEPTION 'La fecha de recibo de la información no es válida.';
    END IF;
    IF (v_momento AT TIME ZONE gestion_documental.fn_zona())::DATE > v.fecha_limite_completar THEN
        RAISE EXCEPTION 'La información llegó después de los % meses (%): se entiende que el titular desistió; puede presentar un reclamo nuevo.',
            seguridad.fn_parametro_privacidad('MESES_DESISTIMIENTO_RECLAMO'), to_char(v.fecha_limite_completar, 'DD/MM/YYYY');
    END IF;
    IF length(trim(COALESCE(p_detalle, ''))) < 10 THEN RAISE EXCEPTION 'Describa qué aportó el titular (mínimo 10 caracteres).'; END IF;
    v_base := gobernanza.fn_dia_base_radicacion(v_momento);
    v_nueva := gobernanza.fn_sumar_dias_habiles(v_base, seguridad.fn_parametro_privacidad('DIAS_RECLAMO_TITULAR')::INT);
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', 'completar');
    UPDATE gobernanza.solicitud_titular SET estado = 'EN_TRAMITE', fecha_completada = v_momento, fecha_base = v_base, fecha_limite = v_nueva,
           observacion_cierre = NULL
     WHERE id_solicitud = p_id;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', '');
    RETURN v_nueva;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Desistimiento: pasaron 2 meses desde el requerimiento sin que el titular completara
CREATE OR REPLACE FUNCTION gobernanza.fn_desistir_solicitud_titular(p_id BIGINT, p_motivo TEXT)
RETURNS VOID AS $$
DECLARE v gobernanza.solicitud_titular%ROWTYPE;
BEGIN
    v := gobernanza.fn_cargar_solicitud_titular(p_id);
    IF v.estado <> 'REQUERIDA' THEN RAISE EXCEPTION 'Solo desiste un reclamo que se le pidió completar al titular.'; END IF;
    IF (now() AT TIME ZONE gestion_documental.fn_zona())::DATE <= v.fecha_limite_completar THEN
        RAISE EXCEPTION 'El titular todavía tiene plazo para completar (hasta el %).', to_char(v.fecha_limite_completar, 'DD/MM/YYYY');
    END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 15 THEN RAISE EXCEPTION 'Escriba la decisión (mínimo 15 caracteres).'; END IF;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', 'desistir');
    UPDATE gobernanza.solicitud_titular SET estado = 'DESISTIDA', fecha_cierre = now(), observacion_cierre = trim(p_motivo),
           usuario_respuesta = auditoria.fn_usuario_actual()
     WHERE id_solicitud = p_id;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', '');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Traslado a quien sea competente (otro responsable del tratamiento) en máximo 2 días hábiles, informando al titular
CREATE OR REPLACE FUNCTION gobernanza.fn_trasladar_solicitud_titular(p_id BIGINT, p_entidad TEXT, p_motivo TEXT)
RETURNS BOOLEAN AS $$
DECLARE v gobernanza.solicitud_titular%ROWTYPE; v_usados INT; v_tardio BOOLEAN;
BEGIN
    v := gobernanza.fn_cargar_solicitud_titular(p_id);
    IF v.estado = 'REQUERIDA' THEN RAISE EXCEPTION 'Primero resuelva el requerimiento al titular.'; END IF;
    IF length(trim(COALESCE(p_entidad, ''))) < 3 THEN RAISE EXCEPTION 'Indique a quién se traslada (la entidad responsable de esos datos).'; END IF;
    IF length(trim(COALESCE(p_motivo, ''))) < 15 THEN RAISE EXCEPTION 'Explique por qué el sindicato no es competente (mínimo 15 caracteres).'; END IF;
    v_usados := gobernanza.fn_dias_habiles_entre(v.fecha_base, (now() AT TIME ZONE gestion_documental.fn_zona())::DATE);
    v_tardio := v_usados > seguridad.fn_parametro_privacidad('DIAS_TRASLADO_RECLAMO');
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', 'trasladar');
    UPDATE gobernanza.solicitud_titular SET estado = 'TRASLADADA', entidad_traslado = trim(p_entidad), traslado_tardio = v_tardio,
           fecha_cierre = now(), observacion_cierre = trim(p_motivo), usuario_respuesta = auditoria.fn_usuario_actual()
     WHERE id_solicitud = p_id;
    PERFORM seguridad.fn_fijar_operacion('privacidad.operacion', '');
    RETURN v_tardio;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Leyenda «reclamo en trámite» (art. 15, num. 2): aparece en cuanto el reclamo está completo y hasta que se decide
CREATE OR REPLACE VIEW gobernanza.v_leyenda_reclamo WITH (security_invoker = true) AS
SELECT s.id_persona, s.id_solicitud, s.radicado, s.tipo,
       'Reclamo en trámite' AS leyenda,
       s.descripcion AS motivo,
       COALESCE(s.fecha_completada, s.fecha_radicacion) AS desde,
       s.fecha_limite
  FROM gobernanza.solicitud_titular s
 WHERE s.tipo <> 'CONSULTA' AND s.estado IN ('RADICADA', 'EN_TRAMITE');
COMMENT ON VIEW gobernanza.v_leyenda_reclamo IS
    'Ley 1581, art. 15, num. 2: leyenda «reclamo en trámite» y su motivo sobre los datos del titular mientras el reclamo completo no se decide.';

CREATE OR REPLACE FUNCTION gobernanza.fn_leyenda_reclamo(p_id_persona BIGINT)
RETURNS TABLE (radicado TEXT, tipo TEXT, motivo TEXT, desde TIMESTAMPTZ, fecha_limite DATE) AS $$
    SELECT l.radicado::TEXT, l.tipo::TEXT, l.motivo, l.desde, l.fecha_limite
      FROM gobernanza.v_leyenda_reclamo l WHERE l.id_persona = p_id_persona ORDER BY l.desde;
$$ LANGUAGE sql STABLE;

-- ----------------------------------------------------------------------------
-- 4. VISTAS Y FUNCIONES QUE CONOCEN LOS ESTADOS NUEVOS
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW gestion_documental.v_auditoria_pqrsd WITH (security_invoker = true) AS
 WITH q AS (
         SELECT p.id_pqrsd,
            p.radicado,
            p.tipo,
            p.id_estamento,
            p.anonima,
            p.nombre_peticionario,
            p.tipo_documento,
            p.numero_documento,
            p.correo_peticionario,
            p.telefono_peticionario,
            p.id_persona,
            p.asunto,
            p.descripcion,
            p.medio,
            p.fecha_recepcion,
            p.motivo_registro_tardio,
            p.id_documento_soporte,
            p.fecha_base,
            p.plazo_dias,
            p.dias_prorroga,
            p.fecha_limite,
            p.motivo_prorroga,
            p.fecha_prorroga,
            p.texto_requerimiento,
            p.fecha_requerimiento,
            p.dias_restantes_suspension,
            p.fecha_limite_completar,
            p.prorroga_completar,
            p.fecha_completada,
            p.id_estamento_origen,
            p.entidad_traslado,
            p.traslado_tardio,
            p.concepto_juridico,
            p.fecha_concepto,
            p.usuario_concepto,
            p.estado,
            p.respuesta,
            p.fecha_respuesta,
            p.usuario_respuesta,
            p.cargo_firma,
            p.huella_respuesta,
            p.id_documento_respuesta,
            p.fecha_cierre,
            p.observacion_cierre,
            p.fecha_creacion,
            p.usuario_creacion,
            p.version,
            p.tipo_requerimiento,
            p.fecha_recurso,
            p.decision_recurso,
            gestion_documental.fn_hoy() AS hoy,
            t.nombre AS nombre_tipo,
            t.silencio_positivo,
            t.revision_juridica,
            GREATEST((p.plazo_dias + p.dias_prorroga), 1) AS plazo_vigente,
                CASE
                    WHEN ((p.estado)::text = ANY ((ARRAY['RADICADA'::character varying, 'EN_TRAMITE'::character varying])::text[])) THEN gobernanza.fn_dias_habiles_entre(GREATEST(gestion_documental.fn_hoy(), p.fecha_base), p.fecha_limite)
                    ELSE NULL::integer
                END AS restantes
           FROM (gestion_documental.pqrsd p
             JOIN gestion_documental.tipo_pqrsd t ON (((t.codigo)::text = (p.tipo)::text)))
        )
 SELECT q.radicado,
    q.nombre_tipo AS tipo,
    e.nombre_estamento AS junta,
    q.asunto,
        CASE
            WHEN q.anonima THEN 'ANÓNIMA'::character varying
            ELSE q.nombre_peticionario
        END AS peticionario,
    q.fecha_recepcion AS recibida,
    q.fecha_limite,
    q.estado,
        CASE
            WHEN (((q.estado)::text = ANY ((ARRAY['RADICADA'::character varying, 'EN_TRAMITE'::character varying])::text[])) AND (q.hoy <= q.fecha_limite)) THEN q.restantes
            ELSE NULL::integer
        END AS dias_habiles_restantes,
        CASE
            WHEN ((q.estado)::text = ANY ((ARRAY['RADICADA'::character varying, 'EN_TRAMITE'::character varying])::text[])) THEN (LEAST((100)::numeric, GREATEST((0)::numeric, round(((100.0 * ((q.plazo_vigente -
            CASE
                WHEN (q.hoy > q.fecha_limite) THEN 0
                ELSE q.restantes
            END))::numeric) / (q.plazo_vigente)::numeric)))))::integer
            ELSE NULL::integer
        END AS porcentaje_consumido,
        CASE
            WHEN ((q.estado)::text = 'ARCHIVADA_ANONIMA'::text) THEN 'ARCHIVADA: ANÓNIMA, NO SE TRAMITA'::text
            WHEN (((q.estado)::text = 'DESISTIDA'::text) AND (q.fecha_recurso IS NOT NULL) AND (q.decision_recurso IS NULL)) THEN 'ALERTA ALTA: RECURSO DE REPOSICIÓN PENDIENTE DE DECIDIR'::text
            WHEN (((q.estado)::text = 'DESISTIDA'::text) AND ((q.tipo_requerimiento)::text = 'ACLARAR'::text)) THEN 'CERRADA: ARCHIVADA POR FALTA DE ACLARACIÓN'::text
            WHEN ((q.estado)::text = 'DESISTIDA'::text) THEN 'CERRADA: DESISTIMIENTO TÁCITO'::text
            WHEN ((q.estado)::text = 'TRASLADADA'::text) THEN (('CERRADA: TRASLADADA A '::text || upper((q.entidad_traslado)::text)) ||
            CASE
                WHEN q.traslado_tardio THEN ' (FUERA DEL PLAZO DE TRASLADO)'::text
                ELSE ''::text
            END)
            WHEN (((q.estado)::text = 'RESPONDIDA'::text) AND (((q.fecha_respuesta AT TIME ZONE gestion_documental.fn_zona()))::date > q.fecha_limite)) THEN 'RESPONDIDA FUERA DE TÉRMINO'::text
            WHEN ((q.estado)::text = 'RESPONDIDA'::text) THEN 'RESPONDIDA A TIEMPO'::text
            WHEN (((q.estado)::text = 'EN_REQUERIMIENTO'::text) AND (q.hoy > q.fecha_limite_completar)) THEN CASE WHEN ((q.tipo_requerimiento)::text = 'ACLARAR'::text) THEN 'ALERTA ALTA: VENCIÓ EL PLAZO PARA ACLARAR, ARCHIVE LA PETICIÓN'::text ELSE 'ALERTA ALTA: VENCIÓ EL PLAZO PARA COMPLETAR, DECLARE EL DESISTIMIENTO'::text END
            WHEN ((q.estado)::text = 'EN_REQUERIMIENTO'::text) THEN (((CASE WHEN ((q.tipo_requerimiento)::text = 'ACLARAR'::text) THEN 'SUSPENDIDA: ESPERANDO QUE EL PETICIONARIO ACLARE (HASTA EL '::text ELSE 'SUSPENDIDA: ESPERANDO QUE EL PETICIONARIO COMPLETE (HASTA EL '::text END) || to_char((q.fecha_limite_completar)::timestamp with time zone, 'DD/MM/YYYY'::text)) || ')'::text)
            WHEN ((q.hoy > q.fecha_limite) AND q.silencio_positivo) THEN ('ALERTA CRÍTICA: VENCIDA, SE ENTIENDE ACEPTADA; ENTREGUE LOS DOCUMENTOS A MÁS TARDAR EL '::text || to_char((gobernanza.fn_sumar_dias_habiles(q.fecha_limite, (gestion_documental.fn_parametro_pqrsd('DIAS_ENTREGA_SILENCIO'::text))::integer))::timestamp with time zone, 'DD/MM/YYYY'::text))
            WHEN (q.hoy > q.fecha_limite) THEN 'ALERTA CRÍTICA: PLAZO VENCIDO SIN RESPUESTA'::text
            WHEN (q.hoy = q.fecha_limite) THEN 'ALERTA CRÍTICA: VENCE HOY'::text
            WHEN (q.revision_juridica AND (q.concepto_juridico IS NULL) AND (((q.plazo_vigente - q.restantes))::numeric >= (((q.plazo_vigente)::numeric * gestion_documental.fn_parametro_pqrsd('ALERTA_MEDIA_PCT'::text)) / (100)::numeric))) THEN 'ALERTA ALTA: DENUNCIA SIN CONCEPTO JURÍDICO Y MÁS DE LA MITAD DEL PLAZO CONSUMIDO'::text
            WHEN (((q.plazo_vigente - q.restantes))::numeric >= (((q.plazo_vigente)::numeric * gestion_documental.fn_parametro_pqrsd('ALERTA_ALTA_PCT'::text)) / (100)::numeric)) THEN 'ALERTA ALTA: SE HA CONSUMIDO EL 80 % DEL PLAZO'::text
            WHEN (((q.plazo_vigente - q.restantes))::numeric >= (((q.plazo_vigente)::numeric * gestion_documental.fn_parametro_pqrsd('ALERTA_MEDIA_PCT'::text)) / (100)::numeric)) THEN 'ALERTA MEDIA: SE HA CONSUMIDO LA MITAD DEL PLAZO'::text
            WHEN (q.revision_juridica AND (q.concepto_juridico IS NULL)) THEN 'EN TÉRMINO: PENDIENTE EL CONCEPTO JURÍDICO'::text
            ELSE 'EN TÉRMINO'::text
        END AS diagnostico,
        CASE
            WHEN (((q.estado)::text = 'DESISTIDA'::text) AND (q.fecha_recurso IS NOT NULL) AND (q.decision_recurso IS NULL)) THEN 'ALTA'::text
            WHEN (((q.estado)::text = 'EN_REQUERIMIENTO'::text) AND (q.hoy > q.fecha_limite_completar)) THEN 'COMPLETAR_VENCIDO'::text
            WHEN (((q.estado)::text = ANY ((ARRAY['RADICADA'::character varying, 'EN_TRAMITE'::character varying])::text[])) AND (q.hoy > q.fecha_limite)) THEN 'VENCIDA'::text
            WHEN (((q.estado)::text = ANY ((ARRAY['RADICADA'::character varying, 'EN_TRAMITE'::character varying])::text[])) AND (q.hoy = q.fecha_limite)) THEN 'VENCE_HOY'::text
            WHEN (((q.estado)::text = ANY ((ARRAY['RADICADA'::character varying, 'EN_TRAMITE'::character varying])::text[])) AND (((q.plazo_vigente - q.restantes))::numeric >= (((q.plazo_vigente)::numeric * gestion_documental.fn_parametro_pqrsd('ALERTA_ALTA_PCT'::text)) / (100)::numeric))) THEN 'ALTA'::text
            WHEN (((q.estado)::text = ANY ((ARRAY['RADICADA'::character varying, 'EN_TRAMITE'::character varying])::text[])) AND (((q.plazo_vigente - q.restantes))::numeric >= (((q.plazo_vigente)::numeric * gestion_documental.fn_parametro_pqrsd('ALERTA_MEDIA_PCT'::text)) / (100)::numeric))) THEN 'MEDIA'::text
            ELSE NULL::text
        END AS nivel_alerta,
    (q.dias_prorroga > 0) AS prorrogada,
    q.traslado_tardio,
    (q.revision_juridica AND (q.concepto_juridico IS NULL)) AS falta_concepto,
    q.id_pqrsd,
    q.id_estamento,
    q.tipo AS codigo_tipo
   FROM (q
     JOIN gobernanza.estamento e ON ((e.id_estamento = q.id_estamento)));

CREATE OR REPLACE VIEW gobernanza.v_auditoria_solicitudes_titular WITH (security_invoker = true) AS
WITH s AS (
    SELECT st.*, (now() AT TIME ZONE gestion_documental.fn_zona())::DATE AS hoy,
           GREATEST(gobernanza.fn_dias_habiles_entre(st.fecha_base, st.fecha_limite), 1) AS plazo,
           gobernanza.fn_dias_habiles_entre(st.fecha_base, LEAST((now() AT TIME ZONE gestion_documental.fn_zona())::DATE, st.fecha_limite)) AS usados
      FROM gobernanza.solicitud_titular st
)
SELECT s.radicado, s.tipo, p.primer_nombre || ' ' || p.primer_apellido AS titular, e.nombre_estamento AS junta,
       s.fecha_radicacion, s.fecha_limite, s.prorrogada, s.estado,
       CASE WHEN s.estado IN ('RADICADA', 'EN_TRAMITE') THEN gobernanza.fn_dias_habiles_entre(s.hoy, s.fecha_limite) END AS dias_habiles_restantes,
       CASE WHEN s.estado = 'RESPONDIDA' AND (s.fecha_respuesta AT TIME ZONE gestion_documental.fn_zona())::DATE > s.fecha_limite
                THEN 'RESPONDIDA FUERA DE TÉRMINO'
            WHEN s.estado = 'RESPONDIDA' THEN 'RESPONDIDA A TIEMPO'
            WHEN s.estado = 'DESISTIDA' THEN 'CERRADA: EL TITULAR DESISTIÓ (NO COMPLETÓ EL RECLAMO)'
            WHEN s.estado = 'TRASLADADA' THEN 'CERRADA: TRASLADADA A ' || upper(s.entidad_traslado)
                 || CASE WHEN s.traslado_tardio THEN ' (FUERA DE LOS 2 DÍAS HÁBILES)' ELSE '' END
            WHEN s.estado = 'REQUERIDA' AND s.hoy > s.fecha_limite_completar
                THEN 'ALERTA ALTA: PASARON LOS 2 MESES SIN QUE EL TITULAR COMPLETARA; DECLARE EL DESISTIMIENTO'
            WHEN s.estado = 'REQUERIDA'
                THEN 'SUSPENDIDA: ESPERANDO QUE EL TITULAR COMPLETE EL RECLAMO (HASTA EL ' || to_char(s.fecha_limite_completar, 'DD/MM/YYYY') || ')'
            WHEN s.hoy > s.fecha_limite THEN 'ALERTA CRÍTICA: PLAZO VENCIDO SIN RESPUESTA'
            WHEN s.usados >= s.plazo * 0.8 THEN 'ALERTA ALTA: SE HA CONSUMIDO EL 80 % DEL PLAZO'
            WHEN s.usados >= s.plazo * 0.5 THEN 'ALERTA MEDIA: SE HA CONSUMIDO LA MITAD DEL PLAZO'
            ELSE 'EN TÉRMINO' END AS diagnostico,
       s.id_solicitud, s.id_persona, a.id_estamento_pertenencia AS id_estamento,
       s.fecha_limite_completar, s.traslado_tardio,
       (s.tipo <> 'CONSULTA' AND s.estado IN ('RADICADA', 'EN_TRAMITE')) AS leyenda_reclamo_en_tramite
  FROM s
  JOIN gobernanza.persona p ON p.id_persona = s.id_persona
  LEFT JOIN gobernanza.afiliado a ON a.id_persona = s.id_persona
  LEFT JOIN gobernanza.estamento e ON e.id_estamento = a.id_estamento_pertenencia;

CREATE OR REPLACE FUNCTION seguridad.fn_mis_solicitudes()
 RETURNS TABLE(tipo text, radicado text, fecha timestamp with time zone, estado text, detalle text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE p BIGINT := seguridad.fn_exigir_mi_persona();
BEGIN
    RETURN QUERY
    SELECT 'Datos personales: ' || lower(s.tipo), s.radicado::TEXT, s.fecha_radicacion, s.estado::TEXT,
           CASE WHEN s.estado = 'RESPONDIDA' THEN s.respuesta
                WHEN s.estado = 'REQUERIDA' THEN 'Su reclamo está incompleto: ' || s.texto_requerimiento || '. Envíe lo que falta a más tardar el '
                     || to_char(s.fecha_limite_completar, 'DD/MM/YYYY') || '.'
                WHEN s.estado = 'DESISTIDA' THEN 'Archivada: ' || s.observacion_cierre
                WHEN s.estado = 'TRASLADADA' THEN 'Trasladada a ' || s.entidad_traslado || ': ' || s.observacion_cierre
                ELSE 'Fecha límite de respuesta: ' || to_char(s.fecha_limite, 'DD/MM/YYYY') END
      FROM gobernanza.solicitud_titular s WHERE s.id_persona = p
    UNION ALL
    SELECT 'Afiliación', s.radicado::TEXT, s.fecha_creacion, s.estado::TEXT, s.observacion_decision
      FROM gobernanza.solicitud_afiliacion s WHERE s.id_persona = p
    UNION ALL
    SELECT 'Exoneración del aporte', 'EXO-' || x.id_exoneracion, x.fecha_creacion, x.estado::TEXT,
           to_char(x.desde_mes, 'YYYY-MM') || ' a ' || to_char(x.hasta_mes, 'YYYY-MM') || COALESCE(' · ' || x.observacion_decision, '')
      FROM finanzas.exoneracion x WHERE x.id_persona = p
    ORDER BY 3 DESC;
END;
$function$;

CREATE OR REPLACE FUNCTION gobernanza.fn_impedimento_anonimizar(p_id_persona bigint)
 RETURNS text
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
    SELECT CASE
        WHEN NOT EXISTS (SELECT 1 FROM gobernanza.persona WHERE id_persona = p_id_persona) THEN 'La persona no existe.'
        WHEN EXISTS (SELECT 1 FROM gobernanza.persona WHERE id_persona = p_id_persona AND dni LIKE 'ANON-%') THEN 'La persona ya fue anonimizada.'
        WHEN EXISTS (SELECT 1 FROM gobernanza.persona WHERE id_persona = p_id_persona AND activo) THEN
             'Primero inactive a la persona (y antes su afiliación): solo se anonimiza a quien ya no tiene vínculo con el sindicato.'
        WHEN EXISTS (SELECT 1 FROM gobernanza.afiliado WHERE id_persona = p_id_persona AND activo) THEN 'La persona tiene una afiliación activa.'
        WHEN EXISTS (SELECT 1 FROM gobernanza.directivo_estamento WHERE id_persona = p_id_persona AND fecha_retiro IS NULL) THEN
             'La persona tiene un cargo directivo vigente.'
        WHEN EXISTS (SELECT 1 FROM seguridad.usuario WHERE id_persona = p_id_persona AND activo) THEN 'La persona tiene un usuario activo.'
        WHEN EXISTS (SELECT 1 FROM gobernanza.solicitud_titular WHERE id_persona = p_id_persona AND estado IN ('RADICADA', 'EN_TRAMITE', 'REQUERIDA')
                        AND tipo <> 'SUPRESION') THEN
             'La persona tiene solicitudes abiertas distintas de la supresión: respóndalas primero.'
        END;
$function$;


-- Vista de consulta: cada plazo de ley y el valor que tiene configurado el sistema
CREATE OR REPLACE VIEW gobernanza.v_plazos_ley WITH (security_invoker = true) AS
SELECT l.descripcion AS plazo, l.norma, l.valor_ley || ' ' || l.unidad AS segun_la_ley,
       c.valor || ' ' || l.unidad AS configurado,
       CASE WHEN c.valor IS NULL THEN 'ALERTA ALTA: EL PARÁMETRO NO EXISTE'
            WHEN c.valor = l.valor_ley THEN 'IGUAL A LA LEY'
            WHEN c.valor < l.valor_ley THEN 'MÁS CORTO QUE LA LEY (DECISIÓN DEL SINDICATO)'
            ELSE 'ALERTA CRÍTICA: SUPERA EL PLAZO DE LEY' END AS diagnostico,
       CASE l.ambito WHEN 'TIPO_PQRSD' THEN 'PQRSD: tipos y plazos' WHEN 'PARAMETRO_PQRSD' THEN 'PQRSD: parámetros'
                     ELSE 'Datos personales' END AS donde_se_configura,
       l.codigo, l.ambito
  FROM gobernanza.plazo_legal l
  LEFT JOIN LATERAL (
      SELECT CASE l.ambito
                  WHEN 'TIPO_PQRSD' THEN (SELECT t.dias_habiles::NUMERIC FROM gestion_documental.tipo_pqrsd t WHERE t.codigo = l.codigo)
                  WHEN 'PARAMETRO_PQRSD' THEN (SELECT p.valor FROM gestion_documental.parametro_pqrsd p WHERE p.codigo = l.codigo)
                  ELSE (SELECT p.valor FROM seguridad.parametro_privacidad p WHERE p.codigo = l.codigo) END AS valor) c ON TRUE;
COMMENT ON VIEW gobernanza.v_plazos_ley IS 'Plazos fijados por la ley y el valor configurado en el sistema.';

-- ----------------------------------------------------------------------------
-- 5. PERMISOS
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        GRANT SELECT ON gobernanza.plazo_legal, gobernanza.v_leyenda_reclamo, gobernanza.v_plazos_ley TO sgs_app;
        GRANT SELECT ON gobernanza.v_auditoria_solicitudes_titular, gestion_documental.v_auditoria_pqrsd TO sgs_app;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_lectura') THEN
        GRANT SELECT ON gobernanza.plazo_legal, gobernanza.v_leyenda_reclamo, gobernanza.v_plazos_ley TO sgs_lectura;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_notificador') THEN
        GRANT SELECT ON gobernanza.v_auditoria_solicitudes_titular, gestion_documental.v_auditoria_pqrsd TO sgs_notificador;
    END IF;
END $$;

DO $$
DECLARE f TEXT;
BEGIN
    -- Funciones internas: no se llaman directamente desde la aplicación
    FOREACH f IN ARRAY ARRAY['gestion_documental.fn_pqrsd_cargar_desistida(bigint)', 'gobernanza.fn_cargar_solicitud_titular(bigint)'] LOOP
        EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', f);
    END LOOP;
END $$;
