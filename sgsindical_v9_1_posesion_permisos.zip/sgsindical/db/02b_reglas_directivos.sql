-- ============================================================================
-- SGSINDICAL v9.1 — 02b: REGLAS ESTATUTARIAS DE CARGOS DIRECTIVOS
-- Ejecutar DESPUÉS de 02_seguridad_auditoria_indices.sql y ANTES de 03_roles_permisos.sql
-- ----------------------------------------------------------------------------
-- Reglas que impone la base de datos (no dependen de la aplicación):
--  R1. Solo existen los cargos del catálogo oficial y cada uno pertenece a un tipo de
--      estamento: 12 de la Junta Directiva Nacional, 12 de Subdirectiva, 2 de Comité Seccional.
--  R2. Un cargo de una junta solo puede estar ocupado por UNA persona a la vez.
--  R3. Una persona NO puede ocupar dos cargos a la vez en la misma junta.
--  R4. Máximo de cargos simultáneos por persona: 1 en la Junta Directiva Nacional
--      + 1 en una Subdirectiva o Comité Seccional (máximo 2 en total).
--  R5. El cargo en Subdirectiva o Comité solo puede ejercerse en el estamento al que
--      pertenece el afiliado. Los cargos nacionales no tienen restricción territorial.
--  R6. El registro ante MinTrabajo del directivo debe ser del mismo estamento.
--  R7. Existe una sola Junta Directiva Nacional.
-- "Vigente" = sin fecha de retiro. Al terminar un cargo se registra la fecha de retiro y el
-- registro queda como historial; el cargo queda libre para la siguiente persona.
-- R2, R3 y R4 son índices únicos: se cumplen incluso con usuarios guardando a la vez.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. CATÁLOGO OFICIAL DE CARGOS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.cargo_directivo (
    id_cargo BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    codigo VARCHAR(20) NOT NULL UNIQUE,
    nombre VARCHAR(80) NOT NULL UNIQUE,
    tipo_estamento VARCHAR(30) NOT NULL CHECK (tipo_estamento IN ('JUNTA DIRECTIVA NACIONAL', 'SUBDIRECTIVA', 'COMITÉ SECCIONAL')),
    orden INT NOT NULL DEFAULT 99,
    activo BOOLEAN NOT NULL DEFAULT TRUE
);
COMMENT ON TABLE gobernanza.cargo_directivo IS 'Catálogo estatutario de cargos por tipo de estamento.';

INSERT INTO gobernanza.cargo_directivo (codigo, nombre, tipo_estamento, orden) VALUES
    ('PRES_NAL',   'PRESIDENTE NAL',                     'JUNTA DIRECTIVA NACIONAL', 1),
    ('VICE_NAL',   'VICEPRESIDENTE NAL',                 'JUNTA DIRECTIVA NACIONAL', 2),
    ('SGEN_NAL',   'SECRETARIO GENERAL NAL',             'JUNTA DIRECTIVA NACIONAL', 3),
    ('TES_NAL',    'TESORERO NAL',                       'JUNTA DIRECTIVA NACIONAL', 4),
    ('FIS_NAL',    'FISCAL NAL',                         'JUNTA DIRECTIVA NACIONAL', 5),
    ('SJUR_NAL',   'SECRETARIO JURÍDICO NAL',            'JUNTA DIRECTIVA NACIONAL', 6),
    ('SEDU_NAL',   'SECRETARIO DE EDUCACIÓN NAL',        'JUNTA DIRECTIVA NACIONAL', 7),
    ('SCUL_NAL',   'SECRETARIO DE CULTURA NAL',          'JUNTA DIRECTIVA NACIONAL', 8),
    ('SMER_NAL',   'SECRETARIO DEL MÉRITO NAL',          'JUNTA DIRECTIVA NACIONAL', 9),
    ('SCOM_NAL',   'SECRETARIO DE COMUNICACIONES NAL',   'JUNTA DIRECTIVA NACIONAL', 10),
    ('CREC1_NAL',  'COMISIONADO DE RECLAMOS NAL 1',      'JUNTA DIRECTIVA NACIONAL', 11),
    ('CREC2_NAL',  'COMISIONADO DE RECLAMOS NAL 2',      'JUNTA DIRECTIVA NACIONAL', 12),
    ('PRES_REG',   'PRESIDENTE REG',                     'SUBDIRECTIVA', 1),
    ('VICE_REG',   'VICEPRESIDENTE REG',                 'SUBDIRECTIVA', 2),
    ('SGEN_REG',   'SECRETARIO GENERAL REG',             'SUBDIRECTIVA', 3),
    ('TES_REG',    'TESORERO REG',                       'SUBDIRECTIVA', 4),
    ('FIS_REG',    'FISCAL REG',                         'SUBDIRECTIVA', 5),
    ('SJUR_REG',   'SECRETARIO JURÍDICO REG',            'SUBDIRECTIVA', 6),
    ('SEDU_REG',   'SECRETARIO DE EDUCACIÓN REG',        'SUBDIRECTIVA', 7),
    ('SCUL_REG',   'SECRETARIO DE CULTURA REG',          'SUBDIRECTIVA', 8),
    ('SMER_REG',   'SECRETARIO DEL MÉRITO REG',          'SUBDIRECTIVA', 9),
    ('SCOM_REG',   'SECRETARIO DE COMUNICACIONES REG',   'SUBDIRECTIVA', 10),
    ('CREC1_REG',  'COMISIONADO DE RECLAMOS REG 1',      'SUBDIRECTIVA', 11),
    ('CREC2_REG',  'COMISIONADO DE RECLAMOS REG 2',      'SUBDIRECTIVA', 12),
    ('PRES_COM',   'PRESIDENTE COMITÉ',                  'COMITÉ SECCIONAL', 1),
    ('SGEN_COM',   'SECRETARIO GENERAL COMITÉ',          'COMITÉ SECCIONAL', 2)
ON CONFLICT (codigo) DO UPDATE SET nombre = EXCLUDED.nombre, tipo_estamento = EXCLUDED.tipo_estamento, orden = EXCLUDED.orden;

-- R8. Cargos que no admiten rotación (el Fiscal, órgano de control de la junta)
ALTER TABLE gobernanza.cargo_directivo ADD COLUMN IF NOT EXISTS permite_rotacion BOOLEAN NOT NULL DEFAULT TRUE;
COMMENT ON COLUMN gobernanza.cargo_directivo.permite_rotacion IS
    'FALSE = quien lo ocupa no puede rotar a otro cargo de la misma junta en el mismo periodo, ni otro directivo puede rotar hacia él.';
UPDATE gobernanza.cargo_directivo SET permite_rotacion = FALSE WHERE codigo IN ('FIS_NAL', 'FIS_REG');

-- R7. Una sola Junta Directiva Nacional
CREATE UNIQUE INDEX IF NOT EXISTS ux_estamento_unica_jdn ON gobernanza.estamento ((tipo_estamento))
    WHERE tipo_estamento = 'JUNTA DIRECTIVA NACIONAL';

-- ----------------------------------------------------------------------------
-- 2. PERTENENCIA DEL AFILIADO A SU SUBDIRECTIVA O COMITÉ
-- ----------------------------------------------------------------------------
ALTER TABLE gobernanza.afiliado
    ADD COLUMN IF NOT EXISTS id_estamento_pertenencia BIGINT REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT;
COMMENT ON COLUMN gobernanza.afiliado.id_estamento_pertenencia IS 'Subdirectiva o comité seccional al que pertenece el afiliado (define dónde puede ser directivo local).';
CREATE INDEX IF NOT EXISTS ix_afiliado_pertenencia ON gobernanza.afiliado (id_estamento_pertenencia);

-- ----------------------------------------------------------------------------
-- 3. NUEVAS COLUMNAS DEL DIRECTIVO
-- ----------------------------------------------------------------------------
ALTER TABLE gobernanza.directivo_estamento
    ADD COLUMN IF NOT EXISTS id_cargo BIGINT REFERENCES gobernanza.cargo_directivo(id_cargo) ON DELETE RESTRICT,
    ADD COLUMN IF NOT EXISTS nivel_cargo VARCHAR(10) CHECK (nivel_cargo IN ('NACIONAL', 'LOCAL')),
    ADD COLUMN IF NOT EXISTS fecha_retiro DATE,
    ADD COLUMN IF NOT EXISTS motivo_retiro TEXT;

DO $$ BEGIN
    ALTER TABLE gobernanza.directivo_estamento ADD CONSTRAINT chk_fecha_retiro
        CHECK (fecha_retiro IS NULL OR fecha_retiro >= fecha_posesion_individual);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE INDEX IF NOT EXISTS ix_directivo_cargo ON gobernanza.directivo_estamento (id_cargo);

-- Tipo de nombramiento: ELECCION y REELECCION abren un periodo nuevo; ROTACION conserva el periodo que traía.
ALTER TABLE gobernanza.directivo_estamento
    ADD COLUMN IF NOT EXISTS tipo_nombramiento VARCHAR(12) NOT NULL DEFAULT 'ELECCION'
        CHECK (tipo_nombramiento IN ('ELECCION', 'REELECCION', 'ROTACION'));

-- PERIODO INDIVIDUAL: el fin de vigencia se calcula desde el inicio del periodo de la persona,
-- no desde la posesión del cargo actual. En una rotación el periodo NO vuelve a empezar.
DO $$
DECLARE v_expr TEXT;
BEGIN
    SELECT pg_get_expr(ad.adbin, ad.adrelid) INTO v_expr
      FROM pg_attrdef ad JOIN pg_attribute a ON a.attrelid = ad.adrelid AND a.attnum = ad.adnum
     WHERE ad.adrelid = 'gobernanza.directivo_estamento'::regclass AND a.attname = 'fecha_fin_vigencia_programada';
    IF v_expr IS NULL OR v_expr NOT LIKE '%fecha_inicio_periodo%' THEN
        ALTER TABLE gobernanza.directivo_estamento ADD COLUMN IF NOT EXISTS fecha_inicio_periodo DATE;
        UPDATE gobernanza.directivo_estamento SET fecha_inicio_periodo = fecha_posesion_individual WHERE fecha_inicio_periodo IS NULL;
        DROP VIEW IF EXISTS gobernanza.v_auditoria_vigencia_directivos;
        DROP VIEW IF EXISTS gobernanza.v_composicion_juntas;
        ALTER TABLE gobernanza.directivo_estamento DROP COLUMN IF EXISTS fecha_fin_vigencia_programada;
        ALTER TABLE gobernanza.directivo_estamento ADD COLUMN fecha_fin_vigencia_programada DATE
            GENERATED ALWAYS AS ((fecha_inicio_periodo + INTERVAL '2 years')::DATE) STORED;
        ALTER TABLE gobernanza.directivo_estamento ALTER COLUMN fecha_inicio_periodo SET NOT NULL;
        CREATE INDEX IF NOT EXISTS ix_directivo_fin_vigencia ON gobernanza.directivo_estamento (fecha_fin_vigencia_programada);
    END IF;
END $$;
COMMENT ON COLUMN gobernanza.directivo_estamento.fecha_inicio_periodo IS
    'Inicio del periodo individual de 2 años. En una ROTACIÓN se hereda del cargo anterior; en ELECCIÓN o REELECCIÓN es la posesión.';
-- Bases existentes: los nombramientos que heredaron el periodo eran rotaciones
UPDATE gobernanza.directivo_estamento SET tipo_nombramiento = 'ROTACION'
 WHERE tipo_nombramiento = 'ELECCION' AND fecha_inicio_periodo < fecha_posesion_individual;

-- Bases existentes: se intenta asignar el cargo a partir del texto anterior (rol_estamento).
UPDATE gobernanza.directivo_estamento d
   SET id_cargo = c.id_cargo
  FROM gobernanza.estamento e, gobernanza.cargo_directivo c
 WHERE d.id_cargo IS NULL AND e.id_estamento = d.id_estamento
   AND c.tipo_estamento = e.tipo_estamento AND c.nombre = UPPER(TRIM(d.rol_estamento));
UPDATE gobernanza.directivo_estamento d
   SET nivel_cargo = CASE WHEN c.tipo_estamento = 'JUNTA DIRECTIVA NACIONAL' THEN 'NACIONAL' ELSE 'LOCAL' END,
       rol_estamento = c.nombre
  FROM gobernanza.cargo_directivo c
 WHERE c.id_cargo = d.id_cargo AND d.nivel_cargo IS NULL;

-- Registro vigente de un estamento = el emitido más recientemente por el inspector.
CREATE OR REPLACE FUNCTION gobernanza.fn_registro_vigente(p_id_estamento BIGINT)
RETURNS BIGINT AS $$
    SELECT id_registro FROM gobernanza.registro_inspector_estamento
     WHERE id_estamento = p_id_estamento
     ORDER BY fecha_emision_registro DESC, id_registro DESC LIMIT 1;
$$ LANGUAGE sql STABLE;

-- ----------------------------------------------------------------------------
-- 4. VALIDACIÓN CON MENSAJES CLAROS
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION gobernanza.fn_validar_directivo()
RETURNS TRIGGER AS $$
DECLARE
    v_cargo gobernanza.cargo_directivo%ROWTYPE;
    v_tipo_est VARCHAR(30);
    v_nombre_est VARCHAR(150);
    v_est_registro BIGINT;
    v_pertenencia BIGINT;
    v_nombre_pert VARCHAR(150);
    v_otro RECORD;
    v_inicio DATE;
BEGIN
    IF NEW.id_cargo IS NULL THEN
        RAISE EXCEPTION 'Debe seleccionar el cargo del catálogo oficial.';
    END IF;
    SELECT * INTO v_cargo FROM gobernanza.cargo_directivo WHERE id_cargo = NEW.id_cargo;
    SELECT tipo_estamento, nombre_estamento INTO v_tipo_est, v_nombre_est
      FROM gobernanza.estamento WHERE id_estamento = NEW.id_estamento;

    -- Ámbito territorial: se verifica antes que cualquier otra regla, para no revelar datos de otros estamentos.
    -- (Solo aplica a sesiones de la aplicación; las funciones existen tras ejecutar 02c.)
    IF current_setting('app.id_usuario', true) <> ''
       AND to_regprocedure('seguridad.fn_ambito_nacional()') IS NOT NULL
       AND NOT seguridad.fn_ambito_nacional()
       AND NOT (NEW.id_estamento = ANY(seguridad.fn_ambito_estamentos())) THEN
        RAISE EXCEPTION USING ERRCODE = '42501',
            MESSAGE = format('Fuera de su ámbito territorial: no puede nombrar ni modificar directivos de "%s".', v_nombre_est);
    END IF;

    -- Campos derivados (no los escribe el usuario)
    NEW.rol_estamento := v_cargo.nombre;
    NEW.nivel_cargo := CASE WHEN v_cargo.tipo_estamento = 'JUNTA DIRECTIVA NACIONAL' THEN 'NACIONAL' ELSE 'LOCAL' END;

    NEW.fecha_inicio_periodo := COALESCE(NEW.fecha_inicio_periodo, NEW.fecha_posesion_individual);

    -- R6. Si no se indica registro, se asocia automáticamente el registro vigente del estamento
    IF NEW.id_registro_inspector IS NULL THEN
        NEW.id_registro_inspector := gobernanza.fn_registro_vigente(NEW.id_estamento);
        IF NEW.id_registro_inspector IS NULL THEN
            RAISE EXCEPTION '"%" no tiene registro ante el inspector de trabajo. Registre primero el registro en Registros ante MinTrabajo.', v_nombre_est;
        END IF;
    END IF;

    -- Un registro que se retira no se vuelve a validar (queda como historial)
    IF NEW.fecha_retiro IS NOT NULL THEN
        RETURN NEW;
    END IF;

    -- R1. Cargo acorde al tipo de estamento
    IF v_tipo_est NOT IN ('JUNTA DIRECTIVA NACIONAL', 'SUBDIRECTIVA', 'COMITÉ SECCIONAL') THEN
        RAISE EXCEPTION 'El estamento "%" es de tipo %, que no tiene cargos directivos en los estatutos.', v_nombre_est, v_tipo_est;
    END IF;
    IF v_cargo.tipo_estamento <> v_tipo_est THEN
        RAISE EXCEPTION 'El cargo % es de %, pero "%" es de tipo %.', v_cargo.nombre, v_cargo.tipo_estamento, v_nombre_est, v_tipo_est;
    END IF;
    IF NOT v_cargo.activo THEN
        RAISE EXCEPTION 'El cargo % está inactivo en el catálogo.', v_cargo.nombre;
    END IF;

    -- R6. Un directivo vigente debe estar asociado al registro VIGENTE de su propio estamento
    SELECT id_estamento INTO v_est_registro FROM gobernanza.registro_inspector_estamento WHERE id_registro = NEW.id_registro_inspector;
    IF v_est_registro IS DISTINCT FROM NEW.id_estamento THEN
        RAISE EXCEPTION 'El registro ante MinTrabajo seleccionado pertenece a otro estamento.';
    END IF;
    IF NEW.id_registro_inspector <> gobernanza.fn_registro_vigente(NEW.id_estamento) THEN
        RAISE EXCEPTION 'El registro seleccionado no es el vigente de "%". Los directivos vigentes se asocian al registro más reciente.', v_nombre_est;
    END IF;

    -- R5. Cargo local solo en el estamento de pertenencia
    IF NEW.nivel_cargo = 'LOCAL' THEN
        SELECT a.id_estamento_pertenencia, e.nombre_estamento INTO v_pertenencia, v_nombre_pert
          FROM gobernanza.afiliado a LEFT JOIN gobernanza.estamento e ON e.id_estamento = a.id_estamento_pertenencia
         WHERE a.id_persona = NEW.id_persona;
        IF v_pertenencia IS NULL THEN
            RAISE EXCEPTION 'El afiliado no tiene registrada la subdirectiva o comité al que pertenece. Regístrelo en Afiliados antes de asignarle un cargo local.';
        END IF;
        IF v_pertenencia <> NEW.id_estamento THEN
            RAISE EXCEPTION 'El afiliado pertenece a "%" y solo puede ser directivo local allí, no en "%".', v_nombre_pert, v_nombre_est;
        END IF;
    END IF;

    -- Se serializa por persona y por cargo para dar el mensaje claro aun con usuarios simultáneos
    PERFORM pg_advisory_xact_lock(hashtext('directivo_persona_' || NEW.id_persona));
    PERFORM pg_advisory_xact_lock(hashtext('directivo_cargo_' || NEW.id_estamento || '_' || NEW.id_cargo));

    -- R2. El cargo ya está ocupado
    SELECT p.primer_nombre || ' ' || p.primer_apellido AS nombre INTO v_otro
      FROM gobernanza.directivo_estamento d JOIN gobernanza.persona p ON p.id_persona = d.id_persona
     WHERE d.id_estamento = NEW.id_estamento AND d.id_cargo = NEW.id_cargo AND d.fecha_retiro IS NULL
       AND d.id_directivo_estamento IS DISTINCT FROM NEW.id_directivo_estamento;
    IF FOUND THEN
        RAISE EXCEPTION 'El cargo % en "%" ya está ocupado por %. Registre primero su fecha de retiro.', v_cargo.nombre, v_nombre_est, v_otro.nombre;
    END IF;

    -- R3. Dos cargos en la misma junta
    SELECT d.rol_estamento INTO v_otro
      FROM gobernanza.directivo_estamento d
     WHERE d.id_persona = NEW.id_persona AND d.id_estamento = NEW.id_estamento AND d.fecha_retiro IS NULL
       AND d.id_directivo_estamento IS DISTINCT FROM NEW.id_directivo_estamento;
    IF FOUND THEN
        RAISE EXCEPTION 'Esta persona ya ocupa el cargo % en "%". No puede tener dos cargos en la misma junta.', v_otro.rol_estamento, v_nombre_est;
    END IF;

    -- R4. Máximo 1 cargo nacional + 1 local
    SELECT d.rol_estamento, e.nombre_estamento INTO v_otro
      FROM gobernanza.directivo_estamento d JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento
     WHERE d.id_persona = NEW.id_persona AND d.nivel_cargo = NEW.nivel_cargo AND d.fecha_retiro IS NULL
       AND d.id_directivo_estamento IS DISTINCT FROM NEW.id_directivo_estamento;
    IF FOUND THEN
        RAISE EXCEPTION 'Esta persona ya tiene un cargo % vigente (% en "%"). Solo puede tener 1 cargo nacional y 1 en su subdirectiva o comité.',
            LOWER(NEW.nivel_cargo), v_otro.rol_estamento, v_otro.nombre_estamento;
    END IF;

    -- R8. Rotación prohibida hacia o desde un cargo no rotable (Fiscal).
    -- Rotación = la misma persona tuvo OTRO cargo en la MISMA junta y su periodo aún no había
    -- terminado al tomar el nuevo. Una nueva elección tras vencer el periodo sí se permite.
    SELECT c.nombre, c.permite_rotacion INTO v_otro
      FROM gobernanza.directivo_estamento d JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
     WHERE d.id_persona = NEW.id_persona AND d.id_estamento = NEW.id_estamento
       AND d.fecha_retiro IS NOT NULL AND d.id_cargo <> NEW.id_cargo
       AND d.fecha_fin_vigencia_programada > NEW.fecha_posesion_individual
       AND d.id_directivo_estamento IS DISTINCT FROM NEW.id_directivo_estamento
       AND (NOT c.permite_rotacion OR NOT v_cargo.permite_rotacion)
     ORDER BY d.fecha_retiro DESC LIMIT 1;
    IF FOUND THEN
        IF NOT v_otro.permite_rotacion THEN
            RAISE EXCEPTION 'Esta persona fue % en "%" en el periodo vigente. El cargo de Fiscal no puede rotarse a otro cargo de la misma junta.',
                v_otro.nombre, v_nombre_est;
        ELSE
            RAISE EXCEPTION 'Esta persona fue % en "%" en el periodo vigente. Ningún directivo puede rotar al cargo de %.',
                v_otro.nombre, v_nombre_est, v_cargo.nombre;
        END IF;
    END IF;

    -- R9. Tipo de nombramiento y periodo individual.
    --   ELECCION / REELECCION: periodo nuevo de 2 años desde la posesión (reelección sin límite, también el Fiscal).
    --   ROTACION: conserva el inicio (y por tanto el fin) del periodo que la persona traía en esta junta.
    IF NEW.tipo_nombramiento = 'REELECCION' AND NOT EXISTS (
        SELECT 1 FROM gobernanza.directivo_estamento d
         WHERE d.id_persona = NEW.id_persona AND d.id_estamento = NEW.id_estamento AND d.id_cargo = NEW.id_cargo
           AND d.fecha_retiro IS NOT NULL AND d.id_directivo_estamento IS DISTINCT FROM NEW.id_directivo_estamento) THEN
        RAISE EXCEPTION 'Una reelección es en el mismo cargo que la persona ya ejerció: no ha sido % en "%". Registre el nombramiento como Elección.',
            v_cargo.nombre, v_nombre_est;
    END IF;
    IF NEW.tipo_nombramiento = 'ROTACION' THEN
        SELECT d.fecha_inicio_periodo INTO v_inicio
          FROM gobernanza.directivo_estamento d
         WHERE d.id_persona = NEW.id_persona AND d.id_estamento = NEW.id_estamento
           AND d.fecha_retiro IS NOT NULL AND d.id_cargo <> NEW.id_cargo
           AND d.fecha_fin_vigencia_programada > NEW.fecha_posesion_individual
           AND d.id_directivo_estamento IS DISTINCT FROM NEW.id_directivo_estamento
         ORDER BY d.fecha_retiro DESC, d.id_directivo_estamento DESC LIMIT 1;
        IF v_inicio IS NULL THEN
            RAISE EXCEPTION 'No hay un cargo de "%" con periodo vigente desde el cual rotar. Una rotación es pasar de otro cargo de la misma junta, dentro del mismo periodo.',
                v_nombre_est;
        END IF;
        NEW.fecha_inicio_periodo := v_inicio;
    ELSE
        NEW.fecha_inicio_periodo := NEW.fecha_posesion_individual;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_validar_directivo ON gobernanza.directivo_estamento;
CREATE TRIGGER trg_validar_directivo
    BEFORE INSERT OR UPDATE ON gobernanza.directivo_estamento
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_validar_directivo();

-- Un afiliado con cargo local vigente no puede cambiar de pertenencia sin retirarse antes.
CREATE OR REPLACE FUNCTION gobernanza.fn_validar_cambio_pertenencia()
RETURNS TRIGGER AS $$
DECLARE v_cargo RECORD;
BEGIN
    IF NEW.id_estamento_pertenencia IS DISTINCT FROM OLD.id_estamento_pertenencia THEN
        SELECT d.rol_estamento, e.nombre_estamento INTO v_cargo
          FROM gobernanza.directivo_estamento d JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento
         WHERE d.id_persona = NEW.id_persona AND d.nivel_cargo = 'LOCAL' AND d.fecha_retiro IS NULL;
        IF FOUND THEN
            RAISE EXCEPTION 'El afiliado es % en "%". Registre su retiro del cargo antes de cambiar su pertenencia.', v_cargo.rol_estamento, v_cargo.nombre_estamento;
        END IF;
    END IF;
    IF NEW.id_estamento_pertenencia IS NOT NULL AND EXISTS (
        SELECT 1 FROM gobernanza.estamento WHERE id_estamento = NEW.id_estamento_pertenencia
           AND tipo_estamento = 'JUNTA DIRECTIVA NACIONAL') THEN
        RAISE EXCEPTION 'La pertenencia debe ser una subdirectiva o comité seccional, no la Junta Directiva Nacional.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_validar_pertenencia ON gobernanza.afiliado;
CREATE TRIGGER trg_validar_pertenencia
    BEFORE INSERT OR UPDATE OF id_estamento_pertenencia ON gobernanza.afiliado
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_validar_cambio_pertenencia();

-- ----------------------------------------------------------------------------
-- 5. RESTRICCIONES ÚNICAS (garantía final, a prueba de concurrencia)
-- ----------------------------------------------------------------------------
CREATE UNIQUE INDEX IF NOT EXISTS ux_directivo_cargo_ocupado
    ON gobernanza.directivo_estamento (id_estamento, id_cargo) WHERE fecha_retiro IS NULL;          -- R2
CREATE UNIQUE INDEX IF NOT EXISTS ux_directivo_un_cargo_por_junta
    ON gobernanza.directivo_estamento (id_persona, id_estamento) WHERE fecha_retiro IS NULL;        -- R3
CREATE UNIQUE INDEX IF NOT EXISTS ux_directivo_un_cargo_por_nivel
    ON gobernanza.directivo_estamento (id_persona, nivel_cargo) WHERE fecha_retiro IS NULL;         -- R4

-- ----------------------------------------------------------------------------
-- 6. AUDITORÍA Y CONCURRENCIA DEL CATÁLOGO
-- ----------------------------------------------------------------------------
ALTER TABLE gobernanza.cargo_directivo ADD COLUMN IF NOT EXISTS version INT NOT NULL DEFAULT 1;
DROP TRIGGER IF EXISTS trg_control_version ON gobernanza.cargo_directivo;
CREATE TRIGGER trg_control_version BEFORE UPDATE ON gobernanza.cargo_directivo
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version();
DROP TRIGGER IF EXISTS trg_auditoria ON gobernanza.cargo_directivo;
CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON gobernanza.cargo_directivo
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria();

-- ----------------------------------------------------------------------------
-- 7. VISTAS: solo directivos vigentes + composición de cada junta
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW gobernanza.v_auditoria_vigencia_directivos AS
SELECT
    d.id_directivo_estamento,
    p.dni,
    p.primer_nombre || ' ' || p.primer_apellido AS nombre_directivo,
    e.nombre_estamento,
    d.rol_estamento,
    r.num_registro_inspector,
    d.fecha_posesion_individual,
    d.fecha_fin_vigencia_programada,
    AGE(CURRENT_DATE, d.fecha_inicio_periodo) AS tiempo_transcurrido,
    CASE WHEN CURRENT_DATE <= d.fecha_fin_vigencia_programada THEN AGE(d.fecha_fin_vigencia_programada, CURRENT_DATE) END AS tiempo_restante,
    CASE WHEN CURRENT_DATE > d.fecha_fin_vigencia_programada THEN AGE(CURRENT_DATE, d.fecha_fin_vigencia_programada) END AS tiempo_exceso,
    CASE
        WHEN CURRENT_DATE > d.fecha_fin_vigencia_programada THEN 'ALERTA CRÍTICA: PERÍODO EXCEDIDO'
        WHEN d.fecha_fin_vigencia_programada - CURRENT_DATE <= 30 THEN 'ALERTA ALTA: FALTA 1 MES O MENOS'
        WHEN d.fecha_fin_vigencia_programada - CURRENT_DATE <= 60 THEN 'ALERTA MEDIA: FALTAN 2 MESES'
        WHEN d.fecha_fin_vigencia_programada - CURRENT_DATE <= 90 THEN 'ALERTA BAJA: FALTAN 3 MESES'
        ELSE 'PERÍODO VIGENTE Y NORMAL'
    END AS estado_alerta
FROM gobernanza.directivo_estamento d
JOIN gobernanza.persona p ON d.id_persona = p.id_persona
JOIN gobernanza.estamento e ON d.id_estamento = e.id_estamento
JOIN gobernanza.registro_inspector_estamento r ON d.id_registro_inspector = r.id_registro
WHERE d.fecha_retiro IS NULL;

CREATE OR REPLACE VIEW gestion_documental.v_auditoria_informes_directivos AS
WITH ultimos_informes_directivo AS (
    SELECT d.id_persona_remitente,
           MAX(d.fecha_radicacion) AS fecha_ultimo_informe,
           COUNT(d.id_documento) AS total_informes_emitidos
    FROM gestion_documental.documento d
    JOIN gestion_documental.tipo_documento t ON d.id_tipo_documento = t.id_tipo_documento
    WHERE t.sigla_tipo = 'INF' AND d.flujo = 'EMITIDO' AND d.estado_tramite <> 'ANULADO'
    GROUP BY d.id_persona_remitente
)
SELECT
    dir.id_directivo_estamento,
    p.tipo_dni || ' ' || p.dni AS identificacion,
    p.primer_nombre || ' ' || COALESCE(p.segundo_nombre || ' ', '') || p.primer_apellido AS nombre_directivo,
    dir.rol_estamento AS cargo_directivo,
    e.nombre_estamento,
    e.tipo_estamento AS ambito_territorial,
    dir.fecha_posesion_individual,
    inf.fecha_ultimo_informe,
    COALESCE(inf.total_informes_emitidos, 0) AS total_informes_historicos,
    CASE WHEN inf.fecha_ultimo_informe IS NOT NULL THEN
        EXTRACT(MONTH FROM AGE(CURRENT_TIMESTAMP, inf.fecha_ultimo_informe))::INT + (EXTRACT(YEAR FROM AGE(CURRENT_TIMESTAMP, inf.fecha_ultimo_informe))::INT * 12)
    ELSE
        EXTRACT(MONTH FROM AGE(CURRENT_TIMESTAMP, dir.fecha_posesion_individual))::INT + (EXTRACT(YEAR FROM AGE(CURRENT_TIMESTAMP, dir.fecha_posesion_individual))::INT * 12)
    END AS meses_sin_informe,
    CASE WHEN inf.fecha_ultimo_informe IS NOT NULL THEN EXTRACT(DAY FROM (CURRENT_TIMESTAMP - inf.fecha_ultimo_informe))::INT
         ELSE (CURRENT_DATE - dir.fecha_posesion_individual)::INT
    END AS dias_sin_informe,
    CASE
        WHEN inf.fecha_ultimo_informe IS NULL THEN 'ALERTA CRÍTICA: NUNCA HA RENDIDO INFORME DE GESTIÓN'
        WHEN (CURRENT_TIMESTAMP - inf.fecha_ultimo_informe) > INTERVAL '90 days' THEN 'ALERTA CRÍTICA: MÁS DE 3 MESES SIN INFORME (>90 DÍAS)'
        WHEN (CURRENT_TIMESTAMP - inf.fecha_ultimo_informe) > INTERVAL '60 days' THEN 'ALERTA ALTA: MÁS DE 2 MESES SIN INFORME (>60 DÍAS)'
        WHEN (CURRENT_TIMESTAMP - inf.fecha_ultimo_informe) > INTERVAL '30 days' THEN 'ALERTA MEDIA: MÁS DE 1 MES SIN INFORME (>30 DÍAS)'
        ELSE 'AL DÍA CON RENDICIÓN DE CUENTAS (<30 DÍAS)'
    END AS diagnostico_auditoria_informe
FROM gobernanza.directivo_estamento dir
JOIN gobernanza.persona p ON dir.id_persona = p.id_persona
JOIN gobernanza.estamento e ON dir.id_estamento = e.id_estamento
LEFT JOIN ultimos_informes_directivo inf ON dir.id_persona = inf.id_persona_remitente
WHERE dir.fecha_retiro IS NULL;

-- Composición de cada junta: todos los cargos estatutarios, quién los ocupa o si están vacantes.
CREATE OR REPLACE VIEW gobernanza.v_composicion_juntas AS
SELECT
    e.id_estamento,
    e.nombre_estamento,
    e.tipo_estamento,
    c.orden,
    c.nombre AS cargo,
    p.tipo_dni || ' ' || p.dni AS identificacion,
    p.primer_nombre || ' ' || p.primer_apellido AS ocupado_por,
    d.fecha_posesion_individual,
    d.fecha_fin_vigencia_programada,
    CASE
        WHEN d.id_directivo_estamento IS NULL THEN 'ALERTA MEDIA: CARGO VACANTE'
        WHEN CURRENT_DATE > d.fecha_fin_vigencia_programada THEN 'ALERTA ALTA: OCUPADO CON PERÍODO VENCIDO'
        ELSE 'CARGO PROVISTO'
    END AS diagnostico
FROM gobernanza.estamento e
JOIN gobernanza.cargo_directivo c ON c.tipo_estamento = e.tipo_estamento AND c.activo
LEFT JOIN gobernanza.directivo_estamento d
       ON d.id_estamento = e.id_estamento AND d.id_cargo = c.id_cargo AND d.fecha_retiro IS NULL
LEFT JOIN gobernanza.persona p ON p.id_persona = d.id_persona;

-- Directivos con doble cargo (nacional + local): informativo
CREATE OR REPLACE VIEW gobernanza.v_directivos_doble_cargo AS
SELECT
    p.tipo_dni || ' ' || p.dni AS identificacion,
    p.primer_nombre || ' ' || p.primer_apellido AS nombre_directivo,
    MAX(CASE WHEN d.nivel_cargo = 'NACIONAL' THEN d.rol_estamento END) AS cargo_nacional,
    MAX(CASE WHEN d.nivel_cargo = 'LOCAL' THEN d.rol_estamento END) AS cargo_local,
    MAX(CASE WHEN d.nivel_cargo = 'LOCAL' THEN e.nombre_estamento END) AS estamento_local
FROM gobernanza.directivo_estamento d
JOIN gobernanza.persona p ON p.id_persona = d.id_persona
JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento
WHERE d.fecha_retiro IS NULL
GROUP BY p.id_persona, p.tipo_dni, p.dni, p.primer_nombre, p.primer_apellido
HAVING COUNT(*) > 1;

-- ----------------------------------------------------------------------------
-- 8. TIPOS DE ESTAMENTO: no existe "Junta Directiva Regional"
--    (las juntas son de la Nacional, de cada Subdirectiva o de cada Comité Seccional)
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM gobernanza.estamento WHERE tipo_estamento = 'JUNTA DIRECTIVA REGIONAL') THEN
        RAISE EXCEPTION 'Hay estamentos de tipo JUNTA DIRECTIVA REGIONAL. Cámbielos a SUBDIRECTIVA o COMITÉ SECCIONAL antes de ejecutar este script.';
    END IF;
    ALTER TABLE gobernanza.estamento DROP CONSTRAINT IF EXISTS estamento_tipo_estamento_check;
    ALTER TABLE gobernanza.estamento DROP CONSTRAINT IF EXISTS chk_tipo_estamento;
    ALTER TABLE gobernanza.estamento ADD CONSTRAINT chk_tipo_estamento
        CHECK (tipo_estamento IN ('JUNTA DIRECTIVA NACIONAL', 'SUBDIRECTIVA', 'COMITÉ SECCIONAL', 'ENTE DISPERSO'));
END $$;

-- ----------------------------------------------------------------------------
-- 9. ASOCIACIÓN DE DIRECTIVOS A CADA REGISTRO VIGENTE (con historial)
--    Cuando el inspector emite un registro nuevo para una Subdirectiva, Comité o la Nacional,
--    todos los directivos VIGENTES de ese estamento quedan asociados al nuevo registro.
--    El periodo de cada directivo es personal: un registro nuevo no lo modifica.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.directivo_registro (
    id_directivo_estamento BIGINT NOT NULL REFERENCES gobernanza.directivo_estamento(id_directivo_estamento) ON DELETE CASCADE,
    id_registro BIGINT NOT NULL REFERENCES gobernanza.registro_inspector_estamento(id_registro) ON DELETE RESTRICT,
    fecha_asociacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_asociacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    PRIMARY KEY (id_directivo_estamento, id_registro)
);
COMMENT ON TABLE gobernanza.directivo_registro IS 'Historial de los registros ante el inspector a los que ha estado asociado cada directivo.';
CREATE INDEX IF NOT EXISTS ix_directivo_registro_registro ON gobernanza.directivo_registro (id_registro);

DROP TRIGGER IF EXISTS trg_auditoria ON gobernanza.directivo_registro;
CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON gobernanza.directivo_registro
    FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria();

INSERT INTO gobernanza.directivo_registro (id_directivo_estamento, id_registro)
SELECT id_directivo_estamento, id_registro_inspector FROM gobernanza.directivo_estamento
ON CONFLICT DO NOTHING;

-- Cada asociación del directivo a un registro queda en el historial
CREATE OR REPLACE FUNCTION gobernanza.fn_historial_registro_directivo()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO gobernanza.directivo_registro (id_directivo_estamento, id_registro)
    VALUES (NEW.id_directivo_estamento, NEW.id_registro_inspector)
    ON CONFLICT DO NOTHING;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_historial_registro ON gobernanza.directivo_estamento;
CREATE TRIGGER trg_historial_registro
    AFTER INSERT OR UPDATE OF id_registro_inspector ON gobernanza.directivo_estamento
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_historial_registro_directivo();

-- Registro nuevo (o cambio de su fecha): se asocian a él los directivos vigentes del estamento
CREATE OR REPLACE FUNCTION gobernanza.fn_asociar_directivos_registro_vigente()
RETURNS TRIGGER AS $$
DECLARE v_vigente BIGINT;
BEGIN
    PERFORM pg_advisory_xact_lock(hashtext('registro_estamento_' || NEW.id_estamento));
    v_vigente := gobernanza.fn_registro_vigente(NEW.id_estamento);
    UPDATE gobernanza.directivo_estamento
       SET id_registro_inspector = v_vigente
     WHERE id_estamento = NEW.id_estamento AND fecha_retiro IS NULL
       AND id_registro_inspector <> v_vigente;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_asociar_registro_vigente ON gobernanza.registro_inspector_estamento;
CREATE TRIGGER trg_asociar_registro_vigente
    AFTER INSERT OR UPDATE OF fecha_emision_registro ON gobernanza.registro_inspector_estamento
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_asociar_directivos_registro_vigente();

-- ----------------------------------------------------------------------------
-- 10. EMPRESA, SEDE Y PERTENENCIA DEL AFILIADO
--  R10. Cada afiliado está vinculado a UNA sola empresa (y opcionalmente a una de sus sedes;
--       sin sede = trabaja en la sede central).
--  R11. Solo puede pertenecer a una Subdirectiva o Comité Seccional del municipio de la sede
--       donde trabaja o del municipio de la sede central de su empresa. Pertenece a uno solo.
--  Se verifica al confirmar la transacción (restricción diferida), para poder cambiar de sede y
--  de pertenencia en una misma operación.
-- ----------------------------------------------------------------------------
CREATE UNIQUE INDEX IF NOT EXISTS ux_afiliado_una_empresa ON gobernanza.afiliado_empresa (id_persona);

ALTER TABLE gobernanza.afiliado_empresa ADD COLUMN IF NOT EXISTS id_sede BIGINT;
CREATE UNIQUE INDEX IF NOT EXISTS ux_sede_empresa_par ON gobernanza.sede_empresa (id_sede, id_empresa);
DO $$ BEGIN
    ALTER TABLE gobernanza.afiliado_empresa ADD CONSTRAINT fk_afiliado_empresa_sede
        FOREIGN KEY (id_sede, id_empresa) REFERENCES gobernanza.sede_empresa (id_sede, id_empresa) ON DELETE RESTRICT;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
CREATE INDEX IF NOT EXISTS ix_afiliado_empresa_sede ON gobernanza.afiliado_empresa (id_sede, id_empresa);
COMMENT ON COLUMN gobernanza.afiliado_empresa.id_sede IS 'Sede donde trabaja el afiliado. NULL = sede central de la empresa.';

CREATE OR REPLACE FUNCTION gobernanza.fn_normalizar_lugar(p TEXT)
RETURNS TEXT AS $$
    SELECT NULLIF(UPPER(TRANSLATE(TRIM(p), 'áéíóúüÁÉÍÓÚÜ', 'aeiouuAEIOUU')), '');
$$ LANGUAGE sql IMMUTABLE;

-- Lugares donde puede pertenecer el afiliado: sede de trabajo y sede central
CREATE OR REPLACE VIEW gobernanza.v_pertenencia_permitida AS
WITH lugares AS (
    SELECT ae.id_persona, 'SEDE DE TRABAJO' AS motivo, s.departamento_sede AS departamento, s.municipio_sede AS municipio
      FROM gobernanza.afiliado_empresa ae JOIN gobernanza.sede_empresa s ON s.id_sede = ae.id_sede
    UNION ALL
    SELECT ae.id_persona, 'SEDE CENTRAL', e.departamento, e.municipio
      FROM gobernanza.afiliado_empresa ae JOIN gobernanza.empresa e ON e.id_empresa = ae.id_empresa
)
SELECT DISTINCT ON (l.id_persona, est.id_estamento)
       l.id_persona, est.id_estamento, est.nombre_estamento, est.tipo_estamento, l.motivo, l.municipio
  FROM lugares l
  JOIN gobernanza.estamento est
    ON est.tipo_estamento IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL')
   AND (gobernanza.fn_normalizar_lugar(est.municipio) = gobernanza.fn_normalizar_lugar(l.municipio)
        OR (est.municipio IS NULL AND gobernanza.fn_normalizar_lugar(est.departamento) = gobernanza.fn_normalizar_lugar(l.departamento)))
 ORDER BY l.id_persona, est.id_estamento, l.motivo DESC;

CREATE OR REPLACE FUNCTION gobernanza.fn_verificar_pertenencia(p_id_persona BIGINT)
RETURNS VOID AS $$
DECLARE
    v_pert BIGINT; v_tipo VARCHAR(30); v_nombre VARCHAR(150);
    v_trabajo TEXT; v_central TEXT; v_empresa TEXT; v_opciones TEXT;
BEGIN
    SELECT a.id_estamento_pertenencia, e.tipo_estamento, e.nombre_estamento INTO v_pert, v_tipo, v_nombre
      FROM gobernanza.afiliado a LEFT JOIN gobernanza.estamento e ON e.id_estamento = a.id_estamento_pertenencia
     WHERE a.id_persona = p_id_persona;
    IF v_pert IS NULL OR v_tipo NOT IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL') THEN RETURN; END IF;
    IF NOT EXISTS (SELECT 1 FROM gobernanza.afiliado_empresa WHERE id_persona = p_id_persona) THEN RETURN; END IF;
    IF EXISTS (SELECT 1 FROM gobernanza.v_pertenencia_permitida WHERE id_persona = p_id_persona AND id_estamento = v_pert) THEN RETURN; END IF;

    SELECT emp.nombre_empresa, COALESCE(s.municipio_sede, emp.municipio), emp.municipio
      INTO v_empresa, v_trabajo, v_central
      FROM gobernanza.afiliado_empresa ae JOIN gobernanza.empresa emp ON emp.id_empresa = ae.id_empresa
      LEFT JOIN gobernanza.sede_empresa s ON s.id_sede = ae.id_sede
     WHERE ae.id_persona = p_id_persona;
    SELECT string_agg('"' || nombre_estamento || '"', ' o ' ORDER BY motivo DESC, nombre_estamento) INTO v_opciones
      FROM gobernanza.v_pertenencia_permitida WHERE id_persona = p_id_persona;
    RAISE EXCEPTION 'El afiliado trabaja en % (%), con sede central en %, y no puede pertenecer a "%". Puede pertenecer a: %.',
        v_empresa, v_trabajo, v_central, v_nombre,
        COALESCE(v_opciones, 'ninguna; no hay subdirectiva ni comité registrados en esos municipios');
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION gobernanza.fn_ck_pertenencia()
RETURNS TRIGGER AS $$
BEGIN
    PERFORM gobernanza.fn_verificar_pertenencia(NEW.id_persona);
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_ck_pertenencia ON gobernanza.afiliado;
CREATE CONSTRAINT TRIGGER trg_ck_pertenencia
    AFTER INSERT OR UPDATE OF id_estamento_pertenencia ON gobernanza.afiliado
    DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_ck_pertenencia();
DROP TRIGGER IF EXISTS trg_ck_pertenencia ON gobernanza.afiliado_empresa;
CREATE CONSTRAINT TRIGGER trg_ck_pertenencia
    AFTER INSERT OR UPDATE OF id_empresa, id_sede ON gobernanza.afiliado_empresa
    DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_ck_pertenencia();

-- Control: afiliados cuya pertenencia no cumple la regla (p. ej. datos antiguos o cambios de municipio de una sede)
CREATE OR REPLACE VIEW gobernanza.v_auditoria_pertenencia AS
SELECT
    p.tipo_dni || ' ' || p.dni AS identificacion,
    p.primer_nombre || ' ' || p.primer_apellido AS afiliado,
    emp.nombre_empresa,
    COALESCE(s.nombre_sede, 'SEDE CENTRAL') AS sede_trabajo,
    COALESCE(s.municipio_sede, emp.municipio) AS municipio_trabajo,
    emp.municipio AS municipio_sede_central,
    est.nombre_estamento AS pertenencia,
    (SELECT string_agg(pp.nombre_estamento, ' / ' ORDER BY pp.nombre_estamento)
       FROM gobernanza.v_pertenencia_permitida pp WHERE pp.id_persona = a.id_persona) AS opciones_permitidas,
    CASE
        WHEN ae.id_persona IS NULL THEN 'ALERTA MEDIA: SIN EMPRESA REGISTRADA'
        WHEN a.id_estamento_pertenencia IS NULL THEN 'ALERTA ALTA: SIN SUBDIRECTIVA O COMITÉ'
        WHEN est.tipo_estamento IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL') AND NOT EXISTS (
             SELECT 1 FROM gobernanza.v_pertenencia_permitida pp
              WHERE pp.id_persona = a.id_persona AND pp.id_estamento = a.id_estamento_pertenencia)
             THEN 'ALERTA CRÍTICA: PERTENENCIA NO CORRESPONDE A SU SEDE'
        ELSE 'PERTENENCIA CORRECTA'
    END AS diagnostico
FROM gobernanza.afiliado a
JOIN gobernanza.persona p ON p.id_persona = a.id_persona
LEFT JOIN gobernanza.estamento est ON est.id_estamento = a.id_estamento_pertenencia
LEFT JOIN gobernanza.afiliado_empresa ae ON ae.id_persona = a.id_persona
LEFT JOIN gobernanza.empresa emp ON emp.id_empresa = ae.id_empresa
LEFT JOIN gobernanza.sede_empresa s ON s.id_sede = ae.id_sede;

-- ----------------------------------------------------------------------------
-- 11. INSPECTOR DE TRABAJO: municipio y género obligatorios (teléfono y correo opcionales)
--     No se guardan documento de identidad, cargo, dirección de oficina ni fecha de retiro
--     porque el sindicato no dispone de esos datos.
-- ----------------------------------------------------------------------------
DO $$
DECLARE v_faltan INT;
BEGIN
    SELECT count(*) INTO v_faltan FROM gobernanza.inspector WHERE municipio IS NULL OR genero IS NULL;
    IF v_faltan > 0 THEN
        RAISE EXCEPTION 'Hay % inspector(es) sin municipio o sin género. Complételos antes de ejecutar este script.', v_faltan;
    END IF;
    ALTER TABLE gobernanza.inspector ALTER COLUMN municipio SET NOT NULL;
    ALTER TABLE gobernanza.inspector ALTER COLUMN genero SET NOT NULL;
END $$;

-- ----------------------------------------------------------------------------
-- 12. JERARQUÍA DE JEFES DE EMPRESA
--   Niveles (de menor a mayor): 1 jefes o coordinadores de grupo, proceso o equipo ·
--   2 subdirectores, subsecretarios o secretarios de despacho · 3 jefe de talento humano ·
--   4 representante legal · 5 viceministros y ministros · 6 Presidente de la Nación.
--  J1. Nadie es jefe de sí mismo, ni directamente ni a través de una cadena (sin ciclos).
--  J2. El jefe directo tiene un nivel IGUAL O SUPERIOR (p. ej. subsecretario → secretario,
--      ambos nivel 2; viceministro → ministro, ambos nivel 5). Puede ser de otra entidad
--      (representante legal → ministro → Presidente).
--  J3. El nivel 6 no tiene jefe directo.
--  J4. El jefe directo de un AFILIADO es de su misma empresa y no es él mismo.
--  J5. El jefe de talento humano de una empresa es nivel 3 y su representante legal nivel 4,
--      ambos registrados como jefes de esa misma empresa.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION gobernanza.fn_nivel_jefe(p_nivel TEXT)
RETURNS INT AS $$ SELECT split_part(p_nivel, ' ', 2)::INT; $$ LANGUAGE sql IMMUTABLE;

CREATE OR REPLACE FUNCTION gobernanza.fn_nombre_jefe(p_id_jefe BIGINT)
RETURNS TEXT AS $$
    SELECT p.primer_nombre || ' ' || p.primer_apellido || ' (' || j.cargo_nivel || ', ' || e.nombre_empresa || ')'
      FROM gobernanza.jefe_empresa j
      JOIN gobernanza.persona p ON p.id_persona = j.id_persona
      JOIN gobernanza.empresa e ON e.id_empresa = j.id_empresa
     WHERE j.id_jefe = p_id_jefe;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_validar_jefe()
RETURNS TRIGGER AS $$
DECLARE
    v_jefe gobernanza.jefe_empresa%ROWTYPE;
    v_actual BIGINT;
    v_pasos INT := 0;
    v_sub TEXT;
BEGIN
    -- Los cambios de jerarquía se serializan para que dos usuarios no formen un ciclo a la vez
    PERFORM pg_advisory_xact_lock(hashtext('jerarquia_jefes'));

    IF NEW.id_jefe_directo IS NOT NULL THEN
        IF gobernanza.fn_nivel_jefe(NEW.cargo_nivel) = 6 THEN
            RAISE EXCEPTION 'El nivel 6 (Presidente de la Nación) no tiene jefe directo.';
        END IF;
        SELECT * INTO v_jefe FROM gobernanza.jefe_empresa WHERE id_jefe = NEW.id_jefe_directo;
        IF v_jefe.id_persona = NEW.id_persona THEN
            RAISE EXCEPTION 'Una persona no puede ser jefe directo de sí misma (aunque esté registrada como jefe en otra empresa).';
        END IF;
        IF gobernanza.fn_nivel_jefe(v_jefe.cargo_nivel) < gobernanza.fn_nivel_jefe(NEW.cargo_nivel) THEN
            RAISE EXCEPTION 'El jefe directo debe tener un nivel igual o superior: % no puede ser jefe de alguien de %.',
                gobernanza.fn_nombre_jefe(v_jefe.id_jefe), NEW.cargo_nivel;
        END IF;
        -- Recorre la cadena hacia arriba: si vuelve a este jefe, hay un ciclo
        IF TG_OP = 'UPDATE' THEN
            v_actual := NEW.id_jefe_directo;
            WHILE v_actual IS NOT NULL AND v_pasos < 1000 LOOP
                IF v_actual = NEW.id_jefe THEN
                    RAISE EXCEPTION 'La jerarquía formaría un ciclo: % ya depende (directa o indirectamente) de esta persona.',
                        gobernanza.fn_nombre_jefe(NEW.id_jefe_directo);
                END IF;
                SELECT id_jefe_directo INTO v_actual FROM gobernanza.jefe_empresa WHERE id_jefe = v_actual;
                v_pasos := v_pasos + 1;
            END LOOP;
        END IF;
    END IF;

    -- Si baja de nivel, no puede quedar por debajo de quienes dependen de él
    IF TG_OP = 'UPDATE' AND NEW.cargo_nivel IS DISTINCT FROM OLD.cargo_nivel THEN
        SELECT gobernanza.fn_nombre_jefe(id_jefe) INTO v_sub FROM gobernanza.jefe_empresa
         WHERE id_jefe_directo = NEW.id_jefe AND gobernanza.fn_nivel_jefe(cargo_nivel) > gobernanza.fn_nivel_jefe(NEW.cargo_nivel)
         LIMIT 1;
        IF FOUND THEN
            RAISE EXCEPTION 'No puede quedar en % porque % depende de esta persona y tiene un nivel superior.', NEW.cargo_nivel, v_sub;
        END IF;
        IF EXISTS (SELECT 1 FROM gobernanza.empresa WHERE id_jefe_talento_humano = NEW.id_jefe) AND gobernanza.fn_nivel_jefe(NEW.cargo_nivel) <> 3 THEN
            RAISE EXCEPTION 'Esta persona está registrada como jefe de talento humano de una empresa; ese cargo es nivel 3.';
        END IF;
        IF EXISTS (SELECT 1 FROM gobernanza.empresa WHERE id_representante_legal = NEW.id_jefe) AND gobernanza.fn_nivel_jefe(NEW.cargo_nivel) <> 4 THEN
            RAISE EXCEPTION 'Esta persona está registrada como representante legal de una empresa; ese cargo es nivel 4.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_validar_jefe ON gobernanza.jefe_empresa;
CREATE TRIGGER trg_validar_jefe BEFORE INSERT OR UPDATE OF id_jefe_directo, cargo_nivel, id_persona ON gobernanza.jefe_empresa
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_validar_jefe();

CREATE OR REPLACE FUNCTION gobernanza.fn_validar_jefe_afiliado()
RETURNS TRIGGER AS $$
DECLARE v_jefe gobernanza.jefe_empresa%ROWTYPE;
BEGIN
    IF NEW.id_jefe_directo IS NULL THEN RETURN NEW; END IF;
    SELECT * INTO v_jefe FROM gobernanza.jefe_empresa WHERE id_jefe = NEW.id_jefe_directo;
    IF v_jefe.id_persona = NEW.id_persona THEN
        RAISE EXCEPTION 'Un afiliado no puede tener como jefe directo a sí mismo.';
    END IF;
    IF v_jefe.id_empresa <> NEW.id_empresa THEN
        RAISE EXCEPTION 'El jefe directo del afiliado debe ser de su misma empresa: % es de otra.', gobernanza.fn_nombre_jefe(v_jefe.id_jefe);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_validar_jefe_afiliado ON gobernanza.afiliado_empresa;
CREATE TRIGGER trg_validar_jefe_afiliado BEFORE INSERT OR UPDATE OF id_jefe_directo, id_empresa ON gobernanza.afiliado_empresa
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_validar_jefe_afiliado();

CREATE OR REPLACE FUNCTION gobernanza.fn_validar_cargos_empresa()
RETURNS TRIGGER AS $$
DECLARE v_jefe gobernanza.jefe_empresa%ROWTYPE;
BEGIN
    IF NEW.id_jefe_talento_humano IS NOT NULL THEN
        SELECT * INTO v_jefe FROM gobernanza.jefe_empresa WHERE id_jefe = NEW.id_jefe_talento_humano;
        IF v_jefe.id_empresa <> NEW.id_empresa OR gobernanza.fn_nivel_jefe(v_jefe.cargo_nivel) <> 3 THEN
            RAISE EXCEPTION 'El jefe de talento humano debe estar registrado como jefe de esta misma empresa con nivel 3.';
        END IF;
    END IF;
    IF NEW.id_representante_legal IS NOT NULL THEN
        SELECT * INTO v_jefe FROM gobernanza.jefe_empresa WHERE id_jefe = NEW.id_representante_legal;
        IF v_jefe.id_empresa <> NEW.id_empresa OR gobernanza.fn_nivel_jefe(v_jefe.cargo_nivel) <> 4 THEN
            RAISE EXCEPTION 'El representante legal debe estar registrado como jefe de esta misma empresa con nivel 4.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_validar_cargos_empresa ON gobernanza.empresa;
CREATE TRIGGER trg_validar_cargos_empresa BEFORE INSERT OR UPDATE OF id_jefe_talento_humano, id_representante_legal ON gobernanza.empresa
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_validar_cargos_empresa();

-- ----------------------------------------------------------------------------
-- 13. HISTORIA DE LAS JUNTAS: composición en una fecha y por registro del inspector
--   Un directivo estaba en el cargo en la fecha F si se posesionó en F o antes y no se había
--   retirado (la fecha de retiro es el primer día en que ya no ejerce).
--   Se respeta el ámbito territorial del usuario que consulta.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION gobernanza.fn_composicion_junta(p_id_estamento BIGINT, p_fecha DATE)
RETURNS TABLE (orden INT, cargo VARCHAR, identificacion TEXT, directivo TEXT, tipo_nombramiento VARCHAR,
               fecha_posesion DATE, fecha_retiro DATE, fin_periodo DATE, registro VARCHAR) AS $$
    SELECT c.orden, c.nombre,
           p.tipo_dni || ' ' || p.dni,
           p.primer_nombre || ' ' || COALESCE(p.segundo_nombre || ' ', '') || p.primer_apellido || COALESCE(' ' || p.segundo_apellido, ''),
           d.tipo_nombramiento, d.fecha_posesion_individual, d.fecha_retiro, d.fecha_fin_vigencia_programada,
           (SELECT r.num_registro_inspector
              FROM gobernanza.directivo_registro dr
              JOIN gobernanza.registro_inspector_estamento r ON r.id_registro = dr.id_registro
             WHERE dr.id_directivo_estamento = d.id_directivo_estamento AND r.fecha_emision_registro::DATE <= p_fecha
             ORDER BY r.fecha_emision_registro DESC LIMIT 1)
      FROM gobernanza.estamento e
      JOIN gobernanza.cargo_directivo c ON c.tipo_estamento = e.tipo_estamento
      LEFT JOIN gobernanza.directivo_estamento d
             ON d.id_estamento = e.id_estamento AND d.id_cargo = c.id_cargo
            AND d.fecha_posesion_individual <= p_fecha AND (d.fecha_retiro IS NULL OR d.fecha_retiro > p_fecha)
      LEFT JOIN gobernanza.persona p ON p.id_persona = d.id_persona
     WHERE e.id_estamento = p_id_estamento
     ORDER BY c.orden, d.fecha_posesion_individual;
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE FUNCTION gobernanza.fn_composicion_registro(p_id_registro BIGINT)
RETURNS TABLE (orden INT, cargo VARCHAR, identificacion TEXT, directivo TEXT, tipo_nombramiento VARCHAR,
               fecha_posesion DATE, fecha_retiro DATE, fin_periodo DATE) AS $$
    SELECT c.orden, c.nombre, p.tipo_dni || ' ' || p.dni,
           p.primer_nombre || ' ' || COALESCE(p.segundo_nombre || ' ', '') || p.primer_apellido || COALESCE(' ' || p.segundo_apellido, ''),
           d.tipo_nombramiento, d.fecha_posesion_individual, d.fecha_retiro, d.fecha_fin_vigencia_programada
      FROM gobernanza.directivo_registro dr
      JOIN gobernanza.directivo_estamento d ON d.id_directivo_estamento = dr.id_directivo_estamento
      JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
      JOIN gobernanza.persona p ON p.id_persona = d.id_persona
     WHERE dr.id_registro = p_id_registro
     ORDER BY c.orden, d.fecha_posesion_individual;
$$ LANGUAGE sql STABLE;
