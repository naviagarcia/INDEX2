-- ============================================================================
-- SGSINDICAL v9.1 — 04: DATOS DE DEMOSTRACIÓN (OPCIONAL, SOLO PARA PRUEBAS)
-- ============================================================================
SELECT set_config('app.usuario', 'carga_inicial', false);

INSERT INTO gobernanza.estamento (nombre_estamento, tipo_estamento, departamento, municipio) VALUES
    ('Junta Directiva Nacional', 'JUNTA DIRECTIVA NACIONAL', 'CUNDINAMARCA', 'BOGOTÁ'),
    ('Subdirectiva Medellín', 'SUBDIRECTIVA', 'ANTIOQUIA', 'MEDELLÍN'),
    ('Comité Seccional Cali', 'COMITÉ SECCIONAL', 'VALLE DEL CAUCA', 'CALI');

INSERT INTO gobernanza.persona (tipo_dni, dni, primer_nombre, primer_apellido, departamento, municipio, genero, telefono, correo_electronico) VALUES
    ('CC', '1010101010', 'ANA', 'GÓMEZ', 'CUNDINAMARCA', 'BOGOTÁ', 'FEMENINO', '3001112233', 'ana.gomez@ejemplo.org'),
    ('CC', '2020202020', 'CARLOS', 'RUIZ', 'ANTIOQUIA', 'MEDELLÍN', 'MASCULINO', '3002223344', 'carlos.ruiz@ejemplo.org'),
    ('CC', '3030303030', 'LUISA', 'MARTÍNEZ', 'VALLE DEL CAUCA', 'CALI', 'FEMENINO', '3003334455', 'luisa.martinez@ejemplo.org');

-- Ana y Carlos pertenecen a la Subdirectiva Medellín; Luisa al Comité Seccional Cali
INSERT INTO gobernanza.afiliado (id_persona, fecha_afiliacion, fecha_nacimiento, nivel_educativo, cargo_empresa, zona_residencia, id_estamento_pertenencia)
SELECT id_persona, DATE '2020-03-01', DATE '1985-06-15', 'PROFESIONAL', 'PROFESIONAL', 'URBANA',
       CASE WHEN id_persona = 3 THEN 3 ELSE 2 END
FROM gobernanza.persona;

INSERT INTO gobernanza.empresa (nit, nombre_empresa, sigla, departamento, municipio, direccion, rango_empleados, telefono_1, correo_general, correo_notificaciones_judiciales)
VALUES ('900123456-7', 'EMPRESA PÚBLICA DE EJEMPLO', 'EPE', 'CUNDINAMARCA', 'BOGOTÁ', 'CALLE 1 # 2-3', 'MÁS DE 500', '6011234567', 'contacto@epe.gov.co', 'judiciales@epe.gov.co');

-- Sede central en Bogotá; sedes en Medellín (id 1) y Cali (id 2)
INSERT INTO gobernanza.sede_empresa (id_empresa, nombre_sede, departamento_sede, municipio_sede)
SELECT id_empresa, x.nombre, x.dep, x.mun FROM gobernanza.empresa,
       (VALUES ('SEDE MEDELLÍN', 'ANTIOQUIA', 'MEDELLÍN'), ('SEDE CALI', 'VALLE DEL CAUCA', 'CALI')) AS x(nombre, dep, mun);

-- Ana y Carlos trabajan en la sede Medellín; Luisa en la sede Cali
INSERT INTO gobernanza.afiliado_empresa (id_persona, id_empresa, id_sede, salario_base, fecha_ingreso_empresa)
SELECT p.id_persona, e.id_empresa, s.id_sede, 3500000, DATE '2018-01-15'
FROM gobernanza.afiliado p CROSS JOIN gobernanza.empresa e
JOIN gobernanza.sede_empresa s ON s.id_empresa = e.id_empresa
 AND s.nombre_sede = CASE WHEN p.id_persona = 3 THEN 'SEDE CALI' ELSE 'SEDE MEDELLÍN' END;

INSERT INTO gobernanza.inspector (primer_nombre, primer_apellido, genero, nombre_territorial, departamento, municipio)
VALUES ('JORGE', 'PÉREZ', 'MASCULINO', 'DIRECCIÓN TERRITORIAL BOGOTÁ', 'CUNDINAMARCA', 'BOGOTÁ');

INSERT INTO gobernanza.registro_inspector_estamento (id_estamento, id_inspector, num_registro_inspector, fecha_emision_registro)
SELECT e.id_estamento, i.id_inspector, 'REG-2025-' || e.id_estamento, TIMESTAMPTZ '2025-01-10 10:00-05'
FROM gobernanza.estamento e CROSS JOIN gobernanza.inspector i;

-- Ana: Presidente Nal · Carlos: Presidente Reg (Medellín) · Luisa: Presidente Comité (Cali)
INSERT INTO gobernanza.directivo_estamento (id_persona, id_estamento, id_registro_inspector, id_cargo, rol_estamento, fecha_posesion_individual)
SELECT x.id_persona, r.id_estamento, r.id_registro, c.id_cargo, c.nombre, CURRENT_DATE - INTERVAL '23 months'
FROM (VALUES (1, 1, 'PRES_NAL'), (2, 2, 'PRES_REG'), (3, 3, 'PRES_COM')) AS x(id_persona, id_estamento, codigo)
JOIN gobernanza.registro_inspector_estamento r ON r.id_estamento = x.id_estamento
JOIN gobernanza.cargo_directivo c ON c.codigo = x.codigo;

INSERT INTO finanzas.cuenta_bancaria (id_estamento, es_cuenta_nacional, banco, numero_cuenta, tipo_cuenta)
VALUES (1, TRUE, 'BANCO DE EJEMPLO', '001-234567-89', 'AHORROS');
