#!/usr/bin/env bash
# Instala la base SGSINDICAL. Uso:  ./instalar.sh [nombre_bd] [--demo]
# Requiere psql y un usuario con permisos de superusuario (PGUSER/PGHOST/PGPORT del entorno).
set -euo pipefail
cd "$(dirname "$0")"
BD="${1:-sgsindical}"
read -rsp "Contraseña para el rol sgs_app (backend): " APP; echo
read -rsp "Contraseña para el rol sgs_lectura (reportes): " LEC; echo
read -rsp "Contraseña para el rol sgs_backup (copias): " BAK; echo
read -rsp "Contraseña para el rol sgs_notificador (correos): " NOT; echo
createdb "$BD" 2>/dev/null || echo "La base $BD ya existe; se actualizarán sus objetos."
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 01_sgsindical_v9_1_estructura.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 02_seguridad_auditoria_indices.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 02b_reglas_directivos.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 02c_acceso_territorial.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 02d_notificaciones.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 02e_finanzas.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 02f_reuniones_actas.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 02g_redes_sociales.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 02h_escritos_juridicos.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 02i_contenidos_redes.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -v app_pass="$APP" -v lectura_pass="$LEC" -v backup_pass="$BAK" -v notif_pass="$NOT" -f 03_roles_permisos.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 05_inactivacion.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 06_datos_personales.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 07_porcentaje_aporte.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 08_ventanilla_autoservicio.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 09_mfa.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 10_pqrsd.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 11_endurecimiento.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 12_roles_suplencias.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 13_plazos_ley.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 14_niveles_jefes.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 15_documentos_legales.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 16_expediente_afiliacion.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 17_lugares_traslados.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 17b_divipola_municipios.sql
psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 18_posesion_permisos.sql
[[ "${2:-}" == "--demo" ]] && psql -v ON_ERROR_STOP=1 -q -d "$BD" -f 04_datos_demo.sql
echo "Base $BD instalada. Siguiente paso: crear el administrador con  python -m app.cli crear-admin"
