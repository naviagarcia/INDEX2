-- ============================================================================
-- SGSINDICAL v9.1 · 14_niveles_jefes.sql
-- Niveles de jefes de empresa por posición en la entidad (no por nombre del cargo) y
-- representante legal separado de los niveles.
--
--   Nivel 1: coordina un grupo, equipo o proceso.
--   Nivel 2: dirige un área o una dependencia.
--   Nivel 3: hace parte de la alta dirección (subdirector, secretario, vicepresidente de la empresa).
--   Nivel 4: máxima autoridad de la entidad (gerente, director, alcalde, ministro, Presidente).
--
-- Reglas (las aplica la base de datos):
--  J1. Nadie es jefe de sí mismo, ni directamente ni a través de una cadena (sin ciclos).
--  J2. El jefe directo tiene un nivel igual o superior; puede ser de otra entidad
--      (gerente de una entidad adscrita → ministro → Presidente, todos nivel 4).
--  J3. Los niveles 1, 2 y 3 tienen jefe directo: es la cadena para escalar una queja.
--      El nivel 4 puede tenerlo en otra entidad, o no tenerlo.
--  J4. El jefe directo de un afiliado es de su misma empresa y no es él mismo (sin cambios).
--  J5. Cada empresa tiene como máximo un representante legal y un jefe de talento humano, ambos
--      registrados como jefes de esa misma empresa, de cualquier nivel. Una persona puede ser
--      representante legal de varias empresas (se registra como jefe en cada una).
--
-- Los niveles 5 y 6 anteriores pasan a 4. Los niveles 2 y 3 anteriores no se pueden convertir
-- sin conocer cada cargo: conservan su número y quedan marcados «por revisar».
-- No modifica los scripts anteriores. Se puede ejecutar más de una vez.
-- ============================================================================

ALTER TABLE gobernanza.jefe_empresa ADD COLUMN IF NOT EXISTS nivel_por_revisar BOOLEAN NOT NULL DEFAULT FALSE;
COMMENT ON COLUMN gobernanza.jefe_empresa.nivel_por_revisar IS
    'El nivel viene de la escala anterior (1 a 6) y hay que confirmarlo con la escala nueva (1 a 4). Se apaga al guardar el nivel.';
COMMENT ON COLUMN gobernanza.jefe_empresa.cargo_nivel IS
    'NIVEL 1 coordina un grupo, equipo o proceso · NIVEL 2 dirige un área o dependencia · NIVEL 3 alta dirección · NIVEL 4 máxima autoridad de la entidad.';

-- 1. Conversión de la escala anterior (solo la primera vez: después ya no hay niveles 5 ni 6).
--    La conversión 1→1, 2→2, 3→3, 4→4, 5→4, 6→4 nunca deja a un jefe por debajo de quien depende de él,
--    así que se hace con la validación apagada para no tropezar con el orden de las filas.
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'jefe_empresa_cargo_nivel_check'
                AND conrelid = 'gobernanza.jefe_empresa'::regclass
                AND pg_get_constraintdef(oid) LIKE '%NIVEL 6%') THEN
        ALTER TABLE gobernanza.jefe_empresa DISABLE TRIGGER trg_validar_jefe;
        UPDATE gobernanza.jefe_empresa SET nivel_por_revisar = TRUE WHERE cargo_nivel IN ('NIVEL 2', 'NIVEL 3', 'NIVEL 5');
        UPDATE gobernanza.jefe_empresa SET cargo_nivel = 'NIVEL 4' WHERE cargo_nivel IN ('NIVEL 5', 'NIVEL 6');
        ALTER TABLE gobernanza.jefe_empresa ENABLE TRIGGER trg_validar_jefe;
        ALTER TABLE gobernanza.jefe_empresa DROP CONSTRAINT jefe_empresa_cargo_nivel_check;
        ALTER TABLE gobernanza.jefe_empresa ADD CONSTRAINT jefe_empresa_cargo_nivel_check
            CHECK (cargo_nivel IN ('NIVEL 1', 'NIVEL 2', 'NIVEL 3', 'NIVEL 4'));
    END IF;
END $$;

-- 2. Validación de la jerarquía
CREATE OR REPLACE FUNCTION gobernanza.fn_validar_jefe()
RETURNS TRIGGER AS $$
DECLARE
    v_jefe gobernanza.jefe_empresa%ROWTYPE;
    v_actual BIGINT;
    v_pasos INT := 0;
    v_sub TEXT;
BEGIN
    -- Los cambios de jerarquía se serializan para que dos usuarios no formen un ciclo a la vez
    PERFORM pg_advisory_xact_lock(hashtext('jerarquia_jefes'));

    -- Al guardar el nivel queda revisado
    IF TG_OP = 'INSERT' THEN
        NEW.nivel_por_revisar := FALSE;
    ELSIF NEW.cargo_nivel IS DISTINCT FROM OLD.cargo_nivel THEN
        NEW.nivel_por_revisar := FALSE;
    END IF;

    -- J3. Los niveles 1 a 3 tienen jefe directo (para escalar una queja)
    IF NEW.id_jefe_directo IS NULL AND gobernanza.fn_nivel_jefe(NEW.cargo_nivel) < 4
       AND (TG_OP = 'INSERT' OR NEW.id_jefe_directo IS DISTINCT FROM OLD.id_jefe_directo
            OR NEW.cargo_nivel IS DISTINCT FROM OLD.cargo_nivel) THEN
        RAISE EXCEPTION 'Un jefe de % debe tener jefe directo: es la cadena para escalar una queja. Solo la máxima autoridad de la entidad (nivel 4) puede no tenerlo. Registre primero a su jefe.',
            NEW.cargo_nivel;
    END IF;

    IF NEW.id_jefe_directo IS NOT NULL THEN
        SELECT * INTO v_jefe FROM gobernanza.jefe_empresa WHERE id_jefe = NEW.id_jefe_directo;
        IF v_jefe.id_persona = NEW.id_persona THEN
            RAISE EXCEPTION 'Una persona no puede ser jefe directo de sí misma (aunque esté registrada como jefe en otra empresa).';
        END IF;
        -- J2. Nivel igual o superior (puede ser de otra entidad)
        IF gobernanza.fn_nivel_jefe(v_jefe.cargo_nivel) < gobernanza.fn_nivel_jefe(NEW.cargo_nivel) THEN
            RAISE EXCEPTION 'El jefe directo debe tener un nivel igual o superior: % no puede ser jefe de alguien de %.',
                gobernanza.fn_nombre_jefe(v_jefe.id_jefe), NEW.cargo_nivel;
        END IF;
        -- J1. Recorre la cadena hacia arriba: si vuelve a este jefe, hay un ciclo
        IF TG_OP = 'UPDATE' THEN
            v_actual := NEW.id_jefe_directo;
            WHILE v_actual IS NOT NULL AND v_pasos < 1000 LOOP
                IF v_actual = NEW.id_jefe THEN
                    RAISE EXCEPTION 'La jerarquía formaría un ciclo: % ya depende (directa o indirectamente) de esta persona.',
                        gobernanza.fn_nombre_jefe(NEW.id_jefe_directo);
                END IF;
                SELECT id_jefe_directo INTO v_actual FROM gobernanza.jefe_empresa WHERE id_jefe = v_actual;
                v_pasos := v_pasos + 1;
            END LOOP;
        END IF;
    END IF;

    -- Si baja de nivel, no puede quedar por debajo de quienes dependen de él
    IF TG_OP = 'UPDATE' AND NEW.cargo_nivel IS DISTINCT FROM OLD.cargo_nivel THEN
        SELECT gobernanza.fn_nombre_jefe(id_jefe) INTO v_sub FROM gobernanza.jefe_empresa
         WHERE id_jefe_directo = NEW.id_jefe AND gobernanza.fn_nivel_jefe(cargo_nivel) > gobernanza.fn_nivel_jefe(NEW.cargo_nivel)
         LIMIT 1;
        IF FOUND THEN
            RAISE EXCEPTION 'No puede quedar en % porque % depende de esta persona y tiene un nivel superior.', NEW.cargo_nivel, v_sub;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_validar_jefe ON gobernanza.jefe_empresa;
CREATE TRIGGER trg_validar_jefe BEFORE INSERT OR UPDATE OF id_jefe_directo, cargo_nivel, id_persona, nivel_por_revisar
    ON gobernanza.jefe_empresa FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_validar_jefe();

-- 3. Representante legal y jefe de talento humano: de la misma empresa, de cualquier nivel
CREATE OR REPLACE FUNCTION gobernanza.fn_validar_cargos_empresa()
RETURNS TRIGGER AS $$
DECLARE v_jefe gobernanza.jefe_empresa%ROWTYPE;
BEGIN
    IF NEW.id_jefe_talento_humano IS NOT NULL THEN
        SELECT * INTO v_jefe FROM gobernanza.jefe_empresa WHERE id_jefe = NEW.id_jefe_talento_humano;
        IF v_jefe.id_empresa <> NEW.id_empresa THEN
            RAISE EXCEPTION 'El jefe de talento humano debe estar registrado como jefe de esta misma empresa.';
        END IF;
    END IF;
    IF NEW.id_representante_legal IS NOT NULL THEN
        SELECT * INTO v_jefe FROM gobernanza.jefe_empresa WHERE id_jefe = NEW.id_representante_legal;
        IF v_jefe.id_empresa <> NEW.id_empresa THEN
            RAISE EXCEPTION 'El representante legal debe estar registrado como jefe de esta misma empresa. Si también representa otra empresa, regístrelo como jefe en cada una.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_validar_cargos_empresa ON gobernanza.empresa;
CREATE TRIGGER trg_validar_cargos_empresa BEFORE INSERT OR UPDATE OF id_jefe_talento_humano, id_representante_legal ON gobernanza.empresa
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_validar_cargos_empresa();

-- 4. Escalamiento: la cadena de jefes desde un jefe hasta la máxima autoridad (y más arriba, si sigue en otra entidad)
CREATE OR REPLACE FUNCTION gobernanza.fn_cadena_jefes(p_id_jefe BIGINT)
RETURNS TABLE (paso INT, id_jefe BIGINT, jefe TEXT, nivel TEXT, empresa TEXT, activo BOOLEAN) AS $$
    WITH RECURSIVE c AS (
        SELECT 1 AS paso, j.id_jefe, j.id_jefe_directo, ARRAY[j.id_jefe] AS visto
          FROM gobernanza.jefe_empresa j WHERE j.id_jefe = p_id_jefe
        UNION ALL
        SELECT c.paso + 1, j.id_jefe, j.id_jefe_directo, c.visto || j.id_jefe
          FROM c JOIN gobernanza.jefe_empresa j ON j.id_jefe = c.id_jefe_directo
         WHERE NOT j.id_jefe = ANY(c.visto) AND c.paso < 50
    )
    SELECT c.paso, c.id_jefe, p.primer_nombre || ' ' || p.primer_apellido, j.cargo_nivel::TEXT, e.nombre_empresa::TEXT, j.activo
      FROM c
      JOIN gobernanza.jefe_empresa j ON j.id_jefe = c.id_jefe
      JOIN gobernanza.persona p ON p.id_persona = j.id_persona
      JOIN gobernanza.empresa e ON e.id_empresa = j.id_empresa
     ORDER BY c.paso;
$$ LANGUAGE sql STABLE;

-- A quién escalar la queja de cada afiliado y con quién negociar en su empresa
CREATE OR REPLACE VIEW gobernanza.v_escalamiento_afiliados WITH (security_invoker = true) AS
SELECT pa.primer_nombre || ' ' || pa.primer_apellido AS afiliado,
       em.nombre_empresa AS empresa,
       est.nombre_estamento AS junta,
       (SELECT string_agg(c.jefe || ' (' || replace(c.nivel, 'NIVEL', 'nivel') || CASE WHEN c.empresa <> em.nombre_empresa THEN ', ' || c.empresa ELSE '' END
                          || CASE WHEN NOT c.activo THEN ', INACTIVO' ELSE '' END || ')', ' → ' ORDER BY c.paso)
          FROM gobernanza.fn_cadena_jefes(ae.id_jefe_directo) c) AS cadena_de_escalamiento,
       (SELECT pr.primer_nombre || ' ' || pr.primer_apellido FROM gobernanza.jefe_empresa jr
          JOIN gobernanza.persona pr ON pr.id_persona = jr.id_persona WHERE jr.id_jefe = em.id_representante_legal) AS representante_legal,
       (SELECT pt.primer_nombre || ' ' || pt.primer_apellido FROM gobernanza.jefe_empresa jt
          JOIN gobernanza.persona pt ON pt.id_persona = jt.id_persona WHERE jt.id_jefe = em.id_jefe_talento_humano) AS jefe_talento_humano,
       CASE WHEN ae.id_jefe_directo IS NULL THEN 'ALERTA MEDIA: SIN JEFE DIRECTO REGISTRADO (NO HAY A QUIÉN ESCALAR)'
            WHEN EXISTS (SELECT 1 FROM gobernanza.fn_cadena_jefes(ae.id_jefe_directo) c WHERE NOT c.activo)
                 THEN 'ALERTA MEDIA: LA CADENA TIENE UN JEFE INACTIVO'
            WHEN NOT EXISTS (SELECT 1 FROM gobernanza.fn_cadena_jefes(ae.id_jefe_directo) c WHERE c.nivel = 'NIVEL 4')
                 THEN 'ALERTA MEDIA: LA CADENA NO LLEGA A LA MÁXIMA AUTORIDAD (NIVEL 4)'
            WHEN em.id_representante_legal IS NULL THEN 'ALERTA MEDIA: LA EMPRESA NO TIENE REPRESENTANTE LEGAL REGISTRADO'
            ELSE 'COMPLETA' END AS diagnostico,
       ae.id_persona, ae.id_empresa, a.id_estamento_pertenencia AS id_estamento
  FROM gobernanza.afiliado_empresa ae
  JOIN gobernanza.afiliado a ON a.id_persona = ae.id_persona AND a.activo
  JOIN gobernanza.persona pa ON pa.id_persona = ae.id_persona
  JOIN gobernanza.empresa em ON em.id_empresa = ae.id_empresa
  LEFT JOIN gobernanza.estamento est ON est.id_estamento = a.id_estamento_pertenencia;
COMMENT ON VIEW gobernanza.v_escalamiento_afiliados IS
    'Cadena de jefes de cada afiliado hasta la máxima autoridad (a quién escalar una queja) y el representante legal de su empresa (con quién negociar).';

-- Revisión de la jerarquía de jefes
CREATE OR REPLACE VIEW gobernanza.v_auditoria_jefes WITH (security_invoker = true) AS
SELECT p.primer_nombre || ' ' || p.primer_apellido AS jefe, e.nombre_empresa AS empresa, j.cargo_nivel AS nivel,
       (SELECT d.primer_nombre || ' ' || d.primer_apellido FROM gobernanza.jefe_empresa jd
          JOIN gobernanza.persona d ON d.id_persona = jd.id_persona WHERE jd.id_jefe = j.id_jefe_directo) AS jefe_directo,
       (j.id_jefe = e.id_representante_legal) AS es_representante_legal,
       (j.id_jefe = e.id_jefe_talento_humano) AS es_jefe_talento_humano,
       CASE WHEN j.nivel_por_revisar THEN 'ALERTA MEDIA: NIVEL POR REVISAR CON LA ESCALA NUEVA (1 A 4)'
            WHEN j.id_jefe_directo IS NULL AND j.cargo_nivel <> 'NIVEL 4' THEN 'ALERTA MEDIA: SIN JEFE DIRECTO (NO SE PUEDE ESCALAR)'
            WHEN j.id_jefe = e.id_representante_legal AND j.cargo_nivel <> 'NIVEL 4'
                 THEN 'REVISAR: EL REPRESENTANTE LEGAL NO ES LA MÁXIMA AUTORIDAD (NIVEL 4)'
            ELSE 'CORRECTO' END AS diagnostico,
       j.id_jefe, j.id_empresa
  FROM gobernanza.jefe_empresa j
  JOIN gobernanza.persona p ON p.id_persona = j.id_persona
  JOIN gobernanza.empresa e ON e.id_empresa = j.id_empresa
 WHERE j.activo;
COMMENT ON VIEW gobernanza.v_auditoria_jefes IS 'Jefes de empresa activos: nivel por revisar, falta de jefe directo y representante legal que no es nivel 4.';

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        GRANT SELECT ON gobernanza.v_escalamiento_afiliados, gobernanza.v_auditoria_jefes TO sgs_app;
        GRANT UPDATE (nivel_por_revisar) ON gobernanza.jefe_empresa TO sgs_app;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_lectura') THEN
        GRANT SELECT ON gobernanza.v_escalamiento_afiliados, gobernanza.v_auditoria_jefes TO sgs_lectura;
    END IF;
END $$;
