-- ============================================================================
-- SGSINDICAL v9.1 — 02: SEGURIDAD, AUDITORÍA, CONCURRENCIA E ÍNDICES
-- Ejecutar DESPUÉS de 01_sgsindical_v9_1_estructura.sql
-- ============================================================================
CREATE SCHEMA IF NOT EXISTS seguridad;

-- ----------------------------------------------------------------------------
-- A. ROLES DE APLICACIÓN Y MATRIZ DE PERMISOS (por módulo y por acción)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS seguridad.rol_app (
    codigo_rol VARCHAR(30) PRIMARY KEY,
    nombre_rol VARCHAR(100) NOT NULL,
    descripcion TEXT,
    es_sistema BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS seguridad.permiso_rol (
    codigo_rol VARCHAR(30) NOT NULL REFERENCES seguridad.rol_app(codigo_rol) ON DELETE CASCADE,
    modulo VARCHAR(30) NOT NULL CHECK (modulo IN ('GOBERNANZA', 'DOCUMENTAL', 'FINANZAS', 'AUDITORIA', 'ADMINISTRACION')),
    puede_consultar BOOLEAN NOT NULL DEFAULT FALSE,
    puede_registrar BOOLEAN NOT NULL DEFAULT FALSE,
    puede_actualizar BOOLEAN NOT NULL DEFAULT FALSE,
    puede_eliminar BOOLEAN NOT NULL DEFAULT FALSE,
    puede_ver_vistas BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (codigo_rol, modulo)
);
COMMENT ON TABLE seguridad.permiso_rol IS 'Matriz de permisos: qué puede hacer cada rol (consultar, registrar, actualizar, eliminar, ver vistas) en cada módulo.';

CREATE TABLE IF NOT EXISTS seguridad.usuario (
    id_usuario BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre_usuario VARCHAR(50) NOT NULL UNIQUE CHECK (nombre_usuario ~ '^[a-zA-Z0-9._-]{3,50}$'),
    nombre_completo VARCHAR(150) NOT NULL,
    correo_electronico VARCHAR(100),
    hash_contrasena VARCHAR(255) NOT NULL,
    codigo_rol VARCHAR(30) NOT NULL REFERENCES seguridad.rol_app(codigo_rol) ON DELETE RESTRICT,
    id_persona BIGINT REFERENCES gobernanza.persona(id_persona) ON DELETE SET NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    intentos_fallidos INT NOT NULL DEFAULT 0,
    bloqueado_hasta TIMESTAMP WITH TIME ZONE,
    debe_cambiar_contrasena BOOLEAN NOT NULL DEFAULT TRUE,
    fecha_cambio_contrasena TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    fecha_ultimo_acceso TIMESTAMP WITH TIME ZONE,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual()
);
COMMENT ON COLUMN seguridad.usuario.hash_contrasena IS 'PBKDF2-SHA256 con sal aleatoria. Nunca se guarda la contraseña en claro.';

-- Sesiones emitidas (permite cerrar sesión y revocar accesos de inmediato)
CREATE TABLE IF NOT EXISTS seguridad.sesion (
    id_sesion UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_usuario BIGINT NOT NULL REFERENCES seguridad.usuario(id_usuario) ON DELETE CASCADE,
    fecha_emision TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_expiracion TIMESTAMP WITH TIME ZONE NOT NULL,
    ultima_actividad TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    revocada BOOLEAN NOT NULL DEFAULT FALSE,
    ip_origen INET,
    equipo VARCHAR(200)
);

INSERT INTO seguridad.rol_app (codigo_rol, nombre_rol, descripcion, es_sistema) VALUES
    ('ADMIN',     'Administrador del sistema', 'Control total, usuarios, permisos, backups e índices.', TRUE),
    ('DIRECTIVO', 'Directivo sindical',        'Gestiona gobernanza y gestión documental.', FALSE),
    ('TESORERO',  'Tesorería',                 'Gestiona el módulo financiero y consulta el resto.', FALSE),
    ('AUDITOR',   'Auditor / Fiscal',          'Solo lectura de todo, incluidas bitácoras y vistas de auditoría.', FALSE),
    ('CONSULTA',  'Consulta',                  'Solo lectura de gobernanza y documentos.', FALSE)
ON CONFLICT (codigo_rol) DO NOTHING;

INSERT INTO seguridad.permiso_rol (codigo_rol, modulo, puede_consultar, puede_registrar, puede_actualizar, puede_eliminar, puede_ver_vistas) VALUES
    ('ADMIN','GOBERNANZA',TRUE,TRUE,TRUE,TRUE,TRUE), ('ADMIN','DOCUMENTAL',TRUE,TRUE,TRUE,TRUE,TRUE),
    ('ADMIN','FINANZAS',TRUE,TRUE,TRUE,TRUE,TRUE),   ('ADMIN','AUDITORIA',TRUE,FALSE,FALSE,FALSE,TRUE),
    ('ADMIN','ADMINISTRACION',TRUE,TRUE,TRUE,TRUE,TRUE),
    ('DIRECTIVO','GOBERNANZA',TRUE,TRUE,TRUE,FALSE,TRUE), ('DIRECTIVO','DOCUMENTAL',TRUE,TRUE,TRUE,FALSE,TRUE),
    ('DIRECTIVO','FINANZAS',TRUE,FALSE,FALSE,FALSE,TRUE),
    ('TESORERO','GOBERNANZA',TRUE,FALSE,FALSE,FALSE,FALSE), ('TESORERO','DOCUMENTAL',TRUE,FALSE,FALSE,FALSE,FALSE),
    ('TESORERO','FINANZAS',TRUE,TRUE,TRUE,TRUE,TRUE),
    ('AUDITOR','GOBERNANZA',TRUE,FALSE,FALSE,FALSE,TRUE), ('AUDITOR','DOCUMENTAL',TRUE,FALSE,FALSE,FALSE,TRUE),
    ('AUDITOR','FINANZAS',TRUE,FALSE,FALSE,FALSE,TRUE),   ('AUDITOR','AUDITORIA',TRUE,FALSE,FALSE,FALSE,TRUE),
    ('CONSULTA','GOBERNANZA',TRUE,FALSE,FALSE,FALSE,FALSE), ('CONSULTA','DOCUMENTAL',TRUE,FALSE,FALSE,FALSE,FALSE)
ON CONFLICT (codigo_rol, modulo) DO NOTHING;

-- ----------------------------------------------------------------------------
-- B. AUDITORÍA DE ACCESOS Y DE BACKUPS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS auditoria.registro_acceso (
    id_acceso BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre_usuario VARCHAR(50) NOT NULL,
    evento VARCHAR(30) NOT NULL CHECK (evento IN ('LOGIN_OK', 'LOGIN_FALLIDO', 'CUENTA_BLOQUEADA', 'LOGOUT',
                                                   'CAMBIO_CONTRASENA', 'ACCESO_DENEGADO', 'SESION_REVOCADA')),
    fecha_hora TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ip_origen INET,
    detalle TEXT
);

CREATE TABLE IF NOT EXISTS auditoria.registro_backup (
    id_backup BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre_archivo VARCHAR(255) NOT NULL,
    tipo VARCHAR(20) NOT NULL DEFAULT 'COMPLETO' CHECK (tipo IN ('COMPLETO', 'ESQUEMA', 'DATOS')),
    origen VARCHAR(20) NOT NULL DEFAULT 'PROGRAMADO' CHECK (origen IN ('PROGRAMADO', 'MANUAL')),
    estado VARCHAR(20) NOT NULL CHECK (estado IN ('EXITOSO', 'FALLIDO')),
    tamano_bytes BIGINT,
    hash_sha256 VARCHAR(64),
    fecha_inicio TIMESTAMP WITH TIME ZONE NOT NULL,
    fecha_fin TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    detalle TEXT
);

-- Inmutabilidad: nadie (ni la aplicación) puede alterar o borrar los registros de auditoría.
CREATE OR REPLACE FUNCTION auditoria.fn_bloquear_modificacion()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'POLÍTICA DE AUDITORÍA: la tabla %.% es inmutable (operación % rechazada).', TG_TABLE_SCHEMA, TG_TABLE_NAME, TG_OP;
END;
$$ LANGUAGE plpgsql;

DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['auditoria.bitacora_cambios', 'auditoria.registro_acceso', 'auditoria.registro_backup'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_inmutable ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_inmutable BEFORE UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_bloquear_modificacion()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_inmutable_truncate ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_inmutable_truncate BEFORE TRUNCATE ON %s FOR EACH STATEMENT EXECUTE FUNCTION auditoria.fn_bloquear_modificacion()', t);
    END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- C. CONTROL DE CONCURRENCIA OPTIMISTA (columna version) + AUDITORÍA EN TODAS LAS TABLAS
-- ----------------------------------------------------------------------------
-- La aplicación actualiza con "WHERE pk = ... AND version = <versión leída>".
-- Si otro usuario guardó antes, la versión ya cambió, no se actualiza ninguna fila
-- y la aplicación informa el conflicto en lugar de sobrescribir.
CREATE OR REPLACE FUNCTION auditoria.fn_control_version()
RETURNS TRIGGER AS $$
BEGIN
    NEW.version := OLD.version + 1;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION gobernanza.fn_persona_modificacion()
RETURNS TRIGGER AS $$
BEGIN
    NEW.fecha_modificacion := CURRENT_TIMESTAMP;
    NEW.usuario_modificacion := auditoria.fn_usuario_actual();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_persona_modificacion ON gobernanza.persona;
CREATE TRIGGER trg_persona_modificacion BEFORE UPDATE ON gobernanza.persona
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_persona_modificacion();

DO $$
DECLARE
    t TEXT;
    tablas TEXT[] := ARRAY[
        'gobernanza.persona', 'gobernanza.afiliado', 'gobernanza.inspector', 'gobernanza.empresa',
        'gobernanza.sede_empresa', 'gobernanza.jefe_empresa', 'gobernanza.afiliado_empresa',
        'gobernanza.estamento', 'gobernanza.registro_inspector_estamento', 'gobernanza.directivo_estamento',
        'gobernanza.comite', 'gobernanza.comite_miembro',
        'gestion_documental.tipo_documento', 'gestion_documental.expediente', 'gestion_documental.documento',
        'gestion_documental.historial_tramite', 'gestion_documental.compromiso_tarea',
        'gestion_documental.historial_avance_compromiso',
        'finanzas.cuenta_bancaria', 'finanzas.consignacion_empresa', 'finanzas.aporte_afiliado',
        'seguridad.rol_app', 'seguridad.permiso_rol', 'seguridad.usuario'];
BEGIN
    FOREACH t IN ARRAY tablas LOOP
        EXECUTE format('ALTER TABLE %s ADD COLUMN IF NOT EXISTS version INT NOT NULL DEFAULT 1', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_control_version ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_control_version BEFORE UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version()', t);
        -- Auditoría de cambios en TODAS las tablas (el script original solo cubría 7)
        EXECUTE format('DROP TRIGGER IF EXISTS trg_auditoria ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria()', t);
    END LOOP;
END $$;

-- Se eliminan los triggers de auditoría individuales del script original para no duplicar registros.
DROP TRIGGER IF EXISTS trg_auditoria_persona ON gobernanza.persona;
DROP TRIGGER IF EXISTS trg_auditoria_afiliado ON gobernanza.afiliado;
DROP TRIGGER IF EXISTS trg_auditoria_empresa ON gobernanza.empresa;
DROP TRIGGER IF EXISTS trg_auditoria_consignacion ON finanzas.consignacion_empresa;
DROP TRIGGER IF EXISTS trg_auditoria_documento ON gestion_documental.documento;
DROP TRIGGER IF EXISTS trg_auditoria_compromisos ON gestion_documental.compromiso_tarea;
DROP TRIGGER IF EXISTS trg_auditoria_expediente ON gestion_documental.expediente;

-- El hash de la contraseña no se copia a la bitácora.
CREATE OR REPLACE FUNCTION auditoria.fn_generar_auditoria()
RETURNS TRIGGER AS $$
DECLARE
    v_usuario VARCHAR := auditoria.fn_usuario_actual();
    v_ip INET := COALESCE(NULLIF(current_setting('app.ip', true), '')::INET, inet_client_addr());
    v_old JSONB;
    v_new JSONB;
BEGIN
    IF TG_OP IN ('UPDATE', 'DELETE') THEN v_old := to_jsonb(OLD) - 'hash_contrasena'; END IF;
    IF TG_OP IN ('UPDATE', 'INSERT') THEN v_new := to_jsonb(NEW) - 'hash_contrasena'; END IF;
    INSERT INTO auditoria.bitacora_cambios(esquema_tabla, nombre_tabla, operacion, usuario_bd, datos_anteriores, datos_nuevos, ip_origen)
    VALUES (TG_TABLE_SCHEMA, TG_TABLE_NAME, TG_OP, v_usuario, v_old, v_new, v_ip);
    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- D. AUTOMATIZACIONES DE TRAZABILIDAD
-- ----------------------------------------------------------------------------
-- Historial de trámite automático al radicar y en cada cambio de estado.
CREATE OR REPLACE FUNCTION gestion_documental.fn_registrar_historial_tramite()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO gestion_documental.historial_tramite (id_documento, estado_anterior, estado_nuevo, observaciones)
        VALUES (NEW.id_documento, NULL, COALESCE(NEW.estado_tramite, 'RADICADO'), 'Radicación inicial ' || NEW.radicado_alfanumerico);
    ELSIF NEW.estado_tramite IS DISTINCT FROM OLD.estado_tramite THEN
        INSERT INTO gestion_documental.historial_tramite (id_documento, estado_anterior, estado_nuevo, observaciones)
        VALUES (NEW.id_documento, OLD.estado_tramite, NEW.estado_tramite, NULLIF(current_setting('app.observacion', true), ''));
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_historial_tramite ON gestion_documental.documento;
CREATE TRIGGER trg_historial_tramite AFTER INSERT OR UPDATE OF estado_tramite ON gestion_documental.documento
    FOR EACH ROW EXECUTE FUNCTION gestion_documental.fn_registrar_historial_tramite();

-- El radicado es inmutable una vez asignado.
CREATE OR REPLACE FUNCTION gestion_documental.fn_proteger_radicado()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.radicado_alfanumerico IS DISTINCT FROM OLD.radicado_alfanumerico THEN
        RAISE EXCEPTION 'El radicado % es inmutable y no puede modificarse.', OLD.radicado_alfanumerico;
    END IF;
    IF NEW.hash_sha256 IS DISTINCT FROM OLD.hash_sha256 AND OLD.hash_sha256 IS NOT NULL THEN
        RAISE EXCEPTION 'El documento % ya tiene un archivo con huella SHA-256 registrada; no puede reemplazarse.', OLD.radicado_alfanumerico;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_proteger_radicado ON gestion_documental.documento;
CREATE TRIGGER trg_proteger_radicado BEFORE UPDATE ON gestion_documental.documento
    FOR EACH ROW EXECUTE FUNCTION gestion_documental.fn_proteger_radicado();

-- Registrar un avance actualiza el porcentaje del compromiso (y dispara su estado).
CREATE OR REPLACE FUNCTION gestion_documental.fn_aplicar_avance_compromiso()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE gestion_documental.compromiso_tarea
       SET porcentaje_avance = NEW.porcentaje_avance_registrado
     WHERE id_compromiso = NEW.id_compromiso;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_aplicar_avance ON gestion_documental.historial_avance_compromiso;
CREATE TRIGGER trg_aplicar_avance AFTER INSERT ON gestion_documental.historial_avance_compromiso
    FOR EACH ROW EXECUTE FUNCTION gestion_documental.fn_aplicar_avance_compromiso();

-- ----------------------------------------------------------------------------
-- E. GESTIÓN DE ÍNDICES
-- ----------------------------------------------------------------------------
-- PostgreSQL NO crea índices automáticamente en las llaves foráneas. Sin ellos,
-- los JOIN de las vistas y los ON DELETE CASCADE/SET NULL recorren tablas completas.
CREATE INDEX IF NOT EXISTS ix_sede_empresa_empresa        ON gobernanza.sede_empresa (id_empresa);
CREATE INDEX IF NOT EXISTS ix_sede_empresa_encargado      ON gobernanza.sede_empresa (id_encargado_persona);
CREATE INDEX IF NOT EXISTS ix_jefe_empresa_empresa        ON gobernanza.jefe_empresa (id_empresa);
CREATE INDEX IF NOT EXISTS ix_jefe_empresa_jefe_directo   ON gobernanza.jefe_empresa (id_jefe_directo);
CREATE INDEX IF NOT EXISTS ix_empresa_jefe_th             ON gobernanza.empresa (id_jefe_talento_humano);
CREATE INDEX IF NOT EXISTS ix_empresa_rep_legal           ON gobernanza.empresa (id_representante_legal);
CREATE INDEX IF NOT EXISTS ix_afiliado_empresa_empresa    ON gobernanza.afiliado_empresa (id_empresa);
CREATE INDEX IF NOT EXISTS ix_afiliado_empresa_jefe       ON gobernanza.afiliado_empresa (id_jefe_directo);
CREATE INDEX IF NOT EXISTS ix_registro_insp_inspector     ON gobernanza.registro_inspector_estamento (id_inspector);
CREATE INDEX IF NOT EXISTS ix_registro_insp_documento     ON gobernanza.registro_inspector_estamento (id_documento_radicado);
CREATE INDEX IF NOT EXISTS ix_directivo_persona           ON gobernanza.directivo_estamento (id_persona);
CREATE INDEX IF NOT EXISTS ix_directivo_estamento         ON gobernanza.directivo_estamento (id_estamento);
CREATE INDEX IF NOT EXISTS ix_directivo_registro          ON gobernanza.directivo_estamento (id_registro_inspector);
CREATE INDEX IF NOT EXISTS ix_directivo_fin_vigencia      ON gobernanza.directivo_estamento (fecha_fin_vigencia_programada);
CREATE INDEX IF NOT EXISTS ix_comite_empresa              ON gobernanza.comite (id_empresa);
CREATE INDEX IF NOT EXISTS ix_comite_miembro_persona      ON gobernanza.comite_miembro (id_persona);
CREATE INDEX IF NOT EXISTS ix_persona_nombre              ON gobernanza.persona (primer_apellido, primer_nombre);

CREATE INDEX IF NOT EXISTS ix_expediente_estamento        ON gestion_documental.expediente (id_estamento_custodio);
CREATE INDEX IF NOT EXISTS ix_expediente_responsable      ON gestion_documental.expediente (id_persona_responsable);
CREATE INDEX IF NOT EXISTS ix_expediente_estado           ON gestion_documental.expediente (estado_expediente);
CREATE INDEX IF NOT EXISTS ix_documento_expediente_folio  ON gestion_documental.documento (id_expediente, numero_folio);
CREATE INDEX IF NOT EXISTS ix_documento_estamento_tipo_fecha ON gestion_documental.documento (id_estamento, id_tipo_documento, fecha_radicacion DESC);
CREATE INDEX IF NOT EXISTS ix_documento_tipo              ON gestion_documental.documento (id_tipo_documento);
CREATE INDEX IF NOT EXISTS ix_documento_remitente         ON gestion_documental.documento (id_persona_remitente);
CREATE INDEX IF NOT EXISTS ix_documento_padre             ON gestion_documental.documento (id_documento_padre);
CREATE INDEX IF NOT EXISTS ix_documento_fecha             ON gestion_documental.documento (fecha_radicacion DESC);
CREATE INDEX IF NOT EXISTS ix_documento_pendientes        ON gestion_documental.documento (estado_tramite)
    WHERE estado_tramite IN ('RADICADO', 'EN_TRAMITE');
CREATE INDEX IF NOT EXISTS ix_historial_tramite_doc       ON gestion_documental.historial_tramite (id_documento, fecha_movimiento);
CREATE INDEX IF NOT EXISTS ix_compromiso_documento        ON gestion_documental.compromiso_tarea (id_documento_origen);
CREATE INDEX IF NOT EXISTS ix_compromiso_estamento        ON gestion_documental.compromiso_tarea (id_estamento);
CREATE INDEX IF NOT EXISTS ix_compromiso_responsable      ON gestion_documental.compromiso_tarea (id_persona_responsable);
CREATE INDEX IF NOT EXISTS ix_compromiso_supervisor       ON gestion_documental.compromiso_tarea (id_persona_supervisor);
CREATE INDEX IF NOT EXISTS ix_compromiso_evidencia        ON gestion_documental.compromiso_tarea (id_documento_evidencia);
CREATE INDEX IF NOT EXISTS ix_compromiso_abiertos         ON gestion_documental.compromiso_tarea (fecha_limite_cumplimiento)
    WHERE estado_compromiso IN ('PENDIENTE', 'EN_PROCESO');
CREATE INDEX IF NOT EXISTS ix_avance_compromiso           ON gestion_documental.historial_avance_compromiso (id_compromiso);
CREATE INDEX IF NOT EXISTS ix_avance_soporte              ON gestion_documental.historial_avance_compromiso (id_documento_soporte);

CREATE INDEX IF NOT EXISTS ix_cuenta_estamento            ON finanzas.cuenta_bancaria (id_estamento);
CREATE INDEX IF NOT EXISTS ix_consignacion_cuenta         ON finanzas.consignacion_empresa (id_cuenta_destino);
CREATE INDEX IF NOT EXISTS ix_aporte_consignacion         ON finanzas.aporte_afiliado (id_consignacion);
CREATE INDEX IF NOT EXISTS ix_aporte_persona_periodo      ON finanzas.aporte_afiliado (id_persona, periodo_anio, periodo_mes);

CREATE INDEX IF NOT EXISTS ix_bitacora_fecha              ON auditoria.bitacora_cambios (fecha_hora DESC);
CREATE INDEX IF NOT EXISTS ix_bitacora_tabla              ON auditoria.bitacora_cambios (esquema_tabla, nombre_tabla, fecha_hora DESC);
CREATE INDEX IF NOT EXISTS ix_bitacora_usuario            ON auditoria.bitacora_cambios (usuario_bd, fecha_hora DESC);
CREATE INDEX IF NOT EXISTS ix_acceso_usuario_fecha        ON auditoria.registro_acceso (nombre_usuario, fecha_hora DESC);
CREATE INDEX IF NOT EXISTS ix_acceso_fecha                ON auditoria.registro_acceso (fecha_hora DESC);
CREATE INDEX IF NOT EXISTS ix_usuario_rol                 ON seguridad.usuario (codigo_rol);
CREATE INDEX IF NOT EXISTS ix_usuario_persona             ON seguridad.usuario (id_persona);
CREATE INDEX IF NOT EXISTS ix_sesion_usuario              ON seguridad.sesion (id_usuario, revocada);

-- Monitor de índices: tamaño, uso y diagnóstico.
CREATE OR REPLACE VIEW auditoria.v_monitor_indices AS
SELECT
    s.schemaname AS esquema,
    s.relname AS tabla,
    s.indexrelname AS indice,
    pg_size_pretty(pg_relation_size(s.indexrelid)) AS tamano,
    pg_relation_size(s.indexrelid) AS tamano_bytes,
    s.idx_scan AS veces_usado,
    i.indisunique AS es_unico,
    i.indisprimary AS es_llave_primaria,
    NOT i.indisvalid AS es_invalido,
    pg_get_indexdef(s.indexrelid) AS definicion,
    CASE
        WHEN NOT i.indisvalid THEN 'ALERTA CRÍTICA: ÍNDICE INVÁLIDO, REQUIERE REINDEX'
        WHEN s.idx_scan = 0 AND NOT i.indisunique AND NOT i.indisprimary
             AND pg_relation_size(s.indexrelid) > 10 * 1024 * 1024 THEN 'ALERTA MEDIA: ÍNDICE GRANDE SIN USO'
        WHEN s.idx_scan = 0 AND NOT i.indisunique AND NOT i.indisprimary THEN 'SIN USO AÚN (VIGILAR)'
        ELSE 'EN USO / NORMAL'
    END AS diagnostico
FROM pg_stat_user_indexes s
JOIN pg_index i ON i.indexrelid = s.indexrelid
WHERE s.schemaname IN ('gobernanza', 'finanzas', 'gestion_documental', 'auditoria', 'seguridad');

-- Monitor de tablas: lecturas secuenciales vs índices, filas muertas y mantenimiento.
CREATE OR REPLACE VIEW auditoria.v_monitor_tablas AS
SELECT
    t.schemaname AS esquema,
    t.relname AS tabla,
    t.n_live_tup AS filas_vivas,
    t.n_dead_tup AS filas_muertas,
    pg_size_pretty(pg_total_relation_size(t.relid)) AS tamano_total,
    t.seq_scan AS lecturas_secuenciales,
    COALESCE(t.idx_scan, 0) AS lecturas_por_indice,
    GREATEST(t.last_vacuum, t.last_autovacuum) AS ultimo_vacuum,
    GREATEST(t.last_analyze, t.last_autoanalyze) AS ultimo_analyze,
    CASE
        WHEN t.n_live_tup > 0 AND t.n_dead_tup::NUMERIC / t.n_live_tup > 0.2 THEN 'ALERTA ALTA: MÁS DEL 20% DE FILAS MUERTAS (VACUUM)'
        WHEN t.n_live_tup > 10000 AND t.seq_scan > COALESCE(t.idx_scan, 0) * 10 THEN 'ALERTA MEDIA: MUCHAS LECTURAS SECUENCIALES (REVISAR ÍNDICES)'
        ELSE 'NORMAL'
    END AS diagnostico
FROM pg_stat_user_tables t
WHERE t.schemaname IN ('gobernanza', 'finanzas', 'gestion_documental', 'auditoria', 'seguridad');

-- Llaves foráneas sin índice (debe devolver 0 filas; sirve para vigilar cambios futuros).
CREATE OR REPLACE VIEW auditoria.v_fk_sin_indice AS
SELECT
    n.nspname AS esquema,
    c.relname AS tabla,
    con.conname AS llave_foranea,
    pg_get_constraintdef(con.oid) AS definicion,
    'CREATE INDEX ON ' || quote_ident(n.nspname) || '.' || quote_ident(c.relname) || ' (' ||
        (SELECT string_agg(quote_ident(a.attname), ', ' ORDER BY k.ord)
           FROM unnest(con.conkey) WITH ORDINALITY k(attnum, ord)
           JOIN pg_attribute a ON a.attrelid = con.conrelid AND a.attnum = k.attnum) || ');' AS sugerencia
FROM pg_constraint con
JOIN pg_class c ON c.oid = con.conrelid
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE con.contype = 'f'
  AND n.nspname IN ('gobernanza', 'finanzas', 'gestion_documental', 'auditoria', 'seguridad')
  AND NOT EXISTS (
      SELECT 1 FROM pg_index i
      WHERE i.indrelid = con.conrelid
        AND (i.indkey::INT2[])[0:array_length(con.conkey, 1) - 1] = con.conkey
  );

-- ============================================================================
-- FIN 02
-- ============================================================================
