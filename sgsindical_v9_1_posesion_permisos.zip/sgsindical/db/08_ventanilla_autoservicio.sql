-- ============================================================================
-- SGSINDICAL v9.1 — 08: VENTANILLA (VEN) Y AUTOSERVICIO DEL AFILIADO (AFI)
-- Ejecutar DESPUÉS de 07. No modifica los scripts anteriores: los complementa.
-- ----------------------------------------------------------------------------
--  V1. ROL VENTANILLA: atiende al público en su subdirectiva (ámbito asignado). Radica documentos,
--      registra personas con datos básicos, recibe SOLICITUDES DE AFILIACIÓN y autorizaciones de
--      datos. No afilia (lo aprueba un directivo), no ve salarios ni datos sensibles, no entra a
--      finanzas, y no inactiva registros.
--  V2. SOLICITUD DE AFILIACIÓN: queda pendiente hasta que el Presidente o el Secretario General de
--      la junta la aprueban; al aprobarla se crean el afiliado, su empresa y su salario.
--  A1. ROL AFILIADO: cada afiliado puede tener una cuenta propia, creada por INVITACIÓN de su junta
--      (enlace de un solo uso, 48 horas). En la activación acepta la política de datos en línea.
--  A2. "SOLO LO MÍO": el afiliado no usa las pantallas generales. Todo lo que ve sale de funciones que
--      devuelven únicamente los datos de la persona ligada a su usuario (perfil, aportes, certificados,
--      solicitudes y quién consultó sus datos). Directivos y personal ligados a un afiliado ven lo
--      mismo en "Mi espacio".
--  A3. CERTIFICADOS de afiliación y paz y salvo con código de verificación y huella SHA-256. Si la
--      empresa no consignó algún mes, el paz y salvo se expide con una nota (la deuda es de la empresa).
--      Cualquier entidad verifica el código en una página pública que no muestra datos sensibles.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. ROLES NUEVOS Y RESTRICCIÓN POR RECURSO
-- ----------------------------------------------------------------------------
INSERT INTO seguridad.rol_app (codigo_rol, nombre_rol, descripcion, es_sistema) VALUES
    ('VENTANILLA', 'Ventanilla / personal de apoyo',
     'Atiende al público en su subdirectiva: radica documentos, registra personas y recibe solicitudes de afiliación. No afilia ni ve salarios.', TRUE),
    ('AFILIADO', 'Afiliado (autoservicio)',
     'Solo consulta sus propios datos, aportes, certificados y solicitudes en el portal del afiliado.', TRUE)
ON CONFLICT (codigo_rol) DO NOTHING;

INSERT INTO seguridad.permiso_rol (codigo_rol, modulo, puede_consultar, puede_registrar, puede_actualizar, puede_eliminar, puede_ver_vistas) VALUES
    ('VENTANILLA', 'GOBERNANZA', TRUE, TRUE, TRUE, FALSE, FALSE),
    ('VENTANILLA', 'DOCUMENTAL', TRUE, TRUE, FALSE, FALSE, FALSE),
    ('VENTANILLA', 'FINANZAS', FALSE, FALSE, FALSE, FALSE, FALSE),
    ('VENTANILLA', 'AUDITORIA', FALSE, FALSE, FALSE, FALSE, FALSE),
    ('VENTANILLA', 'ADMINISTRACION', FALSE, FALSE, FALSE, FALSE, FALSE),
    ('AFILIADO', 'GOBERNANZA', FALSE, FALSE, FALSE, FALSE, FALSE),
    ('AFILIADO', 'DOCUMENTAL', FALSE, FALSE, FALSE, FALSE, FALSE),
    ('AFILIADO', 'FINANZAS', FALSE, FALSE, FALSE, FALSE, FALSE),
    ('AFILIADO', 'AUDITORIA', FALSE, FALSE, FALSE, FALSE, FALSE),
    ('AFILIADO', 'ADMINISTRACION', FALSE, FALSE, FALSE, FALSE, FALSE)
ON CONFLICT (codigo_rol, modulo) DO NOTHING;

-- Si un rol tiene filas aquí, solo puede crear/editar en esos recursos (aunque su módulo lo permita)
CREATE TABLE IF NOT EXISTS seguridad.recurso_permitido_rol (
    codigo_rol VARCHAR(30) NOT NULL REFERENCES seguridad.rol_app(codigo_rol) ON DELETE RESTRICT,
    recurso VARCHAR(60) NOT NULL,
    operaciones TEXT[] NOT NULL,
    version INT NOT NULL DEFAULT 1,
    PRIMARY KEY (codigo_rol, recurso)
);
COMMENT ON TABLE seguridad.recurso_permitido_rol IS 'Restricción fina: los roles listados solo escriben en estos recursos.';
INSERT INTO seguridad.recurso_permitido_rol (codigo_rol, recurso, operaciones) VALUES
    ('VENTANILLA', 'personas', ARRAY['crear', 'editar']),
    ('VENTANILLA', 'solicitudes_afiliacion', ARRAY['crear']),
    ('VENTANILLA', 'autorizaciones_datos', ARRAY['crear']),
    ('VENTANILLA', 'solicitudes_titular', ARRAY['crear']),
    ('VENTANILLA', 'documentos', ARRAY['crear'])
ON CONFLICT (codigo_rol, recurso) DO UPDATE SET operaciones = EXCLUDED.operaciones;

CREATE OR REPLACE FUNCTION seguridad.fn_rol_actual()
RETURNS TEXT AS $$
    SELECT codigo_rol FROM seguridad.usuario WHERE id_usuario = seguridad.fn_id_usuario_actual() AND activo;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Defensa en la base: Ventanilla y Afiliado nunca afilian ni tocan cargos ni salarios directamente
CREATE OR REPLACE FUNCTION seguridad.fn_bloquear_roles_limitados()
RETURNS TRIGGER AS $$
BEGIN
    IF COALESCE(current_setting('afiliacion.operacion', true), '') = 'aprobar' THEN RETURN NEW; END IF;
    IF seguridad.fn_rol_actual() IN ('VENTANILLA', 'AFILIADO') THEN
        RAISE EXCEPTION 'Su rol (%) no puede registrar ni modificar %: la afiliación la aprueba un directivo.',
            lower(seguridad.fn_rol_actual()), replace(TG_TABLE_NAME, '_', ' ') USING ERRCODE = 'insufficient_privilege';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['gobernanza.afiliado', 'gobernanza.afiliado_empresa', 'gobernanza.salario_historico',
                             'gobernanza.directivo_estamento', 'gobernanza.estamento', 'gobernanza.empresa'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_roles_limitados ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_roles_limitados BEFORE INSERT OR UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_roles_limitados()', t);
    END LOOP;
END $$;

-- La persona con cuenta de afiliado que se desafilia pierde el acceso al portal
CREATE OR REPLACE FUNCTION seguridad.fn_desactivar_cuenta_afiliado()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.activo AND NOT NEW.activo THEN
        UPDATE seguridad.usuario SET activo = FALSE, motivo_inactivacion = 'Desafiliación: ' || COALESCE(NEW.motivo_inactivacion, '')
         WHERE id_persona = NEW.id_persona AND codigo_rol = 'AFILIADO' AND activo;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
DROP TRIGGER IF EXISTS trg_desactivar_cuenta_afiliado ON gobernanza.afiliado;
CREATE TRIGGER trg_desactivar_cuenta_afiliado AFTER UPDATE OF activo ON gobernanza.afiliado
    FOR EACH ROW EXECUTE FUNCTION seguridad.fn_desactivar_cuenta_afiliado();

-- ----------------------------------------------------------------------------
-- 2. SOLICITUDES DE AFILIACIÓN
-- ----------------------------------------------------------------------------
CREATE SEQUENCE IF NOT EXISTS gobernanza.seq_solicitud_afiliacion;
CREATE TABLE IF NOT EXISTS gobernanza.solicitud_afiliacion (
    id_solicitud_afiliacion BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    radicado VARCHAR(20) NOT NULL UNIQUE,
    id_persona BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    id_estamento BIGINT NOT NULL REFERENCES gobernanza.estamento(id_estamento) ON DELETE RESTRICT,
    id_empresa BIGINT NOT NULL REFERENCES gobernanza.empresa(id_empresa) ON DELETE RESTRICT,
    id_sede BIGINT REFERENCES gobernanza.sede_empresa(id_sede) ON DELETE RESTRICT,
    fecha_ingreso_empresa DATE NOT NULL,
    salario_base NUMERIC(12,2) NOT NULL CHECK (salario_base > 0),
    fecha_nacimiento DATE NOT NULL,
    nivel_educativo VARCHAR(20) NOT NULL,
    cargo_empresa VARCHAR(20) NOT NULL,
    area_empresa VARCHAR(100),
    medio VARCHAR(12) NOT NULL DEFAULT 'VENTANILLA' CHECK (medio IN ('VENTANILLA', 'CORREO', 'PORTAL')),
    id_documento_soporte BIGINT REFERENCES gestion_documental.documento(id_documento) ON DELETE RESTRICT,
    estado VARCHAR(10) NOT NULL DEFAULT 'PENDIENTE' CHECK (estado IN ('PENDIENTE', 'APROBADA', 'RECHAZADA')),
    fecha_afiliacion DATE,
    fecha_decision TIMESTAMP WITH TIME ZONE,
    usuario_decision VARCHAR(50),
    observacion_decision TEXT,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gobernanza.solicitud_afiliacion IS 'Solicitudes de afiliación recibidas (ventanilla, correo o portal). Las aprueba la Presidencia o la Secretaría General de la junta.';
CREATE INDEX IF NOT EXISTS ix_sol_afil_persona ON gobernanza.solicitud_afiliacion (id_persona);
CREATE INDEX IF NOT EXISTS ix_sol_afil_estamento ON gobernanza.solicitud_afiliacion (id_estamento, estado);
CREATE INDEX IF NOT EXISTS ix_sol_afil_empresa ON gobernanza.solicitud_afiliacion (id_empresa);
CREATE INDEX IF NOT EXISTS ix_sol_afil_sede ON gobernanza.solicitud_afiliacion (id_sede);
CREATE INDEX IF NOT EXISTS ix_sol_afil_soporte ON gobernanza.solicitud_afiliacion (id_documento_soporte);
CREATE UNIQUE INDEX IF NOT EXISTS ux_sol_afil_pendiente ON gobernanza.solicitud_afiliacion (id_persona) WHERE estado = 'PENDIENTE';

-- El salario de la solicitud también es reservado
INSERT INTO seguridad.dato_sensible (tabla, columna, categoria, descripcion) VALUES
    ('gobernanza.solicitud_afiliacion', 'salario_base', 'SALARIO', 'Salario declarado en la solicitud de afiliación.')
ON CONFLICT (tabla, columna) DO NOTHING;

CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_solicitud_afiliacion()
RETURNS TRIGGER AS $$
BEGIN
    IF COALESCE(current_setting('afiliacion.operacion', true), '') IN ('aprobar', 'rechazar') THEN RETURN NEW; END IF;
    IF TG_OP = 'INSERT' THEN
        IF EXISTS (SELECT 1 FROM gobernanza.afiliado WHERE id_persona = NEW.id_persona AND activo) THEN
            RAISE EXCEPTION 'La persona ya es afiliada activa.';
        END IF;
        IF NOT EXISTS (SELECT 1 FROM gobernanza.estamento WHERE id_estamento = NEW.id_estamento AND activo
                          AND tipo_estamento IN ('SUBDIRECTIVA', 'COMITÉ SECCIONAL')) THEN
            RAISE EXCEPTION 'La afiliación se solicita a una subdirectiva o comité activo.';
        END IF;
        NEW.radicado := 'SAF-' || to_char(now() AT TIME ZONE gestion_documental.fn_zona(), 'YYYY') || '-'
                        || lpad(nextval('gobernanza.seq_solicitud_afiliacion')::TEXT, 5, '0');
        NEW.estado := 'PENDIENTE'; NEW.fecha_afiliacion := NULL; NEW.fecha_decision := NULL;
        NEW.usuario_decision := NULL; NEW.observacion_decision := NULL;
        RETURN NEW;
    END IF;
    IF OLD.estado <> 'PENDIENTE' THEN RAISE EXCEPTION 'Una solicitud ya decidida no se modifica.'; END IF;
    IF NEW.estado IS DISTINCT FROM OLD.estado OR NEW.radicado IS DISTINCT FROM OLD.radicado THEN
        RAISE EXCEPTION 'La solicitud se aprueba o se rechaza con su acción.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
DROP TRIGGER IF EXISTS trg_proteger_solicitud_afiliacion ON gobernanza.solicitud_afiliacion;
CREATE TRIGGER trg_proteger_solicitud_afiliacion BEFORE INSERT OR UPDATE ON gobernanza.solicitud_afiliacion
    FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_proteger_solicitud_afiliacion();

CREATE OR REPLACE FUNCTION gobernanza.fn_decidir_solicitud_afiliacion(p_id BIGINT, p_aprobar BOOLEAN, p_fecha_afiliacion DATE DEFAULT NULL,
                                                                     p_observacion TEXT DEFAULT NULL)
RETURNS TEXT AS $$
DECLARE v_s gobernanza.solicitud_afiliacion%ROWTYPE; v_fecha DATE;
BEGIN
    SELECT * INTO v_s FROM gobernanza.solicitud_afiliacion WHERE id_solicitud_afiliacion = p_id FOR UPDATE;
    IF v_s.id_solicitud_afiliacion IS NULL THEN RAISE EXCEPTION 'La solicitud no existe.'; END IF;
    IF v_s.estado <> 'PENDIENTE' THEN RAISE EXCEPTION 'La solicitud ya fue decidida.'; END IF;
    IF NOT (seguridad.fn_es_admin() OR seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'SGEN\_%'], v_s.id_estamento)) THEN
        RAISE EXCEPTION 'La afiliación la aprueban el Presidente o el Secretario General de la junta.';
    END IF;
    IF NOT p_aprobar THEN
        IF length(trim(COALESCE(p_observacion, ''))) < 10 THEN RAISE EXCEPTION 'Escriba el motivo del rechazo (mínimo 10 caracteres).'; END IF;
        PERFORM set_config('afiliacion.operacion', 'rechazar', true);
        UPDATE gobernanza.solicitud_afiliacion SET estado = 'RECHAZADA', fecha_decision = now(), usuario_decision = auditoria.fn_usuario_actual(),
               observacion_decision = trim(p_observacion)
         WHERE id_solicitud_afiliacion = p_id;
        PERFORM set_config('afiliacion.operacion', '', true);
        RETURN 'RECHAZADA';
    END IF;
    v_fecha := COALESCE(p_fecha_afiliacion, (now() AT TIME ZONE gestion_documental.fn_zona())::DATE);
    PERFORM set_config('afiliacion.operacion', 'aprobar', true);
    IF EXISTS (SELECT 1 FROM gobernanza.afiliado WHERE id_persona = v_s.id_persona) THEN
        -- Reafiliación: se reactiva el mismo registro (nada se duplica)
        PERFORM set_config('sgs.operacion', 'sistema', true);
        UPDATE gobernanza.afiliado SET activo = TRUE, fecha_inactivacion = NULL, usuario_inactivacion = NULL, motivo_inactivacion = NULL,
               fecha_afiliacion = v_fecha, id_estamento_pertenencia = v_s.id_estamento
         WHERE id_persona = v_s.id_persona;
        PERFORM set_config('sgs.operacion', '', true);
    ELSE
        INSERT INTO gobernanza.afiliado (id_persona, fecha_afiliacion, fecha_nacimiento, nivel_educativo, cargo_empresa, area_empresa,
                                         id_estamento_pertenencia)
        VALUES (v_s.id_persona, v_fecha, v_s.fecha_nacimiento, v_s.nivel_educativo, v_s.cargo_empresa, v_s.area_empresa, v_s.id_estamento);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM gobernanza.afiliado_empresa WHERE id_persona = v_s.id_persona) THEN
        INSERT INTO gobernanza.afiliado_empresa (id_persona, id_empresa, id_sede, salario_base, fecha_ingreso_empresa)
        VALUES (v_s.id_persona, v_s.id_empresa, v_s.id_sede, v_s.salario_base, v_s.fecha_ingreso_empresa);
    END IF;
    UPDATE gobernanza.solicitud_afiliacion SET estado = 'APROBADA', fecha_afiliacion = v_fecha, fecha_decision = now(),
           usuario_decision = auditoria.fn_usuario_actual(), observacion_decision = NULLIF(trim(COALESCE(p_observacion, '')), '')
     WHERE id_solicitud_afiliacion = p_id;
    PERFORM set_config('afiliacion.operacion', '', true);
    RETURN 'APROBADA';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE VIEW gobernanza.v_auditoria_solicitudes_afiliacion WITH (security_invoker = true) AS
SELECT s.radicado, e.nombre_estamento AS junta, p.primer_nombre || ' ' || p.primer_apellido AS solicitante,
       p.tipo_dni || ' ' || p.dni AS identificacion, em.nombre_empresa AS empresa, s.medio, s.fecha_creacion AS recibida,
       s.usuario_creacion AS recibida_por, s.estado,
       CASE WHEN s.estado = 'PENDIENTE' AND s.fecha_creacion < now() - INTERVAL '15 days'
                THEN 'ALERTA ALTA: SOLICITUD DE AFILIACIÓN SIN DECIDIR HACE MÁS DE 15 DÍAS'
            WHEN s.estado = 'PENDIENTE' THEN 'ALERTA MEDIA: SOLICITUD DE AFILIACIÓN PENDIENTE'
            ELSE s.estado END AS diagnostico,
       s.id_solicitud_afiliacion, s.id_estamento
  FROM gobernanza.solicitud_afiliacion s
  JOIN gobernanza.persona p ON p.id_persona = s.id_persona
  JOIN gobernanza.estamento e ON e.id_estamento = s.id_estamento
  JOIN gobernanza.empresa em ON em.id_empresa = s.id_empresa;

-- ----------------------------------------------------------------------------
-- 3. INVITACIONES Y ACTIVACIÓN DE CUENTAS DE AFILIADO
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS seguridad.invitacion (
    id_invitacion BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tipo VARCHAR(12) NOT NULL DEFAULT 'CUENTA' CHECK (tipo IN ('CUENTA', 'CORREO')),
    id_persona BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    correo VARCHAR(100) NOT NULL,
    hash_token VARCHAR(64) NOT NULL UNIQUE,
    expira TIMESTAMP WITH TIME ZONE NOT NULL,
    usada_en TIMESTAMP WITH TIME ZONE,
    anulada BOOLEAN NOT NULL DEFAULT FALSE,
    id_usuario_creado BIGINT REFERENCES seguridad.usuario(id_usuario) ON DELETE RESTRICT,
    fecha_creacion TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_creacion VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE seguridad.invitacion IS 'Enlaces de un solo uso para crear la cuenta del afiliado o confirmar un correo nuevo. Solo se guarda la huella del enlace.';
CREATE INDEX IF NOT EXISTS ix_invitacion_persona ON seguridad.invitacion (id_persona);
CREATE INDEX IF NOT EXISTS ix_invitacion_usuario ON seguridad.invitacion (id_usuario_creado);

-- La junta invita: solo afiliados activos de su ámbito, con correo registrado y sin cuenta
CREATE OR REPLACE FUNCTION seguridad.fn_crear_invitacion(p_id_persona BIGINT, p_hash_token TEXT)
RETURNS TABLE (correo TEXT, nombre TEXT, expira TIMESTAMPTZ) AS $$
DECLARE v_p RECORD; v_exp TIMESTAMPTZ := now() + INTERVAL '48 hours';
BEGIN
    SELECT p.correo_electronico, p.primer_nombre, a.activo AS afiliado_activo, a.id_estamento_pertenencia INTO v_p
      FROM gobernanza.persona p LEFT JOIN gobernanza.afiliado a ON a.id_persona = p.id_persona WHERE p.id_persona = p_id_persona;
    IF v_p.correo_electronico IS NULL THEN RAISE EXCEPTION 'La persona no existe.'; END IF;
    IF NOT COALESCE(v_p.afiliado_activo, FALSE) THEN RAISE EXCEPTION 'Solo se invita al portal a afiliados activos.'; END IF;
    IF NOT (seguridad.fn_es_admin() OR seguridad.fn_ambito_nacional() OR v_p.id_estamento_pertenencia = ANY (seguridad.fn_ambito_estamentos())) THEN
        RAISE EXCEPTION 'El afiliado está fuera de su ámbito territorial.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF seguridad.fn_rol_actual() IN ('AFILIADO') THEN RAISE EXCEPTION 'Su rol no puede invitar.'; END IF;
    IF EXISTS (SELECT 1 FROM seguridad.usuario u WHERE u.id_persona = p_id_persona AND u.activo AND u.codigo_rol = 'AFILIADO') THEN
        RAISE EXCEPTION 'El afiliado ya tiene una cuenta activa en el portal.';
    END IF;
    UPDATE seguridad.invitacion SET anulada = TRUE WHERE id_persona = p_id_persona AND tipo = 'CUENTA' AND usada_en IS NULL AND NOT anulada;
    INSERT INTO seguridad.invitacion (tipo, id_persona, correo, hash_token, expira)
    VALUES ('CUENTA', p_id_persona, v_p.correo_electronico, p_hash_token, v_exp);
    RETURN QUERY SELECT v_p.correo_electronico::TEXT, v_p.primer_nombre::TEXT, v_exp;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Datos que se muestran en la página de activación (sin iniciar sesión)
CREATE OR REPLACE FUNCTION seguridad.fn_consultar_invitacion(p_hash_token TEXT)
RETURNS TABLE (nombre TEXT, usuario_sugerido TEXT, politica_version TEXT, politica_titulo TEXT, politica_texto TEXT) AS $$
    SELECT p.primer_nombre::TEXT, regexp_replace(p.dni, '[^a-zA-Z0-9._-]', '', 'g'),
           pt.numero_version::TEXT, pt.titulo::TEXT, pt.texto
      FROM seguridad.invitacion i JOIN gobernanza.persona p ON p.id_persona = i.id_persona
      LEFT JOIN gobernanza.politica_tratamiento pt ON pt.vigente
     WHERE i.hash_token = p_hash_token AND i.tipo = 'CUENTA' AND i.usada_en IS NULL AND NOT i.anulada AND i.expira > now();
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_activar_cuenta(p_hash_token TEXT, p_nombre_usuario TEXT, p_hash_contrasena TEXT,
                                                       p_acepta_politica BOOLEAN, p_acepta_comunicaciones BOOLEAN, p_acepta_imagen BOOLEAN)
RETURNS TEXT AS $$
DECLARE v_i seguridad.invitacion%ROWTYPE; v_p RECORD; v_id BIGINT; v_pol BIGINT;
BEGIN
    SELECT * INTO v_i FROM seguridad.invitacion WHERE hash_token = p_hash_token AND tipo = 'CUENTA' FOR UPDATE;
    IF v_i.id_invitacion IS NULL OR v_i.anulada THEN RAISE EXCEPTION 'El enlace no es válido. Pida a su junta una invitación nueva.'; END IF;
    IF v_i.usada_en IS NOT NULL THEN RAISE EXCEPTION 'Este enlace ya se usó. Si no fue usted, avise a su junta.'; END IF;
    IF v_i.expira <= now() THEN RAISE EXCEPTION 'El enlace venció (dura 48 horas). Pida a su junta una invitación nueva.'; END IF;
    IF NOT COALESCE(p_acepta_politica, FALSE) THEN
        RAISE EXCEPTION 'Para usar el portal debe aceptar la política de tratamiento de datos para la gestión sindical.';
    END IF;
    SELECT p.*, a.activo AS afiliado_activo INTO v_p FROM gobernanza.persona p
      JOIN gobernanza.afiliado a ON a.id_persona = p.id_persona WHERE p.id_persona = v_i.id_persona;
    IF NOT COALESCE(v_p.afiliado_activo, FALSE) THEN RAISE EXCEPTION 'La afiliación no está activa.'; END IF;
    IF EXISTS (SELECT 1 FROM seguridad.usuario WHERE lower(nombre_usuario) = lower(p_nombre_usuario)) THEN
        RAISE EXCEPTION 'Ese nombre de usuario ya existe: elija otro.';
    END IF;
    INSERT INTO seguridad.usuario (nombre_usuario, nombre_completo, correo_electronico, hash_contrasena, codigo_rol, id_persona,
                                   debe_cambiar_contrasena)
    VALUES (p_nombre_usuario, v_p.primer_nombre || ' ' || v_p.primer_apellido, v_p.correo_electronico, p_hash_contrasena, 'AFILIADO',
            v_i.id_persona, FALSE)
    RETURNING id_usuario INTO v_id;
    UPDATE seguridad.invitacion SET usada_en = now(), id_usuario_creado = v_id WHERE id_invitacion = v_i.id_invitacion;
    -- Autorizaciones dadas en línea (Ley 1581), sobre la política vigente
    SELECT id_politica INTO v_pol FROM gobernanza.politica_tratamiento WHERE vigente;
    IF v_pol IS NOT NULL THEN
        INSERT INTO gobernanza.autorizacion_datos (id_persona, id_politica, codigo_finalidad, otorgada, medio, observaciones)
        VALUES (v_i.id_persona, v_pol, 'GESTION_SINDICAL', TRUE, 'PORTAL', 'Aceptada al activar la cuenta del portal'),
               (v_i.id_persona, v_pol, 'COMUNICACIONES', COALESCE(p_acepta_comunicaciones, FALSE), 'PORTAL', 'Al activar la cuenta del portal'),
               (v_i.id_persona, v_pol, 'IMAGEN', COALESCE(p_acepta_imagen, FALSE), 'PORTAL', 'Al activar la cuenta del portal');
    END IF;
    RETURN p_nombre_usuario;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 4. "SOLO LO MÍO": funciones del portal (devuelven solo los datos de la persona del usuario)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION seguridad.fn_mi_persona()
RETURNS BIGINT AS $$
    SELECT u.id_persona FROM seguridad.usuario u
      JOIN gobernanza.afiliado a ON a.id_persona = u.id_persona
     WHERE u.id_usuario = seguridad.fn_id_usuario_actual() AND u.activo;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_exigir_mi_persona()
RETURNS BIGINT AS $$
DECLARE v BIGINT := seguridad.fn_mi_persona();
BEGIN
    IF v IS NULL THEN
        RAISE EXCEPTION 'Su usuario no está ligado a un afiliado: el portal del afiliado no está disponible.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    RETURN v;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_mi_perfil()
RETURNS JSONB AS $$
DECLARE p BIGINT := seguridad.fn_exigir_mi_persona();
BEGIN
    RETURN (SELECT jsonb_build_object(
        'nombre', pe.primer_nombre || COALESCE(' ' || pe.segundo_nombre, '') || ' ' || pe.primer_apellido || COALESCE(' ' || pe.segundo_apellido, ''),
        'documento', pe.tipo_dni || ' ' || pe.dni, 'correo', pe.correo_electronico, 'telefono', pe.telefono,
        'municipio', pe.municipio, 'afiliado_activo', a.activo, 'fecha_afiliacion', a.fecha_afiliacion,
        'junta', e.nombre_estamento, 'empresa', em.nombre_empresa, 'sede', s.nombre_sede, 'fecha_ingreso_empresa', ae.fecha_ingreso_empresa,
        'salario', ae.salario_base,
        'porcentaje_aporte', finanzas.fn_porcentaje_afiliado(p, date_trunc('month', CURRENT_DATE)::DATE),
        'cargos', (SELECT jsonb_agg(c.nombre || ' — ' || es2.nombre_estamento) FROM gobernanza.directivo_estamento d
                     JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo JOIN gobernanza.estamento es2 ON es2.id_estamento = d.id_estamento
                    WHERE d.id_persona = p AND d.fecha_retiro IS NULL))
      FROM gobernanza.persona pe
      JOIN gobernanza.afiliado a ON a.id_persona = pe.id_persona
      LEFT JOIN gobernanza.estamento e ON e.id_estamento = a.id_estamento_pertenencia
      LEFT JOIN gobernanza.afiliado_empresa ae ON ae.id_persona = pe.id_persona
      LEFT JOIN gobernanza.empresa em ON em.id_empresa = ae.id_empresa
      LEFT JOIN gobernanza.sede_empresa s ON s.id_sede = ae.id_sede
     WHERE pe.id_persona = p);
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_actualizar_mi_telefono(p_telefono TEXT)
RETURNS VOID AS $$
DECLARE p BIGINT := seguridad.fn_exigir_mi_persona();
BEGIN
    IF p_telefono IS NOT NULL AND p_telefono !~ '^[0-9 +()-]{7,20}$' THEN RAISE EXCEPTION 'Escriba un teléfono válido.'; END IF;
    UPDATE gobernanza.persona SET telefono = NULLIF(trim(p_telefono), '') WHERE id_persona = p;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Cambio de correo: se confirma con un enlace enviado a la dirección nueva
CREATE OR REPLACE FUNCTION seguridad.fn_solicitar_cambio_correo(p_correo TEXT, p_hash_token TEXT)
RETURNS VOID AS $$
DECLARE p BIGINT := seguridad.fn_exigir_mi_persona();
BEGIN
    IF p_correo !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' THEN RAISE EXCEPTION 'Escriba un correo válido.'; END IF;
    IF EXISTS (SELECT 1 FROM gobernanza.persona WHERE lower(correo_electronico) = lower(p_correo) AND id_persona <> p) THEN
        RAISE EXCEPTION 'Ese correo ya está registrado para otra persona.';
    END IF;
    UPDATE seguridad.invitacion SET anulada = TRUE WHERE id_persona = p AND tipo = 'CORREO' AND usada_en IS NULL AND NOT anulada;
    INSERT INTO seguridad.invitacion (tipo, id_persona, correo, hash_token, expira) VALUES ('CORREO', p, lower(trim(p_correo)), p_hash_token, now() + INTERVAL '48 hours');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION seguridad.fn_confirmar_cambio_correo(p_hash_token TEXT)
RETURNS TEXT AS $$
DECLARE p BIGINT := seguridad.fn_exigir_mi_persona(); v_i seguridad.invitacion%ROWTYPE;
BEGIN
    SELECT * INTO v_i FROM seguridad.invitacion WHERE hash_token = p_hash_token AND tipo = 'CORREO' FOR UPDATE;
    IF v_i.id_invitacion IS NULL OR v_i.anulada OR v_i.usada_en IS NOT NULL OR v_i.expira <= now() OR v_i.id_persona <> p THEN
        RAISE EXCEPTION 'El enlace de confirmación no es válido o venció.';
    END IF;
    UPDATE gobernanza.persona SET correo_electronico = v_i.correo WHERE id_persona = p;
    UPDATE seguridad.usuario SET correo_electronico = v_i.correo WHERE id_persona = p;
    UPDATE seguridad.invitacion SET usada_en = now() WHERE id_invitacion = v_i.id_invitacion;
    RETURN v_i.correo;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- Mis aportes: últimos 24 meses
CREATE OR REPLACE FUNCTION seguridad.fn_mis_aportes()
RETURNS TABLE (periodo TEXT, porcentaje NUMERIC, esperado NUMERIC, registrado NUMERIC, empresa TEXT, estado TEXT) AS $$
DECLARE p BIGINT := seguridad.fn_exigir_mi_persona();
BEGIN
    RETURN QUERY
    WITH meses AS (
        SELECT g::DATE AS mes FROM generate_series(date_trunc('month', CURRENT_DATE) - INTERVAL '23 months',
                                                   date_trunc('month', CURRENT_DATE), INTERVAL '1 month') g
    ), ae AS (SELECT * FROM gobernanza.afiliado_empresa WHERE id_persona = p)
    SELECT to_char(m.mes, 'YYYY-MM'), finanzas.fn_porcentaje_afiliado(p, m.mes),
           CASE WHEN finanzas.fn_se_cobra(p, m.mes) THEN finanzas.fn_aporte_esperado(p, ae.id_empresa, m.mes) END,
           (SELECT sum(x.monto_descuento_ley) FROM finanzas.aporte_afiliado x
             WHERE x.id_persona = p AND NOT x.anulado AND x.periodo_anio = EXTRACT(YEAR FROM m.mes) AND x.periodo_mes = EXTRACT(MONTH FROM m.mes)),
           em.nombre_empresa::TEXT,
           CASE WHEN finanzas.fn_exonerado(p, m.mes) THEN 'EXONERADO'
                WHEN NOT finanzas.fn_se_cobra(p, m.mes) THEN 'NO SE COBRA'
                WHEN EXISTS (SELECT 1 FROM finanzas.aporte_afiliado x WHERE x.id_persona = p AND NOT x.anulado
                                AND x.periodo_anio = EXTRACT(YEAR FROM m.mes) AND x.periodo_mes = EXTRACT(MONTH FROM m.mes)) THEN 'AL DÍA'
                WHEN m.mes >= date_trunc('month', CURRENT_DATE) - INTERVAL '1 month' THEN 'EN PLAZO DE CONSIGNACIÓN'
                ELSE 'LA EMPRESA NO HA REPORTADO EL APORTE' END
      FROM meses m CROSS JOIN gobernanza.afiliado a
      LEFT JOIN ae ON TRUE LEFT JOIN gobernanza.empresa em ON em.id_empresa = ae.id_empresa
     WHERE a.id_persona = p AND m.mes >= date_trunc('month', GREATEST(a.fecha_afiliacion, COALESCE(ae.fecha_ingreso_empresa, a.fecha_afiliacion)))
     ORDER BY m.mes DESC;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Mis solicitudes (datos personales, afiliación y exoneraciones)
CREATE OR REPLACE FUNCTION seguridad.fn_mis_solicitudes()
RETURNS TABLE (tipo TEXT, radicado TEXT, fecha TIMESTAMPTZ, estado TEXT, detalle TEXT) AS $$
DECLARE p BIGINT := seguridad.fn_exigir_mi_persona();
BEGIN
    RETURN QUERY
    SELECT 'Datos personales: ' || lower(s.tipo), s.radicado::TEXT, s.fecha_radicacion, s.estado::TEXT,
           CASE WHEN s.estado = 'RESPONDIDA' THEN s.respuesta ELSE 'Fecha límite de respuesta: ' || s.fecha_limite END
      FROM gobernanza.solicitud_titular s WHERE s.id_persona = p
    UNION ALL
    SELECT 'Afiliación', s.radicado::TEXT, s.fecha_creacion, s.estado::TEXT, s.observacion_decision
      FROM gobernanza.solicitud_afiliacion s WHERE s.id_persona = p
    UNION ALL
    SELECT 'Exoneración del aporte', 'EXO-' || x.id_exoneracion, x.fecha_creacion, x.estado::TEXT,
           to_char(x.desde_mes, 'YYYY-MM') || ' a ' || to_char(x.hasta_mes, 'YYYY-MM') || COALESCE(' · ' || x.observacion_decision, '')
      FROM finanzas.exoneracion x WHERE x.id_persona = p
    ORDER BY 3 DESC;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Mi privacidad: autorizaciones y quién consultó mis datos
CREATE OR REPLACE FUNCTION seguridad.fn_mi_privacidad()
RETURNS JSONB AS $$
DECLARE p BIGINT := seguridad.fn_exigir_mi_persona();
BEGIN
    RETURN jsonb_build_object(
        'autorizaciones', (SELECT jsonb_agg(jsonb_build_object('finalidad', f.codigo, 'nombre', f.nombre, 'obligatoria', f.obligatoria,
                                                               'estado', gobernanza.fn_estado_autorizacion(p, f.codigo)) ORDER BY f.orden)
                             FROM gobernanza.finalidad_tratamiento f),
        'accesos', (SELECT jsonb_agg(jsonb_build_object('fecha', a.fecha_hora, 'usuario', a.nombre_usuario, 'tipo', a.tipo, 'sobre', a.recurso)
                                     ORDER BY a.fecha_hora DESC)
                      FROM (SELECT * FROM auditoria.acceso_dato WHERE id_persona = p
                              AND id_usuario IS DISTINCT FROM seguridad.fn_id_usuario_actual() ORDER BY fecha_hora DESC LIMIT 100) a));
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- El titular revoca una finalidad opcional (comunicaciones o uso de imagen)
CREATE OR REPLACE FUNCTION seguridad.fn_cambiar_mi_autorizacion(p_finalidad TEXT, p_otorgada BOOLEAN)
RETURNS TEXT AS $$
DECLARE p BIGINT := seguridad.fn_exigir_mi_persona(); v_pol BIGINT;
BEGIN
    IF NOT EXISTS (SELECT 1 FROM gobernanza.finalidad_tratamiento WHERE codigo = p_finalidad AND NOT obligatoria) THEN
        RAISE EXCEPTION 'Desde el portal solo se cambian las finalidades opcionales. Para la gestión sindical presente una solicitud.';
    END IF;
    SELECT id_politica INTO v_pol FROM gobernanza.politica_tratamiento WHERE vigente;
    IF v_pol IS NULL THEN RAISE EXCEPTION 'No hay una política de tratamiento vigente.'; END IF;
    INSERT INTO gobernanza.autorizacion_datos (id_persona, id_politica, codigo_finalidad, otorgada, medio, observaciones)
    VALUES (p, v_pol, p_finalidad, p_otorgada, 'PORTAL', 'Cambio hecho por el titular en el portal');
    RETURN gobernanza.fn_estado_autorizacion(p, p_finalidad);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 5. CERTIFICADOS CON CÓDIGO DE VERIFICACIÓN
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gobernanza.certificado (
    id_certificado BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    codigo VARCHAR(16) NOT NULL UNIQUE,
    tipo VARCHAR(12) NOT NULL CHECK (tipo IN ('AFILIACION', 'PAZ_Y_SALVO')),
    id_persona BIGINT NOT NULL REFERENCES gobernanza.persona(id_persona) ON DELETE RESTRICT,
    contenido JSONB NOT NULL,
    hash_sha256 VARCHAR(64) NOT NULL,
    fecha_emision TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario_emision VARCHAR(50) NOT NULL DEFAULT auditoria.fn_usuario_actual(),
    anulado BOOLEAN NOT NULL DEFAULT FALSE,
    version INT NOT NULL DEFAULT 1
);
COMMENT ON TABLE gobernanza.certificado IS 'Certificados emitidos (afiliación y paz y salvo). El código permite verificarlos en la página pública.';
CREATE INDEX IF NOT EXISTS ix_certificado_persona ON gobernanza.certificado (id_persona, fecha_emision DESC);

CREATE OR REPLACE FUNCTION gobernanza.fn_proteger_certificado()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'UPDATE' AND (NEW.contenido IS DISTINCT FROM OLD.contenido OR NEW.hash_sha256 IS DISTINCT FROM OLD.hash_sha256
                             OR NEW.codigo IS DISTINCT FROM OLD.codigo OR NEW.id_persona IS DISTINCT FROM OLD.id_persona) THEN
        RAISE EXCEPTION 'Un certificado emitido no se modifica.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_proteger_certificado ON gobernanza.certificado;
CREATE TRIGGER trg_proteger_certificado BEFORE UPDATE ON gobernanza.certificado FOR EACH ROW EXECUTE FUNCTION gobernanza.fn_proteger_certificado();

-- Emite el certificado de la persona del usuario (o, para personal autorizado, de un afiliado de su ámbito)
CREATE OR REPLACE FUNCTION gobernanza.fn_emitir_certificado(p_tipo TEXT, p_codigo TEXT, p_id_persona BIGINT DEFAULT NULL)
RETURNS JSONB AS $$
DECLARE
    p BIGINT; v JSONB; v_pend TEXT; v_af RECORD; v_hash TEXT;
BEGIN
    IF p_id_persona IS NULL THEN
        p := seguridad.fn_exigir_mi_persona();
    ELSE
        p := p_id_persona;
        IF seguridad.fn_rol_actual() = 'AFILIADO' OR NOT (seguridad.fn_es_admin()
              OR seguridad.fn_persona_visible(p, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos())) THEN
            RAISE EXCEPTION 'Solo puede emitir certificados de afiliados de su ámbito.' USING ERRCODE = 'insufficient_privilege';
        END IF;
    END IF;
    SELECT a.*, pe.primer_nombre, pe.segundo_nombre, pe.primer_apellido, pe.segundo_apellido, pe.tipo_dni, pe.dni,
           e.nombre_estamento, em.nombre_empresa, em.nit
      INTO v_af
      FROM gobernanza.afiliado a JOIN gobernanza.persona pe ON pe.id_persona = a.id_persona
      LEFT JOIN gobernanza.estamento e ON e.id_estamento = a.id_estamento_pertenencia
      LEFT JOIN gobernanza.afiliado_empresa ae ON ae.id_persona = a.id_persona
      LEFT JOIN gobernanza.empresa em ON em.id_empresa = ae.id_empresa
     WHERE a.id_persona = p;
    IF v_af.id_persona IS NULL THEN RAISE EXCEPTION 'La persona no es afiliada.'; END IF;
    IF NOT v_af.activo THEN RAISE EXCEPTION 'La afiliación no está activa: no se expiden certificados.'; END IF;
    IF p_tipo NOT IN ('AFILIACION', 'PAZ_Y_SALVO') THEN RAISE EXCEPTION 'Tipo de certificado no válido.'; END IF;
    v := jsonb_build_object(
        'tipo', p_tipo,
        'titular', trim(v_af.primer_nombre || COALESCE(' ' || v_af.segundo_nombre, '') || ' ' || v_af.primer_apellido || COALESCE(' ' || v_af.segundo_apellido, '')),
        'documento', v_af.tipo_dni || ' ' || v_af.dni, 'junta', v_af.nombre_estamento, 'fecha_afiliacion', v_af.fecha_afiliacion,
        'empresa', v_af.nombre_empresa, 'nit', v_af.nit, 'fecha', (now() AT TIME ZONE gestion_documental.fn_zona())::DATE);
    IF p_tipo = 'PAZ_Y_SALVO' THEN
        -- Meses de los últimos 12 (ya vencidos) en que se esperaba el aporte y la empresa no lo reportó
        SELECT string_agg(to_char(g, 'YYYY-MM'), ', ' ORDER BY g) INTO v_pend
          FROM generate_series(date_trunc('month', CURRENT_DATE) - INTERVAL '12 months', date_trunc('month', CURRENT_DATE) - INTERVAL '2 months',
                               INTERVAL '1 month') g
         WHERE finanzas.fn_se_cobra(p, g::DATE)
           AND NOT EXISTS (SELECT 1 FROM finanzas.aporte_afiliado x WHERE x.id_persona = p AND NOT x.anulado
                              AND x.periodo_anio = EXTRACT(YEAR FROM g) AND x.periodo_mes = EXTRACT(MONTH FROM g));
        v := v || jsonb_build_object('meses_sin_reporte', v_pend,
            'nota', CASE WHEN v_pend IS NULL THEN NULL ELSE
                'La empresa ' || COALESCE(v_af.nombre_empresa, '') || ' no ha reportado al sindicato el aporte de: ' || v_pend ||
                '. El aporte se descuenta por nómina: esta diferencia corresponde a la empresa y no al afiliado.' END);
    END IF;
    v_hash := encode(sha256(convert_to(v::TEXT || p_codigo, 'UTF8')), 'hex');
    INSERT INTO gobernanza.certificado (codigo, tipo, id_persona, contenido, hash_sha256) VALUES (p_codigo, p_tipo, p, v, v_hash);
    RETURN v || jsonb_build_object('codigo', p_codigo, 'hash_sha256', v_hash);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_mis_certificados()
RETURNS TABLE (codigo VARCHAR, tipo VARCHAR, fecha_emision TIMESTAMPTZ, hash_sha256 VARCHAR) AS $$
    SELECT c.codigo, c.tipo, c.fecha_emision, c.hash_sha256 FROM gobernanza.certificado c
     WHERE c.id_persona = seguridad.fn_exigir_mi_persona() AND NOT c.anulado ORDER BY c.fecha_emision DESC;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION gobernanza.fn_certificado_para_pdf(p_codigo TEXT)
RETURNS JSONB AS $$
    SELECT c.contenido || jsonb_build_object('codigo', c.codigo, 'hash_sha256', c.hash_sha256, 'emitido', c.fecha_emision)
      FROM gobernanza.certificado c
     WHERE c.codigo = upper(p_codigo) AND NOT c.anulado
       AND (c.id_persona = seguridad.fn_mi_persona() OR seguridad.fn_es_admin()
            OR (seguridad.fn_rol_actual() <> 'AFILIADO'
                AND seguridad.fn_persona_visible(c.id_persona, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos())));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- Verificación pública: sin datos sensibles; el nombre solo con iniciales
CREATE OR REPLACE FUNCTION gobernanza.fn_verificar_certificado(p_codigo TEXT)
RETURNS JSONB AS $$
    SELECT jsonb_build_object(
        'valido', NOT c.anulado AND (c.tipo <> 'AFILIACION' OR a.activo),
        'tipo', CASE c.tipo WHEN 'AFILIACION' THEN 'Certificado de afiliación' ELSE 'Paz y salvo' END,
        'fecha_emision', (c.fecha_emision AT TIME ZONE gestion_documental.fn_zona())::DATE,
        'titular', (SELECT string_agg(left(w, 1) || '***', ' ') FROM regexp_split_to_table(c.contenido->>'titular', '\s+') w),
        'documento', '***' || right(c.contenido->>'documento', 3),
        'afiliacion_vigente', a.activo,
        'hash_sha256', c.hash_sha256)
      FROM gobernanza.certificado c LEFT JOIN gobernanza.afiliado a ON a.id_persona = c.id_persona
     WHERE c.codigo = upper(trim(p_codigo));
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 6. VERSIÓN, AUDITORÍA, NO BORRAR, SEGURIDAD POR FILAS Y PERMISOS
-- ----------------------------------------------------------------------------
DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['gobernanza.solicitud_afiliacion', 'gobernanza.certificado', 'seguridad.invitacion',
                             'seguridad.recurso_permitido_rol'] LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_control_version ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_control_version BEFORE UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_control_version()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_auditoria ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_auditoria AFTER INSERT OR UPDATE OR DELETE ON %s FOR EACH ROW EXECUTE FUNCTION auditoria.fn_generar_auditoria()', t);
        EXECUTE format('DROP TRIGGER IF EXISTS trg_no_borrar ON %s', t);
        EXECUTE format('CREATE TRIGGER trg_no_borrar BEFORE DELETE ON %s FOR EACH ROW EXECUTE FUNCTION seguridad.fn_bloquear_borrado()', t);
    END LOOP;
END $$;

SELECT seguridad.fn_aplicar_politicas('gobernanza.solicitud_afiliacion', ':N OR id_estamento = ANY(:E)', ':N OR id_estamento = ANY(:E)');
SELECT seguridad.fn_aplicar_politicas('gobernanza.certificado',
    'seguridad.fn_persona_visible(id_persona, :N, :E)', 'false');

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_app') THEN
        GRANT SELECT, INSERT, UPDATE ON gobernanza.solicitud_afiliacion TO sgs_app;
        GRANT SELECT ON gobernanza.certificado, seguridad.recurso_permitido_rol TO sgs_app;
        REVOKE INSERT, UPDATE, DELETE ON gobernanza.certificado FROM sgs_app;
        REVOKE ALL ON seguridad.invitacion FROM sgs_app;
        REVOKE DELETE ON gobernanza.solicitud_afiliacion FROM sgs_app;
        GRANT USAGE ON SEQUENCE gobernanza.seq_solicitud_afiliacion TO sgs_app;
        GRANT SELECT ON gobernanza.v_auditoria_solicitudes_afiliacion TO sgs_app;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_lectura') THEN
        GRANT SELECT ON gobernanza.solicitud_afiliacion, gobernanza.certificado, gobernanza.v_auditoria_solicitudes_afiliacion TO sgs_lectura;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sgs_notificador') THEN
        GRANT SELECT ON gobernanza.solicitud_afiliacion, gobernanza.v_auditoria_solicitudes_afiliacion TO sgs_notificador;
    END IF;
END $$;
-- El salario de la solicitud queda reservado (como en afiliado_empresa)
SELECT seguridad.fn_aplicar_reserva_columnas();

-- ----------------------------------------------------------------------------
-- 7. EL SALARIO DE UNA SOLICITUD DE AFILIACIÓN TAMBIÉN SE ENTREGA CON VERIFICACIÓN Y REGISTRO
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION seguridad.fn_revelar_dato(p_tabla TEXT, p_id JSONB, p_motivo TEXT DEFAULT NULL)
RETURNS TEXT AS $$
DECLARE v_valor TEXT; v_persona BIGINT; v_cat TEXT; v_col TEXT; v_existe BOOLEAN;
BEGIN
    IF p_tabla = 'persona' THEN
        v_cat := 'SENSIBLE'; v_col := 'genero'; v_persona := (p_id->>'id_persona')::BIGINT;
        SELECT TRUE, genero INTO v_existe, v_valor FROM gobernanza.persona WHERE id_persona = v_persona;
    ELSIF p_tabla = 'inspector' THEN
        v_cat := 'SENSIBLE'; v_col := 'genero'; v_persona := NULL;
        SELECT TRUE, genero INTO v_existe, v_valor FROM gobernanza.inspector WHERE id_inspector = (p_id->>'id_inspector')::BIGINT;
    ELSIF p_tabla = 'afiliado_empresa' THEN
        v_cat := 'SALARIO'; v_col := 'salario_base'; v_persona := (p_id->>'id_persona')::BIGINT;
        SELECT TRUE, salario_base::TEXT INTO v_existe, v_valor FROM gobernanza.afiliado_empresa
         WHERE id_persona = v_persona AND id_empresa = (p_id->>'id_empresa')::BIGINT;
    ELSIF p_tabla = 'salario_historico' THEN
        v_cat := 'SALARIO'; v_col := 'salario';
        SELECT TRUE, salario::TEXT, id_persona INTO v_existe, v_valor, v_persona FROM gobernanza.salario_historico
         WHERE id_salario = (p_id->>'id_salario')::BIGINT;
    ELSIF p_tabla = 'solicitud_afiliacion' THEN
        v_cat := 'SALARIO'; v_col := 'salario_base';
        SELECT TRUE, salario_base::TEXT, id_persona INTO v_existe, v_valor, v_persona FROM gobernanza.solicitud_afiliacion
         WHERE id_solicitud_afiliacion = (p_id->>'id_solicitud_afiliacion')::BIGINT;
    ELSE
        RAISE EXCEPTION 'Este dato no es reservado.';
    END IF;
    IF NOT COALESCE(v_existe, FALSE) THEN RAISE EXCEPTION 'El registro no existe.'; END IF;
    -- Además del cargo, la persona debe estar dentro del ámbito territorial de quien consulta
    IF p_tabla = 'solicitud_afiliacion' THEN
        IF NOT (seguridad.fn_es_admin() OR seguridad.fn_tiene_cargo(ARRAY['PRES\_%', 'SGEN\_%', 'TES\_%'],
                (SELECT id_estamento FROM gobernanza.solicitud_afiliacion WHERE id_solicitud_afiliacion = (p_id->>'id_solicitud_afiliacion')::BIGINT))) THEN
            RAISE EXCEPTION 'Dato reservado (Ley 1581): su cargo no le permite verlo.' USING ERRCODE = 'insufficient_privilege';
        END IF;
    ELSIF NOT seguridad.fn_puede_ver_dato(v_cat, v_persona)
       OR (v_persona IS NOT NULL AND NOT seguridad.fn_es_admin()
           AND NOT seguridad.fn_persona_visible(v_persona, seguridad.fn_ambito_nacional(), seguridad.fn_ambito_estamentos())) THEN
        RAISE EXCEPTION 'Dato reservado (Ley 1581): su cargo no le permite verlo.' USING ERRCODE = 'insufficient_privilege';
    END IF;
    PERFORM seguridad.fn_registrar_acceso_dato('VER_DATO', p_tabla, v_persona, ARRAY[v_col], 1, p_motivo);
    RETURN v_valor;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public;
