@echo off
REM Backup programado. Registrar en el Programador de tareas de Windows (diario 2:15 a. m.):
REM   schtasks /create /tn "SGSINDICAL Backup" /sc daily /st 02:15 /ru SYSTEM /tr "C:\SGSINDICAL\ops\backup.bat"
cd /d %~dp0\..\backend
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
python -m app.cli backup >> ..\ops\backup.log 2>&1
