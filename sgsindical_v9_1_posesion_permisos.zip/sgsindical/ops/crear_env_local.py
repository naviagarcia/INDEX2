"""SGSINDICAL · Crea el archivo backend/.env del AMBIENTE LOCAL (Mac) con datos demo.
Uso (desde la carpeta backend, con el entorno activado):   python ../ops/crear_env_local.py
No sobrescribe un .env que ya exista.
"""
import secrets
import shutil
import sys
from pathlib import Path

BACKEND = Path.cwd()
if not (BACKEND / "app").is_dir():
    sys.exit("Ejecútelo desde la carpeta backend del proyecto.")
ENV = BACKEND / ".env"
if ENV.exists():
    sys.exit(".env ya existe; no lo toco. Si quiere uno nuevo, bórrelo primero:  rm .env")

sys.path.insert(0, str(BACKEND))
from app.redes import generar_llave  # noqa: E402

datos = Path.home() / "SGSINDICAL_datos"
(datos / "documentos").mkdir(parents=True, exist_ok=True)
(datos / "backups").mkdir(parents=True, exist_ok=True)
pg_dump = shutil.which("pg_dump") or "/opt/homebrew/opt/postgresql@16/bin/pg_dump"
bd = "postgresql://{u}:{p}@localhost:5432/sgsindical_demo"

ENV.write_text(f"""# AMBIENTE LOCAL DE PRUEBAS (Mac) · solo datos demo · creado por crear_env_local.py
DATABASE_URL={bd.format(u="sgs_app", p="app")}
BACKUP_DATABASE_URL={bd.format(u="sgs_backup", p="bak")}
NOTIFICADOR_DATABASE_URL={bd.format(u="sgs_notificador", p="not")}
JWT_SECRET={secrets.token_urlsafe(48)}
SECRETOS_LLAVE={generar_llave()}
SECRETOS_LLAVE_VERSION=1
UPLOAD_DIR={datos / "documentos"}
BACKUP_DIR={datos / "backups"}
PG_DUMP={pg_dump}
# Correos: todos van a Mailpit (http://localhost:8025); nada sale a internet
SMTP_HOST=localhost
SMTP_PORT=1025
SMTP_SEGURIDAD=ninguna
SMTP_USUARIO=
SMTP_CONTRASENA=
CORREO_REMITENTE=pruebas@localhost
APP_URL=http://localhost:8000
ZONA_HORARIA=America/Bogota
# Sin inteligencia artificial real ni transcripción (no se envía nada a terceros)
IA_PROVEEDOR=simulado
TRANSCRIPCION=simulada
ANTHROPIC_API_KEY=
""", encoding="utf-8")
ENV.chmod(0o600)
print("Listo: se creó", ENV)
print("Archivos de prueba en:", datos)
