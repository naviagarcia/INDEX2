@echo off
REM Correos automaticos (alertas y convocatorias). Registrar en el Programador de tareas (cada 30 min, 6 a. m. a 8 p. m.):
REM   schtasks /create /tn "SGSINDICAL Correos" /sc minute /mo 30 /st 06:00 /du 14:30 /ru SYSTEM /tr "C:\SGSINDICAL\ops\notificar.bat"
REM Probar sin enviar:  notificar.bat --simulacro
cd /d %~dp0\..\backend
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
python -m app.cli notificar %* >> ..\ops\correos.log 2>&1
