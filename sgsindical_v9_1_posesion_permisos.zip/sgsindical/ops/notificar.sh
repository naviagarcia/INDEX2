#!/usr/bin/env bash
# Correos automáticos (alertas y convocatorias). Programar cada 30 minutos de 6 a. m. a 8 p. m. (cron):
#   */30 6-20 * * *  /opt/sgsindical/ops/notificar.sh >> /var/log/sgsindical_correos.log 2>&1
# Probar sin enviar:  ./notificar.sh --simulacro
set -euo pipefail
cd "$(dirname "$0")/../backend"
[[ -d .venv ]] && source .venv/bin/activate
python -m app.cli notificar "$@"
