#!/usr/bin/env bash
# SGSINDICAL · Respaldo completo ANTES de un despliegue (base de datos + archivos subidos + programa + configuración).
# Uso (en el servidor, como root):   bash respaldo_previo.sh
# Deja todo en /root/respaldos_despliegue/AAAAMMDD_HHMM con un archivo HUELLAS.sha256 para verificarlo.
set -euo pipefail

APP="${APP:-/opt/sgsindical}"                       # carpeta donde está instalado el programa (ajuste si es otra)
DESTINO="${DESTINO:-/root/respaldos_despliegue}/$(date +%Y%m%d_%H%M)"

ENV="$APP/backend/.env"
[[ -f "$ENV" ]] || { echo "No encuentro $ENV. Revise la variable APP."; exit 1; }
valor() { grep -E "^$1=" "$ENV" | tail -1 | cut -d= -f2- | sed 's/^"//; s/"$//'; }
UPLOAD_DIR="$(valor UPLOAD_DIR)"
BACKUP_DIR="$(valor BACKUP_DIR)"
[[ -d "$UPLOAD_DIR" ]] || { echo "La carpeta de archivos subidos ($UPLOAD_DIR) no existe."; exit 1; }
[[ -d "$BACKUP_DIR" ]] || { echo "La carpeta de backups ($BACKUP_DIR) no existe."; exit 1; }
mkdir -p "$DESTINO"

echo "1/4  Backup de la base de datos (queda también en Auditoría → Registro de backups)…"
bash "$APP/ops/backup.sh"
ULTIMO="$(ls -t "$BACKUP_DIR"/*.dump | head -1)"
cp "$ULTIMO" "$DESTINO/"
[[ -f "${ULTIMO%.dump}.sha256" ]] && cp "${ULTIMO%.dump}.sha256" "$DESTINO/"

echo "2/4  Copia de los archivos subidos ($UPLOAD_DIR)…"
tar -czf "$DESTINO/documentos.tar.gz" -C "$(dirname "$UPLOAD_DIR")" "$(basename "$UPLOAD_DIR")"
ARCHIVOS=$(find "$UPLOAD_DIR" -type f | wc -l)

echo "3/4  Copia del programa actual y de su configuración (.env)…"
tar -czf "$DESTINO/programa.tar.gz" -C "$(dirname "$APP")" \
    --exclude='.venv' --exclude='__pycache__' \
    --exclude="$(basename "$APP")/${UPLOAD_DIR#"$APP"/}" --exclude="$(basename "$APP")/${BACKUP_DIR#"$APP"/}" \
    "$(basename "$APP")"
cp "$ENV" "$DESTINO/env_respaldo"
chmod 600 "$DESTINO/env_respaldo"

echo "4/4  Huellas de verificación…"
(cd "$DESTINO" && sha256sum ./*.dump documentos.tar.gz programa.tar.gz env_respaldo > HUELLAS.sha256)

echo
echo "LISTO. Respaldo en: $DESTINO"
du -sh "$DESTINO"/* | sed 's/^/   /'
echo "   Archivos subidos copiados: $ARCHIVOS"
echo "Siguiente paso: copie esta carpeta FUERA del servidor (vea la guía, paso «Sacar el respaldo del servidor»)."
