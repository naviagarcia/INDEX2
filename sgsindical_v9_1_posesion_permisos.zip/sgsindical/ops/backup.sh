#!/usr/bin/env bash
# Backup programado (usa la configuración del .env del backend y queda en auditoria.registro_backup).
# cron diario 2:15 a. m.:   15 2 * * *  /opt/sgsindical/ops/backup.sh >> /var/log/sgsindical_backup.log 2>&1
set -euo pipefail
cd "$(dirname "$0")/../backend"
[[ -d .venv ]] && source .venv/bin/activate
python -m app.cli backup
