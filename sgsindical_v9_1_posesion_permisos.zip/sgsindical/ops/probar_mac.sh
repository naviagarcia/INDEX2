#!/usr/bin/env bash
# SGSINDICAL · Reinstala la base de PRUEBAS con datos demo y corre todas las verificaciones automáticas.
# Uso (desde la carpeta del proyecto):   bash ops/probar_mac.sh
# Tarda unos minutos. Al final debe decir: TODAS LAS PRUEBAS PASARON (806)   (777 después de las 8 p. m.)
set -euo pipefail
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
BD="sgsindical_pruebas"                       # base desechable: se borra y se crea de nuevo en cada corrida
export PGHOST="${PGHOST:-localhost}" PGPORT="${PGPORT:-5432}" PGUSER="${PGUSER:-$(whoami)}"
SUPER="postgresql://$PGUSER${PGPASSWORD:+:$PGPASSWORD}@$PGHOST:$PGPORT/$BD"

echo "1/3  Borrando y creando de nuevo la base $BD…"
dropdb --if-exists "$BD"

echo "2/3  Instalando los scripts 01 a 17b con datos demo…"
cd "$RAIZ/db"
if ! printf 'app\nlec\nbak\nnot\n' | bash instalar.sh "$BD" --demo > /tmp/sgs_instalar_pruebas.log 2>&1; then
  echo "FALLÓ la instalación. Últimas líneas del registro (/tmp/sgs_instalar_pruebas.log):"
  grep -v NOTICE /tmp/sgs_instalar_pruebas.log | tail -15
  exit 1
fi

echo "3/3  Corriendo las verificaciones…"
cd "$RAIZ/backend"
[[ -d .venv ]] && source .venv/bin/activate
export DATABASE_URL="postgresql://sgs_app:app@$PGHOST:$PGPORT/$BD" \
       BACKUP_DATABASE_URL="postgresql://sgs_backup:bak@$PGHOST:$PGPORT/$BD" \
       NOTIFICADOR_DATABASE_URL="postgresql://sgs_notificador:not@$PGHOST:$PGPORT/$BD" \
       SUPER_DATABASE_URL="$SUPER" \
       PG_DUMP="${PG_DUMP:-pg_dump}"
python -m tests.prueba_api 2>&1 | tee /tmp/sgs_resultado_pruebas.log | grep -E "^[A-ZÁÉÍÓÚ]|Error|assert|TODAS" || true
if grep -q "TODAS LAS PRUEBAS PASARON" /tmp/sgs_resultado_pruebas.log; then
  echo "RESULTADO: VERDE ✔"
else
  echo "RESULTADO: ROJO ✘  — la prueba que falló está al final de /tmp/sgs_resultado_pruebas.log:"
  tail -20 /tmp/sgs_resultado_pruebas.log
  exit 1
fi
