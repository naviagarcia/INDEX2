-- ¿Qué bloques tiene instalados esta base? (solo lee, no cambia nada)
SELECT bloque, CASE WHEN instalado THEN 'SÍ' ELSE 'no' END AS instalado FROM (VALUES
  ('12 roles y suplencias',       to_regclass('gobernanza.suplencia') IS NOT NULL),
  ('13 plazos de ley',            to_regclass('gobernanza.plazo_legal') IS NOT NULL),
  ('15 documentos legales',       to_regclass('gobernanza.texto_institucional') IS NOT NULL),
  ('16 expediente de afiliación', to_regclass('gobernanza.documento_afiliacion') IS NOT NULL),
  ('17 lugares y traslados',      to_regclass('gobernanza.traslado_pertenencia') IS NOT NULL),
  ('18 posesión y permisos',      to_regclass('gobernanza.permiso_sindical') IS NOT NULL)
) AS t(bloque, instalado);
