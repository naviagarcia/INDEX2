@echo off
REM Uso: restaurar_backup.bat C:\SGSINDICAL\backups\sgsindical_AAAAMMDD_HHMMSS.dump [bd_destino]
set ARCHIVO=%~1
set DESTINO=%2
if "%DESTINO%"=="" set DESTINO=sgsindical_restaurada
echo Huella SHA-256 del archivo (compare con Auditoria - Registro de backups):
certutil -hashfile "%ARCHIVO%" SHA256
pause
createdb -U postgres %DESTINO% || exit /b 1
pg_restore -U postgres --no-owner --exit-on-error -d %DESTINO% "%ARCHIVO%" || exit /b 1
echo Restaurado en %DESTINO%. Ejecute db\03_roles_permisos.sql sobre esa base antes de usarla.
