-- SGSINDICAL · Neutraliza una COPIA de producción para el ensayo: cambia correos y teléfonos por valores ficticios.
-- NUNCA se ejecuta en producción: se niega a correr si el nombre de la base no termina en _ensayo.
-- Uso:  sudo -u postgres psql -d sgsindical_ensayo -f /tmp/neutralizar.sql   (archivo: ops/ensayo/neutralizar.sql)
\set ON_ERROR_STOP on
DO $$ BEGIN
  IF current_database() NOT LIKE '%\_ensayo' THEN
    RAISE EXCEPTION 'Este script solo se ejecuta sobre una base cuyo nombre termine en _ensayo (esta es %).', current_database();
  END IF;
END $$;
BEGIN;
-- Apaga los disparadores (protecciones y auditoría) solo dentro de esta transacción; requiere superusuario.
SET LOCAL session_replication_role = replica;
UPDATE gobernanza.persona SET
  correo_electronico = CASE WHEN correo_electronico IS NULL THEN NULL ELSE 'persona' || id_persona || '@ejemplo.invalid' END,
  correo_adicional   = NULL,
  telefono           = CASE WHEN telefono IS NULL THEN NULL ELSE '3000000000' END,
  telefono_adicional = NULL;
UPDATE seguridad.usuario SET correo_electronico = 'usuario' || id_usuario || '@ejemplo.invalid' WHERE correo_electronico IS NOT NULL;
UPDATE seguridad.invitacion SET correo = 'invitacion' || id_invitacion || '@ejemplo.invalid' WHERE correo IS NOT NULL;
UPDATE gobernanza.empresa SET
  correo_general = 'no-enviar@ejemplo.invalid',
  correo_notificaciones_judiciales = CASE WHEN correo_notificaciones_judiciales IS NULL THEN NULL ELSE 'no-enviar@ejemplo.invalid' END,
  correo_talento_humano = CASE WHEN correo_talento_humano IS NULL THEN NULL ELSE 'no-enviar@ejemplo.invalid' END;
UPDATE gobernanza.sede_empresa SET correo_sede = 'no-enviar@ejemplo.invalid' WHERE correo_sede IS NOT NULL;
UPDATE gobernanza.inspector SET correo_electronico = 'no-enviar@ejemplo.invalid' WHERE correo_electronico IS NOT NULL;
UPDATE gestion_documental.pqrsd SET correo_peticionario = 'no-enviar@ejemplo.invalid' WHERE correo_peticionario IS NOT NULL;
UPDATE gestion_documental.reunion_asistente SET correo_invitado = 'no-enviar@ejemplo.invalid' WHERE correo_invitado IS NOT NULL;
COMMIT;
SELECT 'Copia neutralizada: ' || count(*) || ' personas con correo ficticio' FROM gobernanza.persona WHERE correo_electronico LIKE '%@ejemplo.invalid';
