-- ============================================================================
-- SGSINDICAL — Mantenimiento de índices y estadísticas (ejecutar como dueño de la BD)
-- Programar semanalmente en horario de baja actividad:
--   psql -d sgsindical -f ops/mantenimiento.sql
-- ============================================================================
\echo '1. Estado antes del mantenimiento'
SELECT esquema, tabla, filas_vivas, filas_muertas, diagnostico FROM auditoria.v_monitor_tablas WHERE diagnostico <> 'NORMAL';
SELECT esquema, tabla, indice, tamano, diagnostico FROM auditoria.v_monitor_indices WHERE diagnostico LIKE 'ALERTA%';
SELECT * FROM auditoria.v_fk_sin_indice;

\echo '2. VACUUM + ANALYZE (libera espacio de filas muertas y actualiza estadísticas del planificador)'
VACUUM (ANALYZE) gobernanza.persona, gobernanza.afiliado, gobernanza.empresa, gobernanza.afiliado_empresa,
                 gobernanza.directivo_estamento, gestion_documental.documento, gestion_documental.historial_tramite,
                 gestion_documental.compromiso_tarea, gestion_documental.expediente,
                 finanzas.consignacion_empresa, finanzas.aporte_afiliado,
                 auditoria.bitacora_cambios, auditoria.registro_acceso, seguridad.usuario, seguridad.sesion;

\echo '3. Limpieza de sesiones vencidas (más de 30 días)'
DELETE FROM seguridad.sesion WHERE fecha_expiracion < now() - INTERVAL '30 days';

\echo '4. Reconstrucción de índices inválidos (sin bloquear escrituras)'
SELECT format('REINDEX INDEX CONCURRENTLY %I.%I;', esquema, indice)
  FROM auditoria.v_monitor_indices WHERE es_invalido \gexec

\echo 'Mantenimiento terminado.'
