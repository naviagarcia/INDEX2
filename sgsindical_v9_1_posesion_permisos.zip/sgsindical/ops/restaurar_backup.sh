#!/usr/bin/env bash
# Restaura un backup en una base NUEVA (nunca sobre la de producción) tras verificar su huella SHA-256.
# Uso: ./restaurar_backup.sh /ruta/sgsindical_AAAAMMDD_HHMMSS.dump [bd_destino]
set -euo pipefail
ARCHIVO="$1"; DESTINO="${2:-sgsindical_restaurada_$(date +%Y%m%d%H%M)}"
if [[ -f "${ARCHIVO%.dump}.sha256" ]]; then
  (cd "$(dirname "$ARCHIVO")" && sha256sum -c "$(basename "${ARCHIVO%.dump}.sha256")") || { echo "HUELLA NO COINCIDE: backup alterado o dañado."; exit 1; }
else
  echo "ADVERTENCIA: no hay archivo .sha256; compare la huella con Auditoría → Registro de backups."
fi
createdb "$DESTINO"
pg_restore --no-owner --exit-on-error -d "$DESTINO" "$ARCHIVO"
echo "Restaurado en la base '$DESTINO'. Verifique los datos y luego vuelva a ejecutar db/03_roles_permisos.sql sobre ella"
echo "antes de apuntar DATABASE_URL a esta base."
