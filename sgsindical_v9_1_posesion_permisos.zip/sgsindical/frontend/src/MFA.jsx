// Segundo factor de autenticación (MFA): verificación al ingresar, configuración y «Mi seguridad».
import { useEffect, useState } from "react";
import { alPedirCodigo, api, setToken } from "./api.js";
import { Aviso, Campo, Cargando, formatear } from "./ui.jsx";

const guardarEquipo = (t) => { try { if (t) localStorage.setItem("sgs_equipo", t); } catch { /* sin almacenamiento */ } };
export const equipoRecordado = () => { try { return localStorage.getItem("sgs_equipo"); } catch { return null; } };

async function salir() {
  await api.post("/api/auth/logout").catch(() => {});
  setToken(null); window.location.hash = "/"; window.location.reload();
}

// ------------------------------------------------------------------ verificación al ingresar
export function VerificarMFA({ usuario, onListo }) {
  const [metodo, setMetodo] = useState("app");
  const [codigo, setCodigo] = useState("");
  const [recordar, setRecordar] = useState(false);
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const [enviando, setEnviando] = useState(false);
  const enviar = async (e) => {
    e.preventDefault(); setEnviando(true); setMsg({ tipo: "info", texto: "" });
    try {
      const r = await api.post("/api/mfa/verificar", { metodo, codigo, recordar_equipo: recordar, equipo: navigator.platform || null });
      guardarEquipo(r.equipo_confiable);
      if (r.aviso) window.alert(r.aviso);
      onListo();
    } catch (e2) { setMsg({ tipo: "error", texto: e2.message }); setCodigo(""); } finally { setEnviando(false); }
  };
  const porCorreo = async () => {
    try { const r = await api.post("/api/mfa/correo"); setMetodo("correo"); setMsg({ tipo: "exito", texto: `Le enviamos un código a ${r.enviado_a}. Vence en 10 minutos.` }); }
    catch (e2) { setMsg({ tipo: "error", texto: e2.message }); }
  };
  return (
    <div className="login-fondo">
      <form className="login" onSubmit={enviar}>
        <div className="marca"><span className="logo">SG</span><div><strong>Verificación en dos pasos</strong><small>{usuario.nombre_completo}</small></div></div>
        <Aviso tipo={msg.tipo}>{msg.texto}</Aviso>
        <p className="pequeno">{metodo === "app" ? "Escriba el código de 6 dígitos que muestra su aplicación autenticadora."
          : metodo === "correo" ? "Escriba el código de 6 dígitos que le enviamos al correo."
            : "Escriba uno de sus códigos de recuperación (sirve una sola vez)."}</p>
        <div className="campo"><label htmlFor="mfa-c">Código</label>
          <input id="mfa-c" value={codigo} onChange={(e) => setCodigo(e.target.value)} autoFocus autoComplete="one-time-code"
                 inputMode={metodo === "recuperacion" ? "text" : "numeric"} required /></div>
        {usuario.mfa?.puede_recordar_equipo && (
          <label className="interruptor"><input type="checkbox" checked={recordar} onChange={(e) => setRecordar(e.target.checked)} />
            <span>Recordar este equipo durante 30 días (solo en su computador personal)</span></label>
        )}
        <button className="btn btn-primario btn-bloque" disabled={enviando}>{enviando ? "Verificando…" : "Verificar"}</button>
        <div className="acciones">
          {metodo !== "app" && <button type="button" className="btn btn-sm" onClick={() => setMetodo("app")}>Usar la aplicación</button>}
          {metodo !== "correo" && <button type="button" className="btn btn-sm" onClick={porCorreo}>Enviarme un código al correo</button>}
          {metodo !== "recuperacion" && <button type="button" className="btn btn-sm" onClick={() => setMetodo("recuperacion")}>Usar un código de recuperación</button>}
        </div>
        <button type="button" className="btn btn-sm" onClick={salir}>Cancelar</button>
        <p className="tenue pequeno">¿Perdió el celular y los códigos? Pida al administrador el reinicio del MFA.</p>
      </form>
    </div>
  );
}

// ------------------------------------------------------------------ configuración (activar o cambiar de celular)
export function ConfigurarMFA({ obligatorio = false, onListo }) {
  const [qr, setQr] = useState(null);
  const [codigo, setCodigo] = useState("");
  const [codigos, setCodigos] = useState(null);
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const generar = async () => {
    try { setQr(await api.post("/api/mfa/configurar")); setMsg({ tipo: "info", texto: "" }); } catch (e) { setMsg({ tipo: "error", texto: e.message }); }
  };
  useEffect(() => { if (obligatorio) generar(); }, [obligatorio]);
  const confirmar = async (e) => {
    e.preventDefault();
    try { const r = await api.post("/api/mfa/confirmar", { codigo }); setCodigos(r.codigos_recuperacion); }
    catch (e2) { setMsg({ tipo: "error", texto: e2.message }); }
  };
  const contenido = (
    <>
      <Aviso tipo={msg.tipo}>{msg.texto}</Aviso>
      {codigos ? <>
        <Aviso tipo="exito">Verificación en dos pasos activada.</Aviso>
        <p><strong>Guarde estos 10 códigos de recuperación</strong> (imprímalos o anótelos). Sirven si pierde el celular; cada uno una sola vez. No se volverán a mostrar.</p>
        <ol className="codigos-recuperacion">{codigos.map((c) => <li key={c}><code>{c}</code></li>)}</ol>
        <div className="acciones">
          <button type="button" className="btn" onClick={() => navigator.clipboard?.writeText(codigos.join("\n"))}>Copiar</button>
          <button type="button" className="btn btn-primario" onClick={onListo}>Ya los guardé</button>
        </div>
      </> : !qr ? (
        <button type="button" className="btn btn-primario" onClick={generar}>Activar la verificación en dos pasos</button>
      ) : (
        <form onSubmit={confirmar}>
          <ol className="pasos-mfa">
            <li>Instale en su celular una aplicación autenticadora (Google Authenticator, Microsoft Authenticator u otra).</li>
            <li>En la aplicación, agregue una cuenta y escanee este código:</li>
          </ol>
          <div className="qr-mfa" dangerouslySetInnerHTML={{ __html: qr.qr_svg }} />
          <p className="tenue pequeno">Si no puede escanear, escriba esta clave en la aplicación: <code>{qr.secreto}</code></p>
          <div className="campo"><label htmlFor="mfa-n">3. Escriba el código de 6 dígitos que aparece</label>
            <input id="mfa-n" value={codigo} onChange={(e) => setCodigo(e.target.value)} inputMode="numeric" autoComplete="one-time-code" required /></div>
          <button className="btn btn-primario">Confirmar</button>
        </form>
      )}
    </>
  );
  if (!obligatorio) return contenido;
  return (
    <div className="login-fondo">
      <div className="login" style={{ maxWidth: 480 }}>
        <div className="marca"><span className="logo">SG</span><div><strong>Active la verificación en dos pasos</strong><small>Su rol la exige y el plazo terminó</small></div></div>
        {contenido}
        <button type="button" className="btn btn-sm" onClick={salir}>Salir</button>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ «Mi seguridad»
export function MiSeguridad({ usuario }) {
  const [e, setE] = useState(null);
  const [cambiar, setCambiar] = useState(false);
  const [codigos, setCodigos] = useState(null);
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const cargar = () => api.get("/api/mfa/estado").then(setE).catch((x) => setMsg({ tipo: "error", texto: x.message }));
  useEffect(() => { cargar(); }, []);
  if (!e) return <Cargando />;
  const intentar = (fn) => async () => { try { await fn(); } catch (x) { setMsg({ tipo: "error", texto: x.message }); } };
  return (
    <section className="pagina">
      <header className="pagina-cab"><div><h1>Mi seguridad</h1><p className="tenue">Verificación en dos pasos (MFA) de su usuario {usuario.nombre_usuario}.</p></div></header>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      <div className="tarjetas">
        <section className="tarjeta">
          <h3>Estado</h3>
          {e.activo ? <p><span className="insignia insignia-normal">Activa</span> · Códigos de recuperación disponibles: <strong>{e.codigos_restantes}</strong></p>
            : <p><span className="insignia insignia-alta">Sin activar</span>{e.requerido ? ` · Su rol la exige. ${e.dias_restantes > 0 ? `Le quedan ${e.dias_restantes} día(s).` : "El plazo terminó."}` : " · Es opcional para su rol, pero recomendada."}</p>}
          {(!e.activo || cambiar) ? <ConfigurarMFA onListo={() => { setCambiar(false); cargar(); }} /> : (
            <div className="acciones">
              <button className="btn" onClick={intentar(async () => { const r = await api.post("/api/mfa/recuperacion"); setCodigos(r.codigos_recuperacion); cargar(); })}>Generar códigos de recuperación nuevos</button>
              <button className="btn" onClick={() => setCambiar(true)}>Cambié de celular</button>
              <button className="btn" onClick={intentar(async () => { const r = await api.post("/api/mfa/equipos/cerrar"); setMsg({ tipo: "exito", texto: `${r.equipos_cerrados} equipo(s) olvidados: pedirán el código otra vez.` }); })}>Olvidar equipos recordados</button>
            </div>
          )}
          {codigos && <><p><strong>Códigos nuevos</strong> (los anteriores ya no sirven):</p><ol className="codigos-recuperacion">{codigos.map((c) => <li key={c}><code>{c}</code></li>)}</ol></>}
        </section>
        <ReiniciosMFA usuario={usuario} />
      </div>
    </section>
  );
}

function ReiniciosMFA({ usuario }) {
  const [filas, setFilas] = useState(null);
  const [nuevo, setNuevo] = useState({ id_usuario: null, motivo: "" });
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const cargar = () => api.get("/api/mfa/reinicios").then(setFilas).catch(() => setFilas(false));
  useEffect(() => { cargar(); }, []);
  if (filas === false || filas === null) return null;   // solo administrador y Presidencia Nacional
  const decidir = (id, d) => async () => {
    try { const obs = d === "rechazar" ? window.prompt("Motivo del rechazo:") : null; if (d === "rechazar" && !obs) return;
      const r = await api.post(`/api/mfa/reinicios/${id}/${d}`, { observacion: obs }); setMsg({ tipo: "exito", texto: `Reinicio ${r.estado.toLowerCase()}.` }); cargar(); }
    catch (e) { setMsg({ tipo: "error", texto: e.message }); }
  };
  return (
    <section className="tarjeta">
      <h3>Reinicios del MFA (pérdida del celular)</h3>
      <p className="tenue pequeno">Los solicita el administrador y los aprueba la Presidencia Nacional (otra persona). El usuario deberá configurar el MFA de nuevo.</p>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      {usuario.codigo_rol === "ADMIN" && (
        <div className="rejilla-campos">
          <Campo campo={{ nombre: "id_usuario", etiqueta: "Usuario", tipo: "fk", fk: "usuarios" }} valor={nuevo.id_usuario} onCambio={(v) => setNuevo({ ...nuevo, id_usuario: v })} contexto={{}} />
          <Campo campo={{ nombre: "motivo", etiqueta: "Motivo", tipo: "text" }} valor={nuevo.motivo} onCambio={(v) => setNuevo({ ...nuevo, motivo: v || "" })} contexto={{}} />
          <div><button className="btn" disabled={!nuevo.id_usuario} onClick={async () => {
            try { const r = await api.post("/api/mfa/reinicios", nuevo); setMsg({ tipo: "exito", texto: r.mensaje }); setNuevo({ id_usuario: null, motivo: "" }); cargar(); }
            catch (e) { setMsg({ tipo: "error", texto: e.message }); }
          }}>Solicitar reinicio</button></div>
        </div>
      )}
      <ul className="lista-meses">
        {filas.map((f) => (
          <li key={f.id_reinicio}><strong>{f.nombre_usuario}</strong><span>{formatear(f.fecha_solicitud, "datetime")} · {f.motivo} · pidió {f.solicitado_por}</span>
            <span className="insignia insignia-baja">{f.estado.toLowerCase()}</span>
            {f.estado === "PENDIENTE" && usuario.codigo_rol !== "ADMIN" && <>
              <button className="btn btn-sm btn-primario" onClick={decidir(f.id_reinicio, "aprobar")}>Aprobar</button>
              <button className="btn btn-sm" onClick={decidir(f.id_reinicio, "rechazar")}>Rechazar</button></>}
          </li>
        ))}
        {filas.length === 0 && <li className="vacio">No hay solicitudes.</li>}
      </ul>
    </section>
  );
}

// ------------------------------------------------------------------ doble verificación para acciones críticas
// Se monta una vez en la aplicación: cuando la API responde 428 abre esta ventana y espera el código.
export function PedirCodigo() {
  const [pedido, setPedido] = useState(null);   // { mensaje, resolver }
  const [codigo, setCodigo] = useState("");
  const [metodo, setMetodo] = useState("app");
  const [nota, setNota] = useState("");
  useEffect(() => alPedirCodigo((mensaje) => new Promise((resolver) => { setCodigo(""); setNota(""); setPedido({ mensaje, resolver }); })), []);
  if (!pedido) return null;
  const terminar = (valor) => { pedido.resolver(valor); setPedido(null); };
  const enviar = (e) => { e.preventDefault(); const c = codigo.trim(); if (c) terminar({ codigo: c, metodo }); };
  const porCorreo = async () => {
    try { const r = await api.post("/api/mfa/correo"); setMetodo("correo"); setNota(`Código enviado a ${r.enviado_a}.`); }
    catch (x) { setNota(x.message); }
  };
  return (
    <div className="modal-fondo">
      <form className="modal" style={{ maxWidth: 420 }} onSubmit={enviar}>
        <header className="modal-cab"><h2>Confirme que es usted</h2><button type="button" className="btn-icono" onClick={() => terminar(null)}>×</button></header>
        <div className="modal-cuerpo">
          <Aviso tipo="advertencia">{pedido.mensaje}</Aviso>
          <Aviso tipo="info">{nota}</Aviso>
          <p className="pequeno">{metodo === "app" ? "Código de 6 dígitos de su aplicación autenticadora." : metodo === "correo" ? "Código de 6 dígitos enviado a su correo." : "Uno de sus códigos de recuperación."}</p>
          <div className="campo"><label htmlFor="pc-c">Código</label>
            <input id="pc-c" value={codigo} onChange={(e) => setCodigo(e.target.value)} autoFocus autoComplete="one-time-code" inputMode={metodo === "recuperacion" ? "text" : "numeric"} required /></div>
          <div className="acciones" style={{ marginTop: 10 }}>
            {metodo !== "app" && <button type="button" className="btn btn-sm" onClick={() => setMetodo("app")}>Usar la aplicación</button>}
            {metodo !== "correo" && <button type="button" className="btn btn-sm" onClick={porCorreo}>Enviarme un código al correo</button>}
            {metodo !== "recuperacion" && <button type="button" className="btn btn-sm" onClick={() => setMetodo("recuperacion")}>Código de recuperación</button>}
          </div>
          <p className="tenue pequeno">La confirmación vale 5 minutos para otras acciones críticas.</p>
        </div>
        <footer className="modal-pie"><span className="espacio" /><button type="button" className="btn" onClick={() => terminar(null)}>Cancelar</button><button className="btn btn-primario">Confirmar</button></footer>
      </form>
    </div>
  );
}

// Aviso del plazo de gracia: el rol exige MFA y aún no lo activa
export function AvisoPlazoMFA({ mfa, irA }) {
  if (!mfa || !mfa.requerido || mfa.activo) return null;
  return (
    <div className="aviso-mfa">
      <strong>Active la verificación en dos pasos.</strong> Su rol la exige; {mfa.dias_restantes > 0 ? `le quedan ${mfa.dias_restantes} día(s)` : "hoy vence el plazo"}. Después no podrá ingresar sin configurarla.
      <button className="btn btn-sm btn-primario" onClick={irA}>Activar ahora</button>
    </div>
  );
}
