// Portal del afiliado (autoservicio): solo sus propios datos. Pensado primero para celular.
import { useEffect, useState } from "react";
import { api } from "./api.js";
import { Aviso, Cargando, formatear } from "./ui.jsx";
import { MiSeguridad } from "./MFA.jsx";
import { MiAfiliacion } from "./Expediente.jsx";

const pct = (v) => (v === null || v === undefined ? "—" : `${String(Number(v)).replace(".", ",")} %`);
const descargar = (blob, nombre) => { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = nombre; a.click(); };

export function Portal({ usuario, onSalir, embebido = false }) {
  const solicitante = !!usuario.solicitante;   // cuenta creada desde la solicitud: aún no es afiliado
  const [pestana, setPestana] = useState(solicitante ? "afiliacion" : "perfil");
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const avisar = (tipo, texto) => setMsg({ tipo, texto });

  // Confirmación de un correo nuevo (enlace recibido por correo)
  useEffect(() => {
    const h = window.location.hash;
    if (h.startsWith("#/confirmar-correo")) {
      const t = new URLSearchParams(h.split("?")[1] || "").get("t");
      if (t) api.post("/api/autoservicio/correo/confirmar", { token: t })
        .then((r) => avisar("exito", `Correo confirmado: ${r.correo}`)).catch((e) => avisar("error", e.message))
        .finally(() => { window.location.hash = "/"; });
    }
  }, []);

  const PESTANAS = solicitante
    ? [["afiliacion", "Mi afiliación"], ["seguridad", "Seguridad"]]
    : [["perfil", "Mi perfil"], ["aportes", "Mis aportes"], ["certificados", "Certificados"], ["documentos", "Mis documentos"], ["solicitudes", "Mis solicitudes"], ["privacidad", "Privacidad"], ...(embebido ? [] : [["seguridad", "Seguridad"]])];
  return (
    <div className={embebido ? "portal portal-embebido" : "portal"}>
      {!embebido && (
        <header className="portal-cab">
          <div className="marca"><span className="logo" aria-hidden="true" /><div><span className="palabra-marca" role="img" aria-label="ARCADIO" /><strong>{solicitante ? "Mi solicitud de afiliación" : "Portal del afiliado"}</strong><small>{usuario.nombre_completo}</small></div></div>
          <button className="btn btn-sm" onClick={onSalir}>Salir</button>
        </header>
      )}
      {embebido && <h1>Mi espacio</h1>}
      <nav className="portal-pestanas" role="tablist">
        {PESTANAS.map(([k, t]) => <button key={k} role="tab" aria-selected={pestana === k} className={pestana === k ? "activa" : ""} onClick={() => setPestana(k)}>{t}</button>)}
      </nav>
      <Aviso tipo={msg.tipo} onCerrar={() => avisar("info", "")}>{msg.texto}</Aviso>
      <div className="portal-cuerpo">
        {pestana === "afiliacion" && <MiAfiliacion avisar={avisar} />}
        {pestana === "documentos" && <MiAfiliacion avisar={avisar} />}
        {pestana === "perfil" && <MiPerfil avisar={avisar} />}
        {pestana === "aportes" && <MisAportes />}
        {pestana === "certificados" && <Certificados avisar={avisar} />}
        {pestana === "solicitudes" && <MisSolicitudes />}
        {pestana === "privacidad" && <Privacidad avisar={avisar} />}
        {pestana === "seguridad" && <MiSeguridad usuario={usuario} />}
      </div>
    </div>
  );
}

function usarDatos(ruta) {
  const [datos, setDatos] = useState(null);
  const [error, setError] = useState("");
  const cargar = () => api.get(ruta).then(setDatos).catch((e) => setError(e.message));
  useEffect(() => { cargar(); }, [ruta]); // eslint-disable-line react-hooks/exhaustive-deps
  return [datos, error, cargar, setDatos];
}

function MiPerfil({ avisar }) {
  const [p, error, , setP] = usarDatos("/api/autoservicio/perfil");
  const [tel, setTel] = useState(null);
  const [correo, setCorreo] = useState("");
  if (error) return <Aviso tipo="error">{error}</Aviso>;
  if (!p) return <Cargando />;
  const filas = [["Nombre", p.nombre], ["Documento", p.documento], ["Estado", p.afiliado_activo ? "Afiliado activo" : "Afiliación inactiva"],
    ["Afiliado desde", formatear(p.fecha_afiliacion, "date")], ["Junta", p.junta], ["Empresa", p.empresa], ["Sede", p.sede || "Sede central"],
    ["Salario registrado", formatear(p.salario, "decimal")], ["Aporte sindical", pct(p.porcentaje_aporte)],
    ...(p.cargos ? [["Cargos", p.cargos.join("; ")]] : [])];
  return (
    <div className="tarjetas">
      <section className="tarjeta">
        <dl className="datos">{filas.map(([k, v]) => <div key={k}><dt>{k}</dt><dd>{v || "—"}</dd></div>)}</dl>
        <p className="tenue pequeno">Si algún dato no es correcto, presente una solicitud de rectificación a su junta.</p>
      </section>
      <section className="tarjeta">
        <h3>Contacto</h3>
        <div className="campo"><label htmlFor="tel">Teléfono</label>
          <div className="fila-accion"><input id="tel" value={tel ?? p.telefono ?? ""} onChange={(e) => setTel(e.target.value)} inputMode="tel" />
            <button className="btn" onClick={async () => { try { setP(await api.put("/api/autoservicio/perfil", { telefono: tel })); setTel(null); avisar("exito", "Teléfono actualizado."); } catch (e) { avisar("error", e.message); } }}>Guardar</button></div>
        </div>
        <div className="campo"><label htmlFor="cor">Correo ({p.correo})</label>
          <div className="fila-accion"><input id="cor" type="email" placeholder="Correo nuevo" value={correo} onChange={(e) => setCorreo(e.target.value)} />
            <button className="btn" onClick={async () => { try { const r = await api.post("/api/autoservicio/correo", { correo }); setCorreo(""); avisar("exito", r.mensaje + " Ábralo para confirmar el cambio."); } catch (e) { avisar("error", e.message); } }}>Cambiar</button></div>
          <small className="tenue">El cambio se confirma con un enlace enviado al correo nuevo.</small>
        </div>
      </section>
    </div>
  );
}

function MisAportes() {
  const [filas, error] = usarDatos("/api/autoservicio/aportes");
  if (error) return <Aviso tipo="error">{error}</Aviso>;
  if (!filas) return <Cargando />;
  const clase = (e) => (e === "AL DÍA" ? "insignia-normal" : e === "LA EMPRESA NO HA REPORTADO EL APORTE" ? "insignia-alta" : "insignia-baja");
  return (
    <section className="tarjeta">
      <p className="tenue pequeno">La cuota se descuenta por nómina. Si la empresa no reporta un mes, la diferencia es de la empresa, no suya.</p>
      <ul className="lista-meses">
        {filas.map((f) => (
          <li key={f.periodo}>
            <strong>{f.periodo}</strong>
            <span>{pct(f.porcentaje)} · {f.registrado ? formatear(f.registrado, "decimal") : f.esperado ? `esperado ${formatear(f.esperado, "decimal")}` : "—"}</span>
            <span className={`insignia ${clase(f.estado)}`}>{f.estado.toLowerCase()}</span>
          </li>
        ))}
        {filas.length === 0 && <li className="vacio">Sin meses para mostrar.</li>}
      </ul>
    </section>
  );
}

function Certificados({ avisar }) {
  const [lista, error, cargar] = usarDatos("/api/autoservicio/certificados");
  const emitir = (tipo) => async () => {
    try {
      const b = await api.postBlob("/api/autoservicio/certificados", { tipo });
      descargar(b, tipo === "AFILIACION" ? "certificado_afiliacion.pdf" : "paz_y_salvo.pdf"); cargar();
      avisar("exito", "Certificado generado. Cualquier entidad puede verificarlo con el código impreso.");
    } catch (e) { avisar("error", e.message); }
  };
  if (error) return <Aviso tipo="error">{error}</Aviso>;
  return (
    <section className="tarjeta">
      <div className="acciones">
        <button className="btn btn-primario" onClick={emitir("AFILIACION")}>Certificado de afiliación</button>
        <button className="btn" onClick={emitir("PAZ_Y_SALVO")}>Paz y salvo</button>
      </div>
      <h3>Emitidos</h3>
      {!lista ? <Cargando /> : (
        <ul className="lista-meses">
          {lista.map((c) => (
            <li key={c.codigo}><strong>{c.tipo === "AFILIACION" ? "Afiliación" : "Paz y salvo"}</strong><span>{formatear(c.fecha_emision, "datetime")} · código {c.codigo}</span>
              <button className="btn btn-sm" onClick={async () => { try { descargar(await api.descargar(`/api/autoservicio/certificados/${c.codigo}/pdf`), `certificado_${c.codigo}.pdf`); } catch (e) { avisar("error", e.message); } }}>Descargar</button></li>
          ))}
          {lista.length === 0 && <li className="vacio">Aún no ha descargado certificados.</li>}
        </ul>
      )}
    </section>
  );
}

function MisSolicitudes() {
  const [filas, error] = usarDatos("/api/autoservicio/solicitudes");
  if (error) return <Aviso tipo="error">{error}</Aviso>;
  if (!filas) return <Cargando />;
  return (
    <section className="tarjeta">
      <ul className="lista-meses">
        {filas.map((f) => <li key={f.radicado}><strong>{f.tipo}</strong><span>{f.radicado} · {formatear(f.fecha, "datetime")}</span><span className="insignia insignia-baja">{f.estado.toLowerCase()}</span>{f.detalle && <small className="tenue">{f.detalle}</small>}</li>)}
        {filas.length === 0 && <li className="vacio">No tiene solicitudes. Para consultas o reclamos sobre sus datos escriba al correo de su junta.</li>}
      </ul>
    </section>
  );
}

function Privacidad({ avisar }) {
  const [d, error, cargar] = usarDatos("/api/autoservicio/privacidad");
  if (error) return <Aviso tipo="error">{error}</Aviso>;
  if (!d) return <Cargando />;
  return (
    <div className="tarjetas">
      <section className="tarjeta">
        <h3>Mis autorizaciones (Ley 1581)</h3>
        <ul className="lista-meses">
          {(d.autorizaciones || []).map((a) => (
            <li key={a.finalidad}><strong>{a.nombre}</strong><span className="insignia insignia-baja">{a.estado.toLowerCase()}</span>
              {!a.obligatoria && <button className="btn btn-sm" onClick={async () => {
                try { await api.post("/api/autoservicio/privacidad", { finalidad: a.finalidad, otorgada: a.estado !== "AUTORIZADA" }); cargar(); avisar("exito", "Autorización actualizada."); }
                catch (e) { avisar("error", e.message); }
              }}>{a.estado === "AUTORIZADA" ? "Retirar" : "Autorizar"}</button>}</li>
          ))}
        </ul>
      </section>
      <section className="tarjeta">
        <h3>Quién ha consultado mis datos</h3>
        <ul className="lista-meses">
          {(d.accesos || []).map((a, i) => <li key={i}><strong>{formatear(a.fecha, "datetime")}</strong><span>{a.usuario} · {a.tipo.toLowerCase().replace("_", " ")} · {a.sobre}</span></li>)}
          {!(d.accesos || []).length && <li className="vacio">Nadie ha consultado sus datos.</li>}
        </ul>
      </section>
    </div>
  );
}

// ------------------------------------------------------------------ activación de la cuenta (sin iniciar sesión)
export function ActivarCuenta() {
  const t = new URLSearchParams(window.location.hash.split("?")[1] || "").get("t") || "";
  const [inv, setInv] = useState(null);
  const [error, setError] = useState("");
  const [f, setF] = useState({ nombre_usuario: "", contrasena: "", confirmar: "", acepta_politica: false, acepta_comunicaciones: false, acepta_imagen: false });
  const [listo, setListo] = useState("");
  useEffect(() => {
    api.get("/api/publico/invitacion", { t }).then((r) => { setInv(r); setF((x) => ({ ...x, nombre_usuario: r.usuario_sugerido })); })
      .catch((e) => setError(e.message));
  }, [t]);
  const enviar = async (e) => {
    e.preventDefault(); setError("");
    if (f.contrasena !== f.confirmar) { setError("Las contraseñas no coinciden."); return; }
    try { const r = await api.post("/api/publico/activar", { token: t, ...f }); setListo(r.nombre_usuario); }
    catch (e2) { setError(e2.message); }
  };
  return (
    <div className="login-fondo">
      <form className="login portal-activar" onSubmit={enviar}>
        <h1>Portal del afiliado</h1>
        <Aviso tipo="error">{error}</Aviso>
        {listo ? <>
          <Aviso tipo="exito">Su cuenta quedó creada. Su usuario es <strong>{listo}</strong>.</Aviso>
          <a className="btn btn-primario" href="#/">Ingresar</a>
        </> : inv && <>
          <p>Hola, {inv.nombre}. Cree su usuario y contraseña.</p>
          <div className="campo"><label htmlFor="au">Usuario</label><input id="au" value={f.nombre_usuario} onChange={(e) => setF({ ...f, nombre_usuario: e.target.value })} autoComplete="username" required /></div>
          <div className="campo"><label htmlFor="ap">Contraseña</label><input id="ap" type="password" value={f.contrasena} onChange={(e) => setF({ ...f, contrasena: e.target.value })} autoComplete="new-password" required /></div>
          <div className="campo"><label htmlFor="ac">Confirmar contraseña</label><input id="ac" type="password" value={f.confirmar} onChange={(e) => setF({ ...f, confirmar: e.target.value })} autoComplete="new-password" required /></div>
          <details className="politica"><summary>Política de tratamiento de datos (versión {inv.politica_version})</summary><p className="pequeno" style={{ whiteSpace: "pre-wrap" }}>{inv.politica_texto}</p></details>
          <label className="interruptor"><input type="checkbox" checked={f.acepta_politica} onChange={(e) => setF({ ...f, acepta_politica: e.target.checked })} /><span>Autorizo el tratamiento de mis datos, incluida mi afiliación sindical, para la gestión sindical (obligatorio).</span></label>
          <label className="interruptor"><input type="checkbox" checked={f.acepta_comunicaciones} onChange={(e) => setF({ ...f, acepta_comunicaciones: e.target.checked })} /><span>Acepto recibir comunicaciones del sindicato.</span></label>
          <label className="interruptor"><input type="checkbox" checked={f.acepta_imagen} onChange={(e) => setF({ ...f, acepta_imagen: e.target.checked })} /><span>Autorizo el uso de mi imagen en actividades del sindicato.</span></label>
          <button className="btn btn-primario" disabled={!f.acepta_politica}>Crear mi cuenta</button>
        </>}
        {!inv && !error && <Cargando />}
      </form>
    </div>
  );
}

// ------------------------------------------------------------------ textos legales públicos (#/legal/...)
const TEXTOS_LEGALES = [["politica-datos", "Política de datos"], ["aviso-privacidad", "Aviso de privacidad"], ["reglamento-pqrsd", "Reglamento de PQRSD"]];

export function EnlacesLegales() {
  return (
    <nav className="enlaces-legales" aria-label="Documentos legales">
      {TEXTOS_LEGALES.map(([k, t]) => <a key={k} href={`#/legal/${k}`}>{t}</a>)}
    </nav>
  );
}

export function TextoLegal() {
  const clave = (window.location.hash.split("/")[2] || "").split("?")[0];
  const [d, setD] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => { api.get(`/api/publico/legal/${encodeURIComponent(clave)}`).then(setD).catch((e) => setError(e.message)); }, [clave]);
  return (
    <div className="login-fondo">
      <article className="login texto-legal">
        <span className="login-logo" role="img" aria-label="ARCADIO" />
        {error ? <Aviso tipo="advertencia">{error}</Aviso> : !d ? <Cargando /> : <>
          <h1>{d.titulo}</h1>
          <p className="tenue pequeno">Versión {d.numero_version}{d.fecha_vigencia ? ` · vigente desde el ${formatear(d.fecha_vigencia, "date")}` : ""}</p>
          <div className="texto-legal-cuerpo">{d.texto}</div>
        </>}
        <EnlacesLegales />
        <a className="tenue pequeno" href="#/">Volver</a>
      </article>
    </div>
  );
}

// ------------------------------------------------------------------ verificación pública de certificados
export function VerificarCertificado() {
  const [codigo, setCodigo] = useState(new URLSearchParams(window.location.hash.split("?")[1] || "").get("c") || "");
  const [r, setR] = useState(null);
  const [error, setError] = useState("");
  const verificar = async (e) => {
    e?.preventDefault(); setError(""); setR(null);
    try { setR(await api.get(`/api/publico/certificados/${encodeURIComponent(codigo.trim())}`)); } catch (e2) { setError(e2.message); }
  };
  return (
    <div className="login-fondo">
      <form className="login" onSubmit={verificar}>
        <h1>Verificar un certificado</h1>
        <p className="tenue">Escriba el código de verificación impreso en el certificado.</p>
        <div className="campo"><label htmlFor="vc">Código</label><input id="vc" value={codigo} onChange={(e) => setCodigo(e.target.value.toUpperCase())} required /></div>
        <button className="btn btn-primario">Verificar</button>
        <Aviso tipo="error">{error}</Aviso>
        {r && <Aviso tipo={r.valido ? "exito" : "advertencia"}>
          <strong>{r.valido ? "Certificado válido" : "Certificado NO vigente"}</strong><br />
          {r.tipo} expedido el {formatear(r.fecha_emision, "date")} a {r.titular} (documento {r.documento}).
          {!r.afiliacion_vigente && " La persona ya no es afiliada."}
        </Aviso>}
        <a className="tenue pequeno" href="#/">Volver</a>
      </form>
    </div>
  );
}
