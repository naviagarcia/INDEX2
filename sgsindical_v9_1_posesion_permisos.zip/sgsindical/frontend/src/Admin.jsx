import { Fragment, useEffect, useState } from "react";
import { api, ErrorApi } from "./api.js";
import { Aviso, Cargando, formatear } from "./ui.jsx";

const MODULOS = ["GOBERNANZA", "DOCUMENTAL", "FINANZAS", "AUDITORIA", "ADMINISTRACION"];
const ACCIONES = [
  ["puede_consultar", "Consultar"], ["puede_registrar", "Registrar"], ["puede_actualizar", "Actualizar"],
  ["puede_eliminar", "Inactivar / anular"], ["puede_ver_vistas", "Vistas"],
];

export function PermisosPagina({ permisos }) {
  const [roles, setRoles] = useState([]);
  const [filas, setFilas] = useState({});
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const editable = permisos.ADMINISTRACION?.actualizar;
  const puedeCrear = permisos.ADMINISTRACION?.registrar;

  const cargar = async () => {
    const [r, p] = await Promise.all([api.get("/api/r/roles", { tam: 200 }), api.get("/api/r/permisos", { tam: 200 })]);
    setRoles(r.filas);
    setFilas(Object.fromEntries(p.filas.map((f) => [`${f.codigo_rol}|${f.modulo}`, f])));
  };
  useEffect(() => { cargar().catch((e) => setMsg({ tipo: "error", texto: e.message })); }, []);

  const alternar = async (rol, modulo, accion) => {
    const clave = `${rol}|${modulo}`;
    const actual = filas[clave];
    try {
      let r;
      if (!actual) {
        r = await api.post("/api/r/permisos", { codigo_rol: rol, modulo, [accion]: true });
      } else {
        r = await api.put("/api/r/permisos/registro", { [accion]: !actual[accion], version: actual.version }, { codigo_rol: rol, modulo });
      }
      setFilas((s) => ({ ...s, [clave]: r }));
      setMsg({ tipo: "exito", texto: `Permiso actualizado para ${rol} en ${modulo}. Aplica desde la siguiente acción del usuario.` });
    } catch (e) {
      if (e instanceof ErrorApi && e.status === 409) { await cargar(); setMsg({ tipo: "advertencia", texto: "Otro administrador cambió esta matriz; se recargó con los datos actuales." }); }
      else setMsg({ tipo: "error", texto: e.message });
    }
  };

  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <h1>Matriz de permisos</h1>
          <p className="tenue">Qué puede hacer cada rol en cada módulo. Los cambios quedan en la bitácora de auditoría.</p>
        </div>
        {puedeCrear && <div className="acciones"><a className="btn" href="#/r/roles">Gestionar roles</a></div>}
      </header>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      {roles.length === 0 ? <Cargando /> : (
        <div className="tabla-marco">
          <table className="tabla matriz">
            <thead>
              <tr><th rowSpan={2}>Rol</th>{MODULOS.map((m) => <th key={m} colSpan={5} className="grupo">{m}</th>)}</tr>
              <tr>{MODULOS.map((m) => ACCIONES.map(([a, t]) => <th key={m + a} className="vertical" title={`${t} en ${m}`}>{t}</th>))}</tr>
            </thead>
            <tbody>
              {roles.map((r) => (
                <tr key={r.codigo_rol}>
                  <th scope="row" title={r.descripcion}>{r.nombre_rol}<br /><small className="tenue">{r.codigo_rol}</small></th>
                  {MODULOS.map((m) => (
                    <Fragment key={m}>
                      {ACCIONES.map(([a, t]) => {
                        const bloqueado = r.codigo_rol === "ADMIN" && m === "ADMINISTRACION" && (a === "puede_consultar" || a === "puede_actualizar");
                        return (
                          <td key={a} className="centro">
                            <input type="checkbox" aria-label={`${r.codigo_rol} ${t} ${m}`}
                                   checked={!!filas[`${r.codigo_rol}|${m}`]?.[a]} disabled={!editable || bloqueado}
                                   onChange={() => alternar(r.codigo_rol, m, a)} />
                          </td>
                        );
                      })}
                    </Fragment>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

export function SesionesPagina({ permisos }) {
  const [filas, setFilas] = useState(null);
  const [msg, setMsg] = useState("");
  const cargar = () => api.get("/api/admin/sesiones").then(setFilas).catch((e) => setMsg(e.message));
  useEffect(() => { cargar(); }, []);
  const revocar = async (s) => {
    if (!window.confirm(`¿Cerrar la sesión de ${s.nombre_usuario}?`)) return;
    try { await api.post(`/api/admin/sesiones/${s.id_sesion}/revocar`); cargar(); } catch (e) { setMsg(e.message); }
  };
  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div><h1>Sesiones activas</h1><p className="tenue">Usuarios conectados en este momento. Cerrar una sesión la invalida de inmediato.</p></div>
        <div className="acciones"><button className="btn" onClick={cargar}>⟳</button></div>
      </header>
      <Aviso tipo="error" onCerrar={() => setMsg("")}>{msg}</Aviso>
      {!filas ? <Cargando /> : (
        <div className="tabla-marco">
          <table className="tabla">
            <thead><tr><th>Usuario</th><th>Rol</th><th>Inicio</th><th>Última actividad</th><th>Vence</th><th>IP</th><th>Equipo</th><th /></tr></thead>
            <tbody>
              {filas.map((s) => (
                <tr key={s.id_sesion}>
                  <td>{s.nombre_completo} <span className="tenue">({s.nombre_usuario})</span></td>
                  <td>{s.codigo_rol}</td><td>{formatear(s.fecha_emision)}</td><td>{formatear(s.ultima_actividad)}</td>
                  <td>{formatear(s.fecha_expiracion)}</td><td>{s.ip_origen || "—"}</td><td>{s.equipo || "—"}</td>
                  <td>{s.es_la_mia ? <span className="tenue">Esta sesión</span> : permisos.ADMINISTRACION?.actualizar &&
                    <button className="btn btn-sm btn-peligro" onClick={() => revocar(s)}>Cerrar sesión</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

export function BackupsPagina({ permisos }) {
  const [info, setInfo] = useState(null);
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const [trabajando, setTrabajando] = useState(false);
  const cargar = () => api.get("/api/admin/backups").then(setInfo).catch((e) => setMsg({ tipo: "error", texto: e.message }));
  useEffect(() => { cargar(); }, []);

  const respaldar = async () => {
    setTrabajando(true); setMsg({ tipo: "info", texto: "Generando backup… puede tardar según el tamaño de la base." });
    try {
      const r = await api.post("/api/admin/backups");
      setMsg({ tipo: "exito", texto: `Backup ${r.archivo} creado (${(r.tamano_bytes / 1024).toFixed(0)} KB). SHA-256: ${r.hash_sha256}` });
      cargar();
    } catch (e) { setMsg({ tipo: "error", texto: e.message }); } finally { setTrabajando(false); }
  };
  const verificar = async (archivo) => {
    try {
      const r = await api.get(`/api/admin/backups/${archivo}/verificar`);
      setMsg(r.integro ? { tipo: "exito", texto: `${archivo}: íntegro (la huella coincide con la registrada).` }
                       : { tipo: "error", texto: `${archivo}: la huella NO coincide o no hay registro. No lo use para restaurar.` });
    } catch (e) { setMsg({ tipo: "error", texto: e.message }); }
  };

  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div><h1>Backups</h1><p className="tenue">Copias completas con pg_dump, huella SHA-256 y retención automática.</p></div>
        <div className="acciones">
          {permisos.ADMINISTRACION?.registrar && <button className="btn btn-primario" disabled={trabajando || !info?.configurado} onClick={respaldar}>
            {trabajando ? "Respaldando…" : "Hacer backup ahora"}</button>}
        </div>
      </header>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      {info && !info.configurado && <Aviso tipo="advertencia">Los backups no están configurados en este servidor. Defina BACKUP_DATABASE_URL (rol sgs_backup) en el archivo .env.</Aviso>}
      {!info ? <Cargando /> : (
        <>
          <p className="tenue">Carpeta: <code>{info.directorio}</code> · Retención: {info.retencion_dias} días (siempre se conservan los 3 más recientes).</p>
          <div className="tabla-marco">
            <table className="tabla">
              <thead><tr><th>Archivo</th><th>Fecha</th><th className="num">Tamaño</th><th /></tr></thead>
              <tbody>
                {info.archivos.map((a) => (
                  <tr key={a.archivo}>
                    <td><code>{a.archivo}</code></td><td>{formatear(a.fecha)}</td>
                    <td className="num">{(a.tamano_bytes / 1024).toFixed(0)} KB</td>
                    <td><button className="btn btn-sm" onClick={() => verificar(a.archivo)}>Verificar integridad</button></td>
                  </tr>
                ))}
                {info.archivos.length === 0 && <tr><td colSpan={4} className="vacio">Aún no hay backups.</td></tr>}
              </tbody>
            </table>
          </div>
          <p className="tenue">El historial completo (incluidos los fallidos) está en Auditoría → Registro de backups. Para restaurar use <code>ops/restaurar_backup</code> (ver README).</p>
        </>
      )}
    </section>
  );
}

const NOMBRE_TIPO = {
  ACTAS_REUNION: "Actas de reunión", VIGENCIA_DIRECTIVO: "Vencimiento de periodo", INFORME_TRIMESTRAL: "Informe trimestral",
  INACTIVIDAD_DOCUMENTAL: "Inactividad documental", CUMPLEANOS: "Cumpleaños",
};

export function CorreosPagina({ permisos }) {
  const [info, setInfo] = useState(null);
  const [res, setRes] = useState(null);
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const [trabajando, setTrabajando] = useState(false);
  const cargar = () => api.get("/api/admin/notificaciones").then(setInfo).catch((e) => setMsg({ tipo: "error", texto: e.message }));
  useEffect(() => { cargar(); }, []);

  const ejecutar = async (simulacro) => {
    if (!simulacro && !window.confirm("¿Enviar ahora los correos pendientes? Los que ya se enviaron no se repiten.")) return;
    setTrabajando(true); setMsg({ tipo: "info", texto: simulacro ? "Calculando…" : "Enviando…" });
    try {
      const r = await api.post("/api/admin/notificaciones/ejecutar", undefined, { simulacro });
      setRes(r);
      const t = Object.values(r.resumen).reduce((a, c) => ({ e: a.e + c.enviados, f: a.f + c.fallidos }), { e: 0, f: 0 });
      setMsg(simulacro ? { tipo: "info", texto: `Simulacro: se enviarían ${r.vista_previa.length} correo(s). No se envió nada.` }
                       : { tipo: t.f ? "advertencia" : "exito", texto: `${t.e} correo(s) enviado(s)${t.f ? `, ${t.f} fallido(s) (se reintentarán)` : ""}.` });
      cargar();
    } catch (e) { setMsg({ tipo: "error", texto: e.message }); } finally { setTrabajando(false); }
  };

  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div><h1>Correos automáticos</h1><p className="tenue">Alertas por correo. La tarea programada diaria (ops/notificar) los envía sola; aquí puede simular o forzar un envío.</p></div>
        <div className="acciones">
          <button className="btn" disabled={trabajando || !info?.base_configurada} onClick={() => ejecutar(true)}>Simular</button>
          {permisos.ADMINISTRACION?.actualizar && <button className="btn btn-primario" disabled={trabajando || !info?.smtp_configurado} onClick={() => ejecutar(false)}>Enviar ahora</button>}
        </div>
      </header>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      {info && (!info.base_configurada || !info.smtp_configurado) && (
        <Aviso tipo="advertencia">Falta configuración en el archivo .env: {!info.base_configurada && "NOTIFICADOR_DATABASE_URL "}{!info.smtp_configurado && "SMTP_HOST y CORREO_REMITENTE"}.</Aviso>
      )}
      {!info ? <Cargando /> : (
        <>
          <p className="tenue">Remitente: <code>{info.remitente || "—"}</code> · Servidor: <code>{info.servidor || "—"}</code> · Para activar o desactivar: Administración → Tipos de correo automático.</p>
          <div className="tabla-marco">
            <table className="tabla">
              <thead><tr><th>Correo</th><th>Activo</th><th>A quién y cuándo</th><th className="num">Enviados (30 días)</th></tr></thead>
              <tbody>
                {info.tipos.map((t) => {
                  const env = info.ultimos_30_dias.filter((u) => u.codigo_tipo === t.codigo && u.estado === "ENVIADO").reduce((a, u) => a + u.n, 0);
                  return <tr key={t.codigo}><td>{t.nombre}</td><td>{t.activo ? "Sí" : "No"}</td><td>{t.descripcion}{t.dias_umbral ? ` Plazo: ${t.dias_umbral} días.` : ""}</td><td className="num">{env}</td></tr>;
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
      {res && res.vista_previa?.length > 0 && (
        <>
          <h3 style={{ marginTop: 20 }}>Se enviarían</h3>
          <div className="tabla-marco">
            <table className="tabla tabla-compacta">
              <thead><tr><th>Tipo</th><th>Para</th><th>Copia</th><th>Asunto</th></tr></thead>
              <tbody>{res.vista_previa.map((v, i) => <tr key={i}><td>{NOMBRE_TIPO[v.tipo] || v.tipo}</td><td>{v.para}</td><td>{v.copia.join(", ") || "—"}</td><td>{v.asunto}</td></tr>)}</tbody>
            </table>
          </div>
        </>
      )}
    </section>
  );
}
