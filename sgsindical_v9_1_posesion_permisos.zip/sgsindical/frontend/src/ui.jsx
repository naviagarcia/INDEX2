import { useEffect, useRef, useState } from "react";
import { api } from "./api.js";

// ------------------------------------------------------------------ formato
const fmtNumero = new Intl.NumberFormat("es-CO", { maximumFractionDigits: 2 });
const fmtFecha = new Intl.DateTimeFormat("es-CO", { dateStyle: "medium" });
const fmtFechaHora = new Intl.DateTimeFormat("es-CO", { dateStyle: "medium", timeStyle: "short" });

export function formatear(valor, tipo) {
  if (valor === null || valor === undefined || valor === "") return "—";
  if (tipo === "bool" || typeof valor === "boolean") return valor ? "Sí" : "No";
  if (tipo === "decimal") return "$ " + fmtNumero.format(Number(valor));
  if (tipo === "date" && /^\d{4}-\d{2}-\d{2}$/.test(valor)) return fmtFecha.format(new Date(valor + "T00:00:00"));
  if ((tipo === "datetime" || tipo === "date") && !isNaN(Date.parse(valor))) return fmtFechaHora.format(new Date(valor));
  if (tipo === "json") return JSON.stringify(valor);
  if (typeof valor === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(valor)) return fmtFechaHora.format(new Date(valor));
  return String(valor);
}

export const titular = (s) => s.replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase());

// ------------------------------------------------------------------ etiquetas de llaves foráneas (con caché)
const cacheEtiquetas = {};
export async function cargarEtiquetas(recurso, ids) {
  const c = (cacheEtiquetas[recurso] ||= {});
  const faltan = [...new Set(ids.filter((i) => i !== null && i !== undefined && !(String(i) in c)).map(String))];
  if (faltan.length) {
    const r = await api.get(`/api/opciones/${recurso}`, { ids: faltan.join(",") }).catch(() => []);
    r.forEach((o) => (c[String(o.valor)] = o.etiqueta));
    faltan.forEach((i) => !(i in c) && (c[i] = `#${i}`));
  }
  return c;
}
export const olvidarEtiquetas = (recurso) => { delete cacheEtiquetas[recurso]; };

// ------------------------------------------------------------------ componentes
export function Aviso({ tipo = "info", children, onCerrar }) {
  if (!children) return null;
  return (
    <div className={`aviso aviso-${tipo}`} role={tipo === "error" ? "alert" : "status"}>
      <div>{children}</div>
      {onCerrar && <button className="btn-icono" onClick={onCerrar} aria-label="Cerrar">×</button>}
    </div>
  );
}

export function Modal({ titulo, onCerrar, children, ancho = 720, pie }) {
  useEffect(() => {
    const f = (e) => e.key === "Escape" && onCerrar();
    window.addEventListener("keydown", f);
    return () => window.removeEventListener("keydown", f);
  }, [onCerrar]);
  return (
    <div className="modal-fondo" onMouseDown={(e) => e.target === e.currentTarget && onCerrar()}>
      <div className="modal" style={{ maxWidth: ancho }} role="dialog" aria-modal="true" aria-label={titulo}>
        <header className="modal-cab">
          <h2>{titulo}</h2>
          <button className="btn-icono" onClick={onCerrar} aria-label="Cerrar">×</button>
        </header>
        <div className="modal-cuerpo">{children}</div>
        {pie && <footer className="modal-pie">{pie}</footer>}
      </div>
    </div>
  );
}

export function Insignia({ nivel }) {
  const n = { "CRÍTICA": "critica", ALTA: "alta", MEDIA: "media", BAJA: "baja" }[nivel] || "normal";
  return <span className={`insignia insignia-${n}`}>{nivel === "NORMAL" ? "Normal" : nivel}</span>;
}

export function Cargando({ texto = "Cargando…" }) {
  return <div className="cargando"><span className="giro" />{texto}</div>;
}

export function Paginador({ pagina, tam, total, onPagina }) {
  const paginas = Math.max(1, Math.ceil(total / tam));
  return (
    <div className="paginador">
      <span>{total.toLocaleString("es-CO")} registro(s)</span>
      <button className="btn" disabled={pagina <= 1} onClick={() => onPagina(pagina - 1)}>‹ Anterior</button>
      <span>Página {pagina} de {paginas}</span>
      <button className="btn" disabled={pagina >= paginas} onClick={() => onPagina(pagina + 1)}>Siguiente ›</button>
    </div>
  );
}

export function SelectorFK({ recurso, valor, onCambio, deshabilitado, requerido, id, depende }) {
  const [texto, setTexto] = useState("");
  const [opciones, setOpciones] = useState([]);
  const [abierto, setAbierto] = useState(false);
  const temporizador = useRef();

  useEffect(() => {
    if (valor === null || valor === undefined || valor === "") { setTexto(""); return; }
    cargarEtiquetas(recurso, [valor]).then((c) => setTexto(c[String(valor)] || String(valor)));
  }, [recurso, valor]);

  const buscar = (q) => {
    clearTimeout(temporizador.current);
    temporizador.current = setTimeout(() => {
      api.get(`/api/opciones/${recurso}`, { q, depende }).then(setOpciones).catch(() => setOpciones([]));
    }, 200);
  };

  return (
    <div className="selector-fk">
      <input
        id={id}
        value={texto}
        disabled={deshabilitado}
        required={requerido && (valor === null || valor === undefined || valor === "")}
        placeholder="Escriba para buscar…"
        onFocus={() => { setAbierto(true); buscar(""); }}
        onBlur={() => setTimeout(() => setAbierto(false), 150)}
        onChange={(e) => { setTexto(e.target.value); setAbierto(true); buscar(e.target.value); if (!e.target.value) onCambio(null); }}
        autoComplete="off"
      />
      {abierto && !deshabilitado && (
        <ul className="selector-lista" role="listbox">
          {!requerido && <li onMouseDown={() => { onCambio(null); setTexto(""); }} className="tenue">(Ninguno)</li>}
          {opciones.map((o) => (
            <li key={o.valor} onMouseDown={() => { onCambio(o.valor); setTexto(o.etiqueta); }}
                className={String(o.valor) === String(valor) ? "activo" : ""}>{o.etiqueta}</li>
          ))}
          {opciones.length === 0 && <li className="tenue">Sin resultados</li>}
        </ul>
      )}
    </div>
  );
}

export function Campo({ campo, valor, onCambio, soloLectura, contexto = {} }) {
  const id = `c_${campo.nombre}`;
  const comun = { id, disabled: soloLectura, required: !!campo.req && !soloLectura };
  let control;
  switch (campo.tipo) {
    case "textarea":
      control = <textarea {...comun} rows={3} value={valor ?? ""} onChange={(e) => onCambio(e.target.value)} />;
      break;
    case "select":
      control = (
        <select {...comun} value={valor ?? ""} onChange={(e) => onCambio(e.target.value || null)}>
          <option value="">{campo.req ? "Seleccione…" : "(Sin valor)"}</option>
          {campo.opc.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
      );
      break;
    case "bool":
      control = (
        <label className="interruptor">
          <input type="checkbox" id={id} disabled={soloLectura} checked={!!valor} onChange={(e) => onCambio(e.target.checked)} />
          <span>{valor ? "Sí" : "No"}</span>
        </label>
      );
      break;
    case "fk":
      control = <SelectorFK id={id} recurso={campo.fk} valor={valor} onCambio={onCambio} deshabilitado={soloLectura} requerido={campo.req}
                            depende={campo.depende ? contexto[campo.depende] : undefined} />;
      break;
    case "int":
      control = <input {...comun} type="number" step="1" value={valor ?? ""} onChange={(e) => onCambio(e.target.value === "" ? null : Number(e.target.value))} />;
      break;
    case "decimal":
      control = <input {...comun} type="number" step="0.01" min="0" value={valor ?? ""} onChange={(e) => onCambio(e.target.value)} />;
      break;
    case "date":
      control = <input {...comun} type="date" value={(valor ?? "").slice(0, 10)} onChange={(e) => onCambio(e.target.value)} />;
      break;
    case "time":
      control = <input {...comun} type="time" value={(valor ?? "").slice(0, 5)} onChange={(e) => onCambio(e.target.value || null)} />;
      break;
    case "datetime":
      control = soloLectura
        ? <input {...comun} value={formatear(valor, "datetime")} readOnly />
        : <input {...comun} type="datetime-local" value={(valor ?? "").slice(0, 16)} onChange={(e) => onCambio(e.target.value)} />;
      break;
    case "json":
      control = <pre className="json">{valor ? JSON.stringify(valor, null, 2) : "—"}</pre>;
      break;
    default:
      control = (
        <input {...comun} type={campo.tipo === "email" ? "email" : campo.tipo === "password" ? "password" : "text"}
               value={valor ?? ""} onChange={(e) => onCambio(e.target.value)} autoComplete="off" />
      );
  }
  return (
    <div className={`campo ${campo.tipo === "textarea" || campo.tipo === "json" ? "campo-ancho" : ""}`}>
      <label htmlFor={id}>{campo.etiqueta}{campo.req && !soloLectura && <span className="req"> *</span>}</label>
      {control}
      {campo.ayuda && <small className="ayuda">{campo.ayuda}</small>}
    </div>
  );
}
