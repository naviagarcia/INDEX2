// Permisos sindicales (art. 2.2.2.5.4 del Decreto 1072 de 2015, modificado por el Decreto 720 de 2024)
// y designación de directivos con posesión por el registro del inspector (db/18).
import { useEffect, useState } from "react";
import { api } from "./api.js";
import { Aviso, Cargando, formatear, Modal, SelectorFK } from "./ui.jsx";

const FINALIDADES = [
  ["ACTIVIDAD_DIRECTIVA", "Funciones directivas (reunión de junta, representación)"],
  ["ASAMBLEA", "Asamblea sindical (delegados)"],
  ["NEGOCIACION_COLECTIVA", "Negociación colectiva"],
  ["CAPACITACION", "Capacitación sindical"],
  ["OTRA", "Otra actividad sindical"],
];
const nombreFinalidad = (f) => (FINALIDADES.find(([k]) => k === f) || [f, f])[1];

const bajar = async (ruta, nombre) => {
  const b = await api.descargar(ruta);
  const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = nombre; a.click();
};

// ------------------------------------------------------------------ solicitar
export function SolicitarPermiso({ onCerrar, onCreado }) {
  const [juntas, setJuntas] = useState(null);
  const [junta, setJunta] = useState("");
  const [q, setQ] = useState("");
  const [opciones, setOpciones] = useState([]);
  const [elegidos, setElegidos] = useState([]);
  const [f, setF] = useState({ finalidad: "ACTIVIDAD_DIRECTIVA", descripcion: "", fecha_inicio: "", fecha_fin: "", jornada: "COMPLETA",
    horas_dia: "", distribucion: "", lugar: "", excepcional: false, motivo_excepcional: "", destinatario: "" });
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const [creado, setCreado] = useState(null);
  const cambiar = (k) => (e) => setF((x) => ({ ...x, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value }));

  useEffect(() => {
    api.get("/api/permisos/juntas").then((j) => { setJuntas(j); if (j.length === 1) setJunta(String(j[0].id_estamento)); })
      .catch((e) => setMsg({ tipo: "error", texto: e.message }));
  }, []);
  useEffect(() => {
    if (!junta) { setOpciones([]); return; }
    const t = setTimeout(() => api.get("/api/permisos/elegibles", { id_estamento: junta, q }).then(setOpciones)
      .catch((e) => setMsg({ tipo: "error", texto: e.message })), 250);
    return () => clearTimeout(t);
  }, [junta, q]);

  const enviar = async (e) => {
    e.preventDefault();
    if (!elegidos.length) { setMsg({ tipo: "error", texto: "Agregue al menos un afiliado." }); return; }
    try {
      const p = await api.post("/api/permisos", { ...f, id_estamento: Number(junta), personas: elegidos.map((x) => x.id_persona) });
      setCreado(p); onCreado?.(p);
    } catch (e2) { setMsg({ tipo: "error", texto: e2.message }); }
  };

  if (creado) {
    return (
      <Modal titulo={`Permiso ${creado.consecutivo} registrado`} onCerrar={onCerrar}
             pie={<><button className="btn btn-primario" onClick={() => bajar(`/api/permisos/${creado.id_permiso}/carta.pdf`, `permiso_${creado.consecutivo}.pdf`)}>
               Descargar la carta (PDF)</button><button className="btn" onClick={onCerrar}>Cerrar</button></>}>
        <p>Firme la carta y radíquela en la sede central de <b>{creado.empresa}</b>, dirigida a {creado.destinatario}.</p>
        <p>La entidad debe notificar su respuesta a más tardar el <b>{formatear(creado.limite_respuesta, "date")}</b>. Si no lo hace, el permiso
          se entiende concedido. Cuando llegue el acto administrativo, regístrelo en «Permisos sindicales» → el permiso → «Registrar la respuesta».</p>
        {creado.excepcional === "SÍ" && <Aviso tipo="advertencia">Se registró como caso excepcional (menor antelación).</Aviso>}
      </Modal>
    );
  }
  return (
    <Modal titulo="Solicitar permiso sindical" onCerrar={onCerrar} ancho={860}
           pie={<><button className="btn btn-primario" form="form-permiso">Registrar la solicitud</button><button className="btn" onClick={onCerrar}>Cancelar</button></>}>
      <p className="tenue pequeno">Los permisos los solicitan por escrito el Presidente o el Secretario General que ejercen el cargo (art. 2.2.2.5.4 del
        Decreto 1072 de 2015, modificado por el Decreto 720 de 2024). La Junta Nacional puede pedirlos para cualquier afiliado; cada junta, para sus
        afiliados y para quienes trabajan en una empresa con sede central en su municipio. Antelación: 8 días hábiles si hay delegados, 4 si todos son
        directivos, 1 en casos excepcionales.</p>
      {juntas === null ? <Cargando /> : juntas.length === 0 ? (
        <Aviso tipo="advertencia">Usted no ejerce hoy la Presidencia ni la Secretaría General de ninguna junta: no puede firmar solicitudes de permiso.</Aviso>
      ) : (
        <form id="form-permiso" onSubmit={enviar}>
          <div className="rejilla-campos">
            <div className="campo"><label htmlFor="p-junta">Junta que solicita</label>
              <select id="p-junta" value={junta} onChange={(e) => { setJunta(e.target.value); setElegidos([]); }} required>
                <option value="">Seleccione…</option>
                {juntas.map((j) => <option key={j.id_estamento} value={j.id_estamento}>{j.junta} — firma como {j.cargo}{j.por_suplencia ? " (suplente)" : ""}</option>)}
              </select></div>
            <div className="campo"><label htmlFor="p-fin">Finalidad</label>
              <select id="p-fin" value={f.finalidad} onChange={cambiar("finalidad")}>{FINALIDADES.map(([k, t]) => <option key={k} value={k}>{t}</option>)}</select></div>
            <div className="campo campo-ancho"><label htmlFor="p-busca">Afiliados (busque por nombre o cédula)</label>
              <input id="p-busca" value={q} onChange={(e) => setQ(e.target.value)} disabled={!junta} placeholder={junta ? "Escriba para buscar…" : "Elija primero la junta"} />
              {junta && opciones.length > 0 && (
                <ul className="lista-simple">
                  {opciones.filter((o) => !elegidos.some((x) => x.id_persona === o.id_persona)).slice(0, 8).map((o) => (
                    <li key={o.id_persona}><button type="button" className="btn btn-sm" onClick={() => setElegidos((x) => [...x, o])}>+ Agregar</button>{" "}
                      {o.afiliado} · {o.identificacion} · {o.empresa} <span className="tenue">({o.directivo ? "directivo" : "delegado"}; {o.motivo_junta.toLowerCase()})</span></li>
                  ))}
                </ul>
              )}
              {elegidos.length > 0 && <p className="pequeno">Incluidos: {elegidos.map((x) => (
                <span key={x.id_persona} className="insignia insignia-normal" style={{ marginRight: 6 }}>{x.afiliado}
                  <button type="button" className="btn-icono" aria-label={`Quitar a ${x.afiliado}`} onClick={() => setElegidos((y) => y.filter((z) => z.id_persona !== x.id_persona))}>×</button></span>))}
              </p>}
            </div>
            <div className="campo"><label htmlFor="p-ini">Desde</label><input id="p-ini" type="date" value={f.fecha_inicio} onChange={cambiar("fecha_inicio")} required /></div>
            <div className="campo"><label htmlFor="p-hasta">Hasta</label><input id="p-hasta" type="date" value={f.fecha_fin} onChange={cambiar("fecha_fin")} required /></div>
            <div className="campo"><label htmlFor="p-jor">Jornada</label>
              <select id="p-jor" value={f.jornada} onChange={cambiar("jornada")}><option value="COMPLETA">Completa</option><option value="PARCIAL">Parcial</option></select></div>
            {f.jornada === "PARCIAL" && <div className="campo"><label htmlFor="p-horas">Horas por día</label>
              <input id="p-horas" type="number" step="0.5" min="0.5" max="24" value={f.horas_dia} onChange={cambiar("horas_dia")} required /></div>}
            <div className="campo campo-ancho"><label htmlFor="p-desc">Descripción de la finalidad</label>
              <textarea id="p-desc" rows={3} value={f.descripcion} onChange={cambiar("descripcion")} required minLength={10}
                        placeholder="Por ejemplo: reunión ordinaria de la Junta Directiva para aprobar el plan de trabajo del semestre." /></div>
            <div className="campo"><label htmlFor="p-lugar">Lugar (opcional)</label><input id="p-lugar" value={f.lugar} onChange={cambiar("lugar")} /></div>
            <div className="campo"><label htmlFor="p-dist">Distribución (opcional, para permisos periódicos)</label><input id="p-dist" value={f.distribucion} onChange={cambiar("distribucion")} placeholder="Por ejemplo: los lunes de 8 a. m. a 12 m." /></div>
            <div className="campo campo-ancho"><label htmlFor="p-dest">Destinatario (opcional)</label>
              <input id="p-dest" value={f.destinatario} onChange={cambiar("destinatario")} placeholder="Si lo deja vacío: el representante legal de la empresa, en su sede central" /></div>
            <div className="campo campo-ancho">
              <label className="interruptor"><input type="checkbox" checked={f.excepcional} onChange={cambiar("excepcional")} /><span>Caso excepcional (menos antelación)</span></label>
              {f.excepcional && <textarea rows={2} aria-label="Motivo del caso excepcional" value={f.motivo_excepcional} onChange={cambiar("motivo_excepcional")} required minLength={10}
                                          placeholder="Explique por qué no se pudo pedir con la antelación ordinaria." />}
            </div>
          </div>
        </form>
      )}
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
    </Modal>
  );
}

// ------------------------------------------------------------------ detalle, respuesta y anulación
export function DetallePermiso({ idPermiso, onCambio }) {
  const [p, setP] = useState(null);
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const [responder, setResponder] = useState(false);
  const cargar = () => api.get(`/api/permisos/${idPermiso}`).then(setP).catch((e) => setMsg({ tipo: "error", texto: e.message }));
  useEffect(() => { cargar(); }, [idPermiso]);
  if (!p) return msg.texto ? <Aviso tipo="error">{msg.texto}</Aviso> : <Cargando />;
  const intentar = (fn) => async () => { try { await fn(); } catch (e) { setMsg({ tipo: "error", texto: e.message }); } };
  return (
    <section className="tarjeta">
      <h4>{p.consecutivo} · {nombreFinalidad(p.finalidad)}</h4>
      <p className="pequeno"><b>{p.diagnostico}</b></p>
      <p className="pequeno">Firma: {p.firma}. Dirigido a: {p.destinatario}, {p.empresa} (sede central). Del {formatear(p.fecha_inicio, "date")} al {formatear(p.fecha_fin, "date")},
        jornada {p.jornada === "COMPLETA" ? "completa" : `parcial (${p.horas_dia} h/día)`}. {p.descripcion}</p>
      <div className="tabla-marco">
        <table className="tabla">
          <thead><tr><th>Afiliado</th><th>Calidad</th><th>Junta habilitada por</th><th>Días solicitados</th><th>Decisión</th><th>Días concedidos</th><th>Motivo de la entidad</th></tr></thead>
          <tbody>{p.beneficiarios.map((b) => (
            <tr key={b.id_beneficiario}><td>{b.afiliado}</td><td>{b.calidad === "DIRECTIVO" ? `Directivo${b.cargo_directivo ? ": " + b.cargo_directivo : ""}` : "Delegado"}</td>
              <td>{b.motivo_junta.toLowerCase()}</td><td className="num">{b.dias_solicitados}</td><td>{b.decision}</td>
              <td className="num">{b.dias_concedidos ?? "—"}</td><td>{b.motivo_entidad ? `${b.causal === "OTRA" ? "⚠ Otra causal: " : ""}${b.motivo_entidad}` : "—"}</td></tr>
          ))}</tbody>
        </table>
      </div>
      <div className="acciones">
        {p.estado !== "ANULADO" && <button className="btn" onClick={intentar(() => bajar(`/api/permisos/${p.id_permiso}/carta.pdf`, `permiso_${p.consecutivo}.pdf`))}>Descargar la carta (PDF)</button>}
        {p.estado === "SOLICITADO" && <button className="btn btn-primario" onClick={() => setResponder(true)}>Registrar la respuesta de la entidad</button>}
        {p.estado !== "ANULADO" && <button className="btn" onClick={intentar(async () => {
          const m = window.prompt("Motivo de la anulación (la junta desiste del permiso):"); if (!m) return;
          await api.post(`/api/permisos/${p.id_permiso}/anular`, { motivo: m });
          setMsg({ tipo: "exito", texto: "Permiso anulado." }); await cargar(); onCambio?.();
        })}>Anular</button>}
      </div>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      {responder && <RespuestaPermiso p={p} onCerrar={() => setResponder(false)} onListo={async (r) => {
        setResponder(false);
        setMsg({ tipo: r.resultado === "EXTEMPORANEA" ? "advertencia" : "exito", texto: r.resultado === "EXTEMPORANEA"
          ? "Respuesta registrada. Fue notificada después del plazo: el permiso se entiende concedido por silencio." : "Respuesta registrada." });
        await cargar(); onCambio?.();
      }} />}
    </section>
  );
}

function RespuestaPermiso({ p, onCerrar, onListo }) {
  const [f, setF] = useState({ acto: "", fecha_acto: "", fecha_notificacion: "", observacion: "" });
  const [dec, setDec] = useState(Object.fromEntries(p.beneficiarios.map((b) => [b.id_persona, { decision: "CONCEDIDO", dias_concedidos: "", causal: "PRESTACION_SERVICIO", motivo: "" }])));
  const [error, setError] = useState("");
  const cambiarDec = (id, k) => (e) => setDec((d) => ({ ...d, [id]: { ...d[id], [k]: e.target.value } }));
  const enviar = async (e) => {
    e.preventDefault();
    try {
      const r = await api.post(`/api/permisos/${p.id_permiso}/respuesta`, { ...f,
        decisiones: p.beneficiarios.map((b) => ({ id_persona: b.id_persona, ...dec[b.id_persona] })) });
      onListo(r);
    } catch (e2) { setError(e2.message); }
  };
  return (
    <Modal titulo={`Respuesta de la entidad · ${p.consecutivo}`} onCerrar={onCerrar} ancho={900}
           pie={<><button className="btn btn-primario" form="form-resp">Registrar</button><button className="btn" onClick={onCerrar}>Cancelar</button></>}>
      <p className="tenue pequeno">Copie lo que dice el acto administrativo. La única causal legal para negar o limitar un permiso es la afectación de la debida
        prestación del servicio. Si la notificación llegó después del {formatear(p.limite_respuesta, "date")}, el permiso se entiende concedido.</p>
      <form id="form-resp" onSubmit={enviar}>
        <div className="rejilla-campos">
          <div className="campo"><label htmlFor="r-acto">Número del acto administrativo</label><input id="r-acto" value={f.acto} onChange={(e) => setF({ ...f, acto: e.target.value })} required /></div>
          <div className="campo"><label htmlFor="r-fa">Fecha del acto</label><input id="r-fa" type="date" value={f.fecha_acto} onChange={(e) => setF({ ...f, fecha_acto: e.target.value })} /></div>
          <div className="campo"><label htmlFor="r-fn">Fecha de notificación al sindicato</label><input id="r-fn" type="date" value={f.fecha_notificacion} onChange={(e) => setF({ ...f, fecha_notificacion: e.target.value })} required /></div>
        </div>
        <table className="tabla">
          <thead><tr><th>Afiliado</th><th>Decisión</th><th>Días concedidos</th><th>Causal invocada</th><th>Motivo de la entidad</th></tr></thead>
          <tbody>{p.beneficiarios.map((b) => { const d = dec[b.id_persona]; return (
            <tr key={b.id_persona}>
              <td>{b.afiliado} <span className="tenue">({b.dias_solicitados} días)</span></td>
              <td><select aria-label={`Decisión para ${b.afiliado}`} value={d.decision} onChange={cambiarDec(b.id_persona, "decision")}>
                <option value="CONCEDIDO">Concedido</option><option value="LIMITADO">Limitado</option><option value="NEGADO">Negado</option></select></td>
              <td>{d.decision === "LIMITADO" ? <input aria-label="Días concedidos" type="number" min="1" max={b.dias_solicitados - 1} value={d.dias_concedidos}
                                                    onChange={cambiarDec(b.id_persona, "dias_concedidos")} required /> : "—"}</td>
              <td>{d.decision !== "CONCEDIDO" ? <select aria-label="Causal" value={d.causal} onChange={cambiarDec(b.id_persona, "causal")}>
                <option value="PRESTACION_SERVICIO">Afectación del servicio</option><option value="OTRA">Otra</option></select> : "—"}</td>
              <td>{d.decision !== "CONCEDIDO" ? <input aria-label="Motivo" value={d.motivo} onChange={cambiarDec(b.id_persona, "motivo")} required /> : "—"}</td>
            </tr>); })}</tbody>
        </table>
        <div className="campo campo-ancho"><label htmlFor="r-obs">Observación (opcional)</label><textarea id="r-obs" rows={2} value={f.observacion} onChange={(e) => setF({ ...f, observacion: e.target.value })} /></div>
      </form>
      <Aviso tipo="error" onCerrar={() => setError("")}>{error}</Aviso>
    </Modal>
  );
}

// ------------------------------------------------------------------ designar directivo
export function DesignarDirectivo({ onCerrar, onCreado }) {
  const [f, setF] = useState({ id_estamento: null, id_cargo: null, id_persona: null, tipo_nombramiento: "ELECCION", acta: "", observacion: "" });
  const [ocupa, setOcupa] = useState(null);
  const [reemplaza, setReemplaza] = useState(false);
  const [error, setError] = useState("");
  const [hecho, setHecho] = useState(null);
  useEffect(() => {
    setOcupa(null); setReemplaza(false);
    if (f.id_estamento && f.id_cargo) api.get("/api/directivos/ocupante", { id_estamento: f.id_estamento, id_cargo: f.id_cargo }).then(setOcupa).catch(() => setOcupa(null));
  }, [f.id_estamento, f.id_cargo]);
  const enviar = async (e) => {
    e.preventDefault();
    try {
      const r = await api.post("/api/directivos/designaciones", { ...f, id_directivo_saliente: reemplaza && ocupa ? ocupa.id_directivo_estamento : null });
      setHecho(r); onCreado?.(r);
    } catch (e2) { setError(e2.message); }
  };
  if (hecho) {
    return (
      <Modal titulo="Designación registrada" onCerrar={onCerrar} pie={<button className="btn" onClick={onCerrar}>Cerrar</button>}>
        <p><b>{hecho.designado}</b> — {hecho.cargo}, {hecho.junta}.</p>
        <Aviso tipo={hecho.estado === "POSESIONADA" ? "exito" : "info"}>{hecho.estado === "POSESIONADA"
          ? `El registro vigente del inspector ya la incluye: queda posesionado desde el ${formatear(hecho.fecha_posesion, "date")}.`
          : "Queda pendiente del registro del inspector. Cuando lo registre en «Registros ante MinTrabajo», ARCADIO le dará la posesión con la fecha del registro. Mientras tanto no ejerce el cargo."}</Aviso>
      </Modal>
    );
  }
  return (
    <Modal titulo="Designar directivo" onCerrar={onCerrar}
           pie={<><button className="btn btn-primario" form="form-design">Registrar la designación</button><button className="btn" onClick={onCerrar}>Cancelar</button></>}>
      <p className="tenue pequeno">La junta designa con su acta. La fecha de posesión será la del registro del inspector que incluya a la persona;
        hasta entonces no ejerce el cargo (no firma, no aprueba, no pide permisos). Quien sale del cargo se retira ese mismo día.</p>
      <form id="form-design" className="rejilla-campos" onSubmit={enviar}>
        <div className="campo"><label>Junta</label><SelectorFK recurso="estamentos" valor={f.id_estamento} onCambio={(v) => setF({ ...f, id_estamento: v })} requerido /></div>
        <div className="campo"><label>Cargo</label><SelectorFK recurso="cargos" valor={f.id_cargo} onCambio={(v) => setF({ ...f, id_cargo: v })} requerido /></div>
        <div className="campo"><label>Afiliado designado</label><SelectorFK recurso="afiliados" valor={f.id_persona} onCambio={(v) => setF({ ...f, id_persona: v })} requerido /></div>
        <div className="campo"><label htmlFor="d-tipo">Tipo</label>
          <select id="d-tipo" value={f.tipo_nombramiento} onChange={(e) => setF({ ...f, tipo_nombramiento: e.target.value })}>
            <option value="ELECCION">Elección</option><option value="REELECCION">Reelección (mismo cargo)</option><option value="ROTACION">Rotación (desde otro cargo de la junta)</option></select></div>
        <div className="campo"><label htmlFor="d-acta">Radicado del acta de la junta</label><input id="d-acta" value={f.acta} onChange={(e) => setF({ ...f, acta: e.target.value })} required /></div>
        <div className="campo">{ocupa ? (
          <label className="interruptor"><input type="checkbox" checked={reemplaza} onChange={(e) => setReemplaza(e.target.checked)} />
            <span>Reemplaza a {ocupa.nombre}, que ocupa hoy el cargo</span></label>) : f.id_cargo && f.id_estamento ? <span className="tenue pequeno">El cargo está vacante.</span> : null}</div>
        <div className="campo campo-ancho"><label htmlFor="d-obs">Observación (opcional)</label><textarea id="d-obs" rows={2} value={f.observacion} onChange={(e) => setF({ ...f, observacion: e.target.value })} /></div>
      </form>
      <Aviso tipo="error" onCerrar={() => setError("")}>{error}</Aviso>
    </Modal>
  );
}
