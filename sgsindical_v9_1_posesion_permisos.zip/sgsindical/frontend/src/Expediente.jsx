// Expediente documental de afiliación (db/16): lista de documentos, carga, revisión y decisión.
// Lo usan la junta y Ventanilla (desde la solicitud o la ficha del afiliado) y la propia persona en su portal.
import { useEffect, useState } from "react";
import { api } from "./api.js";
import { Aviso, Cargando, formatear, SelectorFK } from "./ui.jsx";

const ESTADO_DOC = {
  POR_REVISAR: ["Por revisar", "insignia-media"],
  ACEPTADO: ["Aceptado", "insignia-normal"],
  RECHAZADO: ["Rechazado", "insignia-alta"],
};
const ESTADO_EXP = {
  INCOMPLETA: ["Documentos incompletos", "insignia-alta"],
  EN_REVISION: ["Documentos por revisar", "insignia-media"],
  COMPLETA: ["Documentos completos", "insignia-normal"],
};
const ACEPTA = "application/pdf,image/jpeg,image/png,.pdf,.jpg,.jpeg,.png";

const bajar = (blob, nombre) => { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = nombre; a.click(); };

// Lista de documentos con sus acciones. `propio` = la persona en su portal (rutas de autoservicio).
export function DocumentosExpediente({ exp, propio = false, avisar, recargar, soloOpcionales = false }) {
  const [cargando, setCargando] = useState("");
  const intentar = (fn) => async (...a) => { try { await fn(...a); } catch (e) { avisar("error", e.message); } finally { setCargando(""); } };
  const subir = (codigo) => intentar(async (e) => {
    const archivos = e.target.files; if (!archivos?.length) return;
    setCargando(codigo);
    const ruta = propio ? `/api/autoservicio/afiliacion/documentos/${codigo}` : `/api/afiliacion/expedientes/${exp.id_persona}/documentos/${codigo}`;
    const r = await api.subirVarios(ruta, archivos);
    e.target.value = "";
    avisar("exito", `Documento guardado (${r.paginas} página${r.paginas === 1 ? "" : "s"}). ${propio ? "La junta lo revisará." : ""}`);
    await recargar();
  });
  const ver = (d) => intentar(async () => {
    let ruta = propio ? `/api/autoservicio/afiliacion/documentos/${d.id_documento}/archivo` : `/api/afiliacion/documentos/${d.id_documento}/archivo`;
    if (!propio && exp.permiso === "ADMIN") {
      const m = window.prompt("Como administrador, escriba el motivo para abrir este documento (queda en la bitácora de accesos):");
      if (!m) return;
      ruta += `?motivo=${encodeURIComponent(m)}`;
    }
    bajar(await api.descargar(ruta), d.nombre_archivo || `${d.codigo.toLowerCase()}.pdf`);
  });
  const revisar = (d, aceptar) => intentar(async () => {
    let motivo = null;
    if (!aceptar) { motivo = window.prompt("Motivo del rechazo (la persona lo verá para corregirlo):"); if (!motivo) return; }
    await api.post(`/api/afiliacion/documentos/${d.id_documento}/revisar`, { aceptar, motivo });
    avisar("exito", aceptar ? "Documento aceptado." : "Documento rechazado: la persona verá el motivo.");
    await recargar();
  });
  const plantilla = (d) => intentar(async () => bajar(await api.descargar(`/api/afiliacion/tipos/${d.codigo}/plantilla`), `${d.codigo.toLowerCase()}_plantilla`));

  const docs = exp.documentos.filter((d) => !soloOpcionales || !d.obligatorio);
  return (
    <ul className="lista-documentos">
      {docs.map((d) => {
        const [txt, cls] = ESTADO_DOC[d.estado] || [d.obligatorio ? "Falta" : "Sin cargar", d.obligatorio ? "insignia-alta" : "insignia-normal"];
        const puedeCargar = exp.puede_cargar && !(propio && d.estado === "ACEPTADO" && d.obligatorio && exp.afiliado_activo);
        return (
          <li key={d.codigo} className="doc-item">
            <div className="doc-cab">
              <strong>{d.nombre}</strong>
              <span className="tenue pequeno">{d.obligatorio ? "Obligatorio" : "Opcional"}</span>
              <span className={`insignia ${cls}`}>{txt}</span>
            </div>
            {d.descripcion && !d.estado && <p className="tenue pequeno">{d.descripcion}</p>}
            {d.estado && (
              <p className="tenue pequeno">
                {d.nombre_archivo && <>{d.nombre_archivo} · </>}{d.paginas ? `${d.paginas} pág. · ` : ""}cargado el {formatear(d.fecha_carga, "datetime")}
                {d.cargado_por && <> por {d.cargado_por}</>}{d.revisado_por && <> · revisado por {d.revisado_por}</>}
                {d.anteriores > 0 && <> · {d.anteriores} versión(es) anterior(es) en el historial</>}
              </p>
            )}
            {d.estado === "RECHAZADO" && d.motivo_rechazo && <p className="doc-rechazo">Motivo del rechazo: {d.motivo_rechazo}</p>}
            <div className="acciones">
              {d.puede_abrir && <button className="btn btn-sm" onClick={ver(d)}>Ver</button>}
              {!propio && exp.puede_revisar && d.estado === "POR_REVISAR" && <>
                <button className="btn btn-sm btn-primario" onClick={revisar(d, true)}>Aceptar</button>
                <button className="btn btn-sm" onClick={revisar(d, false)}>Rechazar…</button>
              </>}
              {d.tiene_plantilla && <button className="btn btn-sm" onClick={plantilla(d)}>Descargar formato</button>}
              {puedeCargar && (
                <label className={`btn btn-sm ${!d.estado || d.estado === "RECHAZADO" ? "btn-primario" : ""}`}>
                  {cargando === d.codigo ? "Subiendo…" : d.estado ? "Reemplazar…" : "Subir (PDF o fotos)…"}
                  <input type="file" accept={ACEPTA} multiple hidden disabled={!!cargando} onChange={subir(d.codigo)} />
                </label>
              )}
            </div>
          </li>
        );
      })}
    </ul>
  );
}

export function EncabezadoExpediente({ exp }) {
  const [txt, cls] = ESTADO_EXP[exp.estado_documental] || ["", ""];
  const s = exp.solicitud;
  return (
    <div className="exp-cab">
      <span className={`insignia ${cls}`}>{txt}</span>
      {exp.disperso && <span className="insignia insignia-baja">{exp.grupo_nacional === "PALMIRA" ? "Palmira (sede nacional) · Junta Directiva Nacional" : "Disperso · Junta Directiva Nacional"}</span>}
      {exp.junta && !exp.disperso && <span className="tenue pequeno">{exp.junta}</span>}
      {s && s.estado === "PENDIENTE" && (
        <span className="tenue pequeno">
          Solicitud {s.radicado} · plazo para completar hasta el {formatear(s.fecha_vence, "date")}
          {s.dias_para_vencer >= 0 ? ` (${s.dias_para_vencer} días)` : " (vencido)"}
        </span>
      )}
    </div>
  );
}

// Panel para la junta, Ventanilla o el administrador
export function ExpedientePanel({ idPersona, onDecidido }) {
  const [exp, setExp] = useState(null);
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const avisar = (tipo, texto) => setMsg({ tipo, texto });
  const cargar = () => api.get(`/api/afiliacion/expedientes/${idPersona}`).then(setExp).catch((e) => avisar("error", e.message));
  useEffect(() => { cargar(); }, [idPersona]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!exp) return <>{msg.texto ? <Aviso tipo={msg.tipo}>{msg.texto}</Aviso> : <Cargando />}</>;
  const s = exp.solicitud;
  // La fecha de afiliación es la de la aprobación; «otraFecha» permite una anterior (desde la radicación) con motivo
  const decidir = (aprobar, otraFecha = false) => async () => {
    try {
      const datos = {};
      if (aprobar) {
        if (s.requiere_acta) {
          const a = window.prompt("Radicado del acta de la reunión de la Junta Directiva Nacional que aprobó la afiliación del disperso:");
          if (!a) return;
          datos.acta = a.trim();
        }
        if (otraFecha) {
          const f = window.prompt(`Fecha de afiliación (AAAA-MM-DD). No puede ser anterior a la radicación (${formatear(s.fecha, "date")}) ni futura:`);
          if (!f) return;
          const m = window.prompt("Motivo para registrar una fecha anterior a la de hoy (queda en la auditoría):");
          if (!m) return;
          datos.fecha_afiliacion = f.trim(); datos.motivo_fecha = m;
        } else if (!window.confirm("La persona quedará afiliada con fecha de hoy. Se crearán el afiliado, su empresa y su salario. ¿Aprobar?")) return;
      } else {
        const o = window.prompt("Motivo del rechazo:"); if (!o) return;
        datos.observacion = o;
        if (s.requiere_acta) { const a = window.prompt("Radicado del acta (opcional):"); if (a) datos.acta = a.trim(); }
      }
      await api.post(`/api/afiliaciones/${s.id_solicitud_afiliacion}/${aprobar ? "aprobar" : "rechazar"}`, datos);
      avisar("exito", aprobar ? "Afiliación aprobada." : "Solicitud rechazada.");
      await cargar(); onDecidido?.();
    } catch (e) { avisar("error", e.message); }
  };
  return (
    <section className="expediente">
      <h3>Expediente de afiliación</h3>
      <EncabezadoExpediente exp={exp} />
      {exp.permiso === "ESTADO" && <p className="tenue pequeno">Usted ve el estado de los documentos; los archivos solo los consultan el Presidente, el Secretario General, el Vicepresidente, el Tesorero y el Fiscal de la junta.</p>}
      {exp.permiso === "VENTANILLA" && <p className="tenue pequeno">Ventanilla carga documentos a nombre de la persona y ve solo los que ella misma cargó. Los revisa la junta.</p>}
      <Aviso tipo={msg.tipo} onCerrar={() => avisar("info", "")}>{msg.texto}</Aviso>
      <DocumentosExpediente exp={exp} avisar={avisar} recargar={cargar} />
      {s && s.estado === "PENDIENTE" && s.puede_decidir && (
        <div className="acciones exp-decision">
          <button className="btn btn-primario" disabled={exp.estado_documental !== "COMPLETA"} onClick={decidir(true)}
                  title={exp.estado_documental !== "COMPLETA" ? "Se aprueba cuando el documento de identidad y el formato firmado estén aceptados" : ""}>
            Aprobar afiliación{s.requiere_acta ? " (con acta)" : ""}
          </button>
          <button className="btn" disabled={exp.estado_documental !== "COMPLETA"} onClick={decidir(true, true)}>Aprobar con fecha anterior…</button>
          <button className="btn" onClick={decidir(false)}>Rechazar solicitud</button>
        </div>
      )}
      {s && s.estado === "PENDIENTE" && s.requiere_acta && !s.puede_decidir && exp.permiso === "GESTIONA" && (
        <p className="tenue pequeno">La afiliación de un disperso la decide la Junta Directiva Nacional en reunión; la registran su Presidente o su Secretario General con el acta.</p>
      )}
    </section>
  );
}

// Pasar a disperso o volver a una subdirectiva o comité (Junta Nacional, con acta)
export function CambiarPertenencia({ idPersona, onCambio }) {
  const [abierto, setAbierto] = useState(false);
  const [destino, setDestino] = useState(null);
  const [acta, setActa] = useState("");
  const [motivo, setMotivo] = useState("");
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  if (!abierto) return <button className="btn" onClick={() => setAbierto(true)}>Junta Nacional (disperso o Palmira)…</button>;
  const enviar = async (e) => {
    e.preventDefault();
    try {
      const r = await api.post(`/api/afiliacion/pertenencia/${idPersona}`, { id_estamento: destino, acta: acta.trim(), motivo });
      setMsg({ tipo: "exito", texto: r.resultado === "DISPERSO" ? "Quedó como afiliado disperso de la Junta Directiva Nacional." : `Ahora pertenece a ${r.resultado}.` });
      onCambio?.();
    } catch (e2) { setMsg({ tipo: "error", texto: e2.message }); }
  };
  return (
    <form className="tarjeta" onSubmit={enviar}>
      <h4>Pertenecer a la Junta Nacional o dejar de hacerlo (decisión de la Junta Nacional)</h4>
      <p className="tenue pequeno">Para que pertenezca a la Junta Directiva Nacional (dispersos, y quienes trabajan en Palmira, sede nacional), elija la Junta Directiva Nacional. Para que vuelva a una subdirectiva o comité, elíjala. Lo registran el Presidente o el Secretario General Nacional, con el acta. ARCADIO lo ubica solo en el grupo Palmira o Dispersos según el municipio donde trabaja.</p>
      <div className="campo"><label>Nueva pertenencia</label><SelectorFK recurso="estamentos" valor={destino} onCambio={setDestino} requerido /></div>
      <div className="campo"><label htmlFor="acta-p">Radicado del acta de la Junta Nacional</label><input id="acta-p" value={acta} onChange={(e) => setActa(e.target.value)} required /></div>
      <div className="campo"><label htmlFor="mot-p">Motivo</label><textarea id="mot-p" value={motivo} onChange={(e) => setMotivo(e.target.value)} required minLength={10} /></div>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      <div className="acciones"><button className="btn btn-primario">Registrar</button><button type="button" className="btn" onClick={() => setAbierto(false)}>Cerrar</button></div>
    </form>
  );
}

// Portal: «Mi afiliación» (solicitante) y «Mis documentos» (afiliado)
export function MiAfiliacion({ avisar }) {
  const [exp, setExp] = useState(null);
  const [error, setError] = useState("");
  const cargar = () => api.get("/api/autoservicio/afiliacion").then(setExp).catch((e) => setError(e.message));
  useEffect(() => { cargar(); }, []);
  if (error) return <Aviso tipo="error">{error}</Aviso>;
  if (!exp) return <Cargando />;
  const s = exp.solicitud;
  return (
    <section className="tarjeta">
      {(!exp.afiliado_activo || exp.estado_documental !== "COMPLETA") && <>
        <EncabezadoExpediente exp={exp} />
        {s?.estado === "PENDIENTE" && exp.estado_documental === "INCOMPLETA" && (
          <p className="pequeno">Suba su documento de identidad (por ambas caras) y el formato de afiliación firmado. Puede usar PDF o tomar fotos con el celular; si son varias, súbalas juntas y quedan en un solo documento. Puede volver cuando quiera: lo que suba queda guardado.</p>
        )}
        {s?.estado === "PENDIENTE" && exp.estado_documental === "EN_REVISION" && <p className="pequeno">Su junta está revisando sus documentos. Le avisaremos si debe corregir alguno.</p>}
        {s?.estado === "PENDIENTE" && exp.estado_documental === "COMPLETA" && <p className="pequeno">Sus documentos están completos. Su junta decidirá su afiliación.</p>}
        {s && s.estado !== "PENDIENTE" && !exp.afiliado_activo && <p className="pequeno">Su solicitud {s.radicado} quedó {s.estado.toLowerCase()}. {s.observacion_decision || ""}</p>}
      </>}
      {exp.afiliado_activo && <p className="tenue pequeno">Aquí puede agregar documentos opcionales (acta de posesión, certificado de carrera) o completar los que falten.</p>}
      <DocumentosExpediente exp={exp} propio avisar={avisar} recargar={cargar} />
    </section>
  );
}

// Traslado entre subdirectivas o comités: una junta lo propone con su acta y la otra lo responde con la suya
export function Trasladar({ idPersona, onCambio }) {
  const [abierto, setAbierto] = useState(false);
  const [destino, setDestino] = useState(null);
  const [acta, setActa] = useState("");
  const [motivo, setMotivo] = useState("");
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  if (!abierto) return <button className="btn" onClick={() => setAbierto(true)}>Trasladar a otra subdirectiva o comité…</button>;
  const enviar = async (e) => {
    e.preventDefault();
    try {
      const t = await api.post("/api/afiliacion/traslados", { id_persona: idPersona, id_estamento: destino, acta: acta.trim(), motivo });
      setMsg({ tipo: "exito", texto: `Traslado propuesto${t.excepcion === "SÍ" ? " como EXCEPCIÓN a la regla de municipio" : ""}. ${t.diagnostico.replace(/^ALERTA [A-ZÁÉÍÓÚ]+: /, "").toLowerCase().replace(/^./, (c) => c.toUpperCase())} (Gobernanza → Traslados entre juntas).` });
      onCambio?.();
    } catch (e2) { setMsg({ tipo: "error", texto: e2.message }); }
  };
  return (
    <form className="tarjeta" onSubmit={enviar}>
      <h4>Trasladar a otra subdirectiva o comité</h4>
      <p className="tenue pequeno">Lo deciden las dos juntas, cada una con su acta. Usted lo propone con el acta de su junta; la otra junta lo acepta o lo rechaza con la suya en «Traslados entre juntas». Si el destino no corresponde al municipio donde trabaja ni al de la sede principal de su empresa, queda como excepción, marcada en la vista de pertenencia.</p>
      <div className="campo"><label>Junta de destino</label><SelectorFK recurso="estamentos" valor={destino} onCambio={setDestino} requerido /></div>
      <div className="campo"><label htmlFor="acta-t">Radicado del acta de su junta</label><input id="acta-t" value={acta} onChange={(e) => setActa(e.target.value)} required /></div>
      <div className="campo"><label htmlFor="mot-t">Motivo</label><textarea id="mot-t" value={motivo} onChange={(e) => setMotivo(e.target.value)} required minLength={10} /></div>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      <div className="acciones"><button className="btn btn-primario">Proponer traslado</button><button type="button" className="btn" onClick={() => setAbierto(false)}>Cerrar</button></div>
    </form>
  );
}
