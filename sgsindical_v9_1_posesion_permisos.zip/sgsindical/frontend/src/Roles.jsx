// Bloque 5: varios roles por usuario (contexto activo), aprobación de roles y suplencias de cargos.
import { useCallback, useEffect, useState } from "react";
import { api, setToken } from "./api.js";
import { Aviso, Cargando, formatear, Modal, SelectorFK } from "./ui.jsx";

export const describirAmbito = (c) =>
  c.ambito_nacional ? "Nacional (todo el país)" : c.juntas?.length ? c.juntas.join(", ") : c.incluye_cargos ? "Según sus cargos" : "Sin ámbito";

// ------------------------------------------------------------------ elegir contexto
function TarjetasContexto({ contextos, onElegir, enviando }) {
  return (
    <div className="contextos">
      {contextos.map((c) => (
        <button key={c.id_usuario_rol} className={`contexto${c.activo ? " contexto-activo" : ""}`} disabled={enviando} onClick={() => onElegir(c)}>
          <strong>{c.nombre_rol}</strong>
          <span>{describirAmbito(c)}</span>
          {c.origen === "SUPLENCIA" && <span className="insignia insignia-media">Suplencia hasta {formatear(c.hasta, "date")}</span>}
          {c.origen !== "SUPLENCIA" && c.hasta && <span className="tenue pequeno">Hasta {formatear(c.hasta, "date")}</span>}
          {c.activo && <span className="insignia insignia-normal">Actual</span>}
        </button>
      ))}
    </div>
  );
}

export function ElegirContexto({ usuario, onListo }) {
  const [error, setError] = useState("");
  const [enviando, setEnviando] = useState(false);
  const elegir = async (c) => {
    setEnviando(true); setError("");
    try { await api.post("/api/auth/contexto", { id_usuario_rol: c.id_usuario_rol }); onListo(); }
    catch (e) { setError(e.message); setEnviando(false); }
  };
  const salir = async () => { await api.post("/api/auth/logout").catch(() => {}); setToken(null); window.location.reload(); };
  return (
    <div className="login-fondo">
      <div className="login" style={{ maxWidth: 560 }}>
        <div className="marca"><span className="logo">SG</span><div><strong>¿Con qué rol va a trabajar?</strong><small>{usuario.nombre_completo}</small></div></div>
        <p className="pequeno">Tiene varios roles. Trabaja con uno a la vez y puede cambiarlo desde el encabezado; los permisos no se suman.</p>
        <Aviso tipo="error">{error}</Aviso>
        <TarjetasContexto contextos={usuario.contextos} onElegir={elegir} enviando={enviando} />
        <button type="button" className="btn btn-sm" onClick={salir}>Salir</button>
      </div>
    </div>
  );
}

export function CambiarContexto({ usuario, onCerrar }) {
  const [error, setError] = useState("");
  const elegir = async (c) => {
    if (c.activo) return onCerrar();
    try { await api.post("/api/auth/contexto", { id_usuario_rol: c.id_usuario_rol }); window.location.hash = "/"; window.location.reload(); }
    catch (e) { setError(e.message); }
  };
  return (
    <Modal titulo="Cambiar de rol" onCerrar={onCerrar} ancho={560}>
      <Aviso tipo="error">{error}</Aviso>
      <TarjetasContexto contextos={usuario.contextos} onElegir={elegir} />
    </Modal>
  );
}

// ------------------------------------------------------------------ roles de un usuario (ficha, administrador)
const ROLES = [["DIRECTIVO", "Directivo sindical"], ["TESORERO", "Tesorería"], ["AUDITOR", "Auditor / Fiscal"], ["ABOGADO", "Abogado"],
  ["VENTANILLA", "Ventanilla"], ["CONSULTA", "Consulta"], ["ADMIN", "Administrador"]];
const ESTADO_ROL = { VIGENTE: "normal", PENDIENTE: "media", RECHAZADO: "baja", REVOCADO: "baja" };

export function RolesUsuario({ idUsuario }) {
  const [d, setD] = useState(null);
  const [nuevo, setNuevo] = useState(null);
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const cargar = useCallback(() => api.get(`/api/roles/usuarios/${idUsuario}`).then(setD).catch((e) => setMsg({ tipo: "error", texto: e.message })), [idUsuario]);
  useEffect(() => { cargar(); }, [cargar]);
  if (!d) return msg.texto ? <Aviso tipo={msg.tipo}>{msg.texto}</Aviso> : null;
  const revocar = async (r) => {
    const m = window.prompt(`Motivo para retirar el rol ${r.nombre_rol}:`); if (!m) return;
    try { await api.post(`/api/roles/${r.id_usuario_rol}/revocar`, { motivo: m }); setMsg({ tipo: "exito", texto: "Rol retirado." }); cargar(); }
    catch (e) { setMsg({ tipo: "error", texto: e.message }); }
  };
  const asignar = async (e) => {
    e.preventDefault();
    try {
      const r = await api.post(`/api/roles/usuarios/${idUsuario}`, { ...nuevo, juntas: nuevo.juntas.filter(Boolean) });
      setMsg({ tipo: r.estado === "PENDIENTE" ? "advertencia" : "exito", texto: r.aviso }); setNuevo(null); cargar();
    } catch (x) { setMsg({ tipo: "error", texto: x.message }); }
  };
  return (
    <section className="acciones-extra">
      <h3>Roles del usuario</h3>
      <p className="tenue pequeno">Trabaja con un rol a la vez. El de Administrador y los de ámbito nacional los aprueba la Presidencia Nacional.</p>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      {d.incompatibilidad && <Aviso tipo="error">{d.incompatibilidad}</Aviso>}
      <ul className="lista-meses">
        {d.roles.map((r) => (
          <li key={r.id_usuario_rol}>
            <strong>{r.nombre_rol}</strong>
            <span>{describirAmbito(r)} · desde {formatear(r.desde, "date")}{r.hasta ? ` hasta ${formatear(r.hasta, "date")}` : ""}{r.origen === "SUPLENCIA" ? " · por suplencia" : ""}{r.activo ? " · en uso" : ""}</span>
            {r.estado === "VIGENTE" && !r.vigente_hoy
              ? <span className="insignia insignia-normal">{r.desde > new Date().toISOString().slice(0, 10) ? "programado" : "terminado"}</span>
              : <span className={`insignia insignia-${ESTADO_ROL[r.estado]}`}>{r.estado.toLowerCase()}</span>}
            {["VIGENTE", "PENDIENTE"].includes(r.estado) && r.origen !== "SUPLENCIA" && <button className="btn btn-sm" onClick={() => revocar(r)}>Retirar</button>}
          </li>
        ))}
      </ul>
      {!nuevo ? <button className="btn" onClick={() => setNuevo({ codigo_rol: "CONSULTA", ambito_nacional: false, juntas: [null], incluye_cargos: false, desde: "", hasta: "", motivo: "" })}>Asignar otro rol</button> : (
        <form className="rejilla-campos" onSubmit={asignar}>
          <div className="campo"><label htmlFor="nr-rol">Rol</label>
            <select id="nr-rol" value={nuevo.codigo_rol} onChange={(e) => setNuevo({ ...nuevo, codigo_rol: e.target.value, incluye_cargos: ["DIRECTIVO", "TESORERO", "AUDITOR"].includes(e.target.value) })}>
              {ROLES.map(([k, t]) => <option key={k} value={k}>{t}</option>)}</select></div>
          <div className="campo"><label className="interruptor"><input type="checkbox" checked={nuevo.ambito_nacional} onChange={(e) => setNuevo({ ...nuevo, ambito_nacional: e.target.checked })} /><span>Ámbito nacional (requiere aprobación)</span></label>
            <label className="interruptor"><input type="checkbox" checked={nuevo.incluye_cargos} onChange={(e) => setNuevo({ ...nuevo, incluye_cargos: e.target.checked })} /><span>Incluye sus cargos directivos</span></label></div>
          {!nuevo.ambito_nacional && <div className="campo campo-ancho"><label>Juntas</label>
            {nuevo.juntas.map((j, i) => <SelectorFK key={i} recurso="estamentos" valor={j} onCambio={(v) => { const js = [...nuevo.juntas]; js[i] = v; setNuevo({ ...nuevo, juntas: js }); }} />)}
            <button type="button" className="btn btn-sm" onClick={() => setNuevo({ ...nuevo, juntas: [...nuevo.juntas, null] })}>Otra junta</button></div>}
          <div className="campo"><label htmlFor="nr-d">Desde</label><input id="nr-d" type="date" value={nuevo.desde} onChange={(e) => setNuevo({ ...nuevo, desde: e.target.value })} /></div>
          <div className="campo"><label htmlFor="nr-h">Hasta (opcional)</label><input id="nr-h" type="date" value={nuevo.hasta} onChange={(e) => setNuevo({ ...nuevo, hasta: e.target.value })} /></div>
          <div className="campo campo-ancho"><label htmlFor="nr-m">Motivo</label><input id="nr-m" value={nuevo.motivo} onChange={(e) => setNuevo({ ...nuevo, motivo: e.target.value })} required /></div>
          <div className="acciones"><button className="btn btn-primario">Asignar</button><button type="button" className="btn" onClick={() => setNuevo(null)}>Cancelar</button></div>
        </form>
      )}
    </section>
  );
}

// ------------------------------------------------------------------ aprobación (Presidencia Nacional)
export function RolesPendientesPagina() {
  const [filas, setFilas] = useState(null);
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const cargar = () => api.get("/api/roles/pendientes").then(setFilas).catch((e) => setMsg({ tipo: "error", texto: e.message }));
  useEffect(() => { cargar(); }, []);
  const decidir = (r, d) => async () => {
    const obs = d === "rechazar" ? window.prompt("Motivo del rechazo:") : null; if (d === "rechazar" && !obs) return;
    try { const x = await api.post(`/api/roles/${r.id_usuario_rol}/${d}`, { observacion: obs }); setMsg({ tipo: "exito", texto: `Rol ${x.estado.toLowerCase()}.` }); cargar(); }
    catch (e) { setMsg({ tipo: "error", texto: e.message }); }
  };
  return (
    <section className="pagina">
      <header className="pagina-cab"><div><h1>Roles por aprobar</h1>
        <p className="tenue">El rol de Administrador y los roles con ámbito nacional los solicita el administrador y los aprueba la Presidencia Nacional. Nadie aprueba lo propio.</p></div></header>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      {!filas ? <Cargando /> : (
        <div className="tabla-marco"><table className="tabla">
          <thead><tr><th>Usuario</th><th>Rol</th><th>Ámbito</th><th>Motivo</th><th>Pidió</th><th></th></tr></thead>
          <tbody>
            {filas.map((r) => (
              <tr key={r.id_usuario_rol}><td><strong>{r.nombre_usuario}</strong><div className="tenue pequeno">{r.nombre_completo}</div></td>
                <td>{r.nombre_rol}</td><td>{describirAmbito(r)}</td><td>{r.motivo}</td><td>{r.solicitado_por}<div className="tenue pequeno">{formatear(r.fecha_solicitud, "datetime")}</div></td>
                <td className="sin-corte"><button className="btn btn-sm btn-primario" onClick={decidir(r, "aprobar")}>Aprobar</button> <button className="btn btn-sm" onClick={decidir(r, "rechazar")}>Rechazar</button></td></tr>
            ))}
            {filas.length === 0 && <tr><td colSpan={6} className="vacio">No hay roles pendientes.</td></tr>}
          </tbody></table></div>
      )}
    </section>
  );
}

// ------------------------------------------------------------------ suplencias
const hoyISO = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const masDias = (iso, n) => { const d = new Date(iso + "T12:00:00"); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };

export function SuplenciasPagina({ usuario }) {
  const [filas, setFilas] = useState(null);
  const [todas, setTodas] = useState(false);
  const [nueva, setNueva] = useState(false);
  const [renovar, setRenovar] = useState(null);
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const cargar = useCallback(() => api.get("/api/suplencias", { todas: todas || undefined }).then(setFilas).catch((e) => setMsg({ tipo: "error", texto: e.message })), [todas]);
  useEffect(() => { cargar(); }, [cargar]);
  const revocar = (s) => async () => {
    const m = window.prompt("Motivo (p. ej. el titular regresó antes):"); if (!m) return;
    try { await api.post(`/api/suplencias/${s.id_suplencia}/revocar`, { motivo: m }); setMsg({ tipo: "exito", texto: "Suplencia revocada: el titular recupera el cargo." }); cargar(); }
    catch (e) { setMsg({ tipo: "error", texto: e.message }); }
  };
  const nivel = (d) => d.startsWith("ALERTA ALTA") ? "alta" : d.startsWith("ALERTA MEDIA") ? "media" : d === "VIGENTE" ? "normal" : "baja";
  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div><h1>Suplencias de cargos</h1>
          <p className="tenue">Encargo temporal de un cargo directivo, decidido por la junta con acta. Máximo 90 días, renovable. Mientras dura,
            el titular queda suspendido y solo actúa el suplente; al vencer, termina sola.</p></div>
        <div className="acciones">{usuario.gestiona_suplencias && <button className="btn btn-primario" onClick={() => setNueva(true)}>Registrar suplencia</button>}</div>
      </header>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      <label className="interruptor"><input type="checkbox" checked={todas} onChange={(e) => setTodas(e.target.checked)} /><span>Incluir terminadas y revocadas</span></label>
      {!filas ? <Cargando /> : (
        <div className="tabla-marco"><table className="tabla">
          <thead><tr><th>Junta</th><th>Cargo</th><th>Titular (suspendido)</th><th>Suplente</th><th>Desde</th><th>Hasta</th><th>Días</th><th>Acta</th><th>Situación</th><th></th></tr></thead>
          <tbody>
            {filas.map((s) => (
              <tr key={s.id_suplencia}><td>{s.junta}</td><td>{s.cargo}</td><td>{s.titular}</td><td><strong>{s.suplente}</strong></td>
                <td className="sin-corte">{formatear(s.desde, "date")}</td><td className="sin-corte">{formatear(s.hasta, "date")}</td><td className="numero">{s.dias_encadenados}</td>
                <td className="sin-corte">{s.acta}</td><td><span className={`insignia insignia-${nivel(s.diagnostico)}`}>{s.diagnostico.replace(/^ALERTA (ALTA|MEDIA): /, "").toLowerCase()}</span></td>
                <td className="sin-corte">{usuario.gestiona_suplencias && s.estado === "VIGENTE" && !["TERMINADA"].includes(s.diagnostico) && <>
                  {!s.renovada && <button className="btn btn-sm" onClick={() => setRenovar(s)}>Renovar</button>} <button className="btn btn-sm" onClick={revocar(s)}>Revocar</button></>}</td></tr>
            ))}
            {filas.length === 0 && <tr><td colSpan={10} className="vacio">No hay suplencias vigentes.</td></tr>}
          </tbody></table></div>
      )}
      {(nueva || renovar) && <FormSuplencia renovar={renovar} onCerrar={() => { setNueva(false); setRenovar(null); }}
        onListo={(r) => { setNueva(false); setRenovar(null); setMsg({ tipo: r.aviso ? "advertencia" : "exito", texto: r.aviso || "Suplencia registrada: el suplente ya puede actuar." }); cargar(); }} />}
    </section>
  );
}

function FormSuplencia({ renovar, onCerrar, onListo }) {
  const [d, setD] = useState({ id_estamento: null, id_cargo: "", id_persona_suplente: null, desde: hoyISO(), hasta: masDias(hoyISO(), 29), id_acta: null, motivo: "" });
  const [cargos, setCargos] = useState([]);
  const [error, setError] = useState("");
  useEffect(() => { if (d.id_estamento) api.get(`/api/suplencias/cargos/${d.id_estamento}`).then(setCargos).catch(() => setCargos([])); }, [d.id_estamento]);
  const titular = cargos.find((c) => String(c.id_cargo) === String(d.id_cargo));
  const enviar = async (e) => {
    e.preventDefault(); setError("");
    try {
      onListo(renovar ? await api.post(`/api/suplencias/${renovar.id_suplencia}/renovar`, { hasta: d.hasta, id_acta: d.id_acta, motivo: d.motivo })
        : await api.post("/api/suplencias", { ...d, id_cargo: Number(d.id_cargo), id_persona_titular: titular?.id_persona }));
    } catch (x) { setError(x.message); }
  };
  return (
    <Modal titulo={renovar ? `Renovar suplencia de ${renovar.cargo} (${renovar.junta})` : "Registrar suplencia"} onCerrar={onCerrar} ancho={640}
      pie={<><span className="espacio" /><button className="btn" onClick={onCerrar}>Cancelar</button><button className="btn btn-primario" form="form-sup">{renovar ? "Renovar" : "Registrar"}</button></>}>
      <form id="form-sup" className="rejilla-campos" onSubmit={enviar}>
        <Aviso tipo="error">{error}</Aviso>
        {!renovar && <>
          <div className="campo"><label>Junta</label><SelectorFK recurso="estamentos" valor={d.id_estamento} onCambio={(v) => setD({ ...d, id_estamento: v, id_cargo: "" })} requerido /></div>
          <div className="campo"><label htmlFor="su-c">Cargo que se suple</label>
            <select id="su-c" value={d.id_cargo} onChange={(e) => setD({ ...d, id_cargo: e.target.value })} required>
              <option value="">—</option>{cargos.map((c) => <option key={c.id_cargo} value={c.id_cargo}>{c.cargo} — {c.titular}</option>)}</select></div>
          <div className="campo campo-ancho"><label>Suplente (afiliado activo)</label><SelectorFK recurso="personas" valor={d.id_persona_suplente} onCambio={(v) => setD({ ...d, id_persona_suplente: v })} requerido /></div>
          <div className="campo"><label htmlFor="su-d">Desde</label><input id="su-d" type="date" value={d.desde} onChange={(e) => setD({ ...d, desde: e.target.value, hasta: masDias(e.target.value, 29) })} required /></div>
        </>}
        <div className="campo"><label htmlFor="su-h">Hasta (máximo 90 días)</label><input id="su-h" type="date" value={d.hasta} onChange={(e) => setD({ ...d, hasta: e.target.value })} required /></div>
        <div className="campo campo-ancho"><label>Acta de la junta que la decidió</label><SelectorFK recurso="documentos" valor={d.id_acta} onCambio={(v) => setD({ ...d, id_acta: v })} requerido /></div>
        <div className="campo campo-ancho"><label htmlFor="su-m">Motivo de la ausencia</label><input id="su-m" value={d.motivo} onChange={(e) => setD({ ...d, motivo: e.target.value })} required={!renovar} /></div>
        <p className="tenue pequeno campo-ancho">Mientras dure, el titular queda suspendido. Si la ausencia supera 60 días, el sistema avisa a la mesa para que estudie la vacancia según los estatutos.</p>
      </form>
    </Modal>
  );
}
