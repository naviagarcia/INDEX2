// Cliente HTTP de la API. El token vive en memoria y en sessionStorage (se borra al cerrar la ventana).
let token = sessionStorage.getItem("sgs_token");
const oyentesSesion = new Set();

export function setToken(t) {
  token = t;
  if (t) sessionStorage.setItem("sgs_token", t);
  else sessionStorage.removeItem("sgs_token");
}
export const getToken = () => token;
export const alPerderSesion = (fn) => { oyentesSesion.add(fn); return () => oyentesSesion.delete(fn); };

// Doble verificación (HTTP 428): la interfaz registra quién pide el código; sin registro se usa prompt().
let pedirCodigo = null;
export const alPedirCodigo = (fn) => { pedirCodigo = fn; return () => { if (pedirCodigo === fn) pedirCodigo = null; }; };
async function obtenerCodigo(mensaje) {
  if (pedirCodigo) return pedirCodigo(mensaje);
  const c = window.prompt(`${mensaje}\nEscriba el código de su aplicación o un código de recuperación:`);
  return c ? { codigo: c.trim(), metodo: /[A-Za-z-]/.test(c) ? "recuperacion" : "app" } : null;
}

export class ErrorApi extends Error {
  constructor(status, detalle) {
    const msg = typeof detalle === "string" ? detalle : detalle?.mensaje || "Error inesperado";
    super(msg);
    this.status = status;
    this.detalle = detalle;
  }
}

async function solicitud(metodo, ruta, opciones = {}, reintento = false) {
  const { params, json, form, blob } = opciones;
  const url = new URL(ruta, window.location.origin);
  if (params) Object.entries(params).forEach(([k, v]) => v !== undefined && v !== null && v !== "" && url.searchParams.set(k, v));
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  let body;
  if (json !== undefined) { headers["Content-Type"] = "application/json"; body = JSON.stringify(json); }
  if (form) body = form;
  let r;
  try {
    r = await fetch(url, { method: metodo, headers, body });
  } catch {
    throw new ErrorApi(0, "No hay conexión con el servidor.");
  }
  if (r.status === 401 && token) {
    const d = await r.json().catch(() => ({}));
    setToken(null);
    oyentesSesion.forEach((fn) => fn(d.detail));
    throw new ErrorApi(401, d.detail || "Sesión vencida");
  }
  if (r.status === 428 && !reintento) {
    // Acción crítica: pedir el código, confirmar la doble verificación y repetir una sola vez
    const d = await r.json().catch(() => ({}));
    const msg = typeof d.detail === "string" ? d.detail : "Acción crítica: confirme con su código de verificación.";
    let error = "";
    for (;;) {
      const datos = await obtenerCodigo(error || msg);
      if (!datos) throw new ErrorApi(428, "Acción cancelada: no se confirmó el código de verificación.");
      try { await solicitud("POST", "/api/mfa/paso-adicional", { json: datos }, true); break; }
      catch (e) {
        if (e.status === 423) { setToken(null); oyentesSesion.forEach((fn) => fn(e.message)); }
        if (e.status === 401 || e.status === 423) throw e;
        error = e.message;
      }
    }
    return solicitud(metodo, ruta, opciones, true);
  }
  if (!r.ok) {
    const d = await r.json().catch(() => ({ detail: r.statusText }));
    throw new ErrorApi(r.status, d.detail);
  }
  if (blob) return r.blob();
  return r.status === 204 ? null : r.json();
}

export const api = {
  get: (ruta, params) => solicitud("GET", ruta, { params }),
  post: (ruta, json, params) => solicitud("POST", ruta, { json, params }),
  put: (ruta, json, params) => solicitud("PUT", ruta, { json, params }),
  del: (ruta, params) => solicitud("DELETE", ruta, { params }),
  subir: (ruta, archivo) => { const f = new FormData(); f.append("archivo", archivo); return solicitud("POST", ruta, { form: f }); },
  subirVarios: (ruta, archivos) => { const f = new FormData(); [...archivos].forEach((a) => f.append("archivos", a)); return solicitud("POST", ruta, { form: f }); },
  descargar: (ruta) => solicitud("GET", ruta, { blob: true }),
  postBlob: (ruta, json) => solicitud("POST", ruta, { json, blob: true }),
};

// Llave primaria de un registro como parámetros de consulta
export const pkParams = (meta, fila) => Object.fromEntries(meta.pk.map((c) => [c, fila[c]]));
export const pkTexto = (meta, fila) => meta.pk.map((c) => fila[c]).join("|");
