import { useCallback, useEffect, useMemo, useState } from "react";
import { api, ErrorApi, pkParams, pkTexto } from "./api.js";
import { AccionesPolitica } from "./Contenidos.jsx";
import { AccionesPrivacidad, DatoReservado } from "./Privacidad.jsx";
import { CambiarPertenencia, ExpedientePanel, Trasladar } from "./Expediente.jsx";
import { DesignarDirectivo, DetallePermiso, SolicitarPermiso } from "./Permisos.jsx";
import { RolesUsuario } from "./Roles.jsx";
import { Aviso, Campo, Cargando, cargarEtiquetas, formatear, Modal, olvidarEtiquetas, Paginador } from "./ui.jsx";

const permisosDe = (meta, permisos) => {
  const p = permisos[meta.modulo] || {};
  return {
    crear: p.registrar && meta.operaciones.includes("crear"),
    editar: p.actualizar && meta.operaciones.includes("editar"),
    eliminar: p.eliminar && meta.operaciones.includes("eliminar"),
    baja: !!p.eliminar && !!meta.baja,  // inactivar/reactivar o anular (nada se borra)
  };
};

export default function RecursoPagina({ meta, permisos, catalogo }) {
  const [datos, setDatos] = useState({ filas: [], total: 0 });
  const [pagina, setPagina] = useState(1);
  const [q, setQ] = useState("");
  const [busqueda, setBusqueda] = useState("");
  const [orden, setOrden] = useState({ campo: null, dir: "asc" });
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");
  const [etiquetas, setEtiquetas] = useState({});
  const [abierto, setAbierto] = useState(null); // null | {} (nuevo) | fila
  const [verInactivos, setVerInactivos] = useState(false);
  const [dialogo, setDialogo] = useState(null);   // formularios propios: solicitar permiso, designar directivo
  const puede = permisosDe(meta, permisos);
  const campos = useMemo(() => Object.fromEntries(meta.campos.map((c) => [c.nombre, c])), [meta]);
  const TAM = 25;

  const cargar = useCallback(async () => {
    setCargando(true);
    setError("");
    try {
      const r = await api.get(`/api/r/${meta.clave}`, { q: busqueda, pagina, tam: TAM, orden: orden.campo, dir: orden.dir,
        ...(meta.baja === "inactivar" && verInactivos ? { inactivos: true } : {}) });
      setDatos(r);
      // Nombres legibles para las llaves foráneas visibles
      const nuevas = {};
      await Promise.all(meta.columnas.filter((c) => campos[c]?.tipo === "fk").map(async (c) => {
        nuevas[c] = await cargarEtiquetas(campos[c].fk, r.filas.map((f) => f[c]));
      }));
      setEtiquetas(nuevas);
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
    }
  }, [meta, busqueda, pagina, orden, campos, verInactivos]);

  useEffect(() => { cargar(); }, [cargar]);
  useEffect(() => { setPagina(1); setBusqueda(""); setQ(""); setOrden({ campo: null, dir: "asc" }); setVerInactivos(false); }, [meta.clave]);
  useEffect(() => { const t = setTimeout(() => { setBusqueda(q); setPagina(1); }, 350); return () => clearTimeout(t); }, [q]);

  const ordenarPor = (c) => setOrden((o) => ({ campo: c, dir: o.campo === c && o.dir === "asc" ? "desc" : "asc" }));

  const celda = (fila, c) => {
    const campo = campos[c];
    const v = fila[c];
    if (campo?.tipo === "fk" && v !== null && v !== undefined) return etiquetas[c]?.[String(v)] || `#${v}`;
    return formatear(v, campo?.tipo);
  };

  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <h1>{meta.titulo}</h1>
          {meta.descripcion && <p className="tenue">{meta.descripcion}</p>}
        </div>
        <div className="acciones">
          {meta.baja === "inactivar" && (
            <label className="interruptor" title="Los registros no se borran: los inactivos quedan en el historial">
              <input type="checkbox" checked={verInactivos} onChange={(e) => { setVerInactivos(e.target.checked); setPagina(1); }} />
              <span>Ver inactivos</span>
            </label>
          )}
          <input className="buscador" type="search" placeholder="Buscar…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar" />
          <button className="btn" onClick={cargar} title="Recargar">⟳</button>
          {meta.clave === "municipios" && permisos.ADMINISTRACION?.actualizar && (
            <label className="btn" title="Archivo oficial DIVIPOLA del DANE (CSV)">
              Cargar archivo DIVIPOLA…
              <input type="file" accept=".csv,.txt,text/csv" hidden onChange={async (e) => {
                const f = e.target.files[0]; if (!f) return;
                try {
                  const r = await api.subir("/api/admin/divipola", f); e.target.value = "";
                  window.alert(`Lista cargada: ${r.municipios} municipios vigentes (${r.nuevos} nuevos, ${r.inactivados} ya no vigentes). Registros revisados: ${r.registros_revisados}. Por corregir: ${r.por_corregir}.`);
                  cargar();
                } catch (e2) { setError(e2.message); }
              }} />
            </label>
          )}
          {meta.clave === "permisos_sindicales" && <button className="btn btn-primario" onClick={() => setDialogo("permiso")}>+ Solicitar permiso</button>}
          {meta.clave === "designaciones" && permisos.GOBERNANZA?.registrar && <button className="btn btn-primario" onClick={() => setDialogo("designar")}>+ Designar directivo</button>}
          {puede.crear && <button className="btn btn-primario" onClick={() => setAbierto({})}>+ Nuevo</button>}
        </div>
      </header>

      <Aviso tipo="error" onCerrar={() => setError("")}>{error}</Aviso>
      {dialogo === "permiso" && <SolicitarPermiso onCerrar={() => setDialogo(null)} onCreado={cargar} />}
      {dialogo === "designar" && <DesignarDirectivo onCerrar={() => setDialogo(null)} onCreado={cargar} />}

      <div className="tabla-marco">
        {cargando && datos.filas.length === 0 ? <Cargando /> : (
          <table className="tabla">
            <thead>
              <tr>
                {meta.columnas.map((c) => (
                  <th key={c} onClick={() => ordenarPor(c)} className="ordenable" aria-sort={orden.campo === c ? (orden.dir === "asc" ? "ascending" : "descending") : "none"}>
                    {campos[c]?.etiqueta || c}{orden.campo === c ? (orden.dir === "asc" ? " ▲" : " ▼") : ""}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {datos.filas.map((f) => (
                <tr key={pkTexto(meta, f)} onClick={() => setAbierto(f)}
                    className={f.activo === false || f.anulado === true ? "fila-inactiva" : undefined}
                    title={f.activo === false ? "Inactivo" : f.anulado === true ? "Anulado" : undefined} tabIndex={0} onKeyDown={(e) => e.key === "Enter" && setAbierto(f)}>
                  {meta.columnas.map((c, i) => <td key={c} className={campos[c]?.tipo === "decimal" || campos[c]?.tipo === "int" ? "num" : ""}>
                    {i === 0 && f.activo === false && <span className="insignia insignia-inactivo">Inactivo</span>}
                    {i === 0 && f.anulado === true && <span className="insignia insignia-inactivo">Anulado</span>}
                    {celda(f, c)}</td>)}
                </tr>
              ))}
              {!cargando && datos.filas.length === 0 && (
                <tr><td colSpan={meta.columnas.length} className="vacio">No hay registros{busqueda ? " que coincidan con la búsqueda" : ""}.</td></tr>
              )}
            </tbody>
          </table>
        )}
      </div>
      <Paginador pagina={pagina} tam={TAM} total={datos.total} onPagina={setPagina} />

      {abierto && (
        <Formulario
          meta={meta}
          inicial={abierto}
          puede={puede}
          permisos={permisos}
          catalogo={catalogo}
          onCerrar={() => setAbierto(null)}
          onGuardado={() => { olvidarEtiquetas(meta.clave); cargar(); }}
        />
      )}
    </section>
  );
}

// ------------------------------------------------------------------ formulario con control de concurrencia
export function Formulario({ meta, inicial, puede, permisos, catalogo, onCerrar, onGuardado }) {
  const esNuevo = !inicial || Object.keys(inicial).length === 0;
  const [valores, setValores] = useState(() => (esNuevo ? {} : { ...inicial }));
  const [original, setOriginal] = useState(() => (esNuevo ? {} : { ...inicial }));
  // Al cambiar un campo se vacían los que dependen de él (p. ej. departamento → municipio)
  const cambiarCampo = (nombre, v) => setValores((s) => {
    const n = { ...s, [nombre]: v };
    let cola = [nombre];
    while (cola.length) {
      const padre = cola.shift();
      meta.campos.filter((x) => x.depende === padre && n[x.nombre] != null && padre !== x.nombre).forEach((x) => { n[x.nombre] = null; cola.push(x.nombre); });
    }
    return n;
  });
  const [error, setError] = useState("");
  const [conflicto, setConflicto] = useState(null);
  const [ok, setOk] = useState("");
  const [guardando, setGuardando] = useState(false);
  const dadoDeBaja = !esNuevo && (original.activo === false || original.anulado === true);
  const editable = esNuevo ? puede.crear : puede.editar && !dadoDeBaja;

  const soloLectura = (c) => {
    if (!editable || c.ro) return true;
    if (!esNuevo && (c.solo_crear || (meta.pk.includes(c.nombre) && !meta.pk_auto))) return true;
    return false;
  };
  const visibles = meta.campos.filter((c) => {
    if (c.oculto) return false;   // texto de lugar: se llena solo desde el código DIVIPOLA
    if (esNuevo && c.ro) return false;
    if (!esNuevo && c.virtual && c.solo_crear) return false;
    if (c.nombre === "_observacion" && esNuevo) return false;
    return true;
  });

  const guardar = async (e) => {
    e.preventDefault();
    setGuardando(true); setError(""); setOk(""); setConflicto(null);
    try {
      let r;
      if (esNuevo) {
        r = await api.post(`/api/r/${meta.clave}`, valores);
        setOk("Registro creado" + (r.radicado_alfanumerico ? ` con radicado ${r.radicado_alfanumerico}` : r.codigo_expediente ? ` con código ${r.codigo_expediente}` : "") + ".");
      } else {
        const cambios = Object.fromEntries(Object.entries(valores).filter(([k, v]) => JSON.stringify(v) !== JSON.stringify(original[k])));
        if (Object.keys(cambios).length === 0) { setOk("No hay cambios para guardar."); return; }
        r = await api.put(`/api/r/${meta.clave}/registro`, { ...cambios, version: original.version }, pkParams(meta, original));
        setOk("Cambios guardados.");
      }
      setValores({ ...r, _observacion: "" }); setOriginal(r);
      onGuardado();
      if (esNuevo) setTimeout(onCerrar, 900);
    } catch (e2) {
      if (e2 instanceof ErrorApi && e2.status === 409 && e2.detalle?.actual) setConflicto(e2.detalle);
      else setError(e2.message);
    } finally {
      setGuardando(false);
    }
  };

  const eliminar = async () => {
    if (!window.confirm("¿Quitar este detalle? Solo se permite mientras el acta no esté firmada; queda registrado en la auditoría.")) return;
    try {
      await api.del(`/api/r/${meta.clave}/registro`, { ...pkParams(meta, original), version: original.version });
      onGuardado(); onCerrar();
    } catch (e2) { setError(e2.message); }
  };

  // Nada se borra (R-01): inactivar / reactivar / anular, con motivo
  const darDeBaja = async (accion) => {
    let cuerpo = { version: original.version };
    if (accion === "reactivar") {
      if (!window.confirm("¿Reactivar este registro? Vuelve a aparecer en listas y desplegables.")) return;
    } else {
      const texto = accion === "anular"
        ? "Motivo de la anulación (mínimo 10 caracteres). La anulación es definitiva: el registro queda en el historial y sale de saldos y totales."
        : "Motivo de la inactivación (mínimo 10 caracteres). El registro no se borra: queda en el historial y se puede reactivar.";
      const motivo = window.prompt(texto); if (!motivo) return;
      cuerpo = { ...cuerpo, motivo };
    }
    setError(""); setOk("");
    try {
      const r = await api.post(`/api/r/${meta.clave}/${accion}`, cuerpo, pkParams(meta, original));
      const fila = accion === "anular" ? r.registro : r;
      setValores(fila); setOriginal(fila);
      setOk(accion === "anular" ? `Registro ${String(r.resultado).toLowerCase()}.` : accion === "inactivar" ? "Registro inactivado." : "Registro reactivado.");
      onGuardado();
    } catch (e2) {
      if (e2 instanceof ErrorApi && e2.status === 409 && e2.detalle?.actual) setConflicto(e2.detalle);
      else setError(e2.message);
    }
  };

  const usarActual = () => { setValores({ ...conflicto.actual }); setOriginal({ ...conflicto.actual }); setConflicto(null); };

  const titulo = esNuevo ? `Nuevo: ${meta.titulo}` : original.radicado_alfanumerico || original.codigo_expediente || `${meta.titulo} — detalle`;

  return (
    <Modal titulo={titulo} onCerrar={onCerrar} ancho={860} pie={
      <>
        {!esNuevo && puede.eliminar && <button className="btn btn-peligro" onClick={eliminar} type="button">Quitar</button>}
        {!esNuevo && puede.baja && meta.baja === "inactivar" && (original.activo === false
          ? <button className="btn" onClick={() => darDeBaja("reactivar")} type="button">Reactivar</button>
          : <button className="btn btn-peligro" onClick={() => darDeBaja("inactivar")} type="button">Inactivar</button>)}
        {!esNuevo && puede.baja && meta.baja === "anular" && original.anulado !== true &&
          <button className="btn btn-peligro" onClick={() => darDeBaja("anular")} type="button">Anular</button>}
        <span className="espacio" />
        {!esNuevo && <span className="tenue version">Versión {original.version ?? "—"}</span>}
        <button className="btn" onClick={onCerrar} type="button">Cerrar</button>
        {editable && <button className="btn btn-primario" type="submit" form="form-registro" disabled={guardando}>{guardando ? "Guardando…" : "Guardar"}</button>}
      </>
    }>
      {conflicto && (
        <Aviso tipo="advertencia">
          <strong>Conflicto de edición.</strong> {conflicto.mensaje}{" "}
          <button className="btn btn-sm" onClick={usarActual}>Cargar datos actuales</button>
        </Aviso>
      )}
      <Aviso tipo="error" onCerrar={() => setError("")}>{error}</Aviso>
      <Aviso tipo="exito" onCerrar={() => setOk("")}>{ok}</Aviso>
      {original.activo === false && (
        <Aviso tipo="advertencia">Registro <strong>inactivo</strong> desde el {formatear(original.fecha_inactivacion, "datetime")}
          {original.usuario_inactivacion ? ` (por ${original.usuario_inactivacion})` : ""}. Motivo: {original.motivo_inactivacion || "—"}.
          {meta.baja === "inactivar" ? " Para modificarlo, primero reactívelo." : ""}</Aviso>
      )}
      {original.anulado === true && (
        <Aviso tipo="advertencia">Registro <strong>anulado</strong> el {formatear(original.fecha_anulacion, "datetime")}
          {original.usuario_anulacion ? ` por ${original.usuario_anulacion}` : ""}. Motivo: {original.motivo_anulacion || "—"}.
          No cuenta en saldos, totales ni mora.</Aviso>
      )}
      {!editable && !dadoDeBaja && <Aviso tipo="info">Modo consulta: su rol no permite modificar este registro.</Aviso>}

      <form id="form-registro" className="rejilla-campos" onSubmit={guardar}>
        {visibles.map((c) => (c.sensible && !esNuevo ? (
          <div key={c.nombre} className="campo">
            <label>{c.etiqueta}</label>
            <DatoReservado meta={meta} fila={original} campo={c} />
            {editable && !c.ro && <Campo campo={{ ...c, etiqueta: "Nuevo valor (solo si va a cambiarlo)", req: false }} valor={valores[c.nombre]}
                                       soloLectura={false} contexto={valores} onCambio={(v) => cambiarCampo(c.nombre, v)} />}
          </div>
        ) : (
          <Campo key={c.nombre} campo={c} valor={valores[c.nombre]} soloLectura={soloLectura(c)} contexto={valores}
                 onCambio={(v) => cambiarCampo(c.nombre, v)} />
        )))}
      </form>

      {!esNuevo && <AccionesExtra meta={meta} fila={original} permisos={permisos} catalogo={catalogo}
                                  onCambio={(r) => { if (r) { setValores(r); setOriginal(r); } onGuardado(); }} />}
    </Modal>
  );
}

// ------------------------------------------------------------------ acciones propias de cada tipo de registro
function AccionesExtra({ meta, fila, permisos, catalogo, onCambio }) {
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const [tabla, setTabla] = useState(null);
  const [verExp, setVerExp] = useState(false);
  const puede = (m, a) => !!permisos[m]?.[a];
  const avisar = (tipo, texto) => setMsg({ tipo, texto });
  const intentar = (fn) => async (...a) => { try { await fn(...a); } catch (e) { avisar("error", e.message); } };

  const recargar = async () => onCambio(await api.get(`/api/r/${meta.clave}/registro`, pkParams(meta, fila)));

  let botones = null;
  let panel = null;
  if (["personas", "anonimizaciones", "autorizaciones_datos", "politicas_tratamiento", "textos_institucionales", "solicitudes_titular"].includes(meta.clave)) {
    botones = <AccionesPrivacidad meta={meta} fila={fila} permisos={permisos} recargar={recargar} avisar={avisar} intentar={intentar} />;
  } else if ((meta.clave === "porcentajes_junta" || meta.clave === "porcentajes_afiliado") && catalogo?.usuarios) {
    // Solo el administrador ve el catálogo de usuarios: es quien corrige errores de digitación
    const tabla = meta.clave === "porcentajes_junta" ? "junta" : "afiliado";
    const id = fila.id_porcentaje_junta ?? fila.id_porcentaje_afiliado;
    botones = <button className="btn" onClick={intentar(async () => {
      const pct = window.prompt("Porcentaje correcto (p. ej. 0.6). Solo si fue un error de digitación y aún no hay aportes con este porcentaje:"); if (!pct) return;
      const motivo = window.prompt("Motivo de la corrección (queda en la auditoría):"); if (!motivo) return;
      await api.post(`/api/finanzas/porcentajes/${tabla}/${id}/corregir`, { porcentaje: pct.replace(",", "."), motivo });
      avisar("exito", "Porcentaje corregido."); await recargar();
    })}>Corregir (error de digitación)</button>;
  } else if (meta.clave === "solicitudes_afiliacion") {
    // Documentos, revisión y decisión: el expediente decide qué puede hacer cada quien
    botones = fila.estado === "PENDIENTE" && puede("GOBERNANZA", "actualizar") ? (
      <button className="btn" onClick={intentar(async () => {
        if (!window.confirm("¿Invitar a esta persona al portal? Recibirá un enlace personal (48 horas) para crear su cuenta y subir sus documentos.")) return;
        const r = await api.post("/api/autoservicio/invitaciones", { id_persona: fila.id_persona });
        avisar(r.enviado ? "exito" : "advertencia", r.enviado ? `Invitación enviada a ${r.correo}.` : `${r.aviso} Enlace: ${r.enlace}`);
      })}>Invitar al portal (para subir sus documentos)</button>
    ) : <></>;
    panel = <ExpedientePanel idPersona={fila.id_persona} onDecidido={recargar} />;
  } else if (meta.clave === "afiliados" && fila.activo !== false) {
    const cert = (tipo) => intentar(async () => {
      const b = await api.postBlob(`/api/autoservicio/personas/${fila.id_persona}/certificados`, { tipo });
      const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = `${tipo.toLowerCase()}_${fila.id_persona}.pdf`; a.click();
      avisar("exito", "Certificado generado con código de verificación.");
    });
    botones = (
      <>
        {puede("GOBERNANZA", "actualizar") && <button className="btn btn-primario" onClick={intentar(async () => {
          if (!window.confirm("¿Invitar a este afiliado al portal? Recibirá en su correo un enlace personal de un solo uso (48 horas).")) return;
          const r = await api.post("/api/autoservicio/invitaciones", { id_persona: fila.id_persona });
          avisar(r.enviado ? "exito" : "advertencia", r.enviado ? `Invitación enviada a ${r.correo}.` : `${r.aviso} Enlace: ${r.enlace}`);
        })}>Invitar al portal del afiliado</button>}
        <button className="btn" onClick={cert("AFILIACION")}>Certificado de afiliación</button>
        <button className="btn" onClick={cert("PAZ_Y_SALVO")}>Paz y salvo</button>
        <button className="btn" onClick={() => setVerExp((v) => !v)}>{verExp ? "Ocultar expediente" : "Expediente de afiliación"}</button>
        <Trasladar idPersona={fila.id_persona} onCambio={recargar} />
        <CambiarPertenencia idPersona={fila.id_persona} onCambio={recargar} />
      </>
    );
    if (verExp) panel = <ExpedientePanel idPersona={fila.id_persona} />;
  } else if (meta.clave === "traslados" && fila.estado === "PROPUESTO") {
    const responder = (accion) => intentar(async () => {
      const datos = {};
      if (accion !== "anular") {
        const a = window.prompt("Radicado del acta de la reunión de su junta que decidió sobre el traslado:"); if (!a) return;
        datos.acta = a.trim();
      }
      if (accion !== "aceptar") { const m = window.prompt(accion === "anular" ? "Motivo de la anulación:" : "Motivo del rechazo:"); if (!m) return; datos.motivo = m; }
      const r = await api.post(`/api/afiliacion/traslados/${fila.id_traslado}/${accion}`, datos);
      avisar("exito", r.estado === "APROBADO" ? "Traslado aprobado: el afiliado ya pertenece a la nueva junta." : `Traslado ${r.estado.toLowerCase()}.`);
      await recargar();
    });
    botones = (
      <>
        <button className="btn btn-primario" onClick={responder("aceptar")}>Aceptar (con acta)</button>
        <button className="btn" onClick={responder("rechazar")}>Rechazar (con acta)</button>
        <button className="btn" onClick={responder("anular")}>Anular (quien lo propuso)</button>
      </>
    );
  } else if (meta.clave === "permisos_sindicales") {
    botones = <></>;
    panel = <DetallePermiso idPermiso={fila.id_permiso} onCambio={recargar} />;
  } else if (meta.clave === "designaciones" && fila.estado === "PENDIENTE") {
    botones = <button className="btn" onClick={intentar(async () => {
      const m = window.prompt("Motivo de la anulación (por ejemplo, la junta cambió su decisión):"); if (!m) return;
      await api.post(`/api/directivos/designaciones/${fila.id_designacion}/anular`, { motivo: m });
      avisar("exito", "Designación anulada."); await recargar();
    })}>Anular la designación</button>;
  } else if (meta.clave === "tipos_documento_afiliacion") {
    botones = (
      <label className="btn">
        {fila.plantilla_nombre ? "Cambiar plantilla…" : "Subir plantilla (PDF o Word)…"}
        <input type="file" accept=".pdf,.doc,.docx" hidden onChange={intentar(async (e) => {
          const f = e.target.files[0]; if (!f) return;
          await api.subir(`/api/afiliacion/tipos/${fila.codigo}/plantilla`, f);
          avisar("exito", "Plantilla publicada: la persona la descarga desde su portal."); await recargar();
        })} />
      </label>
    );
  } else if (meta.clave === "usuarios" && fila.id_usuario) {
    return <RolesUsuario idUsuario={fila.id_usuario} />;
  } else if (meta.clave === "exoneraciones" && fila.estado === "SOLICITADA") {
    return <DecisionExoneracion fila={fila} onCambio={recargar} />;
  } else if (meta.clave === "documentos") {
    const id = fila.id_documento;
    botones = (
      <>
        {!fila.hash_sha256 && puede("DOCUMENTAL", "actualizar") && (
          <label className="btn">
            Adjuntar PDF…
            <input type="file" accept="application/pdf" hidden onChange={intentar(async (e) => {
              const f = e.target.files[0]; if (!f) return;
              const r = await api.subir(`/api/documentos/${id}/archivo`, f);
              avisar("exito", `Archivo guardado. Huella SHA-256: ${r.hash_sha256}`); await recargar();
            })} />
          </label>
        )}
        {fila.hash_sha256 && <button className="btn" onClick={intentar(async () => {
          const b = await api.descargar(`/api/documentos/${id}/archivo`);
          const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = fila.nombre_archivo_adjunto || "documento.pdf"; a.click();
        })}>Descargar PDF</button>}
        {fila.hash_sha256 && <button className="btn" onClick={intentar(async () => {
          const r = await api.get(`/api/documentos/${id}/verificar`);
          avisar(r.integro ? "exito" : "error", r.integro ? "Integridad verificada: el archivo no ha sido alterado." : "ALERTA: el archivo fue alterado, la huella no coincide.");
        })}>Verificar integridad</button>}
        <button className="btn" onClick={intentar(async () => {
          const r = await api.get("/api/r/historial_tramite", { f_id_documento: id, tam: 100 });
          setTabla({ titulo: "Historial del trámite", columnas: ["fecha_movimiento", "estado_anterior", "estado_nuevo", "usuario_responsable", "observaciones"], filas: r.filas });
        })}>Historial del trámite</button>
      </>
    );
  } else if (meta.clave === "egresos") {
    const id = fila.id_egreso;
    botones = (
      <>
        {!fila.hash_soporte && fila.estado === "REGISTRADO" && puede("FINANZAS", "actualizar") && (
          <label className="btn">
            Adjuntar soporte PDF…
            <input type="file" accept="application/pdf" hidden onChange={intentar(async (e) => {
              const f = e.target.files[0]; if (!f) return;
              const r = await api.subir(`/api/egresos/${id}/soporte`, f);
              avisar("exito", `Soporte guardado. Huella SHA-256: ${r.hash_sha256}`); await recargar();
            })} />
          </label>
        )}
        {fila.hash_soporte && <button className="btn" onClick={intentar(async () => {
          const b = await api.descargar(`/api/egresos/${id}/soporte`);
          const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = fila.nombre_archivo_soporte || "soporte.pdf"; a.click();
        })}>Descargar soporte</button>}
        {fila.estado === "REGISTRADO" && <button className="btn btn-primario" onClick={intentar(async () => {
          if (!window.confirm("¿Firmar la aprobación de este egreso? Su firma queda registrada con su cargo.")) return;
          const r = await api.post(`/api/egresos/${id}/aprobar`);
          avisar(r.resultado === "APROBADO" ? "exito" : "info", r.resultado === "APROBADO" ? "Egreso APROBADO con las dos firmas." : r.resultado);
          await recargar();
        })}>Firmar aprobación</button>}
        {fila.estado !== "ANULADO" && <button className="btn btn-peligro" onClick={intentar(async () => {
          const motivo = window.prompt("Motivo de la anulación (queda en el historial):"); if (!motivo) return;
          await api.post(`/api/egresos/${id}/anular`, { motivo });
          avisar("exito", "Egreso anulado."); await recargar();
        })}>Anular</button>}
        <button className="btn" onClick={intentar(async () => {
          const r = await api.get("/api/r/egreso_firmas", { f_id_egreso: id });
          setTabla({ titulo: "Firmas", columnas: ["rol", "cargo", "fecha"], filas: r.filas });
        })}>Ver firmas</button>
      </>
    );
  } else if (meta.clave === "expedientes") {
    botones = <button className="btn" onClick={intentar(async () => {
      const r = await api.get(`/api/expedientes/${encodeURIComponent(fila.codigo_expediente)}/hoja-ruta`);
      setTabla({ titulo: "Hoja de ruta (folios)", columnas: ["folio", "radicado_documento", "tipo_documento", "asunto", "fecha_radicacion"], filas: r });
    })}>Ver hoja de ruta</button>;
  } else if (meta.clave === "consignaciones" && puede("FINANZAS", "registrar")) {
    const generar = (soloJunta) => intentar(async () => {
      const r = await api.post(`/api/consignaciones/${fila.id_consignacion}/generar-aportes`, undefined, { solo_junta: soloJunta });
      const c = r.conciliacion;
      avisar(c.diagnostico_auditoria.startsWith("ARMONIZADO") ? "exito" : "advertencia",
        `${r.aportes_creados} aporte(s) creados. Consignado ${formatear(c.monto_total_consignado, "decimal")} · suma de aportes ${formatear(c.suma_aportes_individuales, "decimal")} · ${c.diagnostico_auditoria}`);
    });
    botones = <>
      <button className="btn" onClick={generar(false)} title="Todos los afiliados de la empresa que aún no tienen aporte en ese mes">Generar aportes del 0.7%</button>
      <button className="btn" onClick={generar(true)} title="Úselo si la empresa repartió el pago: en la subcuenta, solo los afiliados de esa junta">Solo afiliados de la junta de la subcuenta</button>
    </>;
  } else if (meta.clave === "compromisos") {
    botones = (
      <>
        {puede("DOCUMENTAL", "registrar") && <button className="btn" onClick={intentar(async () => {
          const pct = window.prompt("Porcentaje de avance (0-100):", String(fila.porcentaje_avance ?? 0)); if (pct === null) return;
          const desc = window.prompt("Describa el avance:"); if (!desc) return;
          await api.post("/api/r/avances_compromiso", { id_compromiso: fila.id_compromiso, porcentaje_avance_registrado: Number(pct), descripcion_avance: desc });
          avisar("exito", "Avance registrado."); await recargar();
        })}>Registrar avance</button>}
        <button className="btn" onClick={intentar(async () => {
          const r = await api.get("/api/r/avances_compromiso", { f_id_compromiso: fila.id_compromiso, tam: 100 });
          setTabla({ titulo: "Avances registrados", columnas: ["fecha_registro", "porcentaje_avance_registrado", "descripcion_avance", "usuario_registra"], filas: r.filas });
        })}>Ver avances</button>
      </>
    );
  } else if (meta.clave === "politicas_comunicacion" && puede("GOBERNANZA", "actualizar")) {
    return <AccionesPolitica fila={fila} onCambio={recargar} />;
  } else if (meta.clave === "cuentas_redes") {
    return <ClaveRed fila={fila} puedeCambiar={puede("GOBERNANZA", "actualizar")} onCambio={recargar} />;
  } else if (meta.clave === "usuarios" && puede("ADMINISTRACION", "actualizar")) {
    botones = (
      <>
        <button className="btn" onClick={intentar(async () => {
          const c = window.prompt("Nueva contraseña temporal (el usuario deberá cambiarla):"); if (!c) return;
          await api.post(`/api/admin/usuarios/${fila.id_usuario}/restablecer-contrasena`, { contrasena: c });
          avisar("exito", "Contraseña restablecida y sesiones del usuario cerradas."); await recargar();
        })}>Restablecer contraseña</button>
        {fila.bloqueado_hasta && <button className="btn" onClick={intentar(async () => {
          await api.post(`/api/admin/usuarios/${fila.id_usuario}/desbloquear`); avisar("exito", "Usuario desbloqueado."); await recargar();
        })}>Desbloquear</button>}
      </>
    );
  }
  if (!botones) return null;
  return (
    <div className="acciones-extra">
      <h3>Acciones</h3>
      <div className="acciones">{botones}</div>
      <Aviso tipo={msg.tipo} onCerrar={() => avisar("info", "")}>{msg.texto}</Aviso>
      {panel}
      {tabla && (
        <div className="subtabla">
          <h4>{tabla.titulo}</h4>
          <table className="tabla tabla-compacta">
            <thead><tr>{tabla.columnas.map((c) => <th key={c}>{c.replace(/_/g, " ")}</th>)}</tr></thead>
            <tbody>
              {tabla.filas.map((f, i) => <tr key={i}>{tabla.columnas.map((c) => <td key={c}>{formatear(f[c])}</td>)}</tr>)}
              {tabla.filas.length === 0 && <tr><td colSpan={tabla.columnas.length} className="vacio">Sin registros.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ------------------------------------------------------------------ clave de una cuenta de red social
function generarClave(n = 20) {
  const juego = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*?-_";
  const a = new Uint32Array(n); crypto.getRandomValues(a);
  return Array.from(a, (x) => juego[x % juego.length]).join("");
}

function ClaveRed({ fila, puedeCambiar, onCambio }) {
  const id = fila.id_cuenta_red;
  const [perm, setPerm] = useState(null);
  const [visible, setVisible] = useState(null);       // { clave, vigente, fecha, restante }
  const [form, setForm] = useState(null);             // { clave, confirmacion, motivo, mostrar }
  const [tabla, setTabla] = useState(null);
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const avisar = (tipo, texto) => setMsg({ tipo, texto });
  const intentar = (fn) => async (...a) => { try { await fn(...a); } catch (e) { avisar("error", e.message); } };

  useEffect(() => { api.get(`/api/redes/${id}/permiso`).then(setPerm).catch((e) => avisar("error", e.message)); }, [id]);
  useEffect(() => {
    if (!visible) return undefined;
    if (visible.restante <= 0) { setVisible(null); return undefined; }
    const t = setTimeout(() => setVisible((v) => v && { ...v, restante: v.restante - 1 }), 1000);
    return () => clearTimeout(t);
  }, [visible]);
  useEffect(() => () => setVisible(null), []);

  const ver = (idClave, motivo) => intentar(async () => {
    const r = await api.post(`/api/redes/${id}/ver`, { id_clave: idClave ?? null, motivo: motivo ?? null });
    setVisible({ ...r, restante: r.segundos_visible });
  });
  const guardar = intentar(async (e) => {
    e.preventDefault();
    await api.post(`/api/redes/${id}/clave`, { clave: form.clave, confirmacion: form.confirmacion, motivo: form.motivo });
    setForm(null); setVisible(null); avisar("exito", "Clave guardada cifrada. La anterior quedó en el historial.");
    setPerm({ ...perm, tiene_clave: true }); await onCambio();
  });

  const hoyLocal = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  const publicar = intentar(async () => {
    await api.put("/api/r/cuentas_redes/registro", { fecha_ultima_publicacion: hoyLocal, version: fila.version }, { id_cuenta_red: id });
    avisar("exito", "Publicación de hoy registrada."); await onCambio();
  });
  const diasSin = fila.fecha_ultima_publicacion ? Math.round((new Date(hoyLocal) - new Date(fila.fecha_ultima_publicacion)) / 864e5) : null;

  if (!perm) return null;
  return (
    <div className="acciones-extra">
      <h3>Publicaciones</h3>
      <div className="acciones">
        <span className={diasSin === null || diasSin > (fila.dias_max_sin_publicar ?? 5) ? "insignia insignia-alta" : "insignia insignia-normal"}>
          {diasSin === null ? "Sin publicaciones registradas" : diasSin === 0 ? "Publicó hoy" : `${diasSin} día(s) sin publicar`}</span>
        <span className="tenue pequeno">Máximo permitido: {fila.dias_max_sin_publicar ?? 5} días</span>
        {puedeCambiar && diasSin !== 0 && <button className="btn btn-sm" onClick={publicar}>Registrar publicación de hoy</button>}
      </div>
      <h3>Clave de acceso</h3>
      {!perm.cifrado_configurado && <Aviso tipo="advertencia">El servidor no tiene configurada la llave de cifrado (SECRETOS_LLAVE). Pida al administrador que la configure.</Aviso>}
      {!perm.puede_ver_clave
        ? <p className="tenue">Solo los directivos vigentes de la junta dueña de esta cuenta (y los directivos nacionales con acceso nacional) pueden ver o cambiar la clave.</p>
        : <>
          {visible && (
            <div className="clave-visible" role="status">
              <code>{visible.clave}</code>
              <button className="btn btn-sm" onClick={() => navigator.clipboard?.writeText(visible.clave).then(() => avisar("exito", "Clave copiada."))}>Copiar</button>
              <button className="btn btn-sm" onClick={() => setVisible(null)}>Ocultar</button>
              <small className="tenue">{visible.vigente ? "Clave vigente" : `Clave anterior del ${formatear(visible.fecha, "datetime")}`} · se oculta en {visible.restante} s</small>
            </div>
          )}
          <div className="acciones">
            {perm.tiene_clave && !visible && <button className="btn btn-primario" onClick={ver()}>Ver clave</button>}
            {puedeCambiar && !form && <button className="btn" onClick={() => setForm({ clave: "", confirmacion: "", motivo: perm.tiene_clave ? "" : "Registro inicial", mostrar: false })}>
              {perm.tiene_clave ? "Cambiar clave" : "Registrar clave"}</button>}
            {perm.tiene_clave && <button className="btn" onClick={intentar(async () => setTabla({ tipo: "claves", filas: await api.get(`/api/redes/${id}/claves`) }))}>Historial de claves</button>}
            <button className="btn" onClick={intentar(async () => setTabla({ tipo: "consultas", filas: await api.get(`/api/redes/${id}/consultas`) }))}>Quién la ha visto</button>
          </div>
          {!perm.tiene_clave && <p className="tenue">El sindicato aún no tiene registrada la clave de esta cuenta.</p>}
          {form && (
            <form className="form-clave" onSubmit={guardar}>
              <div className="rejilla-campos">
                <div className="campo"><label htmlFor="k-1">Nueva clave</label>
                  <input id="k-1" type={form.mostrar ? "text" : "password"} value={form.clave} autoComplete="new-password" required
                    onChange={(e) => setForm({ ...form, clave: e.target.value })} /></div>
                <div className="campo"><label htmlFor="k-2">Confirmar clave</label>
                  <input id="k-2" type={form.mostrar ? "text" : "password"} value={form.confirmacion} autoComplete="new-password" required
                    onChange={(e) => setForm({ ...form, confirmacion: e.target.value })} /></div>
                <div className="campo campo-ancho"><label htmlFor="k-3">Motivo del cambio</label>
                  <input id="k-3" value={form.motivo} placeholder="Ej.: retiro de un directivo, cambio periódico…" onChange={(e) => setForm({ ...form, motivo: e.target.value })} /></div>
              </div>
              <div className="acciones">
                <button type="button" className="btn btn-sm" onClick={() => { const c = generarClave(); setForm({ ...form, clave: c, confirmacion: c, mostrar: true }); }}>Generar clave segura</button>
                <label className="interruptor"><input type="checkbox" checked={form.mostrar} onChange={(e) => setForm({ ...form, mostrar: e.target.checked })} /><span>Mostrar</span></label>
                <span className="espacio" />
                <button type="button" className="btn" onClick={() => setForm(null)}>Cancelar</button>
                <button className="btn btn-primario">Guardar clave</button>
              </div>
              <small className="tenue">Primero cambie la clave en la red social y luego regístrela aquí. Se guarda cifrada.</small>
            </form>
          )}
        </>}
      <Aviso tipo={msg.tipo} onCerrar={() => avisar("info", "")}>{msg.texto}</Aviso>
      {tabla && (
        <div className="subtabla">
          <h4>{tabla.tipo === "claves" ? "Historial de claves" : "Quién vio o cambió la clave"}</h4>
          <table className="tabla tabla-compacta">
            {tabla.tipo === "claves" ? <>
              <thead><tr><th>Fecha</th><th>Estado</th><th>Cambiada por</th><th>Motivo</th><th /></tr></thead>
              <tbody>{tabla.filas.map((k) => (
                <tr key={k.id_clave}><td>{formatear(k.fecha, "datetime")}</td><td>{k.vigente ? "Vigente" : "Anterior"}</td><td>{k.cambiada_por}</td><td>{k.motivo || "—"}</td>
                  <td>{!k.vigente && <button className="btn btn-sm" onClick={() => { const m = window.prompt("Motivo para ver esta clave anterior (queda registrado):"); if (m) ver(k.id_clave, m)(); }}>Ver</button>}</td></tr>))}
              </tbody>
            </> : <>
              <thead><tr><th>Fecha</th><th>Acción</th><th>Persona</th><th>Usuario</th><th>IP</th><th>Motivo</th></tr></thead>
              <tbody>{tabla.filas.map((q, i) => (
                <tr key={i}><td>{formatear(q.fecha, "datetime")}</td><td>{q.accion === "VER" ? (q.es_clave_vigente ? "Vio la clave" : "Vio una clave anterior") : "Cambió la clave"}</td>
                  <td>{q.persona || "—"}</td><td>{q.nombre_usuario}</td><td>{q.ip || "—"}</td><td>{q.motivo || "—"}</td></tr>))}
                {tabla.filas.length === 0 && <tr><td colSpan={6} className="vacio">Nadie ha consultado la clave.</td></tr>}
              </tbody>
            </>}
          </table>
        </div>
      )}
    </div>
  );
}

// ------------------------------------------------------------------ decisión de la junta sobre una exoneración
function DecisionExoneracion({ fila, onCambio }) {
  const [acta, setActa] = useState(null);
  const [obs, setObs] = useState("");
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const decidir = (decision) => async () => {
    try {
      const r = await api.post(`/api/finanzas/exoneraciones/${fila.id_exoneracion}/${decision}`, { id_acta: acta, observacion: obs || null });
      setMsg({ tipo: "exito", texto: `Exoneración ${r.estado.toLowerCase()}.` }); await onCambio();
    } catch (e) { setMsg({ tipo: "error", texto: e.message }); }
  };
  return (
    <div className="acciones-extra">
      <h3>Decisión de la junta</h3>
      <p className="tenue pequeno">La registran el Presidente o el Secretario General de la junta del afiliado, con el acta de la reunión en que se decidió.</p>
      <div className="rejilla-campos">
        <Campo campo={{ nombre: "id_acta", etiqueta: "Acta de la reunión (ACT)", tipo: "fk", fk: "documentos", req: true }} valor={acta} onCambio={setActa} contexto={{}} />
        <Campo campo={{ nombre: "obs", etiqueta: "Observación (obligatoria si se niega)", tipo: "textarea" }} valor={obs} onCambio={(v) => setObs(v || "")} contexto={{}} />
      </div>
      <div className="acciones">
        <button className="btn btn-primario" onClick={decidir("aprobar")} disabled={!acta}>Aprobar</button>
        <button className="btn btn-peligro" onClick={decidir("negar")} disabled={!acta}>Negar</button>
      </div>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
    </div>
  );
}
