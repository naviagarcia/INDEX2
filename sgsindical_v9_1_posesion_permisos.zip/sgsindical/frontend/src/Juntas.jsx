import { useEffect, useState } from "react";
import { api } from "./api.js";
import { Aviso, Cargando, formatear, SelectorFK } from "./ui.jsx";

const hoy = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const TIPO = { ELECCION: "Elección", REELECCION: "Reelección", ROTACION: "Rotación" };

function TablaJunta({ filas, conRegistro }) {
  return (
    <div className="tabla-marco">
      <table className="tabla">
        <thead><tr><th>Cargo</th><th>Directivo</th><th>Identificación</th><th>Nombramiento</th><th>Posesión</th><th>Fin del periodo</th><th>Retiro</th>{conRegistro && <th>Registro</th>}</tr></thead>
        <tbody>
          {filas.map((f, i) => (
            <tr key={i} className={f.directivo ? "" : "fila-media"}>
              <td>{f.cargo}</td>
              <td>{f.directivo || <span className="tenue">Vacante</span>}</td>
              <td>{f.identificacion || "—"}</td>
              <td>{TIPO[f.tipo_nombramiento] || "—"}</td>
              <td>{formatear(f.fecha_posesion, "date")}</td>
              <td>{formatear(f.fin_periodo, "date")}</td>
              <td>{formatear(f.fecha_retiro, "date")}</td>
              {conRegistro && <td>{f.registro || "—"}</td>}
            </tr>
          ))}
          {filas.length === 0 && <tr><td colSpan={8} className="vacio">Sin directivos.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}

export function JuntasHistoria() {
  const [estamento, setEstamento] = useState(null);
  const [fecha, setFecha] = useState(hoy());
  const [datos, setDatos] = useState(null);
  const [registro, setRegistro] = useState(null);
  const [porRegistro, setPorRegistro] = useState(null);
  const [error, setError] = useState("");
  const [cargando, setCargando] = useState(false);

  useEffect(() => {
    if (!estamento || !fecha) { setDatos(null); return; }
    setCargando(true); setError("");
    api.get(`/api/juntas/${estamento}/composicion`, { fecha }).then(setDatos).catch((e) => setError(e.message)).finally(() => setCargando(false));
  }, [estamento, fecha]);

  useEffect(() => {
    if (!registro) { setPorRegistro(null); return; }
    api.get(`/api/juntas/registro/${registro}`).then(setPorRegistro).catch((e) => setError(e.message));
  }, [registro]);

  const ocupados = datos ? datos.filas.filter((f) => f.directivo).length : 0;

  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <h1>Juntas en el tiempo</h1>
          <p className="tenue">Quiénes integraban una junta directiva en cualquier fecha, o según cada registro del inspector de trabajo.</p>
        </div>
      </header>
      <Aviso tipo="error" onCerrar={() => setError("")}>{error}</Aviso>
      <div className="rejilla-campos" style={{ maxWidth: 720, marginBottom: 16 }}>
        <div className="campo"><label htmlFor="j_est">Junta (Nacional, subdirectiva o comité)</label>
          <SelectorFK id="j_est" recurso="estamentos" valor={estamento} requerido onCambio={(v) => { setEstamento(v); setRegistro(null); }} /></div>
        <div className="campo"><label htmlFor="j_fecha">Fecha</label>
          <input id="j_fecha" type="date" value={fecha} max={hoy()} onChange={(e) => setFecha(e.target.value)} /></div>
      </div>
      {cargando && <Cargando />}
      {datos && (
        <>
          <h3>{datos.estamento} el {formatear(datos.fecha, "date")} · {ocupados} de {datos.filas.length} cargos ocupados</h3>
          <TablaJunta filas={datos.filas} conRegistro />
          {datos.registros.length > 0 && (
            <>
              <h3 style={{ marginTop: 24 }}>Registros ante el inspector de esta junta</h3>
              <div className="acciones" style={{ marginBottom: 12 }}>
                {datos.registros.map((r) => (
                  <button key={r.id_registro} className={`btn btn-sm ${registro === r.id_registro ? "btn-primario" : ""}`} onClick={() => setRegistro(r.id_registro)}>
                    {r.num_registro_inspector} · {formatear(r.fecha, "date")}
                  </button>
                ))}
              </div>
              {porRegistro && (
                <>
                  <p className="tenue">Registro {porRegistro.num_registro_inspector} del {formatear(porRegistro.fecha, "date")}, otorgado por {porRegistro.inspector}. Directivos que figuraron en él:</p>
                  <TablaJunta filas={porRegistro.filas} />
                </>
              )}
            </>
          )}
        </>
      )}
      {!estamento && <p className="tenue">Seleccione una junta para empezar.</p>}
    </section>
  );
}
