// PQRSD recibidas por el sindicato: bandeja, registro, ficha con plazos, acciones e historia.
import { useCallback, useEffect, useState } from "react";
import { api } from "./api.js";
import { Aviso, Cargando, formatear, Modal, SelectorFK } from "./ui.jsx";

const ESTADO = {
  RADICADA: ["Radicada", "baja"], EN_TRAMITE: ["En trámite", "baja"], EN_REQUERIMIENTO: ["Esperando al peticionario", "media"],
  RESPONDIDA: ["Respondida", "normal"], TRASLADADA: ["Trasladada", "normal"], DESISTIDA: ["Desistida", "normal"],
  ARCHIVADA_ANONIMA: ["Anónima · archivada", "normal"],
};
const ALERTA = { VENCIDA: ["Vencida", "critica"], VENCE_HOY: ["Vence hoy", "critica"], ALTA: ["80 % del plazo", "alta"], MEDIA: ["Mitad del plazo", "media"],
  COMPLETAR_VENCIDO: ["No completó: desistimiento", "alta"] };
const ACTUACION = {
  RADICACION: "Radicación", ARCHIVO_ANONIMA: "Archivo (anónima)", EN_TRAMITE: "En trámite", PRORROGA: "Prórroga",
  REQUERIMIENTO: "Se pidió completar", PRORROGA_COMPLETAR: "Más tiempo para completar", COMPLETADA: "Información completada",
  DESISTIMIENTO: "Desistimiento", TRASLADO_INTERNO: "Traslado a otra junta", TRASLADO_EXTERNO: "Traslado a entidad externa",
  CONCEPTO_JURIDICO: "Concepto jurídico", RESPUESTA: "Respuesta firmada", CORREO_ENVIADO: "Correo enviado",
  ACLARACION: "Se pidió aclarar", RECURSO: "Recurso de reposición", DECISION_RECURSO: "Decisión del recurso",
  CORREO_NO_ENVIADO: "Correo NO enviado", NOTA: "Nota",
};

export function EstadoPqrsd({ e }) {
  const [t, c] = ESTADO[e] || [e, "normal"];
  return <span className={`insignia insignia-${c}`}>{t}</span>;
}
function AlertaPqrsd({ n }) {
  if (!n) return <span className="tenue pequeno">En término</span>;
  const [t, c] = ALERTA[n];
  return <span className={`insignia insignia-${c}`}>{t}</span>;
}
const ahoraLocal = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16);
const avisoCorreo = (c) => (!c ? "" : c.enviado ? " Se le avisó al peticionario por correo." : c.aviso ? ` ${c.aviso}` : "");

// ------------------------------------------------------------------ bandeja
export function PqrsdPagina({ permisos, ir }) {
  const [datos, setDatos] = useState(null);
  const [filtro, setFiltro] = useState({ abiertas: true, texto: "", alerta: "", tipo: "" });
  const [tipos, setTipos] = useState([]);
  const [nueva, setNueva] = useState(false);
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });

  const cargar = useCallback(() => {
    api.get("/api/pqrsd", { abiertas: filtro.abiertas || undefined, texto: filtro.texto, alerta: filtro.alerta, tipo: filtro.tipo })
      .then(setDatos).catch((e) => setMsg({ tipo: "error", texto: e.message }));
  }, [filtro]);
  useEffect(() => { const t = setTimeout(cargar, 250); return () => clearTimeout(t); }, [cargar]);
  useEffect(() => { api.get("/api/pqrsd/tipos").then(setTipos).catch(() => {}); }, []);

  const r = datos?.resumen;
  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <h1>PQRSD recibidas</h1>
          <p className="tenue">Peticiones, quejas, reclamos, sugerencias, denuncias, consultas y solicitudes de documentos que llegan al correo
            institucional. Los plazos son en días hábiles; lo recibido desde las 5 p. m. cuenta desde el día hábil siguiente.</p>
        </div>
        <div className="acciones">
          {permisos.DOCUMENTAL?.registrar && <button className="btn btn-primario" onClick={() => setNueva(true)}>Registrar PQRSD</button>}
        </div>
      </header>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      {r && (
        <div className="kpis kpis-pqrsd">
          <button className="kpi" onClick={() => setFiltro({ ...filtro, abiertas: true, alerta: "" })}><span>{r.abiertas}</span>Abiertas</button>
          <button className="kpi kpi-critica" onClick={() => setFiltro({ ...filtro, abiertas: true, alerta: "VENCIDA" })}><span>{r.vencidas}</span>Vencidas o vencen hoy</button>
          <button className="kpi kpi-alta" onClick={() => setFiltro({ ...filtro, abiertas: true, alerta: "ALTA" })}><span>{r.alta}</span>Al 80 % del plazo</button>
          <button className="kpi kpi-media" onClick={() => setFiltro({ ...filtro, abiertas: true, alerta: "MEDIA" })}><span>{r.media}</span>A mitad del plazo</button>
          <div className="kpi"><span>{r.suspendidas}</span>Esperando al peticionario</div>
        </div>
      )}
      <div className="barra-filtros">
        <input placeholder="Buscar por radicado, asunto o peticionario…" value={filtro.texto} onChange={(e) => setFiltro({ ...filtro, texto: e.target.value })} />
        <select value={filtro.tipo} onChange={(e) => setFiltro({ ...filtro, tipo: e.target.value })} aria-label="Tipo">
          <option value="">Todos los tipos</option>
          {tipos.map((t) => <option key={t.codigo} value={t.codigo}>{t.nombre}</option>)}
        </select>
        <select value={filtro.alerta} onChange={(e) => setFiltro({ ...filtro, alerta: e.target.value })} aria-label="Alerta">
          <option value="">Todas las alertas</option><option value="VENCIDA">Vencidas o vencen hoy</option><option value="COMPLETAR_VENCIDO">No completó a tiempo</option><option value="ALTA">80 % del plazo</option><option value="MEDIA">Mitad del plazo</option>
        </select>
        <label className="interruptor"><input type="checkbox" checked={filtro.abiertas} onChange={(e) => setFiltro({ ...filtro, abiertas: e.target.checked })} /><span>Solo abiertas</span></label>
      </div>
      {!datos ? <Cargando /> : (
        <div className="tabla-marco">
          <table className="tabla">
            <thead><tr><th>Radicado</th><th>Tipo</th><th>Peticionario</th><th>Asunto</th><th>Recibida</th><th>Vence</th><th className="numero">Días hábiles</th><th>Estado</th></tr></thead>
            <tbody>
              {datos.filas.map((f) => (
                <tr key={f.id_pqrsd} className="clicable" onClick={() => ir(`/pqrsd/${f.id_pqrsd}`)}>
                  <td className="sin-corte"><strong>{f.radicado}</strong></td><td>{f.tipo}</td><td>{f.peticionario}</td>
                  <td>{f.asunto}<div className="tenue pequeno">{f.junta}</div></td>
                  <td>{formatear(f.recibida, "datetime")}</td><td className="sin-corte">{formatear(f.fecha_limite, "date")}</td>
                  <td className="numero">{f.dias_habiles_restantes ?? "—"}</td>
                  <td><div className="pila"><EstadoPqrsd e={f.estado} />{f.nivel_alerta && <AlertaPqrsd n={f.nivel_alerta} />}</div></td>
                </tr>
              ))}
              {datos.filas.length === 0 && <tr><td colSpan={8} className="vacio">No hay PQRSD con estos filtros.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
      {nueva && <RegistrarPqrsd tipos={tipos} onCerrar={() => setNueva(false)}
        onListo={(x) => { setNueva(false); setMsg({ tipo: "exito", texto: `${x.radicado} registrada.${x.aviso ? " " + x.aviso : ` Vence el ${formatear(x.fecha_limite, "date")}.`}${avisoCorreo(x.correo)}` }); cargar(); }} />}
    </section>
  );
}

// ------------------------------------------------------------------ registro
function RegistrarPqrsd({ tipos, onCerrar, onListo }) {
  const [d, setD] = useState({ tipo: "PETICION", id_estamento: null, anonima: false, nombre_peticionario: "", tipo_documento: "CC", numero_documento: "",
    correo_peticionario: "", telefono_peticionario: "", id_persona: null, asunto: "", descripcion: "", fecha_recepcion: ahoraLocal(),
    motivo_registro_tardio: "", id_documento_soporte: null });
  const [plazo, setPlazo] = useState(null);
  const [error, setError] = useState("");
  const [enviando, setEnviando] = useState(false);
  const cambiar = (k) => (e) => setD({ ...d, [k]: e?.target ? (e.target.type === "checkbox" ? e.target.checked : e.target.value) : e });
  const recepcionIso = d.fecha_recepcion ? new Date(d.fecha_recepcion).toISOString() : null;
  useEffect(() => {
    if (!d.tipo || !recepcionIso) return;
    api.get("/api/pqrsd/simular", { tipo: d.tipo, recepcion: recepcionIso }).then(setPlazo).catch(() => setPlazo(null));
  }, [d.tipo, recepcionIso]);
  const tipo = tipos.find((t) => t.codigo === d.tipo);
  const enviar = async (e) => {
    e.preventDefault(); setEnviando(true); setError("");
    try { onListo(await api.post("/api/pqrsd", { ...d, fecha_recepcion: recepcionIso })); }
    catch (x) { setError(x.message); } finally { setEnviando(false); }
  };
  return (
    <Modal titulo="Registrar PQRSD recibida por correo" onCerrar={onCerrar} ancho={780}
      pie={<><span className="espacio" /><button className="btn" onClick={onCerrar}>Cancelar</button>
        <button className="btn btn-primario" form="form-pqrsd" disabled={enviando}>{enviando ? "Registrando…" : "Registrar y enviar acuse"}</button></>}>
      <form id="form-pqrsd" onSubmit={enviar}>
        <Aviso tipo="error">{error}</Aviso>
        <div className="rejilla-campos">
          <div className="campo"><label htmlFor="pq-tipo">Tipo <span className="req">*</span></label>
            <select id="pq-tipo" value={d.tipo} onChange={cambiar("tipo")}>{tipos.map((t) => <option key={t.codigo} value={t.codigo}>{t.nombre} ({t.dias_habiles} días hábiles)</option>)}</select>
            {tipo?.revision_juridica && <span className="ayuda">Requiere concepto jurídico antes de responder.</span>}</div>
          <div className="campo"><label htmlFor="pq-junta">Junta que la recibe <span className="req">*</span></label>
            <SelectorFK id="pq-junta" recurso="estamentos" valor={d.id_estamento} onCambio={cambiar("id_estamento")} requerido /></div>
          <div className="campo"><label htmlFor="pq-fecha">Fecha y hora en que llegó el correo <span className="req">*</span></label>
            <input id="pq-fecha" type="datetime-local" value={d.fecha_recepcion} max={ahoraLocal()} onChange={cambiar("fecha_recepcion")} required />
            {plazo && <span className="ayuda">Cuenta desde el {formatear(plazo.fecha_base, "date")}: vence el <strong>{formatear(plazo.fecha_limite, "date")}</strong>.</span>}</div>
          <div className="campo"><label className="interruptor"><input type="checkbox" checked={d.anonima} onChange={cambiar("anonima")} />
            <span>Llegó sin identificar (anónima): se archiva sin trámite</span></label></div>
          {!d.anonima && <>
            <div className="campo"><label htmlFor="pq-nom">Nombre del peticionario <span className="req">*</span></label><input id="pq-nom" value={d.nombre_peticionario} onChange={cambiar("nombre_peticionario")} required /></div>
            <div className="campo"><label htmlFor="pq-doc">Documento <span className="req">*</span></label>
              <div className="fila-doc"><select value={d.tipo_documento} onChange={cambiar("tipo_documento")} aria-label="Tipo de documento">{["CC", "CE", "TI", "PAS", "NIT"].map((x) => <option key={x}>{x}</option>)}</select>
                <input id="pq-doc" value={d.numero_documento} onChange={cambiar("numero_documento")} required /></div></div>
            <div className="campo"><label htmlFor="pq-cor">Correo del peticionario <span className="req">*</span></label><input id="pq-cor" type="email" value={d.correo_peticionario} onChange={cambiar("correo_peticionario")} required />
              <span className="ayuda">Allí le llegan el acuse, los avisos y la respuesta.</span></div>
            <div className="campo"><label htmlFor="pq-tel">Teléfono</label><input id="pq-tel" value={d.telefono_peticionario} onChange={cambiar("telefono_peticionario")} /></div>
            <div className="campo"><label htmlFor="pq-per">Persona registrada (si es afiliado)</label><SelectorFK id="pq-per" recurso="personas" valor={d.id_persona} onCambio={cambiar("id_persona")} /></div>
          </>}
          <div className="campo campo-ancho"><label htmlFor="pq-asu">Asunto <span className="req">*</span></label><input id="pq-asu" value={d.asunto} onChange={cambiar("asunto")} maxLength={200} required /></div>
          <div className="campo campo-ancho"><label htmlFor="pq-des">Contenido de la solicitud <span className="req">*</span></label>
            <textarea id="pq-des" rows={5} value={d.descripcion} onChange={cambiar("descripcion")} required /><span className="ayuda">Copie el texto del correo.</span></div>
          <div className="campo"><label htmlFor="pq-sop">Correo o escaneo radicado (soporte)</label><SelectorFK id="pq-sop" recurso="documentos" valor={d.id_documento_soporte} onCambio={cambiar("id_documento_soporte")} /></div>
          <div className="campo"><label htmlFor="pq-tar">Motivo del registro tardío</label><input id="pq-tar" value={d.motivo_registro_tardio} onChange={cambiar("motivo_registro_tardio")} />
            <span className="ayuda">Solo si el correo llegó hace más de 2 días hábiles. El plazo corre desde que llegó.</span></div>
        </div>
      </form>
    </Modal>
  );
}

// ------------------------------------------------------------------ ficha
const DIALOGOS = {
  prorrogar: { titulo: "Prorrogar el plazo", boton: "Prorrogar y avisar", url: "prorrogar",
    ayuda: "Se informa al peticionario antes del vencimiento. El plazo total no puede pasar del doble del inicial.",
    campos: [["dias", "Días hábiles de prórroga", "number"], ["motivo", "Motivo (se le informa al peticionario)", "textarea"]] },
  pedir_completar: { titulo: "Pedir que complete la solicitud", boton: "Enviar requerimiento", url: "pedir-completar",
    ayuda: "El plazo para responder se suspende. El peticionario tiene un mes (prorrogable otro) o se entiende que desistió.",
    campos: [["texto", "Qué información o documentos faltan", "textarea"]] },
  pedir_aclaracion: { titulo: "Pedir que aclare la petición", boton: "Enviar y suspender", url: "pedir-aclaracion",
    ayuda: "Cuando no se entiende qué pide (Ley 1755, art. 19). Tiene 10 días hábiles para aclarar; el plazo se suspende y, al aclarar, se reanuda con los días que quedaban. Si no aclara, se archiva.",
    campos: [["texto", "Qué debe aclarar", "textarea"]] },
  recurso: { titulo: "Registrar el recurso de reposición", boton: "Registrar recurso", url: "recurso",
    ayuda: "Contra el desistimiento procede el recurso de reposición, dentro de los 10 días hábiles siguientes a su notificación.",
    campos: [["recibido_en", "Fecha y hora en que llegó", "datetime-local"], ["texto", "Argumentos del peticionario", "textarea"]] },
  decidir_recurso: { titulo: "Decidir el recurso de reposición", boton: "Decidir y avisar", url: "decidir-recurso",
    ayuda: "Se decide dentro de los 15 días hábiles siguientes a su recibo (reglamento de PQRSD). Si se revoca el desistimiento, el trámite sigue con los días hábiles que quedaban.",
    campos: [["decision", "Decisión", "decision"], ["motivo", "Decisión motivada", "textarea"]] },
  ampliar_completar: { titulo: "Dar un mes más para completar", boton: "Ampliar", url: "ampliar-completar",
    ayuda: "Solo una vez y solo si el peticionario lo pide antes del vencimiento.", campos: [["motivo", "Cómo y cuándo lo pidió", "textarea"]] },
  completada: { titulo: "Registrar la información recibida", boton: "Reanudar el plazo", url: "completada",
    ayuda: "El plazo se reanuda con los días hábiles que quedaban, desde el día siguiente al recibo.",
    campos: [["recibida_en", "Fecha y hora en que llegó", "datetime-local"], ["detalle", "Qué aportó el peticionario", "textarea"]] },
  desistimiento: { titulo: "Declarar el desistimiento tácito", boton: "Declarar y avisar", url: "desistimiento", peligro: true,
    ayuda: "El peticionario no completó a tiempo. Se archiva y puede presentarla de nuevo.", campos: [["motivo", "Decisión motivada", "textarea"]] },
  trasladar: { titulo: "Trasladar por competencia", boton: "Trasladar y avisar", url: "trasladar",
    ayuda: "Dentro de los 5 días hábiles siguientes al recibo. A otra junta: el plazo empieza de nuevo. A una entidad: el trámite termina aquí.",
    campos: [["destino", "", "destino"], ["motivo", "Por qué no es competente esta junta", "textarea"]] },
  concepto: { titulo: "Concepto jurídico", boton: "Registrar concepto", url: "concepto",
    ayuda: "Obligatorio para las denuncias antes de responder.", campos: [["concepto", "Concepto", "textarea"]] },
  responder: { titulo: "Responder y firmar", boton: "Firmar y enviar", url: "responder",
    ayuda: "La respuesta de fondo sale firmada con su cargo, en PDF y por correo al peticionario. Después no se modifica.",
    campos: [["respuesta", "Respuesta al peticionario", "textarea-grande"], ["id_documento", "Documento adjunto ya radicado (opcional)", "fk-documentos"]] },
  nota: { titulo: "Nota interna", boton: "Guardar nota", url: "nota", ayuda: "Queda en la historia; no se envía al peticionario.",
    campos: [["nota", "Nota", "textarea"]] },
};
const ETIQUETA_ACCION = { prorrogar: "Prorrogar", pedir_completar: "Pedir completar", pedir_aclaracion: "Pedir aclaración",
  ampliar_completar: "Dar un mes más", completada: "Llegó la información", desistimiento: "Declarar desistimiento",
  recurso: "Registrar recurso", decidir_recurso: "Decidir recurso", trasladar: "Trasladar", concepto: "Concepto jurídico",
  responder: "Responder y firmar", nota: "Nota interna" };

export function PqrsdDetalle({ id }) {
  const [d, setD] = useState(null);
  const [error, setError] = useState("");
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const [dialogo, setDialogo] = useState(null);
  const cargar = useCallback(() => api.get(`/api/pqrsd/${id}`).then(setD).catch((e) => setError(e.message)), [id]);
  useEffect(() => { cargar(); }, [cargar]);
  if (!d) return <section className="pagina">{error ? <Aviso tipo="error">{error}</Aviso> : <Cargando />}</section>;
  const q = d.pqrsd, p = d.plazo, a = d.acciones;
  const pdf = async () => {
    const b = await api.descargar(`/api/pqrsd/${id}/respuesta.pdf`);
    const x = document.createElement("a"); x.href = URL.createObjectURL(b); x.download = `respuesta_${q.radicado}.pdf`; x.click();
  };
  const tramite = async () => { try { await api.post(`/api/pqrsd/${id}/tramite`); cargar(); } catch (e) { setMsg({ tipo: "error", texto: e.message }); } };
  const pct = p?.porcentaje_consumido;
  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <p className="migas"><a href="#/pqrsd">PQRSD recibidas</a> ›</p>
          <h1>{q.radicado} <EstadoPqrsd e={q.estado} /></h1>
          <p className="tenue">{q.nombre_tipo} · {q.junta}{q.junta_origen ? ` (trasladada desde ${q.junta_origen})` : ""} · recibida el {formatear(q.fecha_recepcion, "datetime")}</p>
        </div>
        <div className="acciones">
          {a.tramite && <button className="btn" onClick={tramite}>Pasar a trámite</button>}
          {Object.keys(ETIQUETA_ACCION).filter((k) => a[k] && k !== "nota").map((k) => (
            <button key={k} className={`btn ${k === "responder" ? "btn-primario" : ""} ${k === "desistimiento" ? "btn-peligro" : ""}`} onClick={() => setDialogo(k)}>
              {k === "desistimiento" && q.tipo_requerimiento === "ACLARAR" ? "Archivar (no aclaró)" : k === "completada" && q.tipo_requerimiento === "ACLARAR" ? "Llegó la aclaración" : ETIQUETA_ACCION[k]}</button>))}
          {q.estado === "RESPONDIDA" && <button className="btn" onClick={pdf}>Descargar respuesta (PDF)</button>}
        </div>
      </header>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      {q.revision_juridica && !q.concepto_juridico && ["RADICADA", "EN_TRAMITE"].includes(q.estado) &&
        <Aviso tipo="advertencia">Esta {q.nombre_tipo.toLowerCase()} necesita el concepto jurídico (abogado o Secretario Jurídico) antes de responderla.</Aviso>}
      <div className="pqrsd-rejilla">
        <section className="tarjeta pqrsd-plazo">
          <h3>Plazo</h3>
          <p className="pqrsd-vence">{["RADICADA", "EN_TRAMITE", "EN_REQUERIMIENTO"].includes(q.estado) ? "Vence el" : "Venció / vencía el"} <strong>{formatear(q.fecha_limite, "date")}</strong></p>
          {pct !== null && pct !== undefined && <>
            <div className="barra" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label="Plazo consumido">
              <span className={`seg-${["VENCIDA", "VENCE_HOY"].includes(p.nivel_alerta) ? "critica" : p.nivel_alerta === "ALTA" ? "alta" : p.nivel_alerta === "MEDIA" ? "media" : "baja"}`} style={{ width: `${pct}%` }} />
            </div>
            <p className="pequeno">{pct} % consumido · {p.dias_habiles_restantes ?? 0} día(s) hábil(es) restantes</p></>}
          <p className="pequeno"><strong>{p?.diagnostico}</strong></p>
          <dl className="datos-lista">
            <dt>Plazo inicial</dt><dd>{q.plazo_dias} días hábiles, desde el {formatear(q.fecha_base, "date")}</dd>
            {q.dias_prorroga > 0 && <><dt>Prórroga</dt><dd>{q.dias_prorroga} días hábiles · {q.motivo_prorroga}</dd></>}
            {q.fecha_requerimiento && <><dt>{q.tipo_requerimiento === "ACLARAR" ? "Aclaración" : "Requerimiento"}</dt><dd>{formatear(q.fecha_requerimiento, "date")} · {q.fecha_completada ? `completada el ${formatear(q.fecha_completada, "datetime")}` : `tiene hasta el ${formatear(q.fecha_limite_completar, "date")}${q.prorroga_completar ? " (ampliado)" : ""}`}<br />{q.texto_requerimiento}</dd></>}
            {q.traslado_tardio && <><dt>Traslado</dt><dd className="texto-alerta">Se hizo después de los 5 días hábiles</dd></>}
          </dl>
        </section>
        <section className="tarjeta">
          <h3>Peticionario</h3>
          {q.anonima ? <p>Anónima. {q.observacion_cierre}</p> : (
            <dl className="datos-lista">
              <dt>Nombre</dt><dd>{q.nombre_peticionario}</dd>
              <dt>Documento</dt><dd>{q.tipo_documento} {q.numero_documento}</dd>
              <dt>Correo</dt><dd>{q.correo_peticionario}</dd>
              <dt>Teléfono</dt><dd>{q.telefono_peticionario || "—"}</dd>
            </dl>)}
        </section>
        <section className="tarjeta pqrsd-ancha">
          <h3>Solicitud</h3>
          <p><strong>{q.asunto}</strong></p>
          <p className="texto-largo">{q.descripcion}</p>
        </section>
        {q.concepto_juridico && <section className="tarjeta pqrsd-ancha"><h3>Concepto jurídico</h3>
          <p className="texto-largo">{q.concepto_juridico}</p><p className="tenue pequeno">{q.usuario_concepto} · {formatear(q.fecha_concepto, "datetime")}</p></section>}
        {q.respuesta && <section className="tarjeta pqrsd-ancha"><h3>Respuesta</h3>
          <p className="texto-largo">{q.respuesta}</p>
          <p className="tenue pequeno">Firmada por {q.usuario_respuesta} ({q.cargo_firma}) el {formatear(q.fecha_respuesta, "datetime")} · huella {q.huella_respuesta?.slice(0, 16)}…</p></section>}
        {["TRASLADADA", "DESISTIDA"].includes(q.estado) && <section className="tarjeta pqrsd-ancha"><h3>{q.estado === "TRASLADADA" ? `Trasladada a ${q.entidad_traslado}` : q.tipo_requerimiento === "ACLARAR" ? "Archivada por falta de aclaración" : "Desistimiento tácito"}</h3>
          <p className="texto-largo">{q.observacion_cierre}</p><p className="tenue pequeno">{q.usuario_respuesta} · {q.cargo_firma} · {formatear(q.fecha_cierre, "datetime")}</p>
          {q.estado === "DESISTIDA" && q.tipo_requerimiento === "COMPLETAR" && !q.fecha_recurso && q.limite_recurso &&
            <p className="pequeno">Recurso de reposición: hasta el {formatear(q.limite_recurso, "date")}.</p>}</section>}
        {q.fecha_recurso && <section className="tarjeta pqrsd-ancha"><h3>Recurso de reposición</h3>
          <p className="texto-largo">{q.texto_recurso}</p><p className="tenue pequeno">Recibido el {formatear(q.fecha_recurso, "datetime")}</p>
          {q.decision_recurso ? <p><strong>{q.decision_recurso === "REVOCA" ? "Se revocó el desistimiento" : "Se confirmó el desistimiento"}:</strong> {q.motivo_decision_recurso}
            <span className="tenue pequeno"> · {q.usuario_decision_recurso} · {formatear(q.fecha_decision_recurso, "datetime")}</span></p>
            : <p className="texto-alerta">Pendiente de decidir.</p>}</section>}
        <section className="tarjeta pqrsd-ancha">
          <div className="tarjeta-cab"><h3>Historia</h3>{a.nota && <button className="btn btn-sm" onClick={() => setDialogo("nota")}>Agregar nota</button>}</div>
          <ol className="historia">
            {d.historia.map((h, i) => (
              <li key={i} className={`historia-${h.tipo === "CORREO_NO_ENVIADO" ? "alerta" : h.tipo.startsWith("CORREO") ? "correo" : "evento"}`}>
                <div><strong>{ACTUACION[h.tipo] || h.tipo}</strong><span className="tenue pequeno"> · {formatear(h.fecha, "datetime")} · {h.usuario}</span></div>
                <p>{h.detalle}</p>
              </li>))}
          </ol>
        </section>
      </div>
      {dialogo && <DialogoAccion clave={dialogo} q={q} onCerrar={() => setDialogo(null)}
        onListo={(r) => { setDialogo(null); setMsg({ tipo: "exito", texto: `${DIALOGOS[dialogo].titulo}: listo.${avisoCorreo(r.correo)}` }); cargar(); }} />}
    </section>
  );
}

function DialogoAccion({ clave, q, onCerrar, onListo }) {
  const def = DIALOGOS[clave];
  const [v, setV] = useState(clave === "prorrogar" ? { dias: q.plazo_dias } : clave === "completada" ? { recibida_en: ahoraLocal() }
    : clave === "recurso" ? { recibido_en: ahoraLocal() } : clave === "decidir_recurso" ? { decision: "CONFIRMA" } : {});
  const [destino, setDestino] = useState("junta");
  const [error, setError] = useState("");
  const [enviando, setEnviando] = useState(false);
  const enviar = async (e) => {
    e.preventDefault(); setEnviando(true); setError("");
    const cuerpo = { ...v };
    if (cuerpo.recibida_en) cuerpo.recibida_en = new Date(cuerpo.recibida_en).toISOString();
    if (cuerpo.recibido_en) cuerpo.recibido_en = new Date(cuerpo.recibido_en).toISOString();
    if (clave === "prorrogar") cuerpo.dias = Number(cuerpo.dias);
    if (clave === "trasladar") { if (destino === "junta") { delete cuerpo.entidad; delete cuerpo.correo_entidad; } else delete cuerpo.id_estamento; }
    try { onListo(await api.post(`/api/pqrsd/${q.id_pqrsd}/${def.url}`, cuerpo)); }
    catch (x) { setError(x.message); } finally { setEnviando(false); }
  };
  return (
    <Modal titulo={`${def.titulo} — ${q.radicado}`} onCerrar={onCerrar} ancho={clave === "responder" ? 760 : 560}
      pie={<><span className="espacio" /><button className="btn" onClick={onCerrar}>Cancelar</button>
        <button className={`btn ${def.peligro ? "btn-peligro" : "btn-primario"}`} form="form-accion" disabled={enviando}>{enviando ? "Enviando…" : def.boton}</button></>}>
      <form id="form-accion" onSubmit={enviar}>
        <p className="tenue pequeno">{def.ayuda}</p>
        <Aviso tipo="error">{error}</Aviso>
        {def.campos.map(([k, etiqueta, tipo]) => {
          if (tipo === "destino") return (
            <div key={k} className="campo">
              <div className="acciones" role="radiogroup" aria-label="Destino">
                <label className="interruptor"><input type="radio" checked={destino === "junta"} onChange={() => setDestino("junta")} /><span>Otra junta del sindicato</span></label>
                <label className="interruptor"><input type="radio" checked={destino === "entidad"} onChange={() => setDestino("entidad")} /><span>Entidad externa</span></label>
              </div>
              {destino === "junta" ? <SelectorFK recurso="estamentos" valor={v.id_estamento ?? null} onCambio={(x) => setV({ ...v, id_estamento: x })} requerido />
                : <div className="rejilla-campos">
                  <div className="campo"><label htmlFor="tr-ent">Entidad</label><input id="tr-ent" value={v.entidad || ""} onChange={(e) => setV({ ...v, entidad: e.target.value })} required /></div>
                  <div className="campo"><label htmlFor="tr-cor">Correo de la entidad (recibe copia)</label><input id="tr-cor" type="email" value={v.correo_entidad || ""} onChange={(e) => setV({ ...v, correo_entidad: e.target.value })} /></div>
                </div>}
            </div>);
          if (tipo === "decision") return (
            <div key={k} className="campo" role="radiogroup" aria-label={etiqueta}>
              <label className="interruptor"><input type="radio" checked={v.decision === "CONFIRMA"} onChange={() => setV({ ...v, decision: "CONFIRMA" })} /><span>Confirmar el desistimiento</span></label>
              <label className="interruptor"><input type="radio" checked={v.decision === "REVOCA"} onChange={() => setV({ ...v, decision: "REVOCA" })} /><span>Revocarlo y seguir el trámite</span></label>
            </div>);
          if (tipo === "fk-documentos") return (
            <div key={k} className="campo"><label>{etiqueta}</label><SelectorFK recurso="documentos" valor={v[k] ?? null} onCambio={(x) => setV({ ...v, [k]: x })} /></div>);
          return (
            <div key={k} className="campo"><label htmlFor={`ac-${k}`}>{etiqueta}</label>
              {tipo.startsWith("textarea") ? <textarea id={`ac-${k}`} rows={tipo === "textarea-grande" ? 12 : 4} value={v[k] || ""} onChange={(e) => setV({ ...v, [k]: e.target.value })} required />
                : <input id={`ac-${k}`} type={tipo} min={tipo === "number" ? 1 : undefined} max={tipo === "number" ? q.plazo_dias : undefined}
                    value={v[k] ?? ""} onChange={(e) => setV({ ...v, [k]: e.target.value })} required />}
            </div>);
        })}
      </form>
    </Modal>
  );
}
