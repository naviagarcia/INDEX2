import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "./api.js";
import { Aviso, Cargando, cargarEtiquetas, formatear, Modal, SelectorFK } from "./ui.jsx";

const ESTADO = {
  BORRADOR: ["Borrador sin texto", "normal"], EN_REVISION: ["En revisión", "baja"], CAMBIOS_SOLICITADOS: ["Cambios solicitados", "media"],
  APROBADO: ["Aprobado · por radicar", "alta"], RADICADO: ["Radicado", "normal"], DESCARTADO: ["Descartado", "critica"],
};
const ROL = { ABOGADO: "Abogado", PRESIDENCIA: "Presidencia", SECRETARIA: "Secretaría General", COMENTARIO: "Comentario" };
const CLASE = { TEXTO: "Texto", PDF: "PDF", WORD: "Word", AUDIO: "Audio", VIDEO: "Video" };
const ACEPTA = ".txt,.md,.pdf,.docx,.mp3,.wav,.m4a,.ogg,.opus,.flac,.aac,.amr,.mp4,.mov,.avi,.mkv,.webm,.3gp";

function Estado({ e }) {
  const [t, c] = ESTADO[e] || [e, "normal"];
  return <span className={`insignia insignia-${c}`}>{t}</span>;
}
async function descargar(ruta, nombre) {
  const b = await api.descargar(ruta);
  const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = nombre; a.click();
}

// ------------------------------------------------------------------ listado
export function EscritosPagina({ permisos, ir }) {
  const [filas, setFilas] = useState(null);
  const [et, setEt] = useState({});
  const [nuevo, setNuevo] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => {
    api.get("/api/r/escritos", { tam: 100 }).then(async (r) => {
      const [a, b] = await Promise.all([cargarEtiquetas("estamentos", r.filas.map((f) => f.id_estamento)),
        cargarEtiquetas("tipos_escrito", r.filas.map((f) => f.codigo_tipo))]);
      setEt({ junta: a, tipo: b }); setFilas(r.filas);
    }).catch((e) => setError(e.message));
  }, []);
  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <h1>Escritos jurídicos</h1>
          <p className="tenue">Derechos de petición, quejas, denuncias públicas, tutelas, recursos y quejas por acoso laboral, redactados con IA a partir de
            documentos, audios o videos. Todo proyecto se revisa: lo aprueban el abogado, la Presidencia y la Secretaría General antes de radicarlo.</p>
        </div>
        <div className="acciones">{permisos.DOCUMENTAL?.registrar && <button className="btn btn-primario" onClick={() => setNuevo(true)}>Nuevo escrito</button>}</div>
      </header>
      <Aviso tipo="error">{error}</Aviso>
      {!filas ? <Cargando /> : (
        <div className="tabla-marco"><table className="tabla">
          <thead><tr><th>Fecha</th><th>Tipo</th><th>Asunto</th><th>Junta</th><th>Versión</th><th>Estado</th></tr></thead>
          <tbody>
            {filas.map((f) => (
              <tr key={f.id_escrito} className="clicable" onClick={() => ir(`/escrito/${f.id_escrito}`)}>
                <td>{formatear(f.fecha_creacion, "date")}</td><td>{et.tipo[f.codigo_tipo]}</td><td>{f.titulo}</td>
                <td>{et.junta[String(f.id_estamento)]}</td><td>{f.version_actual || "—"}</td><td><Estado e={f.estado} /></td>
              </tr>
            ))}
            {filas.length === 0 && <tr><td colSpan={6} className="vacio">Aún no hay escritos.</td></tr>}
          </tbody>
        </table></div>
      )}
      {nuevo && <NuevoEscrito onCerrar={() => setNuevo(false)} onListo={(id) => ir(`/escrito/${id}`)} />}
    </section>
  );
}

function NuevoEscrito({ onCerrar, onListo }) {
  const [f, setF] = useState({});
  const [tipos, setTipos] = useState([]);
  const [error, setError] = useState("");
  useEffect(() => { api.get("/api/opciones/tipos_escrito").then(setTipos).catch(() => {}); }, []);
  const c = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const enviar = async (e) => {
    e.preventDefault(); setError("");
    try { onListo((await api.post("/api/r/escritos", f)).id_escrito); } catch (e2) { setError(e2.message); }
  };
  return (
    <Modal titulo="Nuevo escrito jurídico" onCerrar={onCerrar} ancho={720}
      pie={<><span className="espacio" /><button className="btn" onClick={onCerrar}>Cancelar</button><button className="btn btn-primario" form="f-esc">Crear y agregar fuentes</button></>}>
      <form id="f-esc" onSubmit={enviar}>
        <Aviso tipo="error">{error}</Aviso>
        <div className="rejilla-campos">
          <div className="campo"><label htmlFor="e-t">Tipo de escrito</label>
            <select id="e-t" required value={f.codigo_tipo || ""} onChange={c("codigo_tipo")}>
              <option value="">Seleccione…</option>{tipos.map((t) => <option key={t.valor} value={t.valor}>{t.etiqueta}</option>)}</select></div>
          <div className="campo"><label htmlFor="e-j">Junta que lo presenta</label>
            <SelectorFK id="e-j" recurso="estamentos" requerido valor={f.id_estamento} onCambio={(v) => setF({ ...f, id_estamento: v })} /></div>
          <div className="campo campo-ancho"><label htmlFor="e-a">Asunto</label><input id="e-a" required onChange={c("titulo")} /></div>
          <div className="campo"><label htmlFor="e-dp">Destinatario (nombre y cargo)</label><input id="e-dp" onChange={c("destinatario_persona")} /></div>
          <div className="campo"><label htmlFor="e-di">Entidad destinataria</label><input id="e-di" onChange={c("destinatario_institucion")} /></div>
          <div className="campo campo-ancho"><label htmlFor="e-i">¿Qué se busca con el escrito?</label>
            <textarea id="e-i" rows={4} placeholder="Ej.: pedir copia del acto de traslado y su motivación; exigir que se respete el fuero sindical…" onChange={c("instrucciones")} />
            <small className="ayuda">La IA usa solo los hechos de las fuentes que agregue en el paso siguiente (texto, PDF, Word, audio o video).</small></div>
        </div>
      </form>
    </Modal>
  );
}

// ------------------------------------------------------------------ detalle
export function EscritoDetalle({ id, permisos }) {
  const [d, setD] = useState(null);
  const [texto, setTexto] = useState("");
  const [verVersion, setVerVersion] = useState(null);   // { numero, contenido } de una versión anterior
  const [instr, setInstr] = useState("");
  const [comentario, setComentario] = useState("");
  const [pegado, setPegado] = useState(null);
  const [modalTexto, setModalTexto] = useState(null);
  const [msg, setMsg] = useState(null);
  const [subiendo, setSubiendo] = useState(false);
  const editado = useRef(false);
  const puedeEditar = permisos.DOCUMENTAL?.actualizar;

  const cargar = useCallback(async () => {
    try {
      const r = await api.get(`/api/escritos/${id}`);
      setD(r);
      if (!editado.current) setTexto(r.escrito.contenido || "");
    } catch (e) { setMsg({ tipo: "error", texto: e.message }); }
  }, [id]);
  useEffect(() => { cargar(); }, [cargar]);
  // Mientras la IA redacta o se transcriben fuentes, se consulta cada 3 segundos
  const ocupado = d && (d.escrito.generando || d.fuentes.some((f) => ["PENDIENTE", "PROCESANDO"].includes(f.estado)));
  useEffect(() => { if (!ocupado) return undefined; const t = setInterval(cargar, 3000); return () => clearInterval(t); }, [ocupado, cargar]);

  const intentar = (fn) => async (...a) => {
    setMsg(null);
    try { await fn(...a); } catch (e) { setMsg({ tipo: "error", texto: e.message }); if (e.status === 409) { editado.current = false; cargar(); } }
  };
  if (!d) return <section className="pagina">{msg ? <Aviso tipo="error">{msg.texto}</Aviso> : <Cargando />}</section>;

  const e = d.escrito;
  const cerrado = ["RADICADO", "DESCARTADO"].includes(e.estado);
  const editable = puedeEditar && !cerrado && !e.generando;

  const subir = intentar(async (ev) => {
    const archivos = [...ev.target.files]; ev.target.value = "";
    setSubiendo(true);
    try { for (const a of archivos) await api.subir(`/api/escritos/${id}/fuentes`, a); } finally { setSubiendo(false); }
    setMsg({ tipo: "exito", texto: `${archivos.length} archivo(s) agregados. Los audios y videos se transcriben en el servidor; puede tardar unos minutos.` });
    cargar();
  });
  const generar = intentar(async () => {
    if (editado.current && !window.confirm("Tiene cambios sin guardar en el texto. ¿Descartarlos y pedir una versión nueva a la IA?")) return;
    editado.current = false;
    const r = await api.post(`/api/escritos/${id}/generar`, { instrucciones: instr });
    setInstr(""); setMsg({ tipo: "info", texto: r.mensaje }); cargar();
  });
  const guardarTexto = intentar(async () => {
    const motivo = window.prompt("¿Qué cambió? (opcional, queda en el historial)") ?? null;
    const r = await api.put(`/api/escritos/${id}/contenido`, { contenido: texto, version_base: e.version_actual, motivo });
    editado.current = false; setMsg({ tipo: "exito", texto: r.mensaje }); cargar();
  });
  const revisar = (decision) => intentar(async () => {
    if (decision !== "APRUEBA" && !comentario.trim()) { setMsg({ tipo: "advertencia", texto: "Escriba el comentario." }); return; }
    if (decision === "APRUEBA" && editado.current) { setMsg({ tipo: "advertencia", texto: "Guarde o descarte sus cambios antes de aprobar." }); return; }
    if (decision === "APRUEBA" && !window.confirm(`¿Aprobar la versión ${e.version_actual} como ${ROL[d.mi_rol]}? Verifique hechos, normas y los datos marcados con [COMPLETAR] o [VERIFICAR].`)) return;
    const r = await api.post(`/api/escritos/${id}/revisar`, { numero_version: e.version_actual, decision, comentario });
    setComentario(""); setMsg({ tipo: "exito", texto: `Registrado. Estado: ${ESTADO[r.estado]?.[0] || r.estado}.` }); cargar();
  });
  const radicar = intentar(async () => {
    if (!window.confirm("¿Radicar el escrito aprobado? Desde ese momento ya no se modifica.")) return;
    const r = await api.post(`/api/escritos/${id}/radicar`); setMsg({ tipo: "exito", texto: r.mensaje }); cargar();
  });
  const descartar = intentar(async () => {
    const motivo = window.prompt("Motivo para descartar el escrito:"); if (!motivo) return;
    await api.post(`/api/escritos/${id}/descartar`, { motivo }); cargar();
  });
  const pendientes = /\[(COMPLETAR|VERIFICAR)[^\]]*\]/g;
  const nPend = (texto.match(pendientes) || []).length;

  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <p className="migas"><a href="#/escritos">Escritos jurídicos</a> ›</p>
          <h1>{e.tipo_nombre}: {e.titulo}</h1>
          <p className="tenue">{e.junta}{e.destinatario_institucion ? ` → ${[e.destinatario_persona, e.destinatario_institucion].filter(Boolean).join(", ")}` : ""}
            {e.radicado && <> · Radicado <strong>{e.radicado}</strong></>}</p>
        </div>
        <div className="acciones">
          <Estado e={e.estado} />
          {e.version_actual > 0 && <>
            <button className="btn" onClick={intentar(() => descargar(`/api/escritos/${id}/pdf`, e.radicado ? `${e.radicado}.pdf` : `Proyecto_${id}_v${e.version_actual}.pdf`))}>PDF</button>
            <button className="btn" onClick={intentar(() => descargar(`/api/escritos/${id}/docx`, e.radicado ? `${e.radicado}.docx` : `Proyecto_${id}_v${e.version_actual}.docx`))}>Word</button>
          </>}
          {d.puedo_radicar && <button className="btn btn-primario" onClick={radicar}>Radicar</button>}
          {!cerrado && puedeEditar && <button className="btn btn-peligro" onClick={descartar}>Descartar</button>}
        </div>
      </header>
      {msg && <Aviso tipo={msg.tipo} onCerrar={() => setMsg(null)}>{msg.texto}</Aviso>}
      {!d.ia.configurada && <Aviso tipo="advertencia">La redacción con IA no está configurada en el servidor (falta ANTHROPIC_API_KEY). Puede escribir el texto manualmente.</Aviso>}
      {e.error_generacion && <Aviso tipo="error">No se pudo redactar con IA: {e.error_generacion}</Aviso>}
      {e.estado === "DESCARTADO" && <Aviso tipo="advertencia">Descartado: {e.motivo_descarte}</Aviso>}

      <div className="escrito-rejilla">
        <div>
          {/* Fuentes */}
          <div className="seccion">
            <div className="seccion-cab"><h2>Documentos fuente</h2>
              {editable && <div className="acciones">
                <label className="btn btn-sm">{subiendo ? "Subiendo…" : "Adjuntar archivos"}<input type="file" multiple accept={ACEPTA} hidden onChange={subir} disabled={subiendo} /></label>
                <button className="btn btn-sm" onClick={() => setPegado({ nombre: "", texto: "" })}>Pegar texto</button>
              </div>}
            </div>
            <p className="tenue pequeno">Texto, PDF, Word, notas de voz, audios o videos (se transcriben en el servidor).</p>
            <ul className="fuentes">
              {d.fuentes.map((f) => (
                <li key={f.id_fuente}>
                  <span className={`insignia insignia-${f.estado === "ERROR" ? "critica" : f.estado === "LISTO" ? "normal" : "baja"}`}>{CLASE[f.clase]}</span>
                  <div>
                    <strong>{f.nombre_archivo}</strong>
                    <small className="tenue">{f.estado === "LISTO" ? `${(f.caracteres || 0).toLocaleString("es-CO")} caracteres${f.duracion_segundos ? ` · ${Math.round(f.duracion_segundos / 60 * 10) / 10} min` : ""}`
                      : f.estado === "ERROR" ? f.detalle_error : f.clase === "AUDIO" || f.clase === "VIDEO" ? "Transcribiendo…" : "Procesando…"}</small>
                  </div>
                  <span className="acciones-linea">
                    {f.estado === "LISTO" && <button className="btn btn-sm" onClick={intentar(async () => setModalTexto(await api.get(`/api/escritos/${id}/fuentes/${f.id_fuente}/texto`)))}>Ver texto</button>}
                    {f.hash_sha256 && <button className="btn btn-sm" onClick={intentar(() => descargar(`/api/escritos/${id}/fuentes/${f.id_fuente}/archivo`, f.nombre_archivo))}>Original</button>}
                    {editable && <button className="btn-icono" title="Quitar fuente" onClick={intentar(async () => { if (window.confirm("¿Quitar esta fuente?")) { await api.del(`/api/escritos/${id}/fuentes/${f.id_fuente}`); cargar(); } })}>×</button>}
                  </span>
                </li>
              ))}
              {d.fuentes.length === 0 && <li className="tenue">Agregue los documentos, audios o videos con los hechos.</li>}
            </ul>
          </div>

          {/* Redacción con IA */}
          {editable && (
            <div className="seccion">
              <h2>{e.version_actual ? "Nueva versión con IA" : "Redactar con IA"}</h2>
              {e.instrucciones && <p className="tenue pequeno"><strong>Objetivo:</strong> {e.instrucciones}</p>}
              <textarea rows={3} value={instr} onChange={(ev) => setInstr(ev.target.value)} aria-label="Instrucciones adicionales"
                placeholder={e.version_actual ? "Qué debe cambiar (se aplican también los comentarios de los revisores)…" : "Instrucciones adicionales (opcional)…"} />
              <div className="acciones" style={{ marginTop: 8 }}>
                <button className="btn btn-primario" onClick={generar} disabled={e.generando || !d.ia.configurada}>
                  {e.generando ? "La IA está redactando…" : e.version_actual ? "Pedir nueva versión" : "Redactar proyecto"}</button>
                {e.generando && <span className="giro" />}
                <small className="tenue">{d.ia.proveedor === "simulado" ? "Modo de prueba (sin IA real)" : `Claude · ${d.ia.modelo}`}</small>
              </div>
            </div>
          )}

          {/* Revisión */}
          <div className="seccion">
            <h2>Revisión de la versión {e.version_actual || "—"}</h2>
            <div className="firmas firmas-3">
              {["ABOGADO", "PRESIDENCIA", "SECRETARIA"].map((r) => {
                const a = d.aprobaciones[r];
                return <div key={r} className={`firma ${a ? "firmada" : ""}`}><small>{ROL[r]}</small>
                  {a ? <><strong>{a.nombre_usuario}</strong><span className="tenue">{formatear(a.fecha, "datetime")}</span></> : <span className="tenue">Pendiente</span>}</div>;
              })}
            </div>
            {!cerrado && e.version_actual > 0 && <>
              <textarea rows={2} value={comentario} onChange={(ev) => setComentario(ev.target.value)} placeholder="Comentario u observación…" aria-label="Comentario" style={{ marginTop: 10 }} />
              <div className="acciones" style={{ marginTop: 8 }}>
                {d.mi_rol !== "COMENTARIO" && !d.aprobaciones[d.mi_rol] && <button className="btn btn-primario" onClick={revisar("APRUEBA")}>Aprobar como {ROL[d.mi_rol]}</button>}
                {d.mi_rol !== "COMENTARIO" && <button className="btn" onClick={revisar("CAMBIOS")}>Solicitar cambios</button>}
                <button className="btn" onClick={revisar("COMENTA")}>Comentar</button>
              </div>
            </>}
            <ul className="comentarios">
              {d.revisiones.map((r, i) => (
                <li key={i} className={r.decision === "APRUEBA" ? "ok" : r.decision === "CAMBIOS" ? "cambios" : ""}>
                  <small className="tenue">v{r.numero_version} · {formatear(r.fecha, "datetime")} · {r.nombre_usuario}{r.cargo ? ` (${r.cargo})` : ""}</small>
                  <div><strong>{r.decision === "APRUEBA" ? `Aprobó (${ROL[r.rol]})` : r.decision === "CAMBIOS" ? "Solicitó cambios" : "Comentó"}</strong>{r.comentario ? `: ${r.comentario}` : ""}</div>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Texto */}
        <div className="seccion texto-escrito">
          <div className="seccion-cab">
            <h2>Texto {verVersion ? `· versión ${verVersion.numero} (anterior)` : e.version_actual ? `· versión ${e.version_actual}` : ""}</h2>
            <div className="acciones">
              {d.versiones.length > 1 && <select value={verVersion?.numero || ""} aria-label="Ver versión"
                onChange={intentar(async (ev) => setVerVersion(ev.target.value && Number(ev.target.value) !== e.version_actual ? await api.get(`/api/escritos/${id}/versiones/${ev.target.value}`) : null))}>
                {d.versiones.map((v) => <option key={v.numero} value={v.numero}>v{v.numero} · {v.origen === "IA" ? "IA" : "edición"} · {v.nombre_usuario} · {formatear(v.fecha, "datetime")}</option>)}
              </select>}
              {editable && !verVersion && e.version_actual > 0 && <button className="btn btn-sm btn-primario" onClick={guardarTexto} disabled={texto === e.contenido}>Guardar como versión nueva</button>}
            </div>
          </div>
          {e.version_actual > 0 && <Aviso tipo="advertencia">Proyecto redactado con asistencia de IA: verifique los hechos, las normas y los datos marcados{nPend ? ` (${nPend} marca(s) [COMPLETAR]/[VERIFICAR] pendientes)` : ""}.</Aviso>}
          {verVersion
            ? <textarea className="editor" value={verVersion.contenido} readOnly aria-label="Versión anterior" />
            : e.version_actual > 0 || e.generando
              ? <textarea className="editor" value={e.generando ? "La IA está redactando…" : texto} readOnly={!editable} aria-label="Texto del escrito"
                  onChange={(ev) => { editado.current = true; setTexto(ev.target.value); }} />
              : <p className="tenue">Agregue las fuentes y pida a la IA el primer proyecto.</p>}
          {e.notas_revision && !verVersion && (
            <div className="notas-ia"><h3>Para verificar antes de aprobar (notas de la IA, no hacen parte del escrito)</h3><pre>{e.notas_revision}</pre></div>
          )}
        </div>
      </div>

      {pegado && (
        <Modal titulo="Pegar texto como fuente" onCerrar={() => setPegado(null)} ancho={720}
          pie={<><span className="espacio" /><button className="btn" onClick={() => setPegado(null)}>Cancelar</button>
            <button className="btn btn-primario" onClick={intentar(async () => { await api.post(`/api/escritos/${id}/fuentes/texto`, pegado); setPegado(null); cargar(); })}>Agregar</button></>}>
          <div className="campo"><label htmlFor="pg-n">Nombre de la fuente</label><input id="pg-n" placeholder="Ej.: relato de la afiliada, chat de WhatsApp…" value={pegado.nombre} onChange={(ev) => setPegado({ ...pegado, nombre: ev.target.value })} /></div>
          <div className="campo"><label htmlFor="pg-t">Texto</label><textarea id="pg-t" rows={14} value={pegado.texto} onChange={(ev) => setPegado({ ...pegado, texto: ev.target.value })} /></div>
        </Modal>
      )}
      {modalTexto && (
        <Modal titulo={`Texto de: ${modalTexto.nombre_archivo}`} onCerrar={() => setModalTexto(null)} ancho={820}>
          <pre className="texto-fuente">{modalTexto.texto}</pre>
        </Modal>
      )}
    </section>
  );
}
