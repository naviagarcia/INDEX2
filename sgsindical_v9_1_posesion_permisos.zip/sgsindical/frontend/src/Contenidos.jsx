import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "./api.js";
import { Aviso, Cargando, formatear, Modal, SelectorFK } from "./ui.jsx";

const FORMATO = { VIDEO_CORTO: "Video corto", CARRUSEL: "Carrusel", HILO: "Hilo para X", PUBLICACION: "Publicación", WHATSAPP: "WhatsApp",
  BOLETIN: "Boletín", INFOGRAFIA: "Infografía", PREGUNTAS: "Preguntas y respuestas" };
const ESTADO = { IDEA: ["Idea", "normal"], EN_REVISION: ["En revisión", "baja"], CAMBIOS_SOLICITADOS: ["Cambios solicitados", "media"],
  APROBADA: ["Aprobada · por publicar", "alta"], PUBLICADA: ["Publicada", "normal"], DESCARTADA: ["Descartada", "critica"] };
const ROL = { JURIDICA: "Revisión jurídica", COMUNICACIONES: "Comunicaciones", COMENTARIO: "Comentario" };
const nivel = (d) => (/CRÍTICA/.test(d) ? "critica" : /ALTA/.test(d) ? "alta" : /MEDIA/.test(d) ? "media" : "normal");
const hoyISO = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const Estado = ({ e }) => { const [t, c] = ESTADO[e] || [e, "normal"]; return <span className={`insignia insignia-${c}`}>{t}</span>; };

// ------------------------------------------------------------------ calendario editorial
export function ContenidosPagina({ permisos, ir }) {
  const [cal, setCal] = useState(null);
  const [ctl, setCtl] = useState([]);
  const [nueva, setNueva] = useState(null);
  const [error, setError] = useState("");
  const cargar = useCallback(() => {
    api.get("/api/vistas/calendario_editorial").then(setCal).catch((e) => setError(e.message));
    api.get("/api/vistas/contenidos").then((r) => setCtl(r.filas)).catch(() => {});
  }, []);
  useEffect(cargar, [cargar]);
  const grupos = {};
  (cal?.filas || []).forEach((f) => { (grupos[f.fecha] ||= []).push(f); });
  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <h1>Calendario de contenidos</h1>
          <p className="tenue">Contenidos que educan en derechos laborales. La IA redacta cada pieza; el abogado (o el Secretario Jurídico) y la Secretaría
            de Comunicaciones la aprueban antes de publicarla. Al registrar la publicación, la cuenta queda al día.</p>
        </div>
        <div className="acciones">
          <a className="btn" href="#/r/politicas_comunicacion">Política de comunicaciones</a>
          <a className="btn" href="#/v/rendimiento_contenidos">Rendimiento</a>
          {permisos.GOBERNANZA?.registrar && <button className="btn btn-primario" onClick={() => setNueva({})}>Nueva pieza</button>}
        </div>
      </header>
      <Aviso tipo="error">{error}</Aviso>
      {ctl.length > 0 && (
        <div className="tarjetas" style={{ marginBottom: 16 }}>
          {ctl.map((j) => (
            <div key={j.id_estamento} className="tarjeta" style={{ cursor: "default" }}>
              <div className="tarjeta-cab"><strong>{j.junta}</strong><span className={`insignia insignia-${nivel(j.diagnostico)}`}>{j.diagnostico.startsWith("ALERTA") ? j.diagnostico.split(":")[0].replace("ALERTA ", "") : "Al día"}</span></div>
              <div className="tenue pequeno">{j.programadas_7_dias} programadas esta semana · {j.publicadas_7_dias} publicadas · {j.en_revision} en revisión
                {j.meta_semana ? ` · meta ${j.meta_semana}/semana` : ""}</div>
              {j.diagnostico.startsWith("ALERTA") && <div className="pequeno">{j.diagnostico.split(": ").slice(1).join(": ")}</div>}
            </div>
          ))}
        </div>
      )}
      {!cal ? <Cargando /> : (
        <div className="calendario">
          {Object.keys(grupos).sort().map((fecha) => (
            <div key={fecha} className={`dia ${fecha === hoyISO() ? "hoy" : ""}`}>
              <div className="dia-fecha">{formatear(fecha, "date")}{fecha === hoyISO() && " · hoy"}</div>
              <div className="dia-items">{grupos[fecha].map((f, i) => f.clase === "PIEZA" ? (
                <button key={i} className="pieza" onClick={() => ir(`/pieza/${f.id_pieza}`)}>
                  <span className="pieza-formato">{FORMATO[f.formato]}</span>
                  <strong>{f.titulo}</strong>
                  <small className="tenue">{f.junta}{f.eje ? ` · ${f.eje}` : ""}{f.redes_destino ? ` · ${f.redes_destino}` : ""}</small>
                  <span className={`insignia insignia-${nivel(f.diagnostico)}`}>{f.diagnostico.replace(/^ALERTA (ALTA|MEDIA): /, "")}</span>
                </button>
              ) : (
                <div key={i} className="fecha-clave">
                  <strong>★ {f.titulo}</strong><small className="tenue">{f.junta}{f.eje ? ` · sugerido: ${f.eje}` : ""}</small>
                  <span className={`insignia insignia-${nivel(f.diagnostico)}`}>{f.diagnostico.replace(/^ALERTA MEDIA: /, "")}</span>
                  {permisos.GOBERNANZA?.registrar && f.diagnostico.startsWith("ALERTA") &&
                    <button className="btn btn-sm" onClick={() => setNueva({ titulo: f.titulo, id_estamento: f.id_estamento })}>Preparar contenido</button>}
                </div>
              ))}</div>
            </div>
          ))}
          {Object.keys(grupos).length === 0 && <p className="vacio">No hay piezas programadas ni fechas clave próximas.</p>}
        </div>
      )}
      {nueva && <NuevaPieza inicial={nueva} onCerrar={() => setNueva(null)} onListo={(id) => ir(`/pieza/${id}`)} />}
    </section>
  );
}

function NuevaPieza({ inicial, onCerrar, onListo }) {
  const [f, setF] = useState({ formato: "CARRUSEL", fecha_programada: hoyISO(), ...inicial });
  const [ejes, setEjes] = useState([]);
  const [error, setError] = useState("");
  useEffect(() => { api.get("/api/opciones/ejes_tematicos").then(setEjes).catch(() => {}); }, []);
  const c = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const enviar = async (e) => { e.preventDefault(); setError(""); try { onListo((await api.post("/api/r/piezas", f)).id_pieza); } catch (e2) { setError(e2.message); } };
  return (
    <Modal titulo="Nueva pieza de contenido" onCerrar={onCerrar} ancho={760}
      pie={<><span className="espacio" /><button className="btn" onClick={onCerrar}>Cancelar</button><button className="btn btn-primario" form="f-pz">Crear</button></>}>
      <form id="f-pz" onSubmit={enviar}>
        <Aviso tipo="error">{error}</Aviso>
        <div className="rejilla-campos">
          <div className="campo campo-ancho"><label htmlFor="pz-t">Tema</label><input id="pz-t" required value={f.titulo || ""} onChange={c("titulo")}
            placeholder="Ej.: ¿Me pueden trasladar sin motivación?" /></div>
          <div className="campo"><label htmlFor="pz-j">Junta que publica</label>
            <SelectorFK id="pz-j" recurso="estamentos" requerido valor={f.id_estamento} onCambio={(v) => setF({ ...f, id_estamento: v })} /></div>
          <div className="campo"><label htmlFor="pz-e">Eje temático</label>
            <select id="pz-e" value={f.codigo_eje || ""} onChange={c("codigo_eje")}><option value="">(Sin eje)</option>{ejes.map((x) => <option key={x.valor} value={x.valor}>{x.etiqueta}</option>)}</select></div>
          <div className="campo"><label htmlFor="pz-f">Formato</label>
            <select id="pz-f" value={f.formato} onChange={c("formato")}>{Object.entries(FORMATO).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></div>
          <div className="campo"><label htmlFor="pz-d">Fecha de publicación</label><input id="pz-d" type="date" value={f.fecha_programada || ""} onChange={c("fecha_programada")} /></div>
          <div className="campo"><label htmlFor="pz-p">Público</label><input id="pz-p" onChange={c("publico")} placeholder="Ej.: docentes provisionales" /></div>
          <div className="campo"><label htmlFor="pz-r">Redes</label><input id="pz-r" onChange={c("redes_destino")} placeholder="Ej.: Instagram y TikTok" /></div>
          <div className="campo campo-ancho"><label htmlFor="pz-m">Material de base (opcional)</label>
            <textarea id="pz-m" rows={4} onChange={c("material_base")} placeholder="Pegue el texto de la norma, la noticia o el documento que la IA debe usar." /></div>
        </div>
      </form>
    </Modal>
  );
}

// ------------------------------------------------------------------ ficha de una pieza
export function PiezaDetalle({ id, permisos }) {
  const [d, setD] = useState(null);
  const [texto, setTexto] = useState("");
  const [instr, setInstr] = useState("");
  const [comentario, setComentario] = useState("");
  const [pub, setPub] = useState(null);
  const [msg, setMsg] = useState(null);
  const editado = useRef(false);
  const cargar = useCallback(async () => {
    try { const r = await api.get(`/api/contenidos/piezas/${id}`); setD(r); if (!editado.current) setTexto(r.pieza.contenido || ""); }
    catch (e) { setMsg({ tipo: "error", texto: e.message }); }
  }, [id]);
  useEffect(() => { cargar(); }, [cargar]);
  useEffect(() => { if (!d?.pieza.generando) return undefined; const t = setInterval(cargar, 3000); return () => clearInterval(t); }, [d, cargar]);
  const intentar = (fn) => async (...a) => { setMsg(null); try { await fn(...a); } catch (e) { setMsg({ tipo: "error", texto: e.message }); if (e.status === 409) { editado.current = false; cargar(); } } };
  if (!d) return <section className="pagina">{msg ? <Aviso tipo="error">{msg.texto}</Aviso> : <Cargando />}</section>;
  const p = d.pieza;
  const cerrada = ["PUBLICADA", "DESCARTADA"].includes(p.estado);
  const editable = permisos.GOBERNANZA?.actualizar && !cerrada && !p.generando;

  const generar = intentar(async () => {
    editado.current = false;
    const r = await api.post(`/api/contenidos/piezas/${id}/generar`, { instrucciones: instr }); setInstr(""); setMsg({ tipo: "info", texto: r.mensaje }); cargar();
  });
  const guardar = intentar(async () => {
    const r = await api.put(`/api/contenidos/piezas/${id}/contenido`, { contenido: texto, version_base: p.version_actual });
    editado.current = false; setMsg({ tipo: "exito", texto: r.mensaje }); cargar();
  });
  const revisar = (decision) => intentar(async () => {
    if (decision !== "APRUEBA" && !comentario.trim()) { setMsg({ tipo: "advertencia", texto: "Escriba el comentario." }); return; }
    const r = await api.post(`/api/contenidos/piezas/${id}/revisar`, { numero_version: p.version_actual, decision, comentario });
    setComentario(""); setMsg({ tipo: "exito", texto: `Registrado. Estado: ${ESTADO[r.estado]?.[0] || r.estado}.` }); cargar();
  });
  const publicar = intentar(async (ev) => {
    ev.preventDefault();
    await api.post("/api/r/pieza_publicaciones", { ...pub, id_pieza: id }); setPub(null); setMsg({ tipo: "exito", texto: "Publicación registrada. La cuenta queda al día." }); cargar();
  });
  const medir = (x) => intentar(async () => {
    const alcance = window.prompt("Alcance (personas que la vieron):", x.alcance ?? ""); if (alcance === null) return;
    const interacciones = window.prompt("Interacciones (me gusta, comentarios, guardados…):", x.interacciones ?? ""); if (interacciones === null) return;
    const compartidos = window.prompt("Veces compartida:", x.compartidos ?? ""); if (compartidos === null) return;
    await api.put("/api/r/pieza_publicaciones/registro", { alcance: Number(alcance) || 0, interacciones: Number(interacciones) || 0,
      compartidos: Number(compartidos) || 0, fecha_medicion: hoyISO(), version: x.version }, { id_publicacion: x.id_publicacion });
    cargar();
  });

  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <p className="migas"><a href="#/contenidos">Calendario de contenidos</a> ›</p>
          <h1>{p.titulo}</h1>
          <p className="tenue">{FORMATO[p.formato]} · {p.junta}{p.eje ? ` · ${p.eje}` : ""}{p.fecha_programada ? ` · para el ${formatear(p.fecha_programada, "date")}` : ""}
            {p.fecha_clave ? ` · ${p.fecha_clave}` : ""}</p>
        </div>
        <div className="acciones">
          <Estado e={p.estado} />
          {p.estado === "APROBADA" && d.cuentas.length > 0 && permisos.GOBERNANZA?.registrar &&
            <button className="btn btn-primario" onClick={() => setPub({ id_cuenta_red: d.cuentas[0].id_cuenta_red, fecha_publicacion: hoyISO(), url: "" })}>Registrar publicación</button>}
          {p.estado === "PUBLICADA" && d.cuentas.some((c) => !d.publicaciones.find((x) => x.id_cuenta_red === c.id_cuenta_red)) &&
            <button className="btn" onClick={() => setPub({ id_cuenta_red: d.cuentas.find((c) => !d.publicaciones.find((x) => x.id_cuenta_red === c.id_cuenta_red)).id_cuenta_red, fecha_publicacion: hoyISO(), url: "" })}>Publicar en otra red</button>}
          {!cerrada && permisos.GOBERNANZA?.actualizar && <button className="btn btn-peligro" onClick={intentar(async () => {
            const m = window.prompt("Motivo para descartar la pieza:"); if (!m) return; await api.post(`/api/contenidos/piezas/${id}/descartar`, { motivo: m }); cargar(); })}>Descartar</button>}
        </div>
      </header>
      {msg && <Aviso tipo={msg.tipo} onCerrar={() => setMsg(null)}>{msg.texto}</Aviso>}
      {p.error_generacion && <Aviso tipo="error">No se pudo crear con IA: {p.error_generacion}</Aviso>}
      {!d.tiene_politica && <Aviso tipo="advertencia">La junta no tiene una política de comunicaciones aprobada; la IA usará un tono general. <a href="#/r/politicas_comunicacion">Crear la política</a></Aviso>}

      <div className="escrito-rejilla">
        <div>
          {editable && (
            <div className="seccion">
              <h2>{p.version_actual ? "Nueva versión con IA" : "Crear con IA"}</h2>
              {p.material_base && <p className="tenue pequeno"><strong>Material de base:</strong> {p.material_base.slice(0, 220)}{p.material_base.length > 220 ? "…" : ""}</p>}
              <textarea rows={3} value={instr} onChange={(e) => setInstr(e.target.value)} aria-label="Instrucciones"
                placeholder={p.version_actual ? "Qué cambiar (se aplican también los comentarios)…" : "Enfoque, ejemplo, llamado a la acción… (opcional)"} />
              <div className="acciones" style={{ marginTop: 8 }}>
                <button className="btn btn-primario" onClick={generar} disabled={p.generando || !d.ia.configurada}>{p.generando ? "La IA está creando…" : p.version_actual ? "Pedir nueva versión" : "Crear pieza"}</button>
                {p.generando && <span className="giro" />}
                <small className="tenue">{d.ia.proveedor === "simulado" ? "Modo de prueba (sin IA real)" : `Claude · ${d.ia.modelo}`}</small>
              </div>
            </div>
          )}
          <div className="seccion">
            <h2>Revisión de la versión {p.version_actual || "—"}</h2>
            <div className="firmas">
              {["JURIDICA", "COMUNICACIONES"].map((r) => { const a = d.aprobaciones[r]; return (
                <div key={r} className={`firma ${a ? "firmada" : ""}`}><small>{ROL[r]}</small>
                  {a ? <><strong>{a.nombre_usuario}</strong><span className="tenue">{formatear(a.fecha, "datetime")}</span></> : <span className="tenue">Pendiente</span>}</div>); })}
            </div>
            {!cerrada && p.version_actual > 0 && <>
              <textarea rows={2} value={comentario} onChange={(e) => setComentario(e.target.value)} placeholder="Comentario…" aria-label="Comentario" style={{ marginTop: 10 }} />
              <div className="acciones" style={{ marginTop: 8 }}>
                {d.mi_rol !== "COMENTARIO" && !d.aprobaciones[d.mi_rol] && <button className="btn btn-primario" onClick={revisar("APRUEBA")}>Aprobar ({ROL[d.mi_rol]})</button>}
                {d.mi_rol !== "COMENTARIO" && <button className="btn" onClick={revisar("CAMBIOS")}>Solicitar cambios</button>}
                <button className="btn" onClick={revisar("COMENTA")}>Comentar</button>
              </div>
            </>}
            <ul className="comentarios">
              {d.revisiones.map((r, i) => (
                <li key={i} className={r.decision === "APRUEBA" ? "ok" : r.decision === "CAMBIOS" ? "cambios" : ""}>
                  <small className="tenue">v{r.numero_version} · {formatear(r.fecha, "datetime")} · {r.nombre_usuario}{r.cargo ? ` (${r.cargo})` : ""}</small>
                  <div><strong>{r.decision === "APRUEBA" ? `Aprobó (${ROL[r.rol]})` : r.decision === "CAMBIOS" ? "Solicitó cambios" : "Comentó"}</strong>{r.comentario ? `: ${r.comentario}` : ""}</div>
                </li>))}
            </ul>
          </div>
          {d.publicaciones.length > 0 && (
            <div className="seccion">
              <h2>Publicaciones y resultados</h2>
              <table className="tabla tabla-compacta">
                <thead><tr><th>Red</th><th>Fecha</th><th className="num">Alcance</th><th className="num">Interacciones</th><th className="num">Compartidos</th><th /></tr></thead>
                <tbody>{d.publicaciones.map((x) => (
                  <tr key={x.id_publicacion}><td>{x.url ? <a href={x.url} target="_blank" rel="noreferrer">{x.red} {x.usuario_cuenta}</a> : `${x.red} ${x.usuario_cuenta}`}</td>
                    <td>{formatear(x.fecha_publicacion, "date")}</td><td className="num">{x.alcance ?? "—"}</td><td className="num">{x.interacciones ?? "—"}</td>
                    <td className="num">{x.compartidos ?? "—"}</td><td><button className="btn btn-sm" onClick={medir(x)}>Registrar resultados</button></td></tr>))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <div className="seccion texto-escrito">
          <div className="seccion-cab"><h2>Pieza {p.version_actual ? `· versión ${p.version_actual}` : ""}</h2>
            <div className="acciones">
              {texto && <button className="btn btn-sm" onClick={() => navigator.clipboard?.writeText(texto).then(() => setMsg({ tipo: "exito", texto: "Texto copiado." }))}>Copiar</button>}
              {editable && p.version_actual > 0 && <button className="btn btn-sm btn-primario" disabled={texto === p.contenido} onClick={guardar}>Guardar como versión nueva</button>}
            </div>
          </div>
          {p.version_actual > 0 && <Aviso tipo="advertencia">Creada con asistencia de IA: verifique normas y datos antes de aprobar.</Aviso>}
          {p.version_actual > 0 || p.generando
            ? <textarea className="editor editor-pieza" value={p.generando ? "La IA está creando la pieza…" : texto} readOnly={!editable} aria-label="Texto de la pieza"
                onChange={(e) => { editado.current = true; setTexto(e.target.value); }} />
            : <p className="tenue">Pida a la IA el primer borrador.</p>}
          {p.notas_ia && <div className="notas-ia"><h3>Notas para el revisor (no se publican)</h3><pre>{p.notas_ia}</pre></div>}
        </div>
      </div>
      {pub && (
        <Modal titulo="Registrar publicación" onCerrar={() => setPub(null)}
          pie={<><span className="espacio" /><button className="btn" onClick={() => setPub(null)}>Cancelar</button><button className="btn btn-primario" form="f-pub">Registrar</button></>}>
          <form id="f-pub" onSubmit={publicar} className="rejilla-campos">
            <div className="campo"><label htmlFor="pb-c">Cuenta</label>
              <select id="pb-c" value={pub.id_cuenta_red} onChange={(e) => setPub({ ...pub, id_cuenta_red: Number(e.target.value) })}>
                {d.cuentas.map((c) => <option key={c.id_cuenta_red} value={c.id_cuenta_red}>{c.red} {c.usuario_cuenta}</option>)}</select></div>
            <div className="campo"><label htmlFor="pb-f">Fecha</label><input id="pb-f" type="date" value={pub.fecha_publicacion} onChange={(e) => setPub({ ...pub, fecha_publicacion: e.target.value })} /></div>
            <div className="campo campo-ancho"><label htmlFor="pb-u">Enlace de la publicación</label><input id="pb-u" value={pub.url} onChange={(e) => setPub({ ...pub, url: e.target.value })} /></div>
          </form>
        </Modal>
      )}
    </section>
  );
}

// ------------------------------------------------------------------ acciones de la política (en su ficha)
export function AccionesPolitica({ fila, onCambio }) {
  const [msg, setMsg] = useState(null);
  const [acta, setActa] = useState(null);
  const intentar = (fn) => async () => { setMsg(null); try { await fn(); } catch (e) { setMsg({ tipo: "error", texto: e.message }); } };
  if (fila.vigente || fila.id_acta_aprobacion) return <div className="acciones-extra"><h3>Política</h3><Aviso tipo="exito">Vigente: aprobada en acta. Para cambiarla, cree una nueva política y apruébela.</Aviso></div>;
  return (
    <div className="acciones-extra">
      <h3>Política</h3>
      <div className="acciones">
        <button className="btn" onClick={intentar(async () => {
          const r = await api.post(`/api/contenidos/politicas/${fila.id_politica}/generar`, {});
          setMsg({ tipo: "info", texto: r.mensaje }); setTimeout(onCambio, 1500);
        })}>Redactar con IA</button>
      </div>
      <div className="rejilla-campos" style={{ marginTop: 10 }}>
        <div className="campo"><label htmlFor="ap-a">Acta de la reunión que la aprueba</label>
          <SelectorFK id="ap-a" recurso="documentos" valor={acta} onCambio={setActa} /></div>
        <div className="campo" style={{ alignSelf: "end" }}><button className="btn btn-primario" disabled={!acta} onClick={intentar(async () => {
          const r = await api.post(`/api/contenidos/politicas/${fila.id_politica}/aprobar`, { id_acta: acta }); setMsg({ tipo: "exito", texto: r.mensaje }); onCambio();
        })}>Aprobar con acta</button></div>
      </div>
      {msg && <Aviso tipo={msg.tipo} onCerrar={() => setMsg(null)}>{msg.texto}</Aviso>}
    </div>
  );
}
