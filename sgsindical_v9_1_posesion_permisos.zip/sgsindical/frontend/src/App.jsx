import { useCallback, useEffect, useState } from "react";
import { alPerderSesion, api, getToken, setToken } from "./api.js";
import { BackupsPagina, CorreosPagina, PermisosPagina, SesionesPagina } from "./Admin.jsx";
import { CierresPagina } from "./Cierres.jsx";
import { JuntasHistoria } from "./Juntas.jsx";
import { ContenidosPagina, PiezaDetalle } from "./Contenidos.jsx";
import { EscritoDetalle, EscritosPagina } from "./Escritos.jsx";
import { ReunionDetalle, ReunionesPagina } from "./Reuniones.jsx";
import { PqrsdDetalle, PqrsdPagina } from "./Pqrsd.jsx";
import RecursoPagina from "./Recurso.jsx";
import { Aviso, Cargando } from "./ui.jsx";
import { Tablero, VistaPagina } from "./Vistas.jsx";
import { BitacoraAccesosPagina, estadoPrivacidad } from "./Privacidad.jsx";
import { ActivarCuenta, EnlacesLegales, Portal, TextoLegal, VerificarCertificado } from "./Portal.jsx";
import { CambiarContexto, describirAmbito, ElegirContexto, RolesPendientesPagina, SuplenciasPagina } from "./Roles.jsx";
import { AvisoPlazoMFA, ConfigurarMFA, equipoRecordado, MiSeguridad, PedirCodigo, VerificarMFA } from "./MFA.jsx";

const MODULOS = [
  ["GOBERNANZA", "Gobernanza"],
  ["DOCUMENTAL", "Gestión documental"],
  ["FINANZAS", "Finanzas"],
  ["AUDITORIA", "Auditoría"],
  ["ADMINISTRACION", "Administración"],
];

function usarRuta() {
  const leer = () => window.location.hash.replace(/^#/, "") || "/";
  const [ruta, setRuta] = useState(leer);
  useEffect(() => {
    const f = () => setRuta(leer());
    window.addEventListener("hashchange", f);
    return () => window.removeEventListener("hashchange", f);
  }, []);
  const ir = useCallback((r) => { window.location.hash = r; }, []);
  return [ruta, ir];
}

// Modo local de la aplicación de escritorio: el equipo guarda la contraseña de la base de datos
function AvisoModoLocal() {
  const [local, setLocal] = useState(false);
  useEffect(() => { api.get("/api/salud").then((r) => setLocal(!!r.modo_local)).catch(() => {}); }, []);
  if (!local) return null;
  return (
    <div className="aviso-modo-local" role="alert">
      <strong>Modo local.</strong> Este equipo guarda la contraseña de la base de datos: úselo solo para pruebas o en un único equipo de
      confianza. Para varios usuarios use el modo central (servidor).
    </div>
  );
}

export default function App() {
  return <><AvisoModoLocal /><AppContenido /></>;
}

function AppContenido() {
  const [usuario, setUsuario] = useState(null);
  const [cargando, setCargando] = useState(!!getToken());
  const [aviso, setAviso] = useState("");
  usarRuta();   // vuelve a dibujar al cambiar de página pública (#/legal, #/verificar)

  const cargarPerfil = useCallback(async () => {
    try { setUsuario(await api.get("/api/auth/yo")); } catch { setUsuario(null); } finally { setCargando(false); }
  }, []);

  useEffect(() => { if (getToken()) cargarPerfil(); }, [cargarPerfil]);
  useEffect(() => alPerderSesion((motivo) => { setUsuario(null); setAviso(motivo || "Su sesión terminó. Ingrese de nuevo."); }), []);

  // Páginas públicas: activar la cuenta del afiliado y verificar un certificado
  const h = window.location.hash;
  if (h.startsWith("#/activar")) return <ActivarCuenta />;
  if (h.startsWith("#/verificar")) return <VerificarCertificado />;
  if (h.startsWith("#/legal/")) return <TextoLegal key={h} />;
  if (cargando) return <div className="centro-pantalla"><Cargando /></div>;
  if (!usuario) return <Login aviso={aviso} onIngreso={() => { setAviso(""); setCargando(true); cargarPerfil(); }} />;
  // Segundo factor: verificar (si ya lo tiene) o configurarlo (si el rol lo exige y el plazo terminó)
  if (usuario.mfa && !usuario.mfa.verificada) {
    return usuario.mfa.activo ? <VerificarMFA usuario={usuario} onListo={cargarPerfil} />
      : <ConfigurarMFA obligatorio onListo={cargarPerfil} />;
  }
  if (usuario.debe_cambiar_contrasena) return <CambioObligatorio usuario={usuario} onListo={cargarPerfil} />;
  if (usuario.elegir_contexto) return <ElegirContexto usuario={usuario} onListo={cargarPerfil} />;
  if (usuario.codigo_rol === "AFILIADO") {
    return <><PedirCodigo /><Portal usuario={usuario} onSalir={async () => { await api.post("/api/auth/logout").catch(() => {}); setToken(null); window.location.hash = "/"; window.location.reload(); }} /></>;
  }
  return <><PedirCodigo /><Escritorio usuario={usuario} /></>;
}

// ------------------------------------------------------------------ ingreso
function Login({ onIngreso, aviso }) {
  const [inst, setInst] = useState(null);   // nombre del sindicato: sale de Datos institucionales
  useEffect(() => { api.get("/api/publico/institucion").then(setInst).catch(() => {}); }, []);
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [error, setError] = useState("");
  const [enviando, setEnviando] = useState(false);
  const enviar = async (e) => {
    e.preventDefault(); setEnviando(true); setError("");
    try {
      const r = await api.post("/api/auth/login", { nombre_usuario: u.trim(), contrasena: p, equipo: navigator.platform || null, equipo_confiable: equipoRecordado() });
      setToken(r.token); onIngreso();
    } catch (e2) { setError(e2.message); setP(""); } finally { setEnviando(false); }
  };
  return (
    <div className="login-fondo">
      <form className="login" onSubmit={enviar}>
        <span className="login-logo" role="img" aria-label="ARCADIO" /><p className="login-lema">Sistema de gestión sindical</p>
        {inst?.nombre && <p className="login-sindicato">{inst.sigla ? `${inst.sigla} · ` : ""}{inst.nombre}</p>}
        <Aviso tipo="advertencia">{aviso}</Aviso>
        <Aviso tipo="error">{error}</Aviso>
        <div className="campo"><label htmlFor="u">Usuario</label><input id="u" value={u} onChange={(e) => setU(e.target.value)} autoFocus autoComplete="username" required /></div>
        <div className="campo"><label htmlFor="p">Contraseña</label><input id="p" type="password" value={p} onChange={(e) => setP(e.target.value)} autoComplete="current-password" required /></div>
        <button className="btn btn-primario btn-bloque" disabled={enviando}>{enviando ? "Verificando…" : "Ingresar"}</button>
        <p className="tenue pequeno">Acceso restringido. Todas las acciones quedan registradas en la bitácora de auditoría.</p>
        <EnlacesLegales />
      </form>
    </div>
  );
}

function CambioObligatorio({ usuario, onListo }) {
  const [a, setA] = useState(""); const [n, setN] = useState(""); const [c, setC] = useState("");
  const [error, setError] = useState("");
  const enviar = async (e) => {
    e.preventDefault(); setError("");
    if (n !== c) { setError("La confirmación no coincide."); return; }
    try { await api.post("/api/auth/cambiar-contrasena", { contrasena_actual: a, contrasena_nueva: n }); onListo(); }
    catch (e2) { setError(e2.message); }
  };
  return (
    <div className="login-fondo">
      <form className="login" onSubmit={enviar}>
        <h2>Cambie su contraseña</h2>
        <p className="tenue">Hola {usuario.nombre_completo}. Por política de seguridad debe definir una contraseña nueva (primer ingreso o contraseña vencida).</p>
        <p className="tenue pequeno">Mínimo {usuario.politicas.contrasena_min} caracteres, con mayúscula, minúscula, número y símbolo.</p>
        <Aviso tipo="error">{error}</Aviso>
        <div className="campo"><label htmlFor="a">Contraseña actual</label><input id="a" type="password" value={a} onChange={(e) => setA(e.target.value)} required autoComplete="current-password" /></div>
        <div className="campo"><label htmlFor="n">Nueva contraseña</label><input id="n" type="password" value={n} onChange={(e) => setN(e.target.value)} required autoComplete="new-password" /></div>
        <div className="campo"><label htmlFor="c">Confirmar</label><input id="c" type="password" value={c} onChange={(e) => setC(e.target.value)} required autoComplete="new-password" /></div>
        <button className="btn btn-primario btn-bloque">Guardar contraseña</button>
        <button type="button" className="btn btn-bloque" onClick={async () => { await api.post("/api/auth/logout").catch(() => {}); setToken(null); window.location.reload(); }}>Salir</button>
      </form>
    </div>
  );
}

// ------------------------------------------------------------------ escritorio principal
function Escritorio({ usuario }) {
  const [ruta, ir] = usarRuta();
  const [cambiarClave, setCambiarClave] = useState(false);
  const [cambiarRol, setCambiarRol] = useState(false);
  const recursos = Object.fromEntries(usuario.recursos.map((r) => [r.clave, r]));
  const p = usuario.permisos;
  const [veBitacora, setVeBitacora] = useState(false);
  useEffect(() => { estadoPrivacidad().then((e) => setVeBitacora(!!e.ve_bitacora)); }, []);

  const salir = async () => {
    if (!window.confirm("¿Cerrar sesión?")) return;
    await api.post("/api/auth/logout").catch(() => {});
    setToken(null); window.location.hash = "/"; window.location.reload();
  };

  let contenido;
  const [, tipo, clave] = ruta.split("/");
  if (tipo === "r" && recursos[clave]) contenido = <RecursoPagina key={clave} meta={recursos[clave]} permisos={p} catalogo={recursos} />;
  else if (tipo === "v" && clave) contenido = <VistaPagina key={clave} clave={clave} />;
  else if (tipo === "admin" && clave === "permisos") contenido = <PermisosPagina permisos={p} />;
  else if (tipo === "admin" && clave === "sesiones") contenido = <SesionesPagina permisos={p} />;
  else if (tipo === "admin" && clave === "backups") contenido = <BackupsPagina permisos={p} />;
  else if (tipo === "admin" && clave === "correos") contenido = <CorreosPagina permisos={p} />;
  else if (tipo === "juntas") contenido = <JuntasHistoria />;
  else if (tipo === "contenidos" && p.GOBERNANZA?.consultar) contenido = <ContenidosPagina permisos={p} ir={ir} />;
  else if (tipo === "pieza" && clave && p.GOBERNANZA?.consultar) contenido = <PiezaDetalle key={clave} id={Number(clave)} permisos={p} />;
  else if (tipo === "escritos" && p.DOCUMENTAL?.consultar) contenido = <EscritosPagina permisos={p} ir={ir} />;
  else if (tipo === "escrito" && clave && p.DOCUMENTAL?.consultar) contenido = <EscritoDetalle key={clave} id={Number(clave)} permisos={p} />;
  else if (tipo === "reuniones" && p.DOCUMENTAL?.consultar) contenido = <ReunionesPagina permisos={p} ir={ir} />;
  else if (tipo === "reunion" && clave && p.DOCUMENTAL?.consultar) contenido = <ReunionDetalle key={clave} id={Number(clave)} permisos={p} ir={ir} />;
  else if (tipo === "pqrsd" && clave && p.DOCUMENTAL?.consultar) contenido = <PqrsdDetalle key={clave} id={Number(clave)} />;
  else if (tipo === "pqrsd" && p.DOCUMENTAL?.consultar) contenido = <PqrsdPagina permisos={p} ir={ir} />;
  else if (tipo === "cierres") contenido = <CierresPagina usuario={usuario} />;
  else if (tipo === "privacidad" && clave === "bitacora") contenido = <BitacoraAccesosPagina usuario={usuario} />;
  else if (tipo === "seguridad") contenido = <MiSeguridad usuario={usuario} />;
  else if (tipo === "suplencias" && p.GOBERNANZA?.consultar) contenido = <SuplenciasPagina usuario={usuario} />;
  else if (tipo === "roles-pendientes" && usuario.aprueba_roles) contenido = <RolesPendientesPagina />;
  else if ((tipo === "mi-espacio" || tipo === "confirmar-correo") && usuario.portal_afiliado) contenido = <Portal usuario={usuario} embebido />;
  else contenido = <Tablero usuario={usuario} ir={ir} />;

  const enlace = (destino, texto) => (
    <a key={destino} href={`#${destino}`} className={ruta === destino ? "activo" : ""}>{texto}</a>
  );

  return (
    <div className="escritorio">
      <aside className="lateral">
        <div className="marca"><span className="logo" aria-hidden="true" /><div><span className="palabra-marca" role="img" aria-label="ARCADIO" /><small>Gestión sindical · v9.1</small></div></div>
        <nav>
          {enlace("/", "Tablero de alertas")}
          {usuario.aprueba_roles && enlace("/roles-pendientes", "Roles por aprobar")}
          {usuario.portal_afiliado && enlace("/mi-espacio", "Mi espacio (afiliado)")}
          {MODULOS.map(([m, nombre]) => {
            const rs = usuario.recursos.filter((r) => r.modulo === m && r.clave !== "permisos" && !r.clave.startsWith("reunion") && !["escritos", "piezas"].includes(r.clave));
            const vs = usuario.vistas.filter((v) => v.modulo === m);
            const extras = m === "ADMINISTRACION" && p.ADMINISTRACION?.consultar;
            const historia = m === "GOBERNANZA" && p.GOBERNANZA?.consultar;
            const cierre = m === "FINANZAS" && p.FINANZAS?.consultar;
            const reuniones = m === "DOCUMENTAL" && p.DOCUMENTAL?.consultar;
            const bitacora = m === "AUDITORIA" && veBitacora;
            if (!rs.length && !vs.length && !extras && !bitacora) return null;
            return (
              <details key={m} open={ruta.includes(m) || (m === "GOBERNANZA" && (ruta === "/juntas" || ruta === "/suplencias" || /^\/(contenidos|pieza)/.test(ruta))) || (m === "FINANZAS" && ruta === "/cierres") || (m === "DOCUMENTAL" && /^\/(reunion|escrito|pqrsd)/.test(ruta)) || rs.some((r) => ruta === `/r/${r.clave}`) || vs.some((v) => ruta === `/v/${v.clave}`)}>
                <summary>{nombre}</summary>
                {reuniones && enlace("/pqrsd", "PQRSD recibidas")}
                {reuniones && enlace("/reuniones", "Reuniones y actas")}
                {reuniones && enlace("/escritos", "Escritos jurídicos (IA)")}
                {rs.map((r) => enlace(`/r/${r.clave}`, r.titulo))}
                {historia && enlace("/juntas", "Juntas en el tiempo")}
                {historia && enlace("/suplencias", "Suplencias de cargos")}
                {historia && enlace("/contenidos", "Calendario de contenidos")}
                {cierre && enlace("/cierres", "Cierre mensual")}
                {bitacora && enlace("/privacidad/bitacora", "Bitácora de accesos a datos personales")}
                {extras && [enlace("/admin/permisos", "Matriz de permisos"), enlace("/admin/sesiones", "Sesiones activas"), enlace("/admin/backups", "Backups"), enlace("/admin/correos", "Correos automáticos")]}
                {vs.length > 0 && <div className="nav-sub">Vistas y alertas</div>}
                {vs.map((v) => enlace(`/v/${v.clave}`, v.titulo))}
              </details>
            );
          })}
        </nav>
        <div className="usuario-caja">
          <div>
            <strong>{usuario.nombre_completo}</strong><small>{usuario.nombre_usuario} · {usuario.contexto_activo?.nombre_rol || usuario.codigo_rol}</small>
            <small className="ambito" title="Información que puede consultar y gestionar">
              Ámbito: {usuario.ambito.nacional ? "Nacional (todo el país)"
                : usuario.ambito.estamentos.length ? usuario.ambito.estamentos.join(", ") : "sin estamentos asignados"}
            </small>
          </div>
          <div className="acciones">
            {usuario.contextos?.length > 1 && <button className="btn btn-sm btn-primario" onClick={() => setCambiarRol(true)}>Cambiar de rol</button>}
            <button className="btn btn-sm" onClick={() => setCambiarClave(true)}>Contraseña</button>
            <a className="btn btn-sm" href="#/seguridad">Mi seguridad</a>
            <button className="btn btn-sm" onClick={salir}>Salir</button>
          </div>
        </div>
      </aside>
      <main className="principal">{ruta !== "/seguridad" && <AvisoPlazoMFA mfa={usuario.mfa} irA={() => ir("/seguridad")} />}{contenido}</main>
      {cambiarRol && <CambiarContexto usuario={usuario} onCerrar={() => setCambiarRol(false)} />}
      {cambiarClave && <CambioVoluntario onCerrar={() => setCambiarClave(false)} minimo={usuario.politicas.contrasena_min} />}
    </div>
  );
}

function CambioVoluntario({ onCerrar, minimo }) {
  const [a, setA] = useState(""); const [n, setN] = useState("");
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const enviar = async (e) => {
    e.preventDefault();
    try { await api.post("/api/auth/cambiar-contrasena", { contrasena_actual: a, contrasena_nueva: n }); setMsg({ tipo: "exito", texto: "Contraseña actualizada. Sus otras sesiones se cerraron." }); setA(""); setN(""); }
    catch (e2) { setMsg({ tipo: "error", texto: e2.message }); }
  };
  return (
    <div className="modal-fondo" onMouseDown={(e) => e.target === e.currentTarget && onCerrar()}>
      <form className="modal" style={{ maxWidth: 420 }} onSubmit={enviar}>
        <header className="modal-cab"><h2>Cambiar contraseña</h2><button type="button" className="btn-icono" onClick={onCerrar}>×</button></header>
        <div className="modal-cuerpo">
          <Aviso tipo={msg.tipo}>{msg.texto}</Aviso>
          <p className="tenue pequeno">Mínimo {minimo} caracteres, con mayúscula, minúscula, número y símbolo.</p>
          <div className="campo"><label htmlFor="ca">Actual</label><input id="ca" type="password" value={a} onChange={(e) => setA(e.target.value)} required /></div>
          <div className="campo"><label htmlFor="cn">Nueva</label><input id="cn" type="password" value={n} onChange={(e) => setN(e.target.value)} required /></div>
        </div>
        <footer className="modal-pie"><span className="espacio" /><button type="button" className="btn" onClick={onCerrar}>Cerrar</button><button className="btn btn-primario">Guardar</button></footer>
      </form>
    </div>
  );
}
