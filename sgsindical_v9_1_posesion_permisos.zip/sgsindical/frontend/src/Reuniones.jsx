import { useCallback, useEffect, useState } from "react";
import { api } from "./api.js";
import { Aviso, Cargando, cargarEtiquetas, formatear, Modal, SelectorFK } from "./ui.jsx";

const hora = (t) => {
  if (!t) return "—";
  const [h, m] = t.split(":").map(Number);
  return `${h % 12 || 12}:${String(m).padStart(2, "0")} ${h < 12 ? "a. m." : "p. m."}`;
};
const ESTADO = { CONVOCADA: "Convocada · acta en elaboración", CERRADA: "Acta firmada · pendiente de aprobación", APROBADA: "Acta aprobada", CANCELADA: "Cancelada" };
const CLASE_ESTADO = { CONVOCADA: "baja", CERRADA: "media", APROBADA: "normal", CANCELADA: "critica" };

function Estado({ e }) {
  return <span className={`insignia insignia-${CLASE_ESTADO[e]}`}>{ESTADO[e] || e}</span>;
}

async function abrirPdf(id, nombre) {
  const b = await api.descargar(`/api/reuniones/${id}/pdf`);
  const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = nombre; a.click();
}

// ------------------------------------------------------------------ listado
export function ReunionesPagina({ permisos, ir }) {
  const [filas, setFilas] = useState(null);
  const [juntas, setJuntas] = useState({});
  const [convocables, setConvocables] = useState(null);
  const [convocar, setConvocar] = useState(false);
  const [error, setError] = useState("");
  const [aviso, setAviso] = useState("");

  const cargar = useCallback(async () => {
    try {
      const r = await api.get("/api/r/reuniones", { tam: 100 });
      setJuntas(await cargarEtiquetas("estamentos", r.filas.map((f) => f.id_estamento)));
      setFilas(r.filas);
    } catch (e) { setError(e.message); }
  }, []);
  useEffect(() => { cargar(); api.get("/api/reuniones/convocables").then(setConvocables).catch(() => {}); }, [cargar]);

  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <h1>Reuniones y actas</h1>
          <p className="tenue">Convocan el Presidente o el Secretario General de cada junta, con 12 horas de anticipación y a más tardar a las 8:00 p. m.
            La primera reunión de cada trimestre es ordinaria; las demás, extraordinarias.</p>
        </div>
        <div className="acciones">
          {convocables?.juntas.length > 0 && permisos.DOCUMENTAL?.registrar &&
            <button className="btn btn-primario" onClick={() => setConvocar(true)}>Convocar reunión</button>}
        </div>
      </header>
      <Aviso tipo="error" onCerrar={() => setError("")}>{error}</Aviso>
      <Aviso tipo="exito" onCerrar={() => setAviso("")}>{aviso}</Aviso>
      {!filas ? <Cargando /> : (
        <div className="tabla-marco">
          <table className="tabla">
            <thead><tr><th>Fecha</th><th>Hora</th><th>Junta</th><th>Tipo</th><th>Modalidad</th><th>Estado</th><th>Quórum</th></tr></thead>
            <tbody>
              {filas.map((f) => (
                <tr key={f.id_reunion} className="clicable" onClick={() => ir(`/reunion/${f.id_reunion}`)}>
                  <td>{formatear(f.fecha, "date")}</td><td>{hora(f.hora_inicio)}</td><td>{juntas[String(f.id_estamento)]}</td>
                  <td>{f.tipo_reunion === "ORDINARIA" ? "Ordinaria" : "Extraordinaria"}</td>
                  <td>{f.modalidad.toLowerCase()}</td><td><Estado e={f.estado} /></td>
                  <td>{f.hay_quorum === null ? "—" : f.hay_quorum ? "Sí" : "No"}</td>
                </tr>
              ))}
              {filas.length === 0 && <tr><td colSpan={7} className="vacio">No hay reuniones registradas.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
      {convocar && <ConvocarModal datos={convocables} onCerrar={() => setConvocar(false)}
        onListo={(r) => { setConvocar(false); setAviso(`Reunión ${r.tipo_reunion.toLowerCase()} convocada. Se enviaron las convocatorias a ${r.convocados} directivo(s).`); cargar(); }} />}
    </section>
  );
}

function ConvocarModal({ datos, onCerrar, onListo }) {
  const manana = new Date(Date.now() + 36 * 3600e3 - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  const [f, setF] = useState({ id_estamento: datos.juntas[0]?.id_estamento, fecha: manana, hora_inicio: "09:00", modalidad: "PRESENCIAL", lugar: "" });
  const [puntos, setPuntos] = useState(["Verificación del quórum", "Aprobación del acta anterior", "", "Proposiciones y varios"]);
  const [error, setError] = useState("");
  const [enviando, setEnviando] = useState(false);
  const cambiar = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const enviar = async (e) => {
    e.preventDefault(); setError(""); setEnviando(true);
    try { onListo(await api.post("/api/reuniones/convocar", { ...f, id_estamento: Number(f.id_estamento), orden_del_dia: puntos.filter((p) => p.trim()) })); }
    catch (e2) { setError(e2.message); } finally { setEnviando(false); }
  };
  return (
    <Modal titulo="Convocar reunión de junta" onCerrar={onCerrar} ancho={760}
      pie={<><span className="espacio" /><button className="btn" onClick={onCerrar}>Cancelar</button>
        <button className="btn btn-primario" form="f-convocar" disabled={enviando}>{enviando ? "Enviando…" : "Enviar convocatoria"}</button></>}>
      <form id="f-convocar" onSubmit={enviar}>
        <Aviso tipo="error">{error}</Aviso>
        <Aviso tipo="info">Hora actual: {datos.ahora_local.replace("T", " ")}. La convocatoria se envía por correo a cada directivo vigente de la junta;
          debe salir con al menos 12 horas de anticipación y a más tardar a las 8:00 p. m. El sistema decide si es ordinaria o extraordinaria.</Aviso>
        <div className="rejilla-campos">
          <div className="campo"><label htmlFor="cv-j">Junta</label>
            <select id="cv-j" value={f.id_estamento} onChange={cambiar("id_estamento")}>
              {datos.juntas.map((j) => <option key={j.id_estamento} value={j.id_estamento}>{j.nombre_estamento} ({j.cargo})</option>)}
            </select></div>
          <div className="campo"><label htmlFor="cv-m">Modalidad</label>
            <select id="cv-m" value={f.modalidad} onChange={cambiar("modalidad")}>
              <option value="PRESENCIAL">Presencial</option><option value="VIRTUAL">Virtual</option><option value="MIXTA">Mixta</option>
            </select></div>
          <div className="campo"><label htmlFor="cv-f">Fecha</label><input id="cv-f" type="date" value={f.fecha} onChange={cambiar("fecha")} required /></div>
          <div className="campo"><label htmlFor="cv-h">Hora de inicio</label><input id="cv-h" type="time" value={f.hora_inicio} onChange={cambiar("hora_inicio")} required /></div>
          <div className="campo campo-ancho"><label htmlFor="cv-l">{f.modalidad === "VIRTUAL" ? "Enlace de conexión" : "Lugar"}</label>
            <input id="cv-l" value={f.lugar} onChange={cambiar("lugar")} required /></div>
        </div>
        <h3 className="subtitulo">Orden del día propuesto</h3>
        <p className="tenue pequeno">Va en el correo de convocatoria. Al iniciar la reunión se puede modificar; el acta deja constancia del orden convocado.</p>
        <ol className="lista-puntos">
          {puntos.map((p, i) => (
            <li key={i}>
              <input value={p} placeholder="Tema del punto" onChange={(e) => setPuntos(puntos.map((x, j) => (j === i ? e.target.value : x)))} aria-label={`Punto ${i + 1}`} />
              <button type="button" className="btn-icono" onClick={() => setPuntos(puntos.filter((_, j) => j !== i))} aria-label="Quitar punto">×</button>
            </li>
          ))}
        </ol>
        <button type="button" className="btn btn-sm" onClick={() => setPuntos([...puntos, ""])}>+ Agregar punto</button>
      </form>
    </Modal>
  );
}

// ------------------------------------------------------------------ detalle de una reunión
export function ReunionDetalle({ id, permisos, ir }) {
  const [d, setD] = useState(null);
  const [error, setError] = useState("");
  const [aviso, setAviso] = useState(null);
  const [asis, setAsis] = useState([]);
  const [modal, setModal] = useState(null);
  const puedeEditar = permisos.DOCUMENTAL?.actualizar;

  const cargar = useCallback(async () => {
    try { const r = await api.get(`/api/reuniones/${id}/acta`); setD(r); setAsis(r.asistentes.map((a) => ({ ...a }))); }
    catch (e) { setError(e.message); }
  }, [id]);
  useEffect(() => { cargar(); }, [cargar]);

  const intentar = (fn) => async (...a) => {
    setError(""); setAviso(null);
    try { await fn(...a); } catch (e) { setError(e.message); if (e.status === 409) cargar(); }
  };
  if (!d) return <section className="pagina">{error ? <Aviso tipo="error">{error}</Aviso> : <Cargando />}</section>;

  const r = d.reunion, q = d.quorum;
  const abierta = r.estado === "CONVOCADA" && d.firmas.length === 0;
  const editable = abierta && r.empezo && puedeEditar;
  const cambioAsis = (i, k, v) => setAsis(asis.map((a, j) => (j === i ? { ...a, [k]: v } : a)));
  const presentes = asis.filter((a) => a.calidad === "DIRECTIVO" && a.asistio).length;

  const guardarAsistencia = intentar(async () => {
    const filas = asis.map(({ id_asistente, version, asistio, modalidad_asistencia, hora_llegada, hora_salida, excusa }) =>
      ({ id_asistente, version, asistio, modalidad_asistencia, hora_llegada, hora_salida, excusa }));
    const n = await api.put(`/api/reuniones/${id}/asistencia`, { filas });
    setD(n); setAsis(n.asistentes.map((a) => ({ ...a })));
    setAviso({ tipo: "exito", texto: "Asistencia guardada." });
  });
  const firmar = intentar(async () => {
    if (!window.confirm("Al firmar, el contenido del acta queda congelado. ¿Firmar el acta?")) return;
    const x = await api.post(`/api/reuniones/${id}/firmar`);
    setAviso({ tipo: "exito", texto: x.mensaje }); cargar();
  });
  const cancelar = intentar(async () => {
    const motivo = window.prompt("Motivo de la cancelación (se informa por correo a los directivos):");
    if (!motivo) return;
    await api.post(`/api/reuniones/${id}/cancelar`, { motivo });
    setAviso({ tipo: "exito", texto: "Reunión cancelada. Se informó a los directivos." }); cargar();
  });
  const guardarReunion = intentar(async (cambios) => {
    await api.put("/api/r/reuniones/registro", { ...cambios, version: r.version }, { id_reunion: id }); cargar();
  });
  const borrar = (recurso, pk, fila) => intentar(async () => {
    if (!window.confirm("¿Eliminar?")) return;
    await api.del(`/api/r/${recurso}/registro`, { [pk]: fila[pk], version: fila.version }); cargar();
  });

  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <p className="migas"><a href="#/reuniones">Reuniones y actas</a> ›</p>
          <h1>Reunión {r.tipo_reunion.toLowerCase()} · {r.nombre_estamento}</h1>
          <p className="tenue">{formatear(r.fecha, "date")}, {hora(r.hora_inicio)} · {r.modalidad.toLowerCase()} · {r.lugar}
            <br />Convocó {r.convoca} ({r.cargo_convoca}) el {formatear(r.fecha_convocatoria, "datetime")}</p>
        </div>
        <div className="acciones">
          <Estado e={r.estado} />
          {r.estado !== "CANCELADA" && <button className="btn" onClick={intentar(() => abrirPdf(id, r.radicado ? `Acta_${r.radicado}.pdf` : `Borrador_acta_${id}.pdf`))}>
            {r.radicado ? "Descargar acta (PDF)" : "Vista previa del acta"}</button>}
          {d.mi_firma && abierta && !r.empezo && <button className="btn btn-peligro" onClick={cancelar}>Cancelar reunión</button>}
          {d.mi_firma && r.estado === "CONVOCADA" && r.empezo && !d.ya_firme &&
            <button className="btn btn-primario" onClick={firmar}>Firmar acta ({d.mi_firma === "PRESIDENCIA" ? "Presidencia" : "Secretaría"})</button>}
        </div>
      </header>
      <Aviso tipo="error" onCerrar={() => setError("")}>{error}</Aviso>
      {aviso && <Aviso tipo={aviso.tipo} onCerrar={() => setAviso(null)}>{aviso.texto}</Aviso>}
      {r.estado === "CANCELADA" && <Aviso tipo="advertencia">Cancelada el {formatear(r.fecha_cancelacion, "datetime")}. Motivo: {r.motivo_cancelacion}</Aviso>}
      {abierta && !r.empezo && <Aviso tipo="info">La asistencia, los cambios al orden del día y las decisiones se registran desde la hora de inicio de la reunión.</Aviso>}
      {r.radicado && <Aviso tipo="exito">Acta radicada con el número {r.radicado}. Huella SHA-256: <code>{r.hash_acta}</code></Aviso>}

      <div className="kpis">
        <div className={`kpi ${q.hay_quorum ? "" : "kpi-alta"}`}><span>{editable ? presentes : q.asistentes} / {q.directivos}</span>Directivos presentes</div>
        <div className="kpi"><span>{q.requerido}</span>Quórum requerido (mitad más uno)</div>
        <div className="kpi"><span>{q.invitados}</span>Invitados presentes (sin voto)</div>
      </div>

      {/* Asistencia */}
      <div className="seccion">
        <div className="seccion-cab">
          <h2>Asistencia</h2>
          {editable && <div className="acciones">
            <button className="btn btn-sm" onClick={() => setModal("invitado")}>+ Invitado</button>
            <button className="btn btn-sm btn-primario" onClick={guardarAsistencia}>Guardar asistencia</button>
          </div>}
        </div>
        <div className="tabla-marco">
          <table className="tabla">
            <thead><tr><th>Asistió</th><th>Nombre</th><th>Calidad</th><th>Cargo / institución</th><th>Forma</th><th>Llegada</th><th>Salida</th><th>Excusa</th><th /></tr></thead>
            <tbody>
              {asis.map((a, i) => (
                <tr key={a.id_asistente}>
                  <td><input type="checkbox" checked={!!a.asistio} disabled={!editable} onChange={(e) => cambioAsis(i, "asistio", e.target.checked)} aria-label={`Asistió ${a.nombre}`} /></td>
                  <td>{a.nombre}<br /><small className="tenue">{a.documento}</small></td>
                  <td>{a.calidad === "DIRECTIVO" ? "Directivo" : "Invitado"}</td>
                  <td>{[a.cargo, a.institucion].filter(Boolean).join(" · ") || "—"}</td>
                  <td>{editable && a.asistio
                    ? <select value={a.modalidad_asistencia || ""} onChange={(e) => cambioAsis(i, "modalidad_asistencia", e.target.value || null)} aria-label="Forma de asistencia">
                        <option value="">—</option><option value="PRESENCIAL">Presencial</option><option value="VIRTUAL">Virtual</option></select>
                    : (a.modalidad_asistencia || "—").toLowerCase()}</td>
                  <td>{editable && a.asistio ? <input type="time" value={(a.hora_llegada || "").slice(0, 5)} onChange={(e) => cambioAsis(i, "hora_llegada", e.target.value || null)} aria-label="Hora de llegada" /> : hora(a.hora_llegada)}</td>
                  <td>{editable && a.asistio ? <input type="time" value={(a.hora_salida || "").slice(0, 5)} onChange={(e) => cambioAsis(i, "hora_salida", e.target.value || null)} aria-label="Hora de salida" /> : hora(a.hora_salida)}</td>
                  <td>{editable && !a.asistio ? <input value={a.excusa || ""} placeholder="Sin excusa" onChange={(e) => cambioAsis(i, "excusa", e.target.value)} aria-label="Excusa" /> : a.excusa || "—"}</td>
                  <td>{editable && a.calidad === "INVITADO" && <button className="btn-icono" title="Quitar invitado" onClick={borrar("reunion_asistentes", "id_asistente", a)}>×</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Orden del día */}
      <div className="seccion">
        <div className="seccion-cab">
          <h2>Orden del día</h2>
          {editable && <button className="btn btn-sm" onClick={() => setModal({ punto: { orden: (d.puntos.at(-1)?.orden || 0) + 1, tema: "", desarrollo: "" } })}>+ Punto</button>}
        </div>
        {d.orden_del_dia_modificado && <p className="tenue pequeno">Modificado al iniciar la reunión. Convocado: {r.orden_del_dia_convocado.map((p) => `${p.orden}. ${p.tema}`).join(" · ")}</p>}
        <ol className="puntos">
          {d.puntos.map((p) => (
            <li key={p.id_punto} value={p.orden}>
              <strong>{p.tema}</strong>
              {editable && <span className="acciones-linea">
                <button className="btn btn-sm" onClick={() => setModal({ punto: p })}>Desarrollo</button>
                <button className="btn-icono" title="Quitar punto" onClick={borrar("reunion_puntos", "id_punto", p)}>×</button></span>}
              {p.desarrollo && <p className="desarrollo">{p.desarrollo}</p>}
            </li>
          ))}
        </ol>
      </div>

      {/* Decisiones */}
      <div className="seccion">
        <div className="seccion-cab">
          <h2>Decisiones</h2>
          {editable && <button className="btn btn-sm" onClick={() => setModal("decision")} disabled={!q.hay_quorum && presentes < q.requerido}
            title={presentes < q.requerido ? "Sin quórum no se adoptan decisiones" : ""}>+ Decisión</button>}
        </div>
        <div className="tabla-marco">
          <table className="tabla">
            <thead><tr><th>Punto</th><th>Decisión</th><th className="num">A favor</th><th className="num">En contra</th><th className="num">Abst.</th><th>Resultado</th><th>Compromiso</th><th /></tr></thead>
            <tbody>
              {d.decisiones.map((x) => (
                <tr key={x.id_decision}>
                  <td>{x.orden_punto || "—"}</td><td>{x.texto}</td><td className="num">{x.votos_favor}</td><td className="num">{x.votos_contra}</td><td className="num">{x.abstenciones}</td>
                  <td>{x.aprobada ? "Aprobada" : "No aprobada"}</td>
                  <td>{x.compromiso_titulo ? `${x.compromiso_titulo} — ${x.responsable}, hasta ${formatear(x.fecha_limite, "date")}` : "—"}</td>
                  <td>{editable && <button className="btn-icono" title="Quitar" onClick={borrar("reunion_decisiones", "id_decision", x)}>×</button>}</td>
                </tr>
              ))}
              {d.decisiones.length === 0 && <tr><td colSpan={8} className="vacio">Sin decisiones.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cierre */}
      <div className="seccion">
        <h2>Acta anterior, cierre y firmas</h2>
        <div className="rejilla-campos">
          <div className="campo"><label htmlFor="r-aa">¿Se aprueba el acta anterior?</label>
            <label className="interruptor"><input id="r-aa" type="checkbox" checked={r.aprueba_acta_anterior} disabled={!editable}
              onChange={(e) => guardarReunion({ aprueba_acta_anterior: e.target.checked })} /><span>{r.aprueba_acta_anterior ? "Sí" : "No"}</span></label>
            <small className="ayuda">Con quórum, al cerrar esta acta queda aprobada la anterior de la junta.</small></div>
          <div className="campo"><label htmlFor="r-hf">Hora de finalización</label>
            <input id="r-hf" type="time" defaultValue={(r.hora_fin || "").slice(0, 5)} disabled={!editable}
              onBlur={(e) => e.target.value && e.target.value !== (r.hora_fin || "").slice(0, 5) && guardarReunion({ hora_fin: e.target.value })} /></div>
          <div className="campo campo-ancho"><label htmlFor="r-obs">Observaciones al acta anterior</label>
            <textarea id="r-obs" rows={2} defaultValue={r.observaciones_acta_anterior || ""} disabled={!editable}
              onBlur={(e) => e.target.value !== (r.observaciones_acta_anterior || "") && guardarReunion({ observaciones_acta_anterior: e.target.value })} /></div>
        </div>
        <div className="firmas">
          {["PRESIDENCIA", "SECRETARIA"].map((rol) => {
            const f = d.firmas.find((x) => x.rol === rol);
            return (
              <div key={rol} className={`firma ${f ? "firmada" : ""}`}>
                <small>{rol === "PRESIDENCIA" ? "Presidencia" : "Secretaría General"}</small>
                {f ? <><strong>{f.nombre}</strong><span>{f.cargo}</span><span className="tenue">{formatear(f.fecha, "datetime")}</span></> : <span className="tenue">Firma pendiente</span>}
              </div>
            );
          })}
        </div>
        {r.id_reunion_aprobacion && <p className="tenue">Aprobada en la reunión del {formatear(r.fecha_aprobacion, "date")}. <a href={`#/reunion/${r.id_reunion_aprobacion}`}>Ver reunión</a></p>}
      </div>

      {modal === "invitado" && <InvitadoModal idReunion={id} onCerrar={() => setModal(null)} onListo={() => { setModal(null); cargar(); }} />}
      {modal === "decision" && <DecisionModal idReunion={id} puntos={d.puntos} onCerrar={() => setModal(null)} onListo={() => { setModal(null); cargar(); }} />}
      {modal?.punto && <PuntoModal idReunion={id} punto={modal.punto} onCerrar={() => setModal(null)} onListo={() => { setModal(null); cargar(); }} />}
    </section>
  );
}

function FormModal({ titulo, onCerrar, onEnviar, children }) {
  const [error, setError] = useState("");
  const enviar = async (e) => { e.preventDefault(); setError(""); try { await onEnviar(); } catch (e2) { setError(e2.message); } };
  return (
    <Modal titulo={titulo} onCerrar={onCerrar}
      pie={<><span className="espacio" /><button className="btn" onClick={onCerrar}>Cancelar</button><button className="btn btn-primario" form="f-modal">Guardar</button></>}>
      <form id="f-modal" onSubmit={enviar}><Aviso tipo="error">{error}</Aviso><div className="rejilla-campos">{children}</div></form>
    </Modal>
  );
}

function InvitadoModal({ idReunion, onCerrar, onListo }) {
  const [externo, setExterno] = useState(true);
  const [f, setF] = useState({ asistio: true, modalidad_asistencia: "PRESENCIAL" });
  const c = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <FormModal titulo="Agregar invitado" onCerrar={onCerrar} onEnviar={async () => {
      const datos = { ...f, id_reunion: idReunion };
      if (externo) delete datos.id_persona; else { delete datos.nombre_invitado; delete datos.documento_invitado; delete datos.correo_invitado; }
      await api.post("/api/r/reunion_asistentes", datos); onListo();
    }}>
      <div className="campo campo-ancho">
        <label className="interruptor"><input type="checkbox" checked={externo} onChange={(e) => setExterno(e.target.checked)} />
          <span>{externo ? "Invitado externo (no registrado en el sistema)" : "Persona registrada en el sistema"}</span></label>
      </div>
      {externo ? <>
        <div className="campo"><label htmlFor="i-n">Nombre completo</label><input id="i-n" required onChange={c("nombre_invitado")} /></div>
        <div className="campo"><label htmlFor="i-d">Documento</label><input id="i-d" onChange={c("documento_invitado")} /></div>
        <div className="campo"><label htmlFor="i-c">Correo</label><input id="i-c" type="email" onChange={c("correo_invitado")} /></div>
      </> : <div className="campo"><label htmlFor="i-p">Persona</label>
        <SelectorFK id="i-p" recurso="personas" valor={f.id_persona} requerido onCambio={(v) => setF({ ...f, id_persona: v })} /></div>}
      <div className="campo"><label htmlFor="i-i">Institución u organización</label><input id="i-i" onChange={c("institucion")} /></div>
      <div className="campo"><label htmlFor="i-g">Cargo o calidad en que asiste</label><input id="i-g" onChange={c("cargo")} /></div>
      <div className="campo"><label htmlFor="i-m">Asistió de forma</label>
        <select id="i-m" value={f.modalidad_asistencia} onChange={c("modalidad_asistencia")}><option value="PRESENCIAL">Presencial</option><option value="VIRTUAL">Virtual</option></select></div>
      <div className="campo"><label htmlFor="i-h">Hora de llegada</label><input id="i-h" type="time" onChange={c("hora_llegada")} /></div>
    </FormModal>
  );
}

function PuntoModal({ idReunion, punto, onCerrar, onListo }) {
  const [f, setF] = useState({ orden: punto.orden, tema: punto.tema, desarrollo: punto.desarrollo || "" });
  return (
    <FormModal titulo={punto.id_punto ? `Punto ${punto.orden}` : "Nuevo punto del orden del día"} onCerrar={onCerrar} onEnviar={async () => {
      if (punto.id_punto) await api.put("/api/r/reunion_puntos/registro", { ...f, version: punto.version }, { id_punto: punto.id_punto });
      else await api.post("/api/r/reunion_puntos", { ...f, id_reunion: idReunion });
      onListo();
    }}>
      <div className="campo"><label htmlFor="p-o">N.º</label><input id="p-o" type="number" min="1" value={f.orden} onChange={(e) => setF({ ...f, orden: Number(e.target.value) })} required /></div>
      <div className="campo"><label htmlFor="p-t">Tema</label><input id="p-t" value={f.tema} onChange={(e) => setF({ ...f, tema: e.target.value })} required /></div>
      <div className="campo campo-ancho"><label htmlFor="p-d">Desarrollo</label><textarea id="p-d" rows={8} value={f.desarrollo} onChange={(e) => setF({ ...f, desarrollo: e.target.value })} /></div>
    </FormModal>
  );
}

function DecisionModal({ idReunion, puntos, onCerrar, onListo }) {
  const [f, setF] = useState({ votos_favor: 0, votos_contra: 0, abstenciones: 0 });
  const [comp, setComp] = useState(false);
  const c = (k, num) => (e) => setF({ ...f, [k]: num ? Number(e.target.value) : e.target.value });
  return (
    <FormModal titulo="Registrar decisión" onCerrar={onCerrar} onEnviar={async () => {
      const datos = { ...f, id_reunion: idReunion };
      if (!comp) { delete datos.compromiso_titulo; delete datos.id_persona_responsable; delete datos.fecha_limite; }
      await api.post("/api/r/reunion_decisiones", datos); onListo();
    }}>
      <div className="campo"><label htmlFor="d-p">Punto</label>
        <select id="d-p" onChange={(e) => setF({ ...f, id_punto: e.target.value ? Number(e.target.value) : null })}>
          <option value="">(Sin punto)</option>{puntos.map((p) => <option key={p.id_punto} value={p.id_punto}>{p.orden}. {p.tema}</option>)}</select></div>
      <div className="campo campo-ancho"><label htmlFor="d-t">Decisión</label><textarea id="d-t" rows={3} required onChange={c("texto")} /></div>
      <div className="campo"><label htmlFor="d-f">Votos a favor</label><input id="d-f" type="number" min="0" value={f.votos_favor} onChange={c("votos_favor", 1)} /></div>
      <div className="campo"><label htmlFor="d-c">Votos en contra</label><input id="d-c" type="number" min="0" value={f.votos_contra} onChange={c("votos_contra", 1)} /></div>
      <div className="campo"><label htmlFor="d-a">Abstenciones</label><input id="d-a" type="number" min="0" value={f.abstenciones} onChange={c("abstenciones", 1)} /></div>
      <div className="campo"><label className="interruptor"><input type="checkbox" checked={comp} onChange={(e) => setComp(e.target.checked)} /><span>Genera un compromiso</span></label></div>
      {comp && <>
        <div className="campo campo-ancho"><label htmlFor="d-ct">Compromiso</label><input id="d-ct" required onChange={c("compromiso_titulo")} /></div>
        <div className="campo"><label htmlFor="d-r">Responsable</label><SelectorFK id="d-r" recurso="personas" requerido valor={f.id_persona_responsable} onCambio={(v) => setF({ ...f, id_persona_responsable: v })} /></div>
        <div className="campo"><label htmlFor="d-l">Fecha límite</label><input id="d-l" type="date" required onChange={c("fecha_limite")} /></div>
      </>}
    </FormModal>
  );
}
