import { useEffect, useMemo, useState } from "react";
import { api } from "./api.js";
import { Aviso, Cargando, formatear, Insignia, titular } from "./ui.jsx";

const NIVELES = ["CRÍTICA", "ALTA", "MEDIA", "BAJA"];
const DINERO = /(saldo|valor|aporte|ingreso|egreso|esperado|consignado|diferencia|aprobado|ejecutado|disponible|resultado|extracto|monto|suma)/;
const visibles = (cols) => cols.filter((c) => !c.startsWith("id_"));
const celda = (col, v) => (DINERO.test(col) && v !== null && v !== "" && !isNaN(Number(v)) ? formatear(v, "decimal") : formatear(v));

export function Tablero({ usuario, ir }) {
  const [datos, setDatos] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => { api.get("/api/tablero").then(setDatos).catch((e) => setError(e.message)); }, []);

  const totales = useMemo(() => {
    const t = { "CRÍTICA": 0, ALTA: 0, MEDIA: 0 };
    (datos || []).forEach((v) => Object.keys(t).forEach((n) => (t[n] += v.conteo[n])));
    return t;
  }, [datos]);

  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <h1>Buen día, {usuario.nombre_completo.split(" ")[0]}</h1>
          <p className="tenue">Resumen de alertas de control interno según su rol ({usuario.codigo_rol}).</p>
        </div>
      </header>
      <Aviso tipo="error">{error}</Aviso>
      {!datos && !error && <Cargando />}
      {datos && datos.length === 0 && <Aviso tipo="info">Su rol no tiene acceso a vistas de alertas. Use el menú para consultar la información.</Aviso>}
      {datos && datos.length > 0 && (
        <>
          <div className="kpis">
            <div className="kpi kpi-critica"><span>{totales["CRÍTICA"]}</span>Alertas críticas</div>
            <div className="kpi kpi-alta"><span>{totales.ALTA}</span>Alertas altas</div>
            <div className="kpi kpi-media"><span>{totales.MEDIA}</span>Alertas medias</div>
          </div>
          <div className="tarjetas">
            {datos.map((v) => {
              const alertas = NIVELES.reduce((s, n) => s + v.conteo[n], 0);
              return (
                <button key={v.clave} className="tarjeta" onClick={() => ir(`/v/${v.clave}`)}>
                  <div className="tarjeta-cab">
                    <strong>{v.titulo}</strong>
                    <span className="tenue">{v.modulo.toLowerCase()}</span>
                  </div>
                  <div className="barra" aria-label={`${alertas} alertas de ${v.total}`}>
                    {NIVELES.map((n) => v.conteo[n] > 0 && (
                      <span key={n} className={`seg seg-${n === "CRÍTICA" ? "critica" : n.toLowerCase()}`} style={{ flex: v.conteo[n] }} />
                    ))}
                    {v.conteo.NORMAL > 0 && <span className="seg seg-normal" style={{ flex: v.conteo.NORMAL }} />}
                  </div>
                  <div className="tarjeta-pie">
                    {NIVELES.filter((n) => v.conteo[n] > 0).map((n) => <span key={n}><Insignia nivel={n} /> {v.conteo[n]}</span>)}
                    {alertas === 0 && <span className="tenue">Sin alertas · {v.total} registro(s)</span>}
                  </div>
                </button>
              );
            })}
          </div>
        </>
      )}
    </section>
  );
}

export function VistaPagina({ clave }) {
  const [datos, setDatos] = useState(null);
  const [error, setError] = useState("");
  const [q, setQ] = useState("");
  const [nivel, setNivel] = useState("");

  const cargar = () => { setDatos(null); setError(""); api.get(`/api/vistas/${clave}`).then(setDatos).catch((e) => setError(e.message)); };
  useEffect(cargar, [clave]);

  const filas = useMemo(() => {
    if (!datos) return [];
    const t = q.toLowerCase();
    return datos.filas.filter((f) => (!nivel || f._nivel === nivel) &&
      (!t || datos.columnas.some((c) => String(f[c] ?? "").toLowerCase().includes(t))));
  }, [datos, q, nivel]);

  const exportarCSV = () => {
    const esc = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const csv = [datos.columnas.map(esc).join(";"), ...filas.map((f) => datos.columnas.map((c) => esc(f[c])).join(";"))].join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" }));
    a.download = `${clave}_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    // Ley 1581: la exportación queda en la bitácora de accesos
    api.post("/api/privacidad/exportacion", { origen: `vista:${clave}`, registros: filas.length, detalle: "CSV" }).catch(() => {});
  };

  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <h1>{datos?.titulo || "Vista"}</h1>
          {datos?.descripcion && <p className="tenue">{datos.descripcion}</p>}
        </div>
        <div className="acciones">
          <input className="buscador" type="search" placeholder="Filtrar…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Filtrar" />
          {datos?.columna_diagnostico && (
            <select value={nivel} onChange={(e) => setNivel(e.target.value)} aria-label="Nivel de alerta">
              <option value="">Todos los niveles</option>
              {[...NIVELES, "NORMAL"].map((n) => <option key={n} value={n}>{n === "NORMAL" ? "Normal" : `Alerta ${n.toLowerCase()}`}</option>)}
            </select>
          )}
          <button className="btn" onClick={cargar} title="Recargar">⟳</button>
          {datos && <button className="btn" onClick={exportarCSV}>Exportar CSV</button>}
          {datos && <button className="btn" onClick={() => window.print()}>Imprimir / PDF</button>}
        </div>
      </header>
      <Aviso tipo="error">{error}</Aviso>
      {!datos && !error && <Cargando />}
      {datos && (
        <div className="tabla-marco">
          <table className="tabla">
            <thead>
              <tr>
                {datos.columna_diagnostico && <th>Nivel</th>}
                {visibles(datos.columnas).map((c) => <th key={c} className={DINERO.test(c) ? "num" : ""}>{titular(c)}</th>)}
              </tr>
            </thead>
            <tbody>
              {filas.map((f, i) => (
                <tr key={i} className={`fila-${f._nivel === "CRÍTICA" ? "critica" : f._nivel.toLowerCase()}`}>
                  {datos.columna_diagnostico && <td><Insignia nivel={f._nivel} /></td>}
                  {visibles(datos.columnas).map((c) => <td key={c} className={DINERO.test(c) ? "num" : ""}>{celda(c, f[c])}</td>)}
                </tr>
              ))}
              {filas.length === 0 && <tr><td colSpan={datos.columnas.length + 1} className="vacio">Sin resultados.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
      {datos && <p className="tenue pie-tabla">{filas.length} de {datos.filas.length} fila(s)</p>}
    </section>
  );
}
