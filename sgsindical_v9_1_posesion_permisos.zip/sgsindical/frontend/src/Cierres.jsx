import { useEffect, useState } from "react";
import { api } from "./api.js";
import { Aviso, Cargando, cargarEtiquetas, formatear, SelectorFK } from "./ui.jsx";

const MESES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];

export function CierresPagina({ usuario }) {
  const hoy = new Date();
  const anterior = new Date(hoy.getFullYear(), hoy.getMonth() - 1, 1);
  const [estamento, setEstamento] = useState(null);
  const [anio, setAnio] = useState(anterior.getFullYear());
  const [mes, setMes] = useState(anterior.getMonth() + 1);
  const [cierres, setCierres] = useState(null);
  const [nombres, setNombres] = useState({});
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const esAdmin = usuario.codigo_rol === "ADMIN";

  const cargar = () => api.get("/api/r/cierres", { tam: 100, f_id_estamento: estamento || undefined })
    .then(async (r) => { setCierres(r.filas); setNombres({ ...(await cargarEtiquetas("estamentos", r.filas.map((c) => c.id_estamento))) }); })
    .catch((e) => setMsg({ tipo: "error", texto: e.message }));
  useEffect(() => { cargar(); }, [estamento]);

  const cerrar = async () => {
    if (!window.confirm(`¿Cerrar ${MESES[mes - 1]} de ${anio}? Después no se podrán registrar ni modificar movimientos de ese mes.`)) return;
    try {
      const r = await api.post("/api/finanzas/cierres", { id_estamento: estamento, anio, mes });
      setMsg({ tipo: "exito", texto: `Mes cerrado. Saldo del fondo al cierre: ${formatear(r.saldo_fondo, "decimal")}.` }); cargar();
    } catch (e) { setMsg({ tipo: "error", texto: e.message }); }
  };
  const reabrir = async (c) => {
    const motivo = window.prompt("Motivo de la reapertura (queda en la auditoría):"); if (!motivo) return;
    try { await api.post(`/api/finanzas/cierres/${c.id_cierre}/reabrir`, { motivo }); setMsg({ tipo: "exito", texto: "Mes reabierto." }); cargar(); }
    catch (e) { setMsg({ tipo: "error", texto: e.message }); }
  };

  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <h1>Cierre mensual</h1>
          <p className="tenue">Al cerrar un mes, sus ingresos, egresos, consignaciones y transferencias quedan congelados. Lo cierra el Tesorero de la junta (en comités, el Secretario General); solo el administrador puede reabrirlo, con motivo.</p>
        </div>
      </header>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      <div className="rejilla-campos" style={{ maxWidth: 820, marginBottom: 12 }}>
        <div className="campo"><label htmlFor="c_est">Junta</label><SelectorFK id="c_est" recurso="estamentos" valor={estamento} requerido onCambio={setEstamento} /></div>
        <div className="campo"><label htmlFor="c_mes">Mes</label>
          <div className="acciones">
            <select id="c_mes" value={mes} onChange={(e) => setMes(Number(e.target.value))} style={{ width: "auto" }}>{MESES.map((m, i) => <option key={m} value={i + 1}>{m}</option>)}</select>
            <input type="number" value={anio} onChange={(e) => setAnio(Number(e.target.value))} style={{ width: 100 }} aria-label="Año" />
            <button className="btn btn-primario" disabled={!estamento} onClick={cerrar}>Cerrar mes</button>
          </div>
        </div>
      </div>
      {!cierres ? <Cargando /> : (
        <div className="tabla-marco">
          <table className="tabla">
            <thead><tr><th>Junta</th><th>Periodo</th><th className="num">Saldo del fondo</th><th>Cerrado</th><th>Por</th><th>Estado</th><th /></tr></thead>
            <tbody>
              {cierres.map((c) => (
                <tr key={c.id_cierre}>
                  <td>{nombres[String(c.id_estamento)] || `#${c.id_estamento}`}</td><td>{MESES[c.mes - 1]} {c.anio}</td><td className="num">{formatear(c.saldo_fondo, "decimal")}</td>
                  <td>{formatear(c.fecha_cierre)}</td><td>{c.usuario_cierre}</td>
                  <td>{c.reabierto ? <span className="tenue">Reabierto: {c.motivo_reapertura}</span> : "Cerrado"}</td>
                  <td>{esAdmin && !c.reabierto && <button className="btn btn-sm" onClick={() => reabrir(c)}>Reabrir</button>}</td>
                </tr>
              ))}
              {cierres.length === 0 && <tr><td colSpan={7} className="vacio">Sin cierres registrados.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
