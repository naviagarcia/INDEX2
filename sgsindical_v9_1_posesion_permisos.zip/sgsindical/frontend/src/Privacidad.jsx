// Protección de datos personales (Ley 1581): datos reservados, bitácora de accesos y acciones del titular.
import { useEffect, useState } from "react";
import { api } from "./api.js";
import { Aviso, Cargando, formatear } from "./ui.jsx";

let estadoCache = null;
export async function estadoPrivacidad() {
  if (!estadoCache) estadoCache = api.get("/api/privacidad/estado").catch(() => ({}));
  return estadoCache;
}

// ------------------------------------------------------------------ dato reservado dentro de un formulario
export function DatoReservado({ meta, fila, campo }) {
  const [valor, setValor] = useState(null);
  const [error, setError] = useState("");
  const ver = async () => {
    const motivo = window.prompt("Motivo de la consulta (opcional). Queda registrada en la bitácora de accesos a datos personales:", "");
    if (motivo === null) return;
    setError("");
    try {
      const pk = Object.fromEntries(meta.pk.map((c) => [c, fila[c]]));
      const r = await api.post("/api/privacidad/revelar", { recurso: meta.clave, pk, motivo: motivo || null });
      setValor(r.valor ?? "— (sin dato)");
    } catch (e) { setError(e.message); }
  };
  return (
    <div className="dato-reservado">
      {valor !== null
        ? <span><strong>{campo.tipo === "decimal" ? formatear(valor, "decimal") : valor}</strong> <small className="tenue">· consulta registrada</small></span>
        : <span className="tenue">•••• Dato reservado (Ley 1581)</span>}
      {valor === null && fila._puede_ver_reservado && <button type="button" className="btn btn-sm" onClick={ver}>Ver (queda registrado)</button>}
      {valor === null && !fila._puede_ver_reservado && <small className="tenue">Solo lo ven la Presidencia y la Secretaría General{campo.sensible === "SALARIO" ? " o Tesorería" : ""}.</small>}
      {error && <small className="error-texto">{error}</small>}
    </div>
  );
}

// ------------------------------------------------------------------ acciones en las fichas
export function AccionesPrivacidad({ meta, fila, permisos, recargar, avisar, intentar }) {
  const [estado, setEstado] = useState({});
  useEffect(() => { estadoPrivacidad().then(setEstado); }, []);
  const puede = (m, a) => !!permisos[m]?.[a];
  const pedir = (texto) => { const m = window.prompt(texto); return m && m.trim() ? m.trim() : null; };

  if (meta.clave === "personas") {
    return (
      <>
        <LeyendaReclamo idPersona={fila.id_persona} />
        <button className="btn" onClick={intentar(async () => {
          const b = await api.descargar(`/api/privacidad/personas/${fila.id_persona}/reporte`);
          const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = `datos_personales_${fila.id_persona}.pdf`; a.click();
          avisar("exito", "Reporte generado. La consulta quedó registrada en la bitácora de accesos.");
        })} title="Todo lo que el sindicato tiene registrado sobre esta persona y quién lo ha consultado">Reporte de datos del titular (PDF)</button>
        {estado.es_admin && fila.activo === false && !String(fila.dni).startsWith("ANON-") && (
          <button className="btn btn-peligro" onClick={intentar(async () => {
            const motivo = pedir("Motivo de la anonimización (supresión de datos). La debe aprobar la Presidencia Nacional:"); if (!motivo) return;
            const r = await api.post("/api/privacidad/anonimizaciones", { id_persona: fila.id_persona, motivo });
            avisar("exito", r.mensaje);
          })}>Solicitar anonimización</button>
        )}
      </>
    );
  }
  if (meta.clave === "anonimizaciones" && fila.estado === "PENDIENTE" && estado.es_presidente_nacional) {
    return (
      <>
        <button className="btn btn-peligro" onClick={intentar(async () => {
          if (!window.confirm("¿Aprobar la anonimización? Los datos que identifican a la persona se reemplazan y NO se pueden recuperar.")) return;
          await api.post(`/api/privacidad/anonimizaciones/${fila.id_anonimizacion}/aprobar`, {});
          avisar("exito", "Anonimización ejecutada."); await recargar();
        })}>Aprobar y anonimizar</button>
        <button className="btn" onClick={intentar(async () => {
          const observacion = pedir("Motivo del rechazo:"); if (!observacion) return;
          await api.post(`/api/privacidad/anonimizaciones/${fila.id_anonimizacion}/rechazar`, { observacion });
          avisar("exito", "Solicitud rechazada."); await recargar();
        })}>Rechazar</button>
      </>
    );
  }
  if (meta.clave === "autorizaciones_datos" && fila.estado === "VIGENTE" && puede("GOBERNANZA", "actualizar")) {
    return <button className="btn btn-peligro" onClick={intentar(async () => {
      const motivo = pedir("Motivo de la revocación (lo que manifestó el titular):"); if (!motivo) return;
      await api.post(`/api/privacidad/autorizaciones/${fila.id_autorizacion}/revocar`, { motivo });
      avisar("exito", "Autorización revocada."); await recargar();
    })}>Revocar</button>;
  }
  if (meta.clave === "textos_institucionales" && !fila.fecha_vigencia && (estado.es_admin || estado.es_presidente_nacional)) {
    return <button className="btn btn-primario" onClick={intentar(async () => {
      if (!window.confirm("¿Publicar esta versión? Reemplaza a la vigente, queda a la vista del público y ya no se podrá modificar.")) return;
      await api.post(`/api/privacidad/textos/${fila.id_texto}/publicar`);
      avisar("exito", "Versión publicada y vigente."); await recargar();
    })}>Publicar</button>;
  }
  if (meta.clave === "politicas_tratamiento" && !fila.fecha_vigencia && (estado.es_admin || estado.es_presidente_nacional)) {
    return <button className="btn btn-primario" onClick={intentar(async () => {
      if (!window.confirm("¿Publicar esta versión? Reemplaza a la vigente y ya no se podrá modificar. Las autorizaciones anteriores quedarán desactualizadas.")) return;
      await api.post(`/api/privacidad/politicas/${fila.id_politica}/publicar`);
      avisar("exito", "Versión publicada y vigente."); await recargar();
    })}>Publicar</button>;
  }
  if (meta.clave === "solicitudes_titular" && fila.estado === "REQUERIDA" && puede("GOBERNANZA", "actualizar")) {
    const vencido = fila.fecha_limite_completar && new Date() > new Date(`${fila.fecha_limite_completar}T23:59:59`);
    return (
      <>
        {!vencido && <button className="btn btn-primario" onClick={intentar(async () => {
          const detalle = pedir("Qué aportó el titular para completar el reclamo (el plazo de 15 días hábiles empieza al día siguiente):"); if (!detalle) return;
          const r = await api.post(`/api/privacidad/solicitudes/${fila.id_solicitud}/completar`, { detalle });
          avisar("exito", `Reclamo completo. Debe responderse a más tardar el ${r.fecha_limite}.`); await recargar();
        })}>Llegó lo que faltaba</button>}
        {vencido && <button className="btn btn-peligro" onClick={intentar(async () => {
          const motivo = pedir("Pasaron 2 meses sin que el titular completara el reclamo (Ley 1581, art. 15). Decisión:"); if (!motivo) return;
          await api.post(`/api/privacidad/solicitudes/${fila.id_solicitud}/desistir`, { motivo });
          avisar("exito", "Desistimiento registrado. Comuníqueselo al titular."); await recargar();
        })}>Declarar desistimiento</button>}
      </>
    );
  }
  if (meta.clave === "solicitudes_titular" && ["RADICADA", "EN_TRAMITE"].includes(fila.estado) && puede("GOBERNANZA", "actualizar")) {
    return (
      <>
        <button className="btn btn-primario" onClick={intentar(async () => {
          const respuesta = pedir("Respuesta dada al titular (resumen; si hay un documento, radíquelo y asócielo):"); if (!respuesta) return;
          await api.post(`/api/privacidad/solicitudes/${fila.id_solicitud}/responder`, { respuesta });
          avisar("exito", "Solicitud respondida."); await recargar();
        })}>Registrar respuesta</button>
        {!fila.prorrogada && <button className="btn" onClick={intentar(async () => {
          const motivo = pedir("Motivo de la prórroga (debe informarse al titular antes del vencimiento):"); if (!motivo) return;
          const r = await api.post(`/api/privacidad/solicitudes/${fila.id_solicitud}/prorrogar`, { motivo });
          avisar("exito", `Prorrogada hasta el ${r.fecha_limite}.`); await recargar();
        })}>Prorrogar</button>}
        {fila.tipo !== "CONSULTA" && !fila.fecha_requerimiento && !fila.prorrogada && <button className="btn" onClick={intentar(async () => {
          const texto = pedir("El reclamo está incompleto. Qué debe completar el titular (se le pide dentro de los 5 días hábiles siguientes al recibo; tendrá 2 meses):"); if (!texto) return;
          const r = await api.post(`/api/privacidad/solicitudes/${fila.id_solicitud}/requerir`, { texto });
          avisar("exito", `Requerimiento registrado; el titular tiene hasta el ${r.fecha_limite_completar}. Comuníqueselo.`); await recargar();
        })}>Pedir completar</button>}
        <button className="btn" onClick={intentar(async () => {
          const entidad = pedir("El sindicato no es competente. ¿A quién se traslada (entidad responsable de esos datos)?"); if (!entidad) return;
          const motivo = pedir("Por qué el sindicato no es competente (se informa al titular):"); if (!motivo) return;
          const r = await api.post(`/api/privacidad/solicitudes/${fila.id_solicitud}/trasladar`, { entidad, motivo });
          avisar(r.tardio ? "advertencia" : "exito", r.tardio ? "Trasladada, pero después de los 2 días hábiles que fija la ley. Informe al titular." : "Trasladada. Informe al titular.");
          await recargar();
        })}>Trasladar</button>
      </>
    );
  }
  return null;
}

// Ley 1581, art. 15, num. 2: «reclamo en trámite» sobre los datos de la persona mientras no se decida
function LeyendaReclamo({ idPersona }) {
  const [filas, setFilas] = useState([]);
  useEffect(() => { if (idPersona) api.get(`/api/privacidad/personas/${idPersona}/leyenda`).then(setFilas).catch(() => setFilas([])); }, [idPersona]);
  if (!filas.length) return null;
  return (
    <div className="aviso aviso-advertencia leyenda-reclamo" role="status">
      <strong>Reclamo en trámite</strong> (Ley 1581, art. 15): {filas.map((l) => `${l.radicado} · ${l.tipo.toLowerCase()}: ${l.motivo}`).join(" | ")}.
      {" "}Los datos de esta persona están en discusión hasta que se decida.
    </div>
  );
}

// ------------------------------------------------------------------ bitácora de accesos a datos personales
export function BitacoraAccesosPagina({ usuario }) {
  const [filtro, setFiltro] = useState({ usuario: "", desde: "", hasta: "" });
  const [filas, setFilas] = useState(null);
  const [msg, setMsg] = useState({ tipo: "info", texto: "" });
  const cargar = async () => {
    setMsg({ tipo: "info", texto: "" });
    try {
      const q = Object.fromEntries(Object.entries(filtro).filter(([, v]) => v));
      setFilas(await api.get("/api/privacidad/bitacora", { ...q, limite: 1000 }));
    } catch (e) { setFilas([]); setMsg({ tipo: "error", texto: e.message }); }
  };
  useEffect(() => { cargar(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const purgar = async () => {
    if (!window.confirm("¿Purgar los registros con más antigüedad que la permitida (5 años por defecto)? Los backups anteriores los conservan.")) return;
    try { const r = await api.post("/api/privacidad/bitacora/purgar"); setMsg({ tipo: "exito", texto: `${r.purgados} registro(s) purgados.` }); cargar(); }
    catch (e) { setMsg({ tipo: "error", texto: e.message }); }
  };
  const TIPOS = { FICHA: "Abrió la ficha", LISTADO: "Consultó un listado", VER_DATO: "Vio un dato reservado", EXPORTACION: "Exportó",
    REPORTE_TITULAR: "Generó el reporte del titular", ANONIMIZACION: "Anonimizó", PURGA: "Purgó la bitácora" };
  return (
    <section className="pagina">
      <header className="pagina-cab">
        <div>
          <h1>Bitácora de accesos a datos personales</h1>
          <p className="tenue">Ley 1581: quién consultó datos de qué persona, cuándo, desde dónde y por qué. Es inmutable; solo la ven el administrador y la Presidencia Nacional.</p>
        </div>
        <div className="acciones">
          <input className="buscador" placeholder="Usuario" value={filtro.usuario} onChange={(e) => setFiltro({ ...filtro, usuario: e.target.value })} />
          <input type="date" value={filtro.desde} onChange={(e) => setFiltro({ ...filtro, desde: e.target.value })} aria-label="Desde" />
          <input type="date" value={filtro.hasta} onChange={(e) => setFiltro({ ...filtro, hasta: e.target.value })} aria-label="Hasta" />
          <button className="btn btn-primario" onClick={cargar}>Filtrar</button>
          {usuario.codigo_rol === "ADMIN" && <button className="btn" onClick={purgar}>Purgar antiguos</button>}
        </div>
      </header>
      <Aviso tipo={msg.tipo} onCerrar={() => setMsg({ tipo: "info", texto: "" })}>{msg.texto}</Aviso>
      <div className="tabla-marco">
        {filas === null ? <Cargando /> : (
          <table className="tabla">
            <thead><tr><th>Fecha</th><th>Usuario</th><th>IP</th><th>Acción</th><th>Sobre</th><th>Persona</th><th>Registros</th><th>Motivo</th></tr></thead>
            <tbody>
              {filas.map((f) => (
                <tr key={f.id_acceso_dato}>
                  <td>{formatear(f.fecha_hora, "datetime")}</td><td>{f.nombre_usuario}</td><td>{f.ip_origen || "—"}</td>
                  <td>{TIPOS[f.tipo] || f.tipo}</td><td>{f.recurso}{f.campos ? ` (${f.campos.join(", ")})` : ""}</td>
                  <td>{f.persona || "—"}</td><td className="num">{f.n_registros ?? "—"}</td><td>{f.motivo || "—"}</td>
                </tr>
              ))}
              {filas.length === 0 && <tr><td colSpan={8} className="vacio">Sin registros con esos filtros.</td></tr>}
            </tbody>
          </table>
        )}
      </div>
    </section>
  );
}
