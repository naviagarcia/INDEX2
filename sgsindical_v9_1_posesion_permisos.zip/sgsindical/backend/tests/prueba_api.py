"""Pruebas de extremo a extremo de la API contra una base PostgreSQL real con los scripts 01-04 cargados.

    DATABASE_URL=postgresql://sgs_app:...@localhost/sgsindical \
    BACKUP_DATABASE_URL=postgresql://sgs_backup:...@localhost/sgsindical \
    python -m tests.prueba_api
"""
from __future__ import annotations

import concurrent.futures as cf
import os
import re
import tempfile

os.environ.setdefault("UPLOAD_DIR", tempfile.mkdtemp())
os.environ.setdefault("BACKUP_DIR", tempfile.mkdtemp())
os.environ.setdefault("IA_PROVEEDOR", "simulado")
os.environ.setdefault("TRANSCRIPCION", "simulada")
os.environ.setdefault("SECRETOS_LLAVE", "q2b6o0Yb3f3m1x9pX6u8b6x1e2Q0dWc0Zl9YbW1wbGU=")
# Servidor SMTP local que captura los correos (no sale nada a internet)
os.environ.update({"SMTP_HOST": "127.0.0.1", "SMTP_PORT": "2525", "SMTP_SEGURIDAD": "ninguna",
                   "CORREO_REMITENTE": "alertas@sindicato.test", "SINDICATO_NOMBRE": "Sindicato de Prueba",
                   "APP_URL": "https://sgsindical.test"})

import asyncore  # noqa: E402
import email  # noqa: E402
import smtpd  # noqa: E402
import threading  # noqa: E402
import warnings  # noqa: E402

warnings.filterwarnings("ignore", category=DeprecationWarning)
BUZON: list = []


class Capturador(smtpd.SMTPServer):
    def process_message(self, peer, mailfrom, rcpttos, data, **kw):
        BUZON.append((rcpttos, email.message_from_bytes(data, policy=email.policy.default)))


_servidor_smtp = Capturador(("127.0.0.1", 2525), None, decode_data=False)
threading.Thread(target=asyncore.loop, kwargs={"timeout": 0.2}, daemon=True).start()

from fastapi.testclient import TestClient  # noqa: E402

from app.cli import crear_admin  # noqa: E402
from app.db import abrir_pool  # noqa: E402
from app.main import app  # noqa: E402

CLAVE_ADMIN = "Clave#Segura2026"
ok = 0


def check(cond, msg):
    global ok
    assert cond, msg
    ok += 1
    print("  ✓", msg)


def login(c, u, p, esperado=200):
    r = c.post("/api/auth/login", json={"nombre_usuario": u, "contrasena": p})
    assert r.status_code == esperado, (r.status_code, r.text)
    return r.json()


def auth(token):
    return {"Authorization": f"Bearer {token}"}


def pdf_real(texto="Documento de prueba", paginas=1):
    """PDF válido (el expediente de afiliación cuenta sus páginas)."""
    import io as _io
    from reportlab.pdfgen import canvas as _cv
    b = _io.BytesIO()
    cv = _cv.Canvas(b)
    for i in range(paginas):
        cv.drawString(72, 720, f"{texto} - página {i + 1}")
        cv.showPage()
    cv.save()
    return b.getvalue()


def foto(color="white", formato="JPEG"):
    import io as _io
    from PIL import Image as _Im
    b = _io.BytesIO()
    _Im.new("RGB", (1200, 800), color).save(b, formato)
    return b.getvalue()


with TestClient(app) as c:
    abrir_pool()
    crear_admin("admin", "Administrador", CLAVE_ADMIN)

    print("Seguridad y autenticación")
    check(c.get("/api/r/personas").status_code == 401, "sin token -> 401")
    login(c, "admin", "mala", 401)
    t = login(c, "admin", CLAVE_ADMIN)
    H = auth(t["token"])
    yo = c.get("/api/auth/yo", headers=H).json()
    check(yo["codigo_rol"] == "ADMIN" and len(yo["recursos"]) > 20, "perfil admin con recursos")
    check(c.get("/api/salud").headers["X-Frame-Options"] == "DENY", "cabeceras de seguridad")
    # Lista oficial de municipios: la instala 17b; el administrador puede volver a cargar el archivo del DANE
    _csv = open(os.path.join(os.path.dirname(__file__), "..", "..", "db", "datos", "DIVIPOLA_codigos_municipios.csv"), "rb").read()
    r = c.post("/api/admin/divipola", headers=H, files={"archivo": ("DIVIPOLA.csv", _csv, "text/csv")})
    check(r.status_code == 200 and r.json()["municipios"] == 1122 and r.json()["nuevos"] == 0 and r.json()["inactivados"] == 0
          and r.json()["por_corregir"] == 0,
          "DIVIPOLA instalada (1.122 municipios, áreas no municipalizadas e isla); volver a cargar el archivo del DANE no duplica nada y "
          "los lugares escritos de los datos existentes quedan con código oficial")
    # El nombre del sindicato sale de la base (Datos institucionales), no del código ni del .env
    inst = c.get("/api/publico/institucion").json()
    check(inst["sigla"] == "SINTRACAD" and inst["nit"] == "901.763.807-9" and "Carrera Administrativa" in inst["nombre"],
          "nombre, sigla y NIT del sindicato vienen de la base de datos")
    di = c.get("/api/r/datos_institucionales/registro", headers=H, params={"clave": "NOMBRE_SINDICATO"}).json()
    r = c.put("/api/r/datos_institucionales/registro", headers=H, params={"clave": "NOMBRE_SINDICATO"},
              json={"valor": "Sindicato de Prueba", "version": di["version"]})
    import app.config as _cfg_inst
    _cfg_inst.institucional(forzar=True)
    check(r.status_code == 200 and c.get("/api/publico/institucion").json()["nombre"] == "Sindicato de Prueba",
          "el administrador cambia el nombre oficial y la aplicación lo usa de inmediato")

    # Crear usuario con política de contraseña
    r = c.post("/api/r/usuarios", headers=H, json={"nombre_usuario": "consulta1", "nombre_completo": "Usuario Consulta",
                                                   "codigo_rol": "CONSULTA", "contrasena": "corta"})
    check(r.status_code == 400 and "contraseña" in r.json()["detail"], "política de contraseña aplicada")
    r = c.post("/api/r/usuarios", headers=H, json={"nombre_usuario": "consulta1", "nombre_completo": "Usuario Consulta",
                                                   "codigo_rol": "CONSULTA", "contrasena": "Consulta#2026x"})
    check(r.status_code == 201 and "hash_contrasena" not in r.json(), "usuario creado sin exponer hash")
    id_consulta = r.json()["id_usuario"]

    # Primer ingreso obliga a cambiar contraseña
    tc = login(c, "consulta1", "Consulta#2026x")
    check(tc["debe_cambiar_contrasena"], "primer ingreso exige cambio de contraseña")
    HC = auth(tc["token"])
    check(c.get("/api/r/personas", headers=HC).status_code == 403, "bloqueado hasta cambiar contraseña")
    r = c.post("/api/auth/cambiar-contrasena", headers=HC,
               json={"contrasena_actual": "Consulta#2026x", "contrasena_nueva": "NuevaClave#2026"})
    check(r.status_code == 200, "cambio de contraseña")

    print("Permisos por módulo y acción")
    check(c.get("/api/r/personas", headers=HC).status_code == 200, "CONSULTA puede consultar gobernanza")
    r = c.post("/api/r/estamentos", headers=HC, json={"nombre_estamento": "X", "tipo_estamento": "SUBDIRECTIVA",
                                                      "departamento": "X"})
    check(r.status_code == 403, "CONSULTA no puede registrar")
    check(c.get("/api/r/cuentas", headers=HC).status_code == 403, "CONSULTA no ve finanzas")
    check(c.get("/api/vistas/vigencia_directivos", headers=HC).status_code == 403, "CONSULTA no ve vistas")
    check(c.get("/api/r/bitacora", headers=HC).status_code == 403, "CONSULTA no ve la bitácora")
    # El admin concede 'ver vistas' de gobernanza al rol CONSULTA desde la matriz
    p = c.get("/api/r/permisos/registro", headers=H, params={"codigo_rol": "CONSULTA", "modulo": "GOBERNANZA"}).json()
    r = c.put("/api/r/permisos/registro", headers=H, params={"codigo_rol": "CONSULTA", "modulo": "GOBERNANZA"},
              json={"puede_ver_vistas": True, "version": p["version"]})
    check(r.status_code == 200, "admin modifica la matriz de permisos")
    check(c.get("/api/vistas/vigencia_directivos", headers=HC).status_code == 200, "permiso aplicado de inmediato")

    print("CRUD, radicación y concurrencia")
    r = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 4, "id_estamento": 2,
                                                     "asunto": "Carta a la empresa", "flujo": "RECIBIDO",
                                                     "radicado_alfanumerico": "HACK"})
    check(r.status_code == 201 and r.json()["radicado_alfanumerico"].startswith("SGS-EMI-SUB_MED-CAR-")
          and r.json()["flujo"] == "EMITIDO", "radicado automático; flujo y radicado del cliente ignorados")
    doc = r.json()
    # Dos usuarios editan el mismo documento con la misma versión
    r1 = c.put("/api/r/documentos/registro", headers=H, params={"id_documento": doc["id_documento"]},
               json={"estado_tramite": "EN_TRAMITE", "_observacion": "Se envió a jurídica", "version": doc["version"]})
    r2 = c.put("/api/r/documentos/registro", headers=H, params={"id_documento": doc["id_documento"]},
               json={"asunto": "Cambio que llega tarde", "version": doc["version"]})
    check(r1.status_code == 200 and r2.status_code == 409 and "actual" in r2.json()["detail"],
          "bloqueo optimista: la segunda edición recibe 409 con los datos actuales")
    h = c.get("/api/r/historial_tramite", headers=H, params={"f_id_documento": doc["id_documento"]}).json()
    check(any(f["observaciones"] == "Se envió a jurídica" and f["usuario_responsable"] == "admin" for f in h["filas"]),
          "historial de trámite con observación y usuario de la app")
    r = c.delete("/api/r/documentos/registro", headers=H, params={"id_documento": doc["id_documento"], "version": 1})
    check(r.status_code == 405, "un documento no se borra (R-01): se anula con su estado")

    def radicar(i):
        return c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 2, "id_estamento": 1,
                                                            "asunto": f"Comunicado {i}"}).json()["radicado_alfanumerico"]
    with cf.ThreadPoolExecutor(10) as ex:
        radicados = list(ex.map(radicar, range(15)))
    check(len(set(radicados)) == 15, "15 radicaciones concurrentes -> 15 radicados únicos")

    print("Archivos con huella SHA-256")
    pdf = b"%PDF-1.4\n% prueba\n%%EOF\n"
    r = c.post(f"/api/documentos/{doc['id_documento']}/archivo", headers=H, files={"archivo": ("oficio.pdf", pdf)})
    check(r.status_code == 200 and len(r.json()["hash_sha256"]) == 64, "PDF adjuntado con SHA-256")
    r = c.post(f"/api/documentos/{doc['id_documento']}/archivo", headers=H, files={"archivo": ("otro.pdf", pdf)})
    check(r.status_code == 409, "no se puede reemplazar un archivo ya firmado")
    r = c.post("/api/documentos/1/archivo", headers=H, files={"archivo": ("x.pdf", b"no es pdf")})
    check(r.status_code == 400, "rechaza archivos que no son PDF")
    check(c.get(f"/api/documentos/{doc['id_documento']}/verificar", headers=H).json()["integro"], "verificación íntegra")
    check(c.get(f"/api/documentos/{doc['id_documento']}/archivo", headers=H).content == pdf, "descarga del PDF")

    print("Finanzas")
    r = c.post("/api/r/consignaciones", headers=H, json={"id_empresa": 1, "id_cuenta_destino": 1, "periodo_mes": 9,
                                                         "periodo_anio": 2026, "monto_total_consignado": "73500",
                                                         "fecha_consignacion": "2026-09-28"})
    check(r.status_code == 201, "consignación registrada")
    r = c.post(f"/api/consignaciones/{r.json()['id_consignacion']}/generar-aportes", headers=H).json()
    check(r["aportes_creados"] == 3 and r["conciliacion"]["diagnostico_auditoria"] == "ARMONIZADO / EXACTO",
          "aportes 0.7% generados y conciliados (3 x 24.500)")

    print("Vistas, tablero y auditoría")
    tab = c.get("/api/tablero", headers=H).json()
    check(len(tab) == 40, "tablero con 40 vistas de alertas")
    v = c.get("/api/vistas/vigencia_directivos", headers=H).json()
    check("año" in (v["filas"][0]["tiempo_transcurrido"] or "") or "mes" in (v["filas"][0]["tiempo_transcurrido"] or ""),
          "intervalos traducidos al español")
    check(c.get("/api/vistas/fk_sin_indice", headers=H).json()["filas"] == [], "todas las FK tienen índice")
    check(len(c.get("/api/vistas/monitor_indices", headers=H).json()["filas"]) > 50, "monitor de índices")
    b = c.get("/api/r/bitacora", headers=H, params={"q": "documento"}).json()
    check(b["total"] > 0 and any(f["usuario_bd"] == "admin" for f in b["filas"]), "bitácora registra usuario de la app")
    check(c.post("/api/r/bitacora", headers=H, json={"operacion": "INSERT"}).status_code == 405, "bitácora no editable")
    a = c.get("/api/r/accesos", headers=H, params={"q": "ACCESO_DENEGADO"}).json()
    check(a["total"] >= 1, "accesos denegados auditados")
    check(c.get("/api/opciones/personas", headers=H, params={"ids": "1,2"}).json()[0]["etiqueta"], "etiquetas de FK")

    print("Reglas estatutarias de cargos directivos")
    # Demo: est. 1 = JDN, 2 = Subdirectiva Medellín, 3 = Comité Cali (registro MinTrabajo n.º = n.º de estamento)
    # Ana(1): Presidente Nal, pertenece a 2 · Carlos(2): Presidente Reg en 2 · Luisa(3): Presidente Comité en 3
    cargos = {f["codigo"]: f["id_cargo"] for f in c.get("/api/r/cargos", headers=H, params={"tam": 100}).json()["filas"]}
    check(len(cargos) == 26, "catálogo con 26 cargos (12 nacionales, 12 regionales, 2 de comité)")

    def directivo(persona, estamento, codigo, registro=None, tipo="ELECCION", posesion="2026-09-01"):
        return c.post("/api/r/directivos", headers=H, json={
            "id_persona": persona, "id_estamento": estamento, "id_cargo": cargos[codigo],
            "id_registro_inspector": registro or estamento, "fecha_posesion_individual": posesion,
            "tipo_nombramiento": tipo})

    r = directivo(1, 1, "VICE_NAL")
    check(r.status_code == 400 and "misma junta" in r.json()["detail"], "no puede tener dos cargos en la misma junta")
    r = directivo(2, 1, "PRES_NAL")
    check(r.status_code == 400 and "ocupado por ANA" in r.json()["detail"], "un cargo solo lo ocupa una persona")
    r = directivo(3, 3, "PRES_REG")
    check(r.status_code == 400 and "es de SUBDIRECTIVA" in r.json()["detail"], "cargo debe ser del tipo de la junta")
    r = directivo(2, 3, "SGEN_COM")
    check(r.status_code == 400 and "pertenece a" in r.json()["detail"], "cargo local solo en su estamento de pertenencia")
    r = directivo(2, 1, "VICE_NAL")
    check(r.status_code == 201 and r.json()["rol_estamento"] == "VICEPRESIDENTE NAL" and r.json()["nivel_cargo"] == "NACIONAL",
          "cargo nacional + cargo local permitido")
    r = directivo(1, 2, "VICE_REG")
    check(r.status_code == 201, "Ana: Presidente Nal + Vicepresidente Reg en su subdirectiva")
    dc = c.get("/api/vistas/doble_cargo", headers=H).json()["filas"]
    check(len(dc) == 2, "vista de directivos con doble cargo")

    ana = c.get("/api/r/directivos", headers=H, params={"f_id_persona": 1, "f_nivel_cargo": "NACIONAL"}).json()["filas"][0]
    r = c.put("/api/r/directivos/registro", headers=H, params={"id_directivo_estamento": ana["id_directivo_estamento"]},
              json={"fecha_retiro": "2026-09-29", "motivo_retiro": "Renuncia", "version": ana["version"]})
    check(r.status_code == 200, "retiro del cargo con fecha y motivo")
    r = directivo(2, 1, "PRES_NAL")
    check(r.status_code == 400 and "misma junta" in r.json()["detail"], "máximo 1 cargo nacional por persona")
    check(directivo(1, 1, "PRES_NAL").status_code == 201, "el cargo liberado puede volver a asignarse; el anterior queda en historial")
    hist = c.get("/api/r/directivos", headers=H, params={"f_id_persona": 1, "f_id_cargo": cargos["PRES_NAL"]}).json()
    check(hist["total"] == 2, "historial del cargo conservado")

    af = c.get("/api/r/afiliados/registro", headers=H, params={"id_persona": 2}).json()
    r = c.put("/api/r/afiliados/registro", headers=H, params={"id_persona": 2},
              json={"id_estamento_pertenencia": 3, "version": af["version"]})
    check(r.status_code == 400 and "retiro" in r.json()["detail"], "no cambia de pertenencia con cargo local vigente")

    # Concurrencia: dos afiliados nuevos piden el mismo cargo vacante al mismo tiempo
    nuevos = []
    for i in (1, 2):
        p = c.post("/api/r/personas", headers=H, json={"tipo_dni": "CC", "dni": f"77700{i}", "primer_nombre": f"NUEVO{i}",
                                                      "primer_apellido": "PRUEBA", "correo_electronico": f"nuevo{i}@x.org"}).json()
        c.post("/api/r/afiliados", headers=H, json={"id_persona": p["id_persona"], "fecha_afiliacion": "2024-01-01",
                                                    "fecha_nacimiento": "1990-01-01", "nivel_educativo": "PROFESIONAL",
                                                    "cargo_empresa": "PROFESIONAL", "id_estamento_pertenencia": 2})
        nuevos.append(p["id_persona"])
    with cf.ThreadPoolExecutor(2) as ex:
        codigos = list(ex.map(lambda pid: directivo(pid, 2, "SEDU_REG").status_code, nuevos))
    check(sorted(codigos) in ([201, 400], [201, 409]), f"cargo pedido por dos personas a la vez: solo uno lo obtiene {codigos}")
    comp = c.get("/api/vistas/composicion_juntas", headers=H).json()["filas"]
    vacantes = sum(1 for f in comp if f["_nivel"] == "MEDIA")
    check(len(comp) == 26 and vacantes == 26 - 6, f"composición de juntas: 26 cargos, {vacantes} vacantes")

    print("Rotación de cargos (el Fiscal no rota)")

    def retirar(persona, estamento):
        d = c.get("/api/r/directivos", headers=H, params={"f_id_persona": persona, "f_id_estamento": estamento}).json()["filas"]
        d = next(x for x in d if x["fecha_retiro"] is None)
        return c.put("/api/r/directivos/registro", headers=H, params={"id_directivo_estamento": d["id_directivo_estamento"]},
                     json={"fecha_retiro": "2026-09-30", "motivo_retiro": "Rotación", "version": d["version"]})

    check(retirar(1, 2).status_code == 200 and directivo(1, 2, "SCUL_REG", tipo="ROTACION").status_code == 201,
          "rotación permitida entre cargos que no son Fiscal")
    carlos = next(x for x in c.get("/api/r/directivos", headers=H, params={"f_id_persona": 2, "f_id_estamento": 2}).json()["filas"]
                  if x["fecha_retiro"] is None)
    retirar(2, 2)
    r = directivo(2, 2, "FIS_REG", tipo="ROTACION")
    check(r.status_code == 400 and "Ningún directivo puede rotar" in r.json()["detail"], "nadie puede rotar hacia Fiscal")
    r = directivo(2, 2, "SJUR_REG", tipo="ROTACION")   # posesión 2026-09-01, pero su periodo empezó hace 23 meses
    check(r.status_code == 201 and r.json()["fecha_inicio_periodo"] == carlos["fecha_inicio_periodo"]
          and r.json()["fecha_fin_vigencia_programada"] == carlos["fecha_fin_vigencia_programada"]
          and r.json()["fecha_posesion_individual"] == "2026-09-01",
          f"rotación conserva el periodo individual (fin {carlos['fecha_fin_vigencia_programada']})")
    libre = next(pid for pid in nuevos
                 if c.get("/api/r/directivos", headers=H, params={"f_id_persona": pid}).json()["total"] == 0)
    check(directivo(libre, 2, "FIS_REG").status_code == 201, "afiliado sin cargo previo puede ser nombrado Fiscal")
    retirar(libre, 2)
    r = directivo(libre, 2, "SMER_REG", tipo="ROTACION")
    check(r.status_code == 400 and "Fiscal no puede rotarse" in r.json()["detail"], "el Fiscal no puede rotar a otro cargo")
    r = c.post("/api/r/directivos", headers=H, json={"id_persona": libre, "id_estamento": 2, "id_cargo": cargos["SMER_REG"],
                                                     "id_registro_inspector": 2, "fecha_posesion_individual": "2028-10-01"})
    check(r.status_code == 201 and r.json()["fecha_fin_vigencia_programada"] == "2030-10-01",
          "tras vencer el periodo, el exfiscal puede ser elegido en otro cargo con periodo nuevo")

    print("Elección, reelección y rotación")
    sin_cargo = c.post("/api/r/personas", headers=H, json={"tipo_dni": "CC", "dni": "660001", "primer_nombre": "SIN",
                       "primer_apellido": "CARGO", "correo_electronico": "sincargo@x.org"}).json()["id_persona"]
    c.post("/api/r/afiliados", headers=H, json={"id_persona": sin_cargo, "fecha_afiliacion": "2024-01-01", "fecha_nacimiento": "1990-03-03",
           "nivel_educativo": "PROFESIONAL", "cargo_empresa": "PROFESIONAL", "id_estamento_pertenencia": 2})
    r = directivo(sin_cargo, 2, "SCOM_REG", tipo="ROTACION")
    check(r.status_code == 400 and "desde el cual rotar" in r.json()["detail"], "no se puede rotar sin un cargo previo en la junta")
    def retirar_en(persona, estamento, fecha):
        d = next(x for x in c.get("/api/r/directivos", headers=H, params={"f_id_persona": persona, "f_id_estamento": estamento}).json()["filas"]
                 if x["fecha_retiro"] is None)
        return c.put("/api/r/directivos/registro", headers=H, params={"id_directivo_estamento": d["id_directivo_estamento"]},
                     json={"fecha_retiro": fecha, "motivo_retiro": "Fin de periodo", "version": d["version"]}).status_code

    check(directivo(sin_cargo, 2, "FIS_REG", posesion="2024-10-01").status_code == 201, "elección como Fiscal")
    retirar_en(sin_cargo, 2, "2026-09-30")
    r = directivo(sin_cargo, 2, "FIS_REG", tipo="REELECCION", posesion="2026-09-30")
    check(r.status_code == 201 and r.json()["fecha_inicio_periodo"] == "2026-09-30" and r.json()["fecha_fin_vigencia_programada"] == "2028-09-30",
          "el Fiscal puede reelegirse como Fiscal, con periodo nuevo")
    retirar_en(sin_cargo, 2, "2026-10-01")
    check(directivo(sin_cargo, 2, "FIS_REG", tipo="REELECCION", posesion="2026-10-01").status_code == 201,
          "reelección sin límite (tercer periodo como Fiscal)")
    r = directivo(sin_cargo, 1, "SEDU_NAL", tipo="REELECCION")
    check(r.status_code == 400 and "mismo cargo" in r.json()["detail"], "reelección solo en un cargo que ya ejerció")
    vice = next(x for x in c.get("/api/r/directivos", headers=H, params={"f_id_persona": 2, "f_id_estamento": 1}).json()["filas"]
                if x["fecha_retiro"] is None)
    retirar(2, 1)
    r = directivo(2, 1, "VICE_NAL", tipo="REELECCION", posesion="2026-09-15")
    check(r.status_code == 201 and r.json()["fecha_inicio_periodo"] == "2026-09-15"
          and r.json()["fecha_fin_vigencia_programada"] == "2028-09-15" and vice["fecha_fin_vigencia_programada"] != "2028-09-15",
          "reelección anticipada (antes de terminar el periodo) abre un periodo nuevo")

    print("Registro vigente ante el inspector")
    activos = [x for x in c.get("/api/r/directivos", headers=H, params={"f_id_estamento": 2, "tam": 100}).json()["filas"]
               if x["fecha_retiro"] is None]
    check(all(x["id_registro_inspector"] == 2 for x in activos), "nombramientos asociados solos al registro vigente")
    fin_antes = {x["id_directivo_estamento"]: x["fecha_fin_vigencia_programada"] for x in activos}
    r = c.post("/api/r/registros_inspector", headers=H, json={"id_estamento": 2, "id_inspector": 1,
               "num_registro_inspector": "REG-2026-MED-02", "fecha_emision_registro": "2026-10-02T10:00:00-05:00"})
    check(r.status_code == 201, "el inspector emite un registro nuevo para la subdirectiva")
    nuevo_reg = r.json()["id_registro"]
    todos = c.get("/api/r/directivos", headers=H, params={"f_id_estamento": 2, "tam": 100}).json()["filas"]
    vig = [x for x in todos if x["fecha_retiro"] is None]
    check(all(x["id_registro_inspector"] == nuevo_reg for x in vig), f"los {len(vig)} directivos vigentes pasan al registro nuevo")
    check(all(x["id_registro_inspector"] == 2 for x in todos if x["fecha_retiro"]), "los retirados conservan su registro anterior")
    check(all(fin_antes[x["id_directivo_estamento"]] == x["fecha_fin_vigencia_programada"] for x in vig),
          "el registro nuevo no cambia el periodo personal de nadie")
    h = c.get("/api/r/directivo_registros", headers=H, params={"f_id_directivo_estamento": vig[0]["id_directivo_estamento"]}).json()
    check(h["total"] == 2, "historial: el directivo figura en el registro anterior y en el nuevo")
    est = c.post("/api/r/estamentos", headers=H, json={"nombre_estamento": "Comité Seccional Buga", "tipo_estamento": "COMITÉ SECCIONAL",
                                                       "departamento": "VALLE DEL CAUCA", "municipio": "BUGA"}).json()
    r = c.post("/api/r/directivos", headers=H, json={"id_persona": nuevos[0], "id_estamento": est["id_estamento"],
               "id_cargo": cargos["PRES_COM"], "fecha_posesion_individual": "2026-09-30"})
    check(r.status_code == 400 and "no tiene registro" in r.json()["detail"], "sin registro del inspector no hay nombramientos")
    r = directivo(nuevos[0], 1, "SEDU_NAL")
    check(r.status_code == 201, "la Junta Nacional acepta directivos de cualquier lugar del país")
    # Bloque 18: quien fue nombrado después del registro vigente no ejerce hasta que el inspector emita uno que lo incluya
    check(c.get("/api/r/directivos/registro", headers=H, params={"id_directivo_estamento": r.json()["id_directivo_estamento"]}).json()["fecha_inscripcion"] is None,
          "nombramiento posterior al registro vigente: queda sin inscripción (no ejerce)")
    r = c.post("/api/r/registros_inspector", headers=H, json={"id_estamento": 1, "id_inspector": 1,
               "num_registro_inspector": "REG-2026-JDN-02", "fecha_emision_registro": "2026-09-30T10:00:00-05:00"})
    check(r.status_code == 201, "el inspector emite el registro de la Junta Nacional que incluye a los nuevos directivos")
    jdn_vig = [x for x in c.get("/api/r/directivos", headers=H, params={"f_id_estamento": 1, "tam": 100}).json()["filas"] if x["fecha_retiro"] is None]
    check(all(x["fecha_inscripcion"] == "2026-09-30" for x in jdn_vig if x["origen_posesion"] == "DIRECTO"),
          "con el registro nuevo quedan inscritos (fecha de inscripción = fecha del registro)")

    print("Juntas en el tiempo")
    pasado = c.get("/api/juntas/2/composicion", headers=H, params={"fecha": "2025-06-01"}).json()
    pres = next(f for f in pasado["filas"] if f["cargo"] == "PRESIDENTE REG")
    check(len(pasado["filas"]) == 12 and pres["directivo"] == "CARLOS RUIZ",
          "composición en una fecha pasada: Carlos era Presidente Reg de Medellín en junio de 2025")
    hoy_j = c.get("/api/juntas/2/composicion", headers=H, params={"fecha": "2026-10-01"}).json()
    pres_hoy = next(f for f in hoy_j["filas"] if f["cargo"] == "PRESIDENTE REG")
    sjur = next(f for f in hoy_j["filas"] if f["cargo"] == "SECRETARIO JURÍDICO REG")
    check(pres_hoy["directivo"] is None and sjur["directivo"] == "CARLOS RUIZ" and sjur["tipo_nombramiento"] == "ROTACION",
          "después de su rotación la Presidencia figura vacante y él como Secretario Jurídico")
    check(len(hoy_j["registros"]) == 2, "lista de registros del inspector de la junta")
    reg_ant = c.get("/api/juntas/registro/2", headers=H).json()
    check(any(f["cargo"] == "PRESIDENTE REG" and f["directivo"] == "CARLOS RUIZ" for f in reg_ant["filas"])
          and reg_ant["num_registro_inspector"] == "REG-2025-2", "composición oficial según un registro anterior del inspector")

    print("Empresa única, sede y pertenencia")
    # Empresa demo: sede central Bogotá, sedes 1 = Medellín y 2 = Cali. Estamentos: 2 = Sub. Medellín, 3 = Comité Cali
    p = c.post("/api/r/personas", headers=H, json={"tipo_dni": "CC", "dni": "880001", "primer_nombre": "ROSA",
                                                  "primer_apellido": "CALI", "correo_electronico": "rosa@x.org"}).json()
    rid = p["id_persona"]
    r = c.post("/api/r/afiliados", headers=H, json={"id_persona": rid, "fecha_afiliacion": "2024-01-01", "fecha_nacimiento": "1990-01-01",
                                                    "nivel_educativo": "PROFESIONAL", "cargo_empresa": "PROFESIONAL"})
    check(r.status_code == 400 and ("pertenencia" in r.json()["detail"] or "obligatori" in r.json()["detail"]), "la pertenencia del afiliado es obligatoria")
    c.post("/api/r/afiliados", headers=H, json={"id_persona": rid, "fecha_afiliacion": "2024-01-01", "fecha_nacimiento": "1990-01-01",
                                                "nivel_educativo": "PROFESIONAL", "cargo_empresa": "PROFESIONAL", "id_estamento_pertenencia": 3})
    r = c.post("/api/r/afiliados_empresa", headers=H, json={"id_persona": rid, "id_empresa": 1, "id_sede": 2,
                                                            "salario_base": "3000000", "fecha_ingreso_empresa": "2024-01-01"})
    check(r.status_code == 201, "afiliada vinculada a la sede Cali de su empresa")
    emp2 = c.post("/api/r/empresas", headers=H, json={"nit": "800999", "nombre_empresa": "OTRA EMPRESA", "departamento": "VALLE DEL CAUCA",
                  "municipio": "CALI", "direccion": "X", "rango_empleados": "ENTRE 1 Y 50", "telefono_1": "1",
                  "correo_general": "a@b.co", "correo_notificaciones_judiciales": "a@b.co"}).json()
    r = c.post("/api/r/afiliados_empresa", headers=H, json={"id_persona": rid, "id_empresa": emp2["id_empresa"],
                                                            "salario_base": "1000000", "fecha_ingreso_empresa": "2024-01-01"})
    check(r.status_code == 409, "un afiliado solo puede estar vinculado a una empresa")
    sede_otra = c.post("/api/r/sedes", headers=H, json={"id_empresa": emp2["id_empresa"], "nombre_sede": "SEDE PASTO",
                       "departamento_sede": "NARIÑO", "municipio_sede": "PASTO"}).json()
    ae = c.get("/api/r/afiliados_empresa/registro", headers=H, params={"id_persona": rid, "id_empresa": 1}).json()
    r = c.put("/api/r/afiliados_empresa/registro", headers=H, params={"id_persona": rid, "id_empresa": 1},
              json={"id_sede": sede_otra["id_sede"], "version": ae["version"]})
    check(r.status_code == 409, "la sede debe ser de su misma empresa")

    def pertenecer(estamento):
        a = c.get("/api/r/afiliados/registro", headers=H, params={"id_persona": rid}).json()
        return c.put("/api/r/afiliados/registro", headers=H, params={"id_persona": rid},
                     json={"id_estamento_pertenencia": estamento, "version": a["version"]})

    r = pertenecer(2)
    check(r.status_code == 400 and "traslado" in r.json()["detail"],
          "la subdirectiva de un afiliado ya registrado no se cambia editando: es un traslado (dos juntas, dos actas)")
    p2 = c.post("/api/r/personas", headers=H, json={"tipo_dni": "CC", "dni": "880002", "primer_nombre": "ROSA",
                                                   "primer_apellido": "SEGUNDA", "correo_electronico": "rosa2@x.org"}).json()["id_persona"]
    c.post("/api/r/afiliados", headers=H, json={"id_persona": p2, "fecha_afiliacion": "2024-01-01", "fecha_nacimiento": "1990-01-01",
                                                "nivel_educativo": "PROFESIONAL", "cargo_empresa": "PROFESIONAL", "id_estamento_pertenencia": 2})
    r = c.post("/api/r/afiliados_empresa", headers=H, json={"id_persona": p2, "id_empresa": 1, "id_sede": 2,
                                                            "salario_base": "3000000", "fecha_ingreso_empresa": "2024-01-01"})
    check(r.status_code == 400 and "Puede pertenecer a" in r.json()["detail"],
          "al registrarlo, quien trabaja en Cali no puede quedar en la Subdirectiva Medellín")
    bog = c.post("/api/r/estamentos", headers=H, json={"nombre_estamento": "Subdirectiva Bogotá", "tipo_estamento": "SUBDIRECTIVA",
                                                       "departamento": "CUNDINAMARCA", "municipio": "BOGOTA"}).json()
    check(bog["municipio_codigo"] == "11001" and bog["departamento_codigo"] == "11",
          "«Bogota» escrito sin tilde y en Cundinamarca se reconoce como Bogotá, D.C. (DIVIPOLA 11001)")
    op = next(f for f in c.get("/api/vistas/pertenencia", headers=H).json()["filas"] if f["id_persona"] == rid)
    check("Subdirectiva Bogotá" in op["opciones_permitidas"] and "Comité Seccional Cali" in op["opciones_permitidas"],
          "puede pertenecer al comité del municipio de su sede (Cali) o a la subdirectiva de la sede principal (Bogotá)")
    ae = c.get("/api/r/afiliados_empresa/registro", headers=H, params={"id_persona": rid, "id_empresa": 1}).json()
    r = c.put("/api/r/afiliados_empresa/registro", headers=H, params={"id_persona": rid, "id_empresa": 1},
              json={"id_sede": 1, "version": ae["version"]})
    check(r.status_code == 400 and "traslado" in r.json()["detail"],
          "trasladarse a la sede Medellín sin cambiar la pertenencia de Cali se rechaza: primero el traslado entre juntas")
    # (Preparación para las pruebas de finanzas: la afiliada pasa a la sede y la Subdirectiva Medellín, como si las dos
    #  juntas hubieran aprobado el traslado; el trámite completo se prueba más adelante con sus usuarios.)
    import psycopg as _pgp
    with _pgp.connect(os.environ["SUPER_DATABASE_URL"]) as _sc:
        _sc.execute("SELECT set_config('pertenencia.operacion', 'traslado', true)")
        _sc.execute("UPDATE gobernanza.afiliado SET id_estamento_pertenencia = 2 WHERE id_persona = %s", (rid,))
        _sc.execute("UPDATE gobernanza.afiliado_empresa SET id_sede = 1 WHERE id_persona = %s", (rid,))
    v = c.get("/api/vistas/pertenencia", headers=H).json()["filas"]
    check(not any("CRÍTICA" in f["diagnostico"] for f in v), "vista de pertenencia sin inconsistencias")

    print("Inspector de trabajo")
    base = {"primer_nombre": "ANA", "primer_apellido": "INSPECTORA", "nombre_territorial": "DT VALLE", "departamento": "VALLE DEL CAUCA"}
    r = c.post("/api/r/inspectores", headers=H, json=base)
    check(r.status_code == 400 and "Municipio" in r.json()["detail"] and "Género" in r.json()["detail"],
          "municipio y género del inspector son obligatorios")
    r = c.post("/api/r/inspectores", headers=H, json={**base, "municipio": "CALI", "genero": "FEMENINO"})
    check(r.status_code == 201 and r.json()["telefono"] is None and r.json()["correo_electronico"] is None,
          "teléfono y correo del inspector pueden quedar vacíos")

    print("Jerarquía de jefes de empresa")
    def jefe(dni, empresa, nivel, directo=None):
        per = c.post("/api/r/personas", headers=H, json={"tipo_dni": "CC", "dni": dni, "primer_nombre": "JEFE", "primer_apellido": dni,
                     "correo_electronico": f"jefe{dni}@x.org"}).json()
        r = c.post("/api/r/jefes", headers=H, json={"id_persona": per["id_persona"], "id_empresa": empresa,
                   "cargo_nivel": f"NIVEL {nivel}", "id_jefe_directo": directo})
        return r

    def poner_jefe(j, directo=None, nivel=None):
        a = c.get("/api/r/jefes/registro", headers=H, params={"id_jefe": j}).json()
        datos = {"version": a["version"], "id_jefe_directo": directo if directo is not None else a["id_jefe_directo"]}
        if nivel:
            datos["cargo_nivel"] = f"NIVEL {nivel}"
        return c.put("/api/r/jefes/registro", headers=H, params={"id_jefe": j}, json=datos)

    r = jefe("50009", emp2["id_empresa"], 5)
    check(r.status_code == 400, "solo hay cuatro niveles: no existe el nivel 5")
    ministro = jefe("50001", emp2["id_empresa"], 4)
    check(ministro.status_code == 201, "el ministro es la máxima autoridad de su ministerio (nivel 4) y no necesita jefe")
    ministro = ministro.json()["id_jefe"]
    replegal = jefe("40001", 1, 4, ministro)
    check(replegal.status_code == 201, "máxima autoridad de la empresa (nivel 4) con jefe de otra entidad del mismo nivel (el ministro)")
    replegal = replegal.json()["id_jefe"]
    secretario = jefe("20001", 1, 3, replegal).json()["id_jefe"]
    subsec = jefe("20002", 1, 3, secretario)
    check(subsec.status_code == 201, "jefe con jefe directo del mismo nivel (alta dirección, nivel 3)")
    subsec = subsec.json()["id_jefe"]
    area = jefe("20003", 1, 2, subsec).json()["id_jefe"]
    coord = jefe("10001", 1, 1, area).json()["id_jefe"]
    r = jefe("10002", 1, 1)
    check(r.status_code == 400 and "jefe directo" in r.json()["detail"], "los niveles 1 a 3 deben tener jefe directo (la cadena para escalar)")
    r = jefe("30001", 1, 2, coord)
    check(r.status_code == 400 and "igual o superior" in r.json()["detail"], "el jefe directo no puede ser de nivel inferior")
    r = poner_jefe(secretario, subsec)
    check(r.status_code == 400 and "ciclo" in r.json()["detail"], "ciclo entre dos jefes del mismo nivel bloqueado")
    r = poner_jefe(replegal, coord)
    check(r.status_code == 400, "un jefe no puede depender de alguien de su propia cadena")
    r = poner_jefe(secretario, nivel=1)
    check(r.status_code == 400 and "depende de esta persona" in r.json()["detail"], "no puede bajar de nivel por debajo de sus subordinados")
    ana_jefe = c.post("/api/r/jefes", headers=H, json={"id_persona": 1, "id_empresa": 1, "cargo_nivel": "NIVEL 1", "id_jefe_directo": area}).json()["id_jefe"]
    ae = c.get("/api/r/afiliados_empresa/registro", headers=H, params={"id_persona": 1, "id_empresa": 1}).json()
    r = c.put("/api/r/afiliados_empresa/registro", headers=H, params={"id_persona": 1, "id_empresa": 1},
              json={"id_jefe_directo": ana_jefe, "version": ae["version"]})
    check(r.status_code == 400 and "a sí mismo" in r.json()["detail"], "un afiliado no puede ser su propio jefe directo")
    r = c.put("/api/r/afiliados_empresa/registro", headers=H, params={"id_persona": 1, "id_empresa": 1},
              json={"id_jefe_directo": ministro, "version": ae["version"]})
    check(r.status_code == 400 and "misma empresa" in r.json()["detail"], "el jefe directo del afiliado es de su misma empresa")
    check(c.put("/api/r/afiliados_empresa/registro", headers=H, params={"id_persona": 1, "id_empresa": 1},
                json={"id_jefe_directo": coord, "version": ae["version"]}).status_code == 200, "afiliado con jefe válido")
    em = c.get("/api/r/empresas/registro", headers=H, params={"id_empresa": 1}).json()
    r = c.put("/api/r/empresas/registro", headers=H, params={"id_empresa": 1}, json={"id_representante_legal": ministro, "version": em["version"]})
    check(r.status_code == 400 and "misma empresa" in r.json()["detail"], "el representante legal debe estar registrado como jefe de esa empresa")
    r = c.put("/api/r/empresas/registro", headers=H, params={"id_empresa": 1}, json={"id_representante_legal": secretario, "version": em["version"]})
    check(r.status_code == 200, "el representante legal no tiene que ser nivel 4 (la base no lo exige; la vista lo señala)")
    em = r.json()
    check(c.put("/api/r/empresas/registro", headers=H, params={"id_empresa": 1},
                json={"id_representante_legal": replegal, "version": em["version"]}).status_code == 200, "una empresa, un representante legal")
    per_rl = c.get("/api/r/jefes/registro", headers=H, params={"id_jefe": replegal}).json()["id_persona"]
    rl2 = c.post("/api/r/jefes", headers=H, json={"id_persona": per_rl, "id_empresa": emp2["id_empresa"], "cargo_nivel": "NIVEL 4"}).json()["id_jefe"]
    em2 = c.get("/api/r/empresas/registro", headers=H, params={"id_empresa": emp2["id_empresa"]}).json()
    check(c.put("/api/r/empresas/registro", headers=H, params={"id_empresa": emp2["id_empresa"]},
                json={"id_representante_legal": rl2, "version": em2["version"]}).status_code == 200,
          "la misma persona puede ser representante legal de otra empresa (por ejemplo, una pública y una particular)")
    esc = {f["afiliado"]: f for f in c.get("/api/vistas/escalamiento", headers=H).json()["filas"]}
    fila_ana = [f for f in esc.values() if f["id_persona"] == 1][0]
    check(fila_ana["cadena_de_escalamiento"].count("→") == 5 and fila_ana["diagnostico"] == "COMPLETA" and fila_ana["representante_legal"],
          "a quién escalar: la cadena del afiliado sube nivel por nivel hasta la máxima autoridad (y sigue en otra entidad), con el representante legal")

    print("Acceso por ámbito territorial")

    def crear_usuario(nombre, rol, persona=None):
        r = c.post("/api/r/usuarios", headers=H, json={"nombre_usuario": nombre, "nombre_completo": nombre.upper(),
                   "codigo_rol": rol, "id_persona": persona, "contrasena": "Temporal#2026x"})
        assert r.status_code == 201, r.text
        t = login(c, nombre, "Temporal#2026x")
        hh = auth(t["token"])
        c.post("/api/auth/cambiar-contrasena", headers=hh, json={"contrasena_actual": "Temporal#2026x", "contrasena_nueva": "Definitiva#2026x"})
        return hh, r.json()["id_usuario"]

    _pres_nal = {}

    def dar_rol(id_usuario, rol, nacional=True):
        """El administrador solicita el rol (Administrador o ámbito nacional), la Presidencia Nacional lo aprueba
        y se retira el rol anterior del usuario."""
        if not _pres_nal:
            _pres_nal["h"] = crear_usuario("presidencia.nal", "DIRECTIVO", 1)[0]   # persona 1: Presidente Nacional
        r = c.post(f"/api/roles/usuarios/{id_usuario}", headers=H, json={"codigo_rol": rol, "ambito_nacional": nacional, "incluye_cargos": True,
                   "motivo": "Decisión de la Junta Directiva Nacional"})
        assert r.status_code == 200, r.text
        r = r.json()
        a = c.post(f"/api/roles/{r['id_usuario_rol']}/aprobar", headers=_pres_nal["h"], json={})
        assert a.status_code == 200, a.text
        for v in c.get(f"/api/roles/usuarios/{id_usuario}", headers=H).json()["roles"]:
            if v["estado"] == "VIGENTE" and v["id_usuario_rol"] != r["id_usuario_rol"]:
                c.post(f"/api/roles/{v['id_usuario_rol']}/revocar", headers=H, json={"motivo": "Reemplazado por el rol aprobado"})
        return r["id_usuario_rol"]

    def ids_estamento(hh, recurso="documentos", campo="id_estamento"):
        return {f[campo] for f in c.get(f"/api/r/{recurso}", headers=hh, params={"tam": 200}).json()["filas"]}

    # Datos: documento y cuenta del Comité Cali; empresa con afiliados solo de Medellín
    doc_cali = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": 3, "asunto": "Acta comité Cali"}).json()
    r = c.post("/api/r/cuentas", headers=H, json={"id_estamento": 3, "banco": "BANCO CALI", "numero_cuenta": "777-CALI",
                                                  "tipo_cuenta": "AHORROS", "id_cuenta_padre": 1})
    assert r.status_code == 201, r.text
    sub_cali = r.json()["id_cuenta"]
    emp_med = c.post("/api/r/empresas", headers=H, json={"nit": "901555444-1", "nombre_empresa": "EMPRESA SOLO MEDELLIN",
                     "departamento": "ANTIOQUIA", "municipio": "MEDELLÍN", "direccion": "X", "rango_empleados": "ENTRE 1 Y 50",
                     "telefono_1": "1", "correo_general": "m@m.co", "correo_notificaciones_judiciales": "m@m.co"}).json()
    sede_med = c.post("/api/r/sedes", headers=H, json={"id_empresa": emp_med["id_empresa"], "nombre_sede": "SEDE CALI EMPRESA MED",
                      "departamento_sede": "VALLE DEL CAUCA", "municipio_sede": "CALI"}).json()
    c.post("/api/r/afiliados_empresa", headers=H, json={"id_persona": nuevos[1], "id_empresa": emp_med["id_empresa"],
           "salario_base": "2000000", "fecha_ingreso_empresa": "2024-01-01"})

    HL, _ = crear_usuario("luisa.cali", "DIRECTIVO", 3)   # Presidente Comité Cali
    yo_l = c.get("/api/auth/yo", headers=HL).json()["ambito"]
    check(not yo_l["nacional"] and yo_l["estamentos"] == ["Comité Seccional Cali"], "ámbito derivado del cargo: Comité Cali")
    check(ids_estamento(HL) == {3}, "directivo del comité solo ve los documentos de su comité")
    check(c.get("/api/r/documentos/registro", headers=HL, params={"id_documento": doc["id_documento"]}).status_code == 404,
          "no puede abrir un documento de la Subdirectiva Medellín")
    r = c.post("/api/r/documentos", headers=HL, json={"id_tipo_documento": 4, "id_estamento": 2, "asunto": "Intento fuera de ámbito"})
    check(r.status_code == 403 and "ámbito" in r.json()["detail"], "no puede radicar en otro estamento")
    check(c.post("/api/r/documentos", headers=HL, json={"id_tipo_documento": 4, "id_estamento": 3, "asunto": "Carta del comité"}).status_code == 201,
          "sí radica en su propio comité")
    check(ids_estamento(HL, "afiliados", "id_estamento_pertenencia") == {3}, "solo ve los afiliados de su comité")
    emp_l = {f["nombre_empresa"] for f in c.get("/api/r/empresas", headers=HL, params={"tam": 100}).json()["filas"]}
    check("EMPRESA PÚBLICA DE EJEMPLO" in emp_l and "EMPRESA SOLO MEDELLIN" not in emp_l,
          "solo ve empresas donde su comité tiene afiliados (más las aún sin afiliados)")
    check(ids_estamento(HL, "cuentas") == {1, 3}, "ve la subcuenta de su comité y la cuenta nacional (padre), no las de otras juntas")
    check({f["id_estamento"] for f in c.get("/api/vistas/saldo_cuentas", headers=HL).json()["filas"]} <= {3},
          "pero no ve el saldo de la cuenta nacional")
    vig = c.get("/api/vistas/vigencia_directivos", headers=HL).json()["filas"]
    check({f["nombre_estamento"] for f in vig} <= {"Comité Seccional Cali", "Junta Directiva Nacional"},
          "las vistas de alertas respetan el ámbito (más la composición pública de la Nacional)")
    r = c.post("/api/r/directivos", headers=HL, json={"id_persona": nuevos[1], "id_estamento": 2,
               "id_cargo": cargos["SCOM_REG"], "fecha_posesion_individual": "2026-09-30"})
    check(r.status_code == 403 and "ámbito" in r.json()["detail"] and "MÉRITO" not in r.json()["detail"],
          "no puede nombrar directivos de otro estamento (sin revelar sus datos)")
    nit = c.get("/api/opciones/empresas", headers=HL, params={"q": "901555444"}).json()
    check([o["etiqueta"] for o in nit] == ["EMPRESA SOLO MEDELLIN (901555444-1)"], "encuentra por NIT una empresa fuera de su ámbito para vincular afiliados")
    sedes = c.get("/api/opciones/sedes", headers=HL, params={"depende": emp_med["id_empresa"]}).json()
    check(len(sedes) == 1 and sede_med["id_sede"] == sedes[0]["valor"], "ve las sedes de la empresa encontrada")

    HC, _ = crear_usuario("carlos.med", "DIRECTIVO", 2)  # Vicepresidente Nal + Secretario Jurídico Reg Medellín
    yo_c = c.get("/api/auth/yo", headers=HC).json()["ambito"]
    check(not yo_c["nacional"] and set(yo_c["estamentos"]) == {"Junta Directiva Nacional", "Subdirectiva Medellín"},
          "directivo nacional sin acceso nacional: ve la Nacional y su subdirectiva")
    check(3 not in ids_estamento(HC), "sin acceso nacional no ve el Comité Cali")
    cg = c.get("/api/r/cargos/registro", headers=H, params={"id_cargo": cargos["VICE_NAL"]}).json()
    c.put("/api/r/cargos/registro", headers=H, params={"id_cargo": cargos["VICE_NAL"]},
          json={"acceso_nacional": True, "version": cg["version"]})
    check(c.get("/api/auth/yo", headers=HC).json()["ambito"]["nacional"], "cargo marcado con acceso nacional: ve todo el país")
    check(3 in ids_estamento(HC), "ahora ve los documentos del Comité Cali")
    dc = c.get("/api/r/documentos/registro", headers=HC, params={"id_documento": doc_cali["id_documento"]}).json()
    r = c.put("/api/r/documentos/registro", headers=HC, params={"id_documento": doc_cali["id_documento"]},
              json={"asunto": "Acta comité Cali (revisada por la Nacional)", "version": dc["version"]})
    check(r.status_code == 200, "y puede actualizar datos de cualquier comité o subdirectiva")

    HA, id_apoyo = crear_usuario("apoyo.cali", "CONSULTA")
    check(c.get("/api/r/documentos", headers=HA).json()["total"] == 0, "usuario sin cargo ni ámbito asignado no ve documentos")
    c.post("/api/r/ambitos_usuario", headers=H, json={"id_usuario": id_apoyo, "id_estamento": 3})
    check(ids_estamento(HA) == {3}, "al asignarle el Comité Cali ve solo esa información")

    HF, id_aud = crear_usuario("fiscal.local", "AUDITOR")
    check(c.get("/api/r/bitacora", headers=HF).json()["total"] == 0, "la bitácora solo es visible con ámbito nacional")
    dar_rol(id_aud, "AUDITOR")
    check(c.get("/api/r/bitacora", headers=HF).json()["total"] > 0, "usuario marcado con acceso nacional ve la bitácora")

    d = next(x for x in c.get("/api/r/directivos", headers=H, params={"f_id_persona": 3}).json()["filas"] if x["fecha_retiro"] is None)
    c.put("/api/r/directivos/registro", headers=H, params={"id_directivo_estamento": d["id_directivo_estamento"]},
          json={"fecha_retiro": "2026-09-30", "motivo_retiro": "Fin", "version": d["version"]})
    check(c.get("/api/r/documentos", headers=HL).json()["total"] == 0, "al retirarse del cargo pierde el acceso de inmediato")

    print("Bloqueo por intentos fallidos y sesiones")
    for _ in range(4):
        login(c, "consulta1", "mala", 401)
    login(c, "consulta1", "mala", 423)
    login(c, "consulta1", "NuevaClave#2026", 423)
    check(True, "cuenta bloqueada tras 5 intentos, aun con la clave correcta")
    check(c.post(f"/api/admin/usuarios/{id_consulta}/desbloquear", headers=H).status_code == 200, "admin desbloquea")
    t2 = login(c, "consulta1", "NuevaClave#2026")
    ses = c.get("/api/admin/sesiones", headers=H).json()
    sid = next(s["id_sesion"] for s in ses if s["nombre_usuario"] == "consulta1")
    c.post(f"/api/admin/sesiones/{sid}/revocar", headers=H)
    check(c.get("/api/auth/yo", headers=auth(t2["token"])).status_code == 401, "sesión revocada deja de funcionar")
    r = c.put("/api/r/usuarios/registro", headers=H, params={"id_usuario": yo["id_usuario"]},
              json={"activo": False, "version": 1})
    check(r.status_code == 400, "el admin no puede desactivarse a sí mismo")

    print("Correos automáticos de alertas")
    if os.environ.get("NOTIFICADOR_DATABASE_URL"):
        from datetime import datetime as _dt
        from zoneinfo import ZoneInfo

        from app import config as _cfg_mod
        hoy = _dt.now(ZoneInfo("America/Bogota")).date()
        af = c.get("/api/r/afiliados/registro", headers=H, params={"id_persona": nuevos[0]}).json()
        c.put("/api/r/afiliados/registro", headers=H, params={"id_persona": nuevos[0]},
              json={"fecha_nacimiento": f"1990-{hoy:%m-%d}", "version": af["version"]})

        # Un directivo posesionado en mayo sin informes: su informe trimestral está vencido
        dj = next(x for x in c.get("/api/r/directivos", headers=H, params={"f_id_persona": 2, "f_id_estamento": 2}).json()["filas"]
                  if x["fecha_retiro"] is None)
        c.put("/api/r/directivos/registro", headers=H, params={"id_directivo_estamento": dj["id_directivo_estamento"]},
              json={"fecha_posesion_individual": "2026-05-01", "version": dj["version"]})
        sim = c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": True}).json()
        check(len(sim["vista_previa"]) > 0 and len(BUZON) == 0, f"simulacro: {len(sim['vista_previa'])} correos previstos y ninguno enviado")
        r1 = c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False}).json()["resumen"]
        import time as _t; _t.sleep(0.5)
        check(sum(x["enviados"] for x in r1.values()) == len(BUZON) == len(sim["vista_previa"]),
              f"se enviaron exactamente los {len(BUZON)} correos previstos")
        asuntos = [m["Subject"] for _, m in BUZON]
        actas_med = [m for _, m in BUZON if m["Subject"] == "ALERTA: Subdirectiva Medellín no está radicando actas de reunión"]
        check(len(actas_med) == 1 and actas_med[0]["Cc"], "actas: alerta a todos los directivos de la junta sin actas (con copia)")
        check(any(a.startswith("Consolidado semanal:") and "sin actas de reunión" in a for a in asuntos),
              "actas: consolidado semanal a la Junta Nacional")
        check(r1["VIGENCIA_DIRECTIVO"]["enviados"] >= 1 and any("vence en" in a and "Su periodo" in a for a in asuntos),
              "aviso de vencimiento del periodo personal")
        check(r1["INFORME_TRIMESTRAL"]["enviados"] >= 1 and any("Informe trimestral de gestión vencido" in a for a in asuntos),
              "aviso de informe trimestral de gestión vencido")
        check(r1["INACTIVIDAD_DOCUMENTAL"]["enviados"] >= 1, "resumen semanal de inactividad documental")
        cumple = [(to, m) for to, m in BUZON if m["Subject"].startswith("¡Feliz cumpleaños")]
        check(len(cumple) == 1 and cumple[0][0] == ["nuevo1@x.org"], "saludo de cumpleaños al afiliado")
        cuerpo = cumple[0][1].get_body(("plain",)).get_content()
        check("Sindicato de Prueba" in cuerpo and "https://sgsindical.test" in cuerpo, "correo con nombre del sindicato y enlace")

        n = len(BUZON)
        r2 = c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False}).json()["resumen"]
        check(sum(x["enviados"] for x in r2.values()) == 0 and len(BUZON) == n
              and sum(x["ya_enviados"] for x in r2.values()) == n, "segunda ejecución: no repite ningún correo")

        p = c.post("/api/r/personas", headers=H, json={"tipo_dni": "CC", "dni": "990001", "primer_nombre": "TOMÁS",
                   "primer_apellido": "NUEVO", "correo_electronico": "tomas@x.org"}).json()
        c.post("/api/r/afiliados", headers=H, json={"id_persona": p["id_persona"], "fecha_afiliacion": "2024-01-01",
               "fecha_nacimiento": f"1995-{hoy:%m-%d}", "nivel_educativo": "PROFESIONAL", "cargo_empresa": "PROFESIONAL",
               "id_estamento_pertenencia": 2})
        _cfg_mod.config.SMTP_PORT = 1
        r3 = c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False}).json()["resumen"]
        _cfg_mod.config.SMTP_PORT = 2525
        check(r3["CUMPLEANOS"]["fallidos"] == 1, "si el servidor de correo falla, el envío queda como FALLIDO")
        r4 = c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False}).json()["resumen"]
        _t.sleep(0.5)
        check(r4["CUMPLEANOS"]["enviados"] == 1 and BUZON[-1][0] == ["tomas@x.org"], "y se reintenta en la siguiente ejecución")
        log = c.get("/api/r/registro_envios", headers=H, params={"q": "FALLIDO"}).json()
        check(log["total"] == 1, "el historial de correos registra el fallo")

        t = c.get("/api/r/tipos_notificacion/registro", headers=H, params={"codigo": "CUMPLEANOS"}).json()
        c.put("/api/r/tipos_notificacion/registro", headers=H, params={"codigo": "CUMPLEANOS"},
              json={"activo": False, "version": t["version"]})
        sim2 = c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": True}).json()["resumen"]
        check(sim2["CUMPLEANOS"]["generados"] == 0, "un tipo de correo desactivado no se genera")
        va = c.get("/api/vistas/actas_juntas", headers=H).json()["filas"]
        check(any(f["nombre_estamento"] == "Subdirectiva Medellín" and f["_nivel"] == "CRÍTICA" for f in va),
              "vista de actas de reunión por junta")
        vi = c.get("/api/vistas/informes_directivos", headers=H).json()["filas"]
        check(all("fecha_limite_informe" in f for f in vi) and any("TRIMESTRAL" in f["diagnostico_auditoria_informe"] for f in vi),
              "vista de informes con plazo trimestral")

    print("Gestión financiera")
    def vista(clave, hh=H):
        return c.get(f"/api/vistas/{clave}", headers=hh).json()["filas"]

    def fondo(nombre, hh=H):
        return next(float(f["saldo"]) for f in vista("saldo_fondos", hh) if f["fondo"] == nombre)

    check(fondo("Junta Directiva Nacional") == 14700 and fondo("Subdirectiva Medellín") == 39200 and fondo("Comité Seccional Cali") == 19600,
          "reparto de aportes: 20 % Nacional (14.700) y 80 % a la junta de cada afiliado (39.200 Medellín, 19.600 Cali)")
    cuentas_s = {f["numero_cuenta"]: float(f["saldo"]) for f in vista("saldo_cuentas")}
    check(cuentas_s["001-234567-89"] == 73500 and cuentas_s["777-CALI"] == 0, "el dinero está físicamente en la cuenta nacional")
    tp = next(f for f in vista("transferencias_pendientes") if f["junta"] == "Comité Seccional Cali")
    check(float(tp["diferencia"]) == 19600 and "nacional debe transferir" in tp["accion"],
          "Cali tiene subcuenta: la cuenta nacional le debe transferir 19.600")
    r = c.post("/api/r/cuentas", headers=H, json={"id_estamento": 2, "banco": "B", "numero_cuenta": "SIN-PADRE", "tipo_cuenta": "AHORROS"})
    check(r.status_code == 400 and "hija" in r.json()["detail"], "una subcuenta debe ser hija de la cuenta nacional")
    r = c.post("/api/r/cuentas", headers=H, json={"id_estamento": 3, "banco": "B", "numero_cuenta": "OTRA-CALI", "id_cuenta_padre": 1})
    check(r.status_code == 409, "una sola subcuenta por subdirectiva o comité")
    check(c.post("/api/r/transferencias", headers=H, json={"id_cuenta_origen": 1, "id_cuenta_destino": sub_cali, "fecha": "2026-09-30",
                                                           "valor": "19600"}).status_code == 201, "transferencia de la cuenta nacional a la subcuenta")
    tp = next(f for f in vista("transferencias_pendientes") if f["junta"] == "Comité Seccional Cali")
    check(tp["diagnostico"] == "AL DÍA", "sin transferencias pendientes después de transferir")

    def nuevo_afiliado(dni, nombre, pertenencia):
        pid = c.post("/api/r/personas", headers=H, json={"tipo_dni": "CC", "dni": dni, "primer_nombre": nombre, "primer_apellido": "MED",
                     "correo_electronico": f"{nombre.lower()}@med.org"}).json()["id_persona"]
        c.post("/api/r/afiliados", headers=H, json={"id_persona": pid, "fecha_afiliacion": "2020-01-01", "fecha_nacimiento": "1980-05-05",
               "nivel_educativo": "PROFESIONAL", "cargo_empresa": "PROFESIONAL", "id_estamento_pertenencia": pertenencia})
        return pid
    p_pres, p_tes = nuevo_afiliado("440001", "PRESI", 2), nuevo_afiliado("440002", "TESO", 2)
    check(directivo(p_pres, 2, "PRES_REG").status_code == 201 and directivo(p_tes, 2, "TES_REG").status_code == 201,
          "Presidente y Tesorero de la Subdirectiva Medellín nombrados")
    HT, _ = crear_usuario("teso.med", "TESORERO", p_tes)
    HP, _ = crear_usuario("presi.med", "DIRECTIVO", p_pres)
    HF2, _ = crear_usuario("fiscal.med", "AUDITOR", sin_cargo)

    acta = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": 2, "asunto": "Acta: aprobación del presupuesto 2026"}).json()
    acta_cali = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": 3, "asunto": "Acta Cali"}).json()
    rubros = {f["codigo"]: f["id_rubro"] for f in c.get("/api/r/rubros", headers=H, params={"tam": 50}).json()["filas"]}
    r = c.post("/api/r/presupuestos", headers=H, json={"id_estamento": 2, "anio": 2026, "id_rubro": rubros["PAPELERIA"],
                                                       "valor_aprobado": "30000", "id_acta": acta_cali["id_documento"]})
    check(r.status_code == 400 and "acta" in r.json()["detail"], "el presupuesto se aprueba con un acta de la misma junta")
    check(c.post("/api/r/presupuestos", headers=H, json={"id_estamento": 2, "anio": 2026, "id_rubro": rubros["PAPELERIA"],
                 "valor_aprobado": "30000", "id_acta": acta["id_documento"]}).status_code == 201, "presupuesto de papelería: 30.000")

    def egreso(valor, rubro="PAPELERIA", cuenta=1, fecha="2026-09-20", hh=HT):
        return c.post("/api/r/egresos", headers=hh, json={"id_estamento": 2, "id_cuenta": cuenta, "id_rubro": rubros[rubro],
                      "fecha": fecha, "valor": str(valor), "concepto": "Compra de papelería", "beneficiario_nombre": "PAPELERÍA CENTRAL"})
    r = egreso(25000, cuenta=sub_cali)
    check(r.status_code == 400 and "no corresponde" in r.json()["detail"], "una junta no puede pagar desde la subcuenta de otra")
    e1 = egreso(25000)
    check(e1.status_code == 201 and e1.json()["estado"] == "REGISTRADO",
          "el Tesorero registra un egreso desde la cuenta nacional (Medellín no tiene subcuenta)")
    e1 = e1.json()["id_egreso"]
    r = c.post(f"/api/egresos/{e1}/aprobar", headers=HT)
    check(r.status_code == 400 and "soporte" in r.json()["detail"], "sin soporte no se puede aprobar")
    pdf_factura = b"%PDF-1.4\n% factura\n%%EOF\n"
    check(c.post(f"/api/egresos/{e1}/soporte", headers=HT, files={"archivo": ("factura.pdf", pdf_factura)}).status_code == 200,
          "soporte PDF adjunto con huella SHA-256")
    r = c.post(f"/api/egresos/{e1}/aprobar", headers=HT).json()
    check(r["resultado"].startswith("PENDIENTE"), "primera firma (Tesorero): queda pendiente la segunda")
    r = c.post(f"/api/egresos/{e1}/aprobar", headers=HT)
    check(r.status_code == 400 and "ya está registrada" in r.json()["detail"], "la misma firma no cuenta dos veces")
    r = c.post(f"/api/egresos/{e1}/aprobar", headers=HF2)
    check(r.status_code == 400 and "Fiscal revisa pero no aprueba" in r.json()["detail"], "el Fiscal no puede aprobar egresos")
    r = c.post(f"/api/egresos/{e1}/aprobar", headers=H)
    check(r.status_code == 400, "el administrador tampoco aprueba (no tiene el cargo)")
    r = c.post(f"/api/egresos/{e1}/aprobar", headers=HP).json()
    check(r["resultado"] == "APROBADO" and len(r["firmas"]) == 2, "segunda firma (Presidente): egreso APROBADO")
    ev = c.get("/api/r/egresos/registro", headers=HT, params={"id_egreso": e1}).json()
    r = c.put("/api/r/egresos/registro", headers=HT, params={"id_egreso": e1}, json={"valor": "1", "version": ev["version"]})
    check(r.status_code == 400 and "no se modifica" in r.json()["detail"], "un egreso aprobado no se modifica")
    check(fondo("Subdirectiva Medellín") == 14200, "el egreso descuenta del fondo de Medellín (39.200 - 25.000)")

    e2 = egreso(10000).json()["id_egreso"]
    c.post(f"/api/egresos/{e2}/soporte", headers=HT, files={"archivo": ("factura2.pdf", pdf_factura)})
    c.post(f"/api/egresos/{e2}/aprobar", headers=HT)
    r = c.post(f"/api/egresos/{e2}/aprobar", headers=HP)
    check(r.status_code == 400 and "supera el presupuesto" in r.json()["detail"], "pasar del presupuesto (35.000 > 30.000) se bloquea")
    ev = c.get("/api/r/egresos/registro", headers=HT, params={"id_egreso": e2}).json()
    c.put("/api/r/egresos/registro", headers=HT, params={"id_egreso": e2},
          json={"id_acta_autorizacion": acta["id_documento"], "version": ev["version"]})
    check(c.post(f"/api/egresos/{e2}/aprobar", headers=HP).json()["resultado"] == "APROBADO", "con acta de autorización sí se aprueba")
    e3 = egreso(50000).json()["id_egreso"]
    c.post(f"/api/egresos/{e3}/soporte", headers=HT, files={"archivo": ("f3.pdf", pdf_factura)})
    ev = c.get("/api/r/egresos/registro", headers=HT, params={"id_egreso": e3}).json()
    c.put("/api/r/egresos/registro", headers=HT, params={"id_egreso": e3}, json={"id_acta_autorizacion": acta["id_documento"], "version": ev["version"]})
    c.post(f"/api/egresos/{e3}/aprobar", headers=HT)
    r = c.post(f"/api/egresos/{e3}/aprobar", headers=HP)
    check(r.status_code == 400 and "Fondos insuficientes" in r.json()["detail"], "no se aprueba un egreso mayor que el fondo de la junta")
    r = c.post(f"/api/egresos/{e1}/anular", headers=HP, json={"motivo": "Factura duplicada por el proveedor"})
    check(r.status_code == 200 and fondo("Subdirectiva Medellín") == 29200, "anular un egreso aprobado devuelve el valor al fondo")
    ej = next(f for f in vista("ejecucion_presupuestal") if f["rubro"] == "PAPELERÍA Y ÚTILES" and f["junta"] == "Subdirectiva Medellín")
    check(float(ej["ejecutado"]) == 10000 and float(ej["disponible"]) == 20000, "ejecución presupuestal: 10.000 de 30.000")

    print("Mora, salarios, cierre y conciliación")
    mora = [f for f in vista("mora_empresas") if f["empresa"] == "EMPRESA PÚBLICA DE EJEMPLO"]
    ago = next(f for f in mora if f["periodo"] == "2026-08")
    check("NO CONSIGNÓ" in ago["diagnostico"] and float(ago["esperado"]) == 94500,
          "mora: agosto sin consignar; esperado 94.500 (0,7 % de los salarios vigentes)")
    check(not any(f["periodo"] == "2026-09" for f in mora), "septiembre aún no está vencido (plazo hasta el día 15 del mes siguiente)")
    c.post("/api/r/consignaciones", headers=H, json={"id_empresa": 1, "id_cuenta_destino": 1, "periodo_mes": 8, "periodo_anio": 2026,
                                                     "monto_total_consignado": "50000", "fecha_consignacion": "2026-09-10"})
    ago = next(f for f in vista("mora_empresas") if f["empresa"] == "EMPRESA PÚBLICA DE EJEMPLO" and f["periodo"] == "2026-08")
    check("CONSIGNÓ MENOS" in ago["diagnostico"] and float(ago["diferencia"]) == -44500, "consignó 50.000 de 94.500: alerta de faltante")

    ae = c.get("/api/r/afiliados_empresa/registro", headers=H, params={"id_persona": 1, "id_empresa": 1}).json()
    c.put("/api/r/afiliados_empresa/registro", headers=H, params={"id_persona": 1, "id_empresa": 1},
          json={"salario_base": "4000000", "_salario_desde": "2026-10-01", "version": ae["version"]})
    hist = c.get("/api/r/salarios", headers=H, params={"f_id_persona": 1}).json()
    check(hist["total"] == 2, "historial de salarios: el anterior y el nuevo con su fecha de vigencia")
    ago = next(f for f in vista("mora_empresas") if f["empresa"] == "EMPRESA PÚBLICA DE EJEMPLO" and f["periodo"] == "2026-08")
    check(float(ago["esperado"]) == 94500, "el cambio de salario no altera lo esperado de meses anteriores")
    oct_ = c.post("/api/r/consignaciones", headers=H, json={"id_empresa": 1, "id_cuenta_destino": 1, "periodo_mes": 10, "periodo_anio": 2026,
                  "monto_total_consignado": "1", "fecha_consignacion": "2026-10-05"}).json()
    c.post(f"/api/consignaciones/{oct_['id_consignacion']}/generar-aportes", headers=H)
    ap = c.get("/api/r/aportes", headers=H, params={"f_id_consignacion": oct_["id_consignacion"], "f_id_persona": 1}).json()["filas"][0]
    check(float(ap["monto_descuento_ley"]) == 28000, "los aportes de octubre usan el nuevo salario (0,7 % de 4.000.000)")

    import datetime as _dtm
    _hoy = _dtm.date.today()
    r = c.post("/api/finanzas/cierres", headers=HT, json={"id_estamento": 2, "anio": _hoy.year, "mes": _hoy.month})
    check(r.status_code == 400 and "terminados" in r.json()["detail"], "no se cierra un mes que no ha terminado")
    r = c.post("/api/finanzas/cierres", headers=HP, json={"id_estamento": 2, "anio": 2026, "mes": 8})
    check(r.status_code == 400 and "Tesorero" in r.json()["detail"], "el cierre lo hace el Tesorero")
    cierre = c.post("/api/finanzas/cierres", headers=HT, json={"id_estamento": 2, "anio": 2026, "mes": 8})
    check(cierre.status_code == 200, "el Tesorero cierra agosto")
    r = egreso(1000, fecha="2026-08-15")
    check(r.status_code == 400 and "cerrado" in r.json()["detail"], "en un mes cerrado no se registran movimientos")
    r = c.post(f"/api/finanzas/cierres/{cierre.json()['id_cierre']}/reabrir", headers=HT, json={"motivo": "Error en una factura de agosto"})
    check(r.status_code == 400, "solo el administrador reabre un mes")
    r = c.post(f"/api/finanzas/cierres/{cierre.json()['id_cierre']}/reabrir", headers=H, json={"motivo": "Error en una factura de agosto"})
    check(r.status_code == 200 and egreso(1000, fecha="2026-08-15").status_code == 201, "reabierto con motivo, vuelve a admitir movimientos")
    c.post("/api/r/conciliaciones", headers=H, json={"id_cuenta": 1, "anio": 2026, "mes": 8, "saldo_extracto": "5000"})
    conc = next(f for f in vista("conciliacion_bancaria") if f["anio"] == 2026 and f["mes"] == 8)
    check(float(conc["saldo_sistema"]) == 0 and "NO COINCIDE" in conc["diagnostico"], "conciliación bancaria detecta la diferencia con el extracto")
    tipos_alerta = {f["tipo"] for f in vista("alertas_financieras")}
    check({"CONCILIACIÓN BANCARIA", "EGRESO ANULADO", "EGRESO SIN SOPORTE"} <= tipos_alerta, f"alertas para el Fiscal: {sorted(tipos_alerta)}")
    juntas_t = {f["fondo"] for f in vista("saldo_fondos", HT)}
    check(juntas_t == {"Subdirectiva Medellín"} and vista("saldo_cuentas", HT) == [],
          "el Tesorero de Medellín solo ve el fondo de su junta (no el saldo de la cuenta nacional)")
    if os.environ.get("NOTIFICADOR_DATABASE_URL"):
        n0 = len(BUZON)
        c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False}); _t.sleep(0.5)
        nuevos_c = BUZON[n0:]
        check(any(m["Subject"].startswith("Mora de empresas") and "teso@med.org" in to for to, m in nuevos_c),
              "correo semanal de mora al Tesorero de Medellín")
        check(any(m["Subject"].startswith("Resumen financiero mensual") and "sincargo@x.org" in to for to, m in nuevos_c),
              "correo mensual de alertas financieras al Fiscal de Medellín")

    print("Consignaciones en la cuenta nacional o en la subcuenta")
    tp0 = float(next(f for f in vista("transferencias_pendientes") if f["junta"] == "Comité Seccional Cali")["diferencia"])
    cons = lambda emp, cta, monto: c.post("/api/r/consignaciones", headers=H, json={"id_empresa": emp, "id_cuenta_destino": cta,
                                          "periodo_mes": 5, "periodo_anio": 2026, "monto_total_consignado": str(monto), "fecha_consignacion": "2026-06-10"})
    r = cons(emp_med["id_empresa"], sub_cali, 1000)
    check(r.status_code == 400 and "no tiene afiliados de la junta" in r.json()["detail"],
          "no se consigna en la subcuenta de una junta sin afiliados en la empresa")
    ra = cons(1, sub_cali, 24500)
    check(ra.status_code == 201, "la empresa consigna directamente en la subcuenta del Comité Cali")
    ga = c.post(f"/api/consignaciones/{ra.json()['id_consignacion']}/generar-aportes", headers=H, params={"solo_junta": True}).json()
    check(ga["aportes_creados"] == 1 and ga["conciliacion"]["diagnostico_auditoria"].startswith("ARMONIZADO"),
          "aportes solo de los afiliados de Cali en la consignación a su subcuenta")
    esperado_may = float(next(f for f in vista("mora_empresas") if f["empresa"] == "EMPRESA PÚBLICA DE EJEMPLO" and f["periodo"] == "2026-05")["esperado"])
    rb = cons(1, 1, round(esperado_may - 24500, 2))
    check(rb.status_code == 201, "el mismo mes, la empresa consigna el resto en la cuenta nacional (padre)")
    check(cons(1, 1, 10).status_code == 409, "una sola consignación por cuenta y mes")
    gb = c.post(f"/api/consignaciones/{rb.json()['id_consignacion']}/generar-aportes", headers=H).json()
    afil_emp = c.get("/api/r/afiliados_empresa", headers=H, params={"f_id_empresa": 1, "tam": 200}).json()["filas"]
    n_may = sum(1 for a in afil_emp if a["fecha_ingreso_empresa"] <= "2026-05-31")
    check(gb["aportes_creados"] == n_may - 1, f"la consignación nacional cubre a los demás afiliados ({gb['aportes_creados']}) sin repetir los de Cali")
    check(c.post(f"/api/consignaciones/{ra.json()['id_consignacion']}/generar-aportes", headers=H).json()["aportes_creados"] == 0,
          "volver a generar no duplica aportes de un afiliado en el mismo mes")
    mora_may = next(f for f in vista("mora_empresas") if f["empresa"] == "EMPRESA PÚBLICA DE EJEMPLO" and f["periodo"] == "2026-05")
    check(mora_may["diagnostico"] == "AL DÍA" and "Cuenta nacional" in mora_may["consignado_en"] and "Cali" in mora_may["consignado_en"],
          "la mora suma lo consignado en ambas cuentas")
    pc = next(f for f in vista("consignaciones_por_cuenta") if f["id_consignacion"] == ra.json()["id_consignacion"])
    check(float(pc["para_esta_cuenta"]) == 19600 and float(pc["para_otras_cuentas"]) == 4900 and "OTROS FONDOS" in pc["diagnostico"],
          "consignación en la subcuenta: 19.600 son de Cali y 4.900 (20 %) de la Nacional")
    HTC, id_tc = crear_usuario("apoyo.finanzas.cali", "TESORERO")
    c.post("/api/r/ambitos_usuario", headers=H, json={"id_usuario": id_tc, "id_estamento": 3})
    ids_l = {f["id_consignacion"] for f in c.get("/api/r/consignaciones", headers=HTC, params={"tam": 200}).json()["filas"]}
    check(rb.json()["id_consignacion"] in ids_l and ra.json()["id_consignacion"] in ids_l,
          "Cali ve las consignaciones de su empresa en su subcuenta y en la cuenta nacional")
    check(not any(f["id_estamento"] == 2 for f in c.get("/api/r/cuentas", headers=HTC).json()["filas"]), "y no ve cuentas de otras juntas")
    r = c.post("/api/r/ingresos", headers=H, json={"id_estamento": 3, "id_cuenta": 1, "fecha": "2026-06-15", "valor": "10000",
               "concepto": "Donación para el Comité Cali", "origen": "Particular"})
    check(r.status_code == 201, "un ingreso del Comité Cali puede llegar a la cuenta nacional (padre)")
    tp1 = float(next(f for f in vista("transferencias_pendientes") if f["junta"] == "Comité Seccional Cali")["diferencia"])
    check(round(tp1 - tp0, 2) == 5100, "transferencias pendientes: +19.600 aporte +10.000 donación −24.500 ya en la subcuenta = +5.100")

    print("Nada se borra (R-01): inactivar, reactivar y anular")
    r = c.delete("/api/r/personas/registro", headers=H, params={"id_persona": sin_cargo, "version": 1})
    check(r.status_code == 405, "una persona no se borra: la operación eliminar ya no existe")
    if os.environ.get("SUPER_DATABASE_URL"):
        import psycopg as _pg
        with _pg.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            try:
                sc.execute("DELETE FROM gobernanza.persona WHERE id_persona = %s", (sin_cargo,)); msg_b = "BORRÓ"
            except _pg.Error as e:
                msg_b = str(e)
            check("nada se borra" in msg_b, "ni siquiera un superusuario (pgAdmin) puede borrar: el trigger lo impide")
            n_casc = sc.execute("SELECT count(*) FROM pg_constraint WHERE contype = 'f' AND confdeltype = 'c'").fetchone()[0]
            check(n_casc == 0, "no quedan llaves ON DELETE CASCADE")
        with _pg.connect(os.environ["DATABASE_URL"], autocommit=True) as ac2:
            puede_b = ac2.execute("SELECT has_table_privilege('gobernanza.persona', 'DELETE'), "
                                  "has_table_privilege('gestion_documental.reunion_punto', 'DELETE')").fetchone()
            check(puede_b == (False, True), "la aplicación no tiene permiso de borrar (salvo detalles de un acta sin firmar)")

    # Desafiliación: el mes del retiro se cobra; desde el mes siguiente ya no
    def esperado(periodo):
        return float(next(f for f in vista("mora_empresas") if f["empresa"] == "EMPRESA PÚBLICA DE EJEMPLO" and f["periodo"] == periodo)["esperado"])
    e_ago0 = esperado("2026-08")
    id_bog = next(o["valor"] for o in c.get("/api/opciones/estamentos", headers=H, params={"q": "Bogotá"}).json())
    p_ret = nuevo_afiliado("440777", "RETIRADO", id_bog)
    r = c.post("/api/r/afiliados_empresa", headers=H, json={"id_persona": p_ret, "id_empresa": 1, "salario_base": "1000000",
               "fecha_ingreso_empresa": "2024-01-01"})
    assert r.status_code == 201, r.text
    check(esperado("2026-08") == e_ago0 + 7000, "el nuevo afiliado suma 7.000 a lo esperado de agosto")
    r = c.post("/api/r/personas/inactivar", headers=H, params={"id_persona": p_ret}, json={"motivo": "Prueba de retiro", "version": 1})
    check(r.status_code == 400 and "afiliada activa" in r.json()["detail"], "no se inactiva una persona con afiliación activa")
    af = c.get("/api/r/afiliados/registro", headers=H, params={"id_persona": p_ret}).json()
    r = c.post("/api/r/afiliados/inactivar", headers=H, params={"id_persona": p_ret}, json={"motivo": "corto", "version": af["version"]})
    check(r.status_code == 400 and "motivo" in r.json()["detail"], "inactivar exige motivo (mínimo 10 caracteres)")
    r = c.post("/api/r/afiliados/inactivar", headers=HT, params={"id_persona": p_ret},
               json={"motivo": "Renuncia voluntaria al sindicato", "version": af["version"]})
    check(r.status_code == 403, "inactivar requiere el permiso 'inactivar / anular' del módulo")
    r = c.post("/api/r/afiliados/inactivar", headers=H, params={"id_persona": p_ret},
               json={"motivo": "Renuncia voluntaria al sindicato", "version": af["version"]})
    af = r.json()
    check(r.status_code == 200 and af["activo"] is False and af["usuario_inactivacion"] == "admin" and af["fecha_inactivacion"],
          "afiliado desafiliado: queda inactivo con motivo, fecha y usuario")
    check(esperado("2026-08") == e_ago0 + 7000, "los meses anteriores al retiro se siguen esperando (la nómina ya se causó)")
    check(c.post(f"/api/consignaciones/{oct_['id_consignacion']}/generar-aportes", headers=H).json()["aportes_creados"] == 1,
          "el mes del retiro (octubre) también se cobra")
    nov = c.post("/api/r/consignaciones", headers=H, json={"id_empresa": 1, "id_cuenta_destino": 1, "periodo_mes": 11, "periodo_anio": 2026,
                 "monto_total_consignado": "1", "fecha_consignacion": "2026-10-05"}).json()
    c.post(f"/api/consignaciones/{nov['id_consignacion']}/generar-aportes", headers=H)
    ap_nov = c.get("/api/r/aportes", headers=H, params={"f_id_consignacion": nov["id_consignacion"], "tam": 200}).json()["filas"]
    check(ap_nov and all(a["id_persona"] != p_ret for a in ap_nov), "desde el mes siguiente al retiro ya no se le genera aporte")
    lista = {f["id_persona"] for f in c.get("/api/r/afiliados", headers=H, params={"tam": 200}).json()["filas"]}
    lista_t = {f["id_persona"] for f in c.get("/api/r/afiliados", headers=H, params={"tam": 200, "inactivos": True}).json()["filas"]}
    opc = {o["valor"] for o in c.get("/api/opciones/afiliados", headers=H, params={"q": "RETIRADO"}).json()}
    check(p_ret not in lista and p_ret in lista_t and p_ret not in opc,
          "el inactivo sale de listas y desplegables, pero se consulta con «Ver inactivos»")
    r = c.put("/api/r/afiliados/registro", headers=H, params={"id_persona": p_ret}, json={"area_empresa": "X", "version": af["version"]})
    check(r.status_code == 400 and "reactívelo" in r.json()["detail"], "un registro inactivo no se modifica")
    pr = c.get("/api/r/personas/registro", headers=H, params={"id_persona": p_ret}).json()
    pr = c.post("/api/r/personas/inactivar", headers=H, params={"id_persona": p_ret},
                json={"motivo": "Ya no tiene vínculo con el sindicato", "version": pr["version"]}).json()
    check(pr["activo"] is False, "sin afiliación activa, la persona sí se inactiva")
    r = c.post("/api/r/personas", headers=H, json={"tipo_dni": "CC", "dni": "440777", "primer_nombre": "OTRA", "primer_apellido": "VEZ",
               "correo_electronico": "otra@vez.org"})
    check(r.status_code == 409 and "reactívelo" in r.json()["detail"], "no se duplica: el sistema indica reactivar al inactivo")
    r = c.post("/api/r/afiliados/reactivar", headers=H, params={"id_persona": p_ret}, json={"version": af["version"]})
    check(r.status_code == 400 and "inactiv" in r.json()["detail"], "no se reactiva un afiliado de una persona inactiva")
    pr = c.post("/api/r/personas/reactivar", headers=H, params={"id_persona": p_ret}, json={"version": pr["version"]}).json()
    af = c.post("/api/r/afiliados/reactivar", headers=H, params={"id_persona": p_ret}, json={"version": af["version"]}).json()
    check(pr["activo"] and af["activo"] and af["motivo_inactivacion"] is None, "reactivación de la persona y luego de su afiliación")
    check(c.post("/api/r/afiliados/inactivar", headers=H, params={"id_persona": p_ret},
                 json={"motivo": "Prueba de concurrencia", "version": 1}).status_code == 409, "inactivar con versión vieja -> 409")

    # Empresa: no se inactiva con afiliados activos; si se puede, inactiva en cadena sus sedes
    ev_m = c.get("/api/r/empresas/registro", headers=H, params={"id_empresa": emp_med["id_empresa"]}).json()
    r = c.post("/api/r/empresas/inactivar", headers=H, params={"id_empresa": emp_med["id_empresa"]},
               json={"motivo": "Liquidación de la entidad", "version": ev_m["version"]})
    check(r.status_code == 400 and "afiliado(s) activo(s)" in r.json()["detail"], "no se inactiva una empresa con afiliados activos")
    emp_x = c.post("/api/r/empresas", headers=H, json={"nit": "900111222-3", "nombre_empresa": "EMPRESA LIQUIDADA", "departamento": "ANTIOQUIA",
                   "municipio": "MEDELLÍN", "direccion": "X", "rango_empleados": "ENTRE 1 Y 50", "telefono_1": "1",
                   "correo_general": "l@l.co", "correo_notificaciones_judiciales": "l@l.co"}).json()
    sede_x = c.post("/api/r/sedes", headers=H, json={"id_empresa": emp_x["id_empresa"], "nombre_sede": "SEDE ÚNICA",
                    "departamento_sede": "ANTIOQUIA", "municipio_sede": "MEDELLÍN"}).json()
    r = c.post("/api/r/empresas/inactivar", headers=H, params={"id_empresa": emp_x["id_empresa"]},
               json={"motivo": "Liquidación de la entidad", "version": emp_x["version"]})
    sx = c.get("/api/r/sedes/registro", headers=H, params={"id_sede": sede_x["id_sede"]}).json()
    check(r.status_code == 200 and sx["activo"] is False and sx["motivo_inactivacion"].startswith("Empresa inactivada"),
          "al inactivar la empresa se inactivan en cadena sus sedes")
    r = c.post("/api/r/sedes", headers=H, json={"id_empresa": emp_x["id_empresa"], "nombre_sede": "OTRA",
               "departamento_sede": "ANTIOQUIA", "municipio_sede": "MEDELLÍN"})
    check(r.status_code == 400 and "inactiv" in r.json()["detail"], "no se registran sedes de una empresa inactiva")

    # Juntas y cuentas
    jdn = c.get("/api/r/estamentos/registro", headers=H, params={"id_estamento": 1}).json()
    r = c.post("/api/r/estamentos/inactivar", headers=H, params={"id_estamento": 1}, json={"motivo": "Prueba de la Nacional", "version": jdn["version"]})
    check(r.status_code == 400 and "Nacional" in r.json()["detail"], "la Junta Directiva Nacional no se inactiva")
    em = c.get("/api/r/estamentos/registro", headers=H, params={"id_estamento": 2}).json()
    r = c.post("/api/r/estamentos/inactivar", headers=H, params={"id_estamento": 2}, json={"motivo": "Fusión con otra subdirectiva", "version": em["version"]})
    check(r.status_code == 400 and "afiliado(s) activo(s)" in r.json()["detail"], "no se inactiva una junta con afiliados activos")
    ex = c.post("/api/r/estamentos", headers=H, json={"nombre_estamento": "Subdirectiva Cerrada", "tipo_estamento": "SUBDIRECTIVA",
                "departamento": "ANTIOQUIA", "municipio": "RIONEGRO"}).json()
    r = c.post("/api/r/estamentos/inactivar", headers=H, params={"id_estamento": ex["id_estamento"]},
               json={"motivo": "Subdirectiva disuelta por la asamblea", "version": ex["version"]})
    check(r.status_code == 200, "una junta sin afiliados, directivos ni cuentas sí se inactiva")
    con_junta = [v["clave"] for v in c.get("/api/vistas", headers=H).json()
                 if any("Subdirectiva Cerrada" in str(x) for x in c.get(f"/api/vistas/{v['clave']}", headers=H).json()["filas"])]
    check(con_junta == [], f"una junta inactiva no genera alertas en las vistas de control {con_junta}")
    cc = c.get("/api/r/cuentas/registro", headers=H, params={"id_cuenta": sub_cali}).json()
    r = c.post("/api/r/cuentas/inactivar", headers=H, params={"id_cuenta": sub_cali}, json={"motivo": "Cambio de banco del comité", "version": cc["version"]})
    check(r.status_code == 400 and "saldo" in r.json()["detail"], "no se inactiva una cuenta bancaria con saldo")

    # Anulación de movimientos financieros
    f0 = fondo("Subdirectiva Medellín")
    ing = c.post("/api/r/ingresos", headers=HT, json={"id_estamento": 2, "id_cuenta": 1, "fecha": "2026-10-02", "valor": "5000",
                 "concepto": "Rifa de la subdirectiva", "origen": "Afiliados"}).json()
    check(fondo("Subdirectiva Medellín") == f0 + 5000, "ingreso registrado: el fondo sube 5.000")
    check(c.delete("/api/r/ingresos/registro", headers=HT, params={"id_ingreso": ing["id_ingreso"], "version": 1}).status_code == 405,
          "un ingreso no se borra")
    r = c.post("/api/r/ingresos/anular", headers=HT, params={"id_ingreso": ing["id_ingreso"]}, json={"motivo": "corto"})
    check(r.status_code == 400 and "motivo" in r.json()["detail"], "anular exige motivo")
    r = c.post("/api/r/ingresos/anular", headers=HTC, params={"id_ingreso": ing["id_ingreso"]}, json={"motivo": "Intento desde otra junta"})
    check(r.status_code == 404, "otra junta no puede anular (fuera de su ámbito)")
    r = c.post("/api/r/ingresos/anular", headers=H, params={"id_ingreso": ing["id_ingreso"]}, json={"motivo": "El administrador lo intenta"})
    check(r.status_code == 400 and "Tesorero" in r.json()["detail"], "el administrador no anula movimientos (no tiene el cargo)")
    r = c.post("/api/r/ingresos/anular", headers=HT, params={"id_ingreso": ing["id_ingreso"]}, json={"motivo": "La rifa se registró dos veces"})
    check(r.status_code == 200 and r.json()["registro"]["anulado"] and fondo("Subdirectiva Medellín") == f0,
          "el Tesorero anula: el ingreso queda en el historial y sale del saldo")
    r = c.post("/api/r/ingresos/anular", headers=HT, params={"id_ingreso": ing["id_ingreso"]}, json={"motivo": "La rifa se registró dos veces"})
    check(r.status_code == 400 and "ya está anulado" in r.json()["detail"], "no se anula dos veces")
    ing2 = c.get("/api/r/ingresos/registro", headers=HT, params={"id_ingreso": ing["id_ingreso"]}).json()
    r = c.put("/api/r/ingresos/registro", headers=HT, params={"id_ingreso": ing["id_ingreso"]}, json={"valor": "1", "version": ing2["version"]})
    check(r.status_code == 400 and "anulado" in r.json()["detail"], "un movimiento anulado no se modifica")

    HPN, _ = crear_usuario("tesoreria.nacional", "TESORERO", 1)   # persona 1: Presidente Nacional
    ap_oct = c.get("/api/r/aportes", headers=H, params={"f_id_consignacion": oct_["id_consignacion"], "tam": 200}).json()["filas"]
    r = c.post("/api/r/consignaciones/anular", headers=HT, params={"id_consignacion": oct_["id_consignacion"]},
               json={"motivo": "La empresa reversó la transferencia"})
    check(r.status_code == 400 and "Tesorero" in r.json()["detail"], "una consignación a la cuenta nacional la anula la Nacional, no una subdirectiva")
    r = c.post("/api/r/consignaciones/anular", headers=HPN, params={"id_consignacion": oct_["id_consignacion"]},
               json={"motivo": "La empresa reversó la transferencia"})
    ap_oct2 = c.get("/api/r/aportes", headers=H, params={"f_id_consignacion": oct_["id_consignacion"], "tam": 200}).json()["filas"]
    check(r.status_code == 200 and f"{len(ap_oct)} aporte(s)" in r.json()["resultado"] and all(a["anulado"] for a in ap_oct2),
          "anular una consignación anula también sus aportes")
    oct2 = c.post("/api/r/consignaciones", headers=H, json={"id_empresa": 1, "id_cuenta_destino": 1, "periodo_mes": 10, "periodo_anio": 2026,
                  "monto_total_consignado": "1", "fecha_consignacion": "2026-10-05"})
    check(oct2.status_code == 201, "lo anulado no ocupa el lugar: se registra de nuevo la consignación del mes")
    g2 = c.post(f"/api/consignaciones/{oct2.json()['id_consignacion']}/generar-aportes", headers=H).json()
    check(g2["aportes_creados"] == len(ap_oct), "y se vuelven a generar los aportes de ese mes")

    print("Datos personales (Ley 1581): reserva, bitácora de accesos, consentimiento, titulares y anonimización")
    if os.environ.get("SUPER_DATABASE_URL"):
        import psycopg as _pg
        with _pg.connect(os.environ["DATABASE_URL"], autocommit=True) as ac2:
            def _lee(q):
                try:
                    ac2.execute(q); return "OK"
                except _pg.Error as e:
                    return str(e)
            check("permission denied" in _lee("SELECT genero FROM gobernanza.persona LIMIT 1")
                  and "permission denied" in _lee("SELECT salario_base FROM gobernanza.afiliado_empresa LIMIT 1")
                  and _lee("SELECT dni, primer_nombre FROM gobernanza.persona LIMIT 1") == "OK",
                  "la cuenta de la aplicación no puede leer salario ni género (reserva en la base de datos)")
            check("permission denied" in _lee("SELECT * FROM auditoria.acceso_dato LIMIT 1"),
                  "ni leer directamente la bitácora de accesos")
        with _pg.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            sin_inv = sc.execute("""SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
                                     WHERE c.relkind = 'v' AND n.nspname IN ('gobernanza', 'gestion_documental', 'finanzas')
                                       AND c.relname NOT LIKE 'vf\\_%' AND NOT COALESCE(c.reloptions::text LIKE '%security_invoker=true%', false)""").fetchone()[0]
            check(sin_inv == 0, "todas las vistas de alertas siguen respetando el ámbito territorial de quien consulta")
    # La Presidencia Nacional trabaja con ámbito nacional
    upn = c.get("/api/r/usuarios", headers=H, params={"q": "tesoreria.nacional"}).json()["filas"][0]
    dar_rol(upn["id_usuario"], "TESORERO")
    pp = c.get("/api/r/personas/registro", headers=H, params={"id_persona": sin_cargo}).json()
    check(pp["genero"] is None and pp["_puede_ver_reservado"] is True, "el género no sale en la ficha (se pide aparte)")
    ae_r = c.get("/api/r/afiliados_empresa/registro", headers=HPN, params={"id_persona": p_ret, "id_empresa": 1}).json()
    check(ae_r["salario_base"] is None, "el salario tampoco sale en la ficha")
    rv = lambda hh, rec, pk, m=None: c.post("/api/privacidad/revelar", headers=hh, json={"recurso": rec, "pk": pk, "motivo": m})
    r = rv(HT, "afiliados_empresa", {"id_persona": p_ret, "id_empresa": 1})
    check(r.status_code in (403, 404), "el Tesorero de Medellín no ve el salario de un afiliado de Bogotá")
    r = rv(HPN, "afiliados_empresa", {"id_persona": p_ret, "id_empresa": 1}, "Verificación de la cuota")
    check(r.status_code == 200 and float(r.json()["valor"]) == 1000000, "la Presidencia Nacional sí lo ve, con motivo")
    r = rv(HT, "personas", {"id_persona": sin_cargo})
    check(r.status_code == 403 and "reservado" in r.json()["detail"], "Tesorería ve salarios, pero no el género")
    r = rv(HP, "personas", {"id_persona": sin_cargo})
    check(r.status_code == 200, "el Presidente de la junta del afiliado ve su género")
    r = rv(HF2, "personas", {"id_persona": sin_cargo})
    check(r.status_code == 403, "un usuario sin esos cargos no lo ve")
    r = c.get("/api/privacidad/bitacora", headers=HP)
    check(r.status_code == 403 and "Presidencia Nacional" in r.json()["detail"], "la bitácora de accesos no la ve un presidente regional")
    bit = c.get("/api/privacidad/bitacora", headers=HPN, params={"id_persona": p_ret}).json()
    check(any(b["tipo"] == "VER_DATO" and b["nombre_usuario"] == "tesoreria.nacional" and b["motivo"] == "Verificación de la cuota" for b in bit)
          and any(b["tipo"] == "FICHA" and b["recurso"] == "afiliados_empresa" for b in bit),
          "la bitácora registra quién vio la ficha y quién reveló el salario, con su motivo")
    c.get("/api/r/afiliados", headers=H, params={"tam": 5})
    bit = c.get("/api/privacidad/bitacora", headers=H, params={"usuario": "admin", "limite": 20}).json()
    check(any(b["tipo"] == "LISTADO" and b["recurso"] == "afiliados" and b["n_registros"] == 5 for b in bit),
          "consultar un listado de afiliados (dato sensible) también queda registrado")
    if os.environ.get("SUPER_DATABASE_URL"):
        with _pg.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            try:
                sc.execute("UPDATE auditoria.acceso_dato SET motivo = 'x'"); msg_i = "CAMBIÓ"
            except _pg.Error as e:
                msg_i = str(e)
            check("inmutable" in msg_i, "la bitácora de accesos es inmutable, incluso para un superusuario")
    HAN, id_an = crear_usuario("auditor.nacional", "AUDITOR")
    dar_rol(id_an, "AUDITOR")
    bc = c.get("/api/r/bitacora", headers=HAN, params={"q": "afiliado_empresa", "tam": 50}).json()["filas"]
    bc_a = c.get("/api/r/bitacora", headers=H, params={"q": "afiliado_empresa", "tam": 50}).json()["filas"]
    check(bc and all("salario_base" not in (f["datos_nuevos"] or {}) for f in bc) and any("_reservado" in (f["datos_nuevos"] or {}) for f in bc)
          and any("salario_base" in (f["datos_nuevos"] or {}) for f in bc_a),
          "en la bitácora de cambios el salario aparece oculto, salvo para el administrador")

    # Consentimiento
    def consent(pid):
        return next((f for f in vista("consentimiento") if f["id_persona"] == pid), None)
    check(consent(p_ret)["gestion_sindical"] == "PENDIENTE" and consent(p_ret)["_nivel"] == "ALTA",
          "afiliado sin autorización: se registró, pero queda pendiente con alerta")
    pol1 = [f for f in c.get("/api/r/politicas_tratamiento", headers=H).json()["filas"] if f["vigente"]][0]
    aut = lambda **kw: c.post("/api/r/autorizaciones_datos", headers=H, json={"id_persona": p_ret, "id_politica": pol1["id_politica"], **kw})
    r = aut(codigo_finalidad="GESTION_SINDICAL", otorgada=True, medio="FISICO")
    check(r.status_code == 400 and "soporte" in r.json()["detail"], "una autorización en papel exige el soporte escaneado")
    sop = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 2, "id_estamento": 1, "asunto": "Formato de autorización firmado"}).json()
    a1 = aut(codigo_finalidad="GESTION_SINDICAL", otorgada=True, medio="FISICO", id_documento_soporte=sop["id_documento"])
    check(a1.status_code == 201 and consent(p_ret)["gestion_sindical"] == "AUTORIZADA", "autorización con soporte: queda vigente")
    a2 = aut(codigo_finalidad="COMUNICACIONES", otorgada=False, medio="DIGITAL").json()
    check(consent(p_ret)["comunicaciones"] == "NEGADA", "también se registra cuando la persona NO autoriza una finalidad")
    check(c.put("/api/r/autorizaciones_datos/registro", headers=H, params={"id_autorizacion": a2["id_autorizacion"]},
                json={"otorgada": True, "version": 1}).status_code == 405, "una autorización no se edita")
    a3 = aut(codigo_finalidad="COMUNICACIONES", otorgada=True, medio="DIGITAL").json()
    a2b = c.get("/api/r/autorizaciones_datos/registro", headers=H, params={"id_autorizacion": a2["id_autorizacion"]}).json()
    check(a2b["estado"] == "REEMPLAZADA" and consent(p_ret)["comunicaciones"] == "AUTORIZADA", "si cambia de decisión, la nueva reemplaza a la anterior")
    r = c.post(f"/api/privacidad/autorizaciones/{a3['id_autorizacion']}/revocar", headers=H, json={"motivo": "La titular pidió no recibir correos"})
    check(r.status_code == 200 and r.json()["estado"] == "REVOCADA" and consent(p_ret)["comunicaciones"] == "REVOCADA", "revocación con motivo")
    pol2 = c.post("/api/r/politicas_tratamiento", headers=H, json={"numero_version": "2.0", "titulo": "Política revisada por el abogado",
                  "texto": "Texto revisado de la política de tratamiento de datos personales."}).json()
    r = c.post(f"/api/privacidad/politicas/{pol2['id_politica']}/publicar", headers=H)
    check(r.status_code == 400 and "acta" in r.json()["detail"], "una política nueva se publica solo con el acta que la aprobó")
    acta_p = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": 1, "asunto": "Acta: aprobación política de datos"}).json()
    pol2 = c.put("/api/r/politicas_tratamiento/registro", headers=H, params={"id_politica": pol2["id_politica"]},
                 json={"id_acta_aprobacion": acta_p["id_documento"], "version": pol2["version"]}).json()
    r = c.post(f"/api/privacidad/politicas/{pol2['id_politica']}/publicar", headers=H)
    check(r.status_code == 200 and r.json()["vigente"] and consent(p_ret)["gestion_sindical"] == "DESACTUALIZADA",
          "al publicar la versión 2.0, las autorizaciones de la 1.0 quedan desactualizadas")
    r = c.put("/api/r/politicas_tratamiento/registro", headers=H, params={"id_politica": pol2["id_politica"]},
              json={"texto": "Cambio posterior", "version": r.json()["version"]})
    check(r.status_code == 400 and "versión nueva" in r.json()["detail"], "una versión publicada no se modifica")

    # Solicitudes del titular y días hábiles
    if os.environ.get("SUPER_DATABASE_URL"):
        with _pg.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            fest = sc.execute("SELECT count(*), min(fecha) FILTER (WHERE nombre = 'Ascensión del Señor') FROM gobernanza.fn_festivos_colombia(2026)").fetchone()
            check(fest[0] == 18 and str(fest[1]) == "2026-05-18", "festivos de Colombia 2026 calculados (Ley Emiliani): 18, Ascensión el 18 de mayo")
    s1 = c.post("/api/r/solicitudes_titular", headers=H, json={"id_persona": p_ret, "tipo": "CONSULTA", "descripcion": "Quiero saber qué datos tienen de mí",
                "fecha_radicacion": "2026-10-02T18:30:00-05:00"}).json()
    check(s1["radicado"].startswith("SOL-2026-") and s1["fecha_limite"] == "2026-10-20",
          "consulta del viernes después de las 5 p. m.: cuenta desde el lunes; 10 días hábiles sin el festivo del 12 de octubre = 20 de octubre")
    s2 = c.post("/api/r/solicitudes_titular", headers=H, json={"id_persona": p_ret, "tipo": "SUPRESION", "descripcion": "Pido que borren mis datos",
                "fecha_radicacion": "2026-09-01T10:00:00-05:00"}).json()
    check(s2["fecha_limite"] == "2026-09-22", "reclamo (supresión): 15 días hábiles = 22 de septiembre")
    sv = {f["radicado"]: f for f in vista("solicitudes_titular")}
    check(sv[s2["radicado"]]["_nivel"] == "CRÍTICA", "plazo vencido sin respuesta: alerta crítica")
    r = c.post(f"/api/privacidad/solicitudes/{s2['id_solicitud']}/prorrogar", headers=H, json={"motivo": "Se requiere revisar archivos físicos"})
    check(r.status_code == 400 and "venció" in r.json()["detail"], "no se prorroga un plazo ya vencido")
    r = c.post(f"/api/privacidad/solicitudes/{s1['id_solicitud']}/prorrogar", headers=H, json={"motivo": "Se requiere revisar archivos físicos"})
    check(r.status_code == 200 and r.json()["fecha_limite"] == "2026-10-27", "prórroga de una consulta: 5 días hábiles más")
    r = c.post(f"/api/privacidad/solicitudes/{s1['id_solicitud']}/prorrogar", headers=H, json={"motivo": "Otra prórroga más larga"})
    check(r.status_code == 400 and "una vez" in r.json()["detail"], "solo se prorroga una vez")
    r = c.post(f"/api/privacidad/solicitudes/{s1['id_solicitud']}/responder", headers=H, json={"respuesta": "corta"})
    check(r.status_code == 400, "la respuesta debe quedar escrita")
    r = c.post(f"/api/privacidad/solicitudes/{s1['id_solicitud']}/responder", headers=H,
               json={"respuesta": "Se le envió el reporte completo de sus datos personales en PDF."})
    check(r.status_code == 200 and r.json()["estado"] == "RESPONDIDA", "solicitud respondida")
    rep_pdf = c.get(f"/api/privacidad/personas/{sin_cargo}/reporte", headers=HP)
    check(rep_pdf.status_code == 200 and rep_pdf.content[:4] == b"%PDF", "reporte «¿qué datos tienen de mí?» en PDF")
    check(c.get(f"/api/privacidad/personas/{sin_cargo}/reporte", headers=HT).status_code == 403,
          "el reporte completo no lo genera quien no puede ver los datos sensibles")

    # Anonimización con doble control
    r = c.post("/api/privacidad/anonimizaciones", headers=H, json={"id_persona": p_ret, "motivo": "Solicitud de supresión del titular",
               "id_solicitud": s2["id_solicitud"]})
    check(r.status_code == 400 and "inactive" in r.json()["detail"], "no se anonimiza a una persona activa")
    af = c.get("/api/r/afiliados/registro", headers=H, params={"id_persona": p_ret}).json()
    c.post("/api/r/afiliados/inactivar", headers=H, params={"id_persona": p_ret}, json={"motivo": "Retiro y solicitud de supresión", "version": af["version"]})
    pr = c.get("/api/r/personas/registro", headers=H, params={"id_persona": p_ret}).json()
    c.post("/api/r/personas/inactivar", headers=H, params={"id_persona": p_ret}, json={"motivo": "Retiro y solicitud de supresión", "version": pr["version"]})
    check(c.post("/api/privacidad/anonimizaciones", headers=HP, json={"id_persona": p_ret, "motivo": "Solicitud de supresión"}).status_code == 400,
          "solo el administrador solicita la anonimización")
    an1 = c.post("/api/privacidad/anonimizaciones", headers=H, json={"id_persona": p_ret, "motivo": "Solicitud de supresión del titular",
                 "id_solicitud": s2["id_solicitud"]}).json()["id_anonimizacion"]
    r = c.post(f"/api/privacidad/anonimizaciones/{an1}/aprobar", headers=H, json={})
    check(r.status_code == 400 and "Presidencia Nacional" in r.json()["detail"], "el administrador no puede aprobar su propia solicitud")
    r = c.post(f"/api/privacidad/anonimizaciones/{an1}/rechazar", headers=HPN, json={"observacion": "corto"})
    check(r.status_code == 400, "rechazar exige motivo")
    r = c.post(f"/api/privacidad/anonimizaciones/{an1}/rechazar", headers=HPN, json={"observacion": "Falta verificar la identidad del titular"})
    check(r.json()["estado"] == "RECHAZADA", "la Presidencia Nacional puede rechazarla")
    an2 = c.post("/api/privacidad/anonimizaciones", headers=H, json={"id_persona": p_ret, "motivo": "Identidad verificada, se suprimen los datos",
                 "id_solicitud": s2["id_solicitud"]}).json()["id_anonimizacion"]
    n_ap = len(c.get("/api/r/aportes", headers=H, params={"f_id_persona": p_ret, "tam": 200}).json()["filas"])
    r = c.post(f"/api/privacidad/anonimizaciones/{an2}/aprobar", headers=HPN, json={})
    pa = c.get("/api/r/personas/registro", headers=H, params={"id_persona": p_ret}).json()
    check(r.status_code == 200 and r.json()["estado"] == "EJECUTADA" and pa["dni"] == f"ANON-{p_ret}" and pa["primer_nombre"] == "ANONIMIZADO",
          "aprobada por la Presidencia Nacional: la persona queda anonimizada")
    check(len(c.get("/api/r/aportes", headers=H, params={"f_id_persona": p_ret, "tam": 200}).json()["filas"]) == n_ap,
          "los aportes y cifras financieras se conservan (sin identificar a la persona)")
    if os.environ.get("SUPER_DATABASE_URL"):
        with _pg.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            quedan = sc.execute("SELECT count(*) FROM auditoria.bitacora_cambios WHERE datos_anteriores::text LIKE '%%440777%%' "
                                "OR datos_nuevos::text LIKE '%%440777%%' OR datos_nuevos::text LIKE '%%retirado@med.org%%'").fetchone()[0]
            check(quedan == 0, "tampoco quedan su documento ni su correo en la bitácora de cambios")
    check(c.post("/api/privacidad/anonimizaciones", headers=H, json={"id_persona": p_ret, "motivo": "Otra vez la misma persona"}).status_code == 400,
          "no se anonimiza dos veces")

    # Purga y consultas inusuales
    check(c.post("/api/privacidad/bitacora/purgar", headers=H).json()["purgados"] == 0, "la purga solo borra lo que tiene más de 5 años")
    check(c.post("/api/privacidad/bitacora/purgar", headers=HPN).status_code == 403, "la purga la hace solo el administrador")
    pv = c.get("/api/r/parametros_privacidad/registro", headers=H, params={"codigo": "CONSULTAS_DIA_ALERTA"}).json()
    pv = c.put("/api/r/parametros_privacidad/registro", headers=H, params={"codigo": "CONSULTAS_DIA_ALERTA"}, json={"valor": "1", "version": pv["version"]}).json()
    inus = vista("accesos_inusuales")
    check(any(f["nombre_usuario"] == "admin" for f in inus), "alerta de consultas inusuales de datos personales")
    check(vista("accesos_inusuales", HAN) == [], "esa alerta solo la ve el administrador o la Presidencia Nacional")
    c.put("/api/r/parametros_privacidad/registro", headers=H, params={"codigo": "CONSULTAS_DIA_ALERTA"}, json={"valor": "50", "version": pv["version"]})

    print("Aporte de 0,6 % / 0,7 %, novedades de nómina y exoneraciones")
    if os.environ.get("SUPER_DATABASE_URL"):
        with _pg.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            pm = sc.execute("SELECT finanzas.fn_primer_mes_cobro('2020-01-01', '2026-06-05'), finanzas.fn_primer_mes_cobro('2020-01-01', '2026-06-08'), "
                            "finanzas.fn_primer_mes_cobro('2026-03-20', '2018-01-15')").fetchone()
            check([str(x) for x in pm] == ["2026-06-01", "2026-07-01", "2026-04-01"],
                  "ingreso entre el 1 y el 7: se cobra ese mes; del 8 en adelante: desde el mes siguiente")
    def afil_med(dni, nombre, salario, ingreso):
        pid = nuevo_afiliado(dni, nombre, 2)
        r = c.post("/api/r/afiliados_empresa", headers=H, json={"id_persona": pid, "id_empresa": emp_med["id_empresa"], "salario_base": str(salario),
                   "fecha_ingreso_empresa": ingreso})
        assert r.status_code == 201, r.text
        return pid
    pA = afil_med("550001", "APORTA", 1500000, "2026-06-10")
    pB = afil_med("550002", "BETA", 1234567, "2024-01-01")
    pC = afil_med("550003", "CETA", 2000000, "2024-01-01")
    pj = lambda **kw: c.post("/api/r/porcentajes_junta", headers=HT, json={"id_estamento": 2, **kw})
    pa = lambda pid, pct, desde, hh=HT: c.post("/api/r/porcentajes_afiliado", headers=hh, json={"id_persona": pid, "porcentaje": pct, "vigente_desde": desde})
    r = pj(porcentaje="0.5", vigente_desde="2026-07-01")
    check(r.status_code in (400, 409), "solo se aceptan los porcentajes autorizados (0,6 y 0,7)")
    r = pj(porcentaje="0.6", vigente_desde="2026-07-15")
    check(r.status_code == 201 and r.json()["vigente_desde"] == "2026-07-01",
          "carga inicial: la Subdirectiva Medellín aún aplica el 0,6 % (desde julio; se toma el mes completo)")
    def cons_med(mes):
        r = c.post("/api/r/consignaciones", headers=H, json={"id_empresa": emp_med["id_empresa"], "id_cuenta_destino": 1, "periodo_mes": mes,
                   "periodo_anio": 2026, "monto_total_consignado": "100000", "fecha_consignacion": "2026-10-05"})
        assert r.status_code == 201, r.text
        c.post(f"/api/consignaciones/{r.json()['id_consignacion']}/generar-aportes", headers=H)
        return {a["id_persona"]: a for a in c.get("/api/r/aportes", headers=H, params={"f_id_consignacion": r.json()["id_consignacion"], "tam": 200}).json()["filas"]}
    ap6 = cons_med(6)
    ap7 = cons_med(7)
    check(pA not in ap6 and float(ap7[pA]["monto_descuento_ley"]) == 9000 and float(ap7[pA]["porcentaje_aplicado"]) == 0.6,
          "ingresó el 10 de junio: junio no se cobra; julio al 0,6 % de su junta = 9.000")
    check(float(ap7[pB]["monto_descuento_ley"]) == 7407, "redondeo al peso: 0,6 % de 1.234.567 = 7.407")
    rA = pa(pA, "0.7", "2026-08-01")
    check(rA.status_code == 201, "un afiliado puede pasar al 0,7 % antes que su junta")
    r = pa(pA, "0.6", "2026-09-01")
    check(r.status_code == 400 and "no puede bajar" in r.json()["detail"], "y ya no puede volver al 0,6 %")
    r = c.post(f"/api/finanzas/porcentajes/afiliado/{rA.json()['id_porcentaje_afiliado']}/corregir", headers=HT,
               json={"porcentaje": "0.6", "motivo": "Se digitó mal el porcentaje"})
    check(r.status_code == 400 and "administrador" in r.json()["detail"], "el Tesorero no corrige hacia abajo")
    r = c.post(f"/api/finanzas/porcentajes/afiliado/{rA.json()['id_porcentaje_afiliado']}/corregir", headers=H,
               json={"porcentaje": "0.6", "motivo": "Se digitó mal el porcentaje"})
    rA2 = c.get("/api/r/porcentajes_afiliado/registro", headers=H, params={"id_porcentaje_afiliado": rA.json()["id_porcentaje_afiliado"]}).json()
    check(r.status_code == 200 and rA2["corregido"] and float(rA2["porcentaje"]) == 0.6 and "mal" in rA2["motivo_correccion"],
          "el administrador corrige un error de digitación, con motivo, si aún no hay aportes con ese porcentaje")
    pj0 = c.get("/api/r/porcentajes_junta", headers=H, params={"f_id_estamento": 2}).json()["filas"][0]
    r = c.post(f"/api/finanzas/porcentajes/junta/{pj0['id_porcentaje_junta']}/corregir", headers=H,
               json={"porcentaje": "0.7", "motivo": "Corrección del porcentaje de la junta"})
    check(r.status_code == 400 and "Ya se generaron" in r.json()["detail"], "no se corrige un porcentaje con el que ya se generaron aportes")
    check(pa(pB, "0.6", "2026-08-01").status_code == 201, "en una junta al 0,6 % se puede registrar a un afiliado al 0,6 %")
    r = pj(porcentaje="0.7", vigente_desde="2026-09-01")
    check(r.status_code == 400 and "acta" in r.json()["detail"], "el cambio de porcentaje de la junta exige el acta")
    acta_pj = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": 2, "asunto": "Acta: la subdirectiva aplica el 0,7 %"}).json()
    r = pj(porcentaje="0.7", vigente_desde="2026-09-01", id_acta=acta_pj["id_documento"])
    check(r.status_code == 201 and r.json()["afiliados_actualizados"] > 0, f"transición de la junta al 0,7 % ({r.json().get('afiliados_actualizados')} afiliados)")
    trans = {f["id_persona"]: f for f in c.get("/api/r/porcentajes_afiliado", headers=H, params={"f_origen": "TRANSICION", "tam": 200}).json()["filas"]}
    check(pA in trans and pB in trans and float(trans[pB]["porcentaje"]) == 0.7 and trans[pB]["vigente_desde"] == "2026-09-01",
          "los afiliados que seguían en 0,6 % pasan con la junta desde el mismo mes")
    r = pj(porcentaje="0.6", vigente_desde="2026-10-01", id_acta=acta_pj["id_documento"])
    check(r.status_code == 400 and "no puede bajar" in r.json()["detail"], "una junta no vuelve del 0,7 % al 0,6 %")
    r = pa(pC, "0.6", "2026-10-01")
    check(r.status_code == 400 and "ya aplica" in r.json()["detail"], "en una junta que ya pasó al 0,7 % no se registra a nadie al 0,6 %")
    ap9 = cons_med(9)
    check(float(ap9[pB]["porcentaje_aplicado"]) == 0.7 and float(ap9[pB]["monto_descuento_ley"]) == 8642,
          "septiembre ya se calcula al 0,7 % (8.642) y julio quedó al 0,6 %")
    c.post("/api/r/porcentajes_junta", headers=H, json={"id_estamento": 3, "porcentaje": "0.6", "vigente_desde": "2026-10-01"})
    tv = {f["junta"]: f for f in vista("transicion_aporte")}
    check(tv["Subdirectiva Medellín"]["diagnostico"].startswith("APLICA") and tv["Comité Seccional Cali"]["_nivel"] == "MEDIA",
          "vista de transición: Medellín ya aplica el 0,7 %; Cali aún no")
    check(int(tv["Comité Seccional Cali"]["afiliados_por_debajo"]) >= 1 and float(tv["Comité Seccional Cali"]["diferencia_mensual"]) > 0,
          "y muestra cuántos afiliados siguen por debajo y cuánto dinero mensual representa")

    # Exoneraciones
    ex = c.post("/api/r/exoneraciones", headers=HT, json={"id_persona": pA, "desde_mes": "2026-11-01", "hasta_mes": "2026-12-01",
                "motivo": "Calamidad doméstica: solicita no descontar la cuota"}).json()
    check(ex["estado"] == "SOLICITADA", "el afiliado pide la exoneración (queda solicitada)")
    r = c.post(f"/api/finanzas/exoneraciones/{ex['id_exoneracion']}/aprobar", headers=HT, json={"id_acta": acta_pj["id_documento"]})
    check(r.status_code == 400 and "Presidente" in r.json()["detail"], "la decisión no la registra el Tesorero")
    r = c.post(f"/api/finanzas/exoneraciones/{ex['id_exoneracion']}/aprobar", headers=HP, json={})
    check(r.status_code == 400 and "acta" in r.json()["detail"], "la junta decide con acta")
    r = c.post(f"/api/finanzas/exoneraciones/{ex['id_exoneracion']}/aprobar", headers=HP, json={"id_acta": acta_pj["id_documento"]})
    check(r.status_code == 200 and r.json()["estado"] == "APROBADA", "el Presidente registra la aprobación con el acta de la junta")
    ap11 = cons_med(11)
    check(pA not in ap11 and pB in ap11, "en los meses exonerados no se le genera aporte (a los demás sí)")
    exv = next(f for f in vista("exoneraciones") if f["id_exoneracion"] == ex["id_exoneracion"])
    check(exv["meses"] == 2 and float(exv["valor_exonerado"]) == 21000 and "CONSIGNÓ EN MESES EXONERADOS" in exv["diagnostico"],
          "control de exoneraciones: 2 meses, 21.000 y aviso porque la empresa consignó noviembre")
    ex2 = c.post("/api/r/exoneraciones", headers=HT, json={"id_persona": pA, "desde_mes": "2026-12-01", "hasta_mes": "2027-01-01",
                 "motivo": "Prolongación de la calamidad doméstica"}).json()
    r = c.post(f"/api/finanzas/exoneraciones/{ex2['id_exoneracion']}/aprobar", headers=HP, json={"id_acta": acta_pj["id_documento"]})
    check(r.status_code == 400 and "cubre parte" in r.json()["detail"], "no se superponen dos exoneraciones aprobadas")
    r = c.post(f"/api/finanzas/exoneraciones/{ex2['id_exoneracion']}/negar", headers=HP, json={"id_acta": acta_pj["id_documento"]})
    check(r.status_code == 400, "negar exige explicar el motivo")
    r = c.post(f"/api/finanzas/exoneraciones/{ex2['id_exoneracion']}/negar", headers=HP,
               json={"id_acta": acta_pj["id_documento"], "observacion": "Ya se concedió una exoneración por ese mes"})
    check(r.json()["estado"] == "NEGADA", "la junta también puede negarla")
    check(c.put("/api/r/exoneraciones/registro", headers=HT, params={"id_exoneracion": ex["id_exoneracion"]},
                json={"motivo": "Cambio después de aprobada", "version": 2}).status_code in (400, 409), "una exoneración decidida no se modifica")

    # Meses cerrados
    c.post("/api/finanzas/cierres", headers=HT, json={"id_estamento": 2, "anio": 2026, "mes": 6})
    r = pa(pC, "0.7", "2026-06-01")
    check(r.status_code == 400 and "cerrado" in r.json()["detail"], "un cambio de porcentaje no puede regir desde un mes cerrado")

    print("Ventanilla y portal del afiliado")
    import re as _re
    HV, id_v = crear_usuario("ventanilla.med", "VENTANILLA")
    c.post("/api/r/ambitos_usuario", headers=H, json={"id_usuario": id_v, "id_estamento": 2})
    r = c.post("/api/r/personas", headers=HV, json={"tipo_dni": "CC", "dni": "770001", "primer_nombre": "NUEVA", "primer_apellido": "AFILIADA",
               "correo_electronico": "nueva@med.org"})
    check(r.status_code == 201, "Ventanilla registra a una persona con sus datos básicos")
    p_nueva = r.json()["id_persona"]
    r = c.post("/api/r/afiliados", headers=HV, json={"id_persona": p_nueva, "fecha_afiliacion": "2026-10-01", "fecha_nacimiento": "1990-01-01",
               "nivel_educativo": "PROFESIONAL", "cargo_empresa": "PROFESIONAL", "id_estamento_pertenencia": 2})
    check(r.status_code == 403, "Ventanilla no afilia directamente")
    sol = lambda pid, hh=HV: c.post("/api/r/solicitudes_afiliacion", headers=hh, json={
        "id_persona": pid, "id_estamento": 2, "id_empresa": emp_med["id_empresa"], "fecha_ingreso_empresa": "2024-02-01", "salario_base": "1800000",
        "fecha_nacimiento": "1990-01-01", "nivel_educativo": "PROFESIONAL", "cargo_empresa": "PROFESIONAL", "medio": "VENTANILLA"})
    s1 = sol(p_nueva)
    check(s1.status_code == 201 and s1.json()["radicado"].startswith("SAF-") and s1.json()["salario_base"] is None,
          "Ventanilla recibe la solicitud de afiliación (radicada; el salario queda reservado)")
    s1 = s1.json()
    r = c.post("/api/privacidad/revelar", headers=HV, json={"recurso": "solicitudes_afiliacion", "pk": {"id_solicitud_afiliacion": s1["id_solicitud_afiliacion"]}})
    check(r.status_code == 403, "Ventanilla no ve el salario que registró")
    check(c.get("/api/r/aportes", headers=HV).status_code == 403, "ni entra a finanzas")
    r = c.post(f"/api/afiliaciones/{s1['id_solicitud_afiliacion']}/aprobar", headers=HV, json={})
    check(r.status_code in (400, 403) and "Presidente" in r.json()["detail"], "Ventanilla no aprueba la afiliación")
    r = c.post(f"/api/afiliaciones/{s1['id_solicitud_afiliacion']}/aprobar", headers=HP, json={})
    check(r.status_code == 400 and "documentos" in r.json()["detail"], "sin documentos no se aprueba la afiliación")
    for cod in ("CEDULA", "FORMATO_AFILIACION"):
        r = c.post(f"/api/afiliacion/expedientes/{p_nueva}/documentos/{cod}", headers=HV, files=[("archivos", ("doc.pdf", pdf_real(cod)))])
        assert r.status_code == 200, r.text
    r = c.post(f"/api/afiliaciones/{s1['id_solicitud_afiliacion']}/aprobar", headers=HP, json={})
    check(r.status_code == 400 and "revisar" in r.json()["detail"], "con los documentos cargados pero sin revisar tampoco")
    for d in c.get(f"/api/afiliacion/expedientes/{p_nueva}", headers=HP).json()["documentos"]:
        if d["obligatorio"]:
            c.post(f"/api/afiliacion/documentos/{d['id_documento']}/revisar", headers=HP, json={"aceptar": True})
    r = c.post(f"/api/afiliaciones/{s1['id_solicitud_afiliacion']}/aprobar", headers=HP, json={})
    af_n = c.get("/api/r/afiliados/registro", headers=HP, params={"id_persona": p_nueva})
    check(r.status_code == 200 and r.json()["estado"] == "APROBADA" and af_n.status_code == 200 and af_n.json()["activo"],
          "con la cédula y el formato aceptados, el Presidente aprueba: se crean el afiliado, su empresa y su salario")
    rv_n = c.post("/api/privacidad/revelar", headers=HP, json={"recurso": "afiliados_empresa", "pk": {"id_persona": p_nueva, "id_empresa": emp_med["id_empresa"]}})
    check(float(rv_n.json()["valor"]) == 1800000, "con el salario declarado en la solicitud")
    check(sol(p_nueva).status_code == 400, "no se recibe otra solicitud de quien ya es afiliado")
    p_otra = c.post("/api/r/personas", headers=HV, json={"tipo_dni": "CC", "dni": "770002", "primer_nombre": "OTRA", "primer_apellido": "SOLICITUD",
                    "correo_electronico": "otra.sol@med.org"}).json()["id_persona"]
    s2 = sol(p_otra).json()
    check(c.post(f"/api/afiliaciones/{s2['id_solicitud_afiliacion']}/rechazar", headers=HP, json={}).status_code == 400, "rechazar exige motivo")
    r = c.post(f"/api/afiliaciones/{s2['id_solicitud_afiliacion']}/rechazar", headers=HP, json={"observacion": "No trabaja en una entidad pública"})
    check(r.json()["estado"] == "RECHAZADA", "la junta también puede rechazarla")
    check(any(f["radicado"] == s1["radicado"] for f in vista("solicitudes_afiliacion")), "vista de solicitudes de afiliación")

    # Invitación y activación de la cuenta del afiliado
    n0 = len(BUZON)
    r = c.post("/api/autoservicio/invitaciones", headers=HP, json={"id_persona": pB})
    _t.sleep(0.5)
    inv = [m for to, m in BUZON[n0:] if "beta@med.org" in to]
    check(r.status_code == 200 and r.json()["enviado"] and inv and "enlace" not in r.json(),
          "la junta invita al afiliado: le llega un enlace a su correo (no se muestra a quien invita)")
    token = _re.search(r"t=([A-Za-z0-9_-]+)", inv[0].get_body(preferencelist=("plain",)).get_content()).group(1)
    check(c.get("/api/publico/invitacion", params={"t": "falso"}).status_code == 404, "un enlace inventado no sirve")
    vi = c.get("/api/publico/invitacion", params={"t": token}).json()
    check(vi["nombre"] == "BETA" and vi["politica_version"] == "2.0", "la página de activación muestra la política de datos vigente")
    act = lambda **kw: c.post("/api/publico/activar", json={"token": token, "nombre_usuario": "beta.med", "contrasena": "Afiliada#2026x", **kw})
    r = act(acepta_politica=False)
    check(r.status_code == 400 and "aceptar" in r.json()["detail"], "sin aceptar la política de datos no se crea la cuenta")
    r = c.post("/api/publico/activar", json={"token": token, "nombre_usuario": "beta.med", "contrasena": "corta", "acepta_politica": True})
    check(r.status_code == 400, "la contraseña debe cumplir la política")
    r = act(acepta_politica=True, acepta_comunicaciones=True, acepta_imagen=False)
    check(r.status_code == 200 and r.json()["nombre_usuario"] == "beta.med", "el afiliado crea su cuenta con el enlace")
    check(act(acepta_politica=True).status_code == 400, "el enlace sirve una sola vez")
    check(c.post("/api/autoservicio/invitaciones", headers=HP, json={"id_persona": pB}).status_code == 400, "no se invita a quien ya tiene cuenta")
    cb = consent(pB)
    check(cb["gestion_sindical"] == "AUTORIZADA" and cb["comunicaciones"] == "AUTORIZADA" and cb["uso_imagen"] == "NEGADA",
          "al activar quedan registradas sus autorizaciones de datos (medio: portal)")
    HAF = auth(login(c, "beta.med", "Afiliada#2026x")["token"])
    yo_af = c.get("/api/auth/yo", headers=HAF).json()
    check(yo_af["codigo_rol"] == "AFILIADO" and yo_af["recursos"] == [] and yo_af["portal_afiliado"], "el afiliado entra solo a su portal")
    check(c.get("/api/r/afiliados", headers=HAF).status_code == 403 and c.get("/api/r/personas/registro", headers=HAF, params={"id_persona": pA}).status_code == 403,
          "no puede abrir las pantallas generales ni datos de otras personas")
    perf = c.get("/api/autoservicio/perfil", headers=HAF).json()
    check(perf["documento"] == "CC 550002" and perf["junta"] == "Subdirectiva Medellín" and float(perf["salario"]) == 1234567
          and float(perf["porcentaje_aporte"]) == 0.7, "Mi perfil: sus datos, su junta, su salario y su porcentaje de aporte")
    mis = {a["periodo"]: a for a in c.get("/api/autoservicio/aportes", headers=HAF).json()}
    check(float(mis["2026-07"]["porcentaje"]) == 0.6 and float(mis["2026-07"]["registrado"]) == 7407 and mis["2026-07"]["estado"] == "AL DÍA"
          and float(mis["2026-09"]["registrado"]) == 8642 and mis["2026-08"]["estado"] == "LA EMPRESA NO HA REPORTADO EL APORTE",
          "Mis aportes: mes a mes con su porcentaje; si la empresa no reportó, se lo dice sin culparlo")
    c.get("/api/r/afiliados/registro", headers=HP, params={"id_persona": pB})
    priv = c.get("/api/autoservicio/privacidad", headers=HAF).json()
    check(any(a["usuario"] == "presi.med" for a in priv["accesos"]), "Privacidad: ve quién consultó sus datos")
    check(c.post("/api/autoservicio/privacidad", headers=HAF, json={"finalidad": "IMAGEN", "otorgada": True}).json()["estado"] == "AUTORIZADA",
          "puede cambiar las autorizaciones opcionales")
    check(c.post("/api/autoservicio/privacidad", headers=HAF, json={"finalidad": "GESTION_SINDICAL", "otorgada": False}).status_code == 400,
          "la de gestión sindical se cambia con una solicitud, no desde el portal")
    r = c.put("/api/autoservicio/perfil", headers=HAF, json={"telefono": "300 123 4567"})
    check(r.json()["telefono"] == "300 123 4567", "actualiza su teléfono")
    n0 = len(BUZON)
    c.post("/api/autoservicio/correo", headers=HAF, json={"correo": "beta.nueva@med.org"}); _t.sleep(0.5)
    conf = [m for to, m in BUZON[n0:] if "beta.nueva@med.org" in to]
    tok_c = _re.search(r"t=([A-Za-z0-9_-]+)", conf[0].get_body(preferencelist=("plain",)).get_content()).group(1)
    check(c.get("/api/autoservicio/perfil", headers=HAF).json()["correo"] == "beta@med.org", "el correo nuevo no cambia hasta confirmarlo")
    r = c.post("/api/autoservicio/correo/confirmar", headers=HAF, json={"token": tok_c})
    check(r.status_code == 200 and c.get("/api/autoservicio/perfil", headers=HAF).json()["correo"] == "beta.nueva@med.org",
          "al abrir el enlace enviado a la dirección nueva, queda confirmado")

    # Certificados con código de verificación
    r = c.post("/api/autoservicio/certificados", headers=HAF, json={"tipo": "AFILIACION"})
    cod = r.headers.get("x-codigo-verificacion")
    check(r.status_code == 200 and r.content[:4] == b"%PDF" and cod and len(cod) == 10, "certificado de afiliación en PDF con código de verificación")
    pv = c.get(f"/api/publico/certificados/{cod}").json()
    check(pv["valido"] and pv["titular"] == "B*** M***" and pv["documento"] == "***002" and "salario" not in str(pv),
          "verificación pública: válido, con nombre en iniciales y sin datos sensibles")
    check(c.get("/api/publico/certificados/NOEXISTE12").status_code == 404, "un código inexistente no verifica")
    r = c.post("/api/autoservicio/certificados", headers=HAF, json={"tipo": "PAZ_Y_SALVO"})
    cod_p = r.headers.get("x-codigo-verificacion")
    if os.environ.get("SUPER_DATABASE_URL"):
        with _pg.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            nota = sc.execute("SELECT contenido->>'nota' FROM gobernanza.certificado WHERE codigo = %s", (cod_p,)).fetchone()[0]
        check(nota and "2026-08" in nota and "no al afiliado" in nota,
              "paz y salvo con nota: la empresa no reportó agosto (la deuda es de la empresa, no del afiliado)")
    check(len(c.get("/api/autoservicio/certificados", headers=HAF).json()) == 2, "Mis certificados")
    rp = c.post(f"/api/autoservicio/personas/{pA}/certificados", headers=HP, json={"tipo": "AFILIACION"})
    cod_a = rp.headers.get("x-codigo-verificacion")
    check(rp.status_code == 200 and c.get(f"/api/autoservicio/certificados/{cod_a}/pdf", headers=HAF).status_code == 404
          and c.get(f"/api/autoservicio/certificados/{cod_a}/pdf", headers=HP).status_code == 200,
          "la junta expide certificados a sus afiliados; un afiliado no puede descargar el de otro")
    check(c.post(f"/api/autoservicio/personas/{pA}/certificados", headers=HAF, json={"tipo": "AFILIACION"}).status_code in (403, 400),
          "el afiliado no expide certificados de otros")
    check(c.get("/api/autoservicio/solicitudes", headers=HAF).status_code == 200, "Mis solicitudes")
    check(c.get("/api/autoservicio/perfil", headers=HV).status_code == 403, "quien no es afiliado no tiene portal")

    # Desafiliación: pierde el acceso al portal
    afb = c.get("/api/r/afiliados/registro", headers=H, params={"id_persona": pB}).json()
    c.post("/api/r/afiliados/inactivar", headers=H, params={"id_persona": pB}, json={"motivo": "Renuncia al sindicato", "version": afb["version"]})
    check(c.get("/api/autoservicio/perfil", headers=HAF).status_code == 401 and c.get(f"/api/publico/certificados/{cod}").json()["valido"] is False,
          "al desafiliarse pierde el acceso al portal y su certificado de afiliación deja de ser válido")

    print("PQRSD recibidas: plazos, prórroga, solicitud incompleta, traslado, revisión jurídica y respuesta")
    from app import auth as _auth_pq
    _auth_pq._intentos_ip.clear()
    import time as _tq
    pq = lambda hh=HP, **kw: c.post("/api/pqrsd", headers=hh, json={"tipo": "PETICION", "id_estamento": 2, "nombre_peticionario": "Laura Peña",
                                    "tipo_documento": "CC", "numero_documento": "52.111.222", "correo_peticionario": "laura.pena@correo.test",
                                    "asunto": "Copia del acta de la asamblea", "descripcion": "Solicito copia del acta de la última asamblea.",
                                    "motivo_registro_tardio": "Prueba con fecha fija de recepción", **kw})
    tipos_pq = {t["codigo"]: t["dias_habiles"] for t in c.get("/api/pqrsd/tipos", headers=HP).json()}
    check(tipos_pq["DOCUMENTOS"] == 10 and tipos_pq["DENUNCIA"] == 15 and tipos_pq["CONSULTA"] == 30 and tipos_pq["PETICION"] == 15,
          "plazos iniciales de la ley: documentos 10, denuncia 15, consulta 30 y petición 15 días hábiles")
    n0 = len(BUZON)
    r = pq(tipo="DOCUMENTOS", fecha_recepcion="2026-10-02T18:30:00-05:00")
    _tq.sleep(0.5)
    check(r.status_code == 200 and r.json()["radicado"].startswith("PQRSD-2026-") and r.json()["fecha_limite"] == "2026-10-20",
          "correo recibido el viernes a las 6:30 p. m.: cuenta desde el lunes; 10 días hábiles sin el festivo del 12 de octubre → 20 de octubre")
    q_doc = r.json()["id_pqrsd"]
    acuse = [m for to, m in BUZON[n0:] if "laura.pena@correo.test" in to]
    check(r.json()["correo"]["enviado"] and acuse and "20 de octubre" in acuse[0].get_body(preferencelist=("plain",)).get_content(),
          "al radicar le llega al peticionario el acuse con el radicado y la fecha límite")
    r = pq(tipo="CONSULTA", fecha_recepcion="2026-10-02T16:59:00-05:00")
    check(r.json()["fecha_limite"] == "2026-11-18", "la recibida antes de las 5 p. m. cuenta desde el día siguiente (consulta: 30 días hábiles, sin los festivos del 2 y el 16 de noviembre)")
    r = pq(anonima=True, nombre_peticionario=None, numero_documento=None, correo_peticionario=None, asunto="Denuncia sin firma")
    check(r.status_code == 200 and r.json()["estado"] == "ARCHIVADA_ANONIMA" and "Anónima" in r.json()["aviso"],
          "una PQRSD anónima se registra y se archiva sin trámite")
    r = pq(correo_peticionario=None)
    check(r.status_code == 400 and "correo" in r.json()["detail"], "si el peticionario se identifica, falta el correo es un error (no se vuelve anónima)")
    r = pq(fecha_recepcion="2026-09-01T09:00:00-05:00", motivo_registro_tardio=None)
    check(r.status_code == 400 and "tarde" in r.json()["detail"], "un registro tardío exige explicar la demora (el plazo corre desde que llegó)")
    r = pq(hh=HT)
    check(r.status_code in (400, 403), "el Tesorero no registra PQRSD")
    r = pq(hh=HV, tipo="QUEJA", fecha_recepcion=None, motivo_registro_tardio=None)
    check(r.status_code == 200 and r.json()["estado"] == "RADICADA", "la Ventanilla de la junta sí registra")
    q_v = r.json()["id_pqrsd"]
    check(c.post(f"/api/pqrsd/{q_v}/tramite", headers=HV).status_code == 200
          and c.get(f"/api/pqrsd/{q_v}", headers=HP).json()["pqrsd"]["estado"] == "EN_TRAMITE", "la Ventanilla la pasa a trámite")
    r = pq(hh=HV, id_estamento=3)
    check(r.status_code in (400, 403), "pero no en una junta fuera de su ámbito")
    check(c.post(f"/api/pqrsd/{q_v}/prorrogar", headers=HV, json={"dias": 5, "motivo": "Se requiere consultar a la empresa"}).status_code == 403,
          "la Ventanilla no prorroga")
    check(c.put(f"/api/pqrsd/{q_v}", headers=HP, json={"asunto": "Otro"}).status_code == 400, "el asunto y el contenido no se cambian")

    # Prórroga
    r = c.post(f"/api/pqrsd/{q_v}/prorrogar", headers=HP, json={"dias": 16, "motivo": "Se requiere consultar a la empresa"})
    check(r.status_code == 400 and "doble" in r.json()["detail"], "la prórroga no puede pasar el doble del plazo inicial")
    lim0 = c.get(f"/api/pqrsd/{q_v}", headers=HP).json()["pqrsd"]["fecha_limite"]
    n0 = len(BUZON)
    r = c.post(f"/api/pqrsd/{q_v}/prorrogar", headers=HP, json={"dias": 15, "motivo": "Se requiere información de la empresa para responder"})
    _tq.sleep(0.5)
    check(r.status_code == 200 and r.json()["fecha_limite"] > lim0 and any("laura.pena@correo.test" in to for to, _ in BUZON[n0:]),
          "prórroga de 15 días con aviso al peticionario")
    check(c.post(f"/api/pqrsd/{q_v}/prorrogar", headers=HP, json={"dias": 1, "motivo": "Otra prórroga adicional"}).status_code == 400,
          "solo una prórroga")

    # Solicitud incompleta y desistimiento tácito
    q_inc = pq(fecha_recepcion=None, motivo_registro_tardio=None, asunto="Reclamo por cuota").json()["id_pqrsd"]
    r = c.post(f"/api/pqrsd/{q_inc}/pedir-completar", headers=HP, json={"texto": "Indique el mes y adjunte el desprendible de pago"})
    check(r.status_code == 200, "se pide completar dentro de los 10 días hábiles")
    est = c.get(f"/api/pqrsd/{q_inc}", headers=HP).json()
    check(est["pqrsd"]["estado"] == "EN_REQUERIMIENTO" and est["plazo"]["diagnostico"].startswith("SUSPENDIDA"),
          "mientras tanto el plazo queda suspendido")
    r = c.post(f"/api/pqrsd/{q_inc}/desistimiento", headers=HP, json={"motivo": "No completó la información solicitada"})
    check(r.status_code == 400 and "todavía tiene plazo" in r.json()["detail"], "no se declara el desistimiento antes de que venza el mes")
    r = c.post(f"/api/pqrsd/{q_inc}/ampliar-completar", headers=HP, json={"motivo": "El peticionario lo pidió por correo"})
    check(r.status_code == 200, "el peticionario pide un mes más")
    check(c.post(f"/api/pqrsd/{q_inc}/ampliar-completar", headers=HP, json={"motivo": "Otra vez lo pidió"}).status_code == 400,
          "solo una ampliación")
    q_inc2 = pq(fecha_recepcion=None, motivo_registro_tardio=None, asunto="Petición incompleta 2").json()["id_pqrsd"]
    c.post(f"/api/pqrsd/{q_inc2}/pedir-completar", headers=HP, json={"texto": "Falta indicar a qué empresa se refiere la petición"})
    r = c.post(f"/api/pqrsd/{q_inc2}/completada", headers=HV, json={"detail": "x", "detalle": "Envió el nombre de la empresa por correo"})
    f2 = c.get(f"/api/pqrsd/{q_inc2}", headers=HP).json()
    check(r.status_code == 200 and f2["pqrsd"]["estado"] == "EN_TRAMITE" and any(h["tipo"] == "COMPLETADA" for h in f2["historia"]),
          "al completar, el plazo se reanuda con los días que le quedaban")

    # Traslado
    q_tr = pq(fecha_recepcion=None, motivo_registro_tardio=None, asunto="Asunto de Cali").json()["id_pqrsd"]
    n0 = len(BUZON)
    r = c.post(f"/api/pqrsd/{q_tr}/trasladar", headers=HP, json={"id_estamento": 3, "motivo": "El peticionario trabaja en Cali, no en Medellín"})
    _tq.sleep(0.5)
    check(r.status_code == 200 and r.json()["traslado"] == "INTERNO" and r.json()["correo"]["enviado"]
          and c.get(f"/api/pqrsd/{q_tr}", headers=HP).status_code == 404,
          "traslado a otra junta: se avisa al peticionario y deja de verla la junta de origen")
    q_ex = pq(fecha_recepcion=None, motivo_registro_tardio=None, asunto="Pensión").json()["id_pqrsd"]
    r = c.post(f"/api/pqrsd/{q_ex}/trasladar", headers=HP, json={"entidad": "Colpensiones", "correo_entidad": "pqr@colpensiones.test",
                                                               "motivo": "Es un asunto pensional, competencia de Colpensiones"})
    _tq.sleep(0.5)
    check(r.status_code == 200 and c.get(f"/api/pqrsd/{q_ex}", headers=HP).json()["pqrsd"]["estado"] == "TRASLADADA"
          and any("pqr@colpensiones.test" in to for to, _ in BUZON[n0:]),
          "traslado a una entidad externa, con copia a la entidad: el trámite termina aquí")

    # Denuncia: revisión jurídica obligatoria y respuesta firmada
    HAB, id_abq = crear_usuario("abogado.pqrsd", "ABOGADO")
    c.post("/api/r/ambitos_usuario", headers=H, json={"id_usuario": id_abq, "id_estamento": 2})
    q_den = pq(tipo="DENUNCIA", fecha_recepcion=None, motivo_registro_tardio=None, asunto="Denuncia de acoso").json()["id_pqrsd"]
    r = c.post(f"/api/pqrsd/{q_den}/responder", headers=HP, json={"respuesta": "Respuesta de fondo a la denuncia presentada por la peticionaria."})
    check(r.status_code == 400 and "concepto jurídico" in r.json()["detail"], "una denuncia no se responde sin el concepto jurídico")
    r = c.post(f"/api/pqrsd/{q_den}/concepto", headers=HP, json={"concepto": "Concepto jurídico del presidente que no es abogado."})
    check(r.status_code == 403, "el concepto no lo da el Presidente")
    r = c.post(f"/api/pqrsd/{q_den}/concepto", headers=HAB, json={"concepto": "Procede trasladar los hechos al comité de convivencia laboral."})
    check(r.status_code == 200, "lo da el abogado del ámbito")
    check(c.post(f"/api/pqrsd/{q_den}/responder", headers=HAB, json={"respuesta": "x" * 50}).status_code == 403, "el abogado no firma la respuesta")
    n0 = len(BUZON)
    r = c.post(f"/api/pqrsd/{q_den}/responder", headers=HP, json={"respuesta": "Hemos recibido su denuncia y la trasladamos al comité de convivencia laboral.\nLe informaremos."})
    _tq.sleep(0.5)
    resp = [m for to, m in BUZON[n0:] if "laura.pena@correo.test" in to]
    adj = [a for a in resp[0].iter_attachments()] if resp else []
    check(r.status_code == 200 and len(r.json()["huella"]) == 64 and adj and adj[0].get_content()[:4] == b"%PDF",
          "el Presidente firma: la respuesta llega al peticionario en PDF con huella SHA-256")
    pdf_r = c.get(f"/api/pqrsd/{q_den}/respuesta.pdf", headers=HP)
    check(pdf_r.status_code == 200 and pdf_r.content[:4] == b"%PDF", "la respuesta se puede volver a descargar")
    fd = c.get(f"/api/pqrsd/{q_den}", headers=HP).json()
    check(fd["pqrsd"]["cargo_firma"].startswith("PRESIDENTE REG") and [h["tipo"] for h in fd["historia"]][:2] == ["RADICACION", "CORREO_ENVIADO"]
          and "RESPUESTA" in [h["tipo"] for h in fd["historia"]], "queda la historia completa: radicación, correos, concepto y respuesta")
    check(c.post(f"/api/pqrsd/{q_den}/prorrogar", headers=HP, json={"dias": 2, "motivo": "Prórroga de una cerrada"}).status_code == 400,
          "una PQRSD respondida no se modifica")

    # Alertas y vencimientos
    if os.environ.get("SUPER_DATABASE_URL"):
        import psycopg as _pgq
        with _pgq.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            try:
                sc.execute("UPDATE gestion_documental.pqrsd_actuacion SET detalle = 'x'"); m_i = "CAMBIÓ"
            except _pgq.Error as e:
                m_i = str(e)
            check("inmutable" in m_i, "la historia de la PQRSD es inmutable")
            sc.execute("SELECT set_config('pqrsd.operacion', 'prueba', false)")
            sc.execute("""UPDATE gestion_documental.pqrsd SET fecha_base = gestion_documental.fn_hoy() - 40,
                                 fecha_limite = gestion_documental.fn_hoy() - 1 WHERE id_pqrsd = %s""", (q_doc,))
            sc.execute("""UPDATE gestion_documental.pqrsd SET fecha_limite_completar = gestion_documental.fn_hoy() - 1 WHERE id_pqrsd = %s""", (q_inc,))
            sc.execute("""UPDATE gestion_documental.pqrsd SET fecha_limite = gobernanza.fn_sumar_dias_habiles(gestion_documental.fn_hoy(), 2)
                           WHERE id_pqrsd = %s""", (q_inc2,))
        id_teso = c.get("/api/r/usuarios", headers=H, params={"q": "teso.med"}).json()["filas"][0]["id_usuario"]
        with _pg.connect(os.environ["DATABASE_URL"], autocommit=True) as ac3:
            try:
                ac3.execute("INSERT INTO gestion_documental.pqrsd_actuacion (id_pqrsd, tipo, detalle) VALUES (1, 'NOTA', 'x')"); m_a = "OK"
            except _pg.Error as e:
                m_a = str(e)
            check("permission denied" in m_a, "la aplicación no escribe la historia directamente")
            ac3.execute("SELECT set_config('app.id_usuario', %s, false), set_config('pqrsd.operacion', 'responder', false)", (str(id_teso),))
            try:
                ac3.execute("UPDATE gestion_documental.pqrsd SET estado = 'RESPONDIDA', respuesta = 'falsa' WHERE id_pqrsd = %s", (q_v,)); m_b = "SIN ERROR"
            except _pg.Error as e:
                m_b = str(e)
            check(c.get(f"/api/pqrsd/{q_v}", headers=HP).json()["pqrsd"]["estado"] == "EN_TRAMITE",
                  "fijar la variable de operación o un número de usuario no le sirve a la cuenta de la aplicación para saltarse las reglas")
            try:
                ac3.execute("UPDATE gestion_documental.parametro_pqrsd SET valor = 999 WHERE codigo = 'DIAS_PEDIR_COMPLETAR'"); m_c = ac3.execute(
                    "SELECT valor FROM gestion_documental.parametro_pqrsd WHERE codigo = 'DIAS_PEDIR_COMPLETAR'").fetchone()[0]
            except _pg.Error as e:
                m_c = str(e)
            check(str(m_c) == "10" or "violates" in str(m_c), "los plazos y parámetros no los cambia cualquiera")
        vq = {f["id_pqrsd"]: f for f in c.get("/api/vistas/pqrsd", headers=HP).json()["filas"]}
        check(vq[q_doc]["diagnostico"].startswith("ALERTA CRÍTICA: VENCIDA, SE ENTIENDE ACEPTADA"),
              "solicitud de documentos vencida: se entiende aceptada y hay que entregarlos en 3 días")
        check(vq[q_inc2]["nivel_alerta"] in ("ALTA", "MEDIA") and "80" in vq[q_inc2]["diagnostico"], "alerta al 80 % del plazo")
        check("DESISTIMIENTO" in vq[q_inc]["diagnostico"], "alerta cuando vence el plazo para completar")
        r = c.post(f"/api/pqrsd/{q_inc}/desistimiento", headers=HP, json={"motivo": "No completó la información en el plazo legal"})
        check(r.status_code == 200 and c.get(f"/api/pqrsd/{q_inc}", headers=HP).json()["pqrsd"]["estado"] == "DESISTIDA",
              "vencido el plazo, se declara el desistimiento tácito")
        n0 = len(BUZON)
        c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False, "tipos": "PQRSD_PLAZOS"}); _tq.sleep(0.5)
        al = [m for to, m in BUZON[n0:] if m["Subject"].startswith("PQRSD ")]
        check(any("venció sin respuesta" in m["Subject"] for m in al) and any("80 %" in m["Subject"] for m in al),
              "correo a la junta al 80 % y al vencer")
        n1 = len(BUZON)
        c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False, "tipos": "PQRSD_PLAZOS"}); _tq.sleep(0.5)
        check(not [m for to, m in BUZON[n1:] if m["Subject"].startswith("PQRSD ")], "cada alerta se envía una sola vez")
    lst = c.get("/api/pqrsd", headers=HP, params={"abiertas": True}).json()
    check(lst["resumen"]["abiertas"] >= 3 and all(f["id_estamento"] == 2 for f in lst["filas"]), "bandeja de la junta con su resumen")
    check(c.get("/api/pqrsd", headers=c and auth(login(c, "consulta1", "NuevaClave#2026")["token"])).status_code == 200,
          "el rol de consulta ve la bandeja (sin acciones)")

    print("Segundo factor de autenticación (MFA)")
    from app import auth as _auth_mod
    _auth_mod._intentos_ip.clear()   # el límite de ingresos por equipo no aplica a esta batería de pruebas
    from app.mfa import totp, paso_actual, verificar_totp
    _sec = "JBSWY3DPEHPK3PXP"
    check(verificar_totp(_sec, totp(_sec, paso_actual() - 5)) is not None and verificar_totp(_sec, totp(_sec, paso_actual() - 8)) is None,
          "el código de la aplicación se acepta hasta 3 minutos después de aparecer (y no más)")
    HM, id_m = crear_usuario("mfa.directivo", "DIRECTIVO")
    ym = c.get("/api/auth/yo", headers=HM).json()["mfa"]
    check(ym["requerido"] and not ym["activo"] and ym["dias_restantes"] >= 6 and ym["verificada"],
          "rol que ve datos de otras personas: MFA obligatorio con 7 días de plazo (mientras tanto ingresa normalmente)")
    cfg = c.post("/api/mfa/configurar", headers=HM).json()
    secreto = cfg["secreto"].replace(" ", "")
    check("<svg" in cfg["qr_svg"] and cfg["uri"].startswith("otpauth://totp/"), "código QR generado en el propio servidor")
    check(c.post("/api/mfa/confirmar", headers=HM, json={"codigo": "000000"}).status_code == 400, "un código equivocado no activa el MFA")
    paso_act = paso_actual()
    r = c.post("/api/mfa/confirmar", headers=HM, json={"codigo": totp(secreto, paso_act)})
    codigos = r.json().get("codigos_recuperacion", [])
    check(r.status_code == 200 and len(codigos) == 10 and len(set(codigos)) == 10, "MFA activado: entrega 10 códigos de recuperación")
    if os.environ.get("SUPER_DATABASE_URL"):
        with _pg.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            blob = bytes(sc.execute("SELECT secreto_cifrado FROM secretos.mfa_secreto WHERE id_usuario = %s", (id_m,)).fetchone()[0])
            hashes = [x[0] for x in sc.execute("SELECT hash_codigo FROM seguridad.mfa_recuperacion WHERE id_usuario = %s", (id_m,)).fetchall()]
        check(secreto.encode() not in blob and codigos[0] not in str(hashes),
              "la clave del autenticador se guarda cifrada y los códigos de recuperación solo como huella")
    t = login(c, "mfa.directivo", "Definitiva#2026x")
    HM2 = auth(t["token"])
    check(t["mfa"] == "VERIFICAR" and c.get("/api/r/documentos", headers=HM2).status_code == 403
          and c.get("/api/auth/yo", headers=HM2).json()["mfa"]["verificada"] is False,
          "con solo la contraseña la sesión queda por verificar: no accede a nada")
    r = c.post("/api/mfa/verificar", headers=HM2, json={"codigo": totp(secreto, paso_act), "metodo": "app"})
    check(r.status_code == 400, "un código ya usado no se acepta otra vez")
    r = c.post("/api/mfa/verificar", headers=HM2, json={"codigo": codigos[0].lower(), "metodo": "recuperacion"})
    check(r.status_code == 200 and "Le quedan 9" in (r.json()["aviso"] or "") and c.get("/api/r/documentos", headers=HM2).status_code == 200,
          "ingreso con un código de recuperación (le quedan 9)")
    HM3 = auth(login(c, "mfa.directivo", "Definitiva#2026x")["token"])
    check(c.post("/api/mfa/verificar", headers=HM3, json={"codigo": codigos[0], "metodo": "recuperacion"}).status_code == 400,
          "cada código de recuperación sirve una sola vez")
    for _ in range(3):
        c.post("/api/mfa/verificar", headers=HM3, json={"codigo": "111111", "metodo": "app"})
    r = c.post("/api/mfa/verificar", headers=HM3, json={"codigo": "111111", "metodo": "app"})
    check(r.status_code == 423 and c.get("/api/auth/yo", headers=HM3).status_code == 401
          and c.post("/api/auth/login", json={"nombre_usuario": "mfa.directivo", "contrasena": "Definitiva#2026x"}).status_code == 423,
          "cinco códigos errados bloquean la cuenta y cierran la sesión")
    c.post(f"/api/admin/usuarios/{id_m}/desbloquear", headers=H)
    HM4 = auth(login(c, "mfa.directivo", "Definitiva#2026x")["token"])
    r = c.post("/api/mfa/verificar", headers=HM4, json={"codigo": codigos[1], "metodo": "recuperacion", "recordar_equipo": True, "equipo": "Portátil oficina"})
    equipo = r.json()["equipo_confiable"]
    t5 = c.post("/api/auth/login", json={"nombre_usuario": "mfa.directivo", "contrasena": "Definitiva#2026x", "equipo_confiable": equipo}).json()
    check(equipo and t5["mfa"] is None and c.get("/api/r/documentos", headers=auth(t5["token"])).status_code == 200,
          "«recordar este equipo»: en ese equipo no vuelve a pedir el código (30 días)")
    c.post("/api/auth/cambiar-contrasena", headers=auth(t5["token"]), json={"contrasena_actual": "Definitiva#2026x", "contrasena_nueva": "Segunda#Clave2026"})
    t6 = c.post("/api/auth/login", json={"nombre_usuario": "mfa.directivo", "contrasena": "Segunda#Clave2026", "equipo_confiable": equipo}).json()
    check(t6["mfa"] == "VERIFICAR", "al cambiar la contraseña se olvidan los equipos recordados")
    HM6 = auth(t6["token"])
    check(c.post("/api/mfa/correo", headers=HM6).status_code == 400, "sin correo registrado no hay código por correo")
    um = c.get("/api/r/usuarios/registro", headers=H, params={"id_usuario": id_m}).json()
    c.put("/api/r/usuarios/registro", headers=H, params={"id_usuario": id_m}, json={"correo_electronico": "mfa@med.org", "version": um["version"]})
    n0 = len(BUZON)
    check(c.post("/api/mfa/correo", headers=HM6).status_code == 200, "código alterno por correo")
    _t.sleep(0.5)
    cod_c = _re.search(r"\b(\d{6})\b", next(m for to, m in BUZON[n0:] if "mfa@med.org" in to)["Subject"]).group(1)
    r = c.post("/api/mfa/verificar", headers=HM6, json={"codigo": cod_c, "metodo": "correo"})
    check(r.status_code == 200 and c.get("/api/r/documentos", headers=HM6).status_code == 200, "ingreso con el código enviado al correo")
    if os.environ.get("SUPER_DATABASE_URL"):
        t7 = login(c, "mfa.directivo", "Segunda#Clave2026")
        with _pg.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            sc.execute("UPDATE seguridad.sesion SET fecha_emision = now() - INTERVAL '6 minutes' WHERE id_usuario = %s AND NOT mfa_verificada", (id_m,))
        check(c.get("/api/auth/yo", headers=auth(t7["token"])).status_code == 401, "la sesión sin verificar vence a los 5 minutos")

    # Doble verificación en acciones críticas
    HAD, id_ad = crear_usuario("mfa.admin", "CONSULTA")
    dar_rol(id_ad, "ADMIN")
    sec_ad = c.post("/api/mfa/configurar", headers=HAD).json()["secreto"].replace(" ", "")
    cod_ad = c.post("/api/mfa/confirmar", headers=HAD, json={"codigo": totp(sec_ad, paso_actual())}).json()["codigos_recuperacion"]
    tad = login(c, "mfa.admin", "Definitiva#2026x")
    HAD2 = auth(tad["token"])
    r = c.post("/api/mfa/verificar", headers=HAD2, json={"codigo": cod_ad[0], "metodo": "recuperacion", "recordar_equipo": True})
    check(r.json()["equipo_confiable"] is None, "el administrador no puede recordar equipos")
    pm = c.get("/api/r/permisos/registro", headers=HAD2, params={"codigo_rol": "CONSULTA", "modulo": "DOCUMENTAL"}).json()
    c.post("/api/mfa/paso-adicional", headers=HAD2, json={"codigo": "999999"})  # intento fallido (no cuenta como verificación)
    if os.environ.get("SUPER_DATABASE_URL"):
        with _pg.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            sc.execute("UPDATE seguridad.sesion SET mfa_reciente_en = now() - INTERVAL '10 minutes' WHERE id_usuario = %s", (id_ad,))
    r = c.put("/api/r/permisos/registro", headers=HAD2, params={"codigo_rol": "CONSULTA", "modulo": "DOCUMENTAL"},
              json={"puede_ver_vistas": True, "version": pm["version"]})
    check(r.status_code == 428, "cambiar permisos es una acción crítica: pide de nuevo el código")
    check(c.post("/api/mfa/paso-adicional", headers=HAD2, json={"codigo": cod_ad[1], "metodo": "recuperacion"}).status_code == 200,
          "doble verificación con un código")
    r = c.put("/api/r/permisos/registro", headers=HAD2, params={"codigo_rol": "CONSULTA", "modulo": "DOCUMENTAL"},
              json={"puede_ver_vistas": True, "version": pm["version"]})
    check(r.status_code == 200, "verificado, la acción procede (la verificación vale 5 minutos)")
    if os.environ.get("SUPER_DATABASE_URL"):
        HV2, id_v2 = crear_usuario("mfa.vencido", "CONSULTA")
        with _pg.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            sc.execute("UPDATE seguridad.usuario SET mfa_plazo_hasta = now() - INTERVAL '1 day' WHERE id_usuario = %s", (id_v2,))
        tv = login(c, "mfa.vencido", "Definitiva#2026x")
        check(tv["mfa"] == "CONFIGURAR" and c.get("/api/r/personas", headers=auth(tv["token"])).status_code == 403
              and c.post("/api/mfa/configurar", headers=auth(tv["token"])).status_code == 200,
              "vencido el plazo de 7 días, debe activar el MFA antes de usar el sistema")

    # Reinicio por pérdida del celular (administrador + Presidencia Nacional)
    check(c.post("/api/mfa/reinicios", headers=HAD2, json={"id_usuario": id_ad, "motivo": "Perdí mi celular y los códigos"}).status_code in (400, 428),
          "el administrador no reinicia su propio MFA")
    rr = c.post("/api/mfa/reinicios", headers=H, json={"id_usuario": id_m, "motivo": "Perdió el celular y los códigos de recuperación"}).json()
    check(c.post(f"/api/mfa/reinicios/{rr['id_reinicio']}/aprobar", headers=H, json={}).status_code == 400,
          "quien lo solicita no lo aprueba")
    r = c.post(f"/api/mfa/reinicios/{rr['id_reinicio']}/aprobar", headers=HPN, json={})
    tr = login(c, "mfa.directivo", "Segunda#Clave2026")
    check(r.json()["estado"] == "APROBADO" and c.get("/api/auth/yo", headers=HM6).status_code == 401 and tr["mfa"] == "CONFIGURAR",
          "aprobado por la Presidencia Nacional: se cierran sus sesiones y debe configurar el MFA de nuevo")

    print("Reuniones: convocatoria, asistencia de todos, quórum, firmas y acta en PDF")
    from datetime import datetime as _dt, timedelta as _td
    from zoneinfo import ZoneInfo as _Z
    import hashlib as _hl
    import time as _t
    import psycopg as _pg
    p_sec = nuevo_afiliado("440020", "SECRE", 2)
    check(directivo(p_sec, 2, "SGEN_REG").status_code == 201, "Secretario General de la Subdirectiva Medellín nombrado")
    HS, _ = crear_usuario("secre.med", "DIRECTIVO", p_sec)
    conv = c.get("/api/reuniones/convocables", headers=HP).json()
    check([j["id_estamento"] for j in conv["juntas"]] == [2], "el Presidente puede convocar solo en su junta")

    def convocar(hh, fecha, hora="09:00", orden=("Informe de la presidencia", "Plan de trabajo del trimestre", "Varios")):
        return c.post("/api/reuniones/convocar", headers=hh, json={
            "id_estamento": 2, "fecha": fecha, "hora_inicio": hora, "modalidad": "PRESENCIAL",
            "lugar": "Sede Subdirectiva, Medellín", "orden_del_dia": list(orden)})

    ahora_local = _dt.now(_Z("America/Bogota"))
    r = convocar(HT, "2027-02-10")
    check(r.status_code == 403, "el Tesorero no puede convocar (sin permiso documental)")
    r = convocar(HC, "2027-02-10")
    check(r.status_code == 400 and "Solo el Presidente o el Secretario General" in r.json()["detail"],
          "otro directivo de la junta (sin ser Presidente ni Secretario) no puede convocar")
    if ahora_local.hour >= 20:
        r = convocar(HP, "2027-02-10")
        check(r.status_code == 400 and "8:00 p. m." in r.json()["detail"], "después de las 8:00 p. m. no se envían convocatorias")
        print("  (resto de pruebas de reuniones omitidas: se ejecutan antes de las 8:00 p. m.)")
    else:
        pronto = ahora_local + _td(hours=6)
        r = convocar(HP, pronto.strftime("%Y-%m-%d"), pronto.strftime("%H:%M"))
        check(r.status_code == 400 and "12 horas" in r.json()["detail"], "se exige convocar con 12 horas de anticipación")
        r = convocar(HP, "2027-02-10", orden=[])
        check(r.status_code == 400 and "orden del día" in r.json()["detail"], "la convocatoria exige orden del día")
        n0 = len(BUZON)
        ra = convocar(HP, "2027-02-20")
        check(ra.status_code == 201 and ra.json()["tipo_reunion"] == "ORDINARIA" and ra.json()["convocados"] >= 3,
              "primera reunión del trimestre: ORDINARIA, con los directivos vigentes convocados")
        a = ra.json()["id_reunion"]
        rb = convocar(HS, "2027-02-10")
        b = rb.json()["id_reunion"]
        tipo_a = lambda: c.get("/api/r/reuniones/registro", headers=HP, params={"id_reunion": a}).json()["tipo_reunion"]
        check(rb.json()["tipo_reunion"] == "ORDINARIA" and tipo_a() == "EXTRAORDINARIA",
              "otra reunión anterior en el trimestre pasa a ser la ORDINARIA; la otra queda EXTRAORDINARIA")
        check(convocar(HP, "2027-02-10").status_code == 400, "no se convocan dos reuniones a la misma fecha y hora")
        if os.environ.get("NOTIFICADOR_DATABASE_URL"):
            _t.sleep(0.5)
            convoc = [(to, m) for to, m in BUZON[n0:] if m["Subject"].startswith("Convocatoria:")]
            cuerpo = convoc[0][1].get_body(("plain",)).get_content() if convoc else ""
            check(len(convoc) == 2 * ra.json()["convocados"] and "presi@med.org" in sum((to for to, _ in convoc), [])
                  and "Plan de trabajo del trimestre" in cuerpo and "ordinaria" in convoc[0][1]["Subject"],
                  f"correo de convocatoria a cada directivo con el orden del día ({len(convoc)} correos)")
        r = c.post(f"/api/reuniones/{b}/cancelar", headers=HC, json={"motivo": "x"})
        check(r.status_code == 400, "solo Presidente o Secretario cancelan reuniones")
        n1 = len(BUZON)
        r = c.post(f"/api/reuniones/{b}/cancelar", headers=HS, json={"motivo": "Cruce con la asamblea departamental"})
        check(r.status_code == 200 and tipo_a() == "ORDINARIA", "al cancelar, la siguiente reunión del trimestre vuelve a ser ORDINARIA")
        if os.environ.get("NOTIFICADOR_DATABASE_URL"):
            _t.sleep(0.5)
            check(any(m["Subject"].startswith("CANCELADA:") for _, m in BUZON[n1:]), "correo de cancelación a los directivos")
        check(c.delete("/api/r/reuniones/registro", headers=H, params={"id_reunion": a, "version": 1}).status_code == 405,
              "las reuniones no se eliminan")
        r = c.post("/api/r/reunion_puntos", headers=HP, json={"id_reunion": a, "orden": 9, "tema": "Punto nuevo"})
        check(r.status_code == 400 and "al iniciar la reunión" in r.json()["detail"], "el orden del día convocado no cambia antes de la reunión")
        acta = c.get(f"/api/reuniones/{a}/acta", headers=HP).json()
        d0 = acta["asistentes"][0]
        r = c.put(f"/api/reuniones/{a}/asistencia", headers=HP, json={"filas": [{"id_asistente": d0["id_asistente"], "version": d0["version"], "asistio": True}]})
        check(r.status_code == 400 and "desde la hora de inicio" in r.json()["detail"], "la asistencia se toma desde la hora de inicio")

        SUPER = os.environ.get("SUPER_DATABASE_URL")
        def al_pasado(id_reunion, fecha):
            with _pg.connect(SUPER, autocommit=True) as sc:
                sc.execute("SELECT set_config('documental.operacion', 'tipo', false)")
                sc.execute("UPDATE gestion_documental.reunion SET fecha = %s, fecha_convocatoria = %s::date - 3 WHERE id_reunion = %s",
                           (fecha, fecha, id_reunion))
        if SUPER:
            al_pasado(a, "2026-07-15")   # simula que la reunión ya ocurrió
            r = c.post("/api/r/reunion_asistentes", headers=HP, json={"id_reunion": a, "nombre_invitado": "Luisa Pérez",
                       "documento_invitado": "CC 9001", "institucion": "Ministerio del Trabajo", "cargo": "Inspectora"})
            check(r.status_code == 201 and r.json()["calidad"] == "INVITADO", "invitado externo registrado sin ser persona del sistema")
            r = c.post("/api/r/reunion_asistentes", headers=HP, json={"id_reunion": a, "id_persona": 3, "calidad": "DIRECTIVO",
                       "cargo": "Presidente del Comité Cali"})
            check(r.status_code == 201 and r.json()["calidad"] == "INVITADO", "persona registrada invitada (siempre como INVITADO)")
            r = c.post("/api/r/reunion_asistentes", headers=HP, json={"id_reunion": a, "id_persona": 3, "nombre_invitado": "X"})
            check(r.status_code == 400 and "solo uno de los dos" in r.json()["detail"], "invitado: persona registrada o nombre externo, no ambos")
            r = c.post("/api/r/reunion_puntos", headers=HP, json={"id_reunion": a, "orden": 4, "tema": "Proposición: jornada de afiliación"})
            check(r.status_code == 201, "al iniciar la reunión se ajusta el orden del día")
            acta = c.get(f"/api/reuniones/{a}/acta", headers=HP).json()
            check(acta["orden_del_dia_modificado"], "el sistema detecta que el orden del día cambió frente al convocado")
            dirs = [x for x in acta["asistentes"] if x["calidad"] == "DIRECTIVO"]
            invs = [x for x in acta["asistentes"] if x["calidad"] == "INVITADO"]
            n = len(dirs)
            # Primero sin quórum: solo asiste uno
            filas = [{"id_asistente": x["id_asistente"], "version": x["version"], "asistio": i == 0,
                      "modalidad_asistencia": "PRESENCIAL" if i == 0 else None,
                      "excusa": None if i == 0 else ("Incapacidad médica" if i == 1 else None)} for i, x in enumerate(dirs)]
            filas += [{"id_asistente": x["id_asistente"], "version": x["version"], "asistio": True, "modalidad_asistencia": "VIRTUAL"} for x in invs]
            r = c.put(f"/api/reuniones/{a}/asistencia", headers=HP, json={"filas": filas})
            check(r.status_code == 200 and r.json()["quorum"]["asistentes"] == 1 and not r.json()["quorum"]["hay_quorum"]
                  and r.json()["quorum"]["invitados"] == 2, "asistencia de todos en un lote; los invitados no cuentan para el quórum")
            r2 = c.put(f"/api/reuniones/{a}/asistencia", headers=HP, json={"filas": filas})
            check(r2.status_code == 409, "lote de asistencia con versión vieja -> 409 (concurrencia)")
            pto = acta["puntos"][1]["id_punto"]
            dec = c.post("/api/r/reunion_decisiones", headers=HP, json={
                "id_reunion": a, "id_punto": pto, "texto": "Aprobar el plan de trabajo del trimestre",
                "votos_favor": n + 5, "votos_contra": 0, "abstenciones": 0, "compromiso_titulo": "Publicar el plan de trabajo",
                "id_persona_responsable": p_sec, "fecha_limite": "2026-08-15"})
            check(dec.status_code == 201 and dec.json()["aprobada"], "decisión con votación y compromiso")
            r = c.post(f"/api/reuniones/{a}/firmar", headers=HP)
            check(r.status_code == 400 and "Sin quórum no se pueden adoptar decisiones" in r.json()["detail"], "sin quórum no hay decisiones")
            acta = c.get(f"/api/reuniones/{a}/acta", headers=HP).json()
            dirs = [x for x in acta["asistentes"] if x["calidad"] == "DIRECTIVO"]
            filas = [{"id_asistente": x["id_asistente"], "version": x["version"], "asistio": i != 1,
                      "modalidad_asistencia": "PRESENCIAL" if i != 1 else None, "hora_llegada": "09:05" if i != 1 else None,
                      "excusa": "Incapacidad médica" if i == 1 else None} for i, x in enumerate(dirs)]
            r = c.put(f"/api/reuniones/{a}/asistencia", headers=HP, json={"filas": filas})
            q = r.json()["quorum"]
            check(q["hay_quorum"] and q["requerido"] == n // 2 + 1, f"quórum mitad más uno: {q['asistentes']} de {n} (requiere {q['requerido']})")
            r = c.post(f"/api/reuniones/{a}/firmar", headers=HP)
            check(r.status_code == 400 and "más votos" in r.json()["detail"], "no puede haber más votos que asistentes")
            dj = dec.json()
            c.put("/api/r/reunion_decisiones/registro", headers=HP, params={"id_decision": dj["id_decision"]},
                  json={"votos_favor": q["asistentes"] - 1, "votos_contra": 1, "version": dj["version"]})
            r = c.post(f"/api/reuniones/{a}/firmar", headers=HC)
            check(r.status_code == 400 and "firman el Presidente y el Secretario General" in r.json()["detail"], "solo firman Presidente y Secretario")
            r = c.post(f"/api/reuniones/{a}/firmar", headers=HP)
            check(r.status_code == 200 and r.json()["estado"] == "PENDIENTE", "primera firma (Presidencia)")
            check(c.post(f"/api/reuniones/{a}/firmar", headers=HP).status_code == 400, "no se firma dos veces el mismo rol")
            r = c.post("/api/r/reunion_puntos", headers=HP, json={"id_reunion": a, "orden": 5, "tema": "Otro"})
            check(r.status_code == 400 and "ya fue firmada" in r.json()["detail"], "después de la primera firma el contenido se congela")
            r = c.post(f"/api/reuniones/{a}/firmar", headers=HS)
            cierre = r.json()
            check(r.status_code == 200 and cierre["estado"] == "CERRADA" and "-ACT-" in cierre["radicado"],
                  f"segunda firma: acta cerrada y radicada {cierre.get('radicado')}")
            pdf = c.get(f"/api/reuniones/{a}/pdf", headers=HP)
            check(pdf.status_code == 200 and pdf.content.startswith(b"%PDF") and _hl.sha256(pdf.content).hexdigest() == cierre["hash_sha256"],
                  "PDF del acta adjunto al documento con huella SHA-256")
            check(c.get(f"/api/documentos/{cierre['id_documento']}/verificar", headers=H).json()["integro"], "integridad del acta verificable")
            comp = c.get("/api/r/compromisos", headers=HP, params={"f_id_documento_origen": cierre["id_documento"]}).json()["filas"]
            check(len(comp) == 1 and comp[0]["id_persona_responsable"] == p_sec, "el compromiso de la decisión quedó creado")
            open("/tmp/acta_prueba.pdf", "wb").write(pdf.content)
            # Siguiente reunión con quórum aprueba el acta anterior
            r2 = convocar(HP, "2027-02-25", orden=("Aprobación del acta anterior", "Varios"))
            nxt = r2.json()["id_reunion"]
            al_pasado(nxt, "2026-08-20")
            acta2 = c.get(f"/api/reuniones/{nxt}/acta", headers=HP).json()
            filas = [{"id_asistente": x["id_asistente"], "version": x["version"], "asistio": True} for x in acta2["asistentes"]]
            c.put(f"/api/reuniones/{nxt}/asistencia", headers=HP, json={"filas": filas})
            c.post(f"/api/reuniones/{nxt}/firmar", headers=HS)
            r = c.post(f"/api/reuniones/{nxt}/firmar", headers=HP)
            ant = c.get("/api/r/reuniones/registro", headers=HP, params={"id_reunion": a}).json()
            check(r.json()["estado"] == "CERRADA" and ant["estado"] == "APROBADA" and ant["id_reunion_aprobacion"] == nxt,
                  "el acta queda aprobada en la siguiente reunión con quórum")
            filas_v = c.get("/api/vistas/reuniones", headers=HP).json()["filas"]
            check(any(f["id_reunion"] == b and f["estado"] == "CANCELADA" for f in filas_v)
                  and any(f["id_reunion"] == a and f["invitados"] == 2 for f in filas_v), "vista de reuniones con canceladas e invitados")
            asis = c.get("/api/vistas/asistencia", headers=HP).json()["filas"]
            check(any(f["reuniones"] == 2 for f in asis), "vista de asistencia por directivo")
            check(c.get(f"/api/reuniones/{a}/acta", headers=HL).status_code == 404, "otra junta no ve las reuniones de Medellín")

    print("Redes sociales: inventario, claves cifradas, quién las ve y alertas")
    import base64 as _b64
    import psycopg as _pg2
    from app.config import config as _cfg
    from app.redes import generar_llave as _gen
    SUPER = os.environ.get("SUPER_DATABASE_URL")
    r = c.post("/api/r/cuentas_redes", headers=H, json={"id_estamento": 2, "red": "FACEBOOK", "usuario_cuenta": "@sindicatomedellin",
               "url": "https://facebook.com/sindicatomedellin", "correo_acceso": "redes.med@sindicato.org"})
    check(r.status_code == 201 and r.json()["fecha_cambio_clave"] is None, "cuenta de Facebook de la Subdirectiva Medellín registrada")
    cta = r.json()["id_cuenta_red"]
    r2 = c.post("/api/r/cuentas_redes", headers=H, json={"id_estamento": 2, "red": "FACEBOOK", "usuario_cuenta": "@SindicatoMedellin"})
    check(r2.status_code == 409, "no se registra dos veces la misma cuenta")
    diag = lambda: next(f for f in c.get("/api/vistas/redes_sociales", headers=H).json()["filas"] if f["id_cuenta_red"] == cta)["diagnostico"]
    check("NO TIENE REGISTRADA LA CLAVE" in diag(), "alerta crítica: el sindicato no tiene la clave")
    check(c.get(f"/api/redes/{cta}/permiso", headers=H).json()["puede_ver_clave"] is False, "el administrador sin cargo no ve claves")
    r = c.post(f"/api/redes/{cta}/clave", headers=H, json={"clave": "x"})
    check(r.status_code == 403, "el administrador sin cargo no registra claves")
    r = c.post(f"/api/redes/{cta}/clave", headers=HP, json={"clave": "Fb#Medellin2026", "confirmacion": "otra"})
    check(r.status_code == 400 and "confirmación" in r.json()["detail"], "la confirmación debe coincidir")
    r = c.post(f"/api/redes/{cta}/clave", headers=HP, json={"clave": "Fb#Medellin2026", "confirmacion": "Fb#Medellin2026", "motivo": "Registro inicial"})
    check(r.status_code == 200, "el Presidente de la junta registra la clave")
    if SUPER:
        with _pg2.connect(SUPER) as sc:
            blob = bytes(sc.execute("SELECT clave_cifrada FROM secretos.clave_red WHERE id_cuenta_red = %s AND vigente", (cta,)).fetchone()[0])
        check(b"Medellin2026" not in blob and len(blob) > 28, "en la base solo queda texto cifrado (AES-256-GCM)")
    with _pg2.connect(os.environ["DATABASE_URL"]) as ac:
        try:
            ac.execute("SELECT * FROM secretos.clave_red"); bloqueado = False
        except _pg2.errors.InsufficientPrivilege:
            bloqueado = True
    check(bloqueado, "el rol de la aplicación no puede leer la tabla de claves directamente")
    r = c.post(f"/api/redes/{cta}/ver", headers=HP, json={})
    check(r.status_code == 200 and r.json()["clave"] == "Fb#Medellin2026" and "no-store" in r.headers["Cache-Control"],
          "un directivo de la junta ve la clave (sin caché)")
    check(c.post(f"/api/redes/{cta}/ver", headers=HC, json={}).json()["clave"] == "Fb#Medellin2026", "cualquier directivo vigente de la junta la ve")
    r = c.post(f"/api/redes/{cta}/ver", headers=HL, json={})
    check(r.status_code in (403, 404), "un directivo de otra junta no ve la clave")
    c.post("/api/r/accesos_redes", headers=HP, json={"id_cuenta_red": cta, "id_persona": 2, "rol": "ADMINISTRADOR"})
    hoy_txt = _dt.now(_Z("America/Bogota")).strftime("%Y-%m-%d")
    check(retirar_en(2, 2, hoy_txt) == 200, "Carlos se retira de la Subdirectiva Medellín")
    check(c.post(f"/api/redes/{cta}/ver", headers=HC, json={}).status_code == 200,
          "como Vicepresidente Nacional con acceso nacional, aún puede ver la clave")
    cg = c.get("/api/r/cargos/registro", headers=H, params={"id_cargo": cargos["VICE_NAL"]}).json()
    c.put("/api/r/cargos/registro", headers=H, params={"id_cargo": cargos["VICE_NAL"]}, json={"acceso_nacional": False, "version": cg["version"]})
    d = diag()
    check("CAMBIAR LA CLAVE" in d and "carlos" in d.lower(), f"alerta: la clave la conoce quien ya no es directivo ({d[:60]}…)")
    check(c.post(f"/api/redes/{cta}/ver", headers=HC, json={}).status_code == 403, "quien se retira deja de ver la clave")
    n0 = len(BUZON)
    if os.environ.get("NOTIFICADOR_DATABASE_URL"):
        c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False}); _t.sleep(0.5)
        check(any(m["Subject"].startswith("Seguridad de las redes sociales de Subdirectiva Medellín") and "presi@med.org" in to
                  for to, m in BUZON[n0:]), "correo semanal de alertas de redes al Presidente de la junta")
    r = c.post(f"/api/redes/{cta}/clave", headers=HS, json={"clave": "Nueva#Clave2026", "motivo": "Retiro de Carlos"})
    check(r.status_code == 200 and "QUITAR EL ROL" in diag(), "cambiada la clave, queda la alerta de quitarle el rol en la red")
    acc = c.get("/api/r/accesos_redes", headers=HP, params={"f_id_cuenta_red": cta}).json()["filas"][0]
    c.put("/api/r/accesos_redes/registro", headers=HP, params={"id_acceso": acc["id_acceso"]}, json={"fecha_retiro": hoy_txt, "version": acc["version"]})
    check("NO HAY REGISTRO DE PUBLICACIONES" in diag(), "alerta: la cuenta no tiene publicaciones registradas")
    _hace = lambda n: (_dt.now(_Z("America/Bogota")).date() - _td(days=n)).isoformat()
    cr = c.get("/api/r/cuentas_redes/registro", headers=HP, params={"id_cuenta_red": cta}).json()
    c.put("/api/r/cuentas_redes/registro", headers=HP, params={"id_cuenta_red": cta},
          json={"fecha_ultima_publicacion": _hace(6), "id_persona_administrador": p_sec, "version": cr["version"]})
    check("SIN PUBLICAR HACE 6 DÍAS (MÁXIMO 5)" in diag(), "más de 5 días sin publicar: alerta alta")
    if os.environ.get("NOTIFICADOR_DATABASE_URL"):
        n0 = len(BUZON)
        c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False}); _t.sleep(0.5)
        pub = [(to, m) for to, m in BUZON[n0:] if "sin publicar contenidos" in m["Subject"]]
        check(len(pub) == 1 and "secre@med.org" in pub[0][0] and "presi@med.org" in pub[0][0]
              and "6 días sin publicar" in pub[0][1].get_body(("plain",)).get_content(),
              "correo al responsable de la cuenta y a la mesa de la junta por inactividad")
        n1 = len(BUZON)
        c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False}); _t.sleep(0.5)
        check(not any("sin publicar contenidos" in m["Subject"] for _, m in BUZON[n1:]), "el aviso no se repite el mismo día")
    cr = c.get("/api/r/cuentas_redes/registro", headers=HP, params={"id_cuenta_red": cta}).json()
    c.put("/api/r/cuentas_redes/registro", headers=HP, params={"id_cuenta_red": cta}, json={"dias_max_sin_publicar": 10, "version": cr["version"]})
    check("PUBLICA" not in diag(), "el máximo de días sin publicar se ajusta por cuenta")
    check("RECUPERACIÓN PERSONAL" in diag(), "siguiente alerta: correo o teléfono de recuperación personal")
    cr = c.get("/api/r/cuentas_redes/registro", headers=HP, params={"id_cuenta_red": cta}).json()
    c.put("/api/r/cuentas_redes/registro", headers=HP, params={"id_cuenta_red": cta},
          json={"recuperacion_institucional": True, "tiene_2fa": True, "metodo_2fa": "App autenticadora", "fecha_ultima_publicacion": hoy_txt, "version": cr["version"]})
    check(diag() == "CUENTA AL DÍA", "con recuperación institucional, 2FA y publicaciones recientes: cuenta al día")
    r = c.put("/api/r/cuentas_redes/registro", headers=HP, params={"id_cuenta_red": cta}, json={"fecha_cambio_clave": "2020-01-01T00:00:00", "version": cr["version"] + 1})
    check(c.get("/api/r/cuentas_redes/registro", headers=HP, params={"id_cuenta_red": cta}).json()["fecha_cambio_clave"] > "2026", "la fecha del cambio de clave no se manipula")
    hist = c.get(f"/api/redes/{cta}/claves", headers=HP).json()
    check(len(hist) == 2 and hist[0]["vigente"] and not hist[1]["vigente"], "historial: clave vigente y la anterior")
    r = c.post(f"/api/redes/{cta}/ver", headers=HP, json={"id_clave": hist[1]["id_clave"]})
    check(r.status_code == 400 and "motivo" in r.json()["detail"], "ver una clave anterior exige motivo")
    r = c.post(f"/api/redes/{cta}/ver", headers=HP, json={"id_clave": hist[1]["id_clave"], "motivo": "Recuperación de la cuenta"})
    check(r.json()["clave"] == "Fb#Medellin2026" and not r.json()["vigente"], "se recupera la clave anterior, con motivo")
    q = c.get(f"/api/redes/{cta}/consultas", headers=HP).json()
    check(sum(1 for x in q if x["accion"] == "VER") == 4 and sum(1 for x in q if x["accion"] == "CAMBIAR") == 2
          and any(x["motivo"] == "Recuperación de la cuenta" for x in q), "cada consulta y cambio queda registrado con usuario y motivo")
    with _pg2.connect(os.environ["DATABASE_URL"]) as ac:
        try:
            ac.execute("DELETE FROM gobernanza.cuenta_red_consulta"); borrado = True
        except _pg2.errors.InsufficientPrivilege:
            borrado = False
    check(not borrado, "el registro de consultas de claves no se puede borrar")
    # Rotación de la llave maestra
    vieja = _cfg.SECRETOS_LLAVE
    _cfg.SECRETOS_LLAVE, _cfg.SECRETOS_LLAVE_VERSION, _cfg.SECRETOS_LLAVE_ANTERIOR = _gen(), 2, vieja
    r = c.post("/api/admin/redes/rotar-llave", headers=H)
    check(r.status_code == 200 and r.json()["recifradas"] == 2 and r.json()["mfa_recifrados"] >= 2,
          "rotación de la llave: todas las claves de redes y los secretos del MFA re-cifrados")
    _cfg.SECRETOS_LLAVE_ANTERIOR = ""
    check(c.post(f"/api/redes/{cta}/ver", headers=HP, json={}).json()["clave"] == "Nueva#Clave2026", "tras la rotación la clave se lee con la llave nueva")
    if SUPER:
        with _pg2.connect(SUPER) as sc:
            sc.execute("UPDATE secretos.clave_red SET clave_cifrada = overlay(clave_cifrada placing '\\x00'::bytea from 20 for 1) WHERE id_cuenta_red = %s AND vigente", (cta,))
        n_antes = len(c.get(f"/api/redes/{cta}/consultas", headers=HP).json())
        r = c.post(f"/api/redes/{cta}/ver", headers=HP, json={})
        check(r.status_code == 409 and "INTEGRIDAD" in r.json()["detail"]
              and len(c.get(f"/api/redes/{cta}/consultas", headers=HP).json()) == n_antes, "una clave alterada en la base se detecta (y no cuenta como consulta)")

    print("Escritos jurídicos con IA: fuentes, redacción, revisión y radicación")
    import io as _io
    import subprocess as _sp
    import tempfile as _tf
    from app import ia as _ia
    HAb, id_ab = crear_usuario("abogado.med", "ABOGADO")
    c.post("/api/r/ambitos_usuario", headers=H, json={"id_usuario": id_ab, "id_estamento": 2})
    ua = c.get("/api/r/usuarios/registro", headers=H, params={"id_usuario": id_ab}).json()
    c.put("/api/r/usuarios/registro", headers=H, params={"id_usuario": id_ab}, json={"correo_electronico": "abogado@med.org", "version": ua["version"]})
    r = c.post("/api/r/escritos", headers=HP, json={"id_estamento": 2, "codigo_tipo": "DERECHO_PETICION",
               "titulo": "Solicitud de información sobre el traslado de una afiliada", "destinatario_persona": "Secretario de Talento Humano",
               "destinatario_institucion": "Alcaldía de Medellín"})
    check(r.status_code == 201 and r.json()["estado"] == "BORRADOR", "escrito creado (derecho de petición)")
    esc = r.json()["id_escrito"]
    det = lambda hh=HP: c.get(f"/api/escritos/{esc}", headers=hh).json()
    r = c.post(f"/api/escritos/{esc}/generar", headers=HP, json={})
    check(r.status_code == 400 and "fuente" in r.json()["detail"], "sin fuentes ni instrucciones no se redacta")
    eo = c.get("/api/r/escritos/registro", headers=HP, params={"id_escrito": esc}).json()
    c.put("/api/r/escritos/registro", headers=HP, params={"id_escrito": esc},
          json={"instrucciones": "Pedir copia del acto de traslado y su motivación.", "version": eo["version"]})
    c.post(f"/api/escritos/{esc}/fuentes/texto", headers=HP, json={"nombre": "Relato de la afiliada",
           "texto": "El 3 de septiembre de 2026 la Alcaldía trasladó a la afiliada a otra dependencia sin motivación.\nNo se le notificó el acto."})
    tmp = _tf.mkdtemp()
    _sp.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=2", f"{tmp}/nota_de_voz.ogg"], check=True)
    _sp.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i", "testsrc=duration=1:size=160x120:rate=10", "-f", "lavfi", "-i",
             "sine=duration=1", "-shortest", f"{tmp}/video_reunion.mp4"], check=True)
    import docx as _dx
    dd = _dx.Document(); dd.add_paragraph("Memorando interno: se ordena el traslado inmediato."); dd.save(f"{tmp}/memorando.docx")
    from reportlab.pdfgen import canvas as _cv
    cv = _cv.Canvas(f"{tmp}/resolucion.pdf"); cv.drawString(72, 720, "Resolucion 123 de 2026: traslado por necesidad del servicio."); cv.save()
    open(f"{tmp}/programa.exe", "wb").write(b"MZ")
    for nombre in ("nota_de_voz.ogg", "video_reunion.mp4", "memorando.docx", "resolucion.pdf"):
        with open(f"{tmp}/{nombre}", "rb") as fh:
            r = c.post(f"/api/escritos/{esc}/fuentes", headers=HP, files={"archivo": (nombre, fh)})
        assert r.status_code == 201, r.text
    with open(f"{tmp}/programa.exe", "rb") as fh:
        check(c.post(f"/api/escritos/{esc}/fuentes", headers=HP, files={"archivo": ("programa.exe", fh)}).status_code == 400,
              "se rechazan formatos que no son texto, PDF, Word, audio o video")
    fu = {f["nombre_archivo"]: f for f in det()["fuentes"]}
    check(all(f["estado"] == "LISTO" for f in fu.values()) and fu["nota_de_voz.ogg"]["clase"] == "AUDIO" and fu["video_reunion.mp4"]["clase"] == "VIDEO"
          and fu["nota_de_voz.ogg"]["duracion_segundos"] == 2, "audio y video transcritos; PDF y Word extraídos")
    check("Resolucion 123" in fu["resolucion.pdf"]["vista_previa"] and "Memorando interno" in fu["memorando.docx"]["vista_previa"],
          "texto del PDF y del Word disponible para la redacción")
    msg = _ia.construir_mensaje({"tipo_nombre": "Derecho de petición", "orientacion": "x", "junta": "J", "tipo_junta": "SUBDIRECTIVA",
                                 "firmantes": "", "titulo": "T", "fuentes": [{"nombre": "a", "clase": "TEXTO", "texto": "HECHO ÚNICO"}]})
    check("HECHO ÚNICO" in msg and "Responde SOLO con el escrito" in _ia.instrucciones_sistema() and "[COMPLETAR" in _ia.instrucciones_sistema(),
          "la IA recibe las fuentes y la regla de no inventar ni poner preliminares")
    # Llamada a la API de Anthropic (respuesta simulada): formato de la petición y separación de las notas
    from app.config import config as _cf
    import httpx as _hx
    capt = {}
    class _Resp:
        status_code = 200
        def json(self):
            return {"model": "claude-opus-5-5", "stop_reason": "end_turn", "content": [{"type": "text", "text":
                    "Medellín, 1 de octubre de 2026\n\nSeñor\nHECHOS\n1. Uno.\n===NOTAS PARA LA REVISIÓN===\n- Verificar la fecha."}]}
    def _post(url, **kw):
        capt.update(url=url, **kw); return _Resp()
    _orig, _prov, _key = _ia.httpx.post, _cf.IA_PROVEEDOR, _cf.ANTHROPIC_API_KEY
    _ia.httpx.post, _cf.IA_PROVEEDOR, _cf.ANTHROPIC_API_KEY = _post, "anthropic", "sk-ant-prueba"
    try:
        cu, no, mo = _ia.redactar({"tipo_nombre": "Derecho de petición", "orientacion": "x", "junta": "J", "tipo_junta": "SUBDIRECTIVA",
                                   "firmantes": "", "titulo": "T", "fuentes": []})
    finally:
        _ia.httpx.post, _cf.IA_PROVEEDOR, _cf.ANTHROPIC_API_KEY = _orig, _prov, _key
    check(capt["url"] == "https://api.anthropic.com/v1/messages" and capt["headers"]["x-api-key"] == "sk-ant-prueba"
          and capt["headers"]["anthropic-version"] == "2023-06-01" and capt["json"]["model"] == _cf.IA_MODELO
          and cu.startswith("Medellín") and "NOTAS" not in cu and no == "- Verificar la fecha." and mo == "claude-opus-5-5",
          "petición a la API de Claude bien formada; el escrito y las notas de revisión se separan")
    n0 = len(BUZON)
    r = c.post(f"/api/escritos/{esc}/generar", headers=HP, json={})
    d = det()
    e = d["escrito"]
    check(r.status_code == 202 and e["version_actual"] == 1 and e["estado"] == "EN_REVISION" and not e["generando"]
          and e["contenido"].split("\n")[0].upper().startswith("MEDELLÍN") and "HECHOS" in e["contenido"] and e["notas_revision"],
          "la IA redacta la versión 1 directamente (sin preliminares) y deja notas para la revisión aparte")
    if os.environ.get("NOTIFICADOR_DATABASE_URL"):
        c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False}); _t.sleep(0.5)
        check(any(m["Subject"].startswith("Por revisar:") and "abogado@med.org" in to for to, m in BUZON[n0:]),
              "correo al abogado (y a la mesa de la junta) para revisar la versión")
    r = c.post(f"/api/escritos/{esc}/revisar", headers=HT, json={"numero_version": 1, "decision": "APRUEBA"})
    check(r.status_code == 400 and "dejar comentarios" in r.json()["detail"], "un directivo que no es Presidente ni Secretario no aprueba")
    r = c.post(f"/api/escritos/{esc}/revisar", headers=HT, json={"numero_version": 1, "decision": "COMENTA", "comentario": "Citar el fuero sindical"})
    check(r.status_code == 200, "pero sí comenta")
    check(c.post(f"/api/escritos/{esc}/revisar", headers=HAb, json={"numero_version": 1, "decision": "APRUEBA"}).json()["estado"] == "EN_REVISION",
          "el abogado aprueba la versión 1")
    check(c.post(f"/api/escritos/{esc}/revisar", headers=HAb, json={"numero_version": 1, "decision": "APRUEBA"}).status_code == 400,
          "no se aprueba dos veces con el mismo rol")
    r = c.post(f"/api/escritos/{esc}/revisar", headers=HP, json={"numero_version": 1, "decision": "CAMBIOS"})
    check(r.status_code == 400, "pedir cambios exige un comentario")
    r = c.post(f"/api/escritos/{esc}/revisar", headers=HP, json={"numero_version": 1, "decision": "CAMBIOS", "comentario": "Pedir también la hoja de vida del cargo"})
    check(r.json()["estado"] == "CAMBIOS_SOLICITADOS", "la Presidencia solicita cambios")
    c.post(f"/api/escritos/{esc}/generar", headers=HP, json={"instrucciones": "Incluir la petición de la hoja de vida del cargo"})
    d = det()
    check(d["escrito"]["version_actual"] == 2 and "Ajuste solicitado" in d["escrito"]["contenido"] and all(v is None for v in d["aprobaciones"].values()),
          "versión 2 de la IA con los comentarios; las aprobaciones anteriores ya no valen")
    r = c.post(f"/api/escritos/{esc}/revisar", headers=HAb, json={"numero_version": 1, "decision": "APRUEBA"})
    check(r.status_code == 409 and "versión 2" in r.json()["detail"], "no se aprueba una versión vieja")
    texto3 = d["escrito"]["contenido"].replace("[COMPLETAR: fecha]", "1 de octubre de 2026")
    r = c.put(f"/api/escritos/{esc}/contenido", headers=HAb, json={"contenido": texto3, "version_base": 1})
    check(r.status_code == 409, "edición sobre una versión desactualizada -> 409 (concurrencia)")
    r = c.put(f"/api/escritos/{esc}/contenido", headers=HAb, json={"contenido": texto3, "version_base": 2, "motivo": "Fecha"})
    check(r.status_code == 200 and r.json()["version"] == 3, "el abogado corrige el texto: versión 3 (edición humana)")
    check(c.post(f"/api/escritos/{esc}/radicar", headers=HP).status_code == 400, "no se radica sin las tres aprobaciones")
    for hh in (HAb, HP, HS):
        r = c.post(f"/api/escritos/{esc}/revisar", headers=hh, json={"numero_version": 3, "decision": "APRUEBA"})
    check(r.json()["estado"] == "APROBADO", "aprobado por el abogado, la Presidencia y la Secretaría General sobre la versión 3")
    check(c.post(f"/api/escritos/{esc}/radicar", headers=HAb).status_code == 400, "el abogado no radica: radica la mesa de la junta")
    r = c.post(f"/api/escritos/{esc}/radicar", headers=HP)
    rad = r.json()
    check(r.status_code == 200 and "-PET-" in rad["radicado"], f"escrito radicado como derecho de petición ({rad.get('radicado')})")
    pdf = c.get(f"/api/escritos/{esc}/pdf", headers=HP)
    check(pdf.content.startswith(b"%PDF") and _hl.sha256(pdf.content).hexdigest() == rad["hash_sha256"]
          and c.get(f"/api/documentos/{rad['id_documento']}/verificar", headers=H).json()["integro"], "PDF radicado con huella SHA-256")
    wd = c.get(f"/api/escritos/{esc}/docx", headers=HP)
    check(wd.status_code == 200 and "wordprocessingml" in wd.headers["content-type"]
          and "1 de octubre de 2026" in "\n".join(p.text for p in _dx.Document(_io.BytesIO(wd.content)).paragraphs), "descarga en Word")
    check(c.put(f"/api/escritos/{esc}/contenido", headers=HP, json={"contenido": "x", "version_base": 3}).status_code == 400
          and c.post(f"/api/escritos/{esc}/generar", headers=HP, json={}).status_code == 400, "un escrito radicado ya no se modifica")
    check(len(det()["versiones"]) == 3 and len(det()["revisiones"]) == 6, "historial completo de versiones, comentarios y aprobaciones")
    check(c.get(f"/api/escritos/{esc}", headers=HTC).status_code == 404, "otra junta no ve los escritos de Medellín")
    r2 = c.post("/api/r/escritos", headers=HP, json={"id_estamento": 2, "codigo_tipo": "DENUNCIA_PUBLICA", "titulo": "Denuncia por traslados masivos"}).json()
    c.post(f"/api/escritos/{r2['id_escrito']}/fuentes/texto", headers=HP, json={"texto": "Se trasladaron 12 trabajadores sindicalizados."})
    c.post(f"/api/escritos/{r2['id_escrito']}/generar", headers=HP, json={})
    check(c.post(f"/api/escritos/{r2['id_escrito']}/descartar", headers=HP, json={"motivo": "Se resolvió con la entidad"}).status_code == 200,
          "un proyecto se descarta con motivo (queda en el historial)")
    ve = {f["id_escrito"]: f for f in c.get("/api/vistas/escritos", headers=HP).json()["filas"]}
    check(ve[esc]["diagnostico"] == "RADICADO" and ve[r2["id_escrito"]]["diagnostico"].startswith("DESCARTADO"), "vista de control de escritos")

    print("Estrategia de contenidos en redes: política, calendario, piezas con IA, revisión y resultados")
    p_com = nuevo_afiliado("440030", "COMUNICA", 2)
    check(directivo(p_com, 2, "SCOM_REG").status_code == 201, "Secretario de Comunicaciones de Medellín nombrado")
    HCom, _ = crear_usuario("comunica.med", "DIRECTIVO", p_com)
    pol = c.post("/api/r/politicas_comunicacion", headers=HCom, json={"id_estamento": 2, "objetivos": "Educar en derechos laborales",
                 "tono": "Cercano, de tú", "publicaciones_por_semana": 3}).json()
    r = c.post(f"/api/contenidos/politicas/{pol['id_politica']}/generar", headers=HCom, json={})
    pol2 = c.get("/api/r/politicas_comunicacion/registro", headers=HCom, params={"id_politica": pol["id_politica"]}).json()
    check(r.status_code == 202 and pol2["texto"].startswith("POLÍTICA DE COMUNICACIONES") and not pol2["vigente"],
          "la IA redacta la política de comunicaciones de la junta (aún no vigente)")
    acta_pol = c.post("/api/r/documentos", headers=HP, json={"id_tipo_documento": 1, "id_estamento": 2, "asunto": "Acta: aprobación de la política de comunicaciones"}).json()
    r = c.post(f"/api/contenidos/politicas/{pol['id_politica']}/aprobar", headers=HCom, json={"id_acta": acta_pol["id_documento"]})
    check(r.status_code == 400 and "Presidente o el Secretario General" in r.json()["detail"], "la aprobación de la política la registra la mesa de la junta")
    r = c.post(f"/api/contenidos/politicas/{pol['id_politica']}/aprobar", headers=HP, json={"id_acta": doc_cali["id_documento"]})
    check(r.status_code in (400, 404) , "la política se aprueba con un acta de la misma junta")
    r = c.post(f"/api/contenidos/politicas/{pol['id_politica']}/aprobar", headers=HP, json={"id_acta": acta_pol["id_documento"]})
    pol3 = c.get("/api/r/politicas_comunicacion/registro", headers=HCom, params={"id_politica": pol["id_politica"]}).json()
    check(r.status_code == 200 and pol3["vigente"], "política aprobada con acta: vigente")
    r = c.put("/api/r/politicas_comunicacion/registro", headers=HCom, params={"id_politica": pol["id_politica"]}, json={"tono": "otro", "version": pol3["version"]})
    check(r.status_code == 400, "una política aprobada no se modifica (se reemplaza por una nueva)")
    manana = (_dt.now(_Z("America/Bogota")).date() + _td(days=1)).isoformat()
    hoy_c = _dt.now(_Z("America/Bogota")).date().isoformat()
    pz = c.post("/api/r/piezas", headers=HCom, json={"id_estamento": 2, "titulo": "¿Qué es el acoso laboral y cómo denunciarlo?",
                "codigo_eje": "ACOSO", "formato": "CARRUSEL", "publico": "Trabajadores del sector público", "redes_destino": "Instagram y Facebook",
                "fecha_programada": manana, "material_base": "Ley 1010 de 2006: define el acoso laboral y sus modalidades."}).json()
    check(pz["estado"] == "IDEA", "pieza programada en el calendario editorial")
    msg_c = _ia.mensaje_contenido({"formato": "CARRUSEL", "titulo": "T", "junta": "J", "politica": "Tono: cercano", "material": "Ley 1010"})
    check("POLÍTICA DE COMUNICACIONES" in msg_c and "Ley 1010" in msg_c and "Diapositiva" in msg_c and "[VERIFICAR]" in _ia.sistema_contenidos(),
          "la IA recibe el formato, el material de base y la política vigente, con la regla de verificar normas")
    cal = lambda: {f["id_pieza"]: f for f in c.get("/api/vistas/calendario_editorial", headers=HCom).json()["filas"] if f["clase"] == "PIEZA"}
    c.post(f"/api/contenidos/piezas/{pz['id_pieza']}/generar", headers=HCom, json={})
    dp = c.get(f"/api/contenidos/piezas/{pz['id_pieza']}", headers=HCom).json()
    check(dp["pieza"]["version_actual"] == 1 and "Pieza simulada en formato CARRUSEL" in dp["pieza"]["contenido"] and dp["pieza"]["notas_ia"]
          and dp["tiene_politica"], "la IA crea la pieza (versión 1) con notas para el revisor")
    check("NO ESTÁ APROBADA" in cal()[pz["id_pieza"]]["diagnostico"], "calendario: alerta si se publica pronto y no está aprobada")
    r = c.post("/api/r/pieza_publicaciones", headers=HCom, json={"id_pieza": pz["id_pieza"], "id_cuenta_red": cta, "fecha_publicacion": hoy_c})
    check(r.status_code == 400 and "aprobada" in r.json()["detail"], "no se publica una pieza sin aprobar")
    r = c.post(f"/api/contenidos/piezas/{pz['id_pieza']}/revisar", headers=HT, json={"numero_version": 1, "decision": "APRUEBA"})
    check(r.status_code == 400 and "puede comentar" in r.json()["detail"], "un directivo sin ese cargo no aprueba piezas")
    check(c.post(f"/api/contenidos/piezas/{pz['id_pieza']}/revisar", headers=HCom, json={"numero_version": 1, "decision": "APRUEBA"}).json()["estado"] == "EN_REVISION",
          "aprobación de comunicaciones (Secretario de Comunicaciones)")
    r = c.post(f"/api/contenidos/piezas/{pz['id_pieza']}/revisar", headers=HAb, json={"numero_version": 1, "decision": "CAMBIOS",
               "comentario": "Aclarar que la queja se presenta ante el Comité de Convivencia"})
    check(r.json()["estado"] == "CAMBIOS_SOLICITADOS", "el abogado pide precisión jurídica")
    c.post(f"/api/contenidos/piezas/{pz['id_pieza']}/generar", headers=HCom, json={"instrucciones": "Incluir el Comité de Convivencia"})
    dp = c.get(f"/api/contenidos/piezas/{pz['id_pieza']}", headers=HCom).json()
    check(dp["pieza"]["version_actual"] == 2 and "Comité de Convivencia" in dp["pieza"]["contenido"] and dp["aprobaciones"]["COMUNICACIONES"] is None,
          "versión 2 con la corrección; la aprobación anterior ya no vale")
    for hh in (HCom, HAb):
        r = c.post(f"/api/contenidos/piezas/{pz['id_pieza']}/revisar", headers=hh, json={"numero_version": 2, "decision": "APRUEBA"})
    check(r.json()["estado"] == "APROBADA", "aprobada con revisión jurídica y de comunicaciones")
    cr0 = c.get("/api/r/cuentas_redes/registro", headers=HP, params={"id_cuenta_red": cta}).json()
    c.put("/api/r/cuentas_redes/registro", headers=HP, params={"id_cuenta_red": cta}, json={"fecha_ultima_publicacion": _hace(9), "version": cr0["version"]})
    r = c.post("/api/r/pieza_publicaciones", headers=HCom, json={"id_pieza": pz["id_pieza"], "id_cuenta_red": cta, "fecha_publicacion": hoy_c,
               "url": "https://facebook.com/sindicatomedellin/posts/1"})
    cr1 = c.get("/api/r/cuentas_redes/registro", headers=HP, params={"id_cuenta_red": cta}).json()
    check(r.status_code == 201 and cr1["fecha_ultima_publicacion"] == hoy_c
          and c.get(f"/api/contenidos/piezas/{pz['id_pieza']}", headers=HCom).json()["pieza"]["estado"] == "PUBLICADA",
          "al registrar la publicación la pieza queda publicada y la cuenta sale de la alerta de días sin publicar")
    pub = r.json()
    c.put("/api/r/pieza_publicaciones/registro", headers=HCom, params={"id_publicacion": pub["id_publicacion"]},
          json={"alcance": 1000, "interacciones": 85, "compartidos": 12, "version": pub["version"]})
    rend = c.get("/api/vistas/rendimiento_contenidos", headers=HCom).json()["filas"]
    check(any(float(f["tasa_interaccion"] or 0) == 8.5 and f["eje"] == "Acoso laboral" for f in rend), "rendimiento por eje, formato y red (8,5 % de interacción)")
    check(c.put(f"/api/contenidos/piezas/{pz['id_pieza']}/contenido", headers=HCom, json={"contenido": "x", "version_base": 2}).status_code == 400,
          "una pieza publicada ya no se modifica")
    pz2 = c.post("/api/r/piezas", headers=HCom, json={"id_estamento": 2, "titulo": "Tus derechos como provisional", "codigo_eje": "CARRERA",
                 "formato": "VIDEO_CORTO", "fecha_programada": hoy_c}).json()
    c.post(f"/api/contenidos/piezas/{pz2['id_pieza']}/generar", headers=HCom, json={})
    if os.environ.get("NOTIFICADOR_DATABASE_URL"):
        n0 = len(BUZON)
        c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False}); _t.sleep(0.5)
        cal_m = [(to, m) for to, m in BUZON[n0:] if m["Subject"].startswith("Calendario de redes de Subdirectiva Medellín")]
        check(cal_m and "comunica@med.org" in cal_m[0][0] and "abogado@med.org" in sum((to for to, _ in cal_m), []),
              "correo diario del calendario a comunicaciones y al abogado (piezas por revisar o por publicar)")
    check(c.post(f"/api/contenidos/piezas/{pz2['id_pieza']}/descartar", headers=HCom, json={"motivo": "Se cambia el enfoque"}).status_code == 200,
          "una pieza se descarta con motivo")
    ctl = next(f for f in c.get("/api/vistas/contenidos", headers=HCom).json()["filas"] if f["id_estamento"] == 2)
    check(ctl["tiene_politica"] and ctl["publicadas_7_dias"] == 1, "control de contenidos por junta (política vigente, publicaciones de la semana)")
    check(c.get(f"/api/contenidos/piezas/{pz['id_pieza']}", headers=HTC).status_code == 404, "otra junta no ve las piezas de Medellín")

    print("Endurecimiento: ataques con la contraseña de la cuenta de la aplicación")
    import base64 as _b64, json as _js, psycopg as _pge, time as _te
    from app import auth as _auth_e
    _auth_e._intentos_ip.clear()
    _sid = lambda hh: _js.loads(_b64.urlsafe_b64decode(hh["Authorization"].split()[1].split(".")[1] + "==="))["sid"]
    id_admin = c.get("/api/auth/yo", headers=H).json()["id_usuario"]
    with _pge.connect(os.environ["DATABASE_URL"], autocommit=True) as at:
        def _intento(sql, args=()):
            try:
                at.execute(sql, args); return "SIN ERROR"
            except _pge.Error as e:
                return str(e)
        at.execute("SELECT set_config('app.id_usuario', %s, false)", (str(id_admin),))
        check(at.execute("SELECT seguridad.fn_es_admin(), seguridad.fn_ambito_nacional(), (SELECT count(*) FROM gobernanza.afiliado)").fetchone()
              == (False, False, 0), "fingir ser el administrador con app.id_usuario ya no sirve: sin sesión no ve nada")
        check("permission denied" in _intento("SELECT hash_contrasena FROM seguridad.usuario LIMIT 1"),
              "la aplicación ya no puede leer el hash de las contraseñas")
        check("permission denied" in _intento("INSERT INTO seguridad.sesion (id_sesion, id_usuario, fecha_expiracion) VALUES (gen_random_uuid(), %s, now() + INTERVAL '1 hour')", (id_admin,)),
              "ni crear sesiones a mano")
        check("SEGURIDAD" in _intento("UPDATE seguridad.usuario SET codigo_rol = 'ADMIN' WHERE nombre_usuario = 'consulta1'"),
              "ni subirle el rol a un usuario")
        check("SEGURIDAD" in _intento("UPDATE seguridad.usuario SET mfa_activo = FALSE, correo_electronico = 'x@x.co' WHERE id_usuario = %s", (id_admin,)),
              "ni apagar el MFA o cambiar el correo del administrador")
        check("SEGURIDAD" in _intento("UPDATE seguridad.permiso_rol SET puede_eliminar = TRUE WHERE codigo_rol = 'CONSULTA'")
              and "SEGURIDAD" in _intento("INSERT INTO seguridad.usuario_ambito (id_usuario, id_estamento) VALUES (%s, 1)", (id_admin,)),
              "ni tocar la matriz de permisos o los ámbitos")
        check("permission denied" in _intento("SELECT seguridad.fn_reglas_inactivar('seguridad.usuario', jsonb_build_object('id_usuario', %s), 'x')", (id_admin,))
              and "permission denied" in _intento("SELECT gestion_documental.fn_recalcular_tipos(2, current_date)"),
              "ni ejecutar directamente las funciones internas (cascadas de inactivación, tipos de reunión)")
        r_s = _intento("SELECT seguridad.fn_revocar_sesiones_usuario(%s, FALSE)", (id_admin,))
        check("SEGURIDAD" in r_s and c.get("/api/auth/yo", headers=H).status_code == 200, "ni cerrar las sesiones de otros")
        # Un usuario de la junta (Tesorero) con su propia sesión y la contraseña de la base: las reglas siguen en pie
        at.execute("SELECT set_config('app.sesion', %s, false), set_config('app.id_usuario', '', false)", (_sid(HT),))
        check(at.execute("SELECT seguridad.fn_rol_actual()").fetchone()[0] == "TESORERO", "con su sesión, la base sabe que es el Tesorero")
        at.execute("SELECT set_config('pqrsd.operacion', 'responder', false), set_config('finanzas.operacion', 'anular', false)")
        r_p = _intento("UPDATE gestion_documental.pqrsd SET estado = 'RESPONDIDA', respuesta = 'falsa' WHERE id_pqrsd = %s", (q_v,))
        check("Ventanilla" in r_p or "no se cambian" in r_p, "fijar la variable de operación ya no le permite responder una PQRSD")
        e_any = at.execute("SELECT id_egreso FROM finanzas.egreso WHERE estado = 'APROBADO' LIMIT 1").fetchone()
        r_e = _intento("UPDATE finanzas.egreso SET valor = valor * 10 WHERE id_egreso = %s", (e_any[0],)) if e_any else "sin egresos"
        check(e_any and "no se modifica" in r_e, "ni cambiar el valor de un egreso aprobado haciéndose pasar por la anulación")
        check("SEGURIDAD" in _intento("UPDATE seguridad.usuario SET codigo_rol = 'ADMIN' WHERE nombre_usuario = 'teso.med'"),
              "ni subirse el rol a sí mismo")
        at.execute("SELECT set_config('app.sesion', '', false)")
        # Vigilancia: la conexión ajena queda detectada al siguiente ingreso y llega la alerta
        login(c, "consulta1", "NuevaClave#2026")
    al_s = c.get("/api/vistas/alertas_seguridad", headers=H).json()["filas"]
    check(any(a["tipo"] == "CONEXIÓN AJENA" and a["cuenta"] == "sgs_app" for a in al_s),
          "la conexión con la contraseña de la aplicación hecha fuera de ella queda registrada")
    n0 = len(BUZON)
    c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False}); _te.sleep(0.5)
    check(any(m["Subject"].startswith("Alerta de seguridad de la base de datos") for _, m in BUZON[n0:]),
          "y le llega la alerta por correo al administrador y a la Presidencia Nacional")
    r = c.get("/api/salud").json()
    check(r["modo_local"] is False, "en el servidor no aparece la advertencia de modo local")

    print("Varios roles, contexto activo, incompatibilidades y suplencias")
    import datetime as _dtr, time as _tr
    from app import auth as _auth_r
    _auth_r._intentos_ip.clear()
    _hoy_r = _dtr.datetime.now(ZoneInfo("America/Bogota")).date()
    uid = lambda n: c.get("/api/r/usuarios", headers=H, params={"q": n}).json()["filas"][0]["id_usuario"]
    id_teso, id_presi, id_cons = uid("teso.med"), uid("presi.med"), uid("consulta1")
    asig = lambda i, **kw: c.post(f"/api/roles/usuarios/{i}", headers=H, json={"motivo": "Decisión de la junta directiva", **kw})
    # Un segundo rol: la Tesorera de Medellín también es abogada para el Comité Cali
    r = asig(id_teso, codigo_rol="ABOGADO", juntas=[3])
    check(r.status_code == 200 and r.json()["estado"] == "VIGENTE", "el administrador le asigna un segundo rol (abogado para el Comité Cali)")
    lt = login(c, "teso.med", "Definitiva#2026x")
    HT2 = auth(lt["token"])
    yo_t = c.get("/api/auth/yo", headers=HT2).json()
    check(lt["elegir_contexto"] and yo_t["elegir_contexto"] and len(yo_t["contextos"]) == 2,
          "con dos roles, al ingresar debe elegir con cuál trabajar")
    check(c.get("/api/r/documentos", headers=HT2).status_code == 403, "y no puede trabajar hasta elegir")
    ctx = {x["codigo_rol"]: x["id_usuario_rol"] for x in yo_t["contextos"]}
    r = c.post("/api/auth/contexto", headers=HT2, json={"id_usuario_rol": ctx["ABOGADO"]})
    check(r.status_code == 200 and "Abogado" in r.json()["contexto"], "elige trabajar como abogada")
    yo_t = c.get("/api/auth/yo", headers=HT2).json()
    check(yo_t["codigo_rol"] == "ABOGADO" and yo_t["ambito"]["estamentos"] == ["Comité Seccional Cali"] and yo_t["contexto_activo"]["codigo_rol"] == "ABOGADO",
          "el encabezado muestra el rol y el ámbito activos: abogada · Comité Cali")
    check(c.get("/api/r/aportes", headers=HT2).status_code == 403 and ids_estamento(HT2) <= {3},
          "como abogada no entra a finanzas ni ve Medellín: los permisos no se suman")
    check(c.get(f"/api/pqrsd/{q_v}", headers=HT2).status_code == 404, "y su cargo de Tesorera en Medellín no cuenta en ese contexto")
    c.post("/api/auth/contexto", headers=HT2, json={"id_usuario_rol": ctx["TESORERO"]})
    check(c.get("/api/r/aportes", headers=HT2).status_code == 200, "al volver a Tesorería recupera finanzas")
    # Incompatibilidades
    r = asig(id_teso, codigo_rol="AUDITOR", juntas=[2])
    check(r.status_code == 400 and "incompatibilidad 1" in r.json()["detail"], "Tesorería y Auditoría en la misma junta: bloqueado")
    check(asig(id_teso, codigo_rol="AUDITOR", juntas=[3]).status_code == 200, "en otra junta sí se puede")
    r = asig(id_teso, codigo_rol="AUDITOR", juntas=[2], desde=str(_hoy_r + _dtr.timedelta(days=5)))
    check(r.status_code == 400 and "incompatibilidad 1" in r.json()["detail"], "tampoco con una fecha de inicio futura")
    r = asig(id_presi, codigo_rol="VENTANILLA", juntas=[2])
    check(r.status_code == 400 and "incompatibilidad 3" in r.json()["detail"], "Ventanilla y Presidente de la misma junta: bloqueado")
    # Ligar un usuario de Ventanilla a una persona que preside la junta también es incompatible
    id_ven = uid("ventanilla.med")
    v_ven = c.get("/api/r/usuarios/registro", headers=H, params={"id_usuario": id_ven}).json()
    r = c.put("/api/r/usuarios/registro", headers=H, params={"id_usuario": id_ven}, json={"id_persona": p_pres, "version": v_ven["version"]})
    check(r.status_code == 400 and "incompatibilidad 3" in r.json()["detail"], "ni ligando el usuario de Ventanilla a la persona del Presidente")
    r = asig(id_ad, codigo_rol="CONSULTA", juntas=[2])
    check(r.status_code == 400 and "incompatibilidad 2" in r.json()["detail"], "el Administrador no puede tener otro rol")
    r = asig(uid("admin"), codigo_rol="CONSULTA", juntas=[2])
    check(r.status_code == 403 and "a sí mismo" in r.json()["detail"], "nadie se asigna roles a sí mismo")
    # Aprobación de roles nacionales
    r = asig(id_cons, codigo_rol="CONSULTA", ambito_nacional=True)
    check(r.status_code == 200 and r.json()["estado"] == "PENDIENTE", "un rol con ámbito nacional queda pendiente")
    id_pend = r.json()["id_usuario_rol"]
    check(c.post(f"/api/roles/{id_pend}/aprobar", headers=H, json={}).status_code == 403, "el administrador no lo aprueba")
    pend = c.get("/api/roles/pendientes", headers=_pres_nal["h"]).json()
    check(any(p["id_usuario_rol"] == id_pend for p in pend) and c.get("/api/auth/yo", headers=_pres_nal["h"]).json()["aprueba_roles"],
          "la Presidencia Nacional ve las solicitudes pendientes")
    r = c.post(f"/api/roles/{id_pend}/rechazar", headers=_pres_nal["h"], json={})
    check(r.status_code == 400, "rechazar exige motivo")
    check(c.post(f"/api/roles/{id_pend}/aprobar", headers=_pres_nal["h"], json={}).json()["estado"] == "VIGENTE", "y lo aprueba")
    # La propia Presidencia Nacional: sus solicitudes las aprueba la Secretaría General Nacional (y solo esas)
    p_sgn = nuevo_afiliado("440099", "SGNAL", 2)
    check(directivo(p_sgn, 1, "SGEN_NAL").status_code == 201, "Secretaria General Nacional nombrada")
    HSG, _ = crear_usuario("secretaria.nal", "DIRECTIVO", p_sgn)
    id_pn = uid("presidencia.nal")
    r = asig(id_pn, codigo_rol="DIRECTIVO", ambito_nacional=True)
    id_pnr = r.json()["id_usuario_rol"]
    check(c.post(f"/api/roles/{id_pnr}/aprobar", headers=_pres_nal["h"], json={}).status_code == 403, "la Presidencia Nacional no aprueba su propio rol nacional")
    r_otro = asig(id_cons, codigo_rol="AUDITOR", ambito_nacional=True)
    check(c.post(f"/api/roles/{r_otro.json()['id_usuario_rol']}/aprobar", headers=HSG, json={}).status_code == 403,
          "la Secretaría General Nacional no aprueba roles de otras personas")
    check(c.post(f"/api/roles/{id_pnr}/aprobar", headers=HSG, json={}).json().get("estado") == "VIGENTE",
          "pero sí el rol nacional de la propia Presidencia")
    r = c.put("/api/r/usuarios/registro", headers=H, params={"id_usuario": id_cons},
              json={"codigo_rol": "ADMIN", "version": c.get("/api/r/usuarios/registro", headers=H, params={"id_usuario": id_cons}).json()["version"]})
    check(r.status_code == 403 and "Presidencia Nacional" in r.json()["detail"], "tampoco se puede dar el rol de Administrador desde la ficha del usuario")
    # Suplencias
    acta_s = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": 2, "asunto": "Acta: licencia del presidente"}).json()
    acta_c = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": 3, "asunto": "Acta de Cali"}).json()
    id_pres_reg = next(x["id_cargo"] for x in c.get("/api/suplencias/cargos/2", headers=H).json() if x["id_persona"] == p_pres)
    sup = lambda hh, **kw: c.post("/api/suplencias", headers=hh, json={"id_estamento": 2, "id_cargo": id_pres_reg, "id_persona_titular": p_pres,
                                  "id_persona_suplente": p_tes, "desde": str(_hoy_r), "hasta": str(_hoy_r + _dtr.timedelta(days=29)),
                                  "id_acta": acta_s["id_documento"], "motivo": "Licencia no remunerada del presidente", **kw})
    HPN2 = _pres_nal["h"]
    check(sup(HPN2, hasta=str(_hoy_r + _dtr.timedelta(days=95))).status_code == 400, "una suplencia dura máximo 90 días")
    r = sup(HPN2, id_acta=acta_c["id_documento"])
    check(r.status_code == 400 and "acta" in r.json()["detail"], "y se decide con un acta de la misma junta")
    check(sup(HP).status_code == 403, "el titular no registra su propia suplencia")
    r = sup(HPN2)
    check(r.status_code == 200 and r.json()["usuarios_con_acceso"] == 1, "la Presidencia Nacional registra la suplencia con el acta")
    id_sup = r.json()["id_suplencia"]
    q_s = c.post("/api/pqrsd", headers=HV, json={"tipo": "PETICION", "id_estamento": 2, "nombre_peticionario": "Pedro Gil", "tipo_documento": "CC",
                 "numero_documento": "7788", "correo_peticionario": "pedro@correo.test", "asunto": "Constancia",
                 "descripcion": "Solicito una constancia de afiliación."}).json()["id_pqrsd"]
    r = c.get(f"/api/pqrsd/{q_s}", headers=HP)
    check(r.status_code == 404 or not r.json()["acciones"]["responder"], "durante la suplencia el titular queda suspendido: no actúa en el cargo")
    lt = login(c, "teso.med", "Definitiva#2026x")
    HT3 = auth(lt["token"])
    cs = c.get("/api/auth/yo", headers=HT3).json()["contextos"]
    sup_ctx = next(x for x in cs if x["origen"] == "SUPLENCIA")
    check(sup_ctx["codigo_rol"] == "DIRECTIVO" and sup_ctx["hasta"] == str(_hoy_r + _dtr.timedelta(days=29)),
          "el suplente recibe un contexto temporal de directivo hasta el fin de la suplencia")
    c.post("/api/auth/contexto", headers=HT3, json={"id_usuario_rol": sup_ctx["id_usuario_rol"]})
    r = c.post(f"/api/pqrsd/{q_s}/responder", headers=HT3, json={"respuesta": "Adjuntamos la constancia de afiliación solicitada por usted."})
    check(r.status_code == 200 and "(suplente)" in c.get(f"/api/pqrsd/{q_s}", headers=HT3).json()["pqrsd"]["cargo_firma"],
          "el suplente firma como Presidente (suplente)")
    vs = next(x for x in c.get("/api/suplencias", headers=H).json() if x["id_suplencia"] == id_sup)
    check(vs["diagnostico"] == "VIGENTE" and vs["dias_encadenados"] == 30, "vista de suplencias")
    if os.environ.get("SUPER_DATABASE_URL"):
        import psycopg as _pgr
        with _pgr.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            sc.execute("SELECT set_config('roles.operacion', 'suplencia', false)")
            sc.execute("UPDATE gobernanza.suplencia SET desde = %s, hasta = %s WHERE id_suplencia = %s",
                       (_hoy_r - _dtr.timedelta(days=60), _hoy_r + _dtr.timedelta(days=5), id_sup))
        vs = next(x for x in c.get("/api/suplencias", headers=H).json() if x["id_suplencia"] == id_sup)
        check(vs["diagnostico"].startswith("ALERTA ALTA") and vs["dias_encadenados"] > 60, "alerta cuando la ausencia pasa de 60 días")
        n0 = len(BUZON)
        c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False}); _tr.sleep(0.5)
        check(any(m["Subject"].startswith("Ausencia prolongada") for _, m in BUZON[n0:]), "y llega el aviso a la mesa de la junta")
        with _pgr.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            sc.execute("SELECT set_config('roles.operacion', 'suplencia', false)")
            sc.execute("UPDATE gobernanza.suplencia SET desde = %s, hasta = %s WHERE id_suplencia = %s",
                       (_hoy_r - _dtr.timedelta(days=20), _hoy_r - _dtr.timedelta(days=1), id_sup))
        r = c.get("/api/r/documentos", headers=HT3)
        check(r.status_code == 403 and "Elija" in r.json()["detail"], "al vencer la suplencia el suplente sale de ese contexto (vuelve a elegir)")
        check(c.get(f"/api/pqrsd/{q_s}", headers=HP).status_code == 200 and
              c.post("/api/pqrsd", headers=HP, json={"tipo": "QUEJA", "id_estamento": 2, "nombre_peticionario": "Ana Paz", "tipo_documento": "CC",
                     "numero_documento": "8899", "correo_peticionario": "ana@correo.test", "asunto": "Queja",
                     "descripcion": "Queja por la atención recibida."}).status_code == 200,
              "y el titular recupera el cargo sin hacer nada")
    r = sup(HPN2, desde=str(_hoy_r), hasta=str(_hoy_r + _dtr.timedelta(days=10)), motivo="Incapacidad médica del presidente")
    id_sup2 = r.json()["id_suplencia"]
    r = c.post(f"/api/suplencias/{id_sup2}/revocar", headers=HPN2, json={"motivo": "El presidente regresó antes"})
    check(r.status_code == 200 and c.get(f"/api/pqrsd/{q_s}", headers=HP).status_code == 200, "una suplencia se puede revocar con motivo")
    check(c.get("/api/vistas/incompatibilidades", headers=H).status_code == 200, "vista de incompatibilidades para el administrador")

    if os.environ.get("SUPER_DATABASE_URL"):
        import psycopg as _pgm
        with _pgm.connect(os.environ["SUPER_DATABASE_URL"]) as sm:
            ua = sm.execute("SELECT id_usuario FROM seguridad.usuario WHERE codigo_rol = 'AFILIADO' LIMIT 1").fetchone()
            if ua:
                antes = sm.execute("SELECT requiere FROM seguridad.fn_mfa_estado_ingreso(%s, NULL)", ua).fetchone()[0]
                sm.execute("INSERT INTO seguridad.usuario_rol (id_usuario, codigo_rol, origen, estado) VALUES (%s, 'DIRECTIVO', 'ASIGNADO', 'VIGENTE')", ua)
                despues = sm.execute("SELECT requiere FROM seguridad.fn_mfa_estado_ingreso(%s, NULL)", ua).fetchone()[0]
                sm.rollback()
                check(antes is False and despues is True,
                      "el segundo factor se exige si cualquiera de los roles de la persona lo exige (no solo el activo)")
    # Dos sesiones del mismo usuario no conviven con roles distintos; sin el segundo factor la base no da identidad
    lt_a = login(c, "teso.med", "Definitiva#2026x"); HA = auth(lt_a["token"])
    c.post("/api/auth/contexto", headers=HA, json={"id_usuario_rol": ctx["TESORERO"]})
    lt_b = login(c, "teso.med", "Definitiva#2026x"); HB = auth(lt_b["token"])
    c.post("/api/auth/contexto", headers=HB, json={"id_usuario_rol": ctx["ABOGADO"]})
    check(c.get("/api/auth/yo", headers=HA).status_code == 401 and c.get("/api/auth/yo", headers=HB).status_code == 200,
          "al cambiar de rol en otro equipo se cierra la sesión que tenía el rol anterior")
    if os.environ.get("SUPER_DATABASE_URL"):
        import psycopg as _pgx
        with _pgx.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sx, _pgx.connect(os.environ["DATABASE_URL"], autocommit=True) as ax:
            sx.execute("UPDATE seguridad.sesion SET mfa_verificada = FALSE WHERE id_sesion = seguridad.fn_huella_sesion(%s)", (_sid(HB),))
            ax.execute("SELECT set_config('app.sesion', %s, false)", (_sid(HB),))
            par = ax.execute("SELECT seguridad.fn_id_usuario_actual(), seguridad.fn_id_usuario_sesion()").fetchone()
            sx.execute("UPDATE seguridad.sesion SET mfa_verificada = TRUE WHERE id_sesion = seguridad.fn_huella_sesion(%s)", (_sid(HB),))
            check(par[0] is None and par[1] is not None,
                  "con la contraseña de la base y una sesión sin el segundo factor verificado no se obtiene identidad para operar")
    print("Plazos de ley: Ley 1755 (arts. 14, 17, 19 y 21) y Ley 1581 (arts. 14 y 15)")
    import psycopg as _pgl
    SUPL = os.environ.get("SUPER_DATABASE_URL")
    HP = auth(login(c, "presi.med", "Definitiva#2026x")["token"])
    pl = c.get("/api/vistas/plazos_ley", headers=H).json()["filas"]
    check(len(pl) == 22 and all(f["diagnostico"] == "IGUAL A LA LEY" for f in pl), "los 22 plazos de ley están configurados igual a la ley")
    if SUPL:
        with _pgl.connect(SUPL, autocommit=True) as sc:
            def intento(q):
                try:
                    sc.execute(q); return "OK"
                except _pgl.Error as e:
                    return str(e)
            check("no uno más largo" in intento("UPDATE gestion_documental.tipo_pqrsd SET dias_habiles = 20 WHERE codigo = 'PETICION'"),
                  "nadie puede alargar el plazo de una petición más allá de los 15 días hábiles de la ley")
            check(intento("UPDATE gestion_documental.tipo_pqrsd SET dias_habiles = 12 WHERE codigo = 'PETICION'") == "OK"
                  and intento("UPDATE gestion_documental.tipo_pqrsd SET dias_habiles = 15 WHERE codigo = 'PETICION'") == "OK",
                  "el sindicato sí puede fijar un plazo más corto que el de la ley")
            check("no se cambia" in intento("UPDATE gestion_documental.parametro_pqrsd SET valor = 2 WHERE codigo = 'MESES_COMPLETAR'"),
                  "los plazos del peticionario (un mes para completar) son exactamente los de la ley")
            check("no uno más largo" in intento("UPDATE seguridad.parametro_privacidad SET valor = 20 WHERE codigo = 'DIAS_RECLAMO_TITULAR'"),
                  "el reclamo del titular no se responde en más de 15 días hábiles")
            check("inmutable" in intento("UPDATE gobernanza.plazo_legal SET maximo = 99"), "la tabla de plazos de ley no se modifica")
            esperado = lambda dias: str(sc.execute("SELECT gobernanza.fn_sumar_dias_habiles(gobernanza.fn_dia_base_radicacion(now()), %s)",
                                                   (dias,)).fetchone()[0])
            hoy_mas = lambda dias: str(sc.execute("SELECT gobernanza.fn_sumar_dias_habiles(gestion_documental.fn_hoy(), %s)", (dias,)).fetchone()[0])

            # Art. 19: petición que no se entiende
            q_a = pq(fecha_recepcion=None, motivo_registro_tardio=None, asunto="Petición confusa").json()["id_pqrsd"]
            n0 = len(BUZON)
            r = c.post(f"/api/pqrsd/{q_a}/pedir-aclaracion", headers=HP, json={"texto": "No es claro qué documento o actuación solicita"})
            _tq.sleep(0.5)
            cuerpo = [m.get_body(preferencelist=("plain",)).get_content() for to, m in BUZON[n0:] if "laura.pena@correo.test" in to]
            check(r.status_code == 200 and r.json()["fecha_limite_completar"] == hoy_mas(10) and cuerpo and "artículo 19" in cuerpo[0],
                  "petición que no se entiende: se devuelve para aclararla en 10 días hábiles, con aviso al peticionario (art. 19)")
            fa = c.get(f"/api/pqrsd/{q_a}", headers=HP).json()
            check(fa["pqrsd"]["tipo_requerimiento"] == "ACLARAR" and "ACLARE" in fa["plazo"]["diagnostico"]
                  and not fa["acciones"]["ampliar_completar"] and not fa["acciones"]["pedir_completar"],
                  "mientras tanto el plazo se suspende; los 10 días no se amplían")
            check(c.post(f"/api/pqrsd/{q_a}/ampliar-completar", headers=HP, json={"motivo": "El peticionario pidió más tiempo"}).status_code == 400,
                  "la base tampoco deja ampliar el plazo para aclarar")
            r = c.post(f"/api/pqrsd/{q_a}/completada", headers=HV, json={"detalle": "Aclaró que pide copia del acta de junio"})
            check(r.status_code == 200 and r.json()["fecha_limite"] == esperado(15),
                  "al aclarar, el plazo de 15 días hábiles empieza de nuevo desde el día siguiente")
            q_a2 = pq(fecha_recepcion=None, motivo_registro_tardio=None, asunto="Otra petición confusa").json()["id_pqrsd"]
            c.post(f"/api/pqrsd/{q_a2}/pedir-aclaracion", headers=HP, json={"texto": "No se entiende a qué empresa ni a qué hecho se refiere"})
            sc.execute("SELECT set_config('pqrsd.operacion', 'prueba', false)")
            sc.execute("UPDATE gestion_documental.pqrsd SET fecha_limite_completar = gestion_documental.fn_hoy() - 1 WHERE id_pqrsd = %s", (q_a2,))
            check("ARCHIVE LA PETICIÓN" in c.get(f"/api/pqrsd/{q_a2}", headers=HP).json()["plazo"]["diagnostico"],
                  "vencidos los 10 días sin aclaración: alerta para archivarla")
            r = c.post(f"/api/pqrsd/{q_a2}/desistimiento", headers=HP, json={"motivo": "No aclaró la petición dentro de los diez días"})
            fa2 = c.get(f"/api/pqrsd/{q_a2}", headers=HP).json()
            check(r.status_code == 200 and fa2["plazo"]["diagnostico"] == "CERRADA: ARCHIVADA POR FALTA DE ACLARACIÓN" and not fa2["acciones"]["recurso"],
                  "se archiva por falta de aclaración (sin recurso de reposición, que es del desistimiento del art. 17)")

            # Art. 17: recurso de reposición contra el desistimiento
            desist = [m for to, m in BUZON if m["Subject"].startswith("Archivo de su solicitud por desistimiento")]
            check(desist and "recurso de reposición" in desist[-1].get_body(preferencelist=("plain",)).get_content(),
                  "el aviso del desistimiento le dice al peticionario que puede presentar el recurso de reposición y hasta cuándo")
            fi = c.get(f"/api/pqrsd/{q_inc}", headers=HP).json()
            check(fi["acciones"]["recurso"] and fi["pqrsd"]["limite_recurso"] == hoy_mas(10), "hay 10 días hábiles para el recurso")
            sc.execute("UPDATE gestion_documental.pqrsd SET fecha_cierre = fecha_cierre - INTERVAL '30 days' WHERE id_pqrsd = %s", (q_inc,))
            r = c.post(f"/api/pqrsd/{q_inc}/recurso", headers=HV, json={"texto": "Sí envié el desprendible, adjunto la constancia"})
            check(r.status_code == 400 and "fuera de término" in r.json()["detail"], "el recurso presentado después de los 10 días hábiles se rechaza")
            sc.execute("UPDATE gestion_documental.pqrsd SET fecha_cierre = fecha_cierre + INTERVAL '30 days' WHERE id_pqrsd = %s", (q_inc,))
            r = c.post(f"/api/pqrsd/{q_inc}/recurso", headers=HV, json={"texto": "Sí envié el desprendible a tiempo, adjunto la constancia del envío"})
            check(r.status_code == 200 and "PENDIENTE DE DECIDIR" in c.get(f"/api/pqrsd/{q_inc}", headers=HP).json()["plazo"]["diagnostico"],
                  "la Ventanilla registra el recurso a tiempo y queda la alerta para decidirlo")
            check(c.post(f"/api/pqrsd/{q_inc}/decidir-recurso", headers=HV, json={"decision": "REVOCA", "motivo": "Se verificó el envío oportuno"}).status_code == 403,
                  "el recurso no lo decide la Ventanilla")
            n0 = len(BUZON)
            r = c.post(f"/api/pqrsd/{q_inc}/decidir-recurso", headers=HP, json={"decision": "REVOCA", "motivo": "Se verificó que el envío fue oportuno"})
            _tq.sleep(0.5)
            fi = c.get(f"/api/pqrsd/{q_inc}", headers=HP).json()
            check(r.status_code == 200 and fi["pqrsd"]["estado"] == "EN_TRAMITE" and fi["pqrsd"]["decision_recurso"] == "REVOCA"
                  and any("recurso" in m["Subject"] for to, m in BUZON[n0:]),
                  "si se revoca el desistimiento, el trámite sigue con los días que quedaban y se le avisa al peticionario")

            # Ley 1581: reclamo incompleto, desistimiento, traslado y leyenda «reclamo en trámite»
            sol = lambda tipo="RECTIFICACION", fecha=None: c.post("/api/r/solicitudes_titular", headers=H, json={
                "id_persona": sin_cargo, "tipo": tipo, "descripcion": "Pido corregir mi dirección y mi teléfono",
                **({"fecha_radicacion": fecha} if fecha else {})}).json()
            s3 = sol()
            ley = c.get(f"/api/privacidad/personas/{sin_cargo}/leyenda", headers=H).json()
            check(len(ley) == 1 and ley[0]["radicado"] == s3["radicado"], "al recibir el reclamo, los datos de la persona muestran «reclamo en trámite» (art. 15, num. 2)")
            r = c.post(f"/api/privacidad/solicitudes/{s3['id_solicitud']}/requerir", headers=H, json={"texto": "Indique la dirección y el teléfono correctos"})
            check(r.status_code == 200 and r.json()["fecha_limite_completar"] ==
                  str(sc.execute("SELECT gestion_documental.fn_hoy() + INTERVAL '2 months'").fetchone()[0])[:10],
                  "reclamo incompleto: se le pide al titular completarlo y tiene 2 meses")
            check(c.get(f"/api/privacidad/personas/{sin_cargo}/leyenda", headers=H).json() == [], "mientras está incompleto no lleva la leyenda")
            check(c.post(f"/api/privacidad/solicitudes/{s3['id_solicitud']}/responder", headers=H,
                         json={"respuesta": "Respuesta antes de que el titular complete"}).status_code == 400
                  and c.post(f"/api/privacidad/solicitudes/{s3['id_solicitud']}/prorrogar", headers=H, json={"motivo": "Prórroga sin plazo corriendo"}).status_code == 400,
                  "con el plazo suspendido no se responde ni se prorroga")
            r = c.post(f"/api/privacidad/solicitudes/{s3['id_solicitud']}/completar", headers=H, json={"detalle": "Envió la dirección y el teléfono"})
            check(r.status_code == 200 and r.json()["fecha_limite"] == esperado(15)
                  and len(c.get(f"/api/privacidad/personas/{sin_cargo}/leyenda", headers=H).json()) == 1,
                  "completo el reclamo, los 15 días hábiles cuentan desde el día siguiente y vuelve la leyenda")
            s_c = sol("CONSULTA")
            r = c.post(f"/api/privacidad/solicitudes/{s_c['id_solicitud']}/requerir", headers=H, json={"texto": "Indique qué información quiere conocer"})
            check(r.status_code == 400 and "consultas" in r.json()["detail"], "el requerimiento es para los reclamos, no para las consultas")
            fecha8 = str(sc.execute("SELECT (gobernanza.fn_sumar_dias_habiles(gestion_documental.fn_hoy() - 20, 1) + TIME '10:00') AT TIME ZONE 'America/Bogota'").fetchone()[0])
            s4 = sol(fecha=fecha8.replace(" ", "T"))
            r = c.post(f"/api/privacidad/solicitudes/{s4['id_solicitud']}/requerir", headers=H, json={"texto": "Indique la dirección y el teléfono correctos"})
            check(r.status_code == 400 and "5 días" in r.json()["detail"], "pasados 5 días hábiles del recibo ya no se puede requerir al titular")
            r = c.post(f"/api/privacidad/solicitudes/{s4['id_solicitud']}/trasladar", headers=H,
                       json={"entidad": "Instituto Departamental (empleador)", "motivo": "Esos datos los trata el empleador, no el sindicato"})
            sv4 = {f["radicado"]: f for f in vista("solicitudes_titular")}[s4["radicado"]]
            check(r.status_code == 200 and r.json()["tardio"] and "FUERA DE LOS 2 DÍAS" in sv4["diagnostico"],
                  "traslado a quien es competente: si pasan más de 2 días hábiles queda marcado como tardío")
            s5 = sol()
            c.post(f"/api/privacidad/solicitudes/{s5['id_solicitud']}/requerir", headers=H, json={"texto": "Adjunte el documento que soporta la corrección"})
            sc.execute("SELECT set_config('privacidad.operacion', 'requerir', false)")
            sc.execute("UPDATE gobernanza.solicitud_titular SET fecha_limite_completar = gestion_documental.fn_hoy() - 1 WHERE id_solicitud = %s",
                       (s5["id_solicitud"],))
            sc.execute("SELECT set_config('privacidad.operacion', '', false)")
            sv5 = {f["radicado"]: f for f in vista("solicitudes_titular")}[s5["radicado"]]
            check("PASARON LOS 2 MESES" in sv5["diagnostico"], "alerta cuando pasan los 2 meses sin que el titular complete")
            r = c.post(f"/api/privacidad/solicitudes/{s5['id_solicitud']}/desistir", headers=H, json={"motivo": "No completó el reclamo en dos meses"})
            check(r.status_code == 200 and r.json()["estado"] == "DESISTIDA"
                  and c.post(f"/api/privacidad/solicitudes/{s5['id_solicitud']}/responder", headers=H,
                             json={"respuesta": "Respuesta a una solicitud ya desistida"}).status_code == 400,
                  "se declara el desistimiento y la solicitud queda cerrada")
            with _pgl.connect(os.environ["DATABASE_URL"], autocommit=True) as ap:
                try:
                    ap.execute("UPDATE gobernanza.solicitud_titular SET estado = 'EN_TRAMITE' WHERE id_solicitud = %s", (s3["id_solicitud"],))
                    ap.execute("UPDATE gobernanza.solicitud_titular SET fecha_limite_completar = NULL WHERE id_solicitud = %s", (s3["id_solicitud"],)); m_t = "SIN ERROR"
                except _pgl.Error as e:
                    m_t = str(e)
            check(m_t != "SIN ERROR", "la cuenta de la aplicación no cambia directamente los plazos de una solicitud del titular")
    print("Documentos legales: política de datos, aviso de privacidad, reglamento de PQRSD y criterio de cautela")
    r = c.get("/api/publico/legal/politica-datos")
    check(r.status_code == 200 and r.json()["texto"], "la política de datos vigente se consulta sin iniciar sesión")
    r = c.get("/api/publico/legal/aviso-privacidad")
    check(r.status_code == 404 and "todavía no ha publicado" in r.json()["detail"], "el aviso de privacidad no se ve mientras siga en borrador")
    check(c.get("/api/publico/legal/otra-cosa").status_code == 404, "solo existen los tres documentos públicos")
    pols = {p["numero_version"]: p for p in c.get("/api/r/politicas_tratamiento", headers=H).json()["filas"]}
    r = c.post(f"/api/privacidad/politicas/{pols['2.0-borrador']['id_politica']}/publicar", headers=H)
    check(r.status_code == 400 and "[COMPLETAR]" in r.json()["detail"], "la política 2.0 no se publica mientras tenga marcas para el abogado")
    textos = {t["codigo"]: t for t in c.get("/api/r/textos_institucionales", headers=H).json()["filas"]}
    check(set(textos) == {"AVISO_PRIVACIDAD", "REGLAMENTO_PQRSD"}, "quedan cargados los borradores del aviso de privacidad y del reglamento de PQRSD")
    av = c.get("/api/r/textos_institucionales/registro", headers=H, params={"id_texto": textos["AVISO_PRIVACIDAD"]["id_texto"]}).json()
    check("Ley 1581" in av["texto"] or "sensible" in av["texto"], "el aviso de privacidad trae el texto completo")
    regl = c.get("/api/r/textos_institucionales/registro", headers=H, params={"id_texto": textos["REGLAMENTO_PQRSD"]["id_texto"]}).json()
    check("5:00 p. m." in regl["texto"] and "CRITERIO DE CAUTELA" in regl["texto"], "el reglamento fija la hora de corte y el criterio de cautela")
    r = c.post(f"/api/privacidad/textos/{av['id_texto']}/publicar", headers=H)
    check(r.status_code == 400 and "marca" in r.json()["detail"], "el aviso tampoco se publica con marcas pendientes")
    check(c.post(f"/api/privacidad/textos/{av['id_texto']}/publicar", headers=HP).status_code in (400, 403),
          "solo el administrador o la Presidencia Nacional publican")
    limpio = re.sub(r"\[(COMPLETAR|VERIFICAR)[^\]]*\]", "dato revisado", av["texto"])
    acta_t = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": 1, "asunto": "Acta que aprueba el aviso de privacidad"}).json()
    av = c.put("/api/r/textos_institucionales/registro", headers=H, params={"id_texto": av["id_texto"]},
               json={"texto": limpio, "numero_version": "1.0", "id_acta_aprobacion": acta_t.get("id_documento"), "version": av["version"]}).json()
    r = c.post(f"/api/privacidad/textos/{av['id_texto']}/publicar", headers=H)
    pub = c.get("/api/publico/legal/aviso-privacidad")
    check(r.status_code == 200 and pub.status_code == 200 and pub.json()["numero_version"] == "1.0",
          "revisado por el abogado y con el acta, el aviso se publica y queda a la vista del público")
    r = c.put("/api/r/textos_institucionales/registro", headers=H, params={"id_texto": av["id_texto"]}, json={"texto": "otro", "version": r.json()["version"]})
    check(r.status_code == 400, "una versión publicada no se modifica")
    if SUPL:
        with _pgl.connect(SUPL, autocommit=True) as sc:
            # Art. 19 con criterio de cautela: el plazo se reanuda con los días que quedaban
            n0 = len(BUZON)
            q_c = pq(fecha_recepcion=None, motivo_registro_tardio=None, asunto="Petición que no se entiende").json()["id_pqrsd"]
            _tq.sleep(0.5)
            acuse = [m.get_body(preferencelist=("plain",)).get_content() for to, m in BUZON[n0:] if "laura.pena@correo.test" in to]
            check(acuse and "5:00 p. m." in acuse[0], "el acuse de recibo informa la hora de corte de las 5:00 p. m.")
            base5 = sc.execute("""SELECT max(d)::date FROM generate_series(gestion_documental.fn_hoy() - 20, gestion_documental.fn_hoy(), INTERVAL '1 day') d
                                   WHERE gobernanza.fn_es_habil(d::date) AND gobernanza.fn_dias_habiles_entre(d::date, gestion_documental.fn_hoy()) = 5""").fetchone()[0]
            sc.execute("SELECT set_config('pqrsd.operacion', 'prueba', false)")
            sc.execute("UPDATE gestion_documental.pqrsd SET fecha_base = %s, fecha_limite = gobernanza.fn_sumar_dias_habiles(%s, 15) WHERE id_pqrsd = %s",
                       (base5, base5, q_c))
            sc.execute("SELECT set_config('pqrsd.operacion', '', false)")
            c.post(f"/api/pqrsd/{q_c}/pedir-aclaracion", headers=HP, json={"texto": "No se entiende qué documento solicita ni de qué fecha"})
            fc = c.get(f"/api/pqrsd/{q_c}", headers=HP).json()["pqrsd"]
            r = c.post(f"/api/pqrsd/{q_c}/completada", headers=HV, json={"detalle": "Aclaró que pide el acta de la asamblea de junio"})
            check(fc["dias_restantes_suspension"] == 10 and r.json()["fecha_limite"] == esperado(10),
                  "aclarada la petición, el plazo se reanuda con los días que quedaban (criterio de cautela), no se reinicia")
    print("Expediente de afiliación y afiliados dispersos")
    import time as _te
    import psycopg as _pge
    entrar = lambda u: auth(login(c, u, "Definitiva#2026x")["token"])
    HP, HV, HF2, HCom = entrar("presi.med"), entrar("ventanilla.med"), entrar("fiscal.med"), entrar("comunica.med")
    HSG, HCN = entrar("secretaria.nal"), entrar("carlos.med")
    exp = lambda pid, hh: c.get(f"/api/afiliacion/expedientes/{pid}", headers=hh)
    subir = lambda pid, cod, hh, *arch: c.post(f"/api/afiliacion/expedientes/{pid}/documentos/{cod}", headers=hh,
                                              files=[("archivos", a) for a in arch])
    doc_de = lambda e, cod: next(d for d in e["documentos"] if d["codigo"] == cod)
    # --- Hoja de ruta 1: Carolina, Subdirectiva Medellín, desde la ventanilla y su portal
    r = c.post("/api/r/personas", headers=HV, json={"tipo_dni": "CC", "dni": "1036001", "primer_nombre": "CAROLINA", "primer_apellido": "RESTREPO",
               "correo_electronico": "carolina@med.org", "lugar_expedicion_dni": "MEDELLÍN", "direccion_correspondencia": "Calle 50 # 40-20",
               "departamento": "ANTIOQUIA", "municipio": "MEDELLÍN"})
    check(r.status_code == 201 and r.json()["lugar_expedicion_dni"] == "MEDELLÍN", "Ventanilla registra los datos del formato: lugar de expedición y dirección")
    p_car = r.json()["id_persona"]
    r = c.post("/api/r/solicitudes_afiliacion", headers=HV, json={
        "id_persona": p_car, "id_estamento": 2, "id_empresa": emp_med["id_empresa"], "fecha_ingreso_empresa": "2023-03-01", "salario_base": "2900000",
        "fecha_nacimiento": "1988-04-12", "nivel_educativo": "PROFESIONAL", "cargo_empresa": "PROFESIONAL", "medio": "VENTANILLA",
        "profesion_oficio": "ADMINISTRADORA PÚBLICA", "area_empresa": "TALENTO HUMANO", "empleo_denominacion": "PROFESIONAL UNIVERSITARIO",
        "empleo_codigo": "219", "empleo_grado": "02", "fecha_formato": str(_dtm.date.today() - _dtm.timedelta(days=35))})
    s_car = r.json()
    hoy_e = _dtm.date.today()
    check(r.status_code == 201 and s_car["fecha_vence"] == str(hoy_e + _dtm.timedelta(days=60)),
          "la solicitud queda radicada con 60 días para completar los documentos")
    n0 = len(BUZON)
    r = c.post("/api/autoservicio/invitaciones", headers=HV, json={"id_persona": p_car})
    _te.sleep(0.5)
    inv = [m for to, m in BUZON[n0:] if "carolina@med.org" in to]
    check(r.status_code == 200 and inv, "con la solicitud pendiente ya se le puede invitar al portal (aún no es afiliada)")
    tok = re.search(r"t=([A-Za-z0-9_-]+)", inv[0].get_body(preferencelist=("plain",)).get_content()).group(1)
    from app import autoservicio as _as
    _as._publico.clear()   # el límite de consultas públicas por equipo ya se probó antes
    r = c.post("/api/publico/activar", json={"token": tok, "nombre_usuario": "carolina.r", "contrasena": "Portal#Med2026x", "acepta_politica": True})
    check(r.status_code == 200, "Carolina crea su cuenta desde el enlace" + ("" if r.status_code == 200 else r.text))
    HCAR = auth(login(c, "carolina.r", "Portal#Med2026x")["token"])
    yo_c = c.get("/api/auth/yo", headers=HCAR).json()
    check(yo_c["solicitante"] and not yo_c["portal_afiliado"], "entra como solicitante: solo ve «Mi afiliación»")
    check(c.get("/api/autoservicio/perfil", headers=HCAR).status_code == 403, "todavía no tiene perfil de afiliada")
    me = c.get("/api/autoservicio/afiliacion", headers=HCAR).json()
    check(me["estado_documental"] == "INCOMPLETA" and me["permiso"] == "TITULAR" and me["solicitud"]["radicado"] == s_car["radicado"]
          and [d["codigo"] for d in me["documentos"] if d["obligatorio"]] == ["CEDULA", "FORMATO_AFILIACION"] and len(me["documentos"]) == 4,
          "su lista: documento de identidad y formato obligatorios; acta de posesión y certificado de carrera opcionales")
    r = c.post("/api/autoservicio/afiliacion/documentos/CEDULA", headers=HCAR, files=[("archivos", ("nota.txt", b"hola"))])
    check(r.status_code == 400 and "PDF, JPG o PNG" in r.json()["detail"], "solo se aceptan PDF, JPG o PNG")
    r = c.post("/api/autoservicio/afiliacion/documentos/CEDULA", headers=HCAR,
               files=[("archivos", ("frente.jpg", foto("white"))), ("archivos", ("reverso.png", foto("gray", "PNG")))])
    check(r.status_code == 200 and r.json()["paginas"] == 2 and len(r.json()["hash_sha256"]) == 64,
          "sube la cédula con dos fotos desde el celular: quedan unidas en un PDF de 2 páginas con huella SHA-256")
    me = c.get("/api/autoservicio/afiliacion", headers=HCAR).json()
    check(me["estado_documental"] == "INCOMPLETA" and doc_de(me, "CEDULA")["estado"] == "POR_REVISAR",
          "puede salir y volver: lo cargado queda guardado y sigue faltando el formato")
    check(exp(pA, HCAR).status_code == 403, "no puede ver el expediente de otra persona")
    r = c.post("/api/autoservicio/afiliacion/documentos/FORMATO_AFILIACION", headers=HCAR, files=[("archivos", ("formato.pdf", pdf_real("Formato")))])
    check(r.status_code == 200 and c.get("/api/autoservicio/afiliacion", headers=HCAR).json()["estado_documental"] == "EN_REVISION",
          "con los dos obligatorios cargados el expediente pasa a revisión")
    e_com = exp(p_car, HCom).json()
    id_ced = doc_de(e_com, "CEDULA")["id_documento"]
    check(e_com["permiso"] == "ESTADO" and doc_de(e_com, "CEDULA")["nombre_archivo"] is None
          and c.get(f"/api/afiliacion/documentos/{id_ced}/archivo", headers=HCom).status_code == 403,
          "otro directivo de la junta solo ve el estado, no los archivos")
    e_fis = exp(p_car, HF2).json()
    r = c.get(f"/api/afiliacion/documentos/{id_ced}/archivo", headers=HF2)
    check(e_fis["permiso"] == "CONSULTA" and r.status_code == 200 and r.content[:4] == b"%PDF",
          "el Fiscal de la junta consulta los archivos")
    check(c.post(f"/api/afiliacion/documentos/{id_ced}/revisar", headers=HF2, json={"aceptar": True}).status_code == 403,
          "pero no los acepta ni los rechaza")
    check(c.get(f"/api/afiliacion/documentos/{id_ced}/archivo", headers=HV).status_code == 403,
          "Ventanilla no abre lo que cargó la persona por el portal")
    r = c.get(f"/api/afiliacion/documentos/{id_ced}/archivo", headers=H)
    check(r.status_code == 400 and "motivo" in r.json()["detail"], "el administrador solo abre un archivo escribiendo el motivo")
    check(c.get(f"/api/afiliacion/documentos/{id_ced}/archivo", headers=H, params={"motivo": "Soporte técnico: archivo reportado ilegible"}).status_code == 200,
          "con motivo, sí")
    if os.environ.get("SUPER_DATABASE_URL"):
        with _pge.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            n_acc = sc.execute("""SELECT count(*), count(*) FILTER (WHERE motivo IS NOT NULL) FROM auditoria.acceso_dato
                                   WHERE recurso = 'expediente_afiliacion' AND id_persona = %s""", (p_car,)).fetchone()
        check(n_acc == (2, 1), "cada apertura de un archivo queda en la bitácora de accesos (Ley 1581), con el motivo del administrador")
    id_for = doc_de(e_fis, "FORMATO_AFILIACION")["id_documento"]
    check(c.post(f"/api/afiliacion/documentos/{id_for}/revisar", headers=HP, json={"aceptar": False, "motivo": "corto"}).status_code == 400,
          "rechazar exige un motivo claro")
    r = c.post(f"/api/afiliacion/documentos/{id_for}/revisar", headers=HP, json={"aceptar": False, "motivo": "Falta la firma en la autorización del descuento"})
    me = c.get("/api/autoservicio/afiliacion", headers=HCAR).json()
    check(r.json()["estado"] == "RECHAZADO" and me["estado_documental"] == "INCOMPLETA"
          and doc_de(me, "FORMATO_AFILIACION")["motivo_rechazo"] == "Falta la firma en la autorización del descuento",
          "el Presidente rechaza el formato y Carolina ve el motivo en su portal")
    c.post("/api/autoservicio/afiliacion/documentos/FORMATO_AFILIACION", headers=HCAR, files=[("archivos", ("formato_firmado.pdf", pdf_real("Firmado")))])
    e_p = exp(p_car, HP).json()
    check(doc_de(e_p, "FORMATO_AFILIACION")["estado"] == "POR_REVISAR" and doc_de(e_p, "FORMATO_AFILIACION")["anteriores"] == 1,
          "lo vuelve a subir: el nuevo queda por revisar y el rechazado se conserva en el historial (nada se borra)")
    r = c.post(f"/api/afiliaciones/{s_car['id_solicitud_afiliacion']}/aprobar", headers=HP, json={})
    check(r.status_code == 400 and "revisar" in r.json()["detail"], "no se aprueba mientras haya obligatorios sin revisar")
    for cod in ("CEDULA", "FORMATO_AFILIACION"):
        c.post(f"/api/afiliacion/documentos/{doc_de(e_p, cod)['id_documento']}/revisar", headers=HP, json={"aceptar": True})
    check(exp(p_car, HP).json()["estado_documental"] == "COMPLETA", "aceptados los dos, el expediente queda completo")
    sol_v = next(f for f in vista("solicitudes_afiliacion") if f["radicado"] == s_car["radicado"])
    check(sol_v["estado_documental"] == "COMPLETA" and "LISTA PARA DECIDIR" in sol_v["diagnostico"], "la vista de solicitudes la muestra lista para decidir")
    r = c.post(f"/api/afiliaciones/{s_car['id_solicitud_afiliacion']}/aprobar", headers=HP, json={})
    af_c = c.get("/api/r/afiliados/registro", headers=H, params={"id_persona": p_car}).json()
    check(af_c["fecha_afiliacion"] == str(_dtm.date.today()) and s_car["fecha_formato"] == str(_dtm.date.today() - _dtm.timedelta(days=35)),
          "la fecha de afiliación es la de la aprobación; la del formato queda solo como dato")
    check(r.json()["estado"] == "APROBADA" and af_c["empleo_codigo"] == "219" and af_c["profesion_oficio"] == "ADMINISTRADORA PÚBLICA",
          "el Presidente aprueba: el afiliado queda con su profesión y su empleo (denominación, código y grado)")
    yo_c = c.get("/api/auth/yo", headers=HCAR).json()
    check(yo_c["portal_afiliado"] and not yo_c["solicitante"], "la misma cuenta pasa a ser la del portal completo del afiliado")
    r = c.post("/api/autoservicio/afiliacion/documentos/ACTA_POSESION", headers=HCAR, files=[("archivos", ("acta.pdf", pdf_real("Acta de posesión")))])
    check(r.status_code == 200 and doc_de(c.get("/api/autoservicio/afiliacion", headers=HCAR).json(), "ACTA_POSESION")["estado"] == "POR_REVISAR",
          "ya afiliada, agrega su acta de posesión (opcional) en «Mis documentos»")
    inc = {f["id_persona"] for f in vista("expedientes_incompletos")}
    check(p_car not in inc and pA in inc, "vista informativa: afiliados antiguos sin documentos aparecen; Carolina no")

    # --- Hoja de ruta 2: Jorge, afiliado disperso (Junta Directiva Nacional)
    p_jor = c.post("/api/r/personas", headers=H, json={"tipo_dni": "CC", "dni": "1036002", "primer_nombre": "JORGE", "primer_apellido": "DISPERSO",
                   "correo_electronico": "jorge@pasto.org"}).json()["id_persona"]
    r = c.post("/api/r/solicitudes_afiliacion", headers=H, json={
        "id_persona": p_jor, "id_estamento": 1, "id_empresa": emp_med["id_empresa"], "fecha_ingreso_empresa": "2022-01-10", "salario_base": "3100000",
        "fecha_nacimiento": "1985-02-02", "nivel_educativo": "PROFESIONAL", "cargo_empresa": "PROFESIONAL", "medio": "CORREO"})
    check(r.status_code == 201, "la solicitud de un disperso se dirige a la Junta Directiva Nacional")
    s_jor = r.json()
    check(exp(p_jor, HP).status_code == 403, "la Subdirectiva Medellín no ve el expediente de un disperso")
    for cod in ("CEDULA", "FORMATO_AFILIACION"):
        r = subir(p_jor, cod, HCN, ("doc.pdf", pdf_real(cod)))
    check(r.status_code == 200 and exp(p_jor, HCN).json()["permiso"] == "GESTIONA",
          "cualquier directivo nacional (aquí el Vicepresidente Nacional) carga los documentos del disperso")
    e_j = exp(p_jor, HCN).json()
    for cod in ("CEDULA", "FORMATO_AFILIACION"):
        c.post(f"/api/afiliacion/documentos/{doc_de(e_j, cod)['id_documento']}/revisar", headers=HCN, json={"aceptar": True})
    check(exp(p_jor, HCN).json()["estado_documental"] == "COMPLETA", "y los revisa")
    r = c.post(f"/api/afiliaciones/{s_jor['id_solicitud_afiliacion']}/aprobar", headers=HCN, json={})
    check(r.status_code == 400 and "Junta Directiva Nacional" in r.json()["detail"],
          "pero la afiliación del disperso no la registra cualquiera: la decide la Junta Nacional en reunión")
    r = c.post(f"/api/afiliaciones/{s_jor['id_solicitud_afiliacion']}/aprobar", headers=HSG, json={})
    check(r.status_code == 400 and "acta" in r.json()["detail"], "la Secretaría General Nacional la registra solo con el acta")
    acta_med = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": 2, "asunto": "Acta Medellín"}).json()
    r = c.post(f"/api/afiliaciones/{s_jor['id_solicitud_afiliacion']}/aprobar", headers=HSG, json={"id_acta": acta_med["id_documento"]})
    check(r.status_code == 400, "un acta de otra junta no sirve")
    acta_jdn = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": 1,
                      "asunto": "Acta JDN: afiliación de dispersos"}).json()
    r = c.post(f"/api/afiliaciones/{s_jor['id_solicitud_afiliacion']}/aprobar", headers=HSG, json={"acta": acta_jdn["radicado_alfanumerico"]})
    af_j = c.get("/api/r/afiliados/registro", headers=H, params={"id_persona": p_jor}).json()
    hist = [f for f in vista("historial_pertenencia") if f["id_persona"] == p_jor]
    check(r.json()["estado"] == "APROBADA" and af_j["id_estamento_pertenencia"] == 1 and hist and hist[0]["disperso"]
          and hist[0]["acta"] == acta_jdn["radicado_alfanumerico"],
          "con el acta de la Junta Nacional (por su radicado) queda afiliado como disperso, y el historial guarda el acta")
    # Una afiliada local decide ser dispersa (aunque haya subdirectiva): lo decide la Junta Nacional
    r = c.put("/api/r/afiliados/registro", headers=H, params={"id_persona": p_car}, json={"id_estamento_pertenencia": 1, "version": af_c["version"]})
    check(r.status_code == 400 and "disperso" in r.json()["detail"], "ni el administrador la pasa a disperso editando la ficha")
    r = c.post(f"/api/afiliacion/pertenencia/{p_car}", headers=HP, json={"id_estamento": 1, "acta": acta_jdn["id_documento"], "motivo": "Pidió ser dispersa"})
    check(r.status_code == 403, "ni el Presidente de su subdirectiva")
    r = c.post(f"/api/afiliacion/pertenencia/{p_car}", headers=HSG, json={"id_estamento": 1, "acta": acta_jdn["id_documento"],
               "motivo": "Pidió ser dispersa por traslado de domicilio"})
    check(r.status_code == 200 and r.json()["resultado"] == "DISPERSO", "la Secretaría General Nacional la registra como dispersa, con el acta")
    check(exp(p_car, HP).status_code == 403 and exp(p_car, HCN).json()["permiso"] == "GESTIONA",
          "su expediente pasa a la Junta Nacional: Medellín ya no lo ve")
    r = c.post(f"/api/afiliacion/pertenencia/{p_car}", headers=HSG, json={"id_estamento": 2, "acta": acta_jdn["id_documento"],
               "motivo": "La Junta Nacional aprobó su regreso a Medellín"})
    check(r.status_code == 200 and c.get("/api/r/afiliados/registro", headers=H, params={"id_persona": p_car}).json()["id_estamento_pertenencia"] == 2,
          "y volver a una subdirectiva también lo decide la Junta Nacional (no hay traslado automático)")
    if os.environ.get("SUPER_DATABASE_URL"):
        ap_j = cons_med(12).get(p_jor)
        with _pge.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            filas_d = sc.execute("SELECT concepto, valor, id_estamento FROM finanzas_interno.distribucion WHERE id_aporte = %s",
                                 (ap_j["id_aporte"],)).fetchall() if ap_j else []
        check(ap_j and [(f[0], float(f[1]), f[2]) for f in filas_d] == [("APORTE_NACIONAL", float(ap_j["monto_descuento_ley"]), 1)],
              "el aporte de un disperso va 100 % a la Junta Nacional (nada a una subdirectiva)")

    # --- Vencimiento, recordatorios y aviso a la junta
    def solicitud_med(dni, nombre, correo):
        pid = c.post("/api/r/personas", headers=HV, json={"tipo_dni": "CC", "dni": dni, "primer_nombre": nombre, "primer_apellido": "PLAZO",
                     "correo_electronico": correo}).json()["id_persona"]
        sol = c.post("/api/r/solicitudes_afiliacion", headers=HV, json={
            "id_persona": pid, "id_estamento": 2, "id_empresa": emp_med["id_empresa"], "fecha_ingreso_empresa": "2024-02-01", "salario_base": "1900000",
            "fecha_nacimiento": "1992-01-01", "nivel_educativo": "TECNICO", "cargo_empresa": "TECNICO", "medio": "VENTANILLA"}).json()
        return pid, sol
    p_v, s_v = solicitud_med("1036003", "VENCIDA", "vencida@med.org")
    p_r, s_r = solicitud_med("1036004", "RECORDAR", "recordar@med.org")
    p_q, s_q = solicitud_med("1036005", "REVISAR", "revisar@med.org")
    r = subir(p_q, "CEDULA", HV, ("c.pdf", pdf_real("c")))
    check(r.status_code == 200 and exp(p_q, HV).json()["permiso"] == "VENTANILLA", "Ventanilla carga documentos a nombre de la persona")
    id_vq = doc_de(exp(p_q, HV).json(), "CEDULA")["id_documento"]
    check(c.get(f"/api/afiliacion/documentos/{id_vq}/archivo", headers=HV).status_code == 200, "y puede ver lo que ella misma cargó")
    check(c.post(f"/api/afiliacion/documentos/{id_vq}/revisar", headers=HV, json={"aceptar": True}).status_code == 403, "pero no lo revisa")
    n0 = len(BUZON)
    c.post("/api/autoservicio/invitaciones", headers=HV, json={"id_persona": p_v})
    _te.sleep(0.5)
    tok_v = re.search(r"t=([A-Za-z0-9_-]+)", [m for to, m in BUZON[n0:] if "vencida@med.org" in to][0].get_body(preferencelist=("plain",)).get_content()).group(1)
    _as._publico.clear()
    c.post("/api/publico/activar", json={"token": tok_v, "nombre_usuario": "vencida.p", "contrasena": "Portal#Ven2026x", "acepta_politica": True})
    if os.environ.get("SUPER_DATABASE_URL"):
        with _pge.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            sc.execute("SELECT set_config('afiliacion.operacion', 'archivar', false)")
            sc.execute("""UPDATE gobernanza.solicitud_afiliacion SET fecha_creacion = now() - INTERVAL '61 days',
                                 fecha_vence = gestion_documental.fn_hoy() - 1 WHERE id_solicitud_afiliacion = %s""", (s_v["id_solicitud_afiliacion"],))
            sc.execute("UPDATE gobernanza.solicitud_afiliacion SET fecha_creacion = now() - INTERVAL '4 days' WHERE id_solicitud_afiliacion = %s",
                       (s_r["id_solicitud_afiliacion"],))
            sc.execute("SELECT set_config('afiliacion.operacion', '', false)")
        r = c.post(f"/api/afiliacion/expedientes/{p_v}/documentos/CEDULA", headers=HV, files=[("archivos", ("c.pdf", pdf_real("c")))])
        check(r.status_code == 400 and "venció" in r.json()["detail"], "vencido el plazo ya no se cargan documentos a esa solicitud")
        n0 = len(BUZON)
        res = c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False}).json()["resumen"]["EXPEDIENTE_AFILIACION"]
        _te.sleep(0.5)
        nuevos_c = BUZON[n0:]
        arch = [m for to, m in nuevos_c if "vencida@med.org" in to]
        rec = [m for to, m in nuevos_c if "recordar@med.org" in to]
        junta = [(to, m) for to, m in nuevos_c if m["Subject"].startswith("Solicitudes de afiliación por atender")]
        sv = c.get("/api/r/solicitudes_afiliacion/registro", headers=HP, params={"id_solicitud_afiliacion": s_v["id_solicitud_afiliacion"]}).json()
        check(sv["estado"] == "ARCHIVADA" and arch and "archivada" in arch[0]["Subject"], "a los 60 días sin documentos la solicitud se archiva y se le avisa")
        login(c, "vencida.p", "Portal#Ven2026x", 401)
        check(True, "y su cuenta del portal queda desactivada")
        check(rec and "Faltan documentos" in rec[0]["Subject"] and "Falta:" in rec[0].get_body(("plain",)).get_content(),
              "a los 3 días se le recuerda a la persona lo que le falta")
        check(junta and "presi@med.org" in sum((to for to, _ in junta), []) and any("por revisar" in m.get_body(("plain",)).get_content() for _, m in junta),
              "la junta recibe el resumen de documentos por revisar")
        check(res["enviados"] >= 3, "correos del expediente de afiliación enviados")
        r2 = c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False}).json()["resumen"]["EXPEDIENTE_AFILIACION"]
        check(r2["enviados"] == 0, "los recordatorios no se repiten")
        s_n = c.post("/api/r/solicitudes_afiliacion", headers=HV, json={
            "id_persona": p_v, "id_estamento": 2, "id_empresa": emp_med["id_empresa"], "fecha_ingreso_empresa": "2024-02-01", "salario_base": "1900000",
            "fecha_nacimiento": "1992-01-01", "nivel_educativo": "TECNICO", "cargo_empresa": "TECNICO", "medio": "VENTANILLA"})
        check(s_n.status_code == 201, "la persona puede volver a solicitar la afiliación")
        # Rechazo con el plazo ya vencido: la persona recibe 10 días más para reemplazar el documento
        p_x, s_x = solicitud_med("1036006", "TARDE", "tarde@med.org")
        for cod in ("CEDULA", "FORMATO_AFILIACION"):
            subir(p_x, cod, HV, ("d.pdf", pdf_real(cod)))
        with _pge.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            sc.execute("SELECT set_config('afiliacion.operacion', 'archivar', false)")
            sc.execute("""UPDATE gobernanza.solicitud_afiliacion SET fecha_creacion = now() - INTERVAL '65 days',
                                 fecha_vence = gestion_documental.fn_hoy() - 5 WHERE id_solicitud_afiliacion = %s""", (s_x["id_solicitud_afiliacion"],))
            sc.execute("SELECT set_config('afiliacion.operacion', '', false)")
        sx = next(f for f in vista("solicitudes_afiliacion") if f["radicado"] == s_x["radicado"])
        check("VENCIÓ CON DOCUMENTOS POR REVISAR" in sx["diagnostico"],
              "si la persona cumplió y la junta no revisó a tiempo, la solicitud no se archiva: alerta crítica para la junta")
        c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False})
        check(c.get("/api/r/solicitudes_afiliacion/registro", headers=HP, params={"id_solicitud_afiliacion": s_x["id_solicitud_afiliacion"]}).json()["estado"] == "PENDIENTE",
              "y el proceso de correos no la archiva")
        id_cx = doc_de(exp(p_x, HP).json(), "CEDULA")["id_documento"]
        n0 = len(BUZON)
        c.post(f"/api/afiliacion/documentos/{id_cx}/revisar", headers=HP, json={"aceptar": False, "motivo": "La foto está borrosa, no se lee el número"})
        sxr = c.get("/api/r/solicitudes_afiliacion/registro", headers=HP, params={"id_solicitud_afiliacion": s_x["id_solicitud_afiliacion"]}).json()
        check(sxr["fecha_vence"] == str(hoy_e + _dtm.timedelta(days=10)), "al rechazarle un documento obligatorio, su plazo se extiende a 10 días desde el rechazo")
        c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": False})
        _te.sleep(0.5)
        aviso_r = [m for to, m in BUZON[n0:] if "tarde@med.org" in to and "reemplazar" in m["Subject"]]
        check(len(aviso_r) == 1 and "borrosa" in aviso_r[0].get_body(("plain",)).get_content(),
              "la persona recibe un correo con el motivo del rechazo y la nueva fecha límite")
        check(subir(p_x, "CEDULA", HV, ("c2.pdf", pdf_real("nítida"))).status_code == 200, "y puede reemplazarlo aunque el plazo general ya había vencido")
        r = subir(p_x, "FORMATO_AFILIACION", HP, ("f2.pdf", pdf_real("recibido por el Presidente")))
        r = c.post(f"/api/afiliacion/documentos/{r.json()['id_documento']}/revisar", headers=HP, json={"aceptar": True})
        check(r.status_code == 200 and r.json()["estado"] == "ACEPTADO",
              "el directivo que recibe un documento también puede aceptarlo (decisión del sindicato)")
        # Fecha de afiliación = la de la aprobación; una anterior solo desde la radicación y con motivo
        e_x = exp(p_x, HP).json()
        c.post(f"/api/afiliacion/documentos/{doc_de(e_x, 'CEDULA')['id_documento']}/revisar", headers=HP, json={"aceptar": True})
        aprobar_x = lambda **kw: c.post(f"/api/afiliaciones/{s_x['id_solicitud_afiliacion']}/aprobar", headers=HP, json=kw)
        r = aprobar_x(fecha_afiliacion=str(hoy_e + _dtm.timedelta(days=1)), motivo_fecha="Se registró tarde en el sistema")
        check(r.status_code == 400 and "futura" in r.json()["detail"], "la fecha de afiliación no puede ser futura")
        r = aprobar_x(fecha_afiliacion=str(hoy_e - _dtm.timedelta(days=70)), motivo_fecha="Se registró tarde en el sistema")
        check(r.status_code == 400 and "radicación" in r.json()["detail"], "ni anterior a la radicación de la solicitud")
        r = aprobar_x(fecha_afiliacion=str(hoy_e - _dtm.timedelta(days=30)))
        check(r.status_code == 400 and "motivo" in r.json()["detail"], "una fecha anterior a hoy exige el motivo")
        r = aprobar_x(fecha_afiliacion=str(hoy_e - _dtm.timedelta(days=30)), motivo_fecha="La junta aprobó en el acta del mes pasado y se registró tarde")
        sx2 = c.get("/api/r/solicitudes_afiliacion/registro", headers=HP, params={"id_solicitud_afiliacion": s_x["id_solicitud_afiliacion"]}).json()
        check(r.status_code == 200 and sx2["fecha_afiliacion"] == str(hoy_e - _dtm.timedelta(days=30)) and sx2["motivo_fecha_afiliacion"],
              "con motivo y desde la radicación, sí: el motivo queda en la solicitud")
    # Plantilla del formato
    r = c.post("/api/afiliacion/tipos/FORMATO_AFILIACION/plantilla", headers=HP, files={"archivo": ("formato.pdf", pdf_real("Formato en blanco"))})
    check(r.status_code == 403, "la plantilla del formato la publica la administración o la Presidencia Nacional")
    r = c.post("/api/afiliacion/tipos/FORMATO_AFILIACION/plantilla", headers=H, files={"archivo": ("formato_afiliacion.pdf", pdf_real("Formato en blanco"))})
    b = c.get("/api/afiliacion/tipos/FORMATO_AFILIACION/plantilla", headers=HCAR)
    check(r.status_code == 200 and b.status_code == 200 and b.content[:4] == b"%PDF", "y la persona la descarga desde su portal")
    # Los borradores legales toman el nombre y el NIT de los datos institucionales al publicarse
    if os.environ.get("SUPER_DATABASE_URL"):
        with _pge.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            bor = sc.execute("SELECT texto FROM gobernanza.politica_tratamiento WHERE numero_version = '2.0-borrador'").fetchone()[0]
            lleno = sc.execute("SELECT gobernanza.fn_rellenar_institucional(%s)", (bor[:400],)).fetchone()[0]
        check("{{NIT}}" in bor and "[COMPLETAR: NIT]" not in bor and "901.763.807-9" in lleno and "Sindicato de Prueba" in lleno,
              "los borradores ya no traen el NIT ni el nombre fijos: se llenan con los datos institucionales al publicarlos")

    print("Lugares oficiales (ISO 3166-1 y DIVIPOLA), traslados entre juntas y Palmira")
    opc = lambda clave, **kw: c.get(f"/api/opciones/{clave}", headers=H, params=kw).json()
    pa = opc("paises")
    check(len(pa) == 249 and pa[0]["valor"] == "CO" and pa[0]["etiqueta"] == "Colombia", "lista de 249 países ISO 3166-1 en español, con Colombia primero")
    check(len(opc("departamentos", depende="CO")) == 33 and opc("departamentos", depende="VE") == [],
          "33 departamentos (32 y Bogotá, D.C.), solo cuando el país es Colombia")
    mv = opc("municipios", depende="76")
    check(mv and all(m["valor"].startswith("76") for m in mv), "al elegir Valle del Cauca, solo se ofrecen sus municipios")
    pers = lambda dni, **kw: c.post("/api/r/personas", headers=H, json={"tipo_dni": "CC", "dni": dni, "primer_nombre": "LUGAR",
                                                                       "primer_apellido": "PRUEBA", "correo_electronico": f"{dni}@x.org", **kw})
    r = pers("990101", pais_codigo="VE", departamento_codigo="76")
    check(r.status_code == 400 and "solo se registran para Colombia" in r.json()["detail"], "fuera de Colombia no hay departamento ni municipio")
    r = pers("990102", departamento_codigo="05", municipio_codigo="76001")
    check(r.status_code == 400 and "no pertenece" in r.json()["detail"], "el municipio debe ser del departamento elegido")
    r = pers("990103", municipio="RIONEGRO")
    check(r.status_code == 400 and "no se reconoce" in r.json()["detail"], "un nombre ambiguo (Rionegro, Antioquia o Santander) no se adivina")
    r = pers("990104", departamento_codigo="76", municipio_codigo="76036")
    check(r.status_code == 201 and r.json()["municipio"] == "ANDALUCÍA" and r.json()["pais_codigo"] == "CO",
          "se guarda el código y el nombre oficial; el país queda en Colombia")
    check(not [f for f in vista("lugares_por_corregir") if f["registro"] in ("Empresa", "Sede", "Junta")],
          "empresas, sedes y juntas quedaron con su municipio DIVIPOLA")
    r = c.post("/api/r/estamentos", headers=H, json={"nombre_estamento": "Subdirectiva Palmira", "tipo_estamento": "SUBDIRECTIVA",
                                                     "departamento_codigo": "76", "municipio_codigo": "76520"})
    check(r.status_code == 400 and "sede nacional" in r.json()["detail"], "en Palmira (sede nacional) no se puede crear subdirectiva ni comité")

    # --- El caso de la Gobernación del Valle: sede principal en Cali, sede en Andalucía
    gob = c.post("/api/r/empresas", headers=H, json={"nit": "890399029-5", "nombre_empresa": "GOBERNACIÓN DEL VALLE DEL CAUCA",
                 "departamento_codigo": "76", "municipio_codigo": "76001", "direccion": "Carrera 6 entre calles 9 y 10", "rango_empleados": "MÁS DE 500",
                 "telefono_1": "6026200000", "correo_general": "gob@valle.test", "correo_notificaciones_judiciales": "jud@valle.test"}).json()
    sede_and = c.post("/api/r/sedes", headers=H, json={"id_empresa": gob["id_empresa"], "nombre_sede": "SEDE ANDALUCÍA",
                      "departamento_codigo": "76", "municipio_codigo": "76036"}).json()
    est_and = c.post("/api/r/estamentos", headers=H, json={"nombre_estamento": "Subdirectiva Andalucía", "tipo_estamento": "SUBDIRECTIVA",
                     "departamento_codigo": "76", "municipio_codigo": "76036"}).json()["id_estamento"]
    reg_and = c.post("/api/r/registros_inspector", headers=H, json={"id_estamento": est_and, "id_inspector": 1,
                     "num_registro_inspector": "REG-2026-AND-01", "fecha_emision_registro": "2026-09-01T10:00:00-05:00"}).json()["id_registro"]

    def afiliado_gob(dni, nombre, junta, sede=None):
        pid = c.post("/api/r/personas", headers=H, json={"tipo_dni": "CC", "dni": dni, "primer_nombre": nombre, "primer_apellido": "VALLE",
                     "correo_electronico": f"{dni}@valle.test"}).json()["id_persona"]
        c.post("/api/r/afiliados", headers=H, json={"id_persona": pid, "fecha_afiliacion": "2025-01-01", "fecha_nacimiento": "1985-01-01",
               "nivel_educativo": "PROFESIONAL", "cargo_empresa": "PROFESIONAL", "id_estamento_pertenencia": junta})
        r = c.post("/api/r/afiliados_empresa", headers=H, json={"id_persona": pid, "id_empresa": gob["id_empresa"], "id_sede": sede,
                   "salario_base": "3200000", "fecha_ingreso_empresa": "2020-01-01"})
        assert r.status_code == 201, r.text
        return pid
    p_pand = afiliado_gob("760001", "PRESIDENTA", est_and, sede_and["id_sede"])
    check(directivo(p_pand, est_and, "PRES_REG", registro=reg_and).status_code == 201, "la Subdirectiva Andalucía tiene Presidenta")
    HAND, _ = crear_usuario("presi.andalucia", "DIRECTIVO", p_pand)
    p_pcal = afiliado_gob("760003", "PRESIDENTE", 3)
    check(directivo(p_pcal, 3, "PRES_COM", registro=3).status_code == 201, "y el Comité Cali, Presidente")
    check(c.post("/api/r/registros_inspector", headers=H, json={"id_estamento": 3, "id_inspector": 1, "num_registro_inspector": "REG-2026-CALI-02",
                 "fecha_emision_registro": "2026-09-01T11:00:00-05:00"}).status_code == 201, "el inspector registra al nuevo Presidente del Comité Cali")
    HLC, _ = crear_usuario("presi.cali", "DIRECTIVO", p_pcal)
    p_x = afiliado_gob("760002", "FUNCIONARIA", 3, sede_and["id_sede"])
    check(True, "una funcionaria de la sede Andalucía pertenece al Comité Cali (sede principal de la Gobernación)")
    acta_cali = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": 3, "asunto": "Acta: traslados"}).json()
    acta_and = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": est_and, "asunto": "Acta: traslados"}).json()
    acta_med2 = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": 2, "asunto": "Acta: traslados"}).json()
    proponer = lambda hh, pid, destino, acta, motivo="Facilita la gestión de sus asuntos en su municipio": c.post(
        "/api/afiliacion/traslados", headers=hh, json={"id_persona": pid, "id_estamento": destino, "acta": acta, "motivo": motivo})
    check(proponer(HP, p_x, est_and, acta_med2["radicado_alfanumerico"]).status_code == 403, "una junta ajena al traslado no lo propone")
    r = proponer(HLC, p_x, est_and, acta_and["radicado_alfanumerico"])
    check(r.status_code == 400 and "acta" in r.json()["detail"], "quien propone usa el acta de su propia junta")
    r = proponer(HLC, p_x, est_and, acta_cali["radicado_alfanumerico"])
    t1 = r.json()
    check(r.status_code == 200 and t1["excepcion"] == "NO" and "ANDALUCÍA" in t1["diagnostico"].upper(),
          "el Comité Cali propone el traslado a Andalucía con su acta; queda esperando la respuesta de Andalucía")
    check(proponer(HLC, p_x, est_and, acta_cali["radicado_alfanumerico"]).status_code == 400, "no hay dos traslados propuestos a la vez")
    resp = lambda hh, t, accion, **kw: c.post(f"/api/afiliacion/traslados/{t}/{accion}", headers=hh, json=kw)
    check(resp(HLC, t1["id_traslado"], "aceptar", acta=acta_cali["radicado_alfanumerico"]).status_code == 403,
          "la junta que lo propuso no se lo aprueba a sí misma")
    check(resp(HAND, t1["id_traslado"], "rechazar", acta=acta_and["radicado_alfanumerico"]).status_code == 400, "rechazar exige motivo")
    check(resp(HAND, t1["id_traslado"], "aceptar", acta=acta_cali["radicado_alfanumerico"]).status_code == 400,
          "la junta que responde usa el acta de su propia junta")
    r = resp(HAND, t1["id_traslado"], "aceptar", acta=acta_and["radicado_alfanumerico"])
    afx = c.get("/api/r/afiliados/registro", headers=H, params={"id_persona": p_x}).json()
    hx = [f for f in vista("historial_pertenencia") if f["id_persona"] == p_x][0]
    check(r.json()["estado"] == "APROBADO" and afx["id_estamento_pertenencia"] == est_and and hx["motivo"].startswith("Traslado")
          and hx["acta"] == acta_and["radicado_alfanumerico"],
          "Andalucía lo acepta con su acta: la funcionaria pasa a la Subdirectiva Andalucía y queda en el historial")
    check(exp(p_x, HAND).json()["permiso"] == "GESTIONA" and exp(p_x, HLC).status_code == 403,
          "su expediente pasa a Andalucía y el Comité Cali deja de verlo")
    # Excepción: Andalucía → Medellín (no es su municipio de trabajo ni el de la sede principal)
    r = proponer(HAND, p_x, 2, acta_and["radicado_alfanumerico"], "Decisión de las dos juntas por su labor en la seccional")
    t2 = r.json()
    check(r.status_code == 200 and t2["excepcion"] == "SÍ", "un traslado fuera de la regla de municipio queda marcado como excepción")
    r = resp(HP, t2["id_traslado"], "aceptar", acta=acta_med2["radicado_alfanumerico"])
    vp = next(f for f in vista("pertenencia") if f["id_persona"] == p_x)
    check(r.json()["estado"] == "APROBADO" and vp["diagnostico"].startswith("EXCEPCIÓN APROBADA") and acta_med2["radicado_alfanumerico"] in vp["actas_excepcion"],
          "con las dos actas se admite y la vista de pertenencia la muestra como excepción con sus actas")
    ae = c.get("/api/r/afiliados_empresa/registro", headers=H, params={"id_persona": p_x, "id_empresa": gob["id_empresa"]}).json()
    r = c.put("/api/r/afiliados_empresa/registro", headers=H, params={"id_persona": p_x, "id_empresa": gob["id_empresa"]},
              json={"salario_base": "3300000", "version": ae["version"]})
    check(r.status_code == 200, "la excepción se mantiene: otros cambios de su ficha no la rechazan")
    r = proponer(HP, p_x, est_and, acta_med2["radicado_alfanumerico"], "Regresa a la junta de su municipio de trabajo")
    check(resp(HAND, r.json()["id_traslado"], "anular", motivo="No le corresponde anularlo").status_code == 403
          and resp(HP, r.json()["id_traslado"], "anular", motivo="Se tomó la decisión sin consultar a la afiliada").json()["estado"] == "ANULADO",
          "un traslado propuesto lo anula solo la junta que lo propuso")

    # --- Palmira: sede nacional, sin subdirectiva; sus afiliados pertenecen a la Junta Nacional
    alc = c.post("/api/r/empresas", headers=H, json={"nit": "891380007-3", "nombre_empresa": "ALCALDÍA DE PALMIRA",
                 "departamento_codigo": "76", "municipio_codigo": "76520", "direccion": "Calle 30 # 29-39", "rango_empleados": "MÁS DE 500",
                 "telefono_1": "6022709500", "correo_general": "alcaldia@palmira.test", "correo_notificaciones_judiciales": "jud@palmira.test"}).json()
    pz = c.post("/api/r/personas", headers=H, json={"tipo_dni": "CC", "dni": "765201", "primer_nombre": "PEDRO", "primer_apellido": "PALMIRA",
                "correo_electronico": "pedro@palmira.test"}).json()["id_persona"]
    c.post("/api/r/afiliados", headers=H, json={"id_persona": pz, "fecha_afiliacion": "2025-01-01", "fecha_nacimiento": "1985-01-01",
           "nivel_educativo": "PROFESIONAL", "cargo_empresa": "PROFESIONAL", "id_estamento_pertenencia": 3})
    r = c.post("/api/r/afiliados_empresa", headers=H, json={"id_persona": pz, "id_empresa": alc["id_empresa"],
               "salario_base": "2800000", "fecha_ingreso_empresa": "2021-01-01"})
    check(r.status_code == 400 and "Junta Directiva Nacional (trabaja en el municipio de la sede nacional)" in r.json()["detail"],
          "quien trabaja en Palmira no queda en un comité: el sistema indica que pertenece a la Junta Nacional")
    pz2 = c.post("/api/r/personas", headers=H, json={"tipo_dni": "CC", "dni": "765202", "primer_nombre": "PAOLA", "primer_apellido": "PALMIRA",
                 "correo_electronico": "paola@palmira.test"}).json()["id_persona"]
    sz = c.post("/api/r/solicitudes_afiliacion", headers=H, json={"id_persona": pz2, "id_estamento": 1, "id_empresa": alc["id_empresa"],
                "fecha_ingreso_empresa": "2021-01-01", "salario_base": "2800000", "fecha_nacimiento": "1988-02-02", "nivel_educativo": "PROFESIONAL",
                "cargo_empresa": "PROFESIONAL", "medio": "VENTANILLA"}).json()
    check(exp(pz2, HCN).json()["grupo_nacional"] == "PALMIRA", "su solicitud va a la Junta Nacional, en el grupo Palmira")
    for cod in ("CEDULA", "FORMATO_AFILIACION"):
        d = subir(pz2, cod, HCN, ("d.pdf", pdf_real(cod))).json()
        c.post(f"/api/afiliacion/documentos/{d['id_documento']}/revisar", headers=HCN, json={"aceptar": True})
    r = c.post(f"/api/afiliaciones/{sz['id_solicitud_afiliacion']}/aprobar", headers=HSG, json={"acta": acta_jdn["radicado_alfanumerico"]})
    jn = {f["id_persona"]: f for f in vista("junta_nacional")}
    check(r.json()["estado"] == "APROBADA" and jn[pz2]["grupo"] == "PALMIRA (SEDE NACIONAL)" and jn[p_jor]["grupo"] == "DISPERSOS"
          and jn[pz2]["municipio_trabajo"] == "PALMIRA",
          "en la Junta Nacional, ARCADIO separa solo a Palmira (sede nacional) de los dispersos según el municipio donde trabajan")
    jm = vista("junta_nacional_municipios")
    check(any(f["grupo"].startswith("PALMIRA") and f["municipio"] == "PALMIRA" and f["afiliados"] >= 1 for f in jm),
          "conteo de afiliados de la Junta Nacional por municipio")

    print("Posesión con el registro del inspector y permisos sindicales")
    import psycopg as _pgh
    _hc = _pgh.connect(os.environ["DATABASE_URL"], autocommit=True)

    def habil(n):
        return _hc.execute("SELECT gobernanza.fn_sumar_dias_habiles(gestion_documental.fn_hoy(), %s)::text", (n,)).fetchone()[0]
    hoy = _hc.execute("SELECT gestion_documental.fn_hoy()::text").fetchone()[0]
    # --- Posesión: la junta designa con su acta y la posesión llega con el registro del inspector
    p_sg = afiliado_gob("760010", "SECRETARIA", est_and, sede_and["id_sede"])
    HSGA, _ = crear_usuario("sg.andalucia", "DIRECTIVO", p_sg)
    designar = lambda hh, **kw: c.post("/api/directivos/designaciones", headers=hh, json=kw)
    acta_and2 = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": est_and, "asunto": "Acta: elección de Secretaria General"}).json()
    r = designar(HAND, id_persona=p_sg, id_estamento=est_and, id_cargo=cargos["SGEN_REG"], tipo_nombramiento="ELECCION", acta=acta_and2["radicado_alfanumerico"])
    dz = r.json()
    check(r.status_code == 200 and dz["estado"] == "PENDIENTE" and "ESPERA EL REGISTRO" in dz["diagnostico"],
          "la junta designa a su Secretaria General con su acta: queda pendiente del registro del inspector")
    check(c.get("/api/permisos/juntas", headers=HSGA).json() == [], "mientras el inspector no la registra, no ejerce: no puede firmar permisos")
    r = designar(HAND, id_persona=p_x, id_estamento=est_and, id_cargo=cargos["SGEN_REG"], tipo_nombramiento="ELECCION", acta=acta_and2["radicado_alfanumerico"])
    check(r.status_code == 400 and "pendiente" in r.json()["detail"], "no hay dos designaciones pendientes para el mismo cargo")
    p_nuevo_and = afiliado_gob("760011", "NUEVO", est_and, sede_and["id_sede"])
    r = designar(HAND, id_persona=p_nuevo_and, id_estamento=est_and, id_cargo=cargos["PRES_REG"], tipo_nombramiento="ELECCION", acta=acta_and2["radicado_alfanumerico"])
    check(r.status_code == 400 and "lo ocupa" in r.json()["detail"], "para un cargo ocupado hay que indicar a quién reemplaza")
    ocup = c.get("/api/directivos/ocupante", headers=HAND, params={"id_estamento": est_and, "id_cargo": cargos["PRES_REG"]}).json()
    r = designar(HAND, id_persona=p_nuevo_and, id_estamento=est_and, id_cargo=cargos["PRES_REG"], tipo_nombramiento="ELECCION",
                 acta=acta_and2["radicado_alfanumerico"], id_directivo_saliente=ocup["id_directivo_estamento"])
    check(r.status_code == 200 and r.json()["sale"] == ocup["nombre"], "la designación indica a quién reemplaza (saldrá el día del registro)")
    r2 = c.post(f"/api/directivos/designaciones/{r.json()['id_designacion']}/anular", headers=HAND, json={"motivo": "La junta reconsideró la decisión"})
    check(r2.json()["estado"] == "ANULADA", "una designación pendiente se anula con motivo")
    r = designar(HLC, id_persona=p_nuevo_and, id_estamento=est_and, id_cargo=cargos["TES_REG"], tipo_nombramiento="ELECCION", acta=acta_and2["radicado_alfanumerico"])
    check(r.status_code in (400, 403), "otra junta no designa directivos de Andalucía (ni siquiera ve su acta)")
    acta_cali3 = c.post("/api/r/documentos", headers=H, json={"id_tipo_documento": 1, "id_estamento": 3, "asunto": "Acta: designaciones"}).json()
    r = c.post("/api/directivos/designaciones", headers=HLC, json={"id_persona": p_nuevo_and, "id_estamento": est_and, "id_cargo": cargos["TES_REG"],
               "id_acta": acta_cali3["id_documento"]})
    check(r.status_code == 403 and "ámbito" in r.json()["detail"], "y aunque use un acta suya, está fuera de su ámbito")
    r = c.post("/api/r/registros_inspector", headers=H, json={"id_estamento": est_and, "id_inspector": 1, "num_registro_inspector": "REG-2099-AND-99",
               "fecha_emision_registro": "2099-01-01T10:00:00-05:00"})
    check(r.status_code == 400 and "futura" in r.json()["detail"], "la fecha de emisión de un registro no puede ser futura")
    r = c.post("/api/r/registros_inspector", headers=H, json={"id_estamento": est_and, "id_inspector": 1, "num_registro_inspector": "REG-2026-AND-02",
               "fecha_emision_registro": hoy + "T00:00:00-05:00"})
    check(r.status_code == 201, "el inspector emite el registro de Andalucía que incluye a la nueva Secretaria")
    dz2 = next(f for f in vista("designaciones") if f["id_designacion"] == dz["id_designacion"])
    sg_dir = next(x for x in c.get("/api/r/directivos", headers=H, params={"f_id_persona": p_sg}).json()["filas"] if x["fecha_retiro"] is None)
    check(dz2["estado"] == "POSESIONADA" and str(dz2["fecha_posesion"]) == hoy and sg_dir["fecha_posesion_individual"] == hoy
          and sg_dir["origen_posesion"] == "REGISTRO" and sg_dir["fecha_inscripcion"] == hoy,
          "ARCADIO le da la posesión con la fecha del registro del inspector, no con una fecha escrita a mano")
    check([j["junta"] for j in c.get("/api/permisos/juntas", headers=HSGA).json()] == ["Subdirectiva Andalucía"],
          "ya registrada, ejerce: puede firmar permisos de su junta")
    r = c.put("/api/r/directivos/registro", headers=H, params={"id_directivo_estamento": sg_dir["id_directivo_estamento"]},
              json={"fecha_posesion_individual": "2026-01-01", "version": sg_dir["version"]})
    check(r.status_code == 400 and "registro del inspector" in r.json()["detail"], "esa fecha de posesión no se cambia a mano")
    ins = vista("inscripcion_directivos")
    check(any(f["diagnostico"].startswith("ALERTA ALTA: SIN REGISTRO") for f in ins)
          and any(f["id_persona"] == p_sg and f["diagnostico"] == "INSCRITO EN EL REGISTRO DEL INSPECTOR" for f in ins),
          "la vista de inscripción muestra quién no ejerce por falta de registro y quién está inscrito")

    # --- Permisos sindicales: Gobernación del Valle (sede central Cali, sede Andalucía)
    pedir = lambda hh, junta, personas, ini, fin=None, **kw: c.post("/api/permisos", headers=hh, json={
        "id_estamento": junta, "personas": personas, "finalidad": kw.pop("finalidad", "ACTIVIDAD_DIRECTIVA"),
        "descripcion": kw.pop("descripcion", "Reunión ordinaria de la junta para el plan de trabajo"), "fecha_inicio": ini, "fecha_fin": fin or ini, **kw})
    r = pedir(H, 3, [p_pand], habil(10))
    check(r.status_code == 403 and "Presidente o el Secretario General" in r.json()["detail"] and "720 de 2024" in r.json()["detail"],
          "solo el Presidente o el Secretario General que ejercen el cargo firman la solicitud (art. 2.2.2.5.4, Decreto 720 de 2024)")
    eleg = {f["id_persona"]: f for f in c.get("/api/permisos/elegibles", headers=HLC, params={"id_estamento": 3}).json()}
    check(eleg.get(p_x, {}).get("motivo_junta") == "SEDE CENTRAL" and eleg.get(p_pand, {}).get("motivo_junta") == "SEDE CENTRAL",
          "el Comité Cali puede pedir permisos para quienes trabajan en la Gobernación (sede central en Cali), aunque pertenezcan a otra junta")
    check(c.get("/api/permisos/elegibles", headers=HAND, params={"id_estamento": 3}).status_code == 403, "solo quien firma por esa junta ve esa lista")
    r = pedir(HLC, 3, [p_x, p_pand], habil(3))
    check(r.status_code == 400 and "8 días hábiles" in r.json()["detail"], "con delegados se pide con 8 días hábiles de antelación")
    r = pedir(HLC, 3, [p_pand], habil(3))
    check(r.status_code == 400 and "4 días hábiles" in r.json()["detail"], "si todos son directivos, con 4 días hábiles")
    r = pedir(HLC, 3, [p_pand], habil(3), excepcional=True, motivo_excepcional="Citación urgente del Ministerio del Trabajo")
    p_exc = r.json()
    check(r.status_code == 200 and p_exc["excepcional"] == "SÍ" and p_exc["consecutivo"].startswith("PS-"), "caso excepcional: con menos antelación y su motivo")
    r = pedir(HAND, est_and, [p_pand], habil(3))
    check(r.status_code == 400 and "ya tiene el permiso" in r.json()["detail"] and "Comité Seccional Cali" in r.json()["detail"],
          "un afiliado no tiene dos permisos que se crucen, aunque los pidan juntas distintas")
    r = pedir(HLC, 3, [p_x, p_pand], habil(10), habil(11), finalidad="CAPACITACION", descripcion="Seminario de carrera administrativa")
    pe = r.json()
    assert r.status_code == 200, r.text
    b = {x["id_persona"]: x for x in pe["beneficiarios"]}
    check(r.status_code == 200 and b[p_pand]["calidad"] == "DIRECTIVO" and b[p_x]["calidad"] == "DELEGADO"
          and b[p_x]["dias_solicitados"] == 2 and pe["empresa"] == "GOBERNACIÓN DEL VALLE DEL CAUCA" and pe["destinatario"] == "Nominador o autoridad competente",
          "solicitud para dos afiliados: calidad, días hábiles y dirigida a la sede central de la empresa")
    check(pe["limite_respuesta"] == habil(7), "la entidad debe notificar la respuesta al menos 3 días hábiles antes del inicio")
    r = pedir(HP, 2, [p_pand], habil(15))
    check(r.status_code == 400 and "no puede pedir permisos" in r.json()["detail"], "una junta sin relación con el afiliado no pide permisos para él")
    r = pedir(HP, 2, [p_x], habil(15), descripcion="Asamblea de la subdirectiva de Medellín", finalidad="ASAMBLEA")
    p_med = r.json()
    check(r.status_code == 200 and p_med["beneficiarios"][0]["motivo_junta"] == "PERTENENCIA", "la junta a la que pertenece sí los pide")
    r = pedir(HSG, 1, [p_pand], habil(20))
    p_jdn = r.json()
    check(r.status_code == 200 and p_jdn["beneficiarios"][0]["motivo_junta"] == "JUNTA NACIONAL", "la Junta Nacional los pide para cualquier afiliado")
    r = pedir(HSG, 1, [p_pand, pz2], habil(25))
    check(r.status_code == 400 and "misma empresa" in r.json()["detail"], "cada solicitud va a una sola empresa")
    carta = c.get(f"/api/permisos/{pe['id_permiso']}/carta.pdf", headers=HLC)
    check(carta.status_code == 200 and carta.content.startswith(b"%PDF") and len(carta.content) > 2000, "carta de solicitud en PDF")
    # Respuesta de la entidad
    responder = lambda hh, pid, decisiones, notif=None, **kw: c.post(f"/api/permisos/{pid}/respuesta", headers=hh, json={
        "acto": "RES-2026-0456", "fecha_acto": hoy, "fecha_notificacion": notif or hoy, "decisiones": decisiones, **kw})
    dec_ok = [{"id_persona": p_x, "decision": "NEGADO", "causal": "OTRA", "motivo": "No hay presupuesto para viáticos"},
              {"id_persona": p_pand, "decision": "LIMITADO", "dias_concedidos": 1, "causal": "PRESTACION_SERVICIO", "motivo": "Cierre contable"}]
    check(responder(HAND, pe["id_permiso"], dec_ok).status_code == 403, "la respuesta la registra la junta que lo pidió (o la Nacional)")
    r = responder(HLC, pe["id_permiso"], [dec_ok[0], {**dec_ok[1], "dias_concedidos": 2}])
    check(r.status_code == 400 and "limitado" in r.json()["detail"], "un permiso limitado concede menos días de los solicitados")
    r = responder(HLC, pe["id_permiso"], [dec_ok[0], {**dec_ok[1], "motivo": ""}])
    check(r.status_code == 400 and "motivo" in r.json()["detail"], "una negativa o limitación lleva el motivo de la entidad")
    r = responder(HLC, pe["id_permiso"], dec_ok)
    vp = next(f for f in vista("permisos") if f["id_permiso"] == pe["id_permiso"])
    check(r.status_code == 200 and r.json()["resultado"] == "RESPONDIDO" and vp["diagnostico"].startswith("ALERTA ALTA: NEGADO O LIMITADO POR UNA CAUSA DISTINTA"),
          "respuesta registrada: se alerta la negativa por una causa distinta de la afectación del servicio (única causal legal)")
    check(responder(HLC, pe["id_permiso"], dec_ok).status_code == 400, "un permiso respondido no se responde dos veces")
    # Silencio: sin respuesta notificada a tiempo, el permiso se entiende concedido
    if os.environ.get("SUPER_DATABASE_URL"):
        with _pgh.connect(os.environ["SUPER_DATABASE_URL"], autocommit=True) as sc:
            with sc.transaction():
                sc.execute("SELECT set_config('permiso.operacion', 'prueba', true)")
                sc.execute("UPDATE gobernanza.permiso_sindical SET limite_respuesta = gestion_documental.fn_hoy() - 1, fecha_solicitud = gestion_documental.fn_hoy() - 10 WHERE id_permiso = %s",
                           (p_exc["id_permiso"],))
        vp = next(f for f in vista("permisos") if f["id_permiso"] == p_exc["id_permiso"])
        check(vp["diagnostico"].startswith("CONCEDIDO POR SILENCIO") and vp["dias_concedidos"] == 1,
              "sin respuesta notificada a tiempo, se entiende concedido (silencio)")
        if os.environ.get("NOTIFICADOR_DATABASE_URL"):
            sim = c.post("/api/admin/notificaciones/ejecutar", headers=H, params={"simulacro": True}).json()
            check(any(v["tipo"] == "PERMISOS_SINDICALES" and p_exc["consecutivo"] in v["asunto"] and "silencio" in v["asunto"]
                      and v["para"] == "760003@valle.test" for v in sim["vista_previa"]),
                  "correo automático al Presidente del Comité Cali: el permiso quedó concedido por silencio")
        r = responder(HLC, p_exc["id_permiso"], [{"id_persona": p_pand, "decision": "NEGADO", "causal": "PRESTACION_SERVICIO", "motivo": "Visita de auditoría"}])
        bx = c.get(f"/api/permisos/{p_exc['id_permiso']}", headers=HLC).json()["beneficiarios"][0]
        check(r.json()["resultado"] == "EXTEMPORANEA" and bx["decision"] == "CONCEDIDO POR SILENCIO",
              "una negativa notificada después del plazo no cambia el silencio: queda concedido")
    # Anulación
    check(c.post(f"/api/permisos/{p_med['id_permiso']}/anular", headers=HAND, json={"motivo": "No corresponde a esta junta"}).status_code == 403,
          "otra junta no anula el permiso")
    check(c.post(f"/api/permisos/{p_med['id_permiso']}/anular", headers=HP, json={"motivo": "corto"}).status_code == 400, "anular exige motivo")
    check(c.post(f"/api/permisos/{p_med['id_permiso']}/anular", headers=HP, json={"motivo": "La asamblea se aplazó para el próximo mes"}).json()["estado"] == "ANULADO",
          "la junta que lo pidió lo anula antes de que empiece")
    r = pedir(HP, 2, [p_x], habil(15), descripcion="Asamblea de la subdirectiva de Medellín (nueva fecha)", finalidad="ASAMBLEA")
    check(r.status_code == 200, "un permiso anulado no impide pedir otro en las mismas fechas")
    # Días por afiliado
    dpa = next(f for f in vista("permisos_por_afiliado") if f["id_persona"] == p_pand)
    con_super = bool(os.environ.get("SUPER_DATABASE_URL"))
    check(dpa["dias_solicitados"] == 4 and dpa["dias_negados"] == 1 and dpa["dias_concedidos"] == (2 if con_super else 1)
          and dpa["dias_en_espera"] == (1 if con_super else 2),
          "días por afiliado: solicitados, concedidos (con el silencio), negados y en espera")
    check(c.get("/api/r/permisos_sindicales", headers=HAND).json()["total"] >= 1 and
          all(f["id_estamento_solicita"] in (3, est_and, 1) for f in c.get("/api/r/permisos_sindicales", headers=HAND, params={"tam": 100}).json()["filas"]),
          "Andalucía ve los permisos de sus afiliados aunque los haya pedido otra junta")

    print("Backups")
    if os.environ.get("BACKUP_DATABASE_URL"):
        r = c.post("/api/admin/backups", headers=H)
        check(r.status_code == 200 and r.json()["tamano_bytes"] > 0, "backup pg_dump con SHA-256")
        check(c.get(f"/api/admin/backups/{r.json()['archivo']}/verificar", headers=H).json()["integro"], "backup íntegro")
    c.post("/api/auth/logout", headers=H)
    check(c.get("/api/auth/yo", headers=H).status_code == 401, "logout revoca el token")

print(f"\nTODAS LAS PRUEBAS PASARON ({ok})")
