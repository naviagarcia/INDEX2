"""Extracción de texto de los documentos fuente: texto, PDF, Word, audio y video.

· PDF: texto del PDF (si es escaneado y no tiene texto, se avisa; no hay OCR).
· Word (.docx): párrafos y tablas.
· Audio y video: ffmpeg extrae el audio y faster-whisper lo transcribe EN EL SERVIDOR (nada sale a
  internet). Instalación:  pip install faster-whisper  y ffmpeg en el PATH. La primera vez descarga el
  modelo (TRANSCRIPCION_MODELO: tiny, base, small, medium o large-v3; más grande = más preciso y lento).
"""
from __future__ import annotations

import json
import subprocess
import tempfile
from pathlib import Path

from .config import config

EXT_TEXTO = {".txt", ".md", ".csv", ".srt", ".vtt", ".rtf", ".json", ".html", ".htm", ".eml"}
EXT_AUDIO = {".mp3", ".wav", ".m4a", ".ogg", ".oga", ".opus", ".flac", ".aac", ".amr", ".wma"}
EXT_VIDEO = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".3gp", ".mpeg", ".mpg", ".wmv", ".m4v"}


class ErrorExtraccion(Exception):
    pass


def clase_de(nombre: str) -> str:
    ext = Path(nombre or "").suffix.lower()
    if ext == ".pdf":
        return "PDF"
    if ext in (".docx",):
        return "WORD"
    if ext in EXT_AUDIO:
        return "AUDIO"
    if ext in EXT_VIDEO:
        return "VIDEO"
    if ext in EXT_TEXTO:
        return "TEXTO"
    if ext == ".doc":
        raise ErrorExtraccion("El formato .doc (Word antiguo) no se admite: guárdelo como .docx o PDF.")
    raise ErrorExtraccion(f"Formato no admitido ({ext or 'sin extensión'}). Use texto, PDF, Word (.docx), audio o video.")


def _texto_plano(ruta: Path) -> str:
    datos = ruta.read_bytes()
    for codificacion in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return datos.decode(codificacion)
        except UnicodeDecodeError:
            continue
    return datos.decode("utf-8", errors="replace")


def _pdf(ruta: Path) -> str:
    from pypdf import PdfReader
    try:
        lector = PdfReader(str(ruta))
        paginas = [(p.extract_text() or "").strip() for p in lector.pages]
    except Exception as e:  # noqa: BLE001
        raise ErrorExtraccion(f"No se pudo leer el PDF: {e}")
    texto = "\n\n".join(f"[Página {i}]\n{t}" for i, t in enumerate(paginas, 1) if t)
    if len(texto.strip()) < 20:
        raise ErrorExtraccion("El PDF no tiene texto (parece escaneado). Transcriba su contenido como fuente de texto "
                              "o adjunte una versión con texto.")
    return texto


def _word(ruta: Path) -> str:
    import docx
    try:
        d = docx.Document(str(ruta))
    except Exception as e:  # noqa: BLE001
        raise ErrorExtraccion(f"No se pudo leer el documento de Word: {e}")
    partes = [p.text for p in d.paragraphs if p.text.strip()]
    for t in d.tables:
        for fila in t.rows:
            partes.append(" | ".join(c.text.strip() for c in fila.cells))
    return "\n".join(partes)


def duracion(ruta: Path) -> int | None:
    try:
        r = subprocess.run([config.FFMPEG.replace("ffmpeg", "ffprobe"), "-v", "error", "-show_entries", "format=duration",
                            "-of", "json", str(ruta)], capture_output=True, timeout=60, check=False)
        return int(float(json.loads(r.stdout or b"{}")["format"]["duration"]))
    except Exception:  # noqa: BLE001
        return None


def _audio_wav(ruta: Path, destino: Path) -> None:
    try:
        r = subprocess.run([config.FFMPEG, "-y", "-v", "error", "-i", str(ruta), "-vn", "-ac", "1", "-ar", "16000", str(destino)],
                           capture_output=True, timeout=3600, check=False)
    except FileNotFoundError:
        raise ErrorExtraccion("No se encontró ffmpeg en el servidor (necesario para audio y video). Instálelo o indique su ruta en FFMPEG.")
    if r.returncode != 0:
        raise ErrorExtraccion("No se pudo extraer el audio: " + r.stderr.decode(errors="replace")[:300])


def _transcribir(ruta: Path, clase: str) -> str:
    if config.TRANSCRIPCION == "simulada":
        d = duracion(ruta)
        return f"[Transcripción simulada del {clase.lower()} {ruta.name}; duración {d if d is not None else '?'} s]"
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        raise ErrorExtraccion("La transcripción de audio y video no está instalada en el servidor: ejecute "
                              "'pip install faster-whisper' (y tenga ffmpeg). Mientras tanto, agregue la transcripción como texto.")
    with tempfile.TemporaryDirectory() as tmp:
        wav = Path(tmp) / "audio.wav"
        _audio_wav(ruta, wav)
        modelo = WhisperModel(config.TRANSCRIPCION_MODELO, device="auto", compute_type="int8")
        segmentos, _ = modelo.transcribe(str(wav), language="es", vad_filter=True)
        lineas = []
        for s in segmentos:
            m, seg = divmod(int(s.start), 60)
            lineas.append(f"[{m:02d}:{seg:02d}] {s.text.strip()}")
    if not lineas:
        raise ErrorExtraccion("No se reconoció voz en el archivo.")
    return "\n".join(lineas)


def extraer(ruta: Path, clase: str) -> tuple[str, int | None]:
    """Devuelve (texto, duración en segundos o None)."""
    if clase == "TEXTO":
        return _texto_plano(ruta), None
    if clase == "PDF":
        return _pdf(ruta), None
    if clase == "WORD":
        return _word(ruta), None
    if clase in ("AUDIO", "VIDEO"):
        return _transcribir(ruta, clase), duracion(ruta)
    raise ErrorExtraccion("Clase de fuente desconocida.")
