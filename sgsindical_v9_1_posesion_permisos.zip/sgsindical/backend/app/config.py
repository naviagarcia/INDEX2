"""Configuración central. Todo se lee de variables de entorno o del archivo .env."""
from __future__ import annotations

import os
import secrets
import sys
from pathlib import Path


def _base_dir() -> Path:
    # Cuando se empaqueta con PyInstaller los recursos quedan en sys._MEIPASS
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parent.parent


BASE_DIR = _base_dir()


def _cargar_env() -> None:
    """Carga un .env simple (CLAVE=valor) sin dependencias externas."""
    candidatos = [Path.cwd() / ".env", BASE_DIR / ".env", Path(sys.executable).parent / ".env"]
    for ruta in candidatos:
        if ruta.is_file():
            for linea in ruta.read_text(encoding="utf-8").splitlines():
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                clave, valor = linea.split("=", 1)
                os.environ.setdefault(clave.strip(), valor.strip().strip('"').strip("'"))
            break


_cargar_env()


def _bool(nombre: str, defecto: bool) -> bool:
    return os.environ.get(nombre, str(defecto)).lower() in ("1", "true", "si", "sí", "yes")


class Config:
    # Conexión del backend (usar el rol sgs_app, NUNCA un superusuario)
    DATABASE_URL: str = os.environ.get("DATABASE_URL", "postgresql://sgs_app:cambiar@localhost:5432/sgsindical")
    POOL_MIN: int = int(os.environ.get("POOL_MIN", "2"))
    POOL_MAX: int = int(os.environ.get("POOL_MAX", "20"))

    # Seguridad
    JWT_SECRET: str = os.environ.get("JWT_SECRET") or secrets.token_urlsafe(48)
    JWT_ALGORITMO: str = "HS256"
    SESION_HORAS: int = int(os.environ.get("SESION_HORAS", "8"))
    INACTIVIDAD_MINUTOS: int = int(os.environ.get("INACTIVIDAD_MINUTOS", "30"))
    MAX_INTENTOS_FALLIDOS: int = int(os.environ.get("MAX_INTENTOS_FALLIDOS", "5"))
    BLOQUEO_MINUTOS: int = int(os.environ.get("BLOQUEO_MINUTOS", "15"))
    CONTRASENA_MIN: int = int(os.environ.get("CONTRASENA_MIN", "10"))
    CONTRASENA_DIAS_VIGENCIA: int = int(os.environ.get("CONTRASENA_DIAS_VIGENCIA", "90"))
    PBKDF2_ITERACIONES: int = int(os.environ.get("PBKDF2_ITERACIONES", "390000"))
    CORS_ORIGINS: list[str] = [o for o in os.environ.get("CORS_ORIGINS", "").split(",") if o]

    # Archivos
    UPLOAD_DIR: Path = Path(os.environ.get("UPLOAD_DIR", str(Path.home() / "sgsindical_datos" / "documentos")))
    MAX_ARCHIVO_MB: int = int(os.environ.get("MAX_ARCHIVO_MB", "25"))

    # Claves de redes sociales: llave AES-256 en base64 (32 bytes), FUERA de la base de datos.
    # Genérela con:  python -m app.cli generar-llave   y guárdela también en un lugar seguro (sin ella
    # las claves no se pueden recuperar). Para cambiarla: ponga la nueva en SECRETOS_LLAVE, suba
    # SECRETOS_LLAVE_VERSION, deje la anterior en SECRETOS_LLAVE_ANTERIOR y ejecute "Rotar llave".
    SECRETOS_LLAVE: str = os.environ.get("SECRETOS_LLAVE", "")
    SECRETOS_LLAVE_VERSION: int = int(os.environ.get("SECRETOS_LLAVE_VERSION", "1"))
    SECRETOS_LLAVE_ANTERIOR: str = os.environ.get("SECRETOS_LLAVE_ANTERIOR", "")
    SEGUNDOS_CLAVE_VISIBLE: int = int(os.environ.get("SEGUNDOS_CLAVE_VISIBLE", "30"))

    # Escritos jurídicos con IA (Claude, de Anthropic). IA_PROVEEDOR: anthropic | simulado (pruebas, sin IA real)
    IA_PROVEEDOR: str = os.environ.get("IA_PROVEEDOR", "anthropic").lower()
    ANTHROPIC_API_KEY: str = os.environ.get("ANTHROPIC_API_KEY", "")
    IA_MODELO: str = os.environ.get("IA_MODELO", "claude-opus-5-5")
    IA_MAX_TOKENS: int = int(os.environ.get("IA_MAX_TOKENS", "8000"))
    IA_TIMEOUT_SEGUNDOS: int = int(os.environ.get("IA_TIMEOUT_SEGUNDOS", "300"))
    MAX_CARACTERES_FUENTES: int = int(os.environ.get("MAX_CARACTERES_FUENTES", "200000"))
    # Transcripción de audio y video: local (faster-whisper en el servidor) | simulada (pruebas)
    TRANSCRIPCION: str = os.environ.get("TRANSCRIPCION", "local").lower()
    TRANSCRIPCION_MODELO: str = os.environ.get("TRANSCRIPCION_MODELO", "small")
    FFMPEG: str = os.environ.get("FFMPEG", "ffmpeg")
    FUENTE_MAX_MB: int = int(os.environ.get("FUENTE_MAX_MB", "300"))

    # Backups (usar el rol sgs_backup)
    BACKUP_DIR: Path = Path(os.environ.get("BACKUP_DIR", str(Path.home() / "sgsindical_datos" / "backups")))
    BACKUP_DATABASE_URL: str = os.environ.get("BACKUP_DATABASE_URL", "")
    PG_DUMP: str = os.environ.get("PG_DUMP", "pg_dump")
    BACKUP_RETENCION_DIAS: int = int(os.environ.get("BACKUP_RETENCION_DIAS", "30"))

    # Correos automáticos (tarea programada con el rol sgs_notificador)
    NOTIFICADOR_DATABASE_URL: str = os.environ.get("NOTIFICADOR_DATABASE_URL", "")
    SMTP_HOST: str = os.environ.get("SMTP_HOST", "")
    SMTP_PORT: int = int(os.environ.get("SMTP_PORT", "587"))
    SMTP_SEGURIDAD: str = os.environ.get("SMTP_SEGURIDAD", "starttls").lower()   # starttls | ssl | ninguna
    SMTP_USUARIO: str = os.environ.get("SMTP_USUARIO", "")
    SMTP_CONTRASENA: str = os.environ.get("SMTP_CONTRASENA", "")
    CORREO_REMITENTE: str = os.environ.get("CORREO_REMITENTE", "")
    # El nombre oficial, la sigla y el NIT se guardan en la base (Administración → Datos institucionales).
    # SINDICATO_NOMBRE del .env solo se usa si la base no responde (p. ej. durante la instalación).
    SINDICATO_NOMBRE_RESPALDO: str = os.environ.get("SINDICATO_NOMBRE", "El Sindicato")
    APP_URL: str = os.environ.get("APP_URL", "")
    ZONA_HORARIA: str = os.environ.get("ZONA_HORARIA", "America/Bogota")
    MAX_CORREOS_POR_EJECUCION: int = int(os.environ.get("MAX_CORREOS_POR_EJECUCION", "500"))

    # Frontend compilado (React) que sirve el mismo backend
    FRONTEND_DIR: Path = Path(os.environ.get("FRONTEND_DIR", str(BASE_DIR / "frontend_dist")))
    MOSTRAR_DOCS_API: bool = _bool("MOSTRAR_DOCS_API", False)


    @property
    def SINDICATO_NOMBRE(self) -> str:
        return institucional().get("nombre_sindicato") or self.SINDICATO_NOMBRE_RESPALDO

    @property
    def SINDICATO_SIGLA(self) -> str:
        return institucional().get("sigla") or ""

    @property
    def SINDICATO_NIT(self) -> str:
        return institucional().get("nit") or ""


# ---------------------------------------------------------------- datos institucionales (se leen de la base)
_institucional: dict = {"datos": {}, "leido": 0.0}


def institucional(forzar: bool = False) -> dict:
    """Nombre, sigla y NIT del sindicato, leídos de gobernanza.dato_institucional (se refrescan cada 10 segundos)."""
    import time
    if forzar or time.monotonic() - _institucional["leido"] > 10:
        try:
            from . import db
            if db.pool is not None:
                with db.pool.connection() as conn:
                    fijar_institucional(conn.execute("SELECT gobernanza.fn_datos_institucionales() AS d").fetchone()["d"])
        except Exception:  # noqa: BLE001 - sin base disponible se usa el último valor leído o el del .env
            _institucional["leido"] = time.monotonic()
    return _institucional["datos"]


def fijar_institucional(datos: dict | None) -> None:
    import time
    _institucional["datos"] = dict(datos or {})
    _institucional["leido"] = time.monotonic()


config = Config()
