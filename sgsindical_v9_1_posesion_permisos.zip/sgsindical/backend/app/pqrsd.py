"""PQRSD recibidas por el sindicato (Ley 1755 de 2015).

Las reglas viven en la base de datos (db/10_pqrsd.sql): plazos en días hábiles con corte a las 5 p. m.,
prórroga hasta el doble, solicitud incompleta y desistimiento tácito, traslado, revisión jurídica de las
denuncias, quién firma y la historia inmutable. Aquí se exponen esas acciones, se avisa al peticionario
por correo y se genera la respuesta en PDF."""
from __future__ import annotations

import io
import logging
from datetime import date, datetime
from typing import Any
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from fastapi.responses import Response

from .config import config
from .crud import serializar
from .db import transaccion
from .notificaciones import fecha_larga
from .seguridad import UsuarioActual, requiere

log = logging.getLogger("sgsindical.pqrsd")
router = APIRouter(prefix="/api/pqrsd", tags=["pqrsd"])

ESTADOS_ABIERTOS = ("RADICADA", "EN_TRAMITE", "EN_REQUERIMIENTO")


def _f(v) -> str:
    """Fecha para el peticionario: «martes, 6 de octubre de 2026»."""
    if v is None:
        return "—"
    if isinstance(v, str):
        v = date.fromisoformat(v[:10])
    if isinstance(v, datetime):
        v = v.astimezone(ZoneInfo(config.ZONA_HORARIA)).date()
    return fecha_larga(v)


def _cargar(conn, id_pqrsd: int) -> dict:
    q = conn.execute("""SELECT p.*, t.nombre AS nombre_tipo, t.revision_juridica, t.silencio_positivo, e.nombre_estamento AS junta,
                               o.nombre_estamento AS junta_origen
                          FROM gestion_documental.pqrsd p
                          JOIN gestion_documental.tipo_pqrsd t ON t.codigo = p.tipo
                          JOIN gobernanza.estamento e ON e.id_estamento = p.id_estamento
                          LEFT JOIN gobernanza.estamento o ON o.id_estamento = p.id_estamento_origen
                         WHERE p.id_pqrsd = %s""", (id_pqrsd,)).fetchone()
    if not q:
        raise HTTPException(404, "La PQRSD no existe o está fuera de su ámbito territorial.")
    return q


# ---------------------------------------------------------------- correo al peticionario
def _enviar_peticionario(usuario: UsuarioActual, q: dict, asunto: str, parrafos: list[str],
                         adjunto: tuple[str, bytes] | None = None, copia: list[str] | None = None) -> dict:
    """Envía el correo y deja constancia en la historia de la PQRSD. Si no hay servidor de correo, lo dice."""
    if q.get("anonima") or not q.get("correo_peticionario"):
        return {"enviado": False, "aviso": "La PQRSD no tiene correo del peticionario."}
    enviado, detalle = False, ""
    if not (config.SMTP_HOST and config.CORREO_REMITENTE):
        detalle = "No hay servidor de correo configurado: comunique la actuación al peticionario por otro medio y anótelo."
    else:
        try:
            from . import notificaciones as n
            correo = n.Correo("PQRSD", f"pqrsd:{q['id_pqrsd']}:{asunto}", q["correo_peticionario"],
                              (q.get("nombre_peticionario") or "").title(), asunto, parrafos, copia=copia or [])
            m = correo.mensaje()
            if adjunto:
                m.add_attachment(adjunto[1], maintype="application", subtype="pdf", filename=adjunto[0])
            with n._smtp() as s:
                s.send_message(m)
            enviado = True
        except Exception:  # noqa: BLE001
            log.exception("No se pudo enviar el correo de la PQRSD %s", q.get("radicado"))
            detalle = "El servidor de correo rechazó el envío; reintente o comuníquelo por otro medio."
    with transaccion(usuario) as conn:
        conn.execute("SELECT gestion_documental.fn_pqrsd_registrar_correo(%s, %s, %s)",
                     (q["id_pqrsd"], enviado, f"«{asunto}» a {q['correo_peticionario']}"
                      + (f" (copia: {', '.join(copia)})" if copia else "") + ("" if enviado else f". {detalle}")))
    return {"enviado": enviado, "aviso": None if enviado else detalle}


def _saludo_radicado(q: dict) -> str:
    return f"Radicado {q['radicado']} — {q['nombre_tipo']}: «{q['asunto']}»."


# ---------------------------------------------------------------- respuesta en PDF
def pdf_respuesta(q: dict) -> bytes:
    from xml.sax.saxutils import escape as e

    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
    from reportlab.lib.pagesizes import LETTER
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer

    est = getSampleStyleSheet()
    normal = ParagraphStyle("n", parent=est["Normal"], fontName="Helvetica", fontSize=11, leading=16, alignment=TA_JUSTIFY)
    titulo = ParagraphStyle("t", parent=normal, fontName="Helvetica-Bold", fontSize=13, leading=18, alignment=TA_CENTER)
    peq = ParagraphStyle("p", parent=normal, fontSize=8.5, leading=12, alignment=TA_LEFT, textColor=colors.HexColor("#444444"))
    fecha = q["fecha_respuesta"]
    h = [Paragraph(e(config.SINDICATO_NOMBRE.upper()), titulo), Paragraph(e(q["junta"]), ParagraphStyle("c", parent=normal, alignment=TA_CENTER)),
         Spacer(1, 18),
         Paragraph(f"{e(_f(fecha))}", normal), Spacer(1, 10),
         Paragraph(f"Señor(a)<br/><b>{e((q.get('nombre_peticionario') or '').title())}</b><br/>{e(q.get('correo_peticionario') or '')}", normal),
         Spacer(1, 10),
         Paragraph(f"<b>Asunto:</b> respuesta a su {e(q['nombre_tipo'].lower())} radicada con el número <b>{e(q['radicado'])}</b> "
                   f"el {e(_f(q['fecha_recepcion']))} — «{e(q['asunto'])}».", normal), Spacer(1, 12)]
    for parrafo in str(q["respuesta"]).split("\n"):
        if parrafo.strip():
            h += [Paragraph(e(parrafo.strip()), normal), Spacer(1, 6)]
    h += [Spacer(1, 30), Paragraph("Cordialmente,", normal), Spacer(1, 26),
          Paragraph(f"<b>{e(q.get('nombre_firmante') or q.get('usuario_respuesta') or '')}</b><br/>{e(q.get('cargo_firma') or '')}", normal),
          Spacer(1, 30),
          Paragraph(f"Respuesta generada y firmada en SGSINDICAL el {e(_f(fecha))}. Huella SHA-256: {e(q.get('huella_respuesta') or '')}", peq),
          Paragraph("Con esta respuesta se resuelve de fondo su solicitud (Ley 1755 de 2015). Sus datos personales se tratan según la "
                    "política de tratamiento del sindicato (Ley 1581 de 2012).", peq)]
    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=LETTER, leftMargin=2.5 * cm, rightMargin=2.5 * cm, topMargin=2.2 * cm, bottomMargin=2 * cm,
                      title=f"Respuesta {q['radicado']}", author=config.SINDICATO_NOMBRE).build(h)
    return buf.getvalue()


def _con_firmante(conn, q: dict) -> dict:
    f = conn.execute("""SELECT u.nombre_completo FROM seguridad.usuario u WHERE u.nombre_usuario = %s""",
                     (q.get("usuario_respuesta"),)).fetchone()
    return {**q, "nombre_firmante": f["nombre_completo"] if f else None}


# ---------------------------------------------------------------- consultas
@router.get("/tipos")
def tipos(usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        return serializar(conn.execute("SELECT * FROM gestion_documental.tipo_pqrsd ORDER BY dias_habiles, nombre").fetchall())


@router.get("/simular")
def simular(tipo: str, recepcion: str | None = None, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    """Cuándo vencería una PQRSD de ese tipo recibida en ese momento (para mostrarlo al registrar)."""
    with transaccion(usuario) as conn:
        f = conn.execute("SELECT * FROM gestion_documental.fn_pqrsd_simular_plazo(%s, %s::timestamptz)",
                         (tipo, recepcion or None)).fetchone()
    if not f:
        raise HTTPException(404, "Tipo de PQRSD desconocido.")
    return serializar(f)


@router.get("")
def listar(estado: str | None = None, tipo: str | None = None, id_estamento: int | None = None, alerta: str | None = None,
           texto: str | None = None, abiertas: bool = False, limite: int = Query(200, le=1000),
           usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    cond, args = [], []
    if estado:
        cond.append("v.estado = %s"); args.append(estado)
    if abiertas:
        cond.append("v.estado = ANY(%s)"); args.append(list(ESTADOS_ABIERTOS))
    if tipo:
        cond.append("v.codigo_tipo = %s"); args.append(tipo)
    if id_estamento:
        cond.append("v.id_estamento = %s"); args.append(id_estamento)
    if alerta:
        cond.append("v.nivel_alerta = ANY(%s)"); args.append(["VENCIDA", "VENCE_HOY"] if alerta == "VENCIDA" else [alerta])
    if texto:
        cond.append("(v.radicado ILIKE %s OR v.asunto ILIKE %s OR v.peticionario ILIKE %s)"); args += [f"%{texto}%"] * 3
    sql = ("SELECT v.* FROM gestion_documental.v_auditoria_pqrsd v" + (" WHERE " + " AND ".join(cond) if cond else "")
           + " ORDER BY (v.estado = ANY(%s)) DESC, v.fecha_limite, v.recibida DESC LIMIT %s")
    with transaccion(usuario) as conn:
        filas = conn.execute(sql, (*args, list(ESTADOS_ABIERTOS), limite)).fetchall()
        conn.execute("SELECT seguridad.fn_registrar_acceso_dato('LISTADO', 'pqrsd', NULL, NULL, %s, NULL)", (len(filas),))
        resumen = conn.execute("""SELECT count(*) FILTER (WHERE estado IN ('RADICADA', 'EN_TRAMITE', 'EN_REQUERIMIENTO')) AS abiertas,
                                         count(*) FILTER (WHERE nivel_alerta IN ('VENCIDA', 'VENCE_HOY')) AS vencidas,
                                         count(*) FILTER (WHERE nivel_alerta = 'ALTA') AS alta,
                                         count(*) FILTER (WHERE nivel_alerta = 'MEDIA') AS media,
                                         count(*) FILTER (WHERE estado = 'EN_REQUERIMIENTO') AS suspendidas
                                    FROM gestion_documental.v_auditoria_pqrsd""").fetchone()
    return {"filas": serializar(filas), "resumen": resumen}


@router.get("/{id_pqrsd}")
def ficha(id_pqrsd: int, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        q = _cargar(conn, id_pqrsd)
        v = conn.execute("SELECT diagnostico, nivel_alerta, dias_habiles_restantes, porcentaje_consumido FROM gestion_documental.v_auditoria_pqrsd WHERE id_pqrsd = %s",
                         (id_pqrsd,)).fetchone()
        historia = conn.execute("""SELECT fecha, tipo, detalle, usuario FROM gestion_documental.pqrsd_actuacion
                                    WHERE id_pqrsd = %s ORDER BY fecha, id_actuacion""", (id_pqrsd,)).fetchall()
        puede = conn.execute("""SELECT gestion_documental.fn_pqrsd_autorizado(%s) AS decidir,
                                       gestion_documental.fn_pqrsd_es_juridico(%s) AS concepto,
                                       seguridad.fn_rol_actual() = 'VENTANILLA' AS ventanilla,
                                       gobernanza.fn_dias_habiles_entre(%s, gestion_documental.fn_hoy()) AS dias_desde_radicacion,
                                       gestion_documental.fn_pqrsd_limite_recurso(%s) AS limite_recurso,
                                       gestion_documental.fn_hoy() AS hoy""",
                             (q["id_estamento"], q["id_estamento"], q["fecha_base"], id_pqrsd)).fetchone()
        param = {r["codigo"]: r["valor"] for r in conn.execute("SELECT codigo, valor FROM gestion_documental.parametro_pqrsd").fetchall()}
        conn.execute("SELECT seguridad.fn_registrar_acceso_dato('FICHA', 'pqrsd', %s, NULL, 1, %s)", (q.get("id_persona"), q["radicado"]))
    abierta = q["estado"] in ESTADOS_ABIERTOS
    acciones = {
        "tramite": abierta and q["estado"] == "RADICADA" and (puede["decidir"] or puede["ventanilla"]),
        "prorrogar": abierta and puede["decidir"] and q["estado"] != "EN_REQUERIMIENTO" and q["dias_prorroga"] == 0,
        "pedir_completar": abierta and puede["decidir"] and q["estado"] != "EN_REQUERIMIENTO" and q["fecha_requerimiento"] is None
                           and puede["dias_desde_radicacion"] <= int(param.get("DIAS_PEDIR_COMPLETAR", 10)),
        "pedir_aclaracion": abierta and puede["decidir"] and q["estado"] != "EN_REQUERIMIENTO" and q["fecha_requerimiento"] is None
                            and q["dias_prorroga"] == 0,
        "ampliar_completar": q["estado"] == "EN_REQUERIMIENTO" and puede["decidir"] and not q["prorroga_completar"]
                             and q.get("tipo_requerimiento") != "ACLARAR",
        "completada": q["estado"] == "EN_REQUERIMIENTO" and (puede["decidir"] or puede["ventanilla"]),
        "desistimiento": q["estado"] == "EN_REQUERIMIENTO" and puede["decidir"],
        "trasladar": abierta and puede["decidir"] and q["estado"] != "EN_REQUERIMIENTO",
        "concepto": abierta and puede["concepto"],
        "responder": abierta and puede["decidir"] and q["estado"] != "EN_REQUERIMIENTO"
                     and (not q["revision_juridica"] or q["concepto_juridico"] is not None),
        "recurso": q["estado"] == "DESISTIDA" and q.get("tipo_requerimiento") == "COMPLETAR" and q.get("fecha_recurso") is None
                   and puede["limite_recurso"] is not None and puede["hoy"] <= puede["limite_recurso"]
                   and (puede["decidir"] or puede["ventanilla"]),
        "decidir_recurso": q["estado"] == "DESISTIDA" and q.get("fecha_recurso") is not None and q.get("decision_recurso") is None
                           and puede["decidir"],
        "nota": usuario.codigo_rol not in ("CONSULTA", "AFILIADO"),
    }
    q["limite_recurso"] = puede["limite_recurso"]
    return {"pqrsd": serializar(q), "plazo": serializar(v), "historia": serializar(historia), "acciones": acciones,
            "parametros": serializar(param)}


# ---------------------------------------------------------------- registrar
@router.post("")
def registrar(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "registrar"))):
    campos = ["tipo", "id_estamento", "anonima", "nombre_peticionario", "tipo_documento", "numero_documento", "correo_peticionario",
              "telefono_peticionario", "id_persona", "asunto", "descripcion", "fecha_recepcion", "motivo_registro_tardio",
              "id_documento_soporte"]
    valores = {c: (datos.get(c) if datos.get(c) not in ("",) else None) for c in campos}
    valores["anonima"] = bool(valores.get("anonima"))
    if not valores.get("tipo") or not valores.get("id_estamento") or not valores.get("asunto"):
        raise HTTPException(400, "Indique el tipo, la junta que la recibe y el asunto.")
    if valores["fecha_recepcion"] is None:
        valores.pop("fecha_recepcion")
    cols = list(valores)
    with transaccion(usuario) as conn:
        f = conn.execute(f"INSERT INTO gestion_documental.pqrsd ({', '.join(cols)}) VALUES ({', '.join(['%s'] * len(cols))}) RETURNING id_pqrsd",
                         [valores[c] for c in cols]).fetchone()
        q = _cargar(conn, f["id_pqrsd"])
    correo = {"enviado": False, "aviso": None}
    if not q["anonima"]:
        correo = _enviar_peticionario(usuario, q, f"Recibimos su {q['nombre_tipo'].lower()} — radicado {q['radicado']}", [
            f"{config.SINDICATO_NOMBRE} recibió su {q['nombre_tipo'].lower()} el {_f(q['fecha_recepcion'])}. {_saludo_radicado(q)}",
            f"La atiende {q['junta']}. El plazo para responderle es de {q['plazo_dias']} días hábiles: a más tardar el {_f(q['fecha_limite'])}.",
            "Conserve el número de radicado para cualquier consulta. Puede responder a este correo para aportar información adicional.",
            "Los plazos se cuentan en días hábiles; lo recibido a partir de las 5:00 p. m. o en día no hábil se entiende recibido el día hábil siguiente."
            + (f" Reglamento de PQRSD: {config.APP_URL.rstrip('/')}/#/legal/reglamento-pqrsd" if config.APP_URL else "")])
    return {"id_pqrsd": q["id_pqrsd"], "radicado": q["radicado"], "estado": q["estado"], "fecha_limite": serializar(q["fecha_limite"]),
            "correo": correo,
            "aviso": "Anónima: queda registrada y archivada sin trámite (decisión de la Junta)." if q["anonima"] else None}


@router.put("/{id_pqrsd}")
def actualizar(id_pqrsd: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "registrar"))):
    """Solo los datos que se pueden completar después: teléfono, persona vinculada y soporte."""
    permitidos = [c for c in ("telefono_peticionario", "id_persona", "id_documento_soporte") if c in datos]
    if not permitidos:
        raise HTTPException(400, "Solo se pueden cambiar el teléfono, la persona vinculada y el soporte.")
    with transaccion(usuario) as conn:
        r = conn.execute(f"UPDATE gestion_documental.pqrsd SET {', '.join(f'{c} = %s' for c in permitidos)} WHERE id_pqrsd = %s RETURNING id_pqrsd",
                         [datos[c] or None for c in permitidos] + [id_pqrsd]).fetchone()
    if not r:
        raise HTTPException(404, "La PQRSD no existe o está fuera de su ámbito territorial.")
    return {"actualizada": True}


# ---------------------------------------------------------------- acciones
@router.post("/{id_pqrsd}/tramite")
def en_tramite(id_pqrsd: int, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gestion_documental.fn_pqrsd_en_tramite(%s)", (id_pqrsd,))
    return {"estado": "EN_TRAMITE"}


@router.post("/{id_pqrsd}/prorrogar")
def prorrogar(id_pqrsd: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        nueva = conn.execute("SELECT gestion_documental.fn_pqrsd_prorrogar(%s, %s, %s) AS f",
                             (id_pqrsd, datos.get("dias"), datos.get("motivo"))).fetchone()["f"]
        q = _cargar(conn, id_pqrsd)
    correo = _enviar_peticionario(usuario, q, f"Ampliación del plazo de respuesta — radicado {q['radicado']}", [
        _saludo_radicado(q),
        f"Le informamos que no es posible responderle dentro del plazo inicial por la siguiente razón: {q['motivo_prorroga']}",
        f"Le daremos respuesta a más tardar el {_f(nueva)} (Ley 1755 de 2015, artículo 14, parágrafo)."])
    return {"fecha_limite": serializar(nueva), "correo": correo}


@router.post("/{id_pqrsd}/pedir-completar")
def pedir_completar(id_pqrsd: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        hasta = conn.execute("SELECT gestion_documental.fn_pqrsd_pedir_completar(%s, %s) AS f", (id_pqrsd, datos.get("texto"))).fetchone()["f"]
        q = _cargar(conn, id_pqrsd)
    correo = _enviar_peticionario(usuario, q, f"Su solicitud está incompleta — radicado {q['radicado']}", [
        _saludo_radicado(q),
        f"Para poder resolverla necesitamos lo siguiente: {q['texto_requerimiento']}",
        f"Tiene plazo hasta el {_f(hasta)} para enviarlo respondiendo a este correo; si necesita más tiempo, pídalo antes de esa fecha "
        "y se le puede ampliar por un mes más. Mientras tanto, el plazo para responderle queda suspendido.",
        "Si no recibimos la información a tiempo, se entenderá que desistió de la solicitud y se archivará; podrá presentarla de nuevo "
        "(Ley 1755 de 2015, artículo 17)."])
    return {"fecha_limite_completar": serializar(hasta), "correo": correo}


@router.post("/{id_pqrsd}/ampliar-completar")
def ampliar_completar(id_pqrsd: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        hasta = conn.execute("SELECT gestion_documental.fn_pqrsd_prorrogar_completar(%s, %s) AS f", (id_pqrsd, datos.get("motivo"))).fetchone()["f"]
        q = _cargar(conn, id_pqrsd)
    correo = _enviar_peticionario(usuario, q, f"Le ampliamos el plazo para completar — radicado {q['radicado']}", [
        _saludo_radicado(q), f"Atendiendo su solicitud, tiene hasta el {_f(hasta)} para enviarnos la información pendiente."])
    return {"fecha_limite_completar": serializar(hasta), "correo": correo}


@router.post("/{id_pqrsd}/completada")
def completada(id_pqrsd: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        nueva = conn.execute("SELECT gestion_documental.fn_pqrsd_completada(%s, %s, %s::timestamptz) AS f",
                             (id_pqrsd, datos.get("detalle"), datos.get("recibida_en") or None)).fetchone()["f"]
        q = _cargar(conn, id_pqrsd)
    correo = _enviar_peticionario(usuario, q, f"Recibimos la información que faltaba — radicado {q['radicado']}", [
        _saludo_radicado(q), f"Con la información recibida continuamos el trámite. Le responderemos a más tardar el {_f(nueva)}."])
    return {"fecha_limite": serializar(nueva), "correo": correo}


@router.post("/{id_pqrsd}/desistimiento")
def desistimiento(id_pqrsd: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gestion_documental.fn_pqrsd_desistimiento(%s, %s)", (id_pqrsd, datos.get("motivo")))
        q = _cargar(conn, id_pqrsd)
        limite = conn.execute("SELECT gestion_documental.fn_pqrsd_limite_recurso(%s) AS f", (id_pqrsd,)).fetchone()["f"]
    if q.get("tipo_requerimiento") == "ACLARAR":
        correo = _enviar_peticionario(usuario, q, f"Archivo de su petición por falta de aclaración — radicado {q['radicado']}", [
            _saludo_radicado(q),
            f"El {_f(q['fecha_requerimiento'])} le pedimos aclarar su petición porque no fue posible comprender su objeto, y el plazo "
            f"venció el {_f(q['fecha_limite_completar'])} sin recibir la aclaración. Por eso se archiva (Ley 1755 de 2015, artículo 19).",
            f"Decisión: {q['observacion_cierre']}",
            "Puede presentar de nuevo la petición, con claridad sobre lo que solicita, cuando lo desee."])
    else:
        correo = _enviar_peticionario(usuario, q, f"Archivo de su solicitud por desistimiento — radicado {q['radicado']}", [
            _saludo_radicado(q),
            f"El {_f(q['fecha_requerimiento'])} le pedimos completar su solicitud y el plazo venció el {_f(q['fecha_limite_completar'])} "
            "sin recibir la información. Por eso se entiende que desistió y se archiva (Ley 1755 de 2015, artículo 17).",
            f"Decisión: {q['observacion_cierre']}",
            f"Contra esta decisión procede el recurso de reposición, que puede presentar respondiendo a este correo a más tardar el {_f(limite)}. "
            "También puede presentar de nuevo la solicitud, completa, cuando lo desee."])
    return {"estado": q["estado"], "correo": correo}


@router.post("/{id_pqrsd}/pedir-aclaracion")
def pedir_aclaracion(id_pqrsd: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        hasta = conn.execute("SELECT gestion_documental.fn_pqrsd_pedir_aclaracion(%s, %s) AS f", (id_pqrsd, datos.get("texto"))).fetchone()["f"]
        q = _cargar(conn, id_pqrsd)
    correo = _enviar_peticionario(usuario, q, f"Necesitamos que aclare su petición — radicado {q['radicado']}", [
        _saludo_radicado(q),
        f"No nos fue posible comprender el objeto de su petición. Por favor aclárela: {q['texto_requerimiento']}",
        f"Tiene plazo hasta el {_f(hasta)} para enviar la aclaración respondiendo a este correo. Mientras tanto el plazo para responderle "
        "queda suspendido y, cuando la recibamos, se reanuda. Si no la recibimos a tiempo, la petición se archivará (Ley 1755 de 2015, artículo 19)."])
    return {"fecha_limite_completar": serializar(hasta), "correo": correo}


@router.post("/{id_pqrsd}/recurso")
def recurso(id_pqrsd: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gestion_documental.fn_pqrsd_recurso(%s, %s, %s::timestamptz)",
                     (id_pqrsd, datos.get("texto"), datos.get("recibido_en") or None))
        q = _cargar(conn, id_pqrsd)
    correo = _enviar_peticionario(usuario, q, f"Recibimos su recurso de reposición — radicado {q['radicado']}", [
        _saludo_radicado(q), "Recibimos su recurso de reposición contra el archivo de su solicitud por desistimiento. "
        "La junta lo decidirá y le comunicaremos la decisión por este medio."])
    return {"estado": q["estado"], "correo": correo}


@router.post("/{id_pqrsd}/decidir-recurso")
def decidir_recurso(id_pqrsd: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    revoca = datos.get("decision") == "REVOCA"
    with transaccion(usuario) as conn:
        nueva = conn.execute("SELECT gestion_documental.fn_pqrsd_decidir_recurso(%s, %s, %s) AS f",
                             (id_pqrsd, revoca, datos.get("motivo"))).fetchone()["f"]
        q = _cargar(conn, id_pqrsd)
    parrafos = [_saludo_radicado(q)]
    if revoca:
        parrafos += [f"Su recurso de reposición prosperó: se revoca el archivo y continuamos el trámite. Le responderemos a más tardar el {_f(nueva)}.",
                     f"Motivo: {q['motivo_decision_recurso']}"]
    else:
        parrafos += ["Su recurso de reposición no prosperó: se confirma el archivo de la solicitud por desistimiento.",
                     f"Motivo: {q['motivo_decision_recurso']}", "Puede presentar de nuevo la solicitud, completa, cuando lo desee."]
    correo = _enviar_peticionario(usuario, q, f"Decisión de su recurso de reposición — radicado {q['radicado']}", parrafos)
    return {"estado": q["estado"], "fecha_limite": serializar(nueva), "correo": correo}


@router.post("/{id_pqrsd}/trasladar")
def trasladar(id_pqrsd: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    correo_entidad = (datos.get("correo_entidad") or "").strip() or None
    with transaccion(usuario) as conn:
        clase = conn.execute("SELECT gestion_documental.fn_pqrsd_trasladar(%s, %s, %s, %s) AS c",
                             (id_pqrsd, datos.get("id_estamento") or None, datos.get("entidad") or None, datos.get("motivo"))).fetchone()["c"]
        # Tras un traslado interno la PQRSD puede quedar fuera del ámbito de quien la trasladó
        q = conn.execute("""SELECT p.*, t.nombre AS nombre_tipo, e.nombre_estamento AS junta
                              FROM gestion_documental.fn_pqrsd_resumen_traslado(%s) p
                              JOIN gestion_documental.tipo_pqrsd t ON t.codigo = p.tipo
                              JOIN gobernanza.estamento e ON e.id_estamento = p.id_estamento""", (id_pqrsd,)).fetchone()
    if clase == "INTERNO":
        correo = _enviar_peticionario(usuario, q, f"Su solicitud fue trasladada — radicado {q['radicado']}", [
            _saludo_radicado(q),
            f"Por competencia, su solicitud fue trasladada a {q['junta']} del sindicato, que le responderá "
            f"a más tardar el {_f(q['fecha_limite'])} (Ley 1755 de 2015, artículo 21)."])
    else:
        correo = _enviar_peticionario(usuario, q, f"Su solicitud fue trasladada — radicado {q['radicado']}", [
            _saludo_radicado(q),
            f"El asunto que plantea no es de competencia del sindicato. Por eso trasladamos su solicitud a {q['entidad_traslado']}, "
            "que deberá responderle; este correo es la copia del traslado (Ley 1755 de 2015, artículo 21).",
            f"Motivo: {q['observacion_cierre']}"], copia=[correo_entidad] if correo_entidad else None)
    return {"traslado": clase, "correo": correo}


@router.post("/{id_pqrsd}/concepto")
def concepto(id_pqrsd: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gestion_documental.fn_pqrsd_concepto(%s, %s)", (id_pqrsd, datos.get("concepto")))
    return {"registrado": True}


@router.post("/{id_pqrsd}/responder")
def responder(id_pqrsd: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        huella = conn.execute("SELECT gestion_documental.fn_pqrsd_responder(%s, %s, %s) AS h",
                              (id_pqrsd, datos.get("respuesta"), datos.get("id_documento") or None)).fetchone()["h"]
        q = _con_firmante(conn, _cargar(conn, id_pqrsd))
    pdf = pdf_respuesta(q)
    correo = _enviar_peticionario(usuario, q, f"Respuesta a su {q['nombre_tipo'].lower()} — radicado {q['radicado']}", [
        _saludo_radicado(q), "Adjuntamos la respuesta firmada a su solicitud.", q["respuesta"]],
        adjunto=(f"respuesta_{q['radicado']}.pdf", pdf))
    return {"estado": "RESPONDIDA", "huella": huella, "correo": correo}


@router.get("/{id_pqrsd}/respuesta.pdf")
def respuesta_pdf(id_pqrsd: int, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        q = _cargar(conn, id_pqrsd)
        if q["estado"] != "RESPONDIDA":
            raise HTTPException(409, "La PQRSD todavía no tiene respuesta.")
        q = _con_firmante(conn, q)
    return Response(pdf_respuesta(q), media_type="application/pdf", headers={
        "Content-Disposition": f'attachment; filename="respuesta_{q["radicado"]}.pdf"', "Cache-Control": "no-store"})


@router.post("/{id_pqrsd}/nota")
def nota(id_pqrsd: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gestion_documental.fn_pqrsd_nota(%s, %s)", (id_pqrsd, datos.get("nota")))
    return {"registrada": True}
