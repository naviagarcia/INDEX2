"""Expediente documental de afiliación, afiliados dispersos y datos institucionales (db/16).

Los permisos los decide la base de datos (gobernanza.fn_permiso_expediente): la persona ve y carga lo suyo
desde el portal; Ventanilla carga; el Presidente y el Secretario General de la junta revisan y deciden;
Vicepresidente, Tesorero y Fiscal consultan; los demás solo ven el estado. Cada apertura de un archivo queda
en la bitácora de accesos. Las fotos se convierten a un solo PDF; cada archivo guarda su huella SHA-256."""
from __future__ import annotations

import hashlib
import io
import os
import re
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Body, Depends, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse

from .config import config, institucional
from .crud import serializar
from .db import transaccion
from .seguridad import UsuarioActual, usuario_actual

router = APIRouter(tags=["afiliacion"])

FIRMAS = {b"%PDF-": "pdf", b"\xff\xd8\xff": "jpg", b"\x89PNG\r\n\x1a\n": "png"}
MAX_ARCHIVOS = 10


def _tipo(datos: bytes) -> str | None:
    return next((t for firma, t in FIRMAS.items() if datos.startswith(firma)), None)


def _imagen_a_pdf(datos: bytes) -> bytes:
    """Una foto (JPG o PNG) en una página A4, derecha según su orientación EXIF y reducida a un tamaño razonable."""
    from PIL import Image, ImageOps
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfgen import canvas

    img = ImageOps.exif_transpose(Image.open(io.BytesIO(datos)))
    if img.mode not in ("RGB", "L"):
        fondo = Image.new("RGB", img.size, "white")
        fondo.paste(img, mask=img.split()[-1] if img.mode in ("RGBA", "LA") else None)
        img = fondo
    img.thumbnail((2000, 2000))
    jpg = io.BytesIO()
    img.save(jpg, "JPEG", quality=85, optimize=True)
    ancho, alto = A4
    margen = 28
    escala = min((ancho - 2 * margen) / img.width, (alto - 2 * margen) / img.height)
    w, h = img.width * escala, img.height * escala
    salida = io.BytesIO()
    c = canvas.Canvas(salida, pagesize=A4)
    c.drawImage(ImageReader(io.BytesIO(jpg.getvalue())), (ancho - w) / 2, (alto - h) / 2, w, h)
    c.showPage()
    c.save()
    return salida.getvalue()


async def _armar_pdf(archivos: list[UploadFile]) -> tuple[bytes, int, str]:
    """Une los archivos recibidos (PDF, JPG o PNG) en un solo PDF. Devuelve (pdf, páginas, nombre)."""
    from pypdf import PdfReader, PdfWriter

    if not archivos:
        raise HTTPException(400, "Adjunte el documento (PDF o fotos JPG o PNG).")
    if len(archivos) > MAX_ARCHIVOS:
        raise HTTPException(400, f"Máximo {MAX_ARCHIVOS} archivos por documento.")
    limite, total, partes = config.MAX_ARCHIVO_MB * 1024 * 1024, 0, []
    for a in archivos:
        datos = await a.read(limite + 1)
        total += len(datos)
        if total > limite:
            raise HTTPException(413, f"Los archivos superan el máximo de {config.MAX_ARCHIVO_MB} MB.")
        t = _tipo(datos)
        if not t:
            raise HTTPException(400, f"«{a.filename}» no es un PDF, JPG o PNG. Si su celular guarda las fotos en HEIC, "
                                     "tómelas en JPG o escanéelas como PDF.")
        partes.append((t, datos))
    nombre = re.sub(r"[^\w.\- ]", "_", Path(archivos[0].filename or "documento").stem)[:120] + ".pdf"
    try:
        if len(partes) == 1 and partes[0][0] == "pdf":
            pdf = partes[0][1]
            return pdf, len(PdfReader(io.BytesIO(pdf)).pages), nombre
        escritor = PdfWriter()
        for t, datos in partes:
            lector = PdfReader(io.BytesIO(datos if t == "pdf" else _imagen_a_pdf(datos)))
            for pagina in lector.pages:
                escritor.add_page(pagina)
        salida = io.BytesIO()
        escritor.write(salida)
        return salida.getvalue(), len(escritor.pages), nombre
    except HTTPException:
        raise
    except Exception:  # noqa: BLE001 - PDF dañado o imagen ilegible
        raise HTTPException(400, "No se pudo leer el archivo: verifique que no esté dañado ni protegido con contraseña.")


def _guardar(conn, id_persona: int, codigo: str, pdf: bytes, paginas: int, nombre: str) -> dict:
    """Guarda el PDF bajo UPLOAD_DIR/afiliacion/<persona>/ y lo registra; si la base lo rechaza, el archivo no queda."""
    huella = hashlib.sha256(pdf).hexdigest()
    carpeta = config.UPLOAD_DIR / "afiliacion" / str(int(id_persona))
    carpeta.mkdir(parents=True, exist_ok=True)
    final = carpeta / f"{re.sub(r'[^A-Z0-9_]', '', codigo.upper())}_{huella[:16]}.pdf"
    relativa = final.relative_to(config.UPLOAD_DIR).as_posix()
    id_doc = conn.execute("SELECT gobernanza.fn_registrar_documento_afiliacion(%s, %s, %s, %s, %s, %s, %s) AS id",
                          (id_persona, codigo, relativa, nombre, len(pdf), paginas, huella)).fetchone()["id"]
    if not final.exists():
        temporal = carpeta / f".subiendo_{os.getpid()}_{datetime.now().timestamp()}"
        temporal.write_bytes(pdf)
        shutil.move(str(temporal), final)
        try:
            os.chmod(final, 0o440)
        except OSError:
            pass
    return {"id_documento": id_doc, "hash_sha256": huella, "paginas": paginas, "tamano_bytes": len(pdf), "nombre_archivo": nombre}


def _servir(fila: dict) -> FileResponse:
    if not fila:
        raise HTTPException(404, "Archivo no encontrado.")
    ruta = (config.UPLOAD_DIR / fila["ruta_archivo"]).resolve()
    if not str(ruta).startswith(str(config.UPLOAD_DIR.resolve())) or not ruta.is_file():
        raise HTTPException(404, "El archivo no está en el servidor. Avise al administrador.")
    return FileResponse(ruta, media_type=fila.get("tipo_mime") or "application/pdf", filename=fila["nombre_original"],
                        headers={"Cache-Control": "no-store"})


def _id_acta(conn, valor: Any) -> int | None:
    """El acta se indica por su número interno o por su radicado (p. ej. ACT-2026-00012)."""
    if valor in (None, ""):
        return None
    if isinstance(valor, int) or str(valor).strip().isdigit():
        return int(valor)
    f = conn.execute("SELECT id_documento FROM gestion_documental.documento WHERE upper(radicado_alfanumerico) = upper(%s)",
                     (str(valor).strip(),)).fetchone()
    if not f:
        raise HTTPException(400, f"No se encontró el acta con radicado «{valor}».")
    return f["id_documento"]


# ================================================================ junta, Ventanilla y administrador
@router.get("/api/afiliacion/expedientes/{id_persona}")
def ver_expediente(id_persona: int, usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        e = conn.execute("SELECT gobernanza.fn_expediente_afiliacion(%s) AS e", (id_persona,)).fetchone()["e"]
        if e:   # grupo dentro de la Junta Nacional: PALMIRA (sede nacional) o DISPERSO
            e["grupo_nacional"] = conn.execute("SELECT gobernanza.fn_grupo_nacional(%s) AS g", (id_persona,)).fetchone()["g"]
    if not e:
        raise HTTPException(404, "La persona no existe.")
    return serializar(e)


@router.post("/api/afiliacion/expedientes/{id_persona}/documentos/{codigo}")
async def cargar_documento(id_persona: int, codigo: str, archivos: list[UploadFile] = File(...),
                           usuario: UsuarioActual = Depends(usuario_actual)):
    pdf, paginas, nombre = await _armar_pdf(archivos)
    with transaccion(usuario) as conn:
        return _guardar(conn, id_persona, codigo, pdf, paginas, nombre)


@router.get("/api/afiliacion/documentos/{id_documento}/archivo")
def abrir_documento(id_documento: int, motivo: str | None = None, usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        f = conn.execute("SELECT * FROM gobernanza.fn_abrir_documento_afiliacion(%s, %s)", (id_documento, motivo)).fetchone()
    return _servir(f)


@router.post("/api/afiliacion/documentos/{id_documento}/revisar")
def revisar_documento(id_documento: int, datos: dict = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        e = conn.execute("SELECT gobernanza.fn_revisar_documento_afiliacion(%s, %s, %s) AS e",
                         (id_documento, bool(datos.get("aceptar")), datos.get("motivo"))).fetchone()["e"]
    return {"estado": e}


@router.post("/api/afiliacion/pertenencia/{id_persona}")
def cambiar_pertenencia(id_persona: int, datos: dict = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    """Pasar a disperso (Junta Nacional) o volver a una subdirectiva o comité, con el acta de la Junta Nacional."""
    with transaccion(usuario) as conn:
        r = conn.execute("SELECT gobernanza.fn_cambiar_pertenencia_disperso(%s, %s, %s, %s) AS r",
                         (id_persona, datos.get("id_estamento"), _id_acta(conn, datos.get("acta") or datos.get("id_acta")),
                          datos.get("motivo"))).fetchone()["r"]
    return {"resultado": r}


@router.post("/api/afiliacion/tipos/{codigo}/plantilla")
async def subir_plantilla(codigo: str, archivo: UploadFile = File(...), usuario: UsuarioActual = Depends(usuario_actual)):
    datos = await archivo.read(config.MAX_ARCHIVO_MB * 1024 * 1024 + 1)
    extension = Path(archivo.filename or "").suffix.lower()
    if extension not in (".pdf", ".docx", ".doc") or len(datos) > config.MAX_ARCHIVO_MB * 1024 * 1024 or not datos:
        raise HTTPException(400, f"La plantilla debe ser PDF o Word, de máximo {config.MAX_ARCHIVO_MB} MB.")
    huella = hashlib.sha256(datos).hexdigest()
    carpeta = config.UPLOAD_DIR / "afiliacion" / "plantillas"
    carpeta.mkdir(parents=True, exist_ok=True)
    final = carpeta / f"{re.sub(r'[^A-Z0-9_]', '', codigo.upper())}_{huella[:16]}{extension}"
    nombre = re.sub(r"[^\w.\- ]", "_", Path(archivo.filename or "plantilla").name)[:150]
    with transaccion(usuario) as conn:
        conn.execute("SELECT gobernanza.fn_fijar_plantilla_afiliacion(%s, %s, %s, %s)",
                     (codigo, final.relative_to(config.UPLOAD_DIR).as_posix(), nombre, huella))
        if not final.exists():
            final.write_bytes(datos)
    return {"ok": True, "nombre": nombre}


@router.get("/api/afiliacion/tipos/{codigo}/plantilla")
def bajar_plantilla(codigo: str, usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        f = conn.execute("SELECT * FROM gobernanza.fn_plantilla_afiliacion(%s)", (codigo,)).fetchone()
    if not f or not f["ruta"]:
        raise HTTPException(404, "Este documento no tiene plantilla para descargar.")
    ruta = (config.UPLOAD_DIR / f["ruta"]).resolve()
    if not ruta.is_file():
        raise HTTPException(404, "La plantilla no está en el servidor.")
    return FileResponse(ruta, filename=f["nombre"])


# ================================================================ portal (la propia persona)
@router.get("/api/autoservicio/afiliacion")
def mi_expediente(usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        e = conn.execute("SELECT gobernanza.fn_mi_expediente() AS e").fetchone()["e"]
        e["grupo_nacional"] = conn.execute("SELECT gobernanza.fn_grupo_nacional(seguridad.fn_mi_persona_cuenta()) AS g").fetchone()["g"]
        return serializar(e)


@router.post("/api/autoservicio/afiliacion/documentos/{codigo}")
async def cargar_mi_documento(codigo: str, archivos: list[UploadFile] = File(...), usuario: UsuarioActual = Depends(usuario_actual)):
    pdf, paginas, nombre = await _armar_pdf(archivos)
    with transaccion(usuario) as conn:
        yo = conn.execute("SELECT seguridad.fn_mi_persona_cuenta() AS p").fetchone()["p"]
        if not yo:
            raise HTTPException(403, "Su usuario no está ligado a una persona.")
        return _guardar(conn, yo, codigo, pdf, paginas, nombre)


@router.get("/api/autoservicio/afiliacion/documentos/{id_documento}/archivo")
def abrir_mi_documento(id_documento: int, usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        f = conn.execute("SELECT * FROM gobernanza.fn_abrir_documento_afiliacion(%s, NULL)", (id_documento,)).fetchone()
    return _servir(f)


# ================================================================ traslados entre juntas (db/17)
@router.post("/api/afiliacion/traslados")
def proponer_traslado(datos: dict = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    """Una de las dos juntas propone el traslado con su acta; la otra lo acepta o lo rechaza con la suya."""
    with transaccion(usuario) as conn:
        i = conn.execute("SELECT gobernanza.fn_proponer_traslado(%s, %s, %s, %s) AS i",
                         (datos.get("id_persona"), datos.get("id_estamento"), _id_acta(conn, datos.get("acta") or datos.get("id_acta")),
                          datos.get("motivo"))).fetchone()["i"]
        t = conn.execute("SELECT * FROM gobernanza.v_traslados WHERE id_traslado = %s", (i,)).fetchone()
    return serializar(t)


@router.post("/api/afiliacion/traslados/{id_traslado}/{accion}")
def responder_traslado(id_traslado: int, accion: str, datos: dict = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    if accion not in ("aceptar", "rechazar", "anular"):
        raise HTTPException(404, "Acción no válida.")
    with transaccion(usuario) as conn:
        if accion == "anular":
            r = conn.execute("SELECT gobernanza.fn_anular_traslado(%s, %s) AS r", (id_traslado, datos.get("motivo"))).fetchone()["r"]
        else:
            r = conn.execute("SELECT gobernanza.fn_responder_traslado(%s, %s, %s, %s) AS r",
                             (id_traslado, accion == "aceptar", _id_acta(conn, datos.get("acta") or datos.get("id_acta")),
                              datos.get("motivo"))).fetchone()["r"]
    return {"estado": r}


# ================================================================ lista oficial de municipios (DIVIPOLA)
def _leer_divipola(contenido: bytes) -> list[dict]:
    """Lee el archivo DIVIPOLA del DANE (CSV o texto separado por ; , o tabulador; UTF-8 o Latin-1).
    Toma de cada fila el código de municipio (5 dígitos) y su nombre; el departamento sale de los 2 primeros dígitos."""
    import csv
    texto = None
    for cod in ("utf-8-sig", "latin-1"):
        try:
            texto = contenido.decode(cod)
            break
        except UnicodeDecodeError:
            continue
    muestra = texto[:5000]
    sep = max((";", ",", "\t", "|"), key=muestra.count)
    filas = list(csv.reader(io.StringIO(texto), delimiter=sep))
    if len(filas) < 2:
        raise HTTPException(400, "El archivo está vacío.")
    cab = [re.sub(r"[^a-z]", "", c.lower().replace("ó", "o").replace("í", "i")) for c in filas[0]]
    def col(*claves, evitar=()):
        return next((i for i, c in enumerate(cab) if all(k in c for k in claves) and not any(e in c for e in evitar)), None)
    c_cod = col("codigo", "municipio") if col("codigo", "municipio") is not None else col("codmpio")
    c_nom = col("nombre", "municipio") if col("nombre", "municipio") is not None else col("municipio", evitar=("codigo", "cod", "tipo"))
    if c_cod is None or c_nom is None:
        raise HTTPException(400, "No se encontraron las columnas «Código Municipio» y «Nombre Municipio». Use el archivo DIVIPOLA del DANE.")
    salida = []
    for f in filas[1:]:
        if len(f) <= max(c_cod, c_nom) or not f[c_cod].strip():
            continue
        codigo = re.sub(r"\D", "", f[c_cod]).zfill(5)
        if len(codigo) != 5:
            raise HTTPException(400, f"Código de municipio no válido: «{f[c_cod]}».")
        salida.append({"dep": codigo[:2], "mun": codigo, "mun_nombre": f[c_nom].strip()})
    return salida


@router.post("/api/admin/divipola")
async def cargar_divipola(archivo: UploadFile = File(...), usuario: UsuarioActual = Depends(usuario_actual)):
    contenido = await archivo.read(20 * 1024 * 1024)
    filas = _leer_divipola(contenido)
    import json
    with transaccion(usuario) as conn:
        r = conn.execute("SELECT gobernanza.fn_cargar_divipola(%s::jsonb) AS r", (json.dumps(filas),)).fetchone()["r"]
    return r


# ================================================================ público
@router.get("/api/publico/institucion")
def datos_institucion(request: Request):
    d = institucional()
    return {"nombre": d.get("nombre_sindicato") or config.SINDICATO_NOMBRE_RESPALDO, "sigla": d.get("sigla") or "", "nit": d.get("nit") or ""}
