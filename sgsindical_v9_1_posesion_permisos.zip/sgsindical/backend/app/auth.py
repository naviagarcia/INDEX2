"""Autenticación: inicio/cierre de sesión, bloqueo por intentos, cambio de contraseña y perfil."""
from __future__ import annotations

import math
import hashlib

import threading
import time
import uuid
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Body, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from .config import config
from .crud import serializar
from .db import transaccion
from .recursos import RECURSOS
from .seguridad import (UsuarioActual, crear_token, derivar_hash, hash_contrasena, huella_sesion, ip_cliente, registrar_acceso,
                        usuario_sesion, validar_politica_contrasena)
from .vistas import VISTAS

router = APIRouter(prefix="/api/auth", tags=["autenticación"])

# Limitador simple por IP contra ataques de fuerza bruta (además del bloqueo por usuario)
_intentos_ip: dict[str, deque] = defaultdict(deque)
_lock = threading.Lock()
VENTANA_SEG, MAX_POR_IP = 300, 30


def _limitar_ip(ip: str | None) -> None:
    ahora = time.monotonic()
    with _lock:
        cola = _intentos_ip[ip or "?"]
        while cola and ahora - cola[0] > VENTANA_SEG:
            cola.popleft()
        if len(cola) >= MAX_POR_IP:
            raise HTTPException(429, "Demasiados intentos desde este equipo. Espere unos minutos.")
        cola.append(ahora)


class Credenciales(BaseModel):
    nombre_usuario: str = Field(min_length=1, max_length=50)
    contrasena: str = Field(min_length=1, max_length=200)
    equipo: str | None = Field(default=None, max_length=200)
    equipo_confiable: str | None = Field(default=None, max_length=200)   # "recordar este equipo" (MFA)


class CambioContrasena(BaseModel):
    contrasena_actual: str
    contrasena_nueva: str


@router.post("/login")
def login(cred: Credenciales, request: Request):
    ip = ip_cliente(request)
    _limitar_ip(ip)
    ahora = datetime.now(timezone.utc)
    error_generico = HTTPException(401, "Usuario o contraseña incorrectos.")

    # La base entrega solo la sal; aquí se calcula el hash y la base lo compara, cuenta intentos y crea la sesión
    with transaccion(cred.nombre_usuario, ip) as conn:
        sal = conn.execute("SELECT seguridad.fn_sal_contrasena(%s) AS s", (cred.nombre_usuario,)).fetchone()["s"]
    calculado = derivar_hash(cred.contrasena, sal)
    token_sesion = str(uuid.uuid4())
    hash_equipo = hashlib.sha256(cred.equipo_confiable.encode()).hexdigest() if cred.equipo_confiable else None
    with transaccion(cred.nombre_usuario, ip) as conn:
        r = conn.execute("SELECT * FROM seguridad.fn_iniciar_sesion(%s, %s, %s::uuid, %s::inet, %s, %s, %s, %s, %s, %s)",
                         (cred.nombre_usuario, calculado, huella_sesion(token_sesion), ip, cred.equipo, hash_equipo,
                          config.MAX_INTENTOS_FALLIDOS, config.BLOQUEO_MINUTOS, config.CONTRASENA_DIAS_VIGENCIA,
                          config.SESION_HORAS)).fetchone()
        try:
            conn.execute("SELECT auditoria.fn_detectar_conexiones_ajenas()")
        except Exception:  # noqa: BLE001  (la vigilancia nunca impide el ingreso)
            pass
        if r["resultado"] == "OK":
            elegir = not conn.execute("SELECT contexto_elegido FROM seguridad.sesion WHERE id_sesion = %s::uuid",
                                      (huella_sesion(token_sesion),)).fetchone()["contexto_elegido"]
            conn.execute("INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, ip_origen, detalle) "
                         "VALUES (%s, 'LOGIN_OK', %s, %s)", (r["nombre_usuario"], ip, cred.equipo))
            return {
                "token": crear_token(r["id_usuario"], token_sesion, r["expira"]),
                "expira": r["expira"].isoformat(),
                "debe_cambiar_contrasena": r["debe_cambiar"],
                "motivo_cambio": "vencida" if r["vencida"] else None,
                "mfa": r["mfa"],                 # VERIFICAR | CONFIGURAR | PLAZO | None
                "mfa_dias_restantes": r["mfa_dias"],
                "elegir_contexto": elegir,      # tiene varios roles: debe elegir con cuál trabajar
            }
    if r["resultado"] == "BLOQUEADA":
        hora = r["bloqueado_hasta"].astimezone().strftime("%H:%M")
        evento, detalle = "LOGIN_FALLIDO", "cuenta bloqueada"
        respuesta = HTTPException(423, f"Cuenta bloqueada por intentos fallidos hasta las {hora}.")
    elif r["resultado"] == "BLOQUEO_NUEVO":
        evento, detalle = "CUENTA_BLOQUEADA", r["detalle"]
        respuesta = HTTPException(423, f"Cuenta bloqueada por {config.BLOQUEO_MINUTOS} minutos tras {r['mfa_dias']} intentos fallidos.")
    else:
        evento, detalle, respuesta = "LOGIN_FALLIDO", r["detalle"], error_generico

    # Los fallos se registran en su propia transacción y luego se responde el error
    registrar_acceso(cred.nombre_usuario, evento, ip, detalle)
    raise respuesta


@router.post("/logout")
def logout(usuario: UsuarioActual = Depends(usuario_sesion)):
    with transaccion(usuario) as conn:
        conn.execute("SELECT seguridad.fn_sesion_cerrar_actual()")
        conn.execute("INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, ip_origen) VALUES (%s, 'LOGOUT', %s)",
                     (usuario.nombre_usuario, usuario.ip))
    return {"ok": True}


@router.post("/cambiar-contrasena")
def cambiar_contrasena(datos: CambioContrasena, usuario: UsuarioActual = Depends(usuario_sesion)):
    if usuario.mfa_activo and not usuario.mfa_verificada:
        raise HTTPException(403, "Verifique primero el segundo factor.")
    validar_politica_contrasena(datos.contrasena_nueva, usuario.nombre_usuario)
    if datos.contrasena_nueva == datos.contrasena_actual:
        raise HTTPException(400, "La nueva contraseña debe ser diferente de la actual.")
    with transaccion(usuario) as conn:
        sal = conn.execute("SELECT seguridad.fn_sal_contrasena(%s) AS s", (usuario.nombre_usuario,)).fetchone()["s"]
        ok = conn.execute("SELECT seguridad.fn_cambiar_mi_contrasena(%s, %s) AS ok",
                          (derivar_hash(datos.contrasena_actual, sal), hash_contrasena(datos.contrasena_nueva))).fetchone()["ok"]
        if not ok:
            raise HTTPException(400, "La contraseña actual no es correcta.")
        # Se cierran las demás sesiones abiertas del usuario y se olvidan los equipos recordados
        conn.execute("SELECT seguridad.fn_revocar_sesiones_usuario(%s, TRUE)", (usuario.id_usuario,))
        conn.execute("SELECT seguridad.fn_mfa_revocar_equipos(%s)", (usuario.id_usuario,))
        conn.execute("INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, ip_origen) "
                     "VALUES (%s, 'CAMBIO_CONTRASENA', %s)", (usuario.nombre_usuario, usuario.ip))
    return {"ok": True}


@router.post("/contexto")
def elegir_contexto(datos: dict = Body(...), usuario: UsuarioActual = Depends(usuario_sesion)):
    """Elige (o cambia) el rol y ámbito con que se trabaja. Los permisos no se suman entre contextos."""
    if usuario.mfa_activo and not usuario.mfa_verificada:
        raise HTTPException(403, "Verifique primero el segundo factor.")
    with transaccion(usuario) as conn:
        d = conn.execute("SELECT seguridad.fn_elegir_contexto(%s) AS d", (datos.get("id_usuario_rol"),)).fetchone()["d"]
    return {"contexto": d}


@router.get("/yo")
def perfil(usuario: UsuarioActual = Depends(usuario_sesion)):
    """Datos de la sesión, permisos y catálogo de pantallas que el usuario puede usar."""
    recursos = [r.meta() for r in RECURSOS.values() if usuario.puede(r.modulo, "consultar")]
    with transaccion(usuario) as conn:
        ambito = conn.execute("SELECT * FROM seguridad.fn_describir_ambito()").fetchone()
        portal = conn.execute("SELECT seguridad.fn_mi_persona() IS NOT NULL AS p").fetchone()["p"]
        # Cuenta del portal creada desde la solicitud de afiliación (aún no es afiliado)
        solicitante = (usuario.codigo_rol == "AFILIADO" and not portal
                       and conn.execute("SELECT seguridad.fn_mi_persona_cuenta() IS NOT NULL AS p").fetchone()["p"])
        from .mfa import estado_mfa
        mfa = estado_mfa(conn, usuario)
        contextos = [serializar(c) for c in conn.execute("SELECT * FROM seguridad.fn_contextos_de(%s)", (usuario.id_usuario,)).fetchall()]
        aprueba_roles = conn.execute("SELECT seguridad.fn_aprobador_nacional() AS a").fetchone()["a"]
        suplencias = conn.execute("""SELECT count(*) AS n FROM seguridad.fn_mis_cargos() m
                                      WHERE m.codigo LIKE 'PRES\\_%%' OR m.codigo LIKE 'SGEN\\_%%'""").fetchone()["n"] > 0
    vistas = [{"clave": v.clave, "titulo": v.titulo, "modulo": v.modulo, "descripcion": v.descripcion}
              for v in VISTAS.values() if usuario.puede(v.modulo, "ver_vistas")]
    return {
        "id_usuario": usuario.id_usuario,
        "nombre_usuario": usuario.nombre_usuario,
        "nombre_completo": usuario.nombre_completo,
        "codigo_rol": usuario.codigo_rol,
        "debe_cambiar_contrasena": usuario.debe_cambiar_contrasena,
        "ambito": {"nacional": ambito["nacional"], "estamentos": ambito["estamentos"]},
        "permisos": usuario.permisos,
        "portal_afiliado": portal,
        "solicitante": bool(solicitante),
        "mfa": mfa,   # el usuario está ligado a un afiliado: tiene "Mi espacio"
        "contextos": contextos,                          # roles con los que puede trabajar
        "contexto_activo": next((c for c in contextos if c["activo"]), None),
        "elegir_contexto": usuario.contexto_pendiente,
        "aprueba_roles": aprueba_roles,                  # Presidencia Nacional: aprueba Administrador y roles nacionales
        "gestiona_suplencias": suplencias,
        "recursos": recursos,
        "vistas": vistas,
        "politicas": {
            "contrasena_min": config.CONTRASENA_MIN,
            "inactividad_minutos": config.INACTIVIDAD_MINUTOS,
            "sesion_horas": config.SESION_HORAS,
        },
    }
