"""Varios roles por usuario (contextos), aprobación de roles y suplencias (bloque 5).

Las reglas viven en la base (db/12_roles_suplencias.sql): quién asigna y aprueba, incompatibilidades,
suplencias con acta, máximo 90 días y suspensión del titular. Aquí solo se exponen esas funciones."""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException

from .crud import serializar
from .db import transaccion
from .seguridad import UsuarioActual, exigir_paso_adicional, requiere, usuario_actual

router = APIRouter(prefix="/api", tags=["roles"])


# ---------------------------------------------------------------- roles de un usuario (administrador)
@router.get("/roles/usuarios/{id_usuario}")
def roles_de_usuario(id_usuario: int, usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "consultar"))):
    with transaccion(usuario) as conn:
        filas = conn.execute("SELECT * FROM seguridad.v_roles_usuario WHERE id_usuario = %s ORDER BY estado <> 'VIGENTE', id_usuario_rol",
                             (id_usuario,)).fetchall()
        inc = conn.execute("SELECT seguridad.fn_incompatibilidad(%s) AS m", (id_usuario,)).fetchone()["m"]
    return {"roles": serializar(filas), "incompatibilidad": inc}


@router.post("/roles/usuarios/{id_usuario}")
def asignar_rol(id_usuario: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "actualizar"))):
    exigir_paso_adicional(usuario)
    juntas = [int(j) for j in (datos.get("juntas") or [])]
    with transaccion(usuario) as conn:
        r = conn.execute("SELECT * FROM seguridad.fn_asignar_rol(%s, %s, %s, %s, %s, %s, %s, %s)",
                         (id_usuario, datos.get("codigo_rol"), bool(datos.get("ambito_nacional")), juntas,
                          bool(datos.get("incluye_cargos")), datos.get("desde") or None, datos.get("hasta") or None,
                          datos.get("motivo"))).fetchone()
    aviso = ("Queda pendiente hasta que lo apruebe la Presidencia Nacional." if r["estado"] == "PENDIENTE"
             else "Rol asignado: el usuario lo elige al ingresar o desde el encabezado.")
    return {**serializar(r), "aviso": aviso}


@router.post("/roles/{id_usuario_rol}/revocar")
def revocar_rol(id_usuario_rol: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "actualizar"))):
    exigir_paso_adicional(usuario)
    with transaccion(usuario) as conn:
        conn.execute("SELECT seguridad.fn_revocar_rol(%s, %s)", (id_usuario_rol, datos.get("motivo")))
    return {"estado": "REVOCADO"}


# ---------------------------------------------------------------- aprobación (Presidencia Nacional)
@router.get("/roles/pendientes")
def roles_pendientes(usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        if not conn.execute("SELECT seguridad.fn_aprobador_nacional() OR seguridad.fn_es_admin() AS ok").fetchone()["ok"]:
            raise HTTPException(403, "Los roles pendientes los ve la Presidencia Nacional.")
        filas = conn.execute("SELECT * FROM seguridad.v_roles_usuario WHERE estado = 'PENDIENTE' ORDER BY fecha_solicitud").fetchall()
    return serializar(filas)


@router.post("/roles/{id_usuario_rol}/{decision}")
def decidir_rol(id_usuario_rol: int, decision: str, datos: dict[str, Any] = Body(default={}), usuario: UsuarioActual = Depends(usuario_actual)):
    if decision not in ("aprobar", "rechazar"):
        raise HTTPException(404, "Acción no válida.")
    exigir_paso_adicional(usuario)
    with transaccion(usuario) as conn:
        e = conn.execute("SELECT seguridad.fn_decidir_rol(%s, %s, %s) AS e",
                         (id_usuario_rol, decision == "aprobar", datos.get("observacion"))).fetchone()["e"]
    return {"estado": e}


# ---------------------------------------------------------------- suplencias
@router.get("/suplencias")
def suplencias(todas: bool = False, usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    with transaccion(usuario) as conn:
        filas = conn.execute("SELECT * FROM gobernanza.v_suplencias " + ("" if todas else "WHERE diagnostico NOT IN ('REVOCADA', 'TERMINADA') ")
                             + "ORDER BY hasta DESC, id_suplencia DESC").fetchall()
    return serializar(filas)


@router.get("/suplencias/cargos/{id_estamento}")
def cargos_de_junta(id_estamento: int, usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    """Titulares vigentes de la junta (para elegir a quién se suple)."""
    with transaccion(usuario) as conn:
        filas = conn.execute("""SELECT d.id_cargo, c.nombre AS cargo, d.id_persona, p.primer_nombre || ' ' || p.primer_apellido AS titular
                                  FROM gobernanza.directivo_estamento d
                                  JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
                                  JOIN gobernanza.persona p ON p.id_persona = d.id_persona
                                 WHERE d.id_estamento = %s AND d.fecha_retiro IS NULL ORDER BY c.orden""", (id_estamento,)).fetchall()
    return serializar(filas)


@router.post("/suplencias")
def registrar_suplencia(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    with transaccion(usuario) as conn:
        r = conn.execute("SELECT * FROM gobernanza.fn_registrar_suplencia(%s, %s, %s, %s, %s, %s, %s, %s, NULL)",
                         (datos.get("id_estamento"), datos.get("id_cargo"), datos.get("id_persona_titular"), datos.get("id_persona_suplente"),
                          datos.get("desde"), datos.get("hasta"), datos.get("id_acta"), datos.get("motivo"))).fetchone()
    return _respuesta_suplencia(r)


@router.post("/suplencias/{id_suplencia}/renovar")
def renovar_suplencia(id_suplencia: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    with transaccion(usuario) as conn:
        r = conn.execute("SELECT * FROM gobernanza.fn_renovar_suplencia(%s, %s, %s, %s)",
                         (id_suplencia, datos.get("hasta"), datos.get("id_acta"), datos.get("motivo"))).fetchone()
    return _respuesta_suplencia(r)


@router.post("/suplencias/{id_suplencia}/revocar")
def revocar_suplencia(id_suplencia: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gobernanza.fn_revocar_suplencia(%s, %s)", (id_suplencia, datos.get("motivo")))
    return {"estado": "REVOCADA"}


def _respuesta_suplencia(r: dict) -> dict:
    aviso = None if r["usuarios_con_acceso"] else ("El suplente no tiene usuario en el sistema: pida al administrador que lo cree para que "
                                                   "pueda actuar en la aplicación (la suplencia ya rige).")
    return {"id_suplencia": r["id_suplencia"], "usuarios_con_acceso": r["usuarios_con_acceso"], "aviso": aviso}
