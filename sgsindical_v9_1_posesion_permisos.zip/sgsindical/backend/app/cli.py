"""Comandos de administración.

    python -m app.cli crear-admin --usuario admin --nombre "Administrador"
    python -m app.cli backup            (para programar con cron / Programador de tareas)
    python -m app.cli notificar         (correos de alertas; programar una vez al día)
    python -m app.cli notificar --simulacro   (muestra qué se enviaría, sin enviar)
    python -m app.cli verificar         (prueba de conexión y de políticas)
"""
from __future__ import annotations

import argparse
import getpass
import sys

from .config import config
from .db import abrir_pool, transaccion
from .seguridad import hash_contrasena, validar_politica_contrasena


def crear_admin(usuario: str, nombre: str, contrasena: str | None) -> None:
    from fastapi import HTTPException

    if not contrasena:
        contrasena = getpass.getpass("Contraseña del administrador: ")
        if contrasena != getpass.getpass("Repita la contraseña: "):
            sys.exit("Las contraseñas no coinciden.")
    try:
        validar_politica_contrasena(contrasena, usuario)
    except HTTPException as e:
        sys.exit(e.detail)
    # Instalación nueva: basta la cuenta de la aplicación (se permite crear el primer administrador).
    # Para restablecer un administrador existente se necesita una conexión de mantenimiento
    # (ADMIN_DATABASE_URL: el dueño de la base o un superusuario), porque la aplicación ya no puede hacerlo.
    import os
    import psycopg
    url = os.environ.get("ADMIN_DATABASE_URL")
    if url:
        with psycopg.connect(url) as conn:
            conn.execute("SELECT set_config('app.usuario', 'instalador', false)")
            _guardar_admin(conn, usuario, nombre, contrasena)
        print(f"Administrador '{usuario}' listo.")
        return
    try:
        with transaccion("instalador") as conn:
            _guardar_admin(conn, usuario, nombre, contrasena)
    except psycopg.errors.InsufficientPrivilege:
        sys.exit("Ya hay un administrador activo: para restablecerlo defina ADMIN_DATABASE_URL (conexión del dueño de la base "
                 "o de un superusuario) y vuelva a ejecutar este comando.")
    print(f"Administrador '{usuario}' listo.")


def _guardar_admin(conn, usuario: str, nombre: str, contrasena: str) -> None:
    h = hash_contrasena(contrasena)
    nuevo = conn.execute(
        """INSERT INTO seguridad.usuario (nombre_usuario, nombre_completo, hash_contrasena, codigo_rol, debe_cambiar_contrasena)
           VALUES (%s, %s, %s, 'ADMIN', FALSE) ON CONFLICT (nombre_usuario) DO NOTHING RETURNING id_usuario""",
        (usuario, nombre, h)).fetchone()
    if not nuevo:
        conn.execute("""UPDATE seguridad.usuario SET hash_contrasena = %s, codigo_rol = 'ADMIN', activo = TRUE,
                               intentos_fallidos = 0, bloqueado_hasta = NULL WHERE nombre_usuario = %s""", (h, usuario))


def backup() -> None:
    from .operaciones import ejecutar_backup
    r = ejecutar_backup("PROGRAMADO", "tarea_programada")
    print(f"Backup OK: {r['archivo']} ({r['tamano_bytes']} bytes) SHA-256 {r['hash_sha256']}")


def notificar(simulacro: bool) -> None:
    from .notificaciones import ErrorConfiguracion, ejecutar
    try:
        r = ejecutar(simulacro=simulacro)
    except ErrorConfiguracion as e:
        sys.exit(str(e))
    if r.get("en_curso"):
        print(r["mensaje"]); return
    print(("SIMULACRO " if simulacro else "") + f"Correos del {r['fecha']}:")
    for tipo, c in r["resumen"].items():
        print(f"  {tipo:24} generados {c['generados']:3}  enviados {c['enviados']:3}  ya enviados {c['ya_enviados']:3}  "
              f"fallidos {c['fallidos']:3}  sin correo {c['sin_correo']:3}")
    for v in r["vista_previa"]:
        print(f"  -> [{v['tipo']}] {v['para']} {('(cc ' + ', '.join(v['copia']) + ')') if v['copia'] else ''}: {v['asunto']}")
    if any(c["fallidos"] for c in r["resumen"].values()):
        sys.exit(1)


def verificar() -> None:
    with transaccion("verificacion") as conn:
        v = conn.execute("SELECT version() AS v, current_user AS u").fetchone()
        su = conn.execute("SELECT rolsuper FROM pg_roles WHERE rolname = current_user").fetchone()["rolsuper"]
        fk = conn.execute("SELECT count(*) AS n FROM auditoria.v_fk_sin_indice").fetchone()["n"]
    print("PostgreSQL:", v["v"].split(",")[0])
    print("Usuario de conexión:", v["u"], "(ADVERTENCIA: es superusuario, use sgs_app)" if su else "(OK, sin superusuario)")
    print("Llaves foráneas sin índice:", fk)
    print("Backups configurados:", "sí" if config.BACKUP_DATABASE_URL else "no (defina BACKUP_DATABASE_URL)")


def main() -> None:
    p = argparse.ArgumentParser(prog="sgsindical")
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("crear-admin")
    a.add_argument("--usuario", default="admin")
    a.add_argument("--nombre", default="Administrador del sistema")
    a.add_argument("--contrasena", help="Si no se indica, se pide de forma oculta.")
    sub.add_parser("backup")
    sub.add_parser("verificar")
    sub.add_parser("generar-llave", help="Genera una llave AES-256 para SECRETOS_LLAVE (claves de redes sociales).")
    n = sub.add_parser("notificar")
    n.add_argument("--simulacro", action="store_true", help="Muestra qué correos se enviarían, sin enviarlos.")
    args = p.parse_args()
    if args.cmd == "generar-llave":
        from .redes import generar_llave
        print("Agregue esta línea al archivo .env del servidor y guarde una copia en un lugar seguro")
        print("(sin la llave, las claves de redes sociales guardadas no se pueden recuperar):\n")
        print(f"SECRETOS_LLAVE={generar_llave()}")
        return
    if args.cmd != "notificar":
        abrir_pool()
    if args.cmd == "crear-admin":
        crear_admin(args.usuario, args.nombre, args.contrasena)
    elif args.cmd == "backup":
        backup()
    elif args.cmd == "notificar":
        notificar(args.simulacro)
    else:
        verificar()


if __name__ == "__main__":
    main()
