"""Protección de datos personales (Ley 1581 de 2012).

Las reglas viven en la base de datos (db/06_datos_personales.sql): quién ve los datos reservados,
la bitácora inmutable de accesos, las autorizaciones, los plazos en días hábiles y la anonimización
con doble control. Aquí solo se exponen esas funciones y se genera el reporte en PDF para el titular."""
from __future__ import annotations

import io
import json
from datetime import date, datetime
from typing import Any
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from fastapi.responses import Response

from .config import config
from .crud import obtener_recurso, serializar
from .db import transaccion
from .notificaciones import fecha_larga
from .seguridad import UsuarioActual, exigir_paso_adicional, requiere, usuario_actual, verificar_permiso

router = APIRouter(prefix="/api/privacidad", tags=["privacidad"])


@router.get("/estado")
def estado(usuario: UsuarioActual = Depends(usuario_actual)):
    """Qué puede hacer el usuario en materia de privacidad (para mostrar u ocultar botones)."""
    with transaccion(usuario) as conn:
        f = conn.execute("""SELECT seguridad.fn_es_admin() AS es_admin, seguridad.fn_es_presidente_nacional() AS es_presidente_nacional,
                                   seguridad.fn_ve_bitacora_accesos() AS ve_bitacora,
                                   (SELECT numero_version FROM gobernanza.politica_tratamiento WHERE vigente) AS politica_vigente""").fetchone()
    return f


# ---------------------------------------------------------------- datos reservados
@router.post("/revelar")
def revelar(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    """Entrega un dato reservado (salario o género) a quien tiene el cargo para verlo y deja registro."""
    rec = obtener_recurso(str(datos.get("recurso", "")))
    if not rec.reservado:
        raise HTTPException(400, "Este registro no tiene datos reservados.")
    verificar_permiso(usuario, rec.modulo, "consultar")
    pk = datos.get("pk") or {}
    if any(pk.get(c) in (None, "") for c in rec.pk):
        raise HTTPException(400, "Falta la llave del registro.")
    with transaccion(usuario) as conn:
        valor = conn.execute("SELECT seguridad.fn_revelar_dato(%s, %s::jsonb, %s) AS v",
                             (rec.reservado, json.dumps({c: str(pk[c]) for c in rec.pk}), datos.get("motivo"))).fetchone()["v"]
    campo = next(c["nombre"] for c in rec.campos if c.get("sensible"))
    return {"campo": campo, "valor": valor, "aviso": "Consulta registrada en la bitácora de accesos (Ley 1581)."}


@router.post("/exportacion")
def registrar_exportacion(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    """La interfaz avisa cuando exporta un listado: queda en la bitácora de accesos."""
    with transaccion(usuario) as conn:
        conn.execute("SELECT seguridad.fn_registrar_acceso_dato('EXPORTACION', %s, NULL, NULL, %s, %s)",
                     (str(datos.get("origen", "vista"))[:60], int(datos.get("registros") or 0), datos.get("detalle")))
    return {"registrado": True}


# ---------------------------------------------------------------- bitácora de accesos
@router.get("/bitacora")
def bitacora(id_persona: int | None = None, usuario_q: str | None = Query(None, alias="usuario"),
             desde: date | None = None, hasta: date | None = None, limite: int = Query(500, ge=1, le=5000),
             usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        filas = conn.execute("SELECT * FROM seguridad.fn_bitacora_accesos(%s, %s, %s, %s, %s)",
                             (id_persona, usuario_q, desde, hasta, limite)).fetchall()
    return [serializar(f) for f in filas]


@router.post("/bitacora/purgar")
def purgar(usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "actualizar"))):
    with transaccion(usuario) as conn:
        n = conn.execute("SELECT seguridad.fn_purgar_bitacora_accesos() AS n").fetchone()["n"]
    return {"purgados": n}


# ---------------------------------------------------------------- consentimiento
@router.post("/autorizaciones/{id_autorizacion}/revocar")
def revocar(id_autorizacion: int, datos: dict[str, Any] = Body(...),
            usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gobernanza.fn_revocar_autorizacion(%s, %s)", (id_autorizacion, datos.get("motivo") or ""))
        fila = conn.execute("SELECT * FROM gobernanza.autorizacion_datos WHERE id_autorizacion = %s", (id_autorizacion,)).fetchone()
    return serializar(fila)


@router.post("/politicas/{id_politica}/publicar")
def publicar(id_politica: int, usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gobernanza.fn_publicar_politica_tratamiento(%s)", (id_politica,))
        fila = conn.execute("SELECT id_politica, numero_version, vigente, fecha_vigencia, version FROM gobernanza.politica_tratamiento "
                            "WHERE id_politica = %s", (id_politica,)).fetchone()
    return serializar(fila)


@router.post("/textos/{id_texto}/publicar")
def publicar_texto(id_texto: int, usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gobernanza.fn_publicar_texto_institucional(%s)", (id_texto,))
        fila = conn.execute("SELECT id_texto, codigo, numero_version, vigente, fecha_vigencia, version FROM gobernanza.texto_institucional "
                            "WHERE id_texto = %s", (id_texto,)).fetchone()
    return serializar(fila)


# ---------------------------------------------------------------- solicitudes del titular
@router.post("/solicitudes/{id_solicitud}/prorrogar")
def prorrogar(id_solicitud: int, datos: dict[str, Any] = Body(...),
              usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    with transaccion(usuario) as conn:
        nueva = conn.execute("SELECT gobernanza.fn_prorrogar_solicitud_titular(%s, %s) AS f",
                             (id_solicitud, datos.get("motivo") or "")).fetchone()["f"]
    return {"fecha_limite": nueva.isoformat()}


@router.post("/solicitudes/{id_solicitud}/responder")
def responder(id_solicitud: int, datos: dict[str, Any] = Body(...),
              usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gobernanza.fn_responder_solicitud_titular(%s, %s, %s)",
                     (id_solicitud, datos.get("respuesta") or "", datos.get("id_documento")))
        fila = conn.execute("SELECT * FROM gobernanza.solicitud_titular WHERE id_solicitud = %s", (id_solicitud,)).fetchone()
    return serializar(fila)


@router.post("/solicitudes/{id_solicitud}/requerir")
def requerir(id_solicitud: int, datos: dict[str, Any] = Body(...),
             usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    """Reclamo incompleto (Ley 1581, art. 15): se le pide al titular que lo complete; el plazo queda suspendido."""
    with transaccion(usuario) as conn:
        hasta = conn.execute("SELECT gobernanza.fn_requerir_solicitud_titular(%s, %s) AS f",
                             (id_solicitud, datos.get("texto") or "")).fetchone()["f"]
    return {"fecha_limite_completar": hasta.isoformat()}


@router.post("/solicitudes/{id_solicitud}/completar")
def completar(id_solicitud: int, datos: dict[str, Any] = Body(...),
              usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    with transaccion(usuario) as conn:
        nueva = conn.execute("SELECT gobernanza.fn_completar_solicitud_titular(%s, %s, %s::timestamptz) AS f",
                             (id_solicitud, datos.get("detalle") or "", datos.get("recibida_en") or None)).fetchone()["f"]
    return {"fecha_limite": nueva.isoformat()}


@router.post("/solicitudes/{id_solicitud}/desistir")
def desistir(id_solicitud: int, datos: dict[str, Any] = Body(...),
             usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gobernanza.fn_desistir_solicitud_titular(%s, %s)", (id_solicitud, datos.get("motivo") or ""))
        fila = conn.execute("SELECT * FROM gobernanza.solicitud_titular WHERE id_solicitud = %s", (id_solicitud,)).fetchone()
    return serializar(fila)


@router.post("/solicitudes/{id_solicitud}/trasladar")
def trasladar(id_solicitud: int, datos: dict[str, Any] = Body(...),
              usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    with transaccion(usuario) as conn:
        tardio = conn.execute("SELECT gobernanza.fn_trasladar_solicitud_titular(%s, %s, %s) AS t",
                              (id_solicitud, datos.get("entidad") or "", datos.get("motivo") or "")).fetchone()["t"]
    return {"estado": "TRASLADADA", "tardio": tardio}


@router.get("/personas/{id_persona}/leyenda")
def leyenda(id_persona: int, usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    """Leyenda «reclamo en trámite» (Ley 1581, art. 15, num. 2) mientras el reclamo completo no se decide."""
    with transaccion(usuario) as conn:
        filas = conn.execute("SELECT * FROM gobernanza.fn_leyenda_reclamo(%s)", (id_persona,)).fetchall()
    return serializar(filas)


# ---------------------------------------------------------------- anonimización
@router.post("/anonimizaciones")
def solicitar_anonimizacion(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    exigir_paso_adicional(usuario)
    with transaccion(usuario) as conn:
        id_ = conn.execute("SELECT gobernanza.fn_solicitar_anonimizacion(%s, %s, %s) AS id",
                           (datos.get("id_persona"), datos.get("motivo") or "", datos.get("id_solicitud"))).fetchone()["id"]
    return {"id_anonimizacion": id_, "estado": "PENDIENTE",
            "mensaje": "Solicitud registrada. La debe aprobar la Presidencia Nacional (otra persona)."}


@router.post("/anonimizaciones/{id_anonimizacion}/{decision}")
def decidir_anonimizacion(id_anonimizacion: int, decision: str, datos: dict[str, Any] = Body(default={}),
                          usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    if decision not in ("aprobar", "rechazar"):
        raise HTTPException(404, "Acción no válida.")
    exigir_paso_adicional(usuario)
    with transaccion(usuario) as conn:
        r = conn.execute("SELECT gobernanza.fn_decidir_anonimizacion(%s, %s, %s) AS r",
                         (id_anonimizacion, decision == "aprobar", datos.get("observacion"))).fetchone()["r"]
    return {"estado": r}


# ---------------------------------------------------------------- reporte para el titular
ETIQUETAS = {
    "tipo_dni": "Tipo de documento", "dni": "Número de documento", "primer_nombre": "Primer nombre",
    "segundo_nombre": "Segundo nombre", "primer_apellido": "Primer apellido", "segundo_apellido": "Segundo apellido",
    "pais": "País", "departamento": "Departamento", "municipio": "Municipio", "genero": "Género", "telefono": "Teléfono",
    "correo_electronico": "Correo electrónico", "fecha_afiliacion": "Fecha de afiliación", "fecha_nacimiento": "Fecha de nacimiento",
    "nivel_educativo": "Nivel educativo", "area_empresa": "Área en la empresa", "cargo_empresa": "Nivel del cargo",
    "detalles_cargo": "Detalles del cargo", "tipo_alimentacion": "Alimentación", "zona_residencia": "Zona de residencia",
    "junta": "Junta a la que pertenece", "activo": "Activo", "empresa": "Empresa", "nit": "NIT", "sede": "Sede",
    "fecha_ingreso": "Fecha de ingreso", "salario": "Salario",
}
OMITIR = {"id_persona", "id_estamento_pertenencia", "fecha_creacion", "usuario_creacion", "fecha_modificacion",
          "usuario_modificacion", "fecha_inactivacion", "usuario_inactivacion", "motivo_inactivacion"}


def _txt(v) -> str:
    if v is None or v == "":
        return "—"
    if isinstance(v, bool):
        return "Sí" if v else "No"
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return f"{v:,.0f}".replace(",", ".")
    s = str(v)
    if len(s) >= 10 and s[4] == "-" and s[7] == "-":
        try:
            if len(s) > 10:
                return datetime.fromisoformat(s).astimezone(ZoneInfo(config.ZONA_HORARIA)).strftime("%Y-%m-%d %H:%M")
            return s[:10]
        except ValueError:
            return s
    return s


def generar_reporte_pdf(d: dict, generado_por: str) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import LETTER
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    from xml.sax.saxutils import escape as e

    est = getSampleStyleSheet()
    normal = ParagraphStyle("n", parent=est["Normal"], fontName="Helvetica", fontSize=9.5, leading=13)
    peq = ParagraphStyle("p", parent=normal, fontSize=8.5, leading=11)
    titulo = ParagraphStyle("t", parent=normal, fontName="Helvetica-Bold", fontSize=13, leading=17, alignment=TA_CENTER)
    sub = ParagraphStyle("s", parent=normal, alignment=TA_CENTER, textColor=colors.HexColor("#444444"))
    h2 = ParagraphStyle("h", parent=normal, fontName="Helvetica-Bold", fontSize=10.5, spaceBefore=10, spaceAfter=4,
                        textColor=colors.HexColor("#1f3a5f"))
    estilo = TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8eef5")),
                         ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#b8c2cf")),
                         ("VALIGN", (0, 0), (-1, -1), "TOP"),
                         ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)])

    def pares(obj: dict | None):
        if not obj:
            return Paragraph("Sin información registrada.", normal)
        filas = [[Paragraph(f"<b>{e(ETIQUETAS.get(k, k.replace('_', ' ').capitalize()))}</b>", peq), Paragraph(e(_txt(v)), peq)]
                 for k, v in obj.items() if k not in OMITIR]
        t = Table(filas, colWidths=[5 * cm, 12 * cm])
        t.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, -1), 0.3, colors.HexColor("#d5dbe3")), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        return t

    def tabla(cab, filas, anchos):
        if not filas:
            return Paragraph("No hay registros.", normal)
        datos = [[Paragraph(f"<b>{e(c)}</b>", peq) for c in cab]] + [[Paragraph(e(_txt(v)), peq) for v in f] for f in filas]
        t = Table(datos, colWidths=[a * cm for a in anchos], repeatRows=1)
        t.setStyle(estilo)
        return t

    p = d.get("persona") or {}
    nombre = " ".join(x for x in [p.get("primer_nombre"), p.get("segundo_nombre"), p.get("primer_apellido"), p.get("segundo_apellido")] if x)
    hoy = datetime.now(ZoneInfo(config.ZONA_HORARIA))
    h = [Paragraph(e(config.SINDICATO_NOMBRE.upper()), titulo),
         Paragraph("Reporte de datos personales del titular (Ley 1581 de 2012, art. 8 y 14)", sub), Spacer(1, 8),
         Paragraph(f"Titular: <b>{e(nombre)}</b> — {e(str(p.get('tipo_dni', '')))} {e(str(p.get('dni', '')))}", normal),
         Paragraph(f"Generado el {fecha_larga(hoy.date())} a las {hoy:%H:%M} por {e(generado_por)}. "
                   "Este reporte contiene todos los datos que el sindicato tiene registrados sobre usted y quién los ha consultado.", peq),
         Paragraph("1. Datos de identificación y contacto", h2), pares(p),
         Paragraph("2. Afiliación sindical (dato sensible)", h2), pares(d.get("afiliado")),
         Paragraph("3. Empresa y salario", h2), pares(d.get("empresa")),
         Paragraph("4. Historial de salarios", h2),
         tabla(["Vigente desde", "Salario"], [[s["vigente_desde"], s["salario"]] for s in d.get("salarios") or []], [8, 9]),
         Paragraph("5. Cargos directivos", h2),
         tabla(["Junta", "Cargo", "Posesión", "Retiro"], [[c["junta"], c["cargo"], c["posesion"], c["retiro"]] for c in d.get("cargos") or []],
               [5, 6, 3, 3]),
         Paragraph("6. Aportes sindicales", h2), pares(d.get("aportes")),
         Paragraph("7. Autorizaciones de tratamiento de datos", h2),
         tabla(["Finalidad", "Autorizó", "Medio", "Fecha", "Estado", "Política"],
               [[a["finalidad"], a["otorgada"], a["medio"], a["fecha"], a["estado"], a["politica"]] for a in d.get("autorizaciones") or []],
               [4, 1.8, 2.4, 3.3, 2.7, 2.8]),
         Paragraph("8. Sus solicitudes", h2),
         tabla(["Radicado", "Tipo", "Fecha", "Estado"], [[s["radicado"], s["tipo"], s["fecha"], s["estado"]] for s in d.get("solicitudes") or []],
               [4, 4, 5, 4]),
         Paragraph("9. Quién ha consultado sus datos (últimos 200 registros)", h2),
         tabla(["Fecha", "Usuario", "Consulta", "Sobre", "Motivo"],
               [[a["fecha"], a["usuario"], a["tipo"], a["recurso"], a["motivo"]] for a in d.get("accesos") or []], [3.2, 3, 2.8, 3.5, 4.5]),
         Spacer(1, 10),
         Paragraph("Usted puede conocer, actualizar, rectificar y pedir la supresión de sus datos, y revocar la autorización, "
                   "presentando una solicitud al sindicato. Las consultas se responden en máximo 10 días hábiles y los reclamos "
                   "en máximo 15. También puede acudir a la Superintendencia de Industria y Comercio.", peq)]
    buf = io.BytesIO()

    def pie(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 7.5)
        canvas.setFillColor(colors.HexColor("#666666"))
        canvas.drawString(2 * cm, 1.2 * cm, f"{config.SINDICATO_NOMBRE} · SGSINDICAL · Reporte de datos personales · CONFIDENCIAL")
        canvas.drawRightString(LETTER[0] - 2 * cm, 1.2 * cm, f"Página {doc.page}")
        canvas.restoreState()

    SimpleDocTemplate(buf, pagesize=LETTER, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm, bottomMargin=2 * cm,
                      title="Reporte de datos personales", author=config.SINDICATO_NOMBRE).build(h, onFirstPage=pie, onLaterPages=pie)
    return buf.getvalue()


@router.get("/personas/{id_persona}/reporte")
def reporte_titular(id_persona: int, usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    with transaccion(usuario) as conn:
        d = conn.execute("SELECT seguridad.fn_datos_del_titular(%s) AS d", (id_persona,)).fetchone()["d"]
    if not d or not d.get("persona"):
        raise HTTPException(404, "La persona no existe.")
    pdf = generar_reporte_pdf(d, usuario.nombre_completo or usuario.nombre_usuario)
    return Response(pdf, media_type="application/pdf", headers={
        "Content-Disposition": f'attachment; filename="datos_personales_{id_persona}.pdf"',
        "Cache-Control": "no-store"})
