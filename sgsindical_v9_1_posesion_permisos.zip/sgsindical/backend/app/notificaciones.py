"""Correos automáticos de alertas.

Se ejecuta con una tarea programada diaria (ops/notificar.*) o desde Administración → Correos.
Usa el rol sgs_notificador: lee la información de todo el país y solo escribe el registro de envíos.

Garantías:
  · Cada alerta tiene una clave única; si ya se envió, no se repite (ni con dos ejecuciones a la vez).
  · Si un envío falla, queda como FALLIDO y se reintenta en la siguiente ejecución.
  · Modo simulacro: calcula qué se enviaría sin enviar nada ni registrar envíos.
"""
from __future__ import annotations

from zoneinfo import ZoneInfo

import hashlib
import html
import smtplib
import ssl
from dataclasses import dataclass, field
from datetime import date
from email.message import EmailMessage
from email.utils import formataddr, make_msgid

import psycopg
from psycopg.rows import dict_row

from .config import config, fijar_institucional

TIPOS = ("CONVOCATORIA", "CANCELACION_REUNION", "ACTAS_REUNION", "REVISION_ESCRITOS", "PUBLICACION_REDES", "CALENDARIO_CONTENIDOS", "REDES_SOCIALES", "MORA_EMPRESAS", "RESUMEN_FISCAL", "VIGENCIA_DIRECTIVO", "INFORME_TRIMESTRAL", "INACTIVIDAD_DOCUMENTAL", "CUMPLEANOS",
         "CONSENTIMIENTO_DATOS", "SOLICITUDES_TITULAR", "ACCESOS_INUSUALES", "PQRSD_PLAZOS", "SEGURIDAD_BD", "SUPLENCIAS",
         "EXPEDIENTE_AFILIACION", "PERMISOS_SINDICALES", "DESIGNACIONES_PENDIENTES")
MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre",
         "noviembre", "diciembre"]


def fecha_larga(d: date) -> str:
    return f"{d.day} de {MESES[d.month - 1]} de {d.year}"


def nombre_propio(*partes: str | None) -> str:
    return " ".join(p.strip().title() for p in partes if p and p.strip())


@dataclass
class Correo:
    tipo: str
    clave: str
    para: str
    nombre_para: str
    asunto: str
    parrafos: list[str]
    copia: list[str] = field(default_factory=list)
    tabla: tuple[list[str], list[list[str]]] | None = None

    def mensaje(self) -> EmailMessage:
        m = EmailMessage()
        m["From"] = formataddr((config.SINDICATO_NOMBRE, config.CORREO_REMITENTE))
        m["To"] = formataddr((self.nombre_para, self.para))
        if self.copia:
            m["Cc"] = ", ".join(self.copia)
        m["Subject"] = self.asunto
        m["Message-ID"] = make_msgid(domain=(config.CORREO_REMITENTE.split("@")[-1] or "sgsindical"))
        pie = f"Mensaje automático de {config.SINDICATO_NOMBRE} (SGSINDICAL)."
        if config.APP_URL:
            pie += f" Ingrese al sistema: {config.APP_URL}"
        texto = [f"Hola, {self.nombre_para}:", "", *self.parrafos]
        if self.tabla:
            cab, filas = self.tabla
            texto += ["", " | ".join(cab), *(" | ".join(f) for f in filas)]
        texto += ["", "--", pie]
        m.set_content("\n".join(texto))

        e = html.escape
        cuerpo = "".join(f"<p>{e(p)}</p>" for p in self.parrafos)
        if self.tabla:
            cab, filas = self.tabla
            cuerpo += ('<table style="border-collapse:collapse;font-size:13px">'
                       + "<tr>" + "".join(f'<th style="text-align:left;border-bottom:1px solid #ccc;padding:4px 8px">{e(c)}</th>' for c in cab) + "</tr>"
                       + "".join("<tr>" + "".join(f'<td style="border-bottom:1px solid #eee;padding:4px 8px">{e(v)}</td>' for v in f) + "</tr>" for f in filas)
                       + "</table>")
        m.add_alternative(
            f'<div style="font-family:Arial,sans-serif;font-size:14px;color:#1c2430;max-width:640px">'
            f"<p>Hola, {e(self.nombre_para)}:</p>{cuerpo}"
            f'<p style="color:#5d6878;font-size:12px;margin-top:24px">{e(pie)}</p></div>', subtype="html")
        return m


# ============================================================ generadores de alertas
def alertas_vigencia(conn, hoy: date) -> list[Correo]:
    filas = conn.execute("""
        SELECT d.id_directivo_estamento AS id, p.id_persona, p.primer_nombre, p.primer_apellido, p.correo_electronico AS correo,
               d.rol_estamento AS cargo, e.nombre_estamento, d.fecha_fin_vigencia_programada AS fin,
               (d.fecha_fin_vigencia_programada - CURRENT_DATE) AS dias, pr.id_persona AS id_pres, pr.correo_electronico AS correo_pres
          FROM gobernanza.directivo_estamento d
          JOIN gobernanza.persona p ON p.id_persona = d.id_persona
          JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento
          LEFT JOIN gobernanza.persona pr ON pr.id_persona = notificaciones.fn_directivo_por_cargo(d.id_estamento, 'PRES')
         WHERE d.fecha_retiro IS NULL AND d.fecha_fin_vigencia_programada - CURRENT_DATE <= 90
         ORDER BY d.fecha_fin_vigencia_programada""").fetchall()
    correos = []
    for f in filas:
        dias = f["dias"]
        if dias < 0:
            nivel, clave = "VENCIDO", f"vig:{f['id']}:{f['fin']}:VENCIDO:{hoy:%Y-%m}"
            asunto = f"Su periodo como {f['cargo'].title()} en {f['nombre_estamento']} venció el {fecha_larga(f['fin'])}"
            texto = (f"Su periodo personal de 2 años como {f['cargo'].title()} en {f['nombre_estamento']} venció el "
                     f"{fecha_larga(f['fin'])}, hace {-dias} días, y sigue registrado en el cargo.")
            accion = "Por favor coordine con su junta la elección correspondiente o el registro de su retiro del cargo."
        else:
            nivel = "30" if dias <= 30 else "60" if dias <= 60 else "90"
            clave = f"vig:{f['id']}:{f['fin']}:{nivel}"
            asunto = f"Su periodo como {f['cargo'].title()} en {f['nombre_estamento']} vence en {dias} días"
            texto = (f"Su periodo personal de 2 años como {f['cargo'].title()} en {f['nombre_estamento']} vence el "
                     f"{fecha_larga(f['fin'])} (faltan {dias} días).")
            accion = "Le recomendamos prever con su junta la elección o renovación del cargo."
        copia = [f["correo_pres"]] if f["correo_pres"] and f["id_pres"] != f["id_persona"] else []
        correos.append(Correo("VIGENCIA_DIRECTIVO", clave, f["correo"], nombre_propio(f["primer_nombre"], f["primer_apellido"]),
                              asunto, [texto, accion] + (["Copia al presidente de la junta."] if copia else []), copia))
    return correos


def alertas_informes(conn, hoy: date) -> list[Correo]:
    filas = conn.execute("""
        SELECT v.id_directivo_estamento AS id, v.cargo_directivo AS cargo, v.nombre_estamento, v.fecha_ultimo_informe,
               v.fecha_limite_informe AS limite, v.dias_para_vencer AS dias, v.total_informes_historicos AS total,
               p.id_persona, p.primer_nombre, p.primer_apellido, p.correo_electronico AS correo,
               pr.id_persona AS id_pres, pr.correo_electronico AS correo_pres
          FROM gestion_documental.v_auditoria_informes_directivos v
          JOIN gobernanza.directivo_estamento d ON d.id_directivo_estamento = v.id_directivo_estamento
          JOIN gobernanza.persona p ON p.id_persona = d.id_persona
          LEFT JOIN gobernanza.persona pr ON pr.id_persona = notificaciones.fn_directivo_por_cargo(d.id_estamento, 'PRES')
         WHERE v.dias_para_vencer <= 15
         ORDER BY v.dias_para_vencer""").fetchall()
    correos = []
    for f in filas:
        cargo, est, dias, limite = f["cargo"].title(), f["nombre_estamento"], f["dias"], f["limite"]
        ultimo = (f"Su último informe de gestión fue radicado el {fecha_larga(f['fecha_ultimo_informe'].date())}."
                  if f["fecha_ultimo_informe"] else "Aún no ha radicado informes de gestión en este cargo.")
        if dias >= 0:
            clave = f"inf:{f['id']}:{limite}:PROXIMO"
            asunto = f"Su informe trimestral de gestión como {cargo} vence en {dias} días"
            texto = f"El plazo para radicar su informe trimestral de gestión como {cargo} en {est} vence el {fecha_larga(limite)}."
        else:
            clave = f"inf:{f['id']}:{limite}:VENCIDO:{(-dias) // 30}"
            asunto = f"Informe trimestral de gestión vencido: {cargo} en {est}"
            texto = (f"El plazo de su informe trimestral de gestión como {cargo} en {est} venció el {fecha_larga(limite)}; "
                     f"lleva {-dias} días de retraso.")
        copia = [f["correo_pres"]] if f["correo_pres"] and f["id_pres"] != f["id_persona"] else []
        correos.append(Correo("INFORME_TRIMESTRAL", clave, f["correo"], nombre_propio(f["primer_nombre"], f["primer_apellido"]),
                              asunto, [texto, ultimo, "Los directivos deben rendir un informe de gestión (INF) cada trimestre."], copia))
    return correos


def alertas_inactividad(conn, hoy: date) -> list[Correo]:
    filas = conn.execute("""
        SELECT v.id_estamento, v.nombre_estamento, v.ambito_territorial, v.tipo_documento, v.sigla_tipo,
               v.tiempo_inactividad_formateado AS tiempo, v.diagnostico_inactividad AS diagnostico
          FROM gestion_documental.v_auditoria_inactividad_documental v
         WHERE v.diagnostico_inactividad LIKE 'ALERTA CRÍTICA%' OR v.diagnostico_inactividad LIKE 'ALERTA ALTA%'
         ORDER BY v.nombre_estamento, v.sigla_tipo""").fetchall()
    if not filas:
        return []
    juntas = conn.execute("""
        SELECT e.id_estamento, e.nombre_estamento, e.tipo_estamento,
               pr.primer_nombre AS np, pr.primer_apellido AS ap, pr.correo_electronico AS cp,
               sg.primer_nombre AS ns, sg.primer_apellido AS asg, sg.correo_electronico AS cs
          FROM gobernanza.estamento e
          LEFT JOIN gobernanza.persona pr ON pr.id_persona = notificaciones.fn_directivo_por_cargo(e.id_estamento, 'PRES')
          LEFT JOIN gobernanza.persona sg ON sg.id_persona = notificaciones.fn_directivo_por_cargo(e.id_estamento, 'SGEN')""").fetchall()
    anio, semana, _ = hoy.isocalendar()
    correos = []
    for j in juntas:
        nacional = j["tipo_estamento"] == "JUNTA DIRECTIVA NACIONAL"
        propias = [f for f in filas if nacional or f["id_estamento"] == j["id_estamento"]]
        destinos = [(c, nombre_propio(n, a)) for c, n, a in ((j["cp"], j["np"], j["ap"]), (j["cs"], j["ns"], j["asg"])) if c]
        if not propias or not destinos:
            continue
        para, nombre = destinos[0]
        copia = [c for c, _ in destinos[1:] if c != para]
        cab = (["Estamento"] if nacional else []) + ["Tipo de documento", "Tiempo sin emitir", "Alerta"]
        tabla = [([f["nombre_estamento"]] if nacional else []) +
                 [f"{f['sigla_tipo']} - {f['tipo_documento'].capitalize()}", f["tiempo"],
                  "Crítica" if "CRÍTICA" in f["diagnostico"] else "Alta"] for f in propias]
        alcance = "en todo el sindicato" if nacional else f"en {j['nombre_estamento']}"
        correos.append(Correo(
            "INACTIVIDAD_DOCUMENTAL", f"inact:{j['id_estamento']}:{anio}-S{semana:02d}", para, nombre,
            f"Resumen semanal de inactividad documental {alcance}",
            [f"Estos tipos de documento reconocidos llevan más de 30 días sin emitirse {alcance} (o nunca se han emitido):"],
            copia, (cab, tabla)))
    return correos


def alertas_cumpleanos(conn, hoy: date) -> list[Correo]:
    filas = conn.execute("""
        SELECT p.id_persona, p.primer_nombre, p.primer_apellido, p.correo_electronico AS correo
          FROM gobernanza.afiliado a JOIN gobernanza.persona p ON p.id_persona = a.id_persona
         WHERE a.activo AND p.activo AND gobernanza.fn_acepta_comunicaciones(a.id_persona)
           AND (to_char(a.fecha_nacimiento, 'MM-DD') = to_char(CURRENT_DATE, 'MM-DD')
            OR (to_char(a.fecha_nacimiento, 'MM-DD') = '02-29' AND to_char(CURRENT_DATE, 'MM-DD') = '02-28'
                AND NOT (EXTRACT(YEAR FROM CURRENT_DATE)::INT % 4 = 0
                         AND (EXTRACT(YEAR FROM CURRENT_DATE)::INT % 100 <> 0 OR EXTRACT(YEAR FROM CURRENT_DATE)::INT % 400 = 0))))
    """).fetchall()
    anio = hoy.year
    return [Correo("CUMPLEANOS", f"cumple:{f['id_persona']}:{anio}", f["correo"], nombre_propio(f["primer_nombre"]),
                   f"¡Feliz cumpleaños, {nombre_propio(f['primer_nombre'])}!",
                   [f"Todas y todos en {config.SINDICATO_NOMBRE} le deseamos un muy feliz cumpleaños.",
                    "Gracias por ser parte de nuestra organización. Que este nuevo año le traiga salud, bienestar y "
                    "muchas razones para celebrar."]) for f in filas]


def alertas_actas(conn, hoy: date) -> list[Correo]:
    filas = conn.execute("""
        SELECT * FROM gestion_documental.v_auditoria_actas_juntas
         WHERE diagnostico LIKE 'ALERTA CRÍTICA%' OR diagnostico LIKE 'ALERTA ALTA%'
         ORDER BY diagnostico, dias_desde_ultima_acta DESC NULLS FIRST, nombre_estamento""").fetchall()
    if not filas:
        return []
    anio, semana, _ = hoy.isocalendar()
    marca = f"{anio}-S{semana:02d}"

    def directivos(id_estamento):
        return conn.execute("""
            SELECT p.id_persona, p.primer_nombre, p.primer_apellido, p.correo_electronico AS correo, c.codigo
              FROM gobernanza.directivo_estamento d
              JOIN gobernanza.persona p ON p.id_persona = d.id_persona
              JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
             WHERE d.id_estamento = %s AND d.fecha_retiro IS NULL AND p.correo_electronico IS NOT NULL
             ORDER BY c.orden""", (id_estamento,)).fetchall()

    def estado(f):
        ultima = (f"Su última acta fue radicada el {fecha_larga(f['fecha_ultima_acta'])}."
                  if f["fecha_ultima_acta"] else "No ha radicado ninguna acta de reunión en el sistema.")
        if "CRÍTICA" in f["diagnostico"]:
            hecho = "no radicó acta de reunión el mes pasado y tampoco lleva ninguna en el mes en curso."
        else:
            hecho = f"aún no radica el acta de reunión de este mes, y el mes termina en {f['dias_para_cerrar_mes']} día(s)."
        return hecho, ultima

    def junta(nombre):
        return f"la {nombre}" if nombre.lower().startswith("junta") else f"la junta directiva de la {nombre}"

    correos = []
    for f in filas:
        lista = directivos(f["id_estamento"])
        if not lista:
            continue
        principal = lista[0]
        hecho, ultima = estado(f)
        incumplidos = (f" En los últimos 12 meses la junta ha incumplido {f['meses_incumplidos_ultimo_anio']} mes(es)."
                       if f["meses_incumplidos_ultimo_anio"] else "")
        correos.append(Correo(
            "ACTAS_REUNION", f"actas:{f['id_estamento']}:{marca}", principal["correo"],
            f"directivos de la {f['nombre_estamento']}",
            f"ALERTA: {f['nombre_estamento']} no está radicando actas de reunión",
            [f"{junta(f['nombre_estamento'])[:1].upper()}{junta(f['nombre_estamento'])[1:]} {hecho}",
             ultima + incumplidos,
             "Las juntas directivas deben reunirse al menos una vez al mes, y cada reunión debe quedar en un acta "
             "con sus decisiones, radicada en el sistema como \"Acta de reunión con decisiones\" (ACT).",
             "Este aviso se enviará cada semana a todos los directivos de la junta hasta que se radique un acta. "
             "La Junta Directiva Nacional recibe un consolidado semanal."],
            [d["correo"] for d in lista[1:] if d["correo"] != principal["correo"]]))

    # Consolidado nacional: Presidente, Secretario General y Fiscal de la Junta Nacional
    nal = conn.execute("""SELECT id_estamento FROM gobernanza.estamento WHERE tipo_estamento = 'JUNTA DIRECTIVA NACIONAL'""").fetchone()
    if nal:
        cupula = [d for d in directivos(nal["id_estamento"]) if d["codigo"] in ("PRES_NAL", "SGEN_NAL", "FIS_NAL")]
        if cupula:
            tabla = [[f["nombre_estamento"], fecha_larga(f["fecha_ultima_acta"]) if f["fecha_ultima_acta"] else "Nunca",
                      str(f["meses_incumplidos_ultimo_anio"]),
                      "Sin acta el mes pasado ni este" if "CRÍTICA" in f["diagnostico"] else "Mes por cerrar sin acta"] for f in filas]
            correos.append(Correo(
                "ACTAS_REUNION", f"actas:NACIONAL:{marca}", cupula[0]["correo"], "Junta Directiva Nacional",
                f"Consolidado semanal: {len(filas)} junta(s) sin actas de reunión",
                ["Estas juntas directivas no están cumpliendo la reunión mensual obligatoria:"],
                [d["correo"] for d in cupula[1:]], (["Junta", "Última acta", "Meses incumplidos (12 meses)", "Situación"], tabla)))
    return correos


def _pesos(v) -> str:
    return "$ " + f"{float(v or 0):,.0f}".replace(",", ".")


def _destinatarios(conn, id_estamento, prefijos):
    """Directivos vigentes de la junta cuyos cargos empiezan por los prefijos dados, en ese orden."""
    salida = []
    for pref in prefijos:
        fila = conn.execute("""
            SELECT p.primer_nombre, p.primer_apellido, p.correo_electronico AS correo
              FROM gobernanza.v_cargos_en_ejercicio d          -- el suplente, si el titular está suplido
              JOIN gobernanza.persona p ON p.id_persona = d.id_persona
             WHERE d.id_estamento = %s AND d.codigo LIKE %s
             ORDER BY d.por_suplencia DESC, d.desde DESC LIMIT 1""", (id_estamento, pref)).fetchone()
        if fila and fila["correo"] and fila["correo"] not in [x[0] for x in salida]:
            salida.append((fila["correo"], nombre_propio(fila["primer_nombre"], fila["primer_apellido"])))
    return salida


def _juntas(conn):
    return conn.execute("""SELECT id_estamento, nombre_estamento, tipo_estamento FROM gobernanza.estamento
                            WHERE tipo_estamento IN ('JUNTA DIRECTIVA NACIONAL', 'SUBDIRECTIVA', 'COMITÉ SECCIONAL')""").fetchall()


def alertas_mora(conn, hoy: date) -> list[Correo]:
    mora = conn.execute("""
        SELECT m.*, (SELECT array_agg(DISTINCT a.id_estamento_pertenencia) FROM gobernanza.afiliado_empresa ae
                       JOIN gobernanza.afiliado a ON a.id_persona = ae.id_persona WHERE ae.id_empresa = m.id_empresa) AS juntas
          FROM finanzas.vf_mora_empresas m
         WHERE m.diagnostico LIKE 'ALERTA%' ORDER BY m.empresa, m.periodo""").fetchall()
    if not mora:
        return []
    anio, semana, _ = hoy.isocalendar()
    correos = []
    for j in _juntas(conn):
        nacional = j["tipo_estamento"] == "JUNTA DIRECTIVA NACIONAL"
        filas = [m for m in mora if nacional or j["id_estamento"] in (m["juntas"] or [])]
        dest = _destinatarios(conn, j["id_estamento"], ["TES\\_%", "SGEN\\_COM", "PRES\\_%"])
        if not filas or not dest:
            continue
        tabla = [[m["empresa"], m["periodo"], _pesos(m["esperado"]), _pesos(m["consignado"]),
                  "No consignó" if "NO CONSIGNÓ" in m["diagnostico"] else "Consignó menos"] for m in filas]
        alcance = "todo el sindicato" if nacional else j["nombre_estamento"]
        correos.append(Correo(
            "MORA_EMPRESAS", f"mora:{j['id_estamento']}:{anio}-S{semana:02d}", dest[0][0], dest[0][1],
            f"Mora de empresas en los aportes sindicales: {len(filas)} periodo(s) ({alcance})",
            [f"Estas empresas con afiliados de {alcance} no consignaron los aportes del mes o consignaron menos de lo esperado "
             "según los salarios vigentes. Se recomienda requerirlas por escrito y radicar la comunicación en el sistema."],
            [c for c, _ in dest[1:]], (["Empresa", "Periodo", "Esperado", "Consignado", "Situación"], tabla)))
    return correos


def alertas_fiscal(conn, hoy: date) -> list[Correo]:
    alertas = conn.execute("""SELECT * FROM finanzas.vf_alertas_financieras ORDER BY junta, tipo""").fetchall()
    if not alertas:
        return []
    correos = []
    for j in _juntas(conn):
        nacional = j["tipo_estamento"] == "JUNTA DIRECTIVA NACIONAL"
        filas = [a for a in alertas if nacional or a["id_estamento"] == j["id_estamento"]]
        dest = _destinatarios(conn, j["id_estamento"], ["FIS\\_%"] if j["tipo_estamento"] != "COMITÉ SECCIONAL" else ["PRES\\_COM"])
        if not filas or not dest:
            continue
        alcance = "todo el sindicato" if nacional else j["nombre_estamento"]
        tabla = [([a["junta"]] if nacional else []) + [a["tipo"].capitalize(), a["detalle"] or "", _pesos(a["valor"]) if a["valor"] is not None else "—"]
                 for a in filas]
        correos.append(Correo(
            "RESUMEN_FISCAL", f"fiscal:{j['id_estamento']}:{hoy:%Y-%m}", dest[0][0], dest[0][1],
            f"Resumen financiero mensual para el control fiscal ({alcance})",
            [f"Alertas financieras vigentes de {alcance} para su revisión como órgano de control:"],
            [], ((["Junta"] if nacional else []) + ["Alerta", "Detalle", "Valor"], tabla)))
    return correos


def _hora12(t) -> str:
    h = t.hour % 12 or 12
    return f"{h}:{t.minute:02d} {'a. m.' if t.hour < 12 else 'p. m.'}"


def _junta_de(nombre: str) -> str:
    return f"la {nombre}" if nombre.lower().startswith("junta") else f"la junta directiva de la {nombre}"


_SQL_CONVOCADOS = """
    SELECT r.id_reunion, r.fecha, r.hora_inicio, r.tipo_reunion, r.modalidad, r.lugar, r.cargo_convoca,
           r.orden_del_dia_convocado, r.motivo_cancelacion, e.nombre_estamento,
           pc.primer_nombre AS conv_nombre, pc.primer_apellido AS conv_apellido,
           p.id_persona, p.primer_nombre, p.primer_apellido, p.correo_electronico AS correo, a.cargo
      FROM gestion_documental.reunion r
      JOIN gobernanza.estamento e ON e.id_estamento = r.id_estamento
      JOIN gobernanza.persona pc ON pc.id_persona = COALESCE(r.id_persona_cancela, r.id_persona_convoca)
      JOIN gestion_documental.reunion_asistente a ON a.id_reunion = r.id_reunion AND a.calidad = 'DIRECTIVO'
      JOIN gobernanza.persona p ON p.id_persona = a.id_persona
     WHERE r.estado = %s AND gestion_documental.fn_inicio_reunion(r.fecha, r.hora_inicio) > now() {extra}
     ORDER BY r.id_reunion, a.id_asistente"""


def correos_convocatoria(conn, hoy: date) -> list[Correo]:
    # Las convocatorias (y sus reintentos) solo salen hasta las 8:00 p. m.
    if conn.execute("SELECT localtime > '20:00'::time AS tarde").fetchone()["tarde"]:
        return []
    correos = []
    for f in conn.execute(_SQL_CONVOCADOS.format(extra=""), ("CONVOCADA",)).fetchall():
        quien = nombre_propio(f["conv_nombre"], f["conv_apellido"])
        lugar = ("Enlace de conexión: " if f["modalidad"] == "VIRTUAL" else "Lugar: ") + f["lugar"]
        puntos = [[str(p["orden"]), p["tema"]] for p in f["orden_del_dia_convocado"]]
        correos.append(Correo(
            "CONVOCATORIA", f"convocatoria:{f['id_reunion']}:{f['id_persona']}", f["correo"],
            nombre_propio(f["primer_nombre"], f["primer_apellido"]),
            f"Convocatoria: reunión {f['tipo_reunion'].lower()} de {f['nombre_estamento']} — "
            f"{fecha_larga(f['fecha'])}, {_hora12(f['hora_inicio'])}",
            [f"{quien}, {f['cargo_convoca']}, convoca a los directivos de {_junta_de(f['nombre_estamento'])} "
             f"a reunión {f['tipo_reunion'].lower()}.",
             f"Fecha: {fecha_larga(f['fecha'])}. Hora: {_hora12(f['hora_inicio'])}. Modalidad: {f['modalidad'].lower()}.",
             lugar,
             "Orden del día propuesto (puede ajustarse al iniciar la reunión):"],
            tabla=(["N.º", "Tema"], puntos)))
    return correos


def correos_cancelacion(conn, hoy: date) -> list[Correo]:
    correos = []
    for f in conn.execute(_SQL_CONVOCADOS.format(extra="AND r.fecha_cancelacion > now() - INTERVAL '3 days'"),
                          ("CANCELADA",)).fetchall():
        correos.append(Correo(
            "CANCELACION_REUNION", f"cancelacion:{f['id_reunion']}:{f['id_persona']}", f["correo"],
            nombre_propio(f["primer_nombre"], f["primer_apellido"]),
            f"CANCELADA: reunión de {f['nombre_estamento']} del {fecha_larga(f['fecha'])}, {_hora12(f['hora_inicio'])}",
            [f"La reunión {f['tipo_reunion'].lower()} de {_junta_de(f['nombre_estamento'])} convocada para el "
             f"{fecha_larga(f['fecha'])} a las {_hora12(f['hora_inicio'])} fue cancelada por "
             f"{nombre_propio(f['conv_nombre'], f['conv_apellido'])}.",
             f"Motivo: {f['motivo_cancelacion']}"]))
    return correos


def alertas_redes(conn, hoy: date) -> list[Correo]:
    filas = conn.execute("""SELECT * FROM gobernanza.v_auditoria_redes_sociales
                             WHERE (diagnostico LIKE 'ALERTA CRÍTICA%' OR diagnostico LIKE 'ALERTA ALTA%')
                               AND diagnostico NOT LIKE '%PUBLICA%'   -- la inactividad tiene su propio correo
                             ORDER BY junta, red, usuario_cuenta""").fetchall()
    anio, semana, _ = hoy.isocalendar()
    correos = []
    for j in _juntas(conn):
        propias = [f for f in filas if f["id_estamento"] == j["id_estamento"]]
        dest = _destinatarios(conn, j["id_estamento"], ["PRES\\_%", "SGEN\\_%"])
        if not propias or not dest:
            continue
        tabla = [[f["red"].capitalize(), f["usuario_cuenta"],
                  f["diagnostico"].split(": ", 1)[-1].capitalize()] for f in propias]
        correos.append(Correo(
            "REDES_SOCIALES", f"redes:{j['id_estamento']}:{anio}-S{semana:02d}", dest[0][0], dest[0][1],
            f"Seguridad de las redes sociales de {j['nombre_estamento']}: {len(propias)} cuenta(s) en alerta",
            ["Estas cuentas institucionales necesitan atención para que el sindicato no pierda su control:",
             "Recuerde: cuando un directivo que conocía la clave se retira, la clave se cambia; el correo y el teléfono de "
             "recuperación deben ser del sindicato, y la verificación en dos pasos debe estar activada."],
            [c for c, _ in dest[1:]], (["Red", "Cuenta", "Qué hacer"], tabla)))
    return correos


def alertas_publicacion(conn, hoy: date) -> list[Correo]:
    """Cuenta activa sin publicar más días de los permitidos (5 por defecto). Se repite cada 5 días."""
    filas = conn.execute("""
        SELECT v.*, p.primer_nombre, p.primer_apellido, p.correo_electronico AS correo_resp
          FROM gobernanza.v_auditoria_redes_sociales v
          JOIN gobernanza.cuenta_red_social c ON c.id_cuenta_red = v.id_cuenta_red
          LEFT JOIN gobernanza.persona p ON p.id_persona = c.id_persona_administrador
         WHERE v.sin_publicar ORDER BY v.junta, v.red""").fetchall()
    correos = []
    for f in filas:
        mesa = _destinatarios(conn, f["id_estamento"], ["PRES\\_%", "SGEN\\_%"])
        dest = ([(f["correo_resp"], nombre_propio(f["primer_nombre"], f["primer_apellido"]))] if f["correo_resp"] else []) + mesa
        dest = [d for i, d in enumerate(dest) if d[0] not in [x[0] for x in dest[:i]]]
        if not dest:
            continue
        if f["fecha_ultima_publicacion"]:
            dias = f["dias_sin_publicar"]
            tramo = (dias - f["dias_max_sin_publicar"] - 1) // 5
            clave = f"publicacion:{f['id_cuenta_red']}:{f['fecha_ultima_publicacion']}:{tramo}"
            hecho = (f"lleva {dias} días sin publicar (última publicación: {fecha_larga(f['fecha_ultima_publicacion'])}); "
                     f"el máximo permitido es {f['dias_max_sin_publicar']} días.")
        else:
            clave = f"publicacion:{f['id_cuenta_red']}:nunca:{hoy.toordinal() // 5}"
            hecho = "no tiene registrada ninguna publicación en el sistema."
        red = f["red"].capitalize() if f["red"] != "X" else "X"
        correos.append(Correo(
            "PUBLICACION_REDES", clave, dest[0][0], dest[0][1],
            f"{red} {f['usuario_cuenta']} ({f['junta']}): sin publicar contenidos",
            [f"La cuenta {f['usuario_cuenta']} de {red} de {f['junta']} {hecho}",
             "Las redes del sindicato deben mantenerse activas con contenidos que informen y eduquen a los afiliados. "
             "Después de publicar, registre la fecha en el sistema (Gobernanza → Redes sociales → Registrar publicación de hoy).",
             "Este aviso se repetirá cada 5 días mientras la cuenta siga sin publicar."],
            [c for c, _ in dest[1:]]))
    return correos


def alertas_escritos(conn, hoy: date) -> list[Correo]:
    """A cada revisor que aún no aprueba la versión vigente: al publicarse la versión y cada 3 días."""
    filas = conn.execute("""
        SELECT e.id_escrito, e.titulo, e.version_actual, e.estado, e.id_estamento, j.nombre_estamento AS junta, t.nombre AS tipo,
               (SELECT max(v.fecha) FROM gestion_documental.escrito_version v WHERE v.id_escrito = e.id_escrito)::date AS desde,
               ARRAY(SELECT r.rol FROM gestion_documental.escrito_revision r WHERE r.id_escrito = e.id_escrito
                        AND r.numero_version = e.version_actual AND r.decision = 'APRUEBA') AS aprobados
          FROM gestion_documental.escrito e
          JOIN gobernanza.estamento j ON j.id_estamento = e.id_estamento
          JOIN gestion_documental.tipo_escrito t ON t.codigo = e.codigo_tipo
         WHERE e.estado IN ('EN_REVISION', 'CAMBIOS_SOLICITADOS') AND NOT e.generando""").fetchall()
    correos = []
    for f in filas:
        tramo = max((hoy - f["desde"]).days, 0) // 3
        destinos = []
        if "ABOGADO" not in f["aprobados"]:
            for a in conn.execute("""
                    SELECT DISTINCT u.correo_electronico AS correo, u.nombre_completo FROM seguridad.usuario u
                     WHERE u.activo AND u.codigo_rol = 'ABOGADO' AND u.correo_electronico IS NOT NULL
                       AND (u.ambito_nacional OR EXISTS (SELECT 1 FROM seguridad.usuario_ambito a
                                                          WHERE a.id_usuario = u.id_usuario AND a.id_estamento = %s))""",
                    (f["id_estamento"],)).fetchall():
                destinos.append(("ABOGADO", a["correo"], a["nombre_completo"]))
        for rol, pref in (("PRESIDENCIA", "PRES\\_%"), ("SECRETARIA", "SGEN\\_%")):
            if rol not in f["aprobados"]:
                destinos += [(rol, c, n) for c, n in _destinatarios(conn, f["id_estamento"], [pref])]
        for rol, correo, nombre in destinos:
            correos.append(Correo(
                "REVISION_ESCRITOS", f"escrito:{f['id_escrito']}:v{f['version_actual']}:{rol}:{correo}:{tramo}", correo, nombre,
                f"Por revisar: {f['tipo']} — {f['titulo']} ({f['junta']})",
                [f"El proyecto de {f['tipo'].lower()} \"{f['titulo']}\" de {f['junta']} tiene la versión {f['version_actual']} "
                 f"pendiente de su revisión{' como abogado' if rol == 'ABOGADO' else ''}.",
                 "El escrito fue redactado con asistencia de inteligencia artificial: verifique los hechos, las normas citadas y "
                 "los datos marcados con [COMPLETAR] o [VERIFICAR] antes de aprobarlo. Se radica solo con la aprobación del abogado, "
                 "la Presidencia y la Secretaría General sobre la misma versión.",
                 "Ingrese a Gestión documental → Escritos jurídicos para aprobarlo, pedir cambios o comentar."]))
    return correos


def alertas_calendario(conn, hoy: date) -> list[Correo]:
    """Resumen diario del calendario editorial para comunicaciones y revisores de cada junta."""
    filas = conn.execute("""
        SELECT * FROM gobernanza.v_calendario_editorial
         WHERE diagnostico LIKE 'ALERTA%%' OR (clase = 'PIEZA' AND fecha BETWEEN %s AND %s AND estado NOT IN ('PUBLICADA', 'DESCARTADA'))
         ORDER BY junta, fecha""", (hoy, hoy.fromordinal(hoy.toordinal() + 1))).fetchall()
    revision = conn.execute("""SELECT p.id_estamento, p.titulo, p.formato, p.fecha_programada, p.version_actual,
                                      ARRAY(SELECT r.rol FROM gobernanza.pieza_revision r WHERE r.id_pieza = p.id_pieza
                                             AND r.numero_version = p.version_actual AND r.decision = 'APRUEBA') AS aprobados
                                 FROM gobernanza.pieza_contenido p WHERE p.estado IN ('EN_REVISION', 'CAMBIOS_SOLICITADOS') AND NOT p.generando""").fetchall()
    correos = []
    for j in _juntas(conn):
        propias = [f for f in filas if f["id_estamento"] == j["id_estamento"]]
        pend = [r for r in revision if r["id_estamento"] == j["id_estamento"]]
        if not propias and not pend:
            continue
        comite = j["tipo_estamento"] == "COMITÉ SECCIONAL"
        dest = _destinatarios(conn, j["id_estamento"], ["PRES\\_%", "SGEN\\_%"] if comite else ["SCOM\\_%", "SJUR\\_%", "PRES\\_%"])
        if any("JURIDICA" not in r["aprobados"] for r in pend):
            for a in conn.execute("""SELECT u.correo_electronico AS correo, u.nombre_completo FROM seguridad.usuario u
                                      WHERE u.activo AND u.codigo_rol = 'ABOGADO' AND u.correo_electronico IS NOT NULL
                                        AND (u.ambito_nacional OR EXISTS (SELECT 1 FROM seguridad.usuario_ambito x
                                                                           WHERE x.id_usuario = u.id_usuario AND x.id_estamento = %s))""",
                                  (j["id_estamento"],)).fetchall():
                if a["correo"] not in [d[0] for d in dest]:
                    dest.append((a["correo"], a["nombre_completo"]))
        if not dest:
            continue
        tabla = [[str(f["fecha"]), f["titulo"], (f["formato"] or "Fecha clave").replace("_", " ").capitalize(),
                  f["diagnostico"].split(": ", 1)[-1].capitalize()] for f in propias]
        tabla += [[str(r["fecha_programada"] or "—"), r["titulo"], r["formato"].replace("_", " ").capitalize(),
                   "Por revisar: falta " + " y ".join(x for x in ("jurídica", "comunicaciones")
                                                     if ("JURIDICA" if x == "jurídica" else "COMUNICACIONES") not in r["aprobados"])]
                  for r in pend]
        correos.append(Correo(
            "CALENDARIO_CONTENIDOS", f"calendario:{j['id_estamento']}:{hoy}:{hashlib.md5(repr(tabla).encode()).hexdigest()[:10]}",
            dest[0][0], dest[0][1],
            f"Calendario de redes de {j['nombre_estamento']}: {len(tabla)} pendiente(s) hoy",
            ["Así va el calendario editorial de la junta. Recuerde: cada pieza se publica solo con la revisión jurídica y la de "
             "comunicaciones, y al publicarla se registra el enlace en el sistema (Gobernanza → Calendario de contenidos)."],
            [c for c, _ in dest[1:]], (["Fecha", "Pieza", "Formato", "Situación"], tabla)))
    return correos


# ============================================================ Ley 1581: datos personales
def alertas_consentimiento(conn, hoy: date) -> list[Correo]:
    filas = conn.execute("""SELECT * FROM gobernanza.v_auditoria_consentimiento WHERE diagnostico LIKE 'ALERTA%%'
                             ORDER BY junta, afiliado""").fetchall()
    if not filas:
        return []
    correos = []
    for j in _juntas(conn):
        nacional = j["tipo_estamento"] == "JUNTA DIRECTIVA NACIONAL"
        propias = [f for f in filas if nacional or f["id_estamento"] == j["id_estamento"]]
        dest = _destinatarios(conn, j["id_estamento"], ["PRES\\_%", "SGEN\\_%"])
        if not propias or not dest:
            continue
        alcance = "todo el sindicato" if nacional else j["nombre_estamento"]
        tabla = [([f["junta"] or "—"] if nacional else []) + [f["afiliado"], f["identificacion"], f["gestion_sindical"].capitalize()]
                 for f in propias[:300]]
        correos.append(Correo(
            "CONSENTIMIENTO_DATOS", f"consentimiento:{j['id_estamento']}:{hoy:%Y-%m}", dest[0][0], dest[0][1],
            f"Afiliados sin autorización de tratamiento de datos: {len(propias)} ({alcance})",
            ["La Ley 1581 de 2012 exige la autorización previa y expresa del titular, en especial para datos sensibles como la "
             "afiliación sindical. Estos afiliados no tienen una autorización vigente: por favor recójala (formato físico o digital) "
             "y regístrela en el sistema con su soporte."]
            + ([f"Se muestran los primeros 300 de {len(propias)}."] if len(propias) > 300 else []),
            [c for c, _ in dest[1:]], ((["Junta"] if nacional else []) + ["Afiliado", "Documento", "Estado"], tabla)))
    return correos


def alertas_solicitudes_titular(conn, hoy: date) -> list[Correo]:
    filas = conn.execute("""SELECT * FROM gobernanza.v_auditoria_solicitudes_titular WHERE diagnostico LIKE 'ALERTA%%'
                             ORDER BY fecha_limite""").fetchall()
    if not filas:
        return []
    jdn = next((j for j in _juntas(conn) if j["tipo_estamento"] == "JUNTA DIRECTIVA NACIONAL"), None)
    correos = []
    for j in _juntas(conn):
        nacional = jdn is not None and j["id_estamento"] == jdn["id_estamento"]
        propias = [f for f in filas if f["id_estamento"] == j["id_estamento"] or (nacional and f["id_estamento"] is None)]
        dest = _destinatarios(conn, j["id_estamento"], ["PRES\\_%", "SGEN\\_%"])
        if not propias or not dest:
            continue
        tabla = [[f["radicado"], f["tipo"].capitalize(), f["titular"], str(f["fecha_limite"]),
                  f["diagnostico"].split(": ", 1)[-1].capitalize()] for f in propias]
        correos.append(Correo(
            "SOLICITUDES_TITULAR", f"solicitudes_titular:{j['id_estamento']}:{hoy:%Y-%m-%d}", dest[0][0], dest[0][1],
            f"Solicitudes de titulares de datos por vencer o vencidas: {len(propias)} ({j['nombre_estamento']})",
            ["Estas consultas o reclamos sobre datos personales deben responderse dentro del plazo legal (Ley 1581: consultas 10 "
             "días hábiles y reclamos 15). Si no alcanza, informe la prórroga al titular antes del vencimiento."],
            [c for c, _ in dest[1:]], (["Radicado", "Tipo", "Titular", "Fecha límite", "Situación"], tabla)))
    return correos


def alertas_accesos_inusuales(conn, hoy: date) -> list[Correo]:
    filas = conn.execute("""SELECT * FROM auditoria.v_accesos_inusuales WHERE dia >= %s - 1 ORDER BY dia DESC, consultas_individuales DESC""",
                         (hoy,)).fetchall()
    jdn = next((j for j in _juntas(conn) if j["tipo_estamento"] == "JUNTA DIRECTIVA NACIONAL"), None)
    if not filas or not jdn:
        return []
    dest = _destinatarios(conn, jdn["id_estamento"], ["PRES\\_NAL"])
    if not dest:
        return []
    tabla = [[str(f["dia"]), f["nombre_usuario"], str(f["consultas_individuales"]), str(f["personas_distintas"]), str(f["datos_revelados"])]
             for f in filas]
    huella = hashlib.md5(repr(tabla).encode()).hexdigest()[:10]
    return [Correo(
        "ACCESOS_INUSUALES", f"accesos_inusuales:{hoy:%Y-%m-%d}:{huella}", dest[0][0], dest[0][1],
        f"Consultas inusuales de datos personales: {len(filas)} usuario(s)",
        ["Estos usuarios consultaron más fichas o datos de personas de lo habitual. Revise en Auditoría → Bitácora de accesos "
         "a datos personales qué consultaron y por qué; si no hay justificación, desactive el usuario."],
        [], (["Día", "Usuario", "Consultas", "Personas", "Datos reservados vistos"], tabla))]


def alertas_pqrsd(conn, hoy: date) -> list[Correo]:
    """Un aviso por PQRSD y por nivel (mitad del plazo, 80 % y vencida) a los cuatro cargos que pueden firmar."""
    filas = conn.execute("""SELECT v.*, p.plazo_dias, p.dias_prorroga FROM gestion_documental.v_auditoria_pqrsd v
                              JOIN gestion_documental.pqrsd p ON p.id_pqrsd = v.id_pqrsd
                             WHERE v.nivel_alerta IS NOT NULL ORDER BY v.fecha_limite""").fetchall()
    correos = []
    nombres = {"MEDIA": "consumió la mitad del plazo", "ALTA": "consumió el 80 % del plazo", "VENCE_HOY": "vence hoy",
               "VENCIDA": "venció sin respuesta", "COMPLETAR_VENCIDO": "venció el plazo para completar"}
    for f in filas:
        dest = _destinatarios(conn, f["id_estamento"], ["PRES\\_%", "VICE\\_%", "SGEN\\_%", "FIS\\_%"])
        if not dest:
            continue
        parrafos = [f"La PQRSD {f['radicado']} ({f['tipo'].lower()}) de {f['peticionario']}, «{f['asunto']}», {nombres[f['nivel_alerta']]}.",
                    f"Fecha límite: {fecha_larga(f['fecha_limite'])}."
                    + (f" Le quedan {f['dias_habiles_restantes']} día(s) hábil(es)." if f["nivel_alerta"] in ("MEDIA", "ALTA") else "")]
        if f["nivel_alerta"] == "COMPLETAR_VENCIDO":
            parrafos = [parrafos[0], "El peticionario no completó la información a tiempo: declare el desistimiento tácito (decisión motivada) "
                        "para archivarla; el peticionario podrá presentarla de nuevo."]
        elif f["nivel_alerta"] == "VENCIDA":
            parrafos.append("Respóndala cuanto antes: la falta de respuesta oportuna vulnera el derecho de petición (Ley 1755 de 2015)."
                            + (" Como es una solicitud de documentos, se entiende aceptada: entréguelos dentro de los 3 días hábiles siguientes."
                               if f["codigo_tipo"] == "DOCUMENTOS" else ""))
        elif not f["prorrogada"]:
            parrafos.append("Si no alcanza a responder, informe la prórroga al peticionario ANTES del vencimiento (hasta el doble del plazo inicial).")
        if f["falta_concepto"] and f["nivel_alerta"] != "COMPLETAR_VENCIDO":
            parrafos.append("Todavía falta el concepto jurídico (abogado o Secretario Jurídico), obligatorio antes de responder una denuncia.")
        correos.append(Correo(
            "PQRSD_PLAZOS", f"pqrsd:{f['id_pqrsd']}:{f['nivel_alerta']}:{f['fecha_limite']}", dest[0][0], dest[0][1],
            f"PQRSD {f['radicado']}: {nombres[f['nivel_alerta']]} ({f['junta']})", parrafos, [c for c, _ in dest[1:]]))
    return correos


def alertas_seguridad_bd(conn, hoy: date) -> list[Correo]:
    """Conexiones con la contraseña de la aplicación hechas fuera de ella e intentos bloqueados por la base."""
    try:
        conn.execute("SELECT auditoria.fn_detectar_conexiones_ajenas()")
    except Exception:  # noqa: BLE001
        pass
    filas = conn.execute("""SELECT * FROM auditoria.v_alertas_seguridad WHERE fecha > now() - INTERVAL '2 days'
                             ORDER BY fecha DESC LIMIT 200""").fetchall()
    if not filas:
        return []
    dest = [(f["correo_electronico"], f["nombre_completo"]) for f in conn.execute(
        """SELECT correo_electronico, nombre_completo FROM seguridad.usuario
            WHERE codigo_rol = 'ADMIN' AND activo AND correo_electronico IS NOT NULL ORDER BY id_usuario""").fetchall()]
    jdn = next((j for j in _juntas(conn) if j["tipo_estamento"] == "JUNTA DIRECTIVA NACIONAL"), None)
    if jdn:
        dest += [d for d in _destinatarios(conn, jdn["id_estamento"], ["PRES\\_NAL"]) if d[0] not in [x[0] for x in dest]]
    if not dest:
        return []
    tabla = [[f["fecha"].astimezone(ZoneInfo(config.ZONA_HORARIA)).strftime("%d/%m/%Y %H:%M"), f["tipo"].capitalize(), f["cuenta"] or "",
              (f["detalle"] or "")[:160]] for f in filas]
    huella = hashlib.md5(repr(tabla).encode()).hexdigest()[:12]
    return [Correo(
        "SEGURIDAD_BD", f"seguridad_bd:{huella}", dest[0][0], dest[0][1],
        f"Alerta de seguridad de la base de datos: {len(filas)} evento(s)",
        ["La base de datos de SGSINDICAL registró actividad que no corresponde al uso normal de la aplicación.",
         "«Conexión ajena»: alguien se conectó con la contraseña de la aplicación desde otro programa. Si no fue el "
         "administrador haciendo mantenimiento, cambie de inmediato las contraseñas de la base (sgs_app y sgs_notificador) "
         "y revise quién tiene acceso al servidor y al archivo .env.",
         "«Intento bloqueado»: la base rechazó una operación protegida (usuarios, permisos u operaciones especiales).",
         "Detalle en Administración → Alertas de seguridad de la base."],
        [c for c, _ in dest[1:]], (["Fecha", "Tipo", "Cuenta", "Detalle"], tabla))]


def alertas_suplencias(conn, hoy: date) -> list[Correo]:
    """7 días antes del vencimiento (al suplente y a la mesa) y cuando la ausencia pasa de 60 días (a la mesa)."""
    filas = conn.execute("""SELECT v.*, ps.correo_electronico AS correo_suplente FROM gobernanza.v_suplencias v
                              JOIN gobernanza.persona ps ON ps.id_persona = v.id_persona_suplente
                             WHERE v.diagnostico LIKE 'ALERTA%%' AND NOT v.renovada""").fetchall()
    correos = []
    for f in filas:
        mesa = [d for d in _destinatarios(conn, f["id_estamento"], ["PRES\\_%", "SGEN\\_%"])]
        larga = f["dias_encadenados"] > 60
        if larga:
            if not mesa:
                continue
            correos.append(Correo(
                "SUPLENCIAS", f"suplencia_larga:{f['id_suplencia']}", mesa[0][0], mesa[0][1],
                f"Ausencia prolongada: {f['cargo']} de {f['junta']} ({f['dias_encadenados']} días)",
                [f"{f['titular']} lleva {f['dias_encadenados']} días ausente del cargo {f['cargo']}, suplido por {f['suplente']} "
                 f"(suplencia vigente hasta el {fecha_larga(f['hasta'])}).",
                 "Pasados 60 días, la junta debe estudiar si corresponde declarar la vacancia del cargo según los estatutos. "
                 "Este aviso no bloquea nada: la suplencia sigue vigente hasta su fecha."], [c for c, _ in mesa[1:]]))
        else:
            dest = ([(f["correo_suplente"], nombre_propio(f["suplente"]))] if f["correo_suplente"] else []) + mesa
            if not dest:
                continue
            correos.append(Correo(
                "SUPLENCIAS", f"suplencia_vence:{f['id_suplencia']}", dest[0][0], dest[0][1],
                f"La suplencia de {f['cargo']} ({f['junta']}) vence el {f['hasta']}",
                [f"{f['suplente']} suple a {f['titular']} en el cargo {f['cargo']} hasta el {fecha_larga(f['hasta'])}.",
                 "Al vencer, el suplente deja de actuar y el titular recupera el cargo. Si la ausencia continúa, la junta debe "
                 "renovar la suplencia con un acta nueva antes de esa fecha."], [c for c, _ in dest[1:] if c]))
    return correos


# Solicitudes archivadas en esta ejecución (las llena ejecutar(); en simulacro se calculan sin archivar)
_archivadas: list[dict] = []


def _directivos_nacionales(conn):
    filas = conn.execute("""
        SELECT DISTINCT ON (p.correo_electronico) p.primer_nombre, p.primer_apellido, p.correo_electronico AS correo
          FROM gobernanza.v_cargos_en_ejercicio d JOIN gobernanza.persona p ON p.id_persona = d.id_persona
         WHERE d.id_estamento = gobernanza.fn_id_jdn() AND p.correo_electronico IS NOT NULL
         ORDER BY p.correo_electronico""").fetchall()
    return [(f["correo"], nombre_propio(f["primer_nombre"], f["primer_apellido"])) for f in filas]


def alertas_expediente(conn, hoy: date) -> list[Correo]:
    """Recordatorios a quien solicita la afiliación, aviso de vencimiento y de archivo, y resumen diario a la junta."""
    par = {r["codigo"]: r["valor"] for r in conn.execute("SELECT codigo, valor FROM gobernanza.parametro_afiliacion").fetchall()}
    r1, r2, aviso = par.get("DIAS_RECORDATORIO_1", 3), par.get("DIAS_RECORDATORIO_2", 10), par.get("DIAS_AVISO_VENCIMIENTO", 10)
    plazo = par.get("DIAS_VENCE_SOLICITUD", 60)
    filas = conn.execute("SELECT * FROM gobernanza.v_seguimiento_solicitudes_afiliacion ORDER BY fecha").fetchall()
    rechazos = {}
    for d in conn.execute("""SELECT d.id_persona, t.nombre, d.motivo_rechazo FROM gobernanza.documento_afiliacion d
                               JOIN gobernanza.tipo_documento_afiliacion t USING (id_tipo_documento_afiliacion)
                              WHERE d.vigente AND d.estado = 'RECHAZADO'""").fetchall():
        rechazos.setdefault(d["id_persona"], []).append(f"{d['nombre']}: {d['motivo_rechazo']}")
    portal = f"Ingrese al portal ({config.APP_URL}) con su usuario" if config.APP_URL else "Ingrese al portal con su usuario"
    correos = []
    for f in filas:
        if f["estado_documental"] != "INCOMPLETA" or not f["correo"] or f["dias_para_vencer"] < 0:
            continue
        nombre = nombre_propio(f["primer_nombre"], f["primer_apellido"])
        como = (f"{portal} y cargue lo que falta (PDF o fotos legibles), o llévelo a la ventanilla de {f['junta']}."
                if f["tiene_cuenta"] else f"Llévelo a la ventanilla de {f['junta']} o pida allí la invitación al portal para cargarlo usted.")
        detalle = [f"Falta: {f['faltan']}."] + [f"Documento rechazado — {x}" for x in rechazos.get(f["id_persona"], [])]
        vence = f"Tiene plazo hasta el {fecha_larga(f['fecha_vence'])}; si para entonces faltan documentos, la solicitud se archiva."
        if f["dias_para_vencer"] <= aviso:
            clave, asunto = f"afil_vence:{f['id_solicitud_afiliacion']}", f"Su solicitud de afiliación {f['radicado']} vence pronto"
        elif f["dias_desde"] >= r2:
            clave, asunto = f"afil_rec2:{f['id_solicitud_afiliacion']}", f"Recuerde completar los documentos de su afiliación ({f['radicado']})"
        elif f["dias_desde"] >= r1:
            clave, asunto = f"afil_rec1:{f['id_solicitud_afiliacion']}", f"Faltan documentos para su afiliación ({f['radicado']})"
        else:
            continue
        correos.append(Correo("EXPEDIENTE_AFILIACION", clave, f["correo"], nombre, asunto,
                              [f"Recibimos su solicitud de afiliación {f['radicado']} en {f['junta']}. Para estudiarla necesitamos sus documentos.",
                               *detalle, como, vence]))
    # Documento rechazado: aviso inmediato con el motivo y la fecha límite para reemplazarlo
    pendientes = {f["id_persona"]: f for f in filas}
    for d in conn.execute("""SELECT d.id_documento_afiliacion, d.id_persona, t.nombre, d.motivo_rechazo
                               FROM gobernanza.documento_afiliacion d
                               JOIN gobernanza.tipo_documento_afiliacion t USING (id_tipo_documento_afiliacion)
                              WHERE d.vigente AND d.estado = 'RECHAZADO'""").fetchall():
        f = pendientes.get(d["id_persona"])
        if not f or not f["correo"]:
            continue
        correos.append(Correo("EXPEDIENTE_AFILIACION", f"afil_rechazo:{d['id_documento_afiliacion']}", f["correo"],
                              nombre_propio(f["primer_nombre"], f["primer_apellido"]),
                              f"Debe reemplazar un documento de su afiliación ({f['radicado']})",
                              [f"Su junta revisó el documento «{d['nombre']}» y no lo pudo aceptar. Motivo: {d['motivo_rechazo']}",
                               f"Súbalo de nuevo a más tardar el {fecha_larga(f['fecha_vence'])}"
                               + (f": {portal.lower()} o llévelo a la ventanilla de {f['junta']}." if f["tiene_cuenta"]
                                  else f" en la ventanilla de {f['junta']}.")]))
    # Avisos de archivo
    for a in _archivadas:
        if not a.get("correo"):
            continue
        correos.append(Correo("EXPEDIENTE_AFILIACION", f"afil_archivada:{a['id_solicitud_afiliacion']}", a["correo"],
                              nombre_propio(a["primer_nombre"], a["primer_apellido"]),
                              f"Su solicitud de afiliación {a['radicado']} fue archivada",
                              [f"Pasaron {plazo} días sin que se completaran los documentos obligatorios de su solicitud {a['radicado']} "
                               f"en {a['junta']}, por lo que se archivó y su acceso al portal quedó desactivado.",
                               "Si todavía quiere afiliarse, puede presentar una solicitud nueva en la ventanilla de su junta: los documentos "
                               "que ya le habían aceptado se conservan."]))
    # Resumen diario a quien revisa y decide
    por_junta: dict = {}
    for f in filas:
        if f["por_revisar"] or f["estado_documental"] == "COMPLETA":
            por_junta.setdefault((f["id_estamento"], f["junta"], f["disperso"]), []).append(f)
    for (id_est, junta, disperso), lista in por_junta.items():
        dest = _directivos_nacionales(conn) if disperso else _destinatarios(conn, id_est, ["PRES\\_%", "SGEN\\_%"])
        if not dest:
            continue
        tabla = [[x["radicado"], nombre_propio(x["primer_nombre"], x["primer_apellido"]),
                  "Lista para decidir" if x["estado_documental"] == "COMPLETA" else f"{x['por_revisar']} documento(s) por revisar",
                  str(x["fecha_vence"])] for x in lista]
        quien = ("Cualquier directivo nacional puede revisar los documentos; la afiliación de un disperso la decide la Junta Nacional "
                 "en reunión y la registran su Presidente o su Secretario General con el acta."
                 if disperso else "Los revisan y deciden el Presidente o el Secretario General de la junta.")
        correos.append(Correo("EXPEDIENTE_AFILIACION", f"afil_junta:{id_est}:{hoy:%Y-%m-%d}", dest[0][0], dest[0][1],
                              f"Solicitudes de afiliación por atender: {len(lista)} ({junta})",
                              ["Estas solicitudes de afiliación tienen documentos por revisar o ya están completas.", quien],
                              [c for c, _ in dest[1:]], (["Radicado", "Solicitante", "Situación", "Vence"], tabla)))
    return correos


def alertas_permisos(conn, hoy: date) -> list[Correo]:
    """A la mesa de la junta que pidió el permiso: cuando se acerca el plazo de respuesta de la entidad y cuando
    vence sin respuesta (el permiso se entiende concedido por silencio)."""
    filas = conn.execute("""SELECT * FROM gobernanza.v_permisos_sindicales
                             WHERE estado = 'SOLICITADO' AND (diagnostico LIKE 'ALERTA MEDIA%%' OR diagnostico LIKE 'CONCEDIDO POR SILENCIO%%')""").fetchall()
    correos = []
    for f in filas:
        mesa = _destinatarios(conn, f["id_estamento"], ["PRES\\_%", "SGEN\\_%"])
        if not mesa:
            continue
        if f["diagnostico"].startswith("CONCEDIDO"):
            correos.append(Correo(
                "PERMISOS_SINDICALES", f"permiso_silencio:{f['id_permiso']}", mesa[0][0], mesa[0][1],
                f"Permiso {f['consecutivo']} concedido por silencio ({f['empresa']})",
                [f"{f['empresa']} no notificó respuesta a la solicitud {f['consecutivo']} a más tardar el {fecha_larga(f['limite_respuesta'])}.",
                 "Según el artículo 2.2.2.5.4 del Decreto 1072 de 2015 (modificado por el Decreto 720 de 2024), el permiso se entiende "
                 f"concedido para todos los efectos: del {fecha_larga(f['fecha_inicio'])} al {fecha_larga(f['fecha_fin'])}.",
                 "Si después llega un acto administrativo, regístrelo en ARCADIO: quedará como respuesta extemporánea."],
                [c for c, _ in mesa[1:]]))
        else:
            correos.append(Correo(
                "PERMISOS_SINDICALES", f"permiso_plazo:{f['id_permiso']}", mesa[0][0], mesa[0][1],
                f"Permiso {f['consecutivo']}: la entidad debe responder a más tardar el {f['limite_respuesta']}",
                [f"La solicitud {f['consecutivo']} ({f['empresa']}, del {fecha_larga(f['fecha_inicio'])}) aún no tiene respuesta registrada.",
                 f"La entidad debe notificarla a más tardar el {fecha_larga(f['limite_respuesta'])}. Si ya llegó, regístrela en "
                 "«Permisos sindicales». Si no llega a tiempo, el permiso se entiende concedido."], [c for c, _ in mesa[1:]]))
    return correos


def alertas_designaciones(conn, hoy: date) -> list[Correo]:
    """Resumen semanal a la mesa de cada junta: designaciones que llevan más de 30 días sin registro del inspector."""
    filas = conn.execute("""SELECT * FROM gobernanza.v_designaciones
                             WHERE estado = 'PENDIENTE' AND fecha_designacion <= %s::date - 30 ORDER BY fecha_designacion""", (hoy,)).fetchall()
    por_junta: dict = {}
    for f in filas:
        por_junta.setdefault((f["id_estamento"], f["junta"]), []).append(f)
    correos = []
    for (id_est, junta), lista in por_junta.items():
        mesa = _destinatarios(conn, id_est, ["PRES\\_%", "SGEN\\_%"])
        if not mesa:
            continue
        tabla = [[x["designado"], x["cargo"], x["acta"], str(x["fecha_designacion"])] for x in lista]
        correos.append(Correo(
            "DESIGNACIONES_PENDIENTES", f"designaciones:{id_est}:{hoy:%G-%V}", mesa[0][0], mesa[0][1],
            f"Designaciones sin registro del inspector: {len(lista)} ({junta})",
            ["Estas designaciones llevan más de 30 días esperando el registro del inspector de trabajo. Mientras no se registren, "
             "las personas designadas no ejercen el cargo (no firman, no aprueban, no piden permisos).",
             "Cuando el inspector emita el registro, regístrelo en «Registros ante MinTrabajo»: ARCADIO dará la posesión con esa fecha."],
            [c for c, _ in mesa[1:]], (["Designado", "Cargo", "Acta", "Fecha del acta"], tabla)))
    return correos


GENERADORES = {
    "EXPEDIENTE_AFILIACION": alertas_expediente,
    "PERMISOS_SINDICALES": alertas_permisos,
    "DESIGNACIONES_PENDIENTES": alertas_designaciones,
    "SUPLENCIAS": alertas_suplencias,
    "SEGURIDAD_BD": alertas_seguridad_bd,
    "PQRSD_PLAZOS": alertas_pqrsd,
    "CONSENTIMIENTO_DATOS": alertas_consentimiento,
    "SOLICITUDES_TITULAR": alertas_solicitudes_titular,
    "ACCESOS_INUSUALES": alertas_accesos_inusuales,
    "CALENDARIO_CONTENIDOS": alertas_calendario,
    "REVISION_ESCRITOS": alertas_escritos,
    "PUBLICACION_REDES": alertas_publicacion,
    "REDES_SOCIALES": alertas_redes,
    "CONVOCATORIA": correos_convocatoria,
    "CANCELACION_REUNION": correos_cancelacion,
    "ACTAS_REUNION": alertas_actas,
    "MORA_EMPRESAS": alertas_mora,
    "RESUMEN_FISCAL": alertas_fiscal,
    "VIGENCIA_DIRECTIVO": alertas_vigencia,
    "INFORME_TRIMESTRAL": alertas_informes,
    "INACTIVIDAD_DOCUMENTAL": alertas_inactividad,
    "CUMPLEANOS": alertas_cumpleanos,
}


# ============================================================ ejecución
class ErrorConfiguracion(Exception):
    pass


def verificar_configuracion(simulacro: bool) -> None:
    if not config.NOTIFICADOR_DATABASE_URL:
        raise ErrorConfiguracion("Defina NOTIFICADOR_DATABASE_URL (rol sgs_notificador) en el archivo .env.")
    if not simulacro and not (config.SMTP_HOST and config.CORREO_REMITENTE):
        raise ErrorConfiguracion("Defina SMTP_HOST y CORREO_REMITENTE en el archivo .env para enviar correos.")


def _smtp():
    contexto = ssl.create_default_context()
    if config.SMTP_SEGURIDAD == "ssl":
        s = smtplib.SMTP_SSL(config.SMTP_HOST, config.SMTP_PORT, context=contexto, timeout=30)
    else:
        s = smtplib.SMTP(config.SMTP_HOST, config.SMTP_PORT, timeout=30)
        if config.SMTP_SEGURIDAD == "starttls":
            s.starttls(context=contexto)
    if config.SMTP_USUARIO:
        s.login(config.SMTP_USUARIO, config.SMTP_CONTRASENA)
    return s


def ejecutar(simulacro: bool = False, tipos: list[str] | None = None) -> dict:
    verificar_configuracion(simulacro)
    resumen = {t: {"generados": 0, "enviados": 0, "ya_enviados": 0, "fallidos": 0, "sin_correo": 0} for t in TIPOS}
    vista_previa: list[dict] = []
    with psycopg.connect(config.NOTIFICADOR_DATABASE_URL, row_factory=dict_row, autocommit=True,
                         application_name="sgsindical_notificaciones") as conn:
        # Las fechas (cumpleaños, vencimientos, semanas) se calculan en la zona horaria del sindicato
        conn.execute("SELECT set_config('TimeZone', %s, false), set_config('app.zona', %s, false)",
                     (config.ZONA_HORARIA, config.ZONA_HORARIA))
        hoy = conn.execute("SELECT CURRENT_DATE AS hoy").fetchone()["hoy"]
        if not conn.execute("SELECT pg_try_advisory_lock(hashtext('sgsindical_notificaciones')) AS ok").fetchone()["ok"]:
            return {"en_curso": True, "mensaje": "Ya hay otra ejecución de correos en curso.", "resumen": resumen}
        try:
            # Nombre del sindicato para los correos (de la base)
            fijar_institucional(conn.execute("SELECT gobernanza.fn_datos_institucionales() AS d").fetchone()["d"])
            # Solicitudes de afiliación vencidas con documentos incompletos: se archivan (en simulacro solo se calculan)
            _archivadas.clear()
            if not tipos or "EXPEDIENTE_AFILIACION" in tipos:
                if simulacro:
                    ids = [r["id_solicitud_afiliacion"] for r in conn.execute(
                        """SELECT id_solicitud_afiliacion FROM gobernanza.v_seguimiento_solicitudes_afiliacion
                            WHERE dias_para_vencer < 0 AND estado_documental = 'INCOMPLETA'""").fetchall()]
                else:
                    ids = [r["id_solicitud_afiliacion"] for r in conn.execute(
                        "SELECT * FROM gobernanza.fn_archivar_solicitudes_vencidas()").fetchall()]
                if ids:
                    _archivadas.extend(conn.execute("""
                        SELECT s.id_solicitud_afiliacion, s.radicado, p.primer_nombre, p.primer_apellido, p.correo_electronico AS correo,
                               e.nombre_estamento AS junta
                          FROM gobernanza.solicitud_afiliacion s JOIN gobernanza.persona p ON p.id_persona = s.id_persona
                          JOIN gobernanza.estamento e ON e.id_estamento = s.id_estamento
                         WHERE s.id_solicitud_afiliacion = ANY(%s)""", (ids,)).fetchall())
            # Envíos interrumpidos (p. ej. corte de luz) se liberan para reintentarse
            conn.execute("""UPDATE notificaciones.registro_envio SET estado = 'FALLIDO', detalle = 'Interrumpido; se reintentará'
                             WHERE estado = 'PENDIENTE' AND fecha_creacion < now() - INTERVAL '1 hour'""")
            activos = {r["codigo"] for r in conn.execute(
                "SELECT codigo FROM notificaciones.tipo_notificacion WHERE activo").fetchall()}
            smtp = None
            enviados_total = 0
            try:
                for tipo in TIPOS:
                    if tipo not in activos or (tipos and tipo not in tipos):
                        continue
                    for correo in GENERADORES[tipo](conn, hoy):
                        r = resumen[tipo]
                        r["generados"] += 1
                        if not correo.para:
                            r["sin_correo"] += 1
                            continue
                        if simulacro:
                            ya = conn.execute("SELECT 1 FROM notificaciones.registro_envio WHERE clave = %s AND estado = 'ENVIADO'",
                                              (correo.clave,)).fetchone()
                            if ya:
                                r["ya_enviados"] += 1
                            else:
                                vista_previa.append({"tipo": tipo, "para": correo.para, "copia": correo.copia, "asunto": correo.asunto})
                            continue
                        if enviados_total >= config.MAX_CORREOS_POR_EJECUCION:
                            continue
                        fila = conn.execute(
                            """INSERT INTO notificaciones.registro_envio (codigo_tipo, clave, destinatario, copia, asunto)
                               VALUES (%s, %s, %s, %s, %s)
                               ON CONFLICT (clave) WHERE estado IN ('PENDIENTE', 'ENVIADO') DO NOTHING RETURNING id_envio""",
                            (tipo, correo.clave, correo.para, ", ".join(correo.copia) or None, correo.asunto)).fetchone()
                        if not fila:
                            r["ya_enviados"] += 1
                            continue
                        try:
                            if smtp is None:
                                smtp = _smtp()
                            smtp.send_message(correo.mensaje())
                            conn.execute("UPDATE notificaciones.registro_envio SET estado = 'ENVIADO', fecha_envio = now() "
                                         "WHERE id_envio = %s", (fila["id_envio"],))
                            r["enviados"] += 1
                            enviados_total += 1
                        except Exception as e:  # noqa: BLE001
                            conn.execute("UPDATE notificaciones.registro_envio SET estado = 'FALLIDO', detalle = %s "
                                         "WHERE id_envio = %s", (f"{type(e).__name__}: {e}"[:1000], fila["id_envio"]))
                            r["fallidos"] += 1
                            try:
                                if smtp is not None:
                                    smtp.quit()
                            except Exception:  # noqa: BLE001
                                pass
                            smtp = None
            finally:
                if smtp is not None:
                    try:
                        smtp.quit()
                    except Exception:  # noqa: BLE001
                        pass
        finally:
            conn.execute("SELECT pg_advisory_unlock(hashtext('sgsindical_notificaciones'))")
    return {"simulacro": simulacro, "fecha": hoy.isoformat(), "resumen": resumen, "vista_previa": vista_previa[:200]}
