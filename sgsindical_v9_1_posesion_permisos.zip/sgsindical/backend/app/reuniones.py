"""Reuniones de junta: convocatoria, asistencia de todos (directivos e invitados), orden del día,
decisiones, firma del acta y acta en PDF con huella SHA-256.

Las reglas (quién convoca, 12 horas de anticipación, hasta las 8:00 p. m., tipo ordinaria/extraordinaria,
quórum, firmas, aprobación en la siguiente reunión) están en la base de datos (db/02f); aquí solo se
orquesta y se genera el documento."""
from __future__ import annotations

import hashlib
import io
import json
import logging
import os
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo

from fastapi import APIRouter, BackgroundTasks, Body, Depends, HTTPException
from fastapi.responses import FileResponse, Response

from .config import config
from .crud import serializar
from .db import transaccion
from .notificaciones import fecha_larga, nombre_propio
from .seguridad import UsuarioActual, requiere

router = APIRouter(prefix="/api/reuniones", tags=["reuniones"])
log = logging.getLogger("sgsindical.reuniones")


# ---------------------------------------------------------------- correos inmediatos
def _enviar_correos(tipos: list[str]) -> None:
    """Envía ya los correos de convocatoria/cancelación. Si falla o no hay SMTP, la tarea programada
    de notificaciones los reintenta (cada envío queda en el registro de correos)."""
    if not (config.NOTIFICADOR_DATABASE_URL and config.SMTP_HOST and config.CORREO_REMITENTE):
        log.warning("Correos de reunión pendientes: falta configurar NOTIFICADOR_DATABASE_URL / SMTP.")
        return
    try:
        from . import notificaciones
        notificaciones.ejecutar(tipos=tipos)
    except Exception:  # noqa: BLE001
        log.exception("No se pudieron enviar los correos de reunión; se reintentarán en la tarea programada.")


# ---------------------------------------------------------------- consultas
def _nombre(f: dict, pref: str = "") -> str:
    return nombre_propio(f.get(pref + "primer_nombre"), f.get(pref + "segundo_nombre"),
                         f.get(pref + "primer_apellido"), f.get(pref + "segundo_apellido"))


def datos_acta(conn, id_reunion: int) -> dict:
    r = conn.execute("""
        SELECT r.*, e.nombre_estamento, e.tipo_estamento,
               gestion_documental.fn_inicio_reunion(r.fecha, r.hora_inicio) <= now() AS empezo,
               d.radicado_alfanumerico AS radicado, d.hash_sha256 AS hash_acta,
               pc.primer_nombre AS c_primer_nombre, pc.segundo_nombre AS c_segundo_nombre,
               pc.primer_apellido AS c_primer_apellido, pc.segundo_apellido AS c_segundo_apellido,
               ant.fecha AS fecha_acta_anterior, dant.radicado_alfanumerico AS radicado_acta_anterior
          FROM gestion_documental.reunion r
          JOIN gobernanza.estamento e ON e.id_estamento = r.id_estamento
          JOIN gobernanza.persona pc ON pc.id_persona = r.id_persona_convoca
          LEFT JOIN gestion_documental.documento d ON d.id_documento = r.id_documento_acta
          LEFT JOIN gestion_documental.reunion ant ON ant.id_reunion = r.id_reunion_acta_anterior
          LEFT JOIN gestion_documental.documento dant ON dant.id_documento = ant.id_documento_acta
         WHERE r.id_reunion = %s""", (id_reunion,)).fetchone()
    if not r:
        raise HTTPException(404, "La reunión no existe o está fuera de su ámbito territorial.")
    asistentes = conn.execute("""
        SELECT a.*, p.primer_nombre, p.segundo_nombre, p.primer_apellido, p.segundo_apellido,
               p.tipo_dni, p.dni
          FROM gestion_documental.reunion_asistente a
          LEFT JOIN gobernanza.persona p ON p.id_persona = a.id_persona
         WHERE a.id_reunion = %s
         ORDER BY a.calidad, (SELECT c.orden FROM gobernanza.cargo_directivo c WHERE c.nombre = a.cargo LIMIT 1) NULLS LAST,
                  a.id_asistente""", (id_reunion,)).fetchall()
    for a in asistentes:
        a["nombre"] = _nombre(a) if a["id_persona"] else a["nombre_invitado"]
        a["documento"] = f"{a['tipo_dni']} {a['dni']}" if a["id_persona"] else a["documento_invitado"]
    puntos = conn.execute("SELECT * FROM gestion_documental.reunion_punto WHERE id_reunion = %s ORDER BY orden",
                          (id_reunion,)).fetchall()
    decisiones = conn.execute("""
        SELECT dd.*, pt.orden AS orden_punto, p.primer_nombre, p.segundo_nombre, p.primer_apellido, p.segundo_apellido
          FROM gestion_documental.reunion_decision dd
          LEFT JOIN gestion_documental.reunion_punto pt ON pt.id_punto = dd.id_punto
          LEFT JOIN gobernanza.persona p ON p.id_persona = dd.id_persona_responsable
         WHERE dd.id_reunion = %s ORDER BY pt.orden NULLS LAST, dd.id_decision""", (id_reunion,)).fetchall()
    for d in decisiones:
        d["responsable"] = _nombre(d) if d["id_persona_responsable"] else None
    firmas = conn.execute("""
        SELECT f.*, p.primer_nombre, p.segundo_nombre, p.primer_apellido, p.segundo_apellido, u.nombre_usuario
          FROM gestion_documental.reunion_firma f
          JOIN gobernanza.persona p ON p.id_persona = f.id_persona
          JOIN seguridad.usuario u ON u.id_usuario = f.id_usuario
         WHERE f.id_reunion = %s ORDER BY f.rol""", (id_reunion,)).fetchall()
    for f in firmas:
        f["nombre"] = _nombre(f)
    mesa = conn.execute("SELECT * FROM gestion_documental.fn_cargo_mesa(%s)", (r["id_estamento"],)).fetchone()

    directivos = [a for a in asistentes if a["calidad"] == "DIRECTIVO"]
    presentes = sum(1 for a in directivos if a["asistio"])
    requerido = len(directivos) // 2 + 1
    convocado = [p["tema"] for p in r["orden_del_dia_convocado"]]
    tratado = [p["tema"] for p in puntos]
    r["convoca"] = _nombre(r, "c_")
    return {
        "reunion": r,
        "asistentes": asistentes,
        "puntos": puntos,
        "decisiones": decisiones,
        "firmas": firmas,
        "quorum": {"directivos": len(directivos), "asistentes": presentes, "requerido": requerido,
                   "hay_quorum": presentes >= requerido if directivos else False,
                   "invitados": sum(1 for a in asistentes if a["calidad"] == "INVITADO" and a["asistio"])},
        "orden_del_dia_modificado": convocado != tratado,
        "mi_firma": mesa["rol"] if mesa and mesa["rol"] else None,
        "ya_firme": bool(mesa and mesa["rol"] and any(f["rol"] == mesa["rol"] for f in firmas)),
    }


@router.get("/convocables")
def juntas_convocables(usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    """Juntas en las que el usuario es Presidente o Secretario General vigente (puede convocar)."""
    with transaccion(usuario) as conn:
        filas = conn.execute("""
            SELECT e.id_estamento, e.nombre_estamento, c.nombre AS cargo
              FROM seguridad.usuario u
              JOIN gobernanza.directivo_estamento d ON d.id_persona = u.id_persona AND d.fecha_retiro IS NULL
                                                   AND d.fecha_posesion_individual <= CURRENT_DATE
              JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
              JOIN gobernanza.estamento e ON e.id_estamento = d.id_estamento
             WHERE u.id_usuario = %s AND (c.codigo LIKE 'PRES\\_%%' OR c.codigo LIKE 'SGEN\\_%%')
             ORDER BY e.nombre_estamento""", (usuario.id_usuario,)).fetchall()
        ahora = conn.execute("SELECT (now() AT TIME ZONE %s) AS ahora", (config.ZONA_HORARIA,)).fetchone()["ahora"]
    return {"juntas": [serializar(f) for f in filas], "ahora_local": ahora.isoformat(timespec="minutes"),
            "hora_maxima": "20:00", "horas_anticipacion": 12}


@router.post("/convocar", status_code=201)
def convocar(tareas: BackgroundTasks, datos: dict[str, Any] = Body(...),
             usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "registrar"))):
    orden = [str(p).strip() if not isinstance(p, dict) else str(p.get("tema", "")).strip()
             for p in (datos.get("orden_del_dia") or [])]
    orden = [p for p in orden if p]
    for c, etiqueta in (("id_estamento", "la junta"), ("fecha", "la fecha"), ("hora_inicio", "la hora de inicio")):
        if not datos.get(c):
            raise HTTPException(400, f"Indique {etiqueta}.")
    with transaccion(usuario) as conn:
        id_reunion = conn.execute(
            "SELECT gestion_documental.fn_convocar_reunion(%s, %s, %s, %s, %s, %s::jsonb) AS id",
            (datos["id_estamento"], datos["fecha"], datos["hora_inicio"], datos.get("modalidad") or "PRESENCIAL",
             datos.get("lugar") or "", json.dumps(orden))).fetchone()["id"]
        r = conn.execute("""SELECT id_reunion, tipo_reunion, fecha, hora_inicio,
                                   (SELECT count(*) FROM gestion_documental.reunion_asistente a
                                     WHERE a.id_reunion = r.id_reunion AND a.calidad = 'DIRECTIVO') AS convocados
                              FROM gestion_documental.reunion r WHERE id_reunion = %s""", (id_reunion,)).fetchone()
    tareas.add_task(_enviar_correos, ["CONVOCATORIA"])
    return serializar(r)


@router.post("/{id_reunion}/cancelar")
def cancelar(id_reunion: int, tareas: BackgroundTasks, datos: dict[str, Any] = Body(...),
             usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "actualizar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gestion_documental.fn_cancelar_reunion(%s, %s)", (id_reunion, datos.get("motivo") or ""))
    tareas.add_task(_enviar_correos, ["CANCELACION_REUNION"])
    return {"cancelada": True}


@router.get("/{id_reunion}/acta")
def acta(id_reunion: int, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        return serializar(datos_acta(conn, id_reunion))


@router.put("/{id_reunion}/asistencia")
def registrar_asistencia(id_reunion: int, datos: dict[str, Any] = Body(...),
                         usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "actualizar"))):
    """Guarda en una sola transacción la asistencia de varias personas (todo o nada).
    Cada fila lleva su versión: si otro usuario la cambió, se rechaza el lote (409)."""
    filas = datos.get("filas") or []
    campos = ("asistio", "modalidad_asistencia", "hora_llegada", "hora_salida", "excusa", "cargo")
    with transaccion(usuario) as conn:
        for f in filas:
            valores = {c: (f.get(c).strip() or None) if isinstance(f.get(c), str) else f.get(c) for c in campos if c in f}
            if not valores.get("asistio"):
                valores.update(modalidad_asistencia=None, hora_llegada=None, hora_salida=None)
            else:
                valores["excusa"] = None
            sets = ", ".join(f"{c} = %({c})s" for c in valores)
            res = conn.execute(
                f"""UPDATE gestion_documental.reunion_asistente SET {sets}
                     WHERE id_asistente = %(id)s AND id_reunion = %(reunion)s AND version = %(version)s RETURNING id_asistente""",
                {**valores, "id": f["id_asistente"], "reunion": id_reunion, "version": f.get("version")}).fetchone()
            if not res:
                raise HTTPException(409, {"mensaje": "Otro usuario actualizó la asistencia mientras usted la editaba. "
                                                     "Recargue y vuelva a marcarla."})
        return serializar(datos_acta(conn, id_reunion))


# ---------------------------------------------------------------- firma y PDF
@router.post("/{id_reunion}/firmar")
def firmar(id_reunion: int, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "actualizar"))):
    with transaccion(usuario) as conn:
        resultado = conn.execute("SELECT gestion_documental.fn_firmar_acta(%s) AS r", (id_reunion,)).fetchone()["r"]
        if resultado == "CERRADA":
            d = datos_acta(conn, id_reunion)
            pdf = generar_pdf(d)
            huella = hashlib.sha256(pdf).hexdigest()
            r = d["reunion"]
            config.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
            final = config.UPLOAD_DIR / f"{r['radicado']}_{huella[:12]}.pdf"
            nombre = f"Acta_{r['radicado']}.pdf"
            conn.execute("""UPDATE gestion_documental.documento SET nombre_archivo_adjunto = %s, hash_sha256 = %s
                             WHERE id_documento = %s""", (nombre, huella, r["id_documento_acta"]))
            final.write_bytes(pdf)
            try:
                os.chmod(final, 0o440)
            except OSError:
                pass
            return {"estado": "CERRADA", "mensaje": f"Acta cerrada y radicada con el número {r['radicado']}.",
                    "radicado": r["radicado"], "id_documento": r["id_documento_acta"], "hash_sha256": huella}
    return {"estado": "PENDIENTE", "mensaje": resultado.removeprefix("PENDIENTE: ")}


@router.get("/{id_reunion}/pdf")
def descargar_pdf(id_reunion: int, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    """Acta cerrada: el PDF radicado (verificando su huella). Acta en elaboración: borrador al vuelo."""
    with transaccion(usuario) as conn:
        d = datos_acta(conn, id_reunion)
    r = d["reunion"]
    if r["hash_acta"]:
        ruta = config.UPLOAD_DIR / f"{r['radicado']}_{r['hash_acta'][:12]}.pdf"
        if not ruta.is_file():
            raise HTTPException(410, "El archivo del acta no se encuentra en el repositorio documental.")
        h = hashlib.sha256(ruta.read_bytes()).hexdigest()
        if h != r["hash_acta"]:
            raise HTTPException(409, "ALERTA DE INTEGRIDAD: el archivo del acta fue alterado (la huella SHA-256 no coincide).")
        return FileResponse(ruta, media_type="application/pdf", filename=f"Acta_{r['radicado']}.pdf")
    if r["estado"] == "CANCELADA":
        raise HTTPException(400, "La reunión fue cancelada: no tiene acta.")
    return Response(generar_pdf(d), media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="Borrador_acta_reunion_{id_reunion}.pdf"'})


def _hora(t) -> str:
    if not t:
        return "—"
    h = t.hour % 12 or 12
    return f"{h}:{t.minute:02d} {'a. m.' if t.hour < 12 else 'p. m.'}"


def generar_pdf(d: dict) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import LETTER
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    from xml.sax.saxutils import escape as e

    r, q = d["reunion"], d["quorum"]
    borrador = r["estado"] == "CONVOCADA"
    est = getSampleStyleSheet()
    normal = ParagraphStyle("n", parent=est["Normal"], fontName="Helvetica", fontSize=9.5, leading=13)
    peq = ParagraphStyle("p", parent=normal, fontSize=8.5, leading=11)
    titulo = ParagraphStyle("t", parent=normal, fontName="Helvetica-Bold", fontSize=13, leading=17, alignment=TA_CENTER)
    sub = ParagraphStyle("s", parent=normal, alignment=TA_CENTER, textColor=colors.HexColor("#444444"))
    h2 = ParagraphStyle("h", parent=normal, fontName="Helvetica-Bold", fontSize=10.5, spaceBefore=10, spaceAfter=4,
                        textColor=colors.HexColor("#1f3a5f"))

    def tabla(cab, filas, anchos):
        datos = [[Paragraph(f"<b>{e(c)}</b>", peq) for c in cab]] + [[Paragraph(e(str(v)), peq) for v in f] for f in filas]
        t = Table(datos, colWidths=[a * cm for a in anchos], repeatRows=1)
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8eef5")),
                               ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#b8c2cf")),
                               ("VALIGN", (0, 0), (-1, -1), "TOP"),
                               ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
        return t

    hist = []
    hist.append(Paragraph(e(config.SINDICATO_NOMBRE.upper()), titulo))
    hist.append(Paragraph(e(r["nombre_estamento"]), sub))
    num = f"ACTA N.º {r['radicado']}" if r.get("radicado") else "BORRADOR DE ACTA (SIN RADICAR)"
    hist.append(Spacer(1, 6))
    hist.append(Paragraph(f"{e(num)}<br/>REUNIÓN {e(r['tipo_reunion'])}", titulo))
    hist.append(Spacer(1, 8))
    fecha = r["fecha"] if not isinstance(r["fecha"], str) else datetime.fromisoformat(r["fecha"]).date()
    filas_info = [
        ["Fecha", fecha_larga(fecha)],
        ["Hora", f"{_hora(r['hora_inicio'])} a {_hora(r['hora_fin'])}" if r["hora_fin"] else f"Desde las {_hora(r['hora_inicio'])}"],
        ["Modalidad", r["modalidad"].capitalize()],
        ["Lugar o enlace", r["lugar"]],
        ["Convocó", f"{r['convoca']}, {r['cargo_convoca']}, el "
                    f"{r['fecha_convocatoria'].astimezone(ZoneInfo(config.ZONA_HORARIA)):%Y-%m-%d %H:%M}"],
    ]
    hist.append(_info(filas_info, peq, cm, Table, TableStyle, colors))

    # Asistencia
    directivos = [a for a in d["asistentes"] if a["calidad"] == "DIRECTIVO"]
    invitados = [a for a in d["asistentes"] if a["calidad"] == "INVITADO"]

    def estado_asistencia(a):
        if a["asistio"]:
            partes = [(a["modalidad_asistencia"] or "").capitalize() or "Asistió"]
            if a["hora_llegada"]:
                partes.append(f"llegó {_hora(a['hora_llegada'])}")
            if a["hora_salida"]:
                partes.append(f"salió {_hora(a['hora_salida'])}")
            return ", ".join(partes)
        return f"Excusado: {a['excusa']}" if a["excusa"] else "No asistió"

    hist.append(Paragraph("1. Asistencia de directivos", h2))
    hist.append(tabla(["Directivo", "Documento", "Cargo", "Asistencia"],
                      [[a["nombre"], a["documento"] or "", a["cargo"] or "", estado_asistencia(a)] for a in directivos],
                      [5, 3, 4.5, 4.5]))
    hist.append(Spacer(1, 4))
    hist.append(Paragraph(
        f"Directivos vigentes: <b>{q['directivos']}</b>. Asistentes: <b>{q['asistentes']}</b>. "
        f"Quórum requerido (mitad más uno): <b>{q['requerido']}</b>. "
        + ("<b>HAY QUÓRUM</b> para deliberar y decidir." if q["hay_quorum"]
           else "<b>NO HAY QUÓRUM</b>: no se adoptan decisiones y esta reunión no cuenta como la reunión del mes."), normal))
    hist.append(Paragraph("2. Invitados", h2))
    if invitados:
        hist.append(tabla(["Invitado", "Documento", "Institución / cargo", "Asistencia"],
                          [[a["nombre"], a["documento"] or "",
                            " — ".join(x for x in (a["institucion"], a["cargo"]) if x), estado_asistencia(a)] for a in invitados],
                          [5, 3, 4.5, 4.5]))
        hist.append(Paragraph("Los invitados participan con voz pero sin voto y no cuentan para el quórum.", peq))
    else:
        hist.append(Paragraph("No hubo invitados.", normal))

    # Acta anterior
    hist.append(Paragraph("3. Acta anterior", h2))
    if r.get("id_reunion_acta_anterior") or r.get("fecha_acta_anterior"):
        txt = f"Acta de la reunión del {r['fecha_acta_anterior']}" + (f" (N.º {r['radicado_acta_anterior']})" if r.get("radicado_acta_anterior") else "")
        txt += ": " + ("se aprueba." if r["aprueba_acta_anterior"] and q["hay_quorum"] else "no se aprueba en esta reunión.")
    else:
        txt = ("Se someterá a aprobación el acta anterior pendiente de la junta." if borrador
               else "No había acta anterior pendiente de aprobación.")
    hist.append(Paragraph(e(txt), normal))
    if r.get("observaciones_acta_anterior"):
        hist.append(Paragraph("Observaciones: " + e(r["observaciones_acta_anterior"]), normal))

    # Orden del día
    hist.append(Paragraph("4. Orden del día y desarrollo", h2))
    if d["orden_del_dia_modificado"]:
        conv = "; ".join(f"{p['orden']}. {p['tema']}" for p in r["orden_del_dia_convocado"])
        hist.append(Paragraph("<i>El orden del día se modificó al iniciar la reunión. Orden del día convocado: "
                              + e(conv) + "</i>", peq))
        hist.append(Spacer(1, 3))
    for p in d["puntos"]:
        hist.append(Paragraph(f"<b>{p['orden']}. {e(p['tema'])}</b>", normal))
        if p["desarrollo"]:
            hist.append(Paragraph(e(p["desarrollo"]).replace("\n", "<br/>"), normal))
        hist.append(Spacer(1, 3))

    # Decisiones
    hist.append(Paragraph("5. Decisiones", h2))
    if d["decisiones"]:
        hist.append(tabla(["Punto", "Decisión", "Votos (F/C/A)", "Resultado", "Compromiso"],
                          [[str(x["orden_punto"] or "—"), x["texto"],
                            f"{x['votos_favor']} / {x['votos_contra']} / {x['abstenciones']}",
                            "Aprobada" if x["aprobada"] else "No aprobada",
                            (f"{x['compromiso_titulo']} — {x['responsable']}, hasta {x['fecha_limite']}" if x["compromiso_titulo"] else "—")]
                           for x in d["decisiones"]], [1.3, 6.2, 2.3, 2.2, 5]))
    else:
        hist.append(Paragraph("No se adoptaron decisiones.", normal))

    # Firmas
    hist.append(Spacer(1, 14))
    celdas = []
    for rol, etiqueta in (("PRESIDENCIA", "Presidencia"), ("SECRETARIA", "Secretaría General")):
        f = next((x for x in d["firmas"] if x["rol"] == rol), None)
        if f:
            fecha_f = f["fecha"].astimezone(ZoneInfo(config.ZONA_HORARIA)) if not isinstance(f["fecha"], str) else f["fecha"]
            celdas.append(Paragraph(f"<b>{e(f['nombre'])}</b><br/>{e(f['cargo'])}<br/>"
                                    f"Firmado electrónicamente por el usuario {e(f['nombre_usuario'])}<br/>{fecha_f:%Y-%m-%d %H:%M}", peq))
        else:
            celdas.append(Paragraph(f"<br/><br/>______________________________<br/>{etiqueta}<br/>(firma pendiente)", peq))
    t = Table([celdas], colWidths=[8.5 * cm, 8.5 * cm])
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")]))
    hist.append(KeepTogether([Paragraph("Firmas", h2), t]))

    buf = io.BytesIO()

    def pie(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 7.5)
        canvas.setFillColor(colors.HexColor("#666666"))
        canvas.drawString(2 * cm, 1.2 * cm, f"{config.SINDICATO_NOMBRE} · SGSINDICAL · {num}")
        canvas.drawRightString(LETTER[0] - 2 * cm, 1.2 * cm, f"Página {doc.page}")
        if borrador:
            canvas.setFont("Helvetica-Bold", 60)
            canvas.setFillColor(colors.Color(0.85, 0.2, 0.2, alpha=0.12))
            canvas.translate(LETTER[0] / 2, LETTER[1] / 2)
            canvas.rotate(40)
            canvas.drawCentredString(0, 0, "BORRADOR")
        canvas.restoreState()

    doc = SimpleDocTemplate(buf, pagesize=LETTER, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm,
                            bottomMargin=2 * cm, title=num, author=config.SINDICATO_NOMBRE,
                            subject=f"Acta de reunión de {r['nombre_estamento']}")
    doc.build(hist, onFirstPage=pie, onLaterPages=pie)
    return buf.getvalue()


def _info(filas, estilo, cm, Table, TableStyle, colors):
    from reportlab.platypus import Paragraph
    from xml.sax.saxutils import escape as e
    t = Table([[Paragraph(f"<b>{e(a)}</b>", estilo), Paragraph(e(str(b)), estilo)] for a, b in filas],
              colWidths=[3.5 * cm, 13.5 * cm])
    t.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, -1), 0.3, colors.HexColor("#d5dbe3")),
                           ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    return t
