"""Operaciones especiales: archivos con huella SHA-256, aportes del 0.7%, administración y backups."""
from __future__ import annotations

import psycopg

import hashlib
import os
import re
import shutil
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import APIRouter, Body, Depends, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from psycopg.conninfo import conninfo_to_dict, make_conninfo

from .config import config
from .crud import serializar
from .db import transaccion
from .seguridad import UsuarioActual, exigir_paso_adicional, hash_contrasena, requiere, validar_politica_contrasena

router = APIRouter(prefix="/api", tags=["operaciones"])

TIPOS_PERMITIDOS = {".pdf": "application/pdf"}
FIRMA_PDF = b"%PDF-"


def _sha256_archivo(ruta: Path) -> str:
    h = hashlib.sha256()
    with ruta.open("rb") as f:
        for bloque in iter(lambda: f.read(1024 * 1024), b""):
            h.update(bloque)
    return h.hexdigest()


# ============================================================ DOCUMENTOS: archivo PDF
@router.post("/documentos/{id_documento}/archivo")
async def subir_archivo(id_documento: int, archivo: UploadFile = File(...),
                        usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "actualizar"))):
    extension = Path(archivo.filename or "").suffix.lower()
    if extension not in TIPOS_PERMITIDOS:
        raise HTTPException(400, "Solo se admiten archivos PDF.")
    config.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    temporal = config.UPLOAD_DIR / f".subiendo_{id_documento}_{os.getpid()}_{datetime.now().timestamp()}"
    h, total, limite = hashlib.sha256(), 0, config.MAX_ARCHIVO_MB * 1024 * 1024
    try:
        with temporal.open("wb") as destino:
            primero = True
            while bloque := await archivo.read(1024 * 1024):
                if primero and not bloque.startswith(FIRMA_PDF):
                    raise HTTPException(400, "El archivo no es un PDF válido.")
                primero = False
                total += len(bloque)
                if total > limite:
                    raise HTTPException(413, f"El archivo supera el máximo de {config.MAX_ARCHIVO_MB} MB.")
                h.update(bloque)
                destino.write(bloque)
        huella = h.hexdigest()
        nombre_seguro = re.sub(r"[^\w.\- ]", "_", Path(archivo.filename or "documento.pdf").name)[:150]
        with transaccion(usuario) as conn:
            doc = conn.execute("""SELECT radicado_alfanumerico, hash_sha256 FROM gestion_documental.documento
                                   WHERE id_documento = %s FOR UPDATE""", (id_documento,)).fetchone()
            if not doc:
                raise HTTPException(404, "El documento no existe.")
            if doc["hash_sha256"]:
                raise HTTPException(409, "Este documento ya tiene un archivo con huella SHA-256; por integridad no se reemplaza.")
            final = config.UPLOAD_DIR / f"{doc['radicado_alfanumerico']}_{huella[:12]}.pdf"
            conn.execute("""UPDATE gestion_documental.documento SET nombre_archivo_adjunto = %s, hash_sha256 = %s
                             WHERE id_documento = %s""", (nombre_seguro, huella, id_documento))
            shutil.move(str(temporal), final)  # se mueve dentro de la transacción: si falla, se revierte
            try:
                os.chmod(final, 0o440)
            except OSError:
                pass
        return {"hash_sha256": huella, "tamano_bytes": total, "nombre_archivo_adjunto": nombre_seguro}
    finally:
        if temporal.exists():
            temporal.unlink(missing_ok=True)


def _ruta_archivo(conn, id_documento: int) -> tuple[Path, dict]:
    doc = conn.execute("""SELECT radicado_alfanumerico, hash_sha256, nombre_archivo_adjunto
                            FROM gestion_documental.documento WHERE id_documento = %s""", (id_documento,)).fetchone()
    if not doc or not doc["hash_sha256"]:
        raise HTTPException(404, "El documento no tiene archivo adjunto.")
    ruta = config.UPLOAD_DIR / f"{doc['radicado_alfanumerico']}_{doc['hash_sha256'][:12]}.pdf"
    if not ruta.is_file():
        raise HTTPException(410, "El archivo no se encuentra en el repositorio documental.")
    return ruta, doc


@router.get("/documentos/{id_documento}/verificar")
def verificar_archivo(id_documento: int, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        ruta, doc = _ruta_archivo(conn, id_documento)
    actual = _sha256_archivo(ruta)
    return {"integro": actual == doc["hash_sha256"], "hash_registrado": doc["hash_sha256"], "hash_actual": actual}


@router.get("/documentos/{id_documento}/archivo")
def descargar_archivo(id_documento: int, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        ruta, doc = _ruta_archivo(conn, id_documento)
    if _sha256_archivo(ruta) != doc["hash_sha256"]:
        raise HTTPException(409, "ALERTA DE INTEGRIDAD: el archivo fue alterado (la huella SHA-256 no coincide).")
    return FileResponse(ruta, media_type="application/pdf", filename=doc["nombre_archivo_adjunto"] or ruta.name)


# ============================================================ FINANZAS: aportes del 0.7%
@router.post("/consignaciones/{id_consignacion}/generar-aportes")
def generar_aportes(id_consignacion: int, solo_junta: bool = False,
                    usuario: UsuarioActual = Depends(requiere("FINANZAS", "registrar"))):
    """Crea el aporte (0.7 % por defecto) del salario VIGENTE en ese mes de cada afiliado de la empresa que aún no
    tenga aporte en ese mes (aunque la empresa haya repartido el pago entre la cuenta nacional y una subcuenta).
    solo_junta=true: solo los afiliados que pertenecen a la junta dueña de la subcuenta."""
    with transaccion(usuario) as conn:
        n = conn.execute("SELECT finanzas.fn_generar_aportes(%s, %s) AS n", (id_consignacion, solo_junta)).fetchone()["n"]
        resumen = conn.execute("SELECT * FROM finanzas.v_auditoria_armonizacion_aportes WHERE id_consignacion = %s",
                               (id_consignacion,)).fetchone()
    return {"aportes_creados": n, "conciliacion": serializar(resumen)}


# ============================================================ ADMINISTRACIÓN: usuarios y sesiones
@router.post("/admin/usuarios/{id_usuario}/restablecer-contrasena")
def restablecer_contrasena(id_usuario: int, datos: dict = Body(...),
                           usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "actualizar"))):
    with transaccion(usuario) as conn:
        u = conn.execute("SELECT nombre_usuario FROM seguridad.usuario WHERE id_usuario = %s FOR UPDATE",
                         (id_usuario,)).fetchone()
        if not u:
            raise HTTPException(404, "Usuario no encontrado.")
        validar_politica_contrasena(datos.get("contrasena", ""), u["nombre_usuario"])
        conn.execute("""UPDATE seguridad.usuario SET hash_contrasena = %s, debe_cambiar_contrasena = TRUE,
                               intentos_fallidos = 0, bloqueado_hasta = NULL, fecha_cambio_contrasena = now()
                         WHERE id_usuario = %s""", (hash_contrasena(datos["contrasena"]), id_usuario))
        conn.execute("SELECT seguridad.fn_revocar_sesiones_usuario(%s, FALSE)", (id_usuario,))
        conn.execute("INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, ip_origen, detalle) "
                     "VALUES (%s, 'CAMBIO_CONTRASENA', %s, %s)",
                     (u["nombre_usuario"], usuario.ip, f"restablecida por {usuario.nombre_usuario}"))
    return {"ok": True}


@router.post("/admin/usuarios/{id_usuario}/desbloquear")
def desbloquear(id_usuario: int, usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "actualizar"))):
    with transaccion(usuario) as conn:
        n = conn.execute("""UPDATE seguridad.usuario SET intentos_fallidos = 0, bloqueado_hasta = NULL
                             WHERE id_usuario = %s""", (id_usuario,)).rowcount
    if not n:
        raise HTTPException(404, "Usuario no encontrado.")
    return {"ok": True}


@router.get("/admin/sesiones")
def sesiones_activas(usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "consultar"))):
    with transaccion(usuario) as conn:
        filas = conn.execute(
            """SELECT s.id_sesion, u.nombre_usuario, u.nombre_completo, u.codigo_rol, s.fecha_emision,
                      s.ultima_actividad, s.fecha_expiracion, s.ip_origen, s.equipo,
                      (s.id_sesion = %s) AS es_la_mia
                 FROM seguridad.sesion s JOIN seguridad.usuario u ON u.id_usuario = s.id_usuario
                WHERE NOT s.revocada AND s.fecha_expiracion > now()
                  AND s.ultima_actividad > now() - make_interval(mins => %s)
                ORDER BY s.ultima_actividad DESC""",
            (usuario.id_sesion, config.INACTIVIDAD_MINUTOS)).fetchall()
    return [serializar(f) for f in filas]


@router.post("/admin/sesiones/{id_sesion}/revocar")
def revocar_sesion(id_sesion: str, usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "actualizar"))):
    with transaccion(usuario) as conn:
        try:
            nombre = conn.execute("SELECT seguridad.fn_revocar_sesion(%s::uuid) AS n", (id_sesion,)).fetchone()["n"]
        except psycopg.errors.InvalidTextRepresentation:
            raise HTTPException(404, "Sesión no encontrada.")
        fila = {"nombre_usuario": nombre} if nombre else None
        if not fila:
            raise HTTPException(404, "Sesión no encontrada.")
        conn.execute("INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, ip_origen, detalle) "
                     "VALUES (%s, 'SESION_REVOCADA', %s, %s)",
                     (fila["nombre_usuario"], usuario.ip, f"revocada por {usuario.nombre_usuario}"))
    return {"ok": True}


# ============================================================ ADMINISTRACIÓN: backups
PATRON_BACKUP = re.compile(r"^sgsindical_\d{8}_\d{6}\.dump$")


def ejecutar_backup(origen: str, usuario_nombre: str, ip: str | None = None) -> dict:
    """pg_dump en formato personalizado (comprimido, restaurable con pg_restore), con huella SHA-256,
    registro en auditoría y aplicación de la política de retención."""
    if not config.BACKUP_DATABASE_URL:
        raise HTTPException(503, "Backups no configurados: defina BACKUP_DATABASE_URL (rol sgs_backup) en el .env.")
    if not shutil.which(config.PG_DUMP) and not Path(config.PG_DUMP).is_file():
        raise HTTPException(503, f"No se encontró pg_dump ('{config.PG_DUMP}'). Configure PG_DUMP en el .env.")
    config.BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    inicio = datetime.now(timezone.utc)
    nombre = f"sgsindical_{datetime.now().strftime('%Y%m%d_%H%M%S')}.dump"
    ruta = config.BACKUP_DIR / nombre
    # La contraseña va por variable de entorno, no en la línea de comandos (no queda visible en el sistema)
    info = conninfo_to_dict(config.BACKUP_DATABASE_URL)
    entorno = dict(os.environ)
    if info.get("password"):
        entorno["PGPASSWORD"] = str(info.pop("password"))
    proc = subprocess.run([config.PG_DUMP, "--format=custom", "--compress=6", "--no-owner",
                           f"--file={ruta}", f"--dbname={make_conninfo(**info)}"],
                          capture_output=True, text=True, timeout=3600, env=entorno)
    exito = proc.returncode == 0 and ruta.is_file()
    tamano = ruta.stat().st_size if exito else None
    huella = _sha256_archivo(ruta) if exito else None
    if exito:
        ruta.with_suffix(".sha256").write_text(f"{huella}  {nombre}\n", encoding="utf-8")
    borrados = _aplicar_retencion() if exito else []
    detalle = (proc.stderr or "").strip()[:1500] or (f"Retención: {len(borrados)} backup(s) antiguo(s) eliminado(s)."
                                                     if borrados else None)
    with transaccion(usuario_nombre, ip) as conn:
        conn.execute("""INSERT INTO auditoria.registro_backup (nombre_archivo, origen, estado, tamano_bytes, hash_sha256,
                                                             fecha_inicio, detalle)
                        VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                     (nombre, origen, "EXITOSO" if exito else "FALLIDO", tamano, huella, inicio, detalle))
    if not exito:
        raise HTTPException(500, "El backup falló: " + (proc.stderr or "error desconocido")[:500])
    return {"archivo": nombre, "tamano_bytes": tamano, "hash_sha256": huella, "eliminados_por_retencion": borrados}


def _aplicar_retencion() -> list[str]:
    limite = datetime.now() - timedelta(days=config.BACKUP_RETENCION_DIAS)
    archivos = sorted(p for p in config.BACKUP_DIR.glob("sgsindical_*.dump") if PATRON_BACKUP.match(p.name))
    borrados = []
    for p in archivos[:-3]:  # siempre se conservan al menos los 3 más recientes
        if datetime.fromtimestamp(p.stat().st_mtime) < limite:
            p.unlink(missing_ok=True)
            p.with_suffix(".sha256").unlink(missing_ok=True)
            borrados.append(p.name)
    return borrados


@router.get("/admin/backups")
def listar_backups(usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "consultar"))):
    archivos = []
    if config.BACKUP_DIR.is_dir():
        for p in sorted(config.BACKUP_DIR.glob("sgsindical_*.dump"), reverse=True):
            if PATRON_BACKUP.match(p.name):
                archivos.append({"archivo": p.name, "tamano_bytes": p.stat().st_size,
                                 "fecha": datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds")})
    return {
        "configurado": bool(config.BACKUP_DATABASE_URL),
        "directorio": str(config.BACKUP_DIR),
        "retencion_dias": config.BACKUP_RETENCION_DIAS,
        "archivos": archivos,
    }


@router.post("/admin/backups")
def crear_backup(usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "registrar"))):
    return ejecutar_backup("MANUAL", usuario.nombre_usuario, usuario.ip)


@router.get("/admin/backups/{archivo}/verificar")
def verificar_backup(archivo: str, usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "consultar"))):
    if not PATRON_BACKUP.match(archivo):
        raise HTTPException(400, "Nombre de archivo no válido.")
    ruta = config.BACKUP_DIR / archivo
    if not ruta.is_file():
        raise HTTPException(404, "Backup no encontrado.")
    with transaccion(usuario) as conn:
        reg = conn.execute("SELECT hash_sha256 FROM auditoria.registro_backup WHERE nombre_archivo = %s "
                           "AND estado = 'EXITOSO' ORDER BY id_backup DESC LIMIT 1", (archivo,)).fetchone()
    actual = _sha256_archivo(ruta)
    return {"integro": bool(reg) and reg["hash_sha256"] == actual, "hash_registrado": reg and reg["hash_sha256"],
            "hash_actual": actual}


# ============================================================ ADMINISTRACIÓN: correos automáticos
@router.get("/admin/notificaciones")
def estado_notificaciones(usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "consultar"))):
    with transaccion(usuario) as conn:
        tipos = conn.execute("SELECT * FROM notificaciones.tipo_notificacion ORDER BY codigo").fetchall()
        ultimos = conn.execute("""SELECT codigo_tipo, estado, count(*) AS n, max(fecha_creacion) AS ultima
                                    FROM notificaciones.registro_envio
                                   WHERE fecha_creacion > now() - INTERVAL '30 days'
                                   GROUP BY codigo_tipo, estado""").fetchall()
    return {
        "base_configurada": bool(config.NOTIFICADOR_DATABASE_URL),
        "smtp_configurado": bool(config.SMTP_HOST and config.CORREO_REMITENTE),
        "remitente": config.CORREO_REMITENTE, "servidor": config.SMTP_HOST,
        "tipos": [serializar(t) for t in tipos], "ultimos_30_dias": [serializar(u) for u in ultimos],
    }


@router.post("/admin/notificaciones/ejecutar")
def ejecutar_notificaciones(simulacro: bool = True, usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "actualizar"))):
    from .notificaciones import ErrorConfiguracion, ejecutar
    try:
        r = ejecutar(simulacro=simulacro)
    except ErrorConfiguracion as e:
        raise HTTPException(503, str(e))
    return serializar(r)


# ============================================================ FINANZAS: egresos, cierres
def _soporte_ruta(id_egreso: int, huella: str) -> Path:
    return config.UPLOAD_DIR / "egresos" / f"egreso_{id_egreso}_{huella[:12]}.pdf"


@router.post("/egresos/{id_egreso}/soporte")
async def subir_soporte_egreso(id_egreso: int, archivo: UploadFile = File(...),
                               usuario: UsuarioActual = Depends(requiere("FINANZAS", "actualizar"))):
    if Path(archivo.filename or "").suffix.lower() != ".pdf":
        raise HTTPException(400, "El soporte debe ser un PDF (factura o cuenta de cobro).")
    contenido = await archivo.read(config.MAX_ARCHIVO_MB * 1024 * 1024 + 1)
    if len(contenido) > config.MAX_ARCHIVO_MB * 1024 * 1024:
        raise HTTPException(413, f"El archivo supera el máximo de {config.MAX_ARCHIVO_MB} MB.")
    if not contenido.startswith(FIRMA_PDF):
        raise HTTPException(400, "El archivo no es un PDF válido.")
    huella = hashlib.sha256(contenido).hexdigest()
    nombre = re.sub(r"[^\w.\- ]", "_", Path(archivo.filename or "soporte.pdf").name)[:150]
    with transaccion(usuario) as conn:
        e = conn.execute("SELECT estado, hash_soporte FROM finanzas.egreso WHERE id_egreso = %s FOR UPDATE", (id_egreso,)).fetchone()
        if not e:
            raise HTTPException(404, "El egreso no existe o está fuera de su ámbito.")
        if e["hash_soporte"]:
            raise HTTPException(409, "El egreso ya tiene un soporte con huella SHA-256; por integridad no se reemplaza.")
        conn.execute("UPDATE finanzas.egreso SET nombre_archivo_soporte = %s, hash_soporte = %s WHERE id_egreso = %s",
                     (nombre, huella, id_egreso))
        ruta = _soporte_ruta(id_egreso, huella)
        ruta.parent.mkdir(parents=True, exist_ok=True)
        ruta.write_bytes(contenido)
    return {"hash_sha256": huella, "nombre_archivo_soporte": nombre}


@router.get("/egresos/{id_egreso}/soporte")
def descargar_soporte_egreso(id_egreso: int, usuario: UsuarioActual = Depends(requiere("FINANZAS", "consultar"))):
    with transaccion(usuario) as conn:
        e = conn.execute("SELECT hash_soporte, nombre_archivo_soporte FROM finanzas.egreso WHERE id_egreso = %s", (id_egreso,)).fetchone()
    if not e or not e["hash_soporte"]:
        raise HTTPException(404, "El egreso no tiene soporte.")
    ruta = _soporte_ruta(id_egreso, e["hash_soporte"])
    if not ruta.is_file():
        raise HTTPException(410, "El soporte no se encuentra en el repositorio.")
    if _sha256_archivo(ruta) != e["hash_soporte"]:
        raise HTTPException(409, "ALERTA DE INTEGRIDAD: el soporte fue alterado (la huella SHA-256 no coincide).")
    return FileResponse(ruta, media_type="application/pdf", filename=e["nombre_archivo_soporte"] or ruta.name)


@router.post("/egresos/{id_egreso}/aprobar")
def aprobar_egreso(id_egreso: int, usuario: UsuarioActual = Depends(requiere("FINANZAS", "consultar"))):
    """Firma del Tesorero o del Presidente de la junta. La base de datos verifica el cargo, el soporte,
    el presupuesto y los fondos; con la segunda firma el egreso queda APROBADO."""
    with transaccion(usuario) as conn:
        r = conn.execute("SELECT finanzas.fn_aprobar_egreso(%s) AS r", (id_egreso,)).fetchone()["r"]
        firmas = conn.execute("""SELECT rol, cargo, fecha FROM finanzas.egreso_aprobacion WHERE id_egreso = %s ORDER BY fecha""",
                              (id_egreso,)).fetchall()
    return {"resultado": r, "firmas": [serializar(f) for f in firmas]}


@router.post("/egresos/{id_egreso}/anular")
def anular_egreso(id_egreso: int, datos: dict = Body(...), usuario: UsuarioActual = Depends(requiere("FINANZAS", "consultar"))):
    with transaccion(usuario) as conn:
        r = conn.execute("SELECT finanzas.fn_anular_egreso(%s, %s) AS r", (id_egreso, datos.get("motivo", ""))).fetchone()["r"]
    return {"resultado": r}


@router.post("/finanzas/porcentajes/{tabla}/{id_registro}/corregir")
def corregir_porcentaje(tabla: str, id_registro: int, datos: dict = Body(...),
                        usuario: UsuarioActual = Depends(requiere("FINANZAS", "consultar"))):
    """Corrección de un error de digitación (solo el administrador, sin aportes generados)."""
    if tabla not in ("junta", "afiliado"):
        raise HTTPException(404, "Tipo no válido.")
    exigir_paso_adicional(usuario)
    with transaccion(usuario) as conn:
        r = conn.execute("SELECT finanzas.fn_corregir_porcentaje(%s, %s, %s, %s) AS r",
                         (f"porcentaje_{tabla}", id_registro, datos.get("porcentaje"), datos.get("motivo") or "")).fetchone()["r"]
    return {"resultado": r}


@router.post("/finanzas/exoneraciones/{id_exoneracion}/{decision}")
def decidir_exoneracion(id_exoneracion: int, decision: str, datos: dict = Body(...),
                        usuario: UsuarioActual = Depends(requiere("FINANZAS", "consultar"))):
    if decision not in ("aprobar", "negar"):
        raise HTTPException(404, "Acción no válida.")
    with transaccion(usuario) as conn:
        r = conn.execute("SELECT finanzas.fn_decidir_exoneracion(%s, %s, %s, %s) AS r",
                         (id_exoneracion, decision == "aprobar", datos.get("id_acta"), datos.get("observacion"))).fetchone()["r"]
    return {"estado": r}


@router.post("/afiliaciones/{id_solicitud}/{decision}")
def decidir_afiliacion(id_solicitud: int, decision: str, datos: dict = Body(...),
                       usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    """Aprueba (crea el afiliado, su empresa y su salario) o rechaza una solicitud de afiliación.
    Exige los documentos obligatorios aceptados; la de un disperso, el acta de la Junta Nacional (número o radicado).
    La fecha de afiliación es la de hoy; una anterior (desde la radicación) exige motivo_fecha."""
    if decision not in ("aprobar", "rechazar"):
        raise HTTPException(404, "Acción no válida.")
    from .afiliacion import _id_acta
    with transaccion(usuario) as conn:
        r = conn.execute("SELECT gobernanza.fn_decidir_solicitud_afiliacion(%s, %s, %s, %s, %s, %s) AS r",
                         (id_solicitud, decision == "aprobar", datos.get("fecha_afiliacion") or None, datos.get("observacion"),
                          _id_acta(conn, datos.get("acta") or datos.get("id_acta")), datos.get("motivo_fecha"))).fetchone()["r"]
    return {"estado": r}


@router.post("/finanzas/cierres")
def cerrar_mes(datos: dict = Body(...), usuario: UsuarioActual = Depends(requiere("FINANZAS", "consultar"))):
    try:
        args = (int(datos["id_estamento"]), int(datos["anio"]), int(datos["mes"]))
    except (KeyError, TypeError, ValueError):
        raise HTTPException(400, "Indique la junta, el año y el mes.")
    with transaccion(usuario) as conn:
        id_cierre = conn.execute("SELECT finanzas.fn_cerrar_mes(%s, %s, %s) AS id", args).fetchone()["id"]
        fila = conn.execute("SELECT * FROM finanzas.cierre_mes WHERE id_cierre = %s", (id_cierre,)).fetchone()
    return serializar(fila)


@router.post("/finanzas/cierres/{id_cierre}/reabrir")
def reabrir_mes(id_cierre: int, datos: dict = Body(...), usuario: UsuarioActual = Depends(requiere("FINANZAS", "consultar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT finanzas.fn_reabrir_mes(%s, %s)", (id_cierre, datos.get("motivo", "")))
    return {"ok": True}
