"""Estrategia de contenidos en redes: política de comunicaciones, calendario editorial y piezas educativas
sobre derechos laborales redactadas con IA, con revisión jurídica y de comunicaciones antes de publicar.

Las reglas (aprobaciones, versiones, publicación) están en la base (db/02i)."""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, BackgroundTasks, Body, Depends, HTTPException

from . import ia
from .config import config
from .crud import serializar
from .db import transaccion
from .seguridad import UsuarioActual, requiere

router = APIRouter(prefix="/api/contenidos", tags=["contenidos en redes"])
log = logging.getLogger("sgsindical.contenidos")
MAX_MATERIAL = 60_000


def _ia_lista() -> None:
    if config.IA_PROVEEDOR != "simulado" and not config.ANTHROPIC_API_KEY:
        raise HTTPException(503, "La redacción con IA no está configurada: falta ANTHROPIC_API_KEY en el archivo .env del servidor.")


def _mensaje_error(e: Exception) -> str:
    if isinstance(e, ia.ErrorIA):
        return str(e)
    log.exception("Falló la redacción con IA")
    return getattr(getattr(e, "diag", None), "message_primary", None) or f"{type(e).__name__}: {e}"


def _pieza(conn, id_pieza: int) -> dict:
    p = conn.execute("""
        SELECT p.*, e.nombre_estamento AS junta, x.nombre AS eje, f.nombre AS fecha_clave
          FROM gobernanza.pieza_contenido p
          JOIN gobernanza.estamento e ON e.id_estamento = p.id_estamento
          LEFT JOIN gobernanza.eje_tematico x ON x.codigo = p.codigo_eje
          LEFT JOIN gobernanza.fecha_clave f ON f.id_fecha = p.id_fecha_clave
         WHERE p.id_pieza = %s""", (id_pieza,)).fetchone()
    if not p:
        raise HTTPException(404, "La pieza no existe o está fuera de su ámbito territorial.")
    return p


def _politica_vigente(conn, id_estamento: int) -> str | None:
    pol = conn.execute("""SELECT texto, objetivos, publicos, mensajes_clave, tono, reglas FROM gobernanza.politica_comunicacion
                           WHERE id_estamento = %s AND vigente""", (id_estamento,)).fetchone()
    if not pol:
        return None
    partes = [f"{t}: {pol[c]}" for c, t in (("objetivos", "Objetivos"), ("publicos", "Públicos"), ("mensajes_clave", "Mensajes clave"),
                                            ("tono", "Tono"), ("reglas", "Reglas")) if pol[c]]
    if pol["texto"]:
        partes.append(pol["texto"][:12000])
    return "\n".join(partes) or None


# ---------------------------------------------------------------- piezas
@router.get("/piezas/{id_pieza}")
def detalle(id_pieza: int, usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    with transaccion(usuario) as conn:
        p = _pieza(conn, id_pieza)
        versiones = conn.execute("""SELECT numero, origen, modelo_ia, nombre_usuario, fecha, instrucciones FROM gobernanza.pieza_version
                                     WHERE id_pieza = %s ORDER BY numero DESC""", (id_pieza,)).fetchall()
        revisiones = conn.execute("""SELECT numero_version, rol, decision, comentario, nombre_usuario, cargo, fecha FROM gobernanza.pieza_revision
                                      WHERE id_pieza = %s ORDER BY fecha DESC, id_revision DESC""", (id_pieza,)).fetchall()
        publicaciones = conn.execute("""SELECT pp.*, c.red, c.usuario_cuenta FROM gobernanza.pieza_publicacion pp
                                          JOIN gobernanza.cuenta_red_social c ON c.id_cuenta_red = pp.id_cuenta_red
                                         WHERE pp.id_pieza = %s ORDER BY pp.fecha_publicacion""", (id_pieza,)).fetchall()
        cuentas = conn.execute("""SELECT id_cuenta_red, red, usuario_cuenta FROM gobernanza.cuenta_red_social
                                   WHERE id_estamento = %s AND estado = 'ACTIVA' ORDER BY red""", (p["id_estamento"],)).fetchall()
        mi = conn.execute("SELECT * FROM gobernanza.fn_rol_revision_pieza(%s)", (id_pieza,)).fetchone()
        tiene_politica = _politica_vigente(conn, p["id_estamento"]) is not None
    actuales = [r for r in revisiones if r["numero_version"] == p["version_actual"]]
    aprobaciones = {rol: next((r for r in actuales if r["rol"] == rol and r["decision"] == "APRUEBA"), None)
                    for rol in ("JURIDICA", "COMUNICACIONES")}
    return serializar({"pieza": p, "versiones": versiones, "revisiones": revisiones, "aprobaciones": aprobaciones,
                       "publicaciones": publicaciones, "cuentas": cuentas, "mi_rol": mi["rol"], "mi_cargo": mi["cargo"],
                       "tiene_politica": tiene_politica, "formatos": list(ia.FORMATOS),
                       "ia": {"proveedor": config.IA_PROVEEDOR, "modelo": config.IA_MODELO,
                              "configurada": config.IA_PROVEEDOR == "simulado" or bool(config.ANTHROPIC_API_KEY)}})


@router.get("/piezas/{id_pieza}/versiones/{numero}")
def version(id_pieza: int, numero: int, usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    with transaccion(usuario) as conn:
        v = conn.execute("SELECT * FROM gobernanza.pieza_version WHERE id_pieza = %s AND numero = %s", (id_pieza, numero)).fetchone()
    if not v:
        raise HTTPException(404, "La versión no existe.")
    return serializar(v)


def _redactar_pieza(id_pieza: int, base: int, datos: dict, usuario: UsuarioActual) -> None:
    try:
        cuerpo, notas, modelo = ia.redactar_contenido(datos)
        with transaccion(usuario) as conn:
            conn.execute("SELECT gobernanza.fn_guardar_version_pieza(%s, %s, %s, 'IA', %s, %s, %s)",
                         (id_pieza, base, cuerpo, notas, datos.get("nuevas_instrucciones") or datos.get("instrucciones"), modelo))
    except Exception as e:  # noqa: BLE001
        try:
            with transaccion(usuario) as conn:
                conn.execute("SELECT gobernanza.fn_marcar_generacion_contenido('pieza', %s, FALSE, %s)", (id_pieza, _mensaje_error(e)[:1000]))
        except Exception:  # noqa: BLE001
            log.exception("No se pudo registrar el error de la pieza %s", id_pieza)


@router.post("/piezas/{id_pieza}/generar", status_code=202)
def generar(id_pieza: int, tareas: BackgroundTasks, datos: dict[str, Any] = Body(default={}),
            usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    _ia_lista()
    nuevas = (datos.get("instrucciones") or "").strip() or None
    with transaccion(usuario) as conn:
        p = _pieza(conn, id_pieza)
        comentarios = [r["comentario"] for r in conn.execute(
            """SELECT comentario FROM gobernanza.pieza_revision WHERE id_pieza = %s AND numero_version = %s
                 AND decision IN ('CAMBIOS', 'COMENTA') ORDER BY fecha""", (id_pieza, p["version_actual"])).fetchall()] if p["version_actual"] else []
        politica = _politica_vigente(conn, p["id_estamento"])
        conn.execute("SELECT gobernanza.fn_marcar_generacion_contenido('pieza', %s, TRUE)", (id_pieza,))
    paquete = {"formato": p["formato"], "titulo": p["titulo"], "eje": p["eje"], "publico": p["publico"], "redes": p["redes_destino"],
               "junta": p["junta"], "fecha_clave": p["fecha_clave"], "politica": politica, "instrucciones": p["instrucciones"],
               "material": (p["material_base"] or "")[:MAX_MATERIAL] or None, "nuevas_instrucciones": nuevas,
               "version_anterior": p["contenido"] if p["version_actual"] else None, "comentarios": comentarios}
    tareas.add_task(_redactar_pieza, id_pieza, p["version_actual"], paquete, usuario)
    return {"generando": True, "mensaje": "La IA está creando la pieza. Tarda menos de un minuto."}


@router.put("/piezas/{id_pieza}/contenido")
def editar(id_pieza: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    with transaccion(usuario) as conn:
        n = conn.execute("SELECT gobernanza.fn_guardar_version_pieza(%s, %s, %s, 'EDICION', NULL, %s) AS n",
                         (id_pieza, datos.get("version_base"), datos.get("contenido") or "", datos.get("motivo"))).fetchone()["n"]
    return {"version": n, "mensaje": f"Guardada la versión {n}. Las aprobaciones anteriores ya no valen."}


@router.post("/piezas/{id_pieza}/revisar")
def revisar(id_pieza: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    with transaccion(usuario) as conn:
        estado = conn.execute("SELECT gobernanza.fn_revisar_pieza(%s, %s, %s, %s) AS e",
                              (id_pieza, datos.get("numero_version"), (datos.get("decision") or "").upper(), datos.get("comentario"))).fetchone()["e"]
    return {"estado": estado}


@router.post("/piezas/{id_pieza}/descartar")
def descartar(id_pieza: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gobernanza.fn_descartar_pieza(%s, %s)", (id_pieza, datos.get("motivo") or ""))
    return {"descartada": True}


# ---------------------------------------------------------------- política de comunicaciones
def _redactar_politica(id_politica: int, datos: dict, usuario: UsuarioActual) -> None:
    try:
        texto, notas, _ = ia.redactar_politica(datos)
        with transaccion(usuario) as conn:
            conn.execute("SELECT gobernanza.fn_guardar_politica_ia(%s, %s, %s)", (id_politica, texto, notas))
    except Exception as e:  # noqa: BLE001
        try:
            with transaccion(usuario) as conn:
                conn.execute("SELECT gobernanza.fn_marcar_generacion_contenido('politica', %s, FALSE, %s)", (id_politica, _mensaje_error(e)[:1000]))
        except Exception:  # noqa: BLE001
            log.exception("No se pudo registrar el error de la política %s", id_politica)


@router.post("/politicas/{id_politica}/generar", status_code=202)
def generar_politica(id_politica: int, tareas: BackgroundTasks, datos: dict[str, Any] = Body(default={}),
                     usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    _ia_lista()
    with transaccion(usuario) as conn:
        pol = conn.execute("""SELECT p.*, e.nombre_estamento AS junta FROM gobernanza.politica_comunicacion p
                                JOIN gobernanza.estamento e ON e.id_estamento = p.id_estamento WHERE p.id_politica = %s""",
                           (id_politica,)).fetchone()
        if not pol:
            raise HTTPException(404, "La política no existe o está fuera de su ámbito territorial.")
        cuentas = conn.execute("""SELECT string_agg(red || ' ' || usuario_cuenta, ', ') AS c FROM gobernanza.cuenta_red_social
                                   WHERE id_estamento = %s AND estado = 'ACTIVA'""", (pol["id_estamento"],)).fetchone()["c"]
        ejes = conn.execute("SELECT string_agg(nombre, '; ' ORDER BY nombre) AS e FROM gobernanza.eje_tematico WHERE activo").fetchone()["e"]
        conn.execute("SELECT gobernanza.fn_marcar_generacion_contenido('politica', %s, TRUE)", (id_politica,))
    definido = "\n".join(f"{t}: {pol[c]}" for c, t in (("objetivos", "Objetivos"), ("publicos", "Públicos"),
                         ("mensajes_clave", "Mensajes clave"), ("tono", "Tono"), ("reglas", "Reglas")) if pol[c])
    tareas.add_task(_redactar_politica, id_politica, {"junta": pol["junta"], "cuentas": cuentas, "ejes": ejes,
                    "frecuencia": pol["publicaciones_por_semana"], "definido": definido, "instrucciones": datos.get("instrucciones")}, usuario)
    return {"generando": True, "mensaje": "La IA está redactando la política. Tarda uno o dos minutos."}


@router.post("/politicas/{id_politica}/aprobar")
def aprobar_politica(id_politica: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gobernanza.fn_aprobar_politica(%s, %s)", (id_politica, datos.get("id_acta")))
    return {"vigente": True, "mensaje": "Política aprobada y vigente. Las nuevas piezas la tendrán en cuenta."}
