"""Vistas de auditoría y alertas (solo lectura), tablero de resumen y funciones de consulta."""
from __future__ import annotations

from dataclasses import dataclass

from datetime import date, datetime
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, HTTPException
from psycopg import sql

from .config import config
from .crud import serializar
from .db import transaccion
from .seguridad import UsuarioActual, requiere, usuario_actual, verificar_permiso

router = APIRouter(prefix="/api", tags=["vistas"])


@dataclass
class Vista:
    clave: str
    titulo: str
    modulo: str
    objeto: str            # esquema.vista
    columna_diagnostico: str | None
    orden: str
    descripcion: str


VISTAS: dict[str, Vista] = {v.clave: v for v in [
    Vista("vigencia_directivos", "Vigencia de directivos", "GOBERNANZA", "gobernanza.v_auditoria_vigencia_directivos",
          "estado_alerta", "fecha_fin_vigencia_programada",
          "Control del periodo estatutario de 2 años de cada directivo."),
    Vista("composicion_juntas", "Composición de juntas", "GOBERNANZA", "gobernanza.v_composicion_juntas",
          "diagnostico", "tipo_estamento, nombre_estamento, orden",
          "Cada cargo estatutario de cada junta: quién lo ocupa o si está vacante."),
    Vista("pertenencia", "Pertenencia de afiliados", "GOBERNANZA", "gobernanza.v_auditoria_pertenencia",
          "diagnostico", "afiliado", "Empresa, sede de trabajo y subdirectiva o comité de cada afiliado."),
    Vista("redes_sociales", "Seguridad de redes sociales", "GOBERNANZA", "gobernanza.v_auditoria_redes_sociales",
          "diagnostico", "junta, red, usuario_cuenta",
          "Cuentas sin clave registrada, claves que conoce quien ya no es directivo, recuperación personal, sin 2FA y cuentas inactivas."),
    Vista("calendario_editorial", "Calendario editorial", "GOBERNANZA", "gobernanza.v_calendario_editorial",
          "diagnostico", "fecha, junta", "Piezas programadas y fechas clave de los próximos 60 días."),
    Vista("contenidos", "Control de contenidos en redes", "GOBERNANZA", "gobernanza.v_auditoria_contenidos",
          "diagnostico", "junta", "Política vigente, piezas de la semana, vencidas y en revisión por junta."),
    Vista("rendimiento_contenidos", "Rendimiento de contenidos", "GOBERNANZA", "gobernanza.v_rendimiento_contenidos",
          None, "interacciones DESC NULLS LAST", "Qué ejes, formatos y redes generan más alcance e interacción (últimos 6 meses)."),
    Vista("doble_cargo", "Directivos con doble cargo", "GOBERNANZA", "gobernanza.v_directivos_doble_cargo",
          None, "nombre_directivo", "Personas con un cargo nacional y uno local a la vez."),
    Vista("gestion_documental", "Trámites y términos legales", "DOCUMENTAL", "gestion_documental.v_auditoria_gestion_documental",
          "diagnostico_auditoria", "fecha_radicacion DESC", "Vencimientos de respuesta según el término legal de cada tipo."),
    Vista("compromisos", "Compromisos y tareas", "DOCUMENTAL", "gestion_documental.v_auditoria_compromisos_tareas",
          "diagnostico_auditoria", "fecha_limite_cumplimiento", "Avance, mora y alertas de los compromisos."),
    Vista("actas_juntas", "Actas de reunión por junta", "DOCUMENTAL", "gestion_documental.v_auditoria_actas_juntas",
          "diagnostico", "diagnostico, nombre_estamento",
          "Las juntas deben reunirse al menos una vez al mes: actas (ACT) del mes anterior y del mes en curso."),
    Vista("escritos", "Control de escritos jurídicos", "DOCUMENTAL", "gestion_documental.v_auditoria_escritos",
          "diagnostico", "creado DESC", "Proyectos en revisión, cambios solicitados, aprobaciones pendientes y radicados."),
    Vista("reuniones", "Control de reuniones", "DOCUMENTAL", "gestion_documental.v_auditoria_reuniones",
          "diagnostico", "fecha DESC, hora DESC",
          "Convocatorias, quórum, firmas y aprobación de cada reunión. La primera del trimestre es ordinaria."),
    Vista("asistencia", "Asistencia de directivos", "DOCUMENTAL", "gestion_documental.v_auditoria_asistencia",
          "diagnostico", "junta, directivo",
          "Asistencia de cada directivo vigente a las reuniones de su junta en los últimos 12 meses."),
    Vista("inactividad", "Inactividad documental", "DOCUMENTAL", "gestion_documental.v_auditoria_inactividad_documental",
          "diagnostico_inactividad", "nombre_estamento, sigla_tipo", "Tiempo sin emitir cada tipo de documento por estamento."),
    Vista("informes_directivos", "Rendición de informes (INF)", "DOCUMENTAL",
          "gestion_documental.v_auditoria_informes_directivos", "diagnostico_auditoria_informe", "meses_sin_informe DESC",
          "Informes de gestión rendidos por cada cargo directivo."),
    Vista("expedientes", "Control de expedientes", "DOCUMENTAL", "gestion_documental.v_auditoria_expedientes",
          "diagnostico_auditoria", "fecha_apertura DESC", "Foliación y compromisos pendientes por expediente."),
    Vista("armonizacion_aportes", "Conciliación de aportes 0.7%", "FINANZAS", "finanzas.v_auditoria_armonizacion_aportes",
          "diagnostico_auditoria", "periodo_anio DESC, periodo_mes DESC",
          "Diferencias entre lo consignado y la suma de aportes individuales."),
    Vista("saldo_fondos", "Saldo de los fondos", "FINANZAS", "finanzas.vf_saldo_fondos", "diagnostico", "tipo_estamento, fondo",
          "Fondo de cada junta: aportes (80 % local / 20 % nacional), otros ingresos, egresos aprobados y saldo."),
    Vista("saldo_cuentas", "Saldo de las cuentas", "FINANZAS", "finanzas.vf_saldo_cuentas", None, "clase, titular",
          "Saldo de la cuenta nacional y de cada subcuenta según los movimientos registrados."),
    Vista("transferencias_pendientes", "Transferencias pendientes", "FINANZAS", "finanzas.vf_transferencias_pendientes",
          "diagnostico", "junta", "Diferencia entre el fondo de cada junta y el saldo de su subcuenta."),
    Vista("consignaciones_por_cuenta", "Consignaciones por cuenta", "FINANZAS", "finanzas.vf_consignaciones_por_cuenta",
          "diagnostico", "periodo DESC, empresa",
          "A qué cuenta llegó cada consignación (nacional o subcuenta) y a qué fondos corresponde ese dinero."),
    Vista("mora_empresas", "Mora de empresas", "FINANZAS", "finanzas.vf_mora_empresas", "diagnostico", "periodo DESC, empresa",
          "Meses vencidos sin consignación o con consignación menor a la esperada según los salarios vigentes."),
    Vista("ejecucion_presupuestal", "Ejecución presupuestal", "FINANZAS", "finanzas.vf_ejecucion_presupuestal", "diagnostico",
          "anio DESC, junta, rubro", "Aprobado, ejecutado y disponible por junta y rubro."),
    Vista("estado_resultados", "Ingresos y egresos por mes", "FINANZAS", "finanzas.vf_estado_ingresos_egresos", None,
          "anio DESC, mes DESC, junta", "Estado de ingresos y egresos de cada junta, mes a mes."),
    Vista("movimientos_fondo", "Movimientos de los fondos", "FINANZAS", "finanzas.vf_movimientos_fondo", None,
          "fecha DESC, fondo", "Libro de movimientos de cada fondo."),
    Vista("conciliacion_bancaria", "Conciliación bancaria", "FINANZAS", "finanzas.vf_conciliacion_bancaria", "diagnostico",
          "anio DESC, mes DESC, cuenta", "Saldo del extracto frente al saldo del sistema al cierre de cada mes."),
    Vista("alertas_financieras", "Alertas financieras (Fiscal)", "FINANZAS", "finanzas.vf_alertas_financieras", "diagnostico",
          "junta, tipo", "Egresos sin aprobar o sin soporte, fuera de presupuesto, anulados, transferencias pendientes, "
                         "conciliaciones con diferencia y meses sin cierre."),
    Vista("monitor_indices", "Monitor de índices", "ADMINISTRACION", "auditoria.v_monitor_indices", "diagnostico",
          "esquema, tabla, indice", "Tamaño, uso y validez de cada índice."),
    Vista("monitor_tablas", "Monitor de tablas", "ADMINISTRACION", "auditoria.v_monitor_tablas", "diagnostico",
          "esquema, tabla", "Filas vivas/muertas, lecturas secuenciales y último mantenimiento."),
    Vista("alertas_seguridad", "Alertas de seguridad de la base", "ADMINISTRACION", "auditoria.v_alertas_seguridad", "diagnostico", "fecha DESC",
          "Últimos 30 días: conexiones con la contraseña de la aplicación hechas fuera de ella e intentos bloqueados por la base."),
    Vista("incompatibilidades", "Incompatibilidades de funciones", "ADMINISTRACION", "seguridad.v_incompatibilidades", "diagnostico", "nombre_usuario",
          "Usuarios con funciones incompatibles (Tesorería y Fiscalía en la misma junta, Administrador con otro rol, Ventanilla y quien aprueba afiliaciones)."),
    Vista("mfa_pendiente", "Usuarios sin segundo factor (MFA)", "ADMINISTRACION", "auditoria.v_mfa_pendiente", "diagnostico", "plazo",
          "Usuarios cuyo rol exige MFA y aún no lo activan, con su plazo."),
    Vista("fk_sin_indice", "Llaves foráneas sin índice", "ADMINISTRACION", "auditoria.v_fk_sin_indice", None,
          "esquema, tabla", "Debe estar vacía. Si aparece algo, incluye el CREATE INDEX sugerido."),
    Vista("transicion_aporte", "Transición al 0,7 %", "FINANZAS", "finanzas.vf_transicion_aporte", "diagnostico", "porcentaje_junta, junta",
          "Porcentaje que aplica cada junta, cuántos afiliados siguen por debajo y cuánto dinero mensual representa la diferencia."),
    Vista("exoneraciones", "Exoneraciones del aporte", "FINANZAS", "finanzas.vf_exoneraciones", "diagnostico", "junta, desde",
          "Exoneraciones por junta: meses, valor dejado de recibir y si la empresa igual consignó en esos meses."),
    Vista("solicitudes_afiliacion", "Solicitudes de afiliación", "GOBERNANZA", "gobernanza.v_auditoria_solicitudes_afiliacion",
          "diagnostico", "recibida DESC", "Solicitudes recibidas en Ventanilla, por correo o en el portal, pendientes de decisión de la junta."),
    Vista("consentimiento", "Autorizaciones de datos (Ley 1581)", "GOBERNANZA", "gobernanza.v_auditoria_consentimiento",
          "diagnostico", "junta, afiliado",
          "Afiliados activos y el estado de su autorización de tratamiento de datos por finalidad. Pendiente = falta recogerla."),
    Vista("solicitudes_titular", "Solicitudes de titulares (datos)", "GOBERNANZA", "gobernanza.v_auditoria_solicitudes_titular",
          "diagnostico", "fecha_limite",
          "Consultas (10 días hábiles) y reclamos (15) de los titulares sobre sus datos: requerimientos, desistimientos, traslados y leyenda «reclamo en trámite», con alerta al 50 %, al 80 % y al vencer."),
    Vista("escalamiento", "A quién escalar y con quién negociar", "GOBERNANZA", "gobernanza.v_escalamiento_afiliados", "diagnostico",
          "empresa, afiliado", "Cadena de jefes de cada afiliado hasta la máxima autoridad de la entidad y el representante legal de su empresa."),
    Vista("expedientes_incompletos", "Expedientes incompletos", "GOBERNANZA", "gobernanza.v_expedientes_incompletos", None,
          "junta, afiliado", "Informativa: afiliados actuales a los que les falta el documento de identidad o el formato de afiliación "
          "firmado (o están por revisar). No bloquea nada; se completan desde el expediente del afiliado."),
    Vista("historial_pertenencia", "Historial de pertenencia y dispersos", "GOBERNANZA", "gobernanza.v_historial_pertenencia", None,
          "fecha_registro DESC", "Cada cambio de la junta a la que pertenece un afiliado; pasar a disperso o dejar de serlo lleva el acta "
          "de la Junta Nacional."),
    Vista("sin_pertenencia", "Afiliados sin pertenencia", "GOBERNANZA", "gobernanza.v_afiliados_sin_pertenencia", "diagnostico",
          "afiliado", "Debe estar vacía: la pertenencia es obligatoria. Asigne la subdirectiva o comité (o disperso, con acta)."),
    Vista("traslados", "Traslados entre juntas", "GOBERNANZA", "gobernanza.v_traslados", "diagnostico", "propuesto DESC",
          "Traslados de afiliados entre subdirectivas o comités: los deciden las dos juntas, cada una con su acta. Muestra los que esperan respuesta y las excepciones."),
    Vista("junta_nacional", "Afiliados de la Junta Nacional (Palmira y dispersos)", "GOBERNANZA", "gobernanza.v_afiliados_junta_nacional",
          None, "grupo, afiliado", "Censo de los afiliados que pertenecen a la Junta Directiva Nacional en sus dos grupos: Palmira (sede nacional) y dispersos."),
    Vista("junta_nacional_municipios", "Junta Nacional por municipio", "GOBERNANZA", "gobernanza.v_junta_nacional_por_municipio", None,
          "grupo, afiliados DESC", "Dónde trabajan los afiliados de Palmira y los dispersos: sirve para decidir si conviene crear un comité."),
    Vista("designaciones", "Designaciones de directivos", "GOBERNANZA", "gobernanza.v_designaciones", "diagnostico", "fecha_designacion DESC",
          "Directivos designados por su junta: los pendientes esperan el registro del inspector y aún no ejercen el cargo."),
    Vista("inscripcion_directivos", "Inscripción de directivos ante el inspector", "GOBERNANZA", "gobernanza.v_inscripcion_directivos", "diagnostico",
          "junta, cargo", "Directivos vigentes: quién está inscrito en un registro del inspector, quién no ejerce aún y las posesiones "
          "registradas a mano con una fecha distinta de la del registro."),
    Vista("permisos", "Permisos sindicales", "GOBERNANZA", "gobernanza.v_permisos_sindicales", "diagnostico", "fecha_inicio DESC",
          "Solicitudes de permiso sindical: plazo de respuesta de la entidad, silencio (concedido), negativas y la causal invocada."),
    Vista("permisos_por_afiliado", "Días de permiso por afiliado", "GOBERNANZA", "gobernanza.v_permisos_por_afiliado", None,
          "anio DESC, dias_concedidos DESC", "Días hábiles solicitados, concedidos (incluido el silencio), negados y en espera, por afiliado y año."),
    Vista("lugares_por_corregir", "Lugares por corregir (DIVIPOLA)", "GOBERNANZA", "gobernanza.v_lugares_por_corregir", "diagnostico",
          "registro, nombre", "Debe quedar vacía: personas, empresas, sedes y juntas cuyo municipio escrito no se pudo pasar al código oficial."),
    Vista("jefes", "Jerarquía de jefes", "GOBERNANZA", "gobernanza.v_auditoria_jefes", "diagnostico", "empresa, nivel DESC, jefe",
          "Jefes con el nivel por revisar (escala anterior), sin jefe directo o representantes legales que no son la máxima autoridad."),
    Vista("plazos_ley", "Plazos de ley", "GOBERNANZA", "gobernanza.v_plazos_ley", "diagnostico", "ambito, codigo",
          "Plazos que fijan las leyes 1755 de 2015 y 1581 de 2012 y el valor que tiene el sistema. El sindicato puede acortarlos, nunca alargarlos."),
    Vista("suplencias", "Suplencias de cargos", "GOBERNANZA", "gobernanza.v_suplencias", "diagnostico", "hasta DESC",
          "Suplencias vigentes, por vencer (7 días) y ausencias de más de 60 días."),
    Vista("pqrsd", "PQRSD recibidas: plazos", "DOCUMENTAL", "gestion_documental.v_auditoria_pqrsd", "diagnostico", "fecha_limite",
          "Peticiones, quejas, reclamos, sugerencias, denuncias, consultas y solicitudes de documentos: días hábiles restantes y alertas al 50 %, al 80 % y al vencer."),
    Vista("accesos_inusuales", "Consultas inusuales de datos personales", "AUDITORIA", "auditoria.v_accesos_inusuales",
          "diagnostico", "dia DESC",
          "Usuarios que en un día consultaron más fichas o datos de personas de lo habitual. Solo para el administrador y la Presidencia Nacional."),
]}

TRADUCCION_INTERVALOS = [(" years", " años"), (" year", " año"), (" mons", " meses"), (" mon", " mes"),
                         (" days", " días"), (" day", " día")]


def _texto_intervalo(v):
    if isinstance(v, str):
        for a, b in TRADUCCION_INTERVALOS:
            v = v.replace(a, b)
    return v


def _consultar_vista(conn, vista: Vista, limite: int = 2000):
    esquema, nombre = vista.objeto.split(".")
    cols = conn.execute(
        "SELECT column_name, data_type FROM information_schema.columns "
        "WHERE table_schema = %s AND table_name = %s ORDER BY ordinal_position", (esquema, nombre)).fetchall()
    # Los intervalos (AGE) se devuelven como texto legible
    seleccion = sql.SQL(", ").join(
        sql.SQL("{}::text AS {}").format(sql.Identifier(c["column_name"]), sql.Identifier(c["column_name"]))
        if c["data_type"] == "interval" else sql.Identifier(c["column_name"])
        for c in cols)
    filas = conn.execute(sql.SQL("SELECT {} FROM {}.{} ORDER BY {} LIMIT %s").format(
        seleccion, sql.Identifier(esquema), sql.Identifier(nombre), sql.SQL(vista.orden)), (limite,)).fetchall()
    intervalos = {c["column_name"] for c in cols if c["data_type"] == "interval"}
    salida = []
    for f in filas:
        f = serializar(f)
        for c in intervalos:
            f[c] = _texto_intervalo(f[c])
        salida.append(f)
    return [c["column_name"] for c in cols], salida


def _nivel(diagnostico: str | None) -> str:
    d = (diagnostico or "").upper()
    for nivel in ("CRÍTICA", "ALTA", "MEDIA", "BAJA"):
        if f"ALERTA {nivel}" in d:
            return nivel
    return "NORMAL"


# Vistas que listan afiliados o sus datos personales: su consulta queda en la bitácora de accesos
VISTAS_CON_DATOS_PERSONALES = {"escalamiento", "pqrsd", "pertenencia", "consentimiento", "solicitudes_titular", "exoneraciones", "solicitudes_afiliacion",
                              "expedientes_incompletos", "historial_pertenencia", "sin_pertenencia",
                              "traslados", "junta_nacional", "lugares_por_corregir", "permisos", "permisos_por_afiliado"}


@router.get("/vistas")
def listar_vistas(usuario: UsuarioActual = Depends(usuario_actual)):
    return [{"clave": v.clave, "titulo": v.titulo, "modulo": v.modulo, "descripcion": v.descripcion}
            for v in VISTAS.values() if usuario.puede(v.modulo, "ver_vistas")]


@router.get("/vistas/{clave}")
def ver_vista(clave: str, usuario: UsuarioActual = Depends(usuario_actual)):
    vista = VISTAS.get(clave)
    if not vista:
        raise HTTPException(404, "Vista no encontrada.")
    verificar_permiso(usuario, vista.modulo, "ver_vistas")
    with transaccion(usuario) as conn:
        columnas, filas = _consultar_vista(conn, vista)
        if clave in VISTAS_CON_DATOS_PERSONALES and filas:   # Ley 1581: queda en la bitácora de accesos
            conn.execute("SELECT seguridad.fn_registrar_acceso_dato('LISTADO', %s, NULL, NULL, %s, NULL)", ("vista:" + clave, len(filas)))
    for f in filas:
        f["_nivel"] = _nivel(f.get(vista.columna_diagnostico)) if vista.columna_diagnostico else "NORMAL"
    return {"titulo": vista.titulo, "descripcion": vista.descripcion, "columnas": columnas,
            "columna_diagnostico": vista.columna_diagnostico, "filas": filas}


@router.get("/tablero")
def tablero(usuario: UsuarioActual = Depends(usuario_actual)):
    """Conteo de alertas por nivel en cada vista que el usuario puede ver."""
    resultado = []
    with transaccion(usuario) as conn:
        for v in VISTAS.values():
            if not v.columna_diagnostico or v.modulo == "ADMINISTRACION" or not usuario.puede(v.modulo, "ver_vistas"):
                continue
            esquema, nombre = v.objeto.split(".")
            filas = conn.execute(sql.SQL("SELECT {} AS d, count(*) AS n FROM {}.{} GROUP BY 1").format(
                sql.Identifier(v.columna_diagnostico), sql.Identifier(esquema), sql.Identifier(nombre))).fetchall()
            conteo = {"CRÍTICA": 0, "ALTA": 0, "MEDIA": 0, "BAJA": 0, "NORMAL": 0}
            for f in filas:
                conteo[_nivel(f["d"])] += f["n"]
            resultado.append({"clave": v.clave, "titulo": v.titulo, "modulo": v.modulo, "conteo": conteo,
                              "total": sum(conteo.values())})
    return resultado


@router.get("/expedientes/{codigo}/hoja-ruta")
def hoja_ruta(codigo: str, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        filas = conn.execute("SELECT * FROM gestion_documental.fn_auditar_expediente(%s)", (codigo,)).fetchall()
    return [serializar(f) for f in filas]


@router.get("/juntas/{id_estamento}/composicion")
def composicion_junta(id_estamento: int, fecha: date | None = None,
                      usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    """Quiénes ocupaban cada cargo de la junta en una fecha (por defecto, hoy)."""
    fecha = fecha or datetime.now(ZoneInfo(config.ZONA_HORARIA)).date()
    with transaccion(usuario) as conn:
        est = conn.execute("SELECT nombre_estamento, tipo_estamento FROM gobernanza.estamento WHERE id_estamento = %s",
                           (id_estamento,)).fetchone()
        if not est:
            raise HTTPException(404, "Estamento no encontrado.")
        filas = conn.execute("SELECT * FROM gobernanza.fn_composicion_junta(%s, %s)", (id_estamento, fecha)).fetchall()
        registros = conn.execute("""SELECT id_registro, num_registro_inspector, fecha_emision_registro::DATE AS fecha
                                      FROM gobernanza.registro_inspector_estamento WHERE id_estamento = %s
                                     ORDER BY fecha_emision_registro DESC""", (id_estamento,)).fetchall()
    return {"estamento": est["nombre_estamento"], "fecha": fecha.isoformat(),
            "filas": [serializar(f) for f in filas], "registros": [serializar(r) for r in registros]}


@router.get("/juntas/registro/{id_registro}")
def composicion_registro(id_registro: int, usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    """Directivos que figuraron en un registro del inspector (composición oficial reconocida)."""
    with transaccion(usuario) as conn:
        reg = conn.execute("""SELECT r.num_registro_inspector, r.fecha_emision_registro::DATE AS fecha, e.nombre_estamento,
                                     i.primer_nombre || ' ' || i.primer_apellido || ' (' || i.nombre_territorial || ')' AS inspector
                                FROM gobernanza.registro_inspector_estamento r
                                JOIN gobernanza.estamento e ON e.id_estamento = r.id_estamento
                                JOIN gobernanza.inspector i ON i.id_inspector = r.id_inspector
                               WHERE r.id_registro = %s""", (id_registro,)).fetchone()
        if not reg:
            raise HTTPException(404, "Registro no encontrado.")
        filas = conn.execute("SELECT * FROM gobernanza.fn_composicion_registro(%s)", (id_registro,)).fetchall()
    return {**serializar(reg), "filas": [serializar(f) for f in filas]}
