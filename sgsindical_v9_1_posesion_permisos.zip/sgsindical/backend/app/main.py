"""Punto de entrada de la API SGSINDICAL (FastAPI)."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

import psycopg
from fastapi import FastAPI, Request
from fastapi.exceptions import HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from psycopg import errors as pgerr

from . import afiliacion, auth, autoservicio, contenidos, mfa, crud, escritos, operaciones, permisos, pqrsd, privacidad, redes, reuniones, roles, vistas
from .config import config
from .db import abrir_pool, cerrar_pool

log = logging.getLogger("sgsindical")


@asynccontextmanager
async def ciclo_vida(app: FastAPI):
    abrir_pool()
    yield
    cerrar_pool()


app = FastAPI(
    title="SGSINDICAL API",
    version="9.1",
    lifespan=ciclo_vida,
    docs_url="/api/docs" if config.MOSTRAR_DOCS_API else None,
    redoc_url=None,
    openapi_url="/api/openapi.json" if config.MOSTRAR_DOCS_API else None,
)

if config.CORS_ORIGINS:
    app.add_middleware(CORSMiddleware, allow_origins=config.CORS_ORIGINS, allow_credentials=False,
                       allow_methods=["GET", "POST", "PUT", "DELETE"], allow_headers=["Authorization", "Content-Type"])


@app.middleware("http")
async def cabeceras_seguridad(request: Request, call_next):
    respuesta = await call_next(request)
    respuesta.headers["X-Content-Type-Options"] = "nosniff"
    respuesta.headers["X-Frame-Options"] = "DENY"
    respuesta.headers["Referrer-Policy"] = "no-referrer"
    respuesta.headers["Content-Security-Policy"] = (
        "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
        "script-src 'self'; frame-ancestors 'none'; object-src 'none'")
    if request.url.path.startswith("/api/"):
        respuesta.headers["Cache-Control"] = "no-store"
    return respuesta


# ---------------------------------------------------------------- errores de PostgreSQL en español
def _detalle(e: psycopg.Error) -> str:
    diag = e.diag
    return (diag.message_detail or diag.message_primary or str(e)).strip()


MENSAJES_CHECK = {
    "ck_asistente_directivo_persona": "Un directivo debe estar registrado como persona.",
    "ck_asistente_identidad": "Indique la persona registrada o, si es un invitado externo, su nombre (solo uno de los dos).",
    "ck_asistente_no_asistio": "Si la persona no asistió no se registran modalidad ni horas de llegada o salida.",
    "ck_asistente_excusa": "La excusa se registra solo para quien no asistió.",
    "ck_asistente_horas": "La hora de salida debe ser posterior a la de llegada.",
    "ck_reunion_horas": "La hora de finalización debe ser posterior a la de inicio.",
    "ck_red_otra": "Indique el nombre de la red social.",
    "ck_red_2fa": "El método de verificación en dos pasos se indica solo si la cuenta la tiene activada.",
    "ck_red_publicacion": "La fecha de la última publicación no puede ser futura.",
    "ck_red_acceso_fechas": "La fecha de retiro del rol no puede ser anterior a su asignación.",
    "ck_revision_comentario": "Para solicitar cambios o comentar escriba el comentario.",
    "ck_pieza_revision_comentario": "Para solicitar cambios o comentar escriba el comentario.",
    "ck_politica_vigente": "La política entra en vigencia con un acta de aprobación.",
    "ck_publicacion_fecha": "La fecha de publicación no puede ser futura.",
    "ck_autorizacion_soporte": "Una autorización física o verbal grabada necesita su soporte: radique el documento escaneado o la grabación y asócielo.",
    "ck_decision_compromiso": "Un compromiso necesita título, responsable y fecha límite (los tres o ninguno).",
}


@app.exception_handler(psycopg.Error)
async def error_bd(request: Request, e: psycopg.Error):
    diag = e.diag
    if isinstance(e, pgerr.InsufficientPrivilege) and (diag.message_primary or "").startswith("SEGURIDAD:"):
        # La base bloqueó una operación protegida: queda en el registro de accesos y genera alerta
        try:
            from .seguridad import ip_cliente, registrar_acceso
            registrar_acceso("api", "SEGURIDAD_BLOQUEO", ip_cliente(request),
                             f"{request.method} {request.url.path}: {diag.message_primary[10:].strip()}"[:500])
        except Exception:  # noqa: BLE001
            log.exception("No se pudo registrar el bloqueo de seguridad")
        return JSONResponse({"detail": diag.message_primary[10:].strip().capitalize()}, 403)
    if isinstance(e, pgerr.UniqueViolation):
        return JSONResponse({"detail": f"Ya existe un registro con esos datos. {_detalle(e)} Si está inactivo, búsquelo con "
                                       "«Ver inactivos» y reactívelo en lugar de crearlo de nuevo."}, 409)
    if isinstance(e, pgerr.RestrictViolation):
        return JSONResponse({"detail": diag.message_primary}, 409)
    if isinstance(e, pgerr.ForeignKeyViolation):
        if "is still referenced" in (diag.message_detail or ""):
            msg = f"No se puede eliminar: otros registros dependen de este ({diag.table_name or ''})."
        else:
            msg = "El registro relacionado que seleccionó no existe."
        return JSONResponse({"detail": msg}, 409)
    if isinstance(e, pgerr.CheckViolation):
        msg = MENSAJES_CHECK.get(diag.constraint_name or "")
        return JSONResponse({"detail": msg or f"Un valor no cumple las reglas de la base de datos ({diag.constraint_name})."}, 400)
    if isinstance(e, pgerr.NotNullViolation):
        return JSONResponse({"detail": f"El campo '{diag.column_name}' es obligatorio."}, 400)
    if isinstance(e, (pgerr.RaiseException, pgerr.DataException)):
        return JSONResponse({"detail": diag.message_primary}, 400)
    if isinstance(e, pgerr.InsufficientPrivilege) and (diag.message_primary or "").startswith("Fuera de su ámbito"):
        return JSONResponse({"detail": diag.message_primary}, 403)
    if isinstance(e, pgerr.InsufficientPrivilege) and "row-level security" in (diag.message_primary or ""):
        return JSONResponse({"detail": "Fuera de su ámbito territorial: solo puede registrar o modificar información "
                                       "de los estamentos a los que tiene acceso."}, 403)
    if isinstance(e, pgerr.InsufficientPrivilege) and diag.message_primary and not diag.message_primary.startswith("permission denied"):
        return JSONResponse({"detail": diag.message_primary}, 403)   # mensajes propios (p. ej. dato reservado, Ley 1581)
    if isinstance(e, pgerr.InsufficientPrivilege):
        return JSONResponse({"detail": "La base de datos rechazó la operación por permisos (política de seguridad)."}, 403)
    if isinstance(e, pgerr.SerializationFailure) and diag.message_primary and not diag.message_primary.startswith("could not"):
        return JSONResponse({"detail": diag.message_primary}, 409)
    if isinstance(e, (pgerr.SerializationFailure, pgerr.DeadlockDetected)):
        return JSONResponse({"detail": "Conflicto de concurrencia con otra operación. Intente de nuevo."}, 409)
    if isinstance(e, (pgerr.LockNotAvailable, pgerr.QueryCanceled)):
        return JSONResponse({"detail": "El registro está ocupado por otra operación. Intente en unos segundos."}, 503)
    if isinstance(e, psycopg.OperationalError):
        log.exception("Base de datos no disponible")
        return JSONResponse({"detail": "No hay conexión con la base de datos."}, 503)
    log.exception("Error de base de datos no controlado")
    return JSONResponse({"detail": "Error interno de base de datos."}, 500)


@app.exception_handler(Exception)
async def error_general(request: Request, e: Exception):
    if isinstance(e, HTTPException):
        raise e
    log.exception("Error no controlado")
    return JSONResponse({"detail": "Error interno del servidor."}, 500)


# ---------------------------------------------------------------- rutas
app.include_router(auth.router)
app.include_router(crud.router)
app.include_router(vistas.router)
app.include_router(operaciones.router)
app.include_router(reuniones.router)
app.include_router(redes.router)
app.include_router(escritos.router)
app.include_router(contenidos.router)
app.include_router(privacidad.router)
app.include_router(autoservicio.router)
app.include_router(mfa.router)
app.include_router(pqrsd.router)
app.include_router(roles.router)
app.include_router(afiliacion.router)
app.include_router(permisos.router)


@app.get("/api/salud")
def salud():
    import os
    return {"estado": "ok", "version": app.version, "modo_local": os.environ.get("SGS_MODO_LOCAL") == "1"}


# ---------------------------------------------------------------- interfaz React compilada
if config.FRONTEND_DIR.is_dir():
    app.mount("/assets", StaticFiles(directory=config.FRONTEND_DIR / "assets", check_dir=False), name="assets")

    @app.get("/{ruta:path}", include_in_schema=False)
    def interfaz(ruta: str):
        if ruta.startswith("api/"):
            return JSONResponse({"detail": "No encontrado"}, 404)
        archivo = (config.FRONTEND_DIR / ruta).resolve()
        if ruta and archivo.is_file() and config.FRONTEND_DIR.resolve() in archivo.parents:
            return FileResponse(archivo)
        return FileResponse(config.FRONTEND_DIR / "index.html")
