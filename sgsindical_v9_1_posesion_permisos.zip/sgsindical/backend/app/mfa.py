"""Segundo factor de autenticación (MFA): aplicación autenticadora (TOTP, RFC 6238), código por correo y
códigos de recuperación. Las reglas y los datos viven en la base (db/09_mfa.sql); la clave secreta del
autenticador se cifra aquí con AES-256-GCM (llave SECRETOS_LLAVE) y nunca sale del servidor."""
from __future__ import annotations

import math
import base64
import hashlib
import hmac
import io
import os
import secrets
import struct
import time
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.parse import quote

from fastapi import APIRouter, Body, Depends, HTTPException

from .config import config
from .db import transaccion
from .seguridad import (UsuarioActual, exigir_paso_adicional, registrar_acceso, requiere, usuario_actual,
                        usuario_sesion)

router = APIRouter(prefix="/api/mfa", tags=["mfa"])

PASO_SEG = 30          # el código de la aplicación cambia cada 30 s (estándar de las aplicaciones)
PASOS_ATRAS = 6        # se acepta hasta 3 minutos después de que apareció
PASOS_ADELANTE = 1     # tolerancia por reloj adelantado del celular


# ---------------------------------------------------------------- TOTP (RFC 6238)
def totp(secreto_b32: str, paso: int) -> str:
    clave = base64.b32decode(secreto_b32 + "=" * (-len(secreto_b32) % 8), casefold=True)
    h = hmac.new(clave, struct.pack(">Q", paso), hashlib.sha1).digest()
    o = h[-1] & 0x0F
    return f"{(struct.unpack('>I', h[o:o + 4])[0] & 0x7FFFFFFF) % 1_000_000:06d}"


def paso_actual(ahora: float | None = None) -> int:
    return int((ahora if ahora is not None else time.time()) // PASO_SEG)


def verificar_totp(secreto_b32: str, codigo: str, ahora: float | None = None) -> int | None:
    """Devuelve el paso de tiempo del código si es válido (hasta 3 minutos de antigüedad), o None."""
    codigo = "".join(ch for ch in (codigo or "") if ch.isdigit())
    if len(codigo) != 6:
        return None
    actual = paso_actual(ahora)
    for paso in range(actual + PASOS_ADELANTE, actual - PASOS_ATRAS - 1, -1):
        if hmac.compare_digest(totp(secreto_b32, paso), codigo):
            return paso
    return None


def _hash(texto: str) -> str:
    return hashlib.sha256(texto.encode()).hexdigest()


def _normalizar_recuperacion(c: str) -> str:
    return "".join(ch for ch in (c or "").upper() if ch.isalnum())


# ---------------------------------------------------------------- cifrado del secreto
def _aad(id_usuario: int) -> bytes:
    return f"sgsindical:mfa:{id_usuario}".encode()


def cifrar_secreto(secreto: str, id_usuario: int) -> tuple[bytes, int]:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from .redes import _llaves
    version = config.SECRETOS_LLAVE_VERSION
    nonce = os.urandom(12)
    return nonce + AESGCM(_llaves()[version]).encrypt(nonce, secreto.encode(), _aad(id_usuario)), version


def descifrar_secreto(blob: bytes, id_usuario: int, version: int) -> str:
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from .redes import _llaves
    llave = _llaves().get(version)
    if llave is None:
        raise HTTPException(503, f"El secreto del MFA se cifró con la llave versión {version}, que no está configurada.")
    blob = bytes(blob)
    try:
        return AESGCM(llave).decrypt(blob[:12], blob[12:], _aad(id_usuario)).decode()
    except InvalidTag:
        raise HTTPException(409, "ALERTA DE INTEGRIDAD: el secreto del MFA no corresponde a la llave del servidor.")


def qr_svg(texto: str) -> str:
    from reportlab.graphics import renderSVG
    from reportlab.graphics.barcode.qr import QrCodeWidget
    from reportlab.graphics.shapes import Drawing
    w = QrCodeWidget(texto)
    x1, y1, x2, y2 = w.getBounds()
    lado = 220
    d = Drawing(lado, lado, transform=[lado / (x2 - x1), 0, 0, lado / (y2 - y1), 0, 0])
    d.add(w)
    return renderSVG.drawToString(d)


# ---------------------------------------------------------------- correos de aviso
def _avisar(correo: str | None, nombre: str, asunto: str, texto: str, clave: str) -> None:
    if not correo:
        return
    from .autoservicio import _enviar
    _enviar(correo, nombre, asunto, [texto, "Si usted no hizo esta acción, comuníquese de inmediato con el administrador del sistema."], clave)


def _correo_de(conn, id_usuario: int) -> str | None:
    f = conn.execute("SELECT correo_electronico FROM seguridad.usuario WHERE id_usuario = %s", (id_usuario,)).fetchone()
    return f["correo_electronico"] if f else None


# ---------------------------------------------------------------- estado
def estado_mfa(conn, usuario: UsuarioActual) -> dict:
    e = conn.execute("SELECT * FROM seguridad.fn_mfa_estado_ingreso(%s, NULL)", (usuario.id_usuario,)).fetchone()
    restantes = conn.execute("SELECT seguridad.fn_mfa_codigos_restantes() AS n").fetchone()["n"]
    plazo = e["plazo_hasta"]
    ahora = datetime.now(timezone.utc)
    return {
        "verificada": usuario.mfa_verificada,
        "activo": e["activo"],
        "requerido": e["requiere"],
        "plazo_hasta": plazo.isoformat() if plazo else None,
        "dias_restantes": max(0, math.ceil((plazo - ahora).total_seconds() / 86400)) if plazo and plazo > ahora else 0,
        "configuracion_obligatoria": bool(e["requiere"] and not e["activo"] and (not plazo or plazo <= ahora)),
        "codigos_restantes": restantes,
        "puede_recordar_equipo": not e["es_admin"],
    }


@router.get("/estado")
def estado(usuario: UsuarioActual = Depends(usuario_sesion)):
    with transaccion(usuario) as conn:
        return estado_mfa(conn, usuario)


# ---------------------------------------------------------------- configuración (activar el MFA)
@router.post("/configurar")
def configurar(usuario: UsuarioActual = Depends(usuario_sesion)):
    """Genera la clave del autenticador y su código QR. Si ya tenía el MFA activo (celular nuevo), exige la
    sesión verificada y la doble verificación."""
    secreto = base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")
    blob, version = cifrar_secreto(secreto, usuario.id_usuario)
    with transaccion(usuario) as conn:
        if usuario.mfa_activo:
            if not usuario.mfa_verificada:
                raise HTTPException(403, "Verifique primero su sesión con un código de recuperación.")
            exigir_paso_adicional(usuario)
            conn.execute("SELECT seguridad.fn_mfa_reconfigurar(%s, %s, %s)", (blob, version, usuario.id_sesion))
        else:
            conn.execute("SELECT seguridad.fn_mfa_guardar_pendiente(%s, %s)", (blob, version))
    emisor = config.SINDICATO_NOMBRE.split(" - ")[0].strip() or "SGSINDICAL"
    uri = (f"otpauth://totp/{quote(emisor)}:{quote(usuario.nombre_usuario)}?secret={secreto}&issuer={quote(emisor)}"
           f"&algorithm=SHA1&digits=6&period={PASO_SEG}")
    return {"secreto": " ".join(secreto[i:i + 4] for i in range(0, len(secreto), 4)), "uri": uri, "qr_svg": qr_svg(uri)}


def _codigos_recuperacion() -> list[str]:
    alfabeto = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return ["".join(secrets.choice(alfabeto) for _ in range(4)) + "-" + "".join(secrets.choice(alfabeto) for _ in range(4))
            for _ in range(10)]


@router.post("/confirmar")
def confirmar(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(usuario_sesion)):
    with transaccion(usuario) as conn:
        s = conn.execute("SELECT * FROM seguridad.fn_mfa_mi_secreto()").fetchone()
        if not s or s["activo"]:
            raise HTTPException(400, "Primero genere el código QR.")
        secreto = descifrar_secreto(s["secreto_cifrado"], usuario.id_usuario, s["version_llave"])
        paso = verificar_totp(secreto, str(datos.get("codigo", "")))
        if paso is None or not conn.execute("SELECT seguridad.fn_mfa_usar_paso(%s) AS ok", (paso,)).fetchone()["ok"]:
            raise HTTPException(400, "El código no coincide. Revise que la hora del celular esté bien y escriba el código que aparece ahora.")
        codigos = _codigos_recuperacion()
        conn.execute("SELECT seguridad.fn_mfa_activar(%s)", ([_hash(_normalizar_recuperacion(c)) for c in codigos],))
        conn.execute("SELECT seguridad.fn_mfa_marcar_sesion(%s, 'APP')", (usuario.id_sesion,))
        conn.execute("INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, ip_origen) VALUES (%s, 'MFA_ACTIVADO', %s)",
                     (usuario.nombre_usuario, usuario.ip))
        correo = _correo_de(conn, usuario.id_usuario)
    _avisar(correo, usuario.nombre_completo, "Activó la verificación en dos pasos",
            f"Se activó la verificación en dos pasos (MFA) de su usuario {usuario.nombre_usuario}.", f"mfa_activado:{usuario.id_usuario}")
    return {"activo": True, "codigos_recuperacion": codigos,
            "aviso": "Guarde estos 10 códigos en un lugar seguro: no se volverán a mostrar. Cada uno sirve una sola vez."}


# ---------------------------------------------------------------- verificación al ingresar y doble verificación
def _verificar_codigo(conn, usuario: UsuarioActual, metodo: str, codigo: str) -> tuple[bool, str | None]:
    """Devuelve (correcto, aviso). No cambia el estado de la sesión."""
    if metodo == "app":
        s = conn.execute("SELECT * FROM seguridad.fn_mfa_mi_secreto()").fetchone()
        if not s or not s["activo"]:
            return False, None
        paso = verificar_totp(descifrar_secreto(s["secreto_cifrado"], usuario.id_usuario, s["version_llave"]), codigo)
        ok = paso is not None and conn.execute("SELECT seguridad.fn_mfa_usar_paso(%s) AS ok", (paso,)).fetchone()["ok"]
        return bool(ok), None
    if metodo == "correo":
        ok = conn.execute("SELECT seguridad.fn_mfa_usar_codigo_correo(%s) AS ok",
                          (_hash("".join(ch for ch in codigo if ch.isdigit())),)).fetchone()["ok"]
        return bool(ok), None
    if metodo == "recuperacion":
        n = conn.execute("SELECT seguridad.fn_mfa_usar_recuperacion(%s) AS n", (_hash(_normalizar_recuperacion(codigo)),)).fetchone()["n"]
        if n < 0:
            return False, None
        return True, f"Usó un código de recuperación. Le quedan {n}." + (" Genere códigos nuevos en «Mi seguridad»." if n <= 3 else "")
    raise HTTPException(400, "Método no válido.")


def _fallo(usuario: UsuarioActual) -> HTTPException:
    """Cuenta el intento fallido; al quinto se bloquea la cuenta y se cierra la sesión."""
    with transaccion(usuario) as conn:
        f = conn.execute("SELECT * FROM seguridad.fn_registrar_fallo_codigo(%s, %s)",
                         (config.MAX_INTENTOS_FALLIDOS, config.BLOQUEO_MINUTOS)).fetchone()
        conn.execute("INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, ip_origen, detalle) VALUES (%s, 'MFA_FALLIDO', %s, %s)",
                     (usuario.nombre_usuario, usuario.ip, f"intento {f['intentos']}"))
        if f["bloqueada"]:
            conn.execute("INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, ip_origen, detalle) VALUES (%s, 'CUENTA_BLOQUEADA', %s, %s)",
                         (usuario.nombre_usuario, usuario.ip, "5 códigos MFA errados"))
            return HTTPException(423, f"Cuenta bloqueada por {config.BLOQUEO_MINUTOS} minutos tras 5 códigos errados.")
    return HTTPException(400, "Código incorrecto, vencido o ya usado.")


@router.post("/verificar")
def verificar(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(usuario_sesion)):
    if not usuario.mfa_activo:
        raise HTTPException(400, "Su usuario no tiene el MFA activo.")
    metodo, codigo = str(datos.get("metodo") or "app"), str(datos.get("codigo") or "")
    with transaccion(usuario) as conn:
        ok, aviso = _verificar_codigo(conn, usuario, metodo, codigo)
        if ok:
            conn.execute("SELECT seguridad.fn_reiniciar_mis_intentos()")
            conn.execute("SELECT seguridad.fn_mfa_marcar_sesion(%s, %s)", (usuario.id_sesion, metodo.upper()))
            conn.execute("INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, ip_origen, detalle) VALUES (%s, %s, %s, %s)",
                         (usuario.nombre_usuario, "MFA_RECUPERACION" if metodo == "recuperacion" else "MFA_OK", usuario.ip, metodo))
            equipo = None
            if datos.get("recordar_equipo") and usuario.codigo_rol != "ADMIN":
                equipo = secrets.token_urlsafe(32)
                conn.execute("SELECT seguridad.fn_mfa_recordar_equipo(%s, %s)", (_hash(equipo), datos.get("equipo")))
            correo = _correo_de(conn, usuario.id_usuario) if metodo == "recuperacion" else None
    if not ok:
        raise _fallo(usuario)
    if correo:
        _avisar(correo, usuario.nombre_completo, "Se usó un código de recuperación",
                f"Se ingresó al usuario {usuario.nombre_usuario} con un código de recuperación.", f"mfa_recuperacion:{usuario.id_sesion}")
    return {"verificada": True, "aviso": aviso, "equipo_confiable": equipo}


@router.post("/correo")
def enviar_codigo_correo(usuario: UsuarioActual = Depends(usuario_sesion)):
    codigo = f"{secrets.randbelow(1_000_000):06d}"
    with transaccion(usuario) as conn:
        correo = conn.execute("SELECT seguridad.fn_mfa_crear_codigo_correo(%s) AS c", (_hash(codigo),)).fetchone()["c"]
    from .autoservicio import _enviar, _ocultar_correo
    if not _enviar(correo, usuario.nombre_completo, f"Su código de verificación: {codigo}",
                   [f"Su código para ingresar a SGSINDICAL es {codigo}. Vence en 10 minutos.",
                    "Si usted no está intentando ingresar, cambie su contraseña: alguien la conoce."], f"mfa_correo:{usuario.id_sesion}"):
        raise HTTPException(503, "No se pudo enviar el correo (el servidor no tiene correo configurado). Use la aplicación o un código de recuperación.")
    return {"enviado_a": _ocultar_correo(correo), "vence_en_minutos": 10}


@router.post("/paso-adicional")
def paso_adicional(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    """Doble verificación para acciones críticas: vale 5 minutos."""
    metodo, codigo = str(datos.get("metodo") or "app"), str(datos.get("codigo") or "")
    with transaccion(usuario) as conn:
        ok, aviso = _verificar_codigo(conn, usuario, metodo, codigo)
        if ok:
            conn.execute("SELECT seguridad.fn_mfa_marcar_sesion(%s, %s)", (usuario.id_sesion, metodo.upper()))
            conn.execute("INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, ip_origen, detalle) VALUES (%s, 'MFA_PASO_ADICIONAL', %s, %s)",
                         (usuario.nombre_usuario, usuario.ip, metodo))
    if not ok:
        raise _fallo(usuario)
    return {"verificada": True, "vigente_minutos": 5, "aviso": aviso}


@router.post("/recuperacion")
def regenerar_codigos(usuario: UsuarioActual = Depends(usuario_actual)):
    exigir_paso_adicional(usuario)
    codigos = _codigos_recuperacion()
    with transaccion(usuario) as conn:
        conn.execute("SELECT seguridad.fn_mfa_regenerar_recuperacion(%s)", ([_hash(_normalizar_recuperacion(c)) for c in codigos],))
    return {"codigos_recuperacion": codigos, "aviso": "Los códigos anteriores dejaron de servir."}


@router.post("/equipos/cerrar")
def cerrar_equipos(usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        n = conn.execute("SELECT seguridad.fn_mfa_revocar_equipos(%s) AS n", (usuario.id_usuario,)).fetchone()["n"]
    return {"equipos_cerrados": n}


# ---------------------------------------------------------------- reinicio (administrador + Presidencia Nacional)
@router.post("/reinicios")
def solicitar_reinicio(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "actualizar"))):
    with transaccion(usuario) as conn:
        id_ = conn.execute("SELECT seguridad.fn_mfa_solicitar_reinicio(%s, %s) AS id", (datos.get("id_usuario"), datos.get("motivo"))).fetchone()["id"]
    return {"id_reinicio": id_, "estado": "PENDIENTE", "mensaje": "Solicitud registrada: la debe aprobar la Presidencia Nacional."}


@router.post("/reinicios/{id_reinicio}/{decision}")
def decidir_reinicio(id_reinicio: int, decision: str, datos: dict[str, Any] = Body(default={}),
                     usuario: UsuarioActual = Depends(usuario_actual)):
    if decision not in ("aprobar", "rechazar"):
        raise HTTPException(404, "Acción no válida.")
    with transaccion(usuario) as conn:
        f = conn.execute("SELECT * FROM seguridad.fn_mfa_decidir_reinicio(%s, %s, %s)",
                         (id_reinicio, decision == "aprobar", datos.get("observacion"))).fetchone()
    if f["estado"] == "APROBADO":
        _avisar(f["correo"], f["nombre"], "Se reinició su verificación en dos pasos",
                "Por solicitud aprobada por la Presidencia Nacional, se reinició su MFA. Al ingresar deberá configurarlo de nuevo.",
                f"mfa_reinicio:{id_reinicio}")
    return {"estado": f["estado"]}


@router.get("/reinicios")
def listar_reinicios(usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        if not conn.execute("SELECT seguridad.fn_es_admin() OR seguridad.fn_es_presidente_nacional() AS ok").fetchone()["ok"]:
            raise HTTPException(403, "Solo el administrador y la Presidencia Nacional.")
        filas = conn.execute("""SELECT r.id_reinicio, u.nombre_usuario, r.motivo, r.estado, s.nombre_usuario AS solicitado_por,
                                       r.fecha_solicitud, d.nombre_usuario AS decidido_por, r.fecha_decision
                                  FROM seguridad.mfa_reinicio r JOIN seguridad.usuario u ON u.id_usuario = r.id_usuario
                                  JOIN seguridad.usuario s ON s.id_usuario = r.id_usuario_solicita
                                  LEFT JOIN seguridad.usuario d ON d.id_usuario = r.id_usuario_decide
                                 ORDER BY r.fecha_solicitud DESC LIMIT 200""").fetchall()
    from .crud import serializar
    return [serializar(f) for f in filas]
