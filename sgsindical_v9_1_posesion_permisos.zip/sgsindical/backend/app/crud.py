"""CRUD genérico con permisos por módulo/acción y control de concurrencia optimista."""
from __future__ import annotations

import ipaddress
import uuid
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, Query, Request
from psycopg import sql

from .db import transaccion
from .recursos import RECURSOS, Recurso
from .seguridad import (UsuarioActual, exigir_paso_adicional, hash_contrasena, usuario_actual, validar_politica_contrasena,
                        verificar_permiso)

router = APIRouter(prefix="/api", tags=["datos"])

MAX_PAGINA = 200


# ---------------------------------------------------------------- utilidades
def serializar(valor: Any) -> Any:
    if isinstance(valor, dict):
        return {k: serializar(v) for k, v in valor.items()}
    if isinstance(valor, list):
        return [serializar(v) for v in valor]
    if isinstance(valor, Decimal):
        return str(valor)
    if isinstance(valor, (datetime, date, time)):
        return valor.isoformat()
    if isinstance(valor, timedelta):
        return f"{valor.days} días"
    if isinstance(valor, (uuid.UUID, ipaddress.IPv4Address, ipaddress.IPv6Address,
                          ipaddress.IPv4Network, ipaddress.IPv6Network)):
        return str(valor)
    return valor


def obtener_recurso(clave: str) -> Recurso:
    rec = RECURSOS.get(clave)
    if not rec:
        raise HTTPException(404, f"El recurso '{clave}' no existe.")
    return rec


def tabla_sql(rec: Recurso) -> sql.Composed:
    esquema, nombre = rec.esquema_tabla
    return sql.SQL("{}.{} AS t").format(sql.Identifier(esquema), sql.Identifier(nombre))


def tabla_sin_alias(rec: Recurso) -> sql.Composed:
    esquema, nombre = rec.esquema_tabla
    return sql.SQL("{}.{}").format(sql.Identifier(esquema), sql.Identifier(nombre))


def columnas_reales(rec: Recurso) -> list[str]:
    cols = [c["nombre"] for c in rec.campos if not c.get("virtual")]
    if rec.tabla.startswith("auditoria.") or not rec.con_version:
        return cols  # las tablas de auditoría no llevan versión
    return cols + ["version"]


_TIPO_SQL = {"decimal": "numeric", "int": "bigint", "date": "date", "bool": "boolean"}


def sensibles(rec: Recurso) -> dict[str, str]:
    """Columnas reservadas (Ley 1581) del recurso: nombre -> categoría."""
    return {c["nombre"]: c["sensible"] for c in rec.campos if c.get("sensible")}


def select_cols(rec: Recurso) -> sql.Composed:
    # Selección explícita: nunca se expone una columna que no esté en los metadatos (p. ej. hash_contrasena).
    # Los datos reservados (Ley 1581) nunca salen en listados ni fichas: se piden aparte (queda registro).
    res = sensibles(rec)
    partes = []
    for c in columnas_reales(rec):
        if c in res:
            tipo = _TIPO_SQL.get(rec.campo(c)["tipo"], "text")
            partes.append(sql.SQL("NULL::{} AS {}").format(sql.SQL(tipo), sql.Identifier(c)))
        else:
            partes.append(sql.SQL("t.{}").format(sql.Identifier(c)))
    if res:
        cat = next(iter(res.values()))
        persona = sql.SQL("t.id_persona") if rec.campo("id_persona") else sql.SQL("NULL::bigint")
        partes.append(sql.SQL("seguridad.fn_puede_ver_dato({}, {}) AS _puede_ver_reservado").format(sql.Literal(cat), persona))
    return sql.SQL(", ").join(partes)


def registrar_acceso(conn, rec: Recurso, tipo: str, id_persona=None, n: int | None = None, motivo: str | None = None) -> None:
    """Bitácora de accesos a datos personales (Ley 1581): quién consultó qué y cuándo."""
    if rec.acceso:
        conn.execute("SELECT seguridad.fn_registrar_acceso_dato(%s, %s, %s, NULL, %s, %s)",
                     (tipo, rec.clave, int(id_persona) if id_persona not in (None, "") else None, n, motivo))


def pk_desde_query(rec: Recurso, request: Request) -> dict[str, Any]:
    valores = {}
    for c in rec.pk:
        v = request.query_params.get(c)
        if v is None or v == "":
            raise HTTPException(400, f"Falta la llave '{c}'.")
        valores[c] = v
    return valores


def where_pk(rec: Recurso, pk: dict[str, Any]) -> tuple[sql.Composed, list[Any]]:
    partes = [sql.SQL("t.{} = %s").format(sql.Identifier(c)) for c in rec.pk]
    return sql.SQL(" AND ").join(partes), [pk[c] for c in rec.pk]


def limpiar_datos(rec: Recurso, datos: dict[str, Any], al_crear: bool) -> dict[str, Any]:
    permitidas = rec.escribibles(al_crear)
    limpios: dict[str, Any] = {}
    for k, v in datos.items():
        if k not in permitidas:
            continue  # se ignoran columnas no permitidas (radicados, auditoría, llaves automáticas...)
        if isinstance(v, str):
            v = v.strip()
            if v == "":
                v = None
        limpios[k] = v
    if al_crear:
        faltan = [c["etiqueta"] for c in rec.campos
                  if c.get("req") and not c.get("virtual") and c["nombre"] in permitidas and limpios.get(c["nombre"]) is None
                  and not (c.get("o_texto") and limpios.get(c["o_texto"]))]   # lugar escrito: la base busca su código DIVIPOLA
        if faltan:
            raise HTTPException(400, "Campos obligatorios sin diligenciar: " + ", ".join(faltan) + ".")
    return limpios


def accion_de(operacion: str) -> str:
    return {"crear": "registrar", "editar": "actualizar", "eliminar": "eliminar"}[operacion]


def exigir_operacion(rec: Recurso, operacion: str) -> None:
    if operacion not in rec.operaciones:
        raise HTTPException(405, f"'{rec.titulo}' no permite la operación {operacion} (política de trazabilidad).")


# Cambios de roles y permisos: acción crítica (doble verificación con MFA)
RECURSOS_CRITICOS = {"permisos", "roles", "ambitos_usuario"}
CAMPOS_CRITICOS_USUARIO = {"codigo_rol", "ambito_nacional", "activo"}


def exigir_recurso_del_rol(conn, rec: Recurso, usuario: UsuarioActual, operacion: str, datos: dict | None = None) -> None:
    """Roles con restricción fina (p. ej. Ventanilla): solo escriben en los recursos que tienen asignados.
    Además, cambiar roles o permisos exige la doble verificación (MFA)."""
    if rec.clave in RECURSOS_CRITICOS or (rec.clave == "usuarios" and operacion != "crear"
                                           and CAMPOS_CRITICOS_USUARIO & set((datos or {}).keys())):
        exigir_paso_adicional(usuario)
    filas = conn.execute("SELECT recurso, operaciones FROM seguridad.recurso_permitido_rol WHERE codigo_rol = %s",
                         (usuario.codigo_rol,)).fetchall()
    if filas and not any(f["recurso"] == rec.clave and operacion in f["operaciones"] for f in filas):
        raise HTTPException(403, f"Su rol ({usuario.codigo_rol}) no puede {operacion} en «{rec.titulo}».")


# ---------------------------------------------------------------- reglas especiales por recurso
def antes_de_guardar(conn, rec: Recurso, datos: dict, originales: dict, usuario: UsuarioActual, al_crear: bool,
                     pk: dict | None = None) -> None:
    if rec.clave == "documentos":
        if al_crear:
            fila = conn.execute("SELECT categoria_flujo FROM gestion_documental.tipo_documento WHERE id_tipo_documento = %s",
                                (datos.get("id_tipo_documento"),)).fetchone()
            if not fila:
                raise HTTPException(400, "El tipo documental no existe.")
            datos["flujo"] = fila["categoria_flujo"]
        obs = (originales.get("_observacion") or "").strip()
        if obs:
            conn.execute("SELECT set_config('app.observacion', %s, true)", (obs[:2000],))

    if rec.clave == "afiliados_empresa" and originales.get("_salario_desde"):
        conn.execute("SELECT set_config('app.salario_desde', %s, true)", (str(originales["_salario_desde"])[:10],))
    if rec.clave == "afiliados_empresa" and originales.get("_pertenencia"):
        # Cambio de sede y de pertenencia en la misma transacción (la regla se verifica al confirmar)
        id_persona = datos.get("id_persona") if al_crear else (pk or {}).get("id_persona")
        conn.execute("UPDATE gobernanza.afiliado SET id_estamento_pertenencia = %s WHERE id_persona = %s",
                     (originales["_pertenencia"], id_persona))

    elif rec.clave == "usuarios":
        if al_crear:
            contrasena = originales.get("contrasena") or ""
            validar_politica_contrasena(contrasena, datos.get("nombre_usuario", ""))
            datos["hash_contrasena"] = hash_contrasena(contrasena)
            datos.setdefault("debe_cambiar_contrasena", True)
        elif pk and int(pk["id_usuario"]) == usuario.id_usuario:
            if datos.get("activo") is False or ("codigo_rol" in datos and datos["codigo_rol"] != usuario.codigo_rol):
                raise HTTPException(400, "No puede desactivarse ni cambiarse el rol a sí mismo.")

    elif rec.clave == "permisos" and not al_crear and pk and pk["codigo_rol"] == "ADMIN" and pk["modulo"] == "ADMINISTRACION":
        if datos.get("puede_consultar") is False or datos.get("puede_actualizar") is False:
            raise HTTPException(400, "No se puede quitar al rol ADMIN el acceso a Administración (evita quedar sin administrador).")


def antes_de_eliminar(conn, rec: Recurso, pk: dict, usuario: UsuarioActual) -> None:
    if rec.clave == "usuarios" and int(pk["id_usuario"]) == usuario.id_usuario:
        raise HTTPException(400, "No puede eliminar su propio usuario.")
    if rec.clave == "roles":
        fila = conn.execute("SELECT es_sistema FROM seguridad.rol_app WHERE codigo_rol = %s", (pk["codigo_rol"],)).fetchone()
        if fila and fila["es_sistema"]:
            raise HTTPException(400, "Los roles del sistema no se pueden eliminar.")
    if rec.clave == "permisos" and pk["codigo_rol"] == "ADMIN":
        raise HTTPException(400, "Los permisos del rol ADMIN no se pueden eliminar.")


# ---------------------------------------------------------------- endpoints
@router.get("/r/{clave}")
def listar(
    clave: str,
    request: Request,
    q: str | None = None,
    pagina: int = Query(1, ge=1),
    tam: int = Query(25, ge=1, le=MAX_PAGINA),
    orden: str | None = None,
    dir: str = Query("asc", pattern="^(asc|desc)$"),
    inactivos: bool = False,
    usuario: UsuarioActual = Depends(usuario_actual),
):
    rec = obtener_recurso(clave)
    verificar_permiso(usuario, rec.modulo, "consultar")

    condiciones: list[sql.Composable] = []
    params: list[Any] = []
    if rec.baja == "inactivar" and not inactivos and "f_activo" not in request.query_params:
        condiciones.append(sql.SQL("t.activo"))  # por defecto solo los activos; ?inactivos=true muestra todos
    if q and rec.busqueda:
        condiciones.append(sql.SQL("(") + sql.SQL(" OR ").join(
            sql.SQL("t.{}::text ILIKE %s").format(sql.Identifier(c)) for c in rec.busqueda) + sql.SQL(")"))
        params.extend([f"%{q}%"] * len(rec.busqueda))
    # Filtros exactos: ?f_id_documento=5
    nombres = {c["nombre"] for c in rec.campos if not c.get("virtual") and not c.get("sensible")}
    for k, v in request.query_params.items():
        if k.startswith("f_") and k[2:] in nombres and v != "":
            condiciones.append(sql.SQL("t.{}::text = %s").format(sql.Identifier(k[2:])))
            params.append(v)
    where = sql.SQL(" WHERE ") + sql.SQL(" AND ").join(condiciones) if condiciones else sql.SQL("")

    if orden and orden in nombres:
        order_by = sql.SQL("t.{} {} NULLS LAST").format(sql.Identifier(orden), sql.SQL("DESC" if dir == "desc" else "ASC"))
    else:
        order_by = sql.SQL(rec.orden)

    with transaccion(usuario) as conn:
        total = conn.execute(sql.SQL("SELECT count(*) AS n FROM {}{}").format(tabla_sql(rec), where), params).fetchone()["n"]
        filas = conn.execute(
            sql.SQL("SELECT {} FROM {}{} ORDER BY {} LIMIT %s OFFSET %s").format(select_cols(rec), tabla_sql(rec), where, order_by),
            params + [tam, (pagina - 1) * tam],
        ).fetchall()
        if filas:
            filtro = "; ".join(f"{k}={v}" for k, v in request.query_params.items() if k.startswith("f_") or k == "q")
            registrar_acceso(conn, rec, "LISTADO", request.query_params.get("f_id_persona"), len(filas), filtro or None)
    return {"total": total, "pagina": pagina, "tam": tam, "filas": [serializar(f) for f in filas]}


@router.get("/r/{clave}/registro")
def obtener(clave: str, request: Request, usuario: UsuarioActual = Depends(usuario_actual)):
    rec = obtener_recurso(clave)
    verificar_permiso(usuario, rec.modulo, "consultar")
    pk = pk_desde_query(rec, request)
    cond, params = where_pk(rec, pk)
    with transaccion(usuario) as conn:
        fila = conn.execute(sql.SQL("SELECT {} FROM {} WHERE {}").format(select_cols(rec), tabla_sql(rec), cond), params).fetchone()
        if fila:
            registrar_acceso(conn, rec, "FICHA", fila.get("id_persona"), 1)
    if not fila:
        raise HTTPException(404, "El registro no existe, fue eliminado o está fuera de su ámbito territorial.")
    return serializar(fila)


@router.post("/r/{clave}", status_code=201)
def crear(clave: str, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    rec = obtener_recurso(clave)
    exigir_operacion(rec, "crear")
    verificar_permiso(usuario, rec.modulo, "registrar")
    limpios = limpiar_datos(rec, datos, al_crear=True)
    with transaccion(usuario) as conn:
        exigir_recurso_del_rol(conn, rec, usuario, "crear")
        antes_de_guardar(conn, rec, limpios, datos, usuario, al_crear=True)
        if not limpios:
            raise HTTPException(400, "No se enviaron datos.")
        cols = list(limpios.keys())
        consulta = sql.SQL("INSERT INTO {} ({}) VALUES ({}) RETURNING {}").format(
            tabla_sql(rec),
            sql.SQL(", ").join(sql.Identifier(c) for c in cols),
            sql.SQL(", ").join(sql.Placeholder() for _ in cols),
            select_cols(rec),
        )
        fila = conn.execute(consulta, [limpios[c] for c in cols]).fetchone()
    return serializar(fila)


@router.put("/r/{clave}/registro")
def actualizar(clave: str, request: Request, datos: dict[str, Any] = Body(...),
               usuario: UsuarioActual = Depends(usuario_actual)):
    rec = obtener_recurso(clave)
    exigir_operacion(rec, "editar")
    verificar_permiso(usuario, rec.modulo, "actualizar")
    pk = pk_desde_query(rec, request)
    version = datos.get("version")
    if version is None:
        raise HTTPException(400, "Falta la versión del registro (control de concurrencia).")
    limpios = limpiar_datos(rec, datos, al_crear=False)
    cond, params = where_pk(rec, pk)
    with transaccion(usuario) as conn:
        exigir_recurso_del_rol(conn, rec, usuario, "editar", limpios)
        antes_de_guardar(conn, rec, limpios, datos, usuario, al_crear=False, pk=pk)
        if not limpios:
            raise HTTPException(400, "No hay cambios para guardar.")
        consulta = sql.SQL("UPDATE {} SET {} WHERE {} AND t.version = %s RETURNING {}").format(
            tabla_sql(rec),
            sql.SQL(", ").join(sql.SQL("{} = %s").format(sql.Identifier(c)) for c in limpios),
            cond,
            select_cols(rec),
        )
        fila = conn.execute(consulta, list(limpios.values()) + params + [int(version)]).fetchone()
        if fila is None:
            actual = conn.execute(sql.SQL("SELECT {} FROM {} WHERE {}").format(select_cols(rec), tabla_sql(rec), cond),
                                  params).fetchone()
    if fila is None:
        if actual is None:
            raise HTTPException(404, "El registro ya no existe o está fuera de su ámbito territorial.")
        raise HTTPException(409, {
            "mensaje": "Otro usuario modificó este registro mientras usted lo editaba. Revise los datos actuales "
                       "y vuelva a aplicar sus cambios.",
            "actual": serializar(actual),
        })
    return serializar(fila)


@router.delete("/r/{clave}/registro")
def eliminar(clave: str, request: Request, version: int = Query(...), usuario: UsuarioActual = Depends(usuario_actual)):
    rec = obtener_recurso(clave)
    exigir_operacion(rec, "eliminar")
    verificar_permiso(usuario, rec.modulo, "eliminar")
    pk = pk_desde_query(rec, request)
    cond, params = where_pk(rec, pk)
    with transaccion(usuario) as conn:
        exigir_recurso_del_rol(conn, rec, usuario, "eliminar")
        antes_de_eliminar(conn, rec, pk, usuario)
        fila = conn.execute(sql.SQL("DELETE FROM {} WHERE {} AND t.version = %s RETURNING 1 AS ok").format(
            tabla_sql(rec), cond), params + [version]).fetchone()
        existe = None
        if fila is None:
            existe = conn.execute(sql.SQL("SELECT 1 AS ok FROM {} WHERE {}").format(tabla_sql(rec), cond), params).fetchone()
    if fila is None:
        if existe is None:
            raise HTTPException(404, "El registro ya había sido eliminado.")
        raise HTTPException(409, {"mensaje": "Otro usuario modificó este registro. Recargue antes de eliminarlo."})
    return {"eliminado": True}


# ---------------------------------------------------------------- R-01: inactivar, reactivar y anular
def _baja(rec: Recurso, esperada: str) -> None:
    if rec.baja != esperada:
        verbo = {"inactivar": "inactivar", "anular": "anular"}[esperada]
        raise HTTPException(405, f"'{rec.titulo}' no se puede {verbo}.")


def _cambiar_activo(clave: str, request: Request, datos: dict, usuario: UsuarioActual, activo: bool):
    rec = obtener_recurso(clave)
    _baja(rec, "inactivar")
    verificar_permiso(usuario, rec.modulo, "eliminar")
    pk = pk_desde_query(rec, request)
    version = datos.get("version")
    if version is None:
        raise HTTPException(400, "Falta la versión del registro (control de concurrencia).")
    motivo = (datos.get("motivo") or "").strip() or None
    if not activo and (motivo is None or len(motivo) < 10):
        raise HTTPException(400, "Escriba el motivo de la inactivación (mínimo 10 caracteres).")
    if rec.clave == "roles" and not activo and pk.get("codigo_rol") == usuario.codigo_rol:
        raise HTTPException(400, "No puede inactivar su propio rol.")
    cond, params = where_pk(rec, pk)
    with transaccion(usuario) as conn:
        exigir_recurso_del_rol(conn, rec, usuario, "inactivar")
        fila = conn.execute(sql.SQL("UPDATE {} SET activo = %s, motivo_inactivacion = %s WHERE {} AND t.version = %s RETURNING {}").format(
            tabla_sql(rec), cond, select_cols(rec)), [activo, motivo] + params + [int(version)]).fetchone()
        actual = None
        if fila is None:
            actual = conn.execute(sql.SQL("SELECT {} FROM {} WHERE {}").format(select_cols(rec), tabla_sql(rec), cond), params).fetchone()
    if fila is None:
        if actual is None:
            raise HTTPException(404, "El registro no existe o está fuera de su ámbito territorial.")
        raise HTTPException(409, {"mensaje": "Otro usuario modificó este registro. Recárguelo y vuelva a intentarlo.",
                                  "actual": serializar(actual)})
    return serializar(fila)


@router.post("/r/{clave}/inactivar")
def inactivar(clave: str, request: Request, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    """Nada se borra: el registro queda inactivo, con motivo, fecha y usuario."""
    return _cambiar_activo(clave, request, datos, usuario, False)


@router.post("/r/{clave}/reactivar")
def reactivar(clave: str, request: Request, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    return _cambiar_activo(clave, request, datos, usuario, True)


@router.post("/r/{clave}/anular")
def anular(clave: str, request: Request, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    """Anula un movimiento financiero (queda en el historial, fuera de saldos y totales). Es definitivo."""
    rec = obtener_recurso(clave)
    _baja(rec, "anular")
    verificar_permiso(usuario, rec.modulo, "eliminar")
    pk = pk_desde_query(rec, request)
    cond, params = where_pk(rec, pk)
    with transaccion(usuario) as conn:
        exigir_recurso_del_rol(conn, rec, usuario, "anular")
        # La lectura con RLS confirma que el registro está dentro del ámbito de quien anula
        visible = conn.execute(sql.SQL("SELECT 1 AS ok FROM {} WHERE {}").format(tabla_sql(rec), cond), params).fetchone()
        if not visible:
            raise HTTPException(404, "El registro no existe o está fuera de su ámbito territorial.")
        r = conn.execute("SELECT finanzas.fn_anular_movimiento(%s, %s, %s) AS r",
                         (rec.esquema_tabla[1], int(pk[rec.pk[0]]), datos.get("motivo") or "")).fetchone()["r"]
        fila = conn.execute(sql.SQL("SELECT {} FROM {} WHERE {}").format(select_cols(rec), tabla_sql(rec), cond), params).fetchone()
    return {"resultado": r, "registro": serializar(fila)}


# Listas dependientes: el campo 'depende' filtra por la columna homónima del recurso referenciado
_CAMPOS_DEPENDIENTES: dict[str, list[dict]] = {}
for _r in RECURSOS.values():
    for _c in _r.campos:
        if _c.get("fk") and _c.get("depende") and _c["fk"] in RECURSOS and RECURSOS[_c["fk"]].campo(_c["depende"]):
            _CAMPOS_DEPENDIENTES.setdefault(_c["fk"], []).append(_c)


@router.get("/opciones/{clave}")
def opciones(clave: str, q: str | None = None, ids: str | None = None, depende: str | None = None,
             usuario: UsuarioActual = Depends(usuario_actual)):
    """Valor/etiqueta para listas desplegables y para mostrar nombres en lugar de IDs."""
    rec = obtener_recurso(clave)
    if not usuario.puede(rec.modulo, "consultar"):
        return []
    # Sedes de una empresa concreta: se muestran aunque la empresa aún no tenga afiliados del ámbito
    if clave == "sedes" and depende and depende.isdigit() and not ids:
        with transaccion(usuario) as conn:
            filas = conn.execute("SELECT * FROM seguridad.fn_sedes_de_empresa(%s)", (int(depende),)).fetchall()
        return [serializar(f) for f in filas if not q or q.lower() in f["etiqueta"].lower()]
    extra = []
    if clave == "empresas" and q and sum(ch.isdigit() for ch in q) >= 6:
        # Búsqueda exacta por NIT fuera del ámbito, para vincular afiliados a una empresa existente
        with transaccion(usuario) as conn:
            extra = conn.execute("SELECT * FROM seguridad.fn_buscar_empresa_por_nit(%s)", (q,)).fetchall()
    if len(rec.pk) != 1:
        raise HTTPException(400, "Este recurso no admite selección simple.")
    pkc = sql.Identifier(rec.pk[0])
    etiqueta = sql.SQL(rec.etiqueta)
    condiciones, params = [], []
    col_dep = next((c["depende"] for c in _CAMPOS_DEPENDIENTES.get(clave, [])), None)
    if depende and col_dep and not ids:
        condiciones.append(sql.SQL("t.{}::text = %s").format(sql.Identifier(col_dep)))
        params.append(depende)
    if rec.baja == "inactivar" and not ids:
        condiciones.append(sql.SQL("t.activo"))
    if clave in ("paises", "departamentos", "municipios") and not ids:
        condiciones.append(sql.SQL("t.activo"))
    if ids:
        lista = [i for i in ids.split(",") if i][:500]
        condiciones.append(sql.SQL("t.{}::text = ANY(%s)").format(pkc))
        params.append(lista)
    if q:
        condiciones.append(sql.SQL("({})::text ILIKE %s").format(etiqueta))
        params.append(f"%{q}%")
    where = sql.SQL(" WHERE ") + sql.SQL(" AND ").join(condiciones) if condiciones else sql.SQL("")
    with transaccion(usuario) as conn:
        filas = conn.execute(
            sql.SQL("SELECT t.{} AS valor, ({}) AS etiqueta FROM {}{} ORDER BY {} LIMIT 300").format(
                pkc, etiqueta, tabla_sql(rec), where, sql.SQL(rec.orden_opciones or "2")), params).fetchall()
    vistos = {f["valor"] for f in filas}
    return [serializar(f) for f in filas] + [serializar(f) for f in extra if f["valor"] not in vistos]
