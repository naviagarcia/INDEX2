"""Escritos jurídicos asistidos por IA: fuentes (texto, PDF, Word, audio, video), redacción con Claude,
edición, revisión (abogado, Presidencia, Secretaría; los demás comentan), radicación con PDF y Word.

Las reglas de aprobación, versiones y radicación están en la base (db/02h)."""
from __future__ import annotations

import hashlib
import io
import logging
import os
import re
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, BackgroundTasks, Body, Depends, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response

from . import extraccion, ia
from .config import config
from .crud import serializar
from .db import transaccion
from .seguridad import UsuarioActual, requiere

router = APIRouter(prefix="/api/escritos", tags=["escritos jurídicos"])
log = logging.getLogger("sgsindical.escritos")
MAX_TEXTO_FUENTE = 500_000


def _dir_fuentes() -> Path:
    d = config.UPLOAD_DIR / "fuentes"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _ruta_fuente(f: dict) -> Path:
    return _dir_fuentes() / f"{f['id_fuente']}_{f['hash_sha256'][:12]}{Path(f['nombre_archivo'] or '').suffix.lower()}"


def _escrito(conn, id_escrito: int) -> dict:
    e = conn.execute("""
        SELECT e.*, t.nombre AS tipo_nombre, t.orientacion, t.sigla_tipo_documento, j.nombre_estamento AS junta,
               j.tipo_estamento AS tipo_junta, j.municipio, d.radicado_alfanumerico AS radicado, d.hash_sha256 AS hash_documento
          FROM gestion_documental.escrito e
          JOIN gestion_documental.tipo_escrito t ON t.codigo = e.codigo_tipo
          JOIN gobernanza.estamento j ON j.id_estamento = e.id_estamento
          LEFT JOIN gestion_documental.documento d ON d.id_documento = e.id_documento
         WHERE e.id_escrito = %s""", (id_escrito,)).fetchone()
    if not e:
        raise HTTPException(404, "El escrito no existe o está fuera de su ámbito territorial.")
    return e


def _firmantes(conn, id_estamento: int) -> str:
    filas = conn.execute("""
        SELECT p.primer_nombre, p.segundo_nombre, p.primer_apellido, p.segundo_apellido, c.nombre AS cargo
          FROM gobernanza.directivo_estamento d
          JOIN gobernanza.cargo_directivo c ON c.id_cargo = d.id_cargo
          JOIN gobernanza.persona p ON p.id_persona = d.id_persona
         WHERE d.id_estamento = %s AND d.fecha_retiro IS NULL AND (c.codigo LIKE 'PRES\\_%%' OR c.codigo LIKE 'SGEN\\_%%')
         ORDER BY c.orden""", (id_estamento,)).fetchall()
    from .notificaciones import nombre_propio
    return "; ".join(f"{nombre_propio(f['primer_nombre'], f['segundo_nombre'], f['primer_apellido'], f['segundo_apellido'])}, "
                     f"{f['cargo'].capitalize()}" for f in filas)


# ---------------------------------------------------------------- detalle
@router.get("/{id_escrito}")
def detalle(id_escrito: int, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        e = _escrito(conn, id_escrito)
        fuentes = conn.execute("""SELECT id_fuente, clase, nombre_archivo, hash_sha256, tamano_bytes, duracion_segundos, estado,
                                         detalle_error, fecha_creacion, usuario_creacion, version, length(texto) AS caracteres,
                                         left(texto, 3000) AS vista_previa
                                    FROM gestion_documental.escrito_fuente WHERE id_escrito = %s ORDER BY id_fuente""",
                               (id_escrito,)).fetchall()
        versiones = conn.execute("""SELECT numero, origen, modelo_ia, nombre_usuario, fecha, instrucciones
                                      FROM gestion_documental.escrito_version WHERE id_escrito = %s ORDER BY numero DESC""",
                                 (id_escrito,)).fetchall()
        revisiones = conn.execute("""SELECT numero_version, rol, decision, comentario, nombre_usuario, cargo, fecha
                                       FROM gestion_documental.escrito_revision WHERE id_escrito = %s ORDER BY fecha DESC, id_revision DESC""",
                                  (id_escrito,)).fetchall()
        mi = conn.execute("SELECT * FROM gestion_documental.fn_rol_revision(%s)", (id_escrito,)).fetchone()
        mesa = conn.execute("SELECT rol FROM gestion_documental.fn_cargo_mesa(%s)", (e["id_estamento"],)).fetchone()
    actuales = [r for r in revisiones if r["numero_version"] == e["version_actual"]]
    aprobaciones = {rol: next((r for r in actuales if r["rol"] == rol and r["decision"] == "APRUEBA"), None)
                    for rol in ("ABOGADO", "PRESIDENCIA", "SECRETARIA")}
    return serializar({"escrito": e, "fuentes": fuentes, "versiones": versiones, "revisiones": revisiones,
                       "aprobaciones": aprobaciones, "mi_rol": mi["rol"], "mi_cargo": mi["cargo"],
                       "puedo_radicar": bool(mesa and mesa["rol"]) and e["estado"] == "APROBADO",
                       "ia": {"proveedor": config.IA_PROVEEDOR, "modelo": config.IA_MODELO,
                              "configurada": config.IA_PROVEEDOR == "simulado" or bool(config.ANTHROPIC_API_KEY)}})


@router.get("/{id_escrito}/versiones/{numero}")
def version(id_escrito: int, numero: int, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        v = conn.execute("SELECT * FROM gestion_documental.escrito_version WHERE id_escrito = %s AND numero = %s",
                         (id_escrito, numero)).fetchone()
    if not v:
        raise HTTPException(404, "La versión no existe.")
    return serializar(v)


# ---------------------------------------------------------------- fuentes
def procesar_fuente(id_fuente: int, usuario: UsuarioActual) -> None:
    try:
        with transaccion(usuario) as conn:
            f = conn.execute("SELECT * FROM gestion_documental.escrito_fuente WHERE id_fuente = %s", (id_fuente,)).fetchone()
            if not f:
                return
            conn.execute("SELECT gestion_documental.fn_registrar_extraccion(%s, 'PROCESANDO', NULL)", (id_fuente,))
        try:
            texto, dur = extraccion.extraer(_ruta_fuente(f), f["clase"])
            texto = texto.replace("\x00", "")
            estado, error = "LISTO", None
            if len(texto) > MAX_TEXTO_FUENTE:
                texto = texto[:MAX_TEXTO_FUENTE] + "\n[… texto recortado por su longitud …]"
        except extraccion.ErrorExtraccion as e:
            texto, dur, estado, error = None, None, "ERROR", str(e)
        except Exception as e:  # noqa: BLE001
            log.exception("Error extrayendo la fuente %s", id_fuente)
            texto, dur, estado, error = None, None, "ERROR", f"Error inesperado: {type(e).__name__}: {e}"
        with transaccion(usuario) as conn:
            conn.execute("SELECT gestion_documental.fn_registrar_extraccion(%s, %s, %s, %s, %s)", (id_fuente, estado, texto, error, dur))
    except Exception:  # noqa: BLE001
        log.exception("No se pudo registrar la extracción de la fuente %s", id_fuente)


@router.post("/{id_escrito}/fuentes", status_code=201)
async def subir_fuente(id_escrito: int, tareas: BackgroundTasks, archivo: UploadFile = File(...),
                       usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "actualizar"))):
    nombre = re.sub(r"[^\w.\- ]", "_", Path(archivo.filename or "fuente").name)[:150]
    try:
        clase = extraccion.clase_de(nombre)
    except extraccion.ErrorExtraccion as e:
        raise HTTPException(400, str(e))
    temporal = _dir_fuentes() / f".subiendo_{id_escrito}_{os.getpid()}_{datetime.now().timestamp()}"
    h, total, limite = hashlib.sha256(), 0, config.FUENTE_MAX_MB * 1024 * 1024
    try:
        with temporal.open("wb") as destino:
            while bloque := await archivo.read(1024 * 1024):
                total += len(bloque)
                if total > limite:
                    raise HTTPException(413, f"El archivo supera el máximo de {config.FUENTE_MAX_MB} MB.")
                h.update(bloque)
                destino.write(bloque)
        if total == 0:
            raise HTTPException(400, "El archivo está vacío.")
        with transaccion(usuario) as conn:
            _escrito(conn, id_escrito)
            f = conn.execute("""INSERT INTO gestion_documental.escrito_fuente (id_escrito, clase, nombre_archivo, hash_sha256, tamano_bytes)
                                VALUES (%s, %s, %s, %s, %s) RETURNING *""", (id_escrito, clase, nombre, h.hexdigest(), total)).fetchone()
            shutil.move(str(temporal), _ruta_fuente(f))
    finally:
        temporal.unlink(missing_ok=True)
    tareas.add_task(procesar_fuente, f["id_fuente"], usuario)
    return serializar({k: f[k] for k in ("id_fuente", "clase", "nombre_archivo", "hash_sha256", "tamano_bytes", "estado")})


@router.post("/{id_escrito}/fuentes/texto", status_code=201)
def fuente_texto(id_escrito: int, datos: dict[str, Any] = Body(...),
                 usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "actualizar"))):
    texto = (datos.get("texto") or "").strip()
    if not texto:
        raise HTTPException(400, "Escriba o pegue el texto.")
    if len(texto) > MAX_TEXTO_FUENTE:
        raise HTTPException(400, "El texto es demasiado largo; adjúntelo como archivo.")
    nombre = (datos.get("nombre") or "Texto pegado").strip()[:150]
    with transaccion(usuario) as conn:
        _escrito(conn, id_escrito)
        f = conn.execute("""INSERT INTO gestion_documental.escrito_fuente (id_escrito, clase, nombre_archivo, estado, texto, tamano_bytes)
                            VALUES (%s, 'TEXTO', %s, 'LISTO', %s, %s) RETURNING id_fuente, clase, nombre_archivo, estado""",
                         (id_escrito, nombre, texto, len(texto.encode()))).fetchone()
    return serializar(f)


@router.delete("/{id_escrito}/fuentes/{id_fuente}")
def borrar_fuente(id_escrito: int, id_fuente: int, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "actualizar"))):
    with transaccion(usuario) as conn:
        f = conn.execute("DELETE FROM gestion_documental.escrito_fuente WHERE id_fuente = %s AND id_escrito = %s RETURNING *",
                         (id_fuente, id_escrito)).fetchone()
    if not f:
        raise HTTPException(404, "La fuente no existe.")
    if f["hash_sha256"]:
        _ruta_fuente(f).unlink(missing_ok=True)
    return {"eliminada": True}


@router.get("/{id_escrito}/fuentes/{id_fuente}/archivo")
def descargar_fuente(id_escrito: int, id_fuente: int, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        f = conn.execute("SELECT * FROM gestion_documental.escrito_fuente WHERE id_fuente = %s AND id_escrito = %s",
                         (id_fuente, id_escrito)).fetchone()
    if not f or not f["hash_sha256"]:
        raise HTTPException(404, "La fuente no tiene archivo.")
    ruta = _ruta_fuente(f)
    if not ruta.is_file():
        raise HTTPException(410, "El archivo de la fuente no se encuentra.")
    return FileResponse(ruta, filename=f["nombre_archivo"])


@router.get("/{id_escrito}/fuentes/{id_fuente}/texto")
def texto_fuente(id_escrito: int, id_fuente: int, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        f = conn.execute("SELECT id_fuente, nombre_archivo, clase, estado, texto FROM gestion_documental.escrito_fuente "
                         "WHERE id_fuente = %s AND id_escrito = %s", (id_fuente, id_escrito)).fetchone()
    if not f:
        raise HTTPException(404, "La fuente no existe.")
    return serializar(f)


# ---------------------------------------------------------------- redacción con IA
def _redactar_en_segundo_plano(id_escrito: int, base: int, datos: dict, usuario: UsuarioActual) -> None:
    try:
        cuerpo, notas, modelo = ia.redactar(datos)
        with transaccion(usuario) as conn:
            conn.execute("SELECT gestion_documental.fn_guardar_version_escrito(%s, %s, %s, 'IA', %s, %s, %s)",
                         (id_escrito, base, cuerpo, notas, datos.get("nuevas_instrucciones") or datos.get("instrucciones"), modelo))
    except Exception as e:  # noqa: BLE001
        mensaje = str(e) if isinstance(e, ia.ErrorIA) else getattr(getattr(e, "diag", None), "message_primary", None) or f"{type(e).__name__}: {e}"
        if not isinstance(e, ia.ErrorIA):
            log.exception("Falló la redacción del escrito %s", id_escrito)
        try:
            with transaccion(usuario) as conn:
                conn.execute("SELECT gestion_documental.fn_marcar_generacion(%s, FALSE, %s)", (id_escrito, mensaje[:1000]))
        except Exception:  # noqa: BLE001
            log.exception("No se pudo registrar el error de redacción del escrito %s", id_escrito)


@router.post("/{id_escrito}/generar", status_code=202)
def generar(id_escrito: int, tareas: BackgroundTasks, datos: dict[str, Any] = Body(default={}),
            usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "actualizar"))):
    """Pide a la IA una versión nueva. Corre en segundo plano: consulte el detalle hasta que 'generando' sea falso."""
    if config.IA_PROVEEDOR != "simulado" and not config.ANTHROPIC_API_KEY:
        raise HTTPException(503, "La redacción con IA no está configurada: falta ANTHROPIC_API_KEY en el archivo .env del servidor.")
    nuevas = (datos.get("instrucciones") or "").strip() or None
    with transaccion(usuario) as conn:
        e = _escrito(conn, id_escrito)
        fuentes = conn.execute("SELECT clase, nombre_archivo, estado, texto FROM gestion_documental.escrito_fuente "
                               "WHERE id_escrito = %s ORDER BY id_fuente", (id_escrito,)).fetchall()
        if any(f["estado"] in ("PENDIENTE", "PROCESANDO") for f in fuentes):
            raise HTTPException(409, "Hay fuentes que aún se están procesando (transcripción o extracción). Espere a que terminen.")
        listas = [f for f in fuentes if f["estado"] == "LISTO" and (f["texto"] or "").strip()]
        if not listas and not (e["instrucciones"] or nuevas):
            raise HTTPException(400, "Agregue al menos un documento fuente (texto, PDF, Word, audio o video) o escriba las instrucciones.")
        comentarios = [r["comentario"] for r in conn.execute(
            """SELECT comentario FROM gestion_documental.escrito_revision
                WHERE id_escrito = %s AND numero_version = %s AND decision IN ('CAMBIOS', 'COMENTA') ORDER BY fecha""",
            (id_escrito, e["version_actual"])).fetchall()] if e["version_actual"] else []
        firmantes = _firmantes(conn, e["id_estamento"])
        conn.execute("SELECT gestion_documental.fn_marcar_generacion(%s, TRUE)", (id_escrito,))
    restante = config.MAX_CARACTERES_FUENTES
    lista = []
    for f in listas:
        t = f["texto"][:max(restante, 0)]
        if len(t) < len(f["texto"]):
            t += "\n[… fuente recortada por el límite de longitud …]"
        restante -= len(t)
        lista.append({"nombre": f["nombre_archivo"], "clase": f["clase"], "texto": t})
    paquete = {"tipo_nombre": e["tipo_nombre"], "orientacion": e["orientacion"], "junta": e["junta"], "tipo_junta": e["tipo_junta"],
               "municipio": e["municipio"], "firmantes": firmantes, "titulo": e["titulo"],
               "destinatario_persona": e["destinatario_persona"], "destinatario_institucion": e["destinatario_institucion"],
               "instrucciones": e["instrucciones"], "fuentes": lista, "nuevas_instrucciones": nuevas,
               "version_anterior": e["contenido"] if e["version_actual"] else None, "comentarios": comentarios}
    tareas.add_task(_redactar_en_segundo_plano, id_escrito, e["version_actual"], paquete, usuario)
    return {"generando": True, "mensaje": "La IA está redactando el escrito. Puede tardar uno o dos minutos."}


# ---------------------------------------------------------------- edición, revisión, radicación
@router.put("/{id_escrito}/contenido")
def editar(id_escrito: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "actualizar"))):
    with transaccion(usuario) as conn:
        n = conn.execute("SELECT gestion_documental.fn_guardar_version_escrito(%s, %s, %s, 'EDICION', NULL, %s) AS n",
                         (id_escrito, datos.get("version_base"), datos.get("contenido") or "", datos.get("motivo"))).fetchone()["n"]
    return {"version": n, "mensaje": f"Guardada la versión {n}. Las aprobaciones anteriores ya no valen: la nueva versión pasa a revisión."}


@router.post("/{id_escrito}/revisar")
def revisar(id_escrito: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    decision = (datos.get("decision") or "").upper()
    with transaccion(usuario) as conn:
        estado = conn.execute("SELECT gestion_documental.fn_revisar_escrito(%s, %s, %s, %s) AS e",
                              (id_escrito, datos.get("numero_version"), decision, datos.get("comentario"))).fetchone()["e"]
    return {"estado": estado}


@router.post("/{id_escrito}/radicar")
def radicar(id_escrito: int, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "registrar"))):
    with transaccion(usuario) as conn:
        id_doc = conn.execute("SELECT gestion_documental.fn_radicar_escrito(%s) AS d", (id_escrito,)).fetchone()["d"]
        e = _escrito(conn, id_escrito)
        pdf = generar_pdf(e, e["contenido"], borrador=False)
        huella = hashlib.sha256(pdf).hexdigest()
        config.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        final = config.UPLOAD_DIR / f"{e['radicado']}_{huella[:12]}.pdf"
        conn.execute("UPDATE gestion_documental.documento SET nombre_archivo_adjunto = %s, hash_sha256 = %s WHERE id_documento = %s",
                     (f"{e['radicado']}.pdf", huella, id_doc))
        final.write_bytes(pdf)
    return {"radicado": e["radicado"], "id_documento": id_doc, "hash_sha256": huella,
            "mensaje": f"Escrito radicado con el número {e['radicado']}."}


@router.post("/{id_escrito}/descartar")
def descartar(id_escrito: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "actualizar"))):
    with transaccion(usuario) as conn:
        conn.execute("SELECT gestion_documental.fn_descartar_escrito(%s, %s)", (id_escrito, datos.get("motivo") or ""))
    return {"descartado": True}


# ---------------------------------------------------------------- PDF y Word
def _contenido_de(conn, e: dict, numero: int | None) -> tuple[str, int]:
    if numero is None or numero == e["version_actual"]:
        if not e["contenido"]:
            raise HTTPException(400, "El escrito aún no tiene texto.")
        return e["contenido"], e["version_actual"]
    v = conn.execute("SELECT contenido FROM gestion_documental.escrito_version WHERE id_escrito = %s AND numero = %s",
                     (e["id_escrito"], numero)).fetchone()
    if not v:
        raise HTTPException(404, "La versión no existe.")
    return v["contenido"], numero


def _es_titulo(linea: str) -> bool:
    letras = [c for c in linea if c.isalpha()]
    return 3 <= len(linea) <= 90 and letras and all(c.isupper() for c in letras)


@router.get("/{id_escrito}/pdf")
def pdf(id_escrito: int, version: int | None = None, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    with transaccion(usuario) as conn:
        e = _escrito(conn, id_escrito)
        if e["estado"] == "RADICADO" and version is None and e["hash_documento"]:
            ruta = config.UPLOAD_DIR / f"{e['radicado']}_{e['hash_documento'][:12]}.pdf"
            if ruta.is_file() and hashlib.sha256(ruta.read_bytes()).hexdigest() == e["hash_documento"]:
                return FileResponse(ruta, media_type="application/pdf", filename=f"{e['radicado']}.pdf")
            raise HTTPException(409, "ALERTA DE INTEGRIDAD: el PDF radicado no se encuentra o fue alterado.")
        texto, n = _contenido_de(conn, e, version)
    return Response(generar_pdf(e, texto, borrador=True, numero=n), media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="Proyecto_escrito_{id_escrito}_v{n}.pdf"'})


@router.get("/{id_escrito}/docx")
def docx(id_escrito: int, version: int | None = None, usuario: UsuarioActual = Depends(requiere("DOCUMENTAL", "consultar"))):
    import docx as _docx
    from docx.shared import Pt
    with transaccion(usuario) as conn:
        e = _escrito(conn, id_escrito)
        texto, n = _contenido_de(conn, e, version)
    d = _docx.Document()
    estilo = d.styles["Normal"]
    estilo.font.name, estilo.font.size = "Arial", Pt(11)
    for linea in texto.splitlines():
        p = d.add_paragraph()
        r = p.add_run(linea)
        if _es_titulo(linea.strip()):
            r.bold = True
    buf = io.BytesIO()
    d.save(buf)
    nombre = f"{e['radicado']}.docx" if e["radicado"] and version is None else f"Proyecto_escrito_{id_escrito}_v{n}.docx"
    return Response(buf.getvalue(), media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    headers={"Content-Disposition": f'attachment; filename="{nombre}"'})


def generar_pdf(e: dict, texto: str, borrador: bool, numero: int | None = None) -> bytes:
    from xml.sax.saxutils import escape
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import LETTER
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer

    base = getSampleStyleSheet()["Normal"]
    normal = ParagraphStyle("n", parent=base, fontName="Helvetica", fontSize=10.5, leading=15, alignment=4)
    titulo = ParagraphStyle("t", parent=normal, fontName="Helvetica-Bold", alignment=0, spaceBefore=6)
    cab = ParagraphStyle("c", parent=normal, fontSize=8.5, leading=11, alignment=2, textColor=colors.HexColor("#555555"))
    hist = [Paragraph(escape(f"{config.SINDICATO_NOMBRE} · {e['junta']}"), cab)]
    hist.append(Paragraph(escape(f"Radicado {e['radicado']}" if not borrador and e.get("radicado")
                                 else f"PROYECTO — versión {numero} — sujeto a revisión"), cab))
    hist.append(Spacer(1, 12))
    for linea in texto.splitlines():
        s = linea.strip()
        if not s:
            hist.append(Spacer(1, 6))
        elif _es_titulo(s):
            hist.append(Paragraph(escape(s), titulo))
        else:
            hist.append(Paragraph(escape(s), normal))
    buf = io.BytesIO()
    etiqueta = f"{e['radicado']}" if not borrador and e.get("radicado") else f"Proyecto v{numero} (no radicado)"

    def pie(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 7.5)
        canvas.setFillColor(colors.HexColor("#666666"))
        canvas.drawString(2.5 * cm, 1.3 * cm, f"{config.SINDICATO_NOMBRE} · {etiqueta}")
        canvas.drawRightString(LETTER[0] - 2.5 * cm, 1.3 * cm, f"Página {doc.page}")
        if borrador:
            canvas.setFont("Helvetica-Bold", 54)
            canvas.setFillColor(colors.Color(0.8, 0.2, 0.2, alpha=0.10))
            canvas.translate(LETTER[0] / 2, LETTER[1] / 2)
            canvas.rotate(40)
            canvas.drawCentredString(0, 0, "PROYECTO")
        canvas.restoreState()

    doc = SimpleDocTemplate(buf, pagesize=LETTER, leftMargin=2.5 * cm, rightMargin=2.5 * cm, topMargin=2 * cm, bottomMargin=2.2 * cm,
                            title=e["titulo"], author=config.SINDICATO_NOMBRE, subject=e["tipo_nombre"])
    doc.build(hist, onFirstPage=pie, onLaterPages=pie)
    return buf.getvalue()

