"""Portal del afiliado (autoservicio), invitaciones y verificación pública de certificados.

Regla de oro: todo lo del portal sale de funciones de la base de datos que solo devuelven los datos de
la persona ligada al usuario que pregunta (db/08). No hay identificadores en las rutas del portal:
manipular la dirección o la API no permite ver a otro afiliado."""
from __future__ import annotations

import hashlib
import io
import logging
import secrets
import string
import threading
import time
from collections import defaultdict, deque
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo

from fastapi import APIRouter, BackgroundTasks, Body, Depends, HTTPException, Request
from fastapi.responses import Response

from .config import config
from .crud import serializar
from .db import transaccion
from .notificaciones import fecha_larga, nombre_propio
from .seguridad import UsuarioActual, hash_contrasena, ip_cliente, requiere, usuario_actual, validar_politica_contrasena

router = APIRouter(tags=["autoservicio"])
log = logging.getLogger("sgsindical.autoservicio")

# ---------------------------------------------------------------- límite de consultas públicas por IP
_publico: dict[str, deque] = defaultdict(deque)
_lock = threading.Lock()


def _limitar(request: Request, maximo: int = 20, ventana: int = 60) -> str | None:
    ip = ip_cliente(request)
    ahora = time.monotonic()
    with _lock:
        cola = _publico[ip or "?"]
        while cola and ahora - cola[0] > ventana:
            cola.popleft()
        if len(cola) >= maximo:
            raise HTTPException(429, "Demasiadas consultas desde este equipo. Espere un minuto.")
        cola.append(ahora)
    return ip


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def _enlace(ruta: str) -> str:
    base = (config.APP_URL or "").rstrip("/")
    return f"{base}/#{ruta}" if base else f"#{ruta}"


def _enviar(para: str, nombre: str, asunto: str, parrafos: list[str], clave: str) -> bool:
    """Envía un correo inmediato (la invitación lleva un enlace secreto: no se guarda en el historial)."""
    if not (config.SMTP_HOST and config.CORREO_REMITENTE):
        return False
    try:
        from . import notificaciones as n
        correo = n.Correo("INVITACION", clave, para, nombre, asunto, parrafos)
        with n._smtp() as s:
            s.send_message(correo.mensaje())
        return True
    except Exception:  # noqa: BLE001
        log.exception("No se pudo enviar el correo de %s", clave)
        return False


def _ocultar_correo(c: str) -> str:
    usuario, _, dominio = c.partition("@")
    return (usuario[:2] + "***@" + dominio) if dominio else "***"


# ================================================================ invitaciones (las crea la junta)
@router.post("/api/autoservicio/invitaciones")
def invitar(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    token = secrets.token_urlsafe(32)
    with transaccion(usuario) as conn:
        f = conn.execute("SELECT * FROM seguridad.fn_crear_invitacion(%s, %s)", (datos.get("id_persona"), _hash(token))).fetchone()
    enlace = _enlace(f"/activar?t={token}")
    enviado = _enviar(f["correo"], nombre_propio(f["nombre"]), f"Su cuenta en el portal del afiliado de {config.SINDICATO_NOMBRE}",
                      ["Su junta lo invita a crear su cuenta en el portal del afiliado, donde podrá consultar su afiliación y sus "
                       "aportes, descargar certificados y ver quién ha consultado sus datos.",
                       f"Cree su contraseña con este enlace (es personal y sirve una sola vez durante 48 horas): {enlace}",
                       "Si usted no pidió esta cuenta, ignore este mensaje."], f"invitacion:{datos.get('id_persona')}")
    r = {"correo": _ocultar_correo(f["correo"]), "expira": f["expira"].isoformat(), "enviado": enviado}
    if not enviado:   # sin servidor de correo: el enlace se entrega en persona al afiliado
        r["enlace"] = enlace
        r["aviso"] = "No hay servidor de correo configurado: entregue este enlace personalmente al afiliado. Es de un solo uso."
    return r


# ================================================================ páginas públicas (sin iniciar sesión)
@router.get("/api/publico/invitacion")
def ver_invitacion(t: str, request: Request):
    ip = _limitar(request)
    with transaccion("publico", ip) as conn:
        f = conn.execute("SELECT * FROM seguridad.fn_consultar_invitacion(%s)", (_hash(t),)).fetchone()
    if not f:
        raise HTTPException(404, "El enlace no es válido, ya se usó o venció. Pida a su junta una invitación nueva.")
    return f


@router.post("/api/publico/activar")
def activar(request: Request, datos: dict[str, Any] = Body(...)):
    ip = _limitar(request, maximo=10)
    nombre = (datos.get("nombre_usuario") or "").strip()
    contrasena = datos.get("contrasena") or ""
    validar_politica_contrasena(contrasena, nombre)
    with transaccion("activacion_portal", ip) as conn:
        u = conn.execute("SELECT seguridad.fn_activar_cuenta(%s, %s, %s, %s, %s, %s) AS u",
                         (_hash(datos.get("token") or ""), nombre, hash_contrasena(contrasena), bool(datos.get("acepta_politica")),
                          bool(datos.get("acepta_comunicaciones")), bool(datos.get("acepta_imagen")))).fetchone()["u"]
    return {"nombre_usuario": u, "mensaje": "Cuenta creada. Ya puede ingresar con su usuario y contraseña."}


@router.get("/api/publico/certificados/{codigo}")
def verificar_certificado(codigo: str, request: Request):
    ip = _limitar(request)
    with transaccion("verificacion_publica", ip) as conn:
        r = conn.execute("SELECT gobernanza.fn_verificar_certificado(%s) AS r", (codigo[:20],)).fetchone()["r"]
    if not r:
        raise HTTPException(404, "No existe un certificado con ese código. Revise que lo haya escrito bien.")
    return serializar(r)


LEGAL = {"politica-datos": "POLITICA_DATOS", "aviso-privacidad": "AVISO_PRIVACIDAD", "reglamento-pqrsd": "REGLAMENTO_PQRSD"}


@router.get("/api/publico/legal/{clave}")
def texto_legal(clave: str, request: Request):
    """Política de datos, aviso de privacidad y reglamento de PQRSD vigentes, sin iniciar sesión."""
    if clave not in LEGAL:
        raise HTTPException(404, "Ese documento no existe.")
    ip = _limitar(request, maximo=60)
    with transaccion("publico", ip) as conn:
        f = conn.execute("SELECT * FROM gobernanza.fn_texto_publico(%s)", (LEGAL[clave],)).fetchone()
    if not f:
        raise HTTPException(404, "El sindicato todavía no ha publicado este documento.")
    return serializar(f)


# ================================================================ portal del afiliado ("solo lo mío")
@router.get("/api/autoservicio/perfil")
def perfil(usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        return serializar(conn.execute("SELECT seguridad.fn_mi_perfil() AS p").fetchone()["p"])


@router.put("/api/autoservicio/perfil")
def actualizar_perfil(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        conn.execute("SELECT seguridad.fn_actualizar_mi_telefono(%s)", (datos.get("telefono"),))
        return serializar(conn.execute("SELECT seguridad.fn_mi_perfil() AS p").fetchone()["p"])


@router.post("/api/autoservicio/correo")
def cambiar_correo(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    token = secrets.token_urlsafe(32)
    nuevo = (datos.get("correo") or "").strip().lower()
    with transaccion(usuario) as conn:
        conn.execute("SELECT seguridad.fn_solicitar_cambio_correo(%s, %s)", (nuevo, _hash(token)))
    enlace = _enlace(f"/confirmar-correo?t={token}")
    enviado = _enviar(nuevo, usuario.nombre_completo, "Confirme su nuevo correo en el portal del afiliado",
                      [f"Para confirmar que este será su correo en {config.SINDICATO_NOMBRE}, ingrese al portal y abra este enlace "
                       f"(sirve 48 horas): {enlace}"], f"correo:{usuario.id_usuario}")
    r = {"enviado": enviado, "mensaje": f"Le enviamos un enlace de confirmación a {_ocultar_correo(nuevo)}."}
    if not enviado:
        r["enlace"] = enlace
    return r


@router.post("/api/autoservicio/correo/confirmar")
def confirmar_correo(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        c = conn.execute("SELECT seguridad.fn_confirmar_cambio_correo(%s) AS c", (_hash(datos.get("token") or ""),)).fetchone()["c"]
    return {"correo": c}


@router.get("/api/autoservicio/aportes")
def mis_aportes(usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        return [serializar(f) for f in conn.execute("SELECT * FROM seguridad.fn_mis_aportes()").fetchall()]


@router.get("/api/autoservicio/solicitudes")
def mis_solicitudes(usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        return [serializar(f) for f in conn.execute("SELECT * FROM seguridad.fn_mis_solicitudes()").fetchall()]


@router.get("/api/autoservicio/privacidad")
def mi_privacidad(usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        return serializar(conn.execute("SELECT seguridad.fn_mi_privacidad() AS p").fetchone()["p"])


@router.post("/api/autoservicio/privacidad")
def cambiar_autorizacion(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        e = conn.execute("SELECT seguridad.fn_cambiar_mi_autorizacion(%s, %s) AS e",
                         (datos.get("finalidad"), bool(datos.get("otorgada")))).fetchone()["e"]
    return {"estado": e}


# ---------------------------------------------------------------- certificados
_ALFABETO = string.ascii_uppercase.replace("O", "").replace("I", "") + "23456789"


def _codigo() -> str:
    return "".join(secrets.choice(_ALFABETO) for _ in range(10))


def pdf_certificado(c: dict) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
    from reportlab.lib.pagesizes import LETTER
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
    from xml.sax.saxutils import escape as e

    est = getSampleStyleSheet()
    normal = ParagraphStyle("n", parent=est["Normal"], fontName="Helvetica", fontSize=11, leading=17, alignment=TA_JUSTIFY)
    titulo = ParagraphStyle("t", parent=normal, fontName="Helvetica-Bold", fontSize=14, leading=20, alignment=TA_CENTER)
    centro = ParagraphStyle("c", parent=normal, alignment=TA_CENTER)
    peq = ParagraphStyle("p", parent=normal, fontSize=8.5, leading=12, textColor=colors.HexColor("#444444"))
    fecha = datetime.fromisoformat(str(c["fecha"])).date() if isinstance(c.get("fecha"), str) else c["fecha"]
    afil = datetime.fromisoformat(str(c["fecha_afiliacion"])).date() if c.get("fecha_afiliacion") else None
    es_paz = c["tipo"] == "PAZ_Y_SALVO"
    cuerpo = (f"Que <b>{e(c['titular'])}</b>, identificado(a) con {e(c['documento'])}, es afiliado(a) activo(a) de "
              f"{e(config.SINDICATO_NOMBRE)}, adscrito(a) a {e(c.get('junta') or '—')}"
              + (f", desde el {fecha_larga(afil)}" if afil else "") +
              (f", y trabaja en {e(c['empresa'])} (NIT {e(c.get('nit') or '')})" if c.get("empresa") else "") + ".")
    if es_paz:
        cuerpo += (" Se encuentra a paz y salvo con el sindicato por concepto de cuota sindical, la cual se descuenta por nómina.")
    h = [Paragraph(e(config.SINDICATO_NOMBRE.upper()), titulo), Spacer(1, 16),
         Paragraph("PAZ Y SALVO" if es_paz else "CERTIFICADO DE AFILIACIÓN", titulo), Spacer(1, 18),
         Paragraph("EL SINDICATO CERTIFICA:", centro), Spacer(1, 12), Paragraph(cuerpo, normal)]
    if es_paz and c.get("nota"):
        h += [Spacer(1, 10), Paragraph(f"<b>Nota:</b> {e(c['nota'])}", normal)]
    h += [Spacer(1, 14), Paragraph(f"Se expide el {fecha_larga(fecha)}, a solicitud del interesado.", normal), Spacer(1, 40),
          Paragraph(f"Código de verificación: <b>{e(c['codigo'])}</b>", centro),
          Paragraph(f"Verifique su autenticidad en {e(_enlace('/verificar'))} con este código.", peq),
          Paragraph(f"Huella SHA-256: {e(c['hash_sha256'])}", peq),
          Spacer(1, 8),
          Paragraph("Documento generado por SGSINDICAL. La verificación en línea solo muestra si el certificado es válido; "
                    "no expone datos personales.", peq)]
    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=LETTER, leftMargin=2.5 * cm, rightMargin=2.5 * cm, topMargin=2.5 * cm, bottomMargin=2 * cm,
                      title="Paz y salvo" if es_paz else "Certificado de afiliación", author=config.SINDICATO_NOMBRE).build(h)
    return buf.getvalue()


def _respuesta_pdf(c: dict) -> Response:
    return Response(pdf_certificado(c), media_type="application/pdf", headers={
        "Content-Disposition": f'attachment; filename="{c["tipo"].lower()}_{c["codigo"]}.pdf"', "Cache-Control": "no-store",
        "X-Codigo-Verificacion": c["codigo"]})


@router.get("/api/autoservicio/certificados")
def mis_certificados(usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        return [serializar(f) for f in conn.execute("SELECT * FROM gobernanza.fn_mis_certificados()").fetchall()]


@router.post("/api/autoservicio/certificados")
def emitir_mio(datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        c = conn.execute("SELECT gobernanza.fn_emitir_certificado(%s, %s, NULL) AS c", (datos.get("tipo"), _codigo())).fetchone()["c"]
    return _respuesta_pdf(c)


@router.post("/api/autoservicio/personas/{id_persona}/certificados")
def emitir_para(id_persona: int, datos: dict[str, Any] = Body(...), usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    with transaccion(usuario) as conn:
        c = conn.execute("SELECT gobernanza.fn_emitir_certificado(%s, %s, %s) AS c", (datos.get("tipo"), _codigo(), id_persona)).fetchone()["c"]
    return _respuesta_pdf(c)


@router.get("/api/autoservicio/certificados/{codigo}/pdf")
def descargar_certificado(codigo: str, usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        c = conn.execute("SELECT gobernanza.fn_certificado_para_pdf(%s) AS c", (codigo,)).fetchone()["c"]
    if not c:
        raise HTTPException(404, "El certificado no existe.")
    return _respuesta_pdf(c)
