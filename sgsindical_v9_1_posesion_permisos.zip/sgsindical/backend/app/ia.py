"""Redacción de escritos jurídicos con Claude (API de Anthropic).

El texto de las fuentes y las instrucciones se envía a Anthropic para procesarlo. Los proyectos que
produce son BORRADORES sujetos a revisión del abogado y de la junta: el sistema no permite radicarlos
sin esas aprobaciones.
"""
from __future__ import annotations

import httpx

from .config import config

MARCA_NOTAS = "===NOTAS PARA LA REVISIÓN==="
URL_API = "https://api.anthropic.com/v1/messages"


class ErrorIA(Exception):
    pass


def instrucciones_sistema() -> str:
    return f"""Eres el asistente jurídico de {config.SINDICATO_NOMBRE}, una organización sindical colombiana de trabajadores \
del sector público. Redactas PROYECTOS de escritos jurídicos que después revisan y aprueban un abogado, el Presidente \
y el Secretario General de la junta directiva. Defiendes con rigor los derechos laborales y sindicales de los trabajadores.

REGLAS OBLIGATORIAS
1. Responde SOLO con el escrito, listo para usar: sin saludos, introducciones, explicaciones ni comentarios antes o \
después. La primera línea de tu respuesta es la primera línea del escrito.
2. Usa únicamente los hechos que aparecen en los documentos fuente y en las instrucciones. No inventes hechos, fechas, \
nombres, cifras, números de actos administrativos, radicados ni pruebas. Donde falte un dato escribe \
[COMPLETAR: qué dato falta].
3. Cita normas y jurisprudencia solo si estás seguro de su existencia y vigencia en Colombia. Si dudas, escribe \
[VERIFICAR] junto a la cita. Nunca inventes sentencias ni números de artículos.
4. Español jurídico colombiano, claro, respetuoso y firme. Texto plano, sin Markdown (no uses #, *, ** ni tablas). \
Los títulos de sección van en MAYÚSCULAS en una línea propia; los hechos y las peticiones van numerados.
5. Protege los datos personales: no incluyas datos de salud u otros datos sensibles salvo que sean indispensables y \
estén en las fuentes. En comunicados públicos, nunca.
6. Usa lenguaje de presunción ("presuntamente") cuando no exista decisión de autoridad competente. Evita expresiones \
que puedan constituir injuria o calumnia.
7. Al terminar el escrito, en una línea aparte escribe exactamente {MARCA_NOTAS} y debajo, en líneas cortas que \
empiecen por "- ", lo que el abogado y los directivos deben verificar o completar: datos faltantes, citas por \
verificar, riesgos y plazos. Esa sección NO forma parte del escrito."""


def construir_mensaje(d: dict) -> str:
    partes = [f"TIPO DE ESCRITO: {d['tipo_nombre']}", "", "ORIENTACIÓN PARA ESTE TIPO DE ESCRITO:", d["orientacion"], ""]
    partes += ["DATOS DE QUIEN PRESENTA EL ESCRITO:",
               f"- Organización: {config.SINDICATO_NOMBRE}",
               f"- Junta directiva: {d['junta']} ({d['tipo_junta'].lower()}){', ' + d['municipio'] if d.get('municipio') else ''}",
               f"- Firman: {d['firmantes'] or '[COMPLETAR: nombres y cargos de quienes firman]'}", ""]
    if d.get("destinatario_persona") or d.get("destinatario_institucion"):
        partes += ["DESTINATARIO:", f"- {d.get('destinatario_persona') or '[COMPLETAR: nombre y cargo]'}"
                   f"{' — ' + d['destinatario_institucion'] if d.get('destinatario_institucion') else ''}", ""]
    partes += [f"ASUNTO: {d['titulo']}", ""]
    if d.get("instrucciones"):
        partes += ["INSTRUCCIONES DE LA JUNTA:", d["instrucciones"], ""]
    partes += [f"DOCUMENTOS FUENTE ({len(d['fuentes'])}):"]
    for i, f in enumerate(d["fuentes"], 1):
        partes += [f"--- Fuente {i}: {f['nombre']} ({f['clase'].lower()}) ---", f["texto"], f"--- Fin de la fuente {i} ---"]
    if d.get("version_anterior"):
        partes += ["", "VERSIÓN ANTERIOR DEL ESCRITO (corrígela según los comentarios y las nuevas instrucciones; conserva lo que esté bien):",
                   d["version_anterior"]]
    if d.get("comentarios"):
        partes += ["", "COMENTARIOS DE LOS REVISORES A TENER EN CUENTA:"] + [f"- {c}" for c in d["comentarios"]]
    if d.get("nuevas_instrucciones"):
        partes += ["", "NUEVAS INSTRUCCIONES PARA ESTA VERSIÓN:", d["nuevas_instrucciones"]]
    partes += ["", "Redacta ahora el escrito completo siguiendo las reglas."]
    return "\n".join(partes)


def separar(respuesta: str) -> tuple[str, str | None]:
    texto = respuesta.strip()
    if MARCA_NOTAS in texto:
        cuerpo, notas = texto.split(MARCA_NOTAS, 1)
        return cuerpo.strip(), notas.strip() or None
    return texto, None


def _simulado(d: dict) -> str:
    """Redacción de prueba sin IA real (IA_PROVEEDOR=simulado)."""
    hechos = []
    for f in d["fuentes"]:
        for linea in f["texto"].splitlines():
            if linea.strip():
                hechos.append(linea.strip()[:300])
            if len(hechos) >= 5:
                break
    destino = d.get("destinatario_persona") or "[COMPLETAR: destinatario]"
    cuerpo = [f"{d.get('municipio') or '[COMPLETAR: ciudad]'}, [COMPLETAR: fecha]", "", destino,
              d.get("destinatario_institucion") or "[COMPLETAR: entidad]", "", f"REFERENCIA: {d['tipo_nombre']} — {d['titulo']}", "",
              "HECHOS"] + [f"{i}. {h}" for i, h in enumerate(hechos, 1)] + ["", "PETICIONES",
              "1. [COMPLETAR: petición concreta]", "", "FUNDAMENTOS DE DERECHO", "Artículo 23 de la Constitución Política.", "",
              "NOTIFICACIONES", "[COMPLETAR: dirección y correo]", "", d["firmantes"] or "[COMPLETAR: firmas]"]
    if d.get("nuevas_instrucciones"):
        cuerpo.insert(-2, f"[Ajuste solicitado: {d['nuevas_instrucciones']}]")
    return "\n".join(cuerpo) + f"\n{MARCA_NOTAS}\n- Verificar los hechos con las fuentes.\n- Completar la fecha y el destinatario."


def _llamar(sistema: str, mensaje: str) -> tuple[str, str]:
    """Llama a la API de Mensajes de Anthropic. Devuelve (texto, modelo)."""
    if not config.ANTHROPIC_API_KEY:
        raise ErrorIA("Falta ANTHROPIC_API_KEY en el archivo .env del servidor (clave de la API de Anthropic).")
    try:
        r = httpx.post(URL_API, timeout=config.IA_TIMEOUT_SEGUNDOS, headers={
            "x-api-key": config.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"},
            json={"model": config.IA_MODELO, "max_tokens": config.IA_MAX_TOKENS, "system": sistema,
                  "messages": [{"role": "user", "content": mensaje}]})
    except httpx.TimeoutException:
        raise ErrorIA("La IA tardó demasiado en responder. Intente de nuevo (o reduzca las fuentes).")
    except httpx.HTTPError as e:
        raise ErrorIA(f"No hubo conexión con la API de Anthropic: {e}")
    if r.status_code != 200:
        try:
            err = r.json().get("error", {})
            detalle = f"{err.get('type', '')}: {err.get('message', '')}"
        except ValueError:
            detalle = r.text[:300]
        raise ErrorIA(f"La API de Anthropic respondió {r.status_code} ({detalle}).")
    datos = r.json()
    texto = "".join(b.get("text", "") for b in datos.get("content", []) if b.get("type") == "text")
    if not texto.strip():
        raise ErrorIA("La IA no devolvió texto.")
    if datos.get("stop_reason") == "max_tokens":
        texto += f"\n{MARCA_NOTAS}\n- ATENCIÓN: el texto quedó incompleto por su longitud (aumente IA_MAX_TOKENS)." if MARCA_NOTAS not in texto \
            else "\n- ATENCIÓN: el texto quedó incompleto por su longitud (aumente IA_MAX_TOKENS)."
    return texto, datos.get("model", config.IA_MODELO)


def redactar(d: dict) -> tuple[str, str | None, str]:
    """Escrito jurídico. Devuelve (escrito, notas_para_revision, modelo)."""
    mensaje = construir_mensaje(d)
    if config.IA_PROVEEDOR == "simulado":
        cuerpo, notas = separar(_simulado(d))
        return cuerpo, notas, "simulado"
    texto, modelo = _llamar(instrucciones_sistema(), mensaje)
    cuerpo, notas = separar(texto)
    return cuerpo, notas, modelo


# ============================================================ contenidos para redes
FORMATOS = {
    "VIDEO_CORTO": "Guion de video corto vertical (TikTok, Reels o Shorts) de 45 a 60 segundos: GANCHO (primeros 3 segundos), "
                   "escenas numeradas con lo que se dice y lo que se ve en pantalla (texto sobreimpreso), CIERRE con llamado a la acción. "
                   "Al final, el texto de la publicación y de 3 a 6 etiquetas (#).",
    "CARRUSEL": "Carrusel de 6 a 8 diapositivas para Instagram o Facebook. Para cada una: 'Diapositiva N', un título corto (máximo 8 "
                "palabras) y un texto breve (máximo 30 palabras). La primera engancha con una pregunta; la última invita a actuar. "
                "Al final, el texto de la publicación y de 3 a 6 etiquetas (#).",
    "HILO": "Hilo para X de 5 a 8 publicaciones numeradas (1/8, 2/8…), cada una de máximo 270 caracteres. La primera engancha; la "
            "última invita a seguir la cuenta o a contactar al sindicato.",
    "PUBLICACION": "Publicación para Facebook o Instagram: un titular, de 3 a 5 párrafos cortos, un llamado a la acción y de 3 a 6 "
                   "etiquetas (#). Sugiera en una línea la imagen que la acompaña.",
    "WHATSAPP": "Mensaje para grupos de WhatsApp de máximo 120 palabras, cercano, con viñetas sencillas y un llamado a la acción. "
                "Puede usar negritas con *asteriscos* (formato de WhatsApp) y 1 o 2 emojis.",
    "BOLETIN": "Boletín por correo: asunto, saludo, de 3 a 5 secciones cortas con subtítulo, cierre y firma de la junta.",
    "INFOGRAFIA": "Texto para una infografía: título, de 4 a 6 bloques (título del bloque + máximo 25 palabras), un dato destacado "
                  "y la fuente normativa. Sugiera el orden visual.",
    "PREGUNTAS": "Preguntas y respuestas: de 5 a 7 preguntas que haría un trabajador del sector público, con respuestas de máximo "
                 "60 palabras, en lenguaje cotidiano.",
}


def sistema_contenidos() -> str:
    return f"""Eres el equipo de comunicaciones de {config.SINDICATO_NOMBRE}, un sindicato colombiano de trabajadores del sector \
público. Creas contenidos para redes sociales que EDUCAN EN DERECHOS LABORALES y fortalecen la organización sindical. \
Antes de publicarse, los revisan un abogado (exactitud jurídica) y la secretaría de comunicaciones.

REGLAS OBLIGATORIAS
1. Responde SOLO con la pieza, lista para usar, sin introducciones ni comentarios. La primera línea es la primera línea de la pieza.
2. Lenguaje sencillo, cercano, cálido y esperanzador, para cualquier trabajador (sin jerga jurídica; si usas un término técnico, \
explícalo). Tutea o usa "usted" según la política de comunicaciones; si no está definida, usa "tú".
3. Exactitud: cita normas solo si estás seguro de que existen y están vigentes en Colombia, con su número (por ejemplo, Ley 1010 de \
2006). Si dudas, escribe [VERIFICAR] junto a la cita. Nunca inventes cifras, fechas, sentencias ni casos reales.
4. No incluyas datos personales de trabajadores ni acusaciones contra personas identificables. Lenguaje de presunción cuando corresponda.
5. Invita a la acción: consultar al sindicato, afiliarse, compartir o asistir, según el objetivo.
6. Sigue la política de comunicaciones de la junta si se entrega (tono, mensajes clave, reglas).
7. Al terminar, en una línea aparte escribe exactamente {MARCA_NOTAS} y debajo, en líneas que empiecen por "- ", lo que el abogado \
debe verificar (normas, cifras) y sugerencias de imagen, horario o red. Esa sección NO forma parte de la pieza."""


def mensaje_contenido(d: dict) -> str:
    partes = [f"FORMATO: {d['formato']}", FORMATOS.get(d["formato"], ""), "",
              f"TEMA: {d['titulo']}", f"EJE TEMÁTICO: {d.get('eje') or 'No definido'}",
              f"PÚBLICO: {d.get('publico') or 'Trabajadores del sector público afiliados y no afiliados'}",
              f"REDES: {d.get('redes') or 'Según el formato'}",
              f"JUNTA QUE PUBLICA: {d['junta']}", ""]
    if d.get("fecha_clave"):
        partes += [f"FECHA CLAVE: {d['fecha_clave']}", ""]
    if d.get("politica"):
        partes += ["POLÍTICA DE COMUNICACIONES DE LA JUNTA:", d["politica"], ""]
    if d.get("instrucciones"):
        partes += ["INSTRUCCIONES:", d["instrucciones"], ""]
    if d.get("material"):
        partes += ["MATERIAL DE BASE (normas, noticias o documentos que debes usar):", d["material"], ""]
    if d.get("version_anterior"):
        partes += ["VERSIÓN ANTERIOR (corrígela según los comentarios y las nuevas instrucciones):", d["version_anterior"], ""]
    if d.get("comentarios"):
        partes += ["COMENTARIOS DE LOS REVISORES:"] + [f"- {c}" for c in d["comentarios"]] + [""]
    if d.get("nuevas_instrucciones"):
        partes += ["NUEVAS INSTRUCCIONES:", d["nuevas_instrucciones"], ""]
    partes += ["Crea ahora la pieza siguiendo las reglas."]
    return "\n".join(partes)


def redactar_contenido(d: dict) -> tuple[str, str | None, str]:
    if config.IA_PROVEEDOR == "simulado":
        cuerpo = (f"¿Sabías esto sobre {d['titulo'].lower()}?\n\n[Pieza simulada en formato {d['formato']}]\n"
                  f"{(d.get('material') or 'Consulta a tu sindicato.')[:200]}\n"
                  + (f"[Ajuste: {d['nuevas_instrucciones']}]\n" if d.get("nuevas_instrucciones") else "")
                  + "👉 Escríbenos y te orientamos.\n#DerechosLaborales #Sindicato")
        return cuerpo, "- Verificar la norma citada.\n- Imagen sugerida: trabajadores en su lugar de trabajo.", "simulado"
    texto, modelo = _llamar(sistema_contenidos(), mensaje_contenido(d))
    cuerpo, notas = separar(texto)
    return cuerpo, notas, modelo


def redactar_politica(d: dict) -> tuple[str, str | None, str]:
    sistema = sistema_contenidos().replace("Creas contenidos para redes sociales", "Redactas políticas de comunicaciones y creas contenidos para redes sociales")
    mensaje = "\n".join([
        f"Redacta la POLÍTICA DE COMUNICACIONES Y CONTENIDOS EN REDES de {d['junta']} ({config.SINDICATO_NOMBRE}).",
        "Estructura (títulos en MAYÚSCULAS, texto plano sin Markdown): 1. PROPÓSITO; 2. OBJETIVOS (medibles); 3. PÚBLICOS; "
        "4. MENSAJES CLAVE; 5. EJES TEMÁTICOS (educación en derechos laborales del sector público); 6. TONO Y ESTILO; "
        "7. REDES Y FORMATOS (qué publicar en cada red); 8. FRECUENCIA Y CALENDARIO (incluidas fechas clave del mundo del trabajo); "
        "9. REVISIÓN Y APROBACIÓN (revisión jurídica del abogado o Secretario Jurídico y de la Secretaría de Comunicaciones antes de "
        "publicar); 10. MANEJO DE CRISIS Y COMENTARIOS NEGATIVOS; 11. PROTECCIÓN DE DATOS Y USO RESPONSABLE DE LA IA (revisión "
        "humana siempre, transparencia cuando una imagen o video se hizo con IA); 12. SEGURIDAD DE LAS CUENTAS; 13. MEDICIÓN.",
        f"Cuentas activas de la junta: {d.get('cuentas') or 'por definir'}.",
        f"Ejes temáticos disponibles: {d.get('ejes')}.",
        f"Publicaciones por semana deseadas: {d.get('frecuencia')}.",
        *([f"Lo que la junta ya definió:\n{d['definido']}"] if d.get("definido") else []),
        *([f"Instrucciones:\n{d['instrucciones']}"] if d.get("instrucciones") else []),
        "Responde solo con la política, sin introducciones. Al final, la sección de notas con la marca indicada."])
    if config.IA_PROVEEDOR == "simulado":
        return (f"POLÍTICA DE COMUNICACIONES Y CONTENIDOS EN REDES — {d['junta']}\n\n1. PROPÓSITO\nEducar en derechos laborales.\n\n"
                f"8. FRECUENCIA Y CALENDARIO\n{d.get('frecuencia')} publicaciones por semana.", "- Validar con la junta.", "simulado")
    texto, modelo = _llamar(sistema, mensaje)
    cuerpo, notas = separar(texto)
    return cuerpo, notas, modelo
