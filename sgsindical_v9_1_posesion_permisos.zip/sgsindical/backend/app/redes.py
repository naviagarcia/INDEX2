"""Cuentas del sindicato en redes sociales: claves cifradas con AES-256-GCM.

· La llave está en el .env del servidor (SECRETOS_LLAVE), nunca en la base de datos: un backup o una
  consulta directa a la base solo ven texto cifrado.
· Cada texto cifrado va ligado a su cuenta (dato asociado): no se puede copiar a otra cuenta.
· Quién puede ver o cambiar una clave lo decide la base (directivos vigentes de la junta dueña y
  directivos nacionales con acceso nacional), y cada consulta queda registrada con usuario, fecha e IP.
"""
from __future__ import annotations

import base64
import binascii
import os
from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException
from fastapi.responses import JSONResponse

from .config import config
from .crud import serializar
from .db import transaccion
from .seguridad import UsuarioActual, exigir_paso_adicional, requiere

router = APIRouter(prefix="/api", tags=["redes sociales"])

MAX_CLAVE = 256


# ---------------------------------------------------------------- cifrado
def _llave(texto: str, nombre: str) -> bytes:
    try:
        llave = base64.b64decode(texto, validate=True)
    except (binascii.Error, ValueError):
        raise HTTPException(503, f"{nombre} no es base64 válido. Genérela con: python -m app.cli generar-llave")
    if len(llave) != 32:
        raise HTTPException(503, f"{nombre} debe tener 32 bytes (AES-256). Genérela con: python -m app.cli generar-llave")
    return llave


def _llaves() -> dict[int, bytes]:
    if not config.SECRETOS_LLAVE:
        raise HTTPException(503, "Las claves de redes sociales están deshabilitadas: falta SECRETOS_LLAVE en el archivo .env "
                                 "del servidor (genérela con: python -m app.cli generar-llave).")
    llaves = {config.SECRETOS_LLAVE_VERSION: _llave(config.SECRETOS_LLAVE, "SECRETOS_LLAVE")}
    if config.SECRETOS_LLAVE_ANTERIOR:
        llaves[config.SECRETOS_LLAVE_VERSION - 1] = _llave(config.SECRETOS_LLAVE_ANTERIOR, "SECRETOS_LLAVE_ANTERIOR")
    return llaves


def _aad(id_cuenta: int) -> bytes:
    return f"sgsindical:cuenta_red:{id_cuenta}".encode()


def cifrar(texto: str, id_cuenta: int) -> tuple[bytes, int]:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    version = config.SECRETOS_LLAVE_VERSION
    nonce = os.urandom(12)
    return nonce + AESGCM(_llaves()[version]).encrypt(nonce, texto.encode("utf-8"), _aad(id_cuenta)), version


def descifrar(blob: bytes, id_cuenta: int, version: int) -> str:
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    llave = _llaves().get(version)
    if llave is None:
        raise HTTPException(503, f"La clave fue cifrada con la llave versión {version}, que no está configurada en el servidor.")
    blob = bytes(blob)
    try:
        return AESGCM(llave).decrypt(blob[:12], blob[12:], _aad(id_cuenta)).decode("utf-8")
    except InvalidTag:
        raise HTTPException(409, "ALERTA DE INTEGRIDAD: la clave cifrada no corresponde a la llave del servidor o fue alterada.")


def generar_llave() -> str:
    return base64.b64encode(os.urandom(32)).decode()


# ---------------------------------------------------------------- endpoints
def _sin_cache(contenido: dict) -> JSONResponse:
    return JSONResponse(contenido, headers={"Cache-Control": "no-store, max-age=0", "Pragma": "no-cache"})


@router.get("/redes/{id_cuenta}/permiso")
def permiso(id_cuenta: int, usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    with transaccion(usuario) as conn:
        c = conn.execute("SELECT fecha_cambio_clave FROM gobernanza.cuenta_red_social WHERE id_cuenta_red = %s",
                         (id_cuenta,)).fetchone()
        if not c:
            raise HTTPException(404, "La cuenta no existe o está fuera de su ámbito territorial.")
        puede = conn.execute("SELECT gobernanza.fn_puede_ver_clave_red(%s) AS ok", (id_cuenta,)).fetchone()["ok"]
    return {"puede_ver_clave": puede, "tiene_clave": c["fecha_cambio_clave"] is not None,
            "cifrado_configurado": bool(config.SECRETOS_LLAVE), "segundos_visible": config.SEGUNDOS_CLAVE_VISIBLE}


@router.post("/redes/{id_cuenta}/clave")
def cambiar_clave(id_cuenta: int, datos: dict[str, Any] = Body(...),
                  usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    clave = datos.get("clave") or ""
    if not clave.strip():
        raise HTTPException(400, "Escriba la clave.")
    if len(clave) > MAX_CLAVE:
        raise HTTPException(400, f"La clave no puede superar {MAX_CLAVE} caracteres.")
    if "confirmacion" in datos and datos["confirmacion"] != clave:
        raise HTTPException(400, "La confirmación no coincide con la clave.")
    blob, version = cifrar(clave, id_cuenta)
    with transaccion(usuario) as conn:
        conn.execute("SELECT gobernanza.fn_guardar_clave_red(%s, %s, %s, %s)",
                     (id_cuenta, blob, datos.get("motivo") or "", version))
    return {"guardada": True, "mensaje": "Clave guardada cifrada. La anterior queda en el historial."}


@router.post("/redes/{id_cuenta}/ver")
def ver_clave(id_cuenta: int, datos: dict[str, Any] = Body(default={}),
              usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    exigir_paso_adicional(usuario)   # acción crítica: doble verificación (MFA)
    with transaccion(usuario) as conn:
        k = conn.execute("SELECT * FROM gobernanza.fn_leer_clave_red(%s, %s, %s)",
                         (id_cuenta, datos.get("id_clave"), datos.get("motivo"))).fetchone()
        # Se descifra DENTRO de la transacción: si falla, tampoco queda registrada la consulta
        clave = descifrar(k["clave_cifrada"], id_cuenta, k["version_llave"])
    return _sin_cache({"clave": clave, "vigente": k["vigente"], "fecha": k["fecha"].isoformat(),
                       "segundos_visible": config.SEGUNDOS_CLAVE_VISIBLE})


@router.get("/redes/{id_cuenta}/claves")
def historial(id_cuenta: int, usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    with transaccion(usuario) as conn:
        filas = conn.execute("SELECT * FROM gobernanza.fn_historial_claves_red(%s)", (id_cuenta,)).fetchall()
    return [serializar(f) for f in filas]


@router.post("/admin/redes/rotar-llave")
def rotar_llave(usuario: UsuarioActual = Depends(requiere("ADMINISTRACION", "actualizar"))):
    """Re-cifra todas las claves (vigentes e historial) y los secretos del MFA con la llave actual."""
    exigir_paso_adicional(usuario)
    actual = config.SECRETOS_LLAVE_VERSION
    with transaccion(usuario) as conn:
        filas = conn.execute("SELECT * FROM gobernanza.fn_claves_para_rotar()").fetchall()
        n = 0
        for f in filas:
            if f["version_llave"] == actual:
                continue
            texto = descifrar(f["clave_cifrada"], f["id_cuenta_red"], f["version_llave"])
            blob, _ = cifrar(texto, f["id_cuenta_red"])
            conn.execute("SELECT gobernanza.fn_reemplazar_cifrado(%s, %s, %s)", (f["id_clave"], blob, actual))
            n += 1
        # Secretos del autenticador (MFA)
        from .mfa import cifrar_secreto, descifrar_secreto
        m = 0
        for f in conn.execute("SELECT * FROM seguridad.fn_mfa_secretos_para_rotar()").fetchall():
            if f["version_llave"] == actual:
                continue
            blob, _ = cifrar_secreto(descifrar_secreto(f["secreto_cifrado"], f["id_usuario"], f["version_llave"]), f["id_usuario"])
            conn.execute("SELECT seguridad.fn_mfa_reemplazar_cifrado(%s, %s, %s)", (f["id_usuario"], blob, actual))
            m += 1
    return {"recifradas": n, "mfa_recifrados": m, "total": len(filas), "version_llave": actual,
            "mensaje": f"{n} clave(s) re-cifradas con la llave versión {actual}. Ya puede retirar SECRETOS_LLAVE_ANTERIOR."}


@router.get("/redes/{id_cuenta}/consultas")
def consultas(id_cuenta: int, usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "consultar"))):
    """Quién vio o cambió la clave (últimos 100 registros)."""
    with transaccion(usuario) as conn:
        filas = conn.execute("""
            SELECT q.fecha, q.accion, q.es_clave_vigente, q.nombre_usuario, q.ip, q.motivo,
                   p.primer_nombre || ' ' || p.primer_apellido AS persona
              FROM gobernanza.cuenta_red_consulta q LEFT JOIN gobernanza.persona p ON p.id_persona = q.id_persona
             WHERE q.id_cuenta_red = %s ORDER BY q.fecha DESC, q.id_consulta DESC LIMIT 100""", (id_cuenta,)).fetchall()
    return [serializar(f) for f in filas]
