"""Seguridad: contraseñas, política de claves, tokens de sesión y control de permisos."""
from __future__ import annotations

import uuid

import base64
import hashlib
import hmac
import ipaddress
import re
import secrets
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

import jwt
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from .config import config
from .db import transaccion

MODULOS = ("GOBERNANZA", "DOCUMENTAL", "FINANZAS", "AUDITORIA", "ADMINISTRACION")
ACCIONES = ("consultar", "registrar", "actualizar", "eliminar", "ver_vistas")

# ---------------------------------------------------------------- contraseñas
def hash_contrasena(contrasena: str) -> str:
    sal = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", contrasena.encode(), sal, config.PBKDF2_ITERACIONES)
    return "pbkdf2_sha256${}${}${}".format(
        config.PBKDF2_ITERACIONES, base64.b64encode(sal).decode(), base64.b64encode(dk).decode()
    )


def verificar_contrasena(contrasena: str, almacenado: str) -> bool:
    try:
        algoritmo, iteraciones, sal, dk = almacenado.split("$")
        if algoritmo != "pbkdf2_sha256":
            return False
        calculado = hashlib.pbkdf2_hmac("sha256", contrasena.encode(), base64.b64decode(sal), int(iteraciones))
        return hmac.compare_digest(calculado, base64.b64decode(dk))
    except Exception:
        return False


def validar_politica_contrasena(contrasena: str, nombre_usuario: str = "") -> None:
    errores = []
    if len(contrasena) < config.CONTRASENA_MIN:
        errores.append(f"mínimo {config.CONTRASENA_MIN} caracteres")
    if not re.search(r"[A-ZÁÉÍÓÚÑ]", contrasena):
        errores.append("una mayúscula")
    if not re.search(r"[a-záéíóúñ]", contrasena):
        errores.append("una minúscula")
    if not re.search(r"\d", contrasena):
        errores.append("un número")
    if not re.search(r"[^\w\s]", contrasena):
        errores.append("un símbolo")
    if nombre_usuario and nombre_usuario.lower() in contrasena.lower():
        errores.append("no contener el nombre de usuario")
    if errores:
        raise HTTPException(400, "La contraseña debe tener: " + ", ".join(errores) + ".")


# ---------------------------------------------------------------- utilidades
def ip_cliente(request: Request) -> str | None:
    host = request.client.host if request.client else None
    try:
        return str(ipaddress.ip_address(host)) if host else None
    except ValueError:
        return None


def registrar_acceso(nombre_usuario: str, evento: str, ip: str | None, detalle: str | None = None) -> None:
    with transaccion(nombre_usuario, ip) as conn:
        conn.execute(
            "INSERT INTO auditoria.registro_acceso (nombre_usuario, evento, ip_origen, detalle) VALUES (%s, %s, %s, %s)",
            (nombre_usuario[:50], evento, ip, detalle),
        )


def huella_sesion(token_sesion: str) -> str:
    """Huella con la que se guarda la sesión en la base (igual a seguridad.fn_huella_sesion): el token nunca se guarda."""
    return str(uuid.UUID(hashlib.sha256(token_sesion.encode()).hexdigest()[:32]))


def derivar_hash(contrasena: str, sal: str) -> str:
    """Calcula el hash con la sal ('pbkdf2_sha256$iteraciones$sal') que entrega la base; la base lo compara."""
    try:
        algoritmo, iteraciones, sal_b64 = sal.split("$")[:3]
        dk = hashlib.pbkdf2_hmac("sha256", contrasena.encode(), base64.b64decode(sal_b64), int(iteraciones))
        return f"{algoritmo}${iteraciones}${sal_b64}${base64.b64encode(dk).decode()}"
    except Exception:
        return "invalido"


def crear_token(id_usuario: int, id_sesion: str, expira: datetime) -> str:
    return jwt.encode(
        {"sub": str(id_usuario), "sid": id_sesion, "exp": expira, "iat": datetime.now(timezone.utc)},
        config.JWT_SECRET,
        algorithm=config.JWT_ALGORITMO,
    )


# ---------------------------------------------------------------- usuario actual
@dataclass
class UsuarioActual:
    id_usuario: int
    nombre_usuario: str
    nombre_completo: str
    codigo_rol: str
    id_sesion: str                   # huella de la sesión (como está en la base)
    ip: str | None
    debe_cambiar_contrasena: bool
    permisos: dict[str, dict[str, bool]] = field(default_factory=dict)
    mfa_verificada: bool = True      # la sesión pasó el segundo factor (o no lo necesita)
    mfa_activo: bool = False         # el usuario tiene el MFA activado
    mfa_reciente: bool = False       # verificó un código en los últimos 5 minutos (acciones críticas)
    sid: str = ""                    # token de la sesión: la base identifica al usuario con él (app.sesion)
    contexto_pendiente: bool = False  # tiene varios roles y todavía no eligió con cuál trabajar

    def puede(self, modulo: str, accion: str) -> bool:
        return bool(self.permisos.get(modulo, {}).get(accion))


_bearer = HTTPBearer(auto_error=False)


def _no_autorizado(msg: str = "Sesión no válida o vencida. Inicie sesión de nuevo.") -> HTTPException:
    return HTTPException(status.HTTP_401_UNAUTHORIZED, msg, headers={"WWW-Authenticate": "Bearer"})


def cargar_permisos(conn, codigo_rol: str) -> dict[str, dict[str, bool]]:
    filas = conn.execute(
        """SELECT modulo, puede_consultar, puede_registrar, puede_actualizar, puede_eliminar, puede_ver_vistas
             FROM seguridad.permiso_rol WHERE codigo_rol = %s""",
        (codigo_rol,),
    ).fetchall()
    return {
        f["modulo"]: {
            "consultar": f["puede_consultar"],
            "registrar": f["puede_registrar"],
            "actualizar": f["puede_actualizar"],
            "eliminar": f["puede_eliminar"],
            "ver_vistas": f["puede_ver_vistas"],
        }
        for f in filas
    }


def _usuario_desde_token(request: Request, cred: HTTPAuthorizationCredentials | None) -> UsuarioActual:
    if cred is None or cred.scheme.lower() != "bearer":
        raise _no_autorizado()
    try:
        datos = jwt.decode(cred.credentials, config.JWT_SECRET, algorithms=[config.JWT_ALGORITMO])
    except jwt.PyJWTError:
        raise _no_autorizado()

    ip = ip_cliente(request)
    ahora = datetime.now(timezone.utc)
    sid = str(datos.get("sid") or "")
    with transaccion(None, ip, sesion=sid) as conn:
        # Si el contexto activo venció (p. ej. terminó una suplencia), la base vuelve al principal
        conn.execute("SELECT seguridad.fn_revisar_contexto()")
        fila = conn.execute(
            """SELECT u.id_usuario, u.nombre_usuario, u.nombre_completo, u.codigo_rol, u.activo,
                      u.debe_cambiar_contrasena, s.revocada, s.fecha_expiracion, s.ultima_actividad,
                      s.fecha_emision, s.mfa_verificada, s.mfa_reciente_en, u.mfa_activo, s.contexto_elegido
                 FROM seguridad.sesion s JOIN seguridad.usuario u ON u.id_usuario = s.id_usuario
                WHERE s.id_sesion = %s AND u.id_usuario = %s""",
            (huella_sesion(sid), int(datos.get("sub", 0))),
        ).fetchone()
        if not fila or fila["revocada"] or not fila["activo"] or fila["fecha_expiracion"] < ahora:
            raise _no_autorizado()
        inactiva = fila["ultima_actividad"] < ahora - timedelta(minutes=config.INACTIVIDAD_MINUTOS)
        # Sin el segundo factor la sesión solo vive 5 minutos (tiempo para escribir el código)
        if not fila["mfa_verificada"] and fila["fecha_emision"] < ahora - timedelta(minutes=5):
            inactiva = True
        if inactiva:
            # Se confirma la revocación antes de responder (la excepción se lanza fuera de la transacción)
            conn.execute("SELECT seguridad.fn_sesion_cerrar_actual()")
        else:
            conn.execute("SELECT seguridad.fn_sesion_actividad()")
            permisos = cargar_permisos(conn, fila["codigo_rol"])
    if inactiva:
        raise _no_autorizado("La sesión se cerró por inactividad.")

    return UsuarioActual(
        id_usuario=fila["id_usuario"],
        nombre_usuario=fila["nombre_usuario"],
        nombre_completo=fila["nombre_completo"],
        codigo_rol=fila["codigo_rol"],
        id_sesion=huella_sesion(sid),
        sid=sid,
        contexto_pendiente=not fila["contexto_elegido"],
        ip=ip,
        debe_cambiar_contrasena=fila["debe_cambiar_contrasena"],
        permisos=permisos,
        mfa_verificada=fila["mfa_verificada"],
        mfa_activo=fila["mfa_activo"],
        mfa_reciente=bool(fila["mfa_reciente_en"] and fila["mfa_reciente_en"] > ahora - timedelta(minutes=5)),
    )


def usuario_sesion(request: Request, cred: HTTPAuthorizationCredentials | None = Depends(_bearer)) -> UsuarioActual:
    """Usuario autenticado, aunque deba cambiar su contraseña (para /me, /logout, /cambiar-contrasena)."""
    return _usuario_desde_token(request, cred)


def usuario_actual(usuario: UsuarioActual = Depends(usuario_sesion)) -> UsuarioActual:
    """Usuario autenticado y habilitado para operar."""
    if not usuario.mfa_verificada:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Falta verificar el segundo factor (código de verificación).")
    if usuario.debe_cambiar_contrasena:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Debe cambiar su contraseña antes de continuar.")
    if usuario.contexto_pendiente:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Elija con qué rol va a trabajar.")
    return usuario


def verificar_permiso(usuario: UsuarioActual, modulo: str, accion: str) -> None:
    if not usuario.puede(modulo, accion):
        try:
            registrar_acceso(usuario.nombre_usuario, "ACCESO_DENEGADO", usuario.ip, f"{accion} en {modulo}")
        except Exception:
            pass
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            f"Su rol ({usuario.codigo_rol}) no tiene permiso para {accion.replace('_', ' ')} en el módulo {modulo}.",
        )


def requiere(modulo: str, accion: str):
    def dependencia(usuario: UsuarioActual = Depends(usuario_actual)) -> UsuarioActual:
        verificar_permiso(usuario, modulo, accion)
        return usuario

    return dependencia


def exigir_paso_adicional(usuario: UsuarioActual) -> None:
    """Acciones críticas: si el usuario tiene el MFA activo, debe haber escrito un código en los últimos 5 minutos.
    (Mientras no lo active, rige el plazo de gracia y la acción se permite.)"""
    if usuario.mfa_activo and not usuario.mfa_reciente:
        raise HTTPException(428, "Acción crítica: confirme con su código de verificación.")
