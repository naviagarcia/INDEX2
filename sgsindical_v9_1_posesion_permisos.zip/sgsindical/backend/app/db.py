"""Acceso a PostgreSQL: pool de conexiones y transacciones con contexto de auditoría."""
from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

import psycopg
from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

from .config import config

pool: ConnectionPool | None = None


def abrir_pool() -> None:
    global pool
    if pool is None:
        pool = ConnectionPool(
            config.DATABASE_URL,
            min_size=config.POOL_MIN,
            max_size=config.POOL_MAX,
            kwargs={"row_factory": dict_row, "application_name": "sgsindical_api"},
            open=True,
            timeout=15,
        )


def cerrar_pool() -> None:
    global pool
    if pool is not None:
        pool.close()
        pool = None


@contextmanager
def transaccion(usuario=None, ip: str | None = None, sesion: str | None = None) -> Iterator[psycopg.Connection]:
    """Abre una transacción atómica.

    - Todo lo que ocurre dentro se confirma junto o se revierte junto.
    - Se fijan app.usuario, app.id_usuario, app.ip y app.sesion SOLO para esta transacción (set_config(..., true)).
      La base identifica al usuario por el token de su sesión (app.sesion); app.id_usuario es solo informativo.
      la auditoría registra quién hizo cada cambio y la seguridad por filas de PostgreSQL limita
      los datos al ámbito territorial del usuario.
    - `usuario` puede ser el usuario autenticado (UsuarioActual) o solo un nombre (procesos internos).
    """
    if pool is None:
        abrir_pool()
    assert pool is not None
    if hasattr(usuario, "nombre_usuario"):
        nombre, id_usuario, ip = usuario.nombre_usuario, usuario.id_usuario, ip or usuario.ip
        sesion = sesion or getattr(usuario, "sid", "") or None
    else:
        nombre, id_usuario = usuario, None
    with pool.connection() as conn:
        with conn.transaction():
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT set_config('app.usuario', %s, true), set_config('app.ip', %s, true), "
                    "set_config('app.id_usuario', %s, true), set_config('app.zona', %s, true), "
                    "set_config('app.sesion', %s, true)",
                    (nombre or "", ip or "", str(id_usuario) if id_usuario else "", config.ZONA_HORARIA, sesion or ""),
                )
            yield conn
