"""Posesión de directivos con el registro del inspector y permisos sindicales (db/18).

Las reglas las decide la base de datos: la junta designa con su acta y la posesión llega con el registro del
inspector (gobernanza.fn_designar_directivo); los permisos los firman el Presidente o el Secretario General que
ejercen el cargo (gobernanza.fn_solicitar_permiso), con la antelación, la junta habilitada y el cruce de fechas
que verifica la base. Aquí solo se exponen las acciones y se genera la carta dirigida a la sede central."""
from __future__ import annotations

import io
from datetime import date
from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException
from fastapi.responses import Response

from .afiliacion import _id_acta
from .config import config, institucional
from .crud import serializar
from .db import transaccion
from .seguridad import UsuarioActual, requiere, usuario_actual

router = APIRouter(tags=["permisos"])

FINALIDADES = {
    "ASAMBLEA": "asistencia a asamblea sindical",
    "NEGOCIACION_COLECTIVA": "negociación colectiva",
    "CAPACITACION": "capacitación sindical",
    "ACTIVIDAD_DIRECTIVA": "ejercicio de funciones directivas sindicales",
    "OTRA": "actividad sindical",
}


def _fecha(v: Any) -> date | None:
    if v in (None, ""):
        return None
    if isinstance(v, date):
        return v
    try:
        return date.fromisoformat(str(v)[:10])
    except ValueError:
        raise HTTPException(400, f"Fecha no válida: «{v}». Use el formato AAAA-MM-DD.")


# ================================================================ designaciones de directivos
@router.post("/api/directivos/designaciones")
def designar(datos: dict = Body(...), usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "registrar"))):
    """La junta designa con su acta; si el registro vigente ya la incluye (emitido el día del acta o después),
    la posesión es inmediata; si no, queda pendiente del próximo registro del inspector."""
    with transaccion(usuario) as conn:
        i = conn.execute("SELECT gobernanza.fn_designar_directivo(%s, %s, %s, %s, %s, %s, %s) AS i",
                         (datos.get("id_persona"), datos.get("id_estamento"), datos.get("id_cargo"),
                          datos.get("tipo_nombramiento") or "ELECCION", _id_acta(conn, datos.get("acta") or datos.get("id_acta")),
                          datos.get("id_directivo_saliente") or None, datos.get("observacion"))).fetchone()["i"]
        f = conn.execute("SELECT * FROM gobernanza.v_designaciones WHERE id_designacion = %s", (i,)).fetchone()
    return serializar(f)


@router.post("/api/directivos/designaciones/{id_designacion}/anular")
def anular_designacion(id_designacion: int, datos: dict = Body(...), usuario: UsuarioActual = Depends(requiere("GOBERNANZA", "actualizar"))):
    with transaccion(usuario) as conn:
        r = conn.execute("SELECT gobernanza.fn_anular_designacion(%s, %s) AS r", (id_designacion, datos.get("motivo"))).fetchone()["r"]
    return {"estado": r}


@router.get("/api/directivos/ocupante")
def ocupante(id_estamento: int, id_cargo: int, usuario: UsuarioActual = Depends(usuario_actual)):
    """Quién ocupa hoy un cargo (para indicar que la designación lo reemplaza)."""
    with transaccion(usuario) as conn:
        f = conn.execute("""SELECT d.id_directivo_estamento, gobernanza.fn_nombre_persona(d.id_persona) AS nombre, d.id_persona
                              FROM gobernanza.directivo_estamento d
                             WHERE d.id_estamento = %s AND d.id_cargo = %s AND d.fecha_retiro IS NULL""", (id_estamento, id_cargo)).fetchone()
    return serializar(f) if f else None


# ================================================================ permisos sindicales
@router.get("/api/permisos/juntas")
def juntas_para_permiso(usuario: UsuarioActual = Depends(usuario_actual)):
    """Juntas en las que el usuario puede firmar solicitudes (Presidencia o Secretaría General en ejercicio)."""
    with transaccion(usuario) as conn:
        return [serializar(f) for f in conn.execute("SELECT * FROM gobernanza.fn_juntas_para_permiso()").fetchall()]


@router.get("/api/permisos/elegibles")
def elegibles(id_estamento: int, q: str = "", usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        return [serializar(f) for f in conn.execute("SELECT * FROM gobernanza.fn_afiliados_para_permiso(%s, %s)", (id_estamento, q)).fetchall()]


def _cargar(conn, id_permiso: int) -> dict:
    p = conn.execute("""SELECT v.*, p.descripcion, p.lugar, p.jornada, p.horas_dia, p.distribucion, p.destinatario, p.motivo_excepcional,
                               p.cargo_firma, p.firma_por_suplencia, p.antelacion_requerida, p.fecha_acto, p.observacion_respuesta,
                               p.respuesta_extemporanea, p.id_persona_firma, gobernanza.fn_nombre_persona(p.id_persona_firma) AS nombre_firma,
                               emp.nit, emp.direccion, emp.municipio AS municipio_empresa
                          FROM gobernanza.v_permisos_sindicales v
                          JOIN gobernanza.permiso_sindical p ON p.id_permiso = v.id_permiso
                          CROSS JOIN LATERAL gobernanza.fn_empresa_permiso(p.id_empresa) emp
                         WHERE v.id_permiso = %s""", (id_permiso,)).fetchone()
    if not p:
        raise HTTPException(404, "El permiso no existe o está fuera de su ámbito.")
    b = conn.execute("SELECT * FROM gobernanza.v_permisos_beneficiarios WHERE id_permiso = %s ORDER BY afiliado", (id_permiso,)).fetchall()
    return {**serializar(p), "beneficiarios": [serializar(x) for x in b]}


@router.post("/api/permisos")
def solicitar(datos: dict = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    personas = datos.get("personas") or []
    if not isinstance(personas, list):
        raise HTTPException(400, "Indique la lista de afiliados.")
    with transaccion(usuario) as conn:
        i = conn.execute("""SELECT gobernanza.fn_solicitar_permiso(%s, %s::BIGINT[], %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) AS i""",
                         (datos.get("id_estamento"), [int(x) for x in personas], datos.get("finalidad"), datos.get("descripcion"),
                          _fecha(datos.get("fecha_inicio")), _fecha(datos.get("fecha_fin")), datos.get("jornada") or "COMPLETA",
                          datos.get("horas_dia") or None, datos.get("distribucion"), datos.get("lugar"), bool(datos.get("excepcional")),
                          datos.get("motivo_excepcional"), datos.get("destinatario"))).fetchone()["i"]
        return _cargar(conn, i)


@router.get("/api/permisos/{id_permiso}")
def ver(id_permiso: int, usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        return _cargar(conn, id_permiso)


@router.post("/api/permisos/{id_permiso}/respuesta")
def responder(id_permiso: int, datos: dict = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    import json
    with transaccion(usuario) as conn:
        r = conn.execute("SELECT gobernanza.fn_responder_permiso(%s, %s, %s, %s, %s::jsonb, %s) AS r",
                         (id_permiso, datos.get("acto"), _fecha(datos.get("fecha_acto")), _fecha(datos.get("fecha_notificacion")),
                          json.dumps(datos.get("decisiones") or []), datos.get("observacion"))).fetchone()["r"]
        return {"resultado": r, **_cargar(conn, id_permiso)}


@router.post("/api/permisos/{id_permiso}/anular")
def anular(id_permiso: int, datos: dict = Body(...), usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        r = conn.execute("SELECT gobernanza.fn_anular_permiso(%s, %s) AS r", (id_permiso, datos.get("motivo"))).fetchone()["r"]
    return {"estado": r}


# ---------------------------------------------------------------- carta de solicitud (PDF)
MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]


def _larga(d: Any) -> str:
    d = _fecha(d)
    return f"{d.day} de {MESES[d.month - 1]} de {d.year}" if d else ""


def pdf_carta(p: dict) -> bytes:
    from xml.sax.saxutils import escape as e

    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
    from reportlab.lib.pagesizes import LETTER
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    inst = institucional()
    est = getSampleStyleSheet()
    normal = ParagraphStyle("n", parent=est["Normal"], fontName="Helvetica", fontSize=10.5, leading=15, alignment=TA_JUSTIFY)
    titulo = ParagraphStyle("t", parent=normal, fontName="Helvetica-Bold", fontSize=12.5, leading=17, alignment=TA_CENTER)
    centro = ParagraphStyle("c", parent=normal, alignment=TA_CENTER, fontSize=9.5, leading=13)
    celda = ParagraphStyle("cel", parent=normal, fontSize=9, leading=12, alignment=TA_LEFT)
    peq = ParagraphStyle("p", parent=normal, fontSize=8, leading=11, alignment=TA_LEFT, textColor=colors.HexColor("#444444"))

    nombre = inst.get("nombre_sindicato") or config.SINDICATO_NOMBRE
    sigla = inst.get("sigla") or ""
    nit = inst.get("nit") or ""
    finalidad = FINALIDADES.get(p["finalidad"], "actividad sindical")
    jornada = "jornada completa" if p["jornada"] == "COMPLETA" else f"jornada parcial de {p['horas_dia']} horas por día"
    rango = (f"el {_larga(p['fecha_inicio'])}" if p["fecha_inicio"] == p["fecha_fin"]
             else f"del {_larga(p['fecha_inicio'])} al {_larga(p['fecha_fin'])}")

    h = [Paragraph(e(nombre.upper()), titulo),
         Paragraph(e(" · ".join(x for x in (sigla, f"NIT {nit}" if nit else "", p["junta"]) if x)), centro),
         Spacer(1, 16),
         Paragraph(f"{e(p.get('municipio_empresa') or '')}{', ' if p.get('municipio_empresa') else ''}{e(_larga(p['fecha_solicitud']))}", normal),
         Paragraph(f"<b>{e(p['consecutivo'])}</b>", normal), Spacer(1, 10),
         Paragraph("Señor(a)<br/><b>" + e(p["destinatario"]) + "</b><br/>" + e(p["empresa"])
                   + (f"<br/>{e(p['direccion'])}" if p.get("direccion") else "")
                   + (f"<br/>{e(p['municipio_empresa'])}" if p.get("municipio_empresa") else ""), normal),
         Spacer(1, 10),
         Paragraph(f"<b>Asunto:</b> solicitud de permiso sindical — {e(finalidad)}, {e(rango)}.", normal), Spacer(1, 10),
         Paragraph(
             f"En nombre de {e(nombre)}{' (' + e(sigla) + ')' if sigla else ''}, y de conformidad con los artículos 2.2.2.5.3 y 2.2.2.5.4 "
             "del Decreto 1072 de 2015, modificados por el Decreto 720 de 2024, solicito de manera respetuosa conceder permiso "
             f"sindical remunerado a los servidores relacionados a continuación, {e(rango)}, en {e(jornada)}, con la siguiente finalidad: "
             f"<b>{e(finalidad)}</b>. {e(p['descripcion'].rstrip('.'))}."
             + (f" Lugar: {e(p['lugar'])}." if p.get("lugar") else "")
             + (f" Distribución: {e(p['distribucion'])}." if p.get("distribucion") else ""), normal),
         Spacer(1, 8)]
    if p.get("excepcional") == "SÍ":
        h += [Paragraph(f"Por tratarse de un caso excepcional (parágrafo 1 del artículo 2.2.2.5.4), la solicitud se presenta con menor "
                        f"antelación por el siguiente motivo: {e(p.get('motivo_excepcional') or '')}", normal), Spacer(1, 8)]
    filas = [[Paragraph("<b>Nombre</b>", celda), Paragraph("<b>Identificación</b>", celda), Paragraph("<b>Calidad</b>", celda),
              Paragraph("<b>Días hábiles</b>", celda)]]
    for b in p["beneficiarios"]:
        calidad = f"Directivo: {b['cargo_directivo']}" if b["calidad"] == "DIRECTIVO" and b.get("cargo_directivo") else (
            "Directivo" if b["calidad"] == "DIRECTIVO" else "Delegado")
        filas.append([Paragraph(e(b["afiliado"]), celda), Paragraph(e(b["identificacion"]), celda), Paragraph(e(calidad), celda),
                      Paragraph(str(b["dias_solicitados"]), celda)])
    t = Table(filas, colWidths=[5.6 * cm, 3.2 * cm, 5.6 * cm, 2.0 * cm], repeatRows=1)
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#999999")),
                           ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#EEEEEE")), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    h += [t, Spacer(1, 10),
          Paragraph("Conforme a la norma citada, agradecemos dar respuesta de fondo mediante acto administrativo motivado que indique el "
                    "nombre de cada servidor, la finalidad y la duración del permiso, notificado a la organización sindical dentro de la "
                    "jornada laboral y como mínimo dentro de los tres (3) días anteriores al inicio del permiso. La única razón para "
                    "negarlo o limitarlo es la afectación de la debida prestación del servicio; si no se responde en los términos, el permiso "
                    "se entiende concedido para todos los efectos.", normal),
          Spacer(1, 26), Paragraph("Cordialmente,", normal), Spacer(1, 30),
          Paragraph(f"<b>{e(p['nombre_firma'] or '')}</b><br/>{e(p['cargo_firma'])}"
                    f"{' (suplente)' if p.get('firma_por_suplencia') else ''}<br/>{e(p['junta'])}", normal),
          Spacer(1, 26),
          Paragraph(f"Solicitud {e(p['consecutivo'])} generada en SGSINDICAL el {e(_larga(p['fecha_solicitud']))}. Los datos personales de esta "
                    "comunicación se tratan conforme a la Ley 1581 de 2012 y se usan solo para el trámite del permiso.", peq)]
    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=LETTER, leftMargin=2.5 * cm, rightMargin=2.5 * cm, topMargin=2.0 * cm, bottomMargin=2 * cm,
                      title=f"Permiso sindical {p['consecutivo']}", author=nombre).build(h)
    return buf.getvalue()


@router.get("/api/permisos/{id_permiso}/carta.pdf")
def carta(id_permiso: int, usuario: UsuarioActual = Depends(usuario_actual)):
    with transaccion(usuario) as conn:
        p = _cargar(conn, id_permiso)
    if p["estado"] == "ANULADO":
        raise HTTPException(409, "El permiso está anulado.")
    return Response(pdf_carta(p), media_type="application/pdf", headers={
        "Content-Disposition": f'attachment; filename="permiso_{p["consecutivo"]}.pdf"', "Cache-Control": "no-store"})
