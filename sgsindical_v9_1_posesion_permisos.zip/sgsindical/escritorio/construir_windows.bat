@echo off
REM Genera dist\SGSINDICAL\SGSINDICAL.exe  (ejecutar desde la carpeta escritorio, con Python 3.11+)
cd /d %~dp0
python -m venv .venv || goto :error
call .venv\Scripts\activate
pip install -r requirements-escritorio.txt || goto :error
pyinstaller --noconfirm --windowed --name SGSINDICAL ^
  --paths ..\backend ^
  --add-data "..\backend\frontend_dist;frontend_dist" ^
  --hidden-import app.main --collect-submodules app ^
  --collect-submodules uvicorn --collect-submodules psycopg --collect-submodules psycopg_binary ^
  sgsindical_escritorio.py || goto :error
copy /Y escritorio.ini.ejemplo dist\SGSINDICAL\escritorio.ini
copy /Y ..\backend\.env.ejemplo dist\SGSINDICAL\.env.ejemplo
echo.
echo Listo: dist\SGSINDICAL\SGSINDICAL.exe  (edite escritorio.ini antes de distribuir)
goto :eof
:error
echo ERROR durante la construccion.
exit /b 1
