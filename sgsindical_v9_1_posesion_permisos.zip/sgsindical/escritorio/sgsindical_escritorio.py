"""SGSINDICAL — Aplicación de escritorio.

Abre una ventana nativa (pywebview) con la interfaz. Dos modos, según escritorio.ini:

  [app]
  modo = central                         ; varios usuarios: todos se conectan al servidor FastAPI
  servidor = https://sgsindical.midominio.org

  [app]
  modo = local                           ; un solo equipo: el backend corre dentro de esta app
                                         ; (lee DATABASE_URL, JWT_SECRET, etc. del archivo .env)

En modo central las credenciales de PostgreSQL nunca se guardan en los equipos de los usuarios.
El modo local guarda en el equipo la contraseña de la base de datos: úselo solo para pruebas o en un único
equipo de confianza (la aplicación lo advierte en pantalla).
"""
from __future__ import annotations

import os

import configparser
import platform
import socket
import sys
import threading
import time
import urllib.request
from pathlib import Path

import webview  # pywebview

TITULO = "SGSINDICAL — Sistema de Gestión Sindical"


def carpeta_app() -> Path:
    return Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent


def leer_config() -> configparser.ConfigParser:
    cfg = configparser.ConfigParser()
    cfg.read_dict({"app": {"modo": "local", "servidor": "", "ancho": "1366", "alto": "860"}})
    for ruta in (carpeta_app() / "escritorio.ini", Path.home() / ".sgsindical" / "escritorio.ini"):
        if ruta.is_file():
            cfg.read(ruta, encoding="utf-8")
            break
    return cfg


def puerto_libre() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def esperar(url: str, segundos: float = 25) -> bool:
    limite = time.time() + segundos
    while time.time() < limite:
        try:
            with urllib.request.urlopen(url + "/api/salud", timeout=2) as r:
                if r.status == 200:
                    return True
        except Exception:
            time.sleep(0.3)
    return False


def iniciar_backend_local() -> tuple[str, object]:
    """Levanta FastAPI en 127.0.0.1 (solo accesible desde este equipo) en un hilo."""
    for backend in (carpeta_app() / "backend", carpeta_app().parent / "backend"):
        if (backend / "app").is_dir():
            sys.path.insert(0, str(backend))
            break
    import uvicorn
    os.environ["SGS_MODO_LOCAL"] = "1"   # la interfaz muestra la advertencia de modo local
    from app.main import app

    puerto = puerto_libre()
    servidor = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=puerto, loop="asyncio", http="h11",
                                             log_level="warning", access_log=False))
    threading.Thread(target=servidor.run, daemon=True).start()
    return f"http://127.0.0.1:{puerto}", servidor


def pagina_error(titulo: str, detalle: str) -> str:
    return f"""<!doctype html><html lang="es"><meta charset="utf-8">
    <body style="font-family:system-ui,Segoe UI,sans-serif;background:#14293b;color:#e6ebf1;display:grid;place-items:center;height:100vh;margin:0">
    <div style="max-width:560px;background:#19202a;padding:32px;border-radius:12px">
    <h2 style="margin-top:0">{titulo}</h2><p style="line-height:1.5">{detalle}</p>
    <p style="color:#98a4b3;font-size:13px">Revise escritorio.ini y el archivo .env junto al programa, o contacte al administrador.</p>
    </div></body></html>"""


def main() -> None:
    cfg = leer_config()["app"]
    modo = cfg.get("modo", "local").strip().lower()
    servidor_local = None

    if modo == "central":
        url = cfg.get("servidor", "").rstrip("/")
        if not url:
            html = pagina_error("Falta configurar el servidor", "En escritorio.ini indique <code>servidor = https://…</code>.")
        elif not esperar(url, 10):
            html = pagina_error("No hay conexión con el servidor", f"No se pudo contactar <code>{url}</code>. Verifique la red o que el servidor esté encendido.")
        else:
            html = None
    else:
        try:
            url, servidor_local = iniciar_backend_local()
            html = None if esperar(url) else pagina_error("El servicio local no arrancó", "Revise DATABASE_URL en el archivo .env y que PostgreSQL esté encendido.")
        except Exception as e:  # noqa: BLE001
            url, html = "", pagina_error("No se pudo iniciar SGSINDICAL", f"{type(e).__name__}: {e}")

    ventana_args = dict(width=cfg.getint("ancho", 1366), height=cfg.getint("alto", 860), min_size=(1024, 640),
                        text_select=True, confirm_close=True)
    if html:
        webview.create_window(TITULO, html=html, **ventana_args)
    else:
        webview.create_window(TITULO, url, **ventana_args)

    # private_mode: no guarda cookies ni almacenamiento entre ejecuciones (la sesión muere al cerrar la ventana)
    webview.start(private_mode=True, gui="edgechromium" if platform.system() == "Windows" else None)

    if servidor_local is not None:
        servidor_local.should_exit = True


if __name__ == "__main__":
    main()
