#!/usr/bin/env bash
# Genera dist/SGSINDICAL/ (Linux o macOS). Ejecutar desde la carpeta escritorio.
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements-escritorio.txt
pyinstaller --noconfirm --windowed --name SGSINDICAL \
  --paths ../backend \
  --add-data "../backend/frontend_dist:frontend_dist" \
  --hidden-import app.main --collect-submodules app \
  --collect-submodules uvicorn --collect-submodules psycopg --collect-submodules psycopg_binary \
  sgsindical_escritorio.py
cp escritorio.ini.ejemplo dist/SGSINDICAL/escritorio.ini
echo "Listo: dist/SGSINDICAL/"
